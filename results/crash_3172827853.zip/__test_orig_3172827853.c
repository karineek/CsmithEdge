/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 2ceb80e
 * Options:   --seed 3172827853
 * Seed:      3172827853
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_9 = 0xA319L;
static uint8_t g_14 = 0x41L;
static int32_t g_19 = 0L;
static int32_t *g_18 = &g_19;
static int32_t *g_22 = &g_19;
static int32_t ** volatile g_21 = &g_22;/* VOLATILE GLOBAL g_21 */
static uint16_t g_48 = 65535UL;
static int16_t g_51 = (-7L);
static int32_t g_53 = 0xFFC5A258L;
static uint32_t g_54 = 0x6367AFFFL;
static int16_t g_58 = 4L;
static int16_t *g_57 = &g_58;
static uint64_t g_101 = 0xE8FED2B77DEECC15LL;
static int32_t g_136[7] = {0x7B43BFD2L,(-1L),0x7B43BFD2L,0x7B43BFD2L,(-1L),0x7B43BFD2L,0x7B43BFD2L};
static int32_t g_159 = 0x3A92D299L;
static int8_t g_179[10] = {0L,(-4L),0L,(-4L),0L,(-4L),0L,(-4L),0L,(-4L)};
static uint32_t g_191 = 5UL;
static volatile int32_t g_223 = 8L;/* VOLATILE GLOBAL g_223 */
static volatile int32_t g_224 = 0xB365E47CL;/* VOLATILE GLOBAL g_224 */
static volatile int32_t g_225 = 8L;/* VOLATILE GLOBAL g_225 */
static volatile int32_t *g_222[9] = {&g_225,&g_224,&g_225,&g_224,&g_225,&g_224,&g_225,&g_224,&g_225};
static volatile int32_t * volatile * const g_221 = &g_222[6];
static uint8_t g_251 = 255UL;
static int8_t g_313 = 0x93L;
static uint32_t g_342[10] = {0UL,0xBBC769E7L,0xBBC769E7L,0UL,0xBBC769E7L,0xBBC769E7L,0UL,0xBBC769E7L,0xBBC769E7L,0UL};
static int64_t g_344[7][9][1] = {{{(-10L)},{(-1L)},{(-4L)},{0x04996D6FC5D29383LL},{(-1L)},{0xD559065AF7AC0CD2LL},{0x1CA1A8B28CE6065ELL},{(-1L)},{0x3BB5358F03E51691LL}},{{0x0304D74A20B93434LL},{1L},{0xE8291654FE5E0AE8LL},{0L},{0x0304D74A20B93434LL},{0x1CA1A8B28CE6065ELL},{0x44EEF87003E30353LL},{0x79D063AE7AD94609LL},{0xE8291654FE5E0AE8LL}},{{(-1L)},{1L},{1L},{1L},{0x79D063AE7AD94609LL},{0x0304D74A20B93434LL},{0xE1AED80D39D85764LL},{0x0304D74A20B93434LL},{0x79D063AE7AD94609LL}},{{1L},{1L},{1L},{(-1L)},{0xE8291654FE5E0AE8LL},{0x79D063AE7AD94609LL},{0x44EEF87003E30353LL},{0x1CA1A8B28CE6065ELL},{0x0304D74A20B93434LL}},{{0L},{0xE8291654FE5E0AE8LL},{1L},{0xBC21BE6D622A8838LL},{1L},{0xE8291654FE5E0AE8LL},{0L},{0x0304D74A20B93434LL},{0x1CA1A8B28CE6065ELL}},{{0x44EEF87003E30353LL},{0x79D063AE7AD94609LL},{0xE8291654FE5E0AE8LL},{(-1L)},{1L},{1L},{1L},{0x79D063AE7AD94609LL},{0x0304D74A20B93434LL}},{{0xE1AED80D39D85764LL},{0x0304D74A20B93434LL},{0x79D063AE7AD94609LL},{1L},{1L},{1L},{(-1L)},{0xE8291654FE5E0AE8LL},{0x79D063AE7AD94609LL}}};
static const volatile uint32_t * volatile *g_382 = (void*)0;
static const volatile uint32_t * volatile * volatile *g_381 = &g_382;
static uint16_t g_406[5] = {0xF38EL,0xF38EL,0xF38EL,0xF38EL,0xF38EL};
static int32_t *g_410 = &g_136[5];
static int32_t * const ***g_485 = (void*)0;
static int32_t g_491 = 0xB5E93056L;
static const int32_t *g_508[3][3] = {{(void*)0,(void*)0,(void*)0},{&g_53,&g_159,&g_53},{(void*)0,(void*)0,(void*)0}};
static uint16_t *g_548 = &g_406[1];
static int16_t * volatile *g_599 = &g_57;
static int16_t * volatile ** volatile g_598 = &g_599;/* VOLATILE GLOBAL g_598 */
static int16_t * volatile ** volatile *g_597 = &g_598;
static const uint32_t g_607 = 0xF9B3F220L;
static uint32_t *g_678 = (void*)0;
static uint32_t **g_677 = &g_678;
static uint32_t ***g_676 = &g_677;
static uint32_t ****g_675 = &g_676;
static uint32_t g_710 = 0xAABD6E1DL;
static int32_t g_711 = 0x26B8D118L;
static volatile int16_t **g_747 = (void*)0;
static volatile int16_t ***g_746 = &g_747;
static volatile int16_t ****g_745 = &g_746;
static int32_t g_798 = (-1L);
static uint32_t *****g_906 = (void*)0;
static int16_t g_914[10] = {0xA403L,0xA403L,0xA403L,0xA403L,0xA403L,0xA403L,0xA403L,0xA403L,0xA403L,0xA403L};
static int32_t **g_958 = &g_410;
static int32_t ***g_995 = (void*)0;
static int32_t ****g_994[4] = {&g_995,&g_995,&g_995,&g_995};
static int32_t *****g_993 = &g_994[1];
static int64_t g_1004 = 1L;
static volatile int32_t g_1069 = 3L;/* VOLATILE GLOBAL g_1069 */
static volatile int32_t *g_1068 = &g_1069;
static volatile int32_t **g_1067 = &g_1068;
static uint32_t g_1104 = 4294967289UL;
static uint64_t g_1166 = 0UL;
static int32_t *g_1321 = &g_53;
static uint64_t g_1329 = 0xF1914BF23AC5143ELL;
static uint16_t g_1332 = 0UL;
static uint16_t **g_1434 = &g_548;
static int8_t g_1475 = 0x13L;
static int16_t *g_1492 = &g_914[0];
static int32_t ** const *g_1599[3] = {&g_958,&g_958,&g_958};
static int32_t ** const **g_1598 = &g_1599[2];
static int32_t ** const ***g_1597 = &g_1598;
static int32_t **g_1612 = (void*)0;
static uint8_t g_1727 = 254UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int64_t  func_15(int64_t  p_16, int16_t * p_17);
static int32_t  func_29(uint8_t  p_30, int32_t ** p_31, uint32_t  p_32, int32_t * p_33, int16_t * p_34);
static uint8_t  func_63(int8_t  p_64, int16_t * const  p_65, uint32_t  p_66);
static int8_t  func_67(uint64_t  p_68);
static uint16_t  func_71(int16_t * p_72, int16_t * p_73, const int32_t  p_74);
static int16_t * func_75(uint32_t  p_76, int16_t  p_77, int32_t * p_78, int16_t * p_79, uint32_t  p_80);
static uint32_t  func_81(int16_t * p_82, int16_t  p_83, const uint16_t  p_84, int16_t * p_85);
static int8_t  func_87(int16_t  p_88, int32_t * p_89, int16_t ** p_90);
static uint8_t  func_93(int16_t ** p_94, uint16_t  p_95, uint16_t  p_96);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_18 g_21 g_19 g_48 g_54 g_57 g_58 g_101 g_51 g_53 g_342 g_410 g_136 g_745 g_746 g_599 g_191 g_251 g_993 g_914 g_548 g_406 g_179 g_313 g_958 g_676 g_677 g_678 g_1004 g_1492 g_710 g_1332 g_1434 g_1166 g_491 g_159 g_1597 g_1598 g_1599 g_1612 g_1321 g_994 g_995 g_607 g_798 g_1475 g_1727 g_1329 g_9 g_224
 * writes: g_9 g_18 g_22 g_48 g_51 g_53 g_101 g_54 g_58 g_136 g_344 g_191 g_251 g_993 g_1004 g_406 g_678 g_1166 g_179 g_1104 g_342 g_410 g_798
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_7[9][10] = {{0x3E76E5B1L,0x3E76E5B1L,0xE948708EL,0x6B471DFDL,0x3E76E5B1L,0x5E790E86L,0x6B471DFDL,0x6B471DFDL,0x5E790E86L,0x3E76E5B1L},{0x3E76E5B1L,6L,6L,0x3E76E5B1L,(-1L),6L,0x6B471DFDL,(-1L),(-1L),0x6B471DFDL},{(-1L),0x3E76E5B1L,6L,6L,0x3E76E5B1L,(-1L),6L,0x6B471DFDL,(-1L),(-1L)},{0x3E76E5B1L,0x6B471DFDL,0xE948708EL,0x3E76E5B1L,0x3E76E5B1L,0xE948708EL,0x6B471DFDL,0x3E76E5B1L,0x5E790E86L,0x6B471DFDL},{0x3E76E5B1L,(-1L),6L,0x6B471DFDL,(-1L),(-1L),0x6B471DFDL,6L,(-1L),0x3E76E5B1L},{(-1L),0x6B471DFDL,6L,(-1L),0x3E76E5B1L,6L,6L,0x3E76E5B1L,(-1L),6L},{0x3E76E5B1L,0x3E76E5B1L,0xE948708EL,0x6B471DFDL,0x3E76E5B1L,0x5E790E86L,0x6B471DFDL,0x6B471DFDL,0x5E790E86L,0x3E76E5B1L},{0x3E76E5B1L,6L,6L,0x3E76E5B1L,(-1L),6L,0x6B471DFDL,(-1L),(-1L),0x6B471DFDL},{(-1L),0x3E76E5B1L,6L,6L,0x3E76E5B1L,(-1L),6L,0x6B471DFDL,(-1L),(-1L)}};
    int16_t *l_8 = &g_9;
    int32_t l_47 = 8L;
    uint64_t l_49 = 8UL;
    int16_t *l_50 = &g_51;
    int32_t *l_52[4] = {&g_53,&g_53,&g_53,&g_53};
    int32_t l_55[4] = {0x79815C87L,0x79815C87L,0x79815C87L,0x79815C87L};
    uint16_t l_56 = 0UL;
    int32_t l_1710 = 0x85E938E2L;
    int16_t l_1711 = 0x6506L;
    int16_t l_1720 = 9L;
    int16_t **l_1726 = &g_1492;
    int16_t ***l_1725 = &l_1726;
    int16_t ****l_1724 = &l_1725;
    int16_t *****l_1723 = &l_1724;
    int8_t l_1728[3][10][1] = {{{0x46L},{0xA7L},{0x56L},{0xA7L},{0x46L},{(-8L)},{0xCBL},{(-2L)},{0xCBL},{2L}},{{(-1L)},{(-2L)},{0x46L},{(-2L)},{(-1L)},{2L},{0x56L},{(-8L)},{0x56L},{2L}},{{(-1L)},{(-2L)},{0x46L},{(-2L)},{(-1L)},{2L},{0x56L},{(-8L)},{0x56L},{2L}}};
    int i, j, k;
    l_1711 = ((*g_1321) = (+(((safe_rshift_func_int32_t_s_u((l_1710 &= (safe_div_func_int16_t_s_s(((*l_8) = l_7[7][3]), (safe_div_func_uint64_t_u_u((((safe_rshift_func_int8_t_s_s((g_14 & func_15(g_14, l_8)), (safe_sub_func_uint8_t_u_u(((((((safe_mod_func_int8_t_s_s((safe_div_func_int32_t_s_s(func_29((((safe_lshift_func_int8_t_s_u((0x2199L && ((safe_mul_func_int16_t_s_s((safe_mod_func_int32_t_s_s((g_53 = ((((*l_50) = ((g_48 ^= ((l_47 = (safe_add_func_uint8_t_u_u((((0x4373L < (safe_add_func_uint64_t_u_u(1UL, g_19))) | l_7[3][7]) && (-9L)), 4UL))) && 18446744073709551607UL)) , l_49)) | l_7[2][0]) == 0x6302L)), g_54)), g_19)) == 1UL)), 6)) <= l_55[2]) > l_56), &l_52[0], g_14, &g_19, g_57), 0x5962E1A6L)), l_49)) > (-6L)) , (***g_1598)) == &l_55[3]) >= g_1475) || 0x54L), l_56)))) <= l_55[2]) != l_56), g_14))))), 27)) >= l_49) & g_1332)));
    (*g_410) |= (safe_mod_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s(((safe_mod_func_int8_t_s_s((safe_mod_func_int8_t_s_s(((((l_1720 && (safe_lshift_func_int8_t_s_s((&g_597 == &g_597), (1UL || (l_1723 == &g_597))))) ^ ((g_1727 || (((void*)0 != (**l_1725)) == l_1728[0][6][0])) > (*g_548))) == (*g_1321)) | 1L), 255UL)), 0xEDL)) || 18446744073709551612UL), g_1329)) < 1L), g_9));
    return g_224;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_21 g_19
 * writes: g_18 g_22
 */
static int64_t  func_15(int64_t  p_16, int16_t * p_17)
{ /* block id: 2 */
    int32_t **l_20 = &g_18;
    (*g_21) = ((*l_20) = g_18);
    return (**l_20);
}


/* ------------------------------------------ */
/* 
 * reads : g_58 g_57 g_101 g_14 g_19 g_51 g_53 g_48 g_54 g_342 g_410 g_136 g_745 g_746 g_599 g_191 g_251 g_993 g_914 g_548 g_406 g_179 g_313 g_958 g_676 g_677 g_678 g_1004 g_1492 g_710 g_1332 g_1434 g_1166 g_491 g_159 g_1597 g_1598 g_1599 g_1612 g_1321 g_994 g_995 g_607 g_798
 * writes: g_101 g_48 g_53 g_54 g_58 g_51 g_136 g_344 g_191 g_251 g_993 g_1004 g_406 g_678 g_1166 g_179 g_1104 g_342 g_410 g_798
 */
static int32_t  func_29(uint8_t  p_30, int32_t ** p_31, uint32_t  p_32, int32_t * p_33, int16_t * p_34)
{ /* block id: 10 */
    int16_t **l_86[6] = {&g_57,&g_57,&g_57,&g_57,&g_57,&g_57};
    int32_t l_99 = 0L;
    uint64_t *l_100 = &g_101;
    uint16_t *l_108[1][3][10] = {{{&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48},{&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48},{&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48,&g_48}}};
    uint32_t l_726 = 0UL;
    int32_t l_1661 = 1L;
    int32_t *l_1699 = &l_99;
    int32_t *l_1700 = (void*)0;
    int32_t *l_1701[10][9] = {{(void*)0,(void*)0,&g_159,&g_159,(void*)0,(void*)0,&g_159,&g_159,(void*)0},{&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491},{(void*)0,&g_159,&g_159,(void*)0,(void*)0,&g_159,&g_159,(void*)0,(void*)0},{(void*)0,&l_1661,(void*)0,&l_1661,(void*)0,&l_1661,(void*)0,&l_1661,(void*)0},{(void*)0,(void*)0,&g_159,&g_159,(void*)0,(void*)0,&g_159,&g_159,(void*)0},{&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491},{(void*)0,&g_159,&g_159,(void*)0,(void*)0,&g_159,&g_159,(void*)0,(void*)0},{(void*)0,&l_1661,(void*)0,&l_1661,(void*)0,&l_1661,(void*)0,&l_1661,(void*)0},{(void*)0,(void*)0,&g_159,&g_159,(void*)0,(void*)0,&g_159,&g_159,(void*)0},{&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491,&l_1661,&g_491}};
    int32_t l_1702 = (-1L);
    uint64_t l_1703 = 0xA694A3EC3B7AE453LL;
    int i, j, k;
    if ((safe_lshift_func_uint32_t_u_u((l_1661 |= (safe_mod_func_uint8_t_u_u(func_63(((*p_34) , func_67(((safe_sub_func_uint64_t_u_u((func_71(func_75(func_81((p_34 = (void*)0), (func_87((safe_sub_func_uint8_t_u_u(func_93(l_86[4], (safe_sub_func_uint32_t_u_u((((((((*g_57) < (g_48 = ((p_32 && (((*l_100) &= l_99) | (p_30 | (safe_sub_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint64_t_u_u(g_14, ((&g_51 != &g_58) , 0x508B3DEF23EAFAF4LL))), p_32)), l_99))))) , 0x0ADFL))) >= g_14) , l_99) <= g_19) & l_99) > l_99), 0x24A3AAF9L)), g_51), 0L)), &l_99, &g_57) > g_19), g_19, g_57), l_726, &l_99, g_57, p_30), g_1492, g_710) , g_179[9]), p_30)) & p_32))), &g_914[1], p_30), g_607))), p_30)))
    { /* block id: 849 */
        int8_t l_1680 = 0L;
        int32_t l_1694 = 0xC423BF48L;
        uint8_t *l_1695 = &g_251;
        int64_t l_1696[8] = {0x83F5EC703FDF546DLL,0x3C063D5A92955D6ELL,0x83F5EC703FDF546DLL,0x83F5EC703FDF546DLL,0x3C063D5A92955D6ELL,0x83F5EC703FDF546DLL,0x83F5EC703FDF546DLL,0x3C063D5A92955D6ELL};
        int8_t *l_1697[4] = {&g_179[4],&g_179[4],&g_179[4],&g_179[4]};
        int i;
        (****g_1598) = ((((safe_div_func_int64_t_s_s((safe_add_func_uint8_t_u_u((((safe_div_func_uint64_t_u_u(l_726, 0x91035552555A2144LL)) == g_19) < (safe_div_func_uint8_t_u_u((((safe_sub_func_int8_t_s_s((l_1694 = (((((((((safe_mul_func_int8_t_s_s((safe_mod_func_int16_t_s_s((((safe_sub_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((l_1680 |= (p_30 >= (*****g_1597))), (p_32 = ((((safe_add_func_int8_t_s_s(l_1661, (((safe_add_func_uint16_t_u_u((safe_mod_func_int16_t_s_s((!(((*l_1695) = ((p_32 , (*g_57)) >= (safe_mul_func_uint16_t_u_u(((safe_div_func_int64_t_s_s(p_30, l_1694)) && 0L), (*g_1492))))) != g_406[0])), (*g_1492))), 0x1078L)) , l_1694) & 0UL))) >= l_1661) , 0xFEE1L) & l_1696[6])))), l_1661)) , 0x797BC52AF8BC01F9LL) ^ g_710), 65532UL)), 0x67L)) >= l_1694) & (*p_33)) > l_99) >= p_30) | p_30) < 0x9CB7724BL) , 0x1FL) != 0xF6L)), p_30)) ^ l_99) && 0x14F6F97AL), l_1696[1]))), 0x60L)), p_30)) >= 0xA359L) & l_99) != l_1696[1]);
    }
    else
    { /* block id: 855 */
        int32_t *l_1698[5];
        int i;
        for (i = 0; i < 5; i++)
            l_1698[i] = (void*)0;
        (*p_31) = l_1698[1];
    }
    ++l_1703;
    for (g_798 = 24; (g_798 <= (-1)); g_798--)
    { /* block id: 861 */
        int16_t ***l_1709 = &l_86[5];
        int16_t ****l_1708[1];
        int i;
        for (i = 0; i < 1; i++)
            l_1708[i] = &l_1709;
        (*l_1699) = (l_1708[0] == (void*)0);
    }
    return (*p_33);
}


/* ------------------------------------------ */
/* 
 * reads : g_1598 g_1599 g_958 g_410
 * writes: g_136
 */
static uint8_t  func_63(int8_t  p_64, int16_t * const  p_65, uint32_t  p_66)
{ /* block id: 842 */
    int16_t l_1658[2];
    int32_t l_1659 = 0x49A96291L;
    int32_t l_1660 = 0L;
    int i;
    for (i = 0; i < 2; i++)
        l_1658[i] = (-3L);
    (****g_1598) = p_66;
    l_1660 = (l_1659 |= (l_1658[1] = p_66));
    return l_1659;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_67(uint64_t  p_68)
{ /* block id: 839 */
    uint64_t l_1655 = 1UL;
    ++l_1655;
    return l_1655;
}


/* ------------------------------------------ */
/* 
 * reads : g_914 g_548 g_406 g_1332 g_342 g_313 g_58 g_101 g_1434 g_51 g_19 g_1492 g_57 g_958 g_410 g_136 g_1166 g_491 g_1004 g_159 g_191 g_14 g_1597 g_1598 g_1599 g_1612 g_1321 g_53 g_993 g_994 g_995
 * writes: g_406 g_101 g_51 g_58 g_136 g_344 g_1166 g_179 g_191 g_1104 g_53 g_342 g_410
 */
static uint16_t  func_71(int16_t * p_72, int16_t * p_73, const int32_t  p_74)
{ /* block id: 760 */
    int16_t **l_1498 = (void*)0;
    int16_t ***l_1497 = &l_1498;
    uint64_t *l_1504 = &g_101;
    const int32_t l_1505[6][8][5] = {{{0x7187FBFEL,(-10L),0x7187FBFEL,0L,(-10L)},{0x4EC90FD0L,(-1L),0xDB2791A0L,0L,0xDB2791A0L},{0x295DCADEL,0x295DCADEL,0xA24A0AFCL,(-10L),(-7L)},{3L,0xE45A8954L,0xDB2791A0L,(-1L),0x88DDA34AL},{(-7L),4L,0x7187FBFEL,(-7L),0L},{0L,0xE45A8954L,0L,0xE45A8954L,0L},{0x7187FBFEL,0x7187FBFEL,0xA24A0AFCL,7L,0x7187FBFEL},{0x6E3491EAL,0x0A61D839L,0L,(-1L),(-2L)}},{{0L,4L,0x295DCADEL,0x7187FBFEL,0x7187FBFEL},{(-10L),(-1L),(-10L),0x38EED77CL,0x6E3491EAL},{0x7187FBFEL,0xA24A0AFCL,7L,0x7187FBFEL,7L},{3L,0x91034829L,0x4EC90FD0L,(-1L),0xDB2791A0L},{8L,0L,7L,7L,0L},{0xDB2791A0L,0x0A61D839L,(-10L),(-1L),(-2L)},{4L,0L,0x295DCADEL,0L,4L},{(-10L),0x91034829L,0L,0x38EED77CL,3L}},{{4L,0xA24A0AFCL,0xA24A0AFCL,4L,7L},{0xDB2791A0L,(-1L),0x4EC90FD0L,0x91034829L,3L},{8L,4L,8L,7L,4L},{3L,0x0A61D839L,(-2L),0x91034829L,(-2L)},{0x7187FBFEL,0x7187FBFEL,0x295DCADEL,4L,0L},{(-10L),(-1L),(-2L),0x38EED77CL,0xDB2791A0L},{0L,0xA24A0AFCL,8L,0L,7L},{0x6E3491EAL,(-1L),0x4EC90FD0L,(-1L),0x6E3491EAL}},{{8L,0x7187FBFEL,0xA24A0AFCL,7L,0x7187FBFEL},{0x6E3491EAL,0x0A61D839L,0L,(-1L),(-2L)},{0L,4L,0x295DCADEL,0x7187FBFEL,0x7187FBFEL},{(-10L),(-1L),(-10L),0x38EED77CL,0x6E3491EAL},{0x7187FBFEL,0xA24A0AFCL,7L,0x7187FBFEL,7L},{3L,0x91034829L,0x4EC90FD0L,(-1L),0xDB2791A0L},{8L,0L,7L,7L,0L},{0xDB2791A0L,0x0A61D839L,(-10L),(-1L),(-2L)}},{{4L,0L,0x295DCADEL,0L,4L},{(-10L),0x91034829L,0L,0x38EED77CL,3L},{4L,0xA24A0AFCL,0xA24A0AFCL,4L,7L},{0xDB2791A0L,(-1L),0x4EC90FD0L,0x91034829L,3L},{8L,4L,8L,7L,4L},{3L,0x0A61D839L,(-2L),0x91034829L,(-2L)},{0x7187FBFEL,0x7187FBFEL,0x295DCADEL,4L,0L},{(-10L),(-1L),(-2L),0x38EED77CL,0xDB2791A0L}},{{0L,0xA24A0AFCL,8L,0L,7L},{0x6E3491EAL,(-1L),0x4EC90FD0L,(-1L),0x6E3491EAL},{8L,0x7187FBFEL,0xA24A0AFCL,7L,0x7187FBFEL},{0x6E3491EAL,0x0A61D839L,0L,(-1L),(-2L)},{0L,4L,0x7187FBFEL,8L,8L},{0x88DDA34AL,0x0A61D839L,0x88DDA34AL,0x58925441L,0L},{8L,0x295DCADEL,(-10L),8L,(-10L)},{(-10L),0xF3967739L,3L,0x0A61D839L,(-2L)}}};
    int32_t l_1506[3][2][9] = {{{0xDA92F36DL,8L,0x0B0A03A1L,8L,0xDA92F36DL,0xDA92F36DL,8L,0x0B0A03A1L,8L},{1L,0L,0xF433BF27L,0xB5DB1FB6L,0x64D784DEL,(-1L),0x64D784DEL,0xB5DB1FB6L,0xF433BF27L}},{{0xDA92F36DL,0xDA92F36DL,8L,0x0B0A03A1L,8L,0xDA92F36DL,0xDA92F36DL,8L,0x0B0A03A1L},{1L,0L,1L,(-1L),1L,0xC3101F04L,0x64D784DEL,0xC3101F04L,1L}},{{0xCF19DF7FL,8L,8L,0xCF19DF7FL,0xD5485E9DL,0xCF19DF7FL,8L,8L,0xCF19DF7FL},{(-6L),(-1L),0xF433BF27L,(-1L),(-6L),(-1L),1L,0xB5DB1FB6L,1L}}};
    int32_t l_1507 = 0x1B2EE012L;
    uint32_t ** const *l_1528 = &g_677;
    int32_t l_1588 = 1L;
    uint8_t l_1617[9][9] = {{0UL,255UL,4UL,4UL,255UL,0UL,255UL,4UL,4UL},{0x0DL,0x0DL,0UL,4UL,0UL,0x0DL,0x0DL,0UL,4UL},{0xC1L,255UL,0xC1L,0UL,0UL,0xC1L,255UL,0xC1L,0UL},{0xC1L,0UL,0UL,0xC1L,255UL,0xC1L,0UL,0UL,0xC1L},{0x0DL,0UL,4UL,0UL,0x0DL,0x0DL,0UL,4UL,0UL},{0UL,255UL,4UL,4UL,255UL,0UL,255UL,4UL,4UL},{0x0DL,0x0DL,0UL,4UL,0UL,0x0DL,0x0DL,0UL,4UL},{0xC1L,255UL,0xC1L,0UL,0UL,0xC1L,255UL,0xC1L,0UL},{0xC1L,0UL,0UL,0xC1L,255UL,0xC1L,0UL,0UL,0xC1L}};
    int32_t l_1639 = 0x52AC27CCL;
    uint8_t l_1640 = 0x81L;
    int32_t *l_1643 = &g_136[2];
    int32_t *l_1644 = &g_491;
    int32_t *l_1645 = (void*)0;
    int32_t *l_1646 = &l_1506[0][1][3];
    int32_t *l_1647 = &l_1507;
    int32_t *l_1648 = &l_1506[0][1][3];
    int32_t *l_1649 = (void*)0;
    int32_t *l_1650[9][1][8] = {{{&l_1507,&g_53,&g_491,&g_491,&g_53,&l_1507,&g_136[0],&l_1506[0][1][3]}},{{&l_1507,&l_1506[0][1][3],(void*)0,&g_53,&g_136[0],&g_53,(void*)0,&l_1506[0][1][3]}},{{&g_53,(void*)0,&g_53,&g_53,&l_1506[0][1][3],&l_1506[0][1][3],&l_1506[0][1][3],&l_1506[0][1][3]}},{{&g_491,&l_1506[0][1][3],&l_1506[0][1][3],&g_491,&g_53,&l_1506[0][1][3],&l_1506[0][1][3],&l_1507}},{{(void*)0,&g_491,&g_53,&l_1506[0][1][3],&g_53,&g_491,&g_798,&l_1506[0][1][3]}},{{&l_1507,&l_1506[0][1][3],&g_798,&l_1506[0][1][3],&g_53,&g_53,&l_1506[0][1][3],&g_798}},{{&l_1506[0][1][3],&l_1506[0][1][3],&l_1506[0][1][3],&g_53,&g_53,(void*)0,&g_53,(void*)0}},{{&l_1507,&g_798,&g_53,&g_798,&l_1507,&g_491,&l_1506[0][1][3],(void*)0}},{{&g_798,&g_53,&g_53,&g_53,&g_53,&g_53,&g_53,&g_798}}};
    int16_t l_1651[9][5][5] = {{{0L,(-7L),0x17B8L,0x7E0DL,(-6L)},{1L,5L,0xA581L,0x658BL,(-1L)},{0x1D62L,0xC939L,0x17B8L,(-6L),8L},{0x6842L,0xDFBEL,0L,0L,0xDFBEL},{0x2B7CL,0xEE38L,0x7E0DL,0L,0x24BCL}},{{7L,(-1L),0L,1L,0x2257L},{0x17B8L,(-4L),0L,0x1D62L,(-6L)},{7L,0x953EL,0x658BL,0x6842L,0xAE64L},{0x2B7CL,1L,1L,0x2B7CL,0x7E0DL},{0x6842L,0x658BL,0x953EL,7L,1L}},{{0x1D62L,0L,(-4L),0x17B8L,0x3E1AL},{1L,0L,(-1L),7L,0x47DCL},{0L,0x7E0DL,0xEE38L,0x2B7CL,0xEE38L},{0L,0L,0xDFBEL,0x6842L,0L},{(-6L),0x17B8L,0xC939L,0x1D62L,0x2B7CL}},{{0x658BL,0xA581L,5L,1L,(-1L)},{0x7E0DL,0x17B8L,(-7L),0L,(-4L)},{(-1L),0L,1L,0L,(-1L)},{3L,0x7E0DL,0xA1DEL,(-6L),(-1L)},{0xAE64L,0L,7L,0x658BL,1L}},{{0xA1DEL,0L,8L,0x7E0DL,(-1L)},{(-1L),0x658BL,0xAE64L,(-1L),(-1L)},{(-1L),1L,(-1L),3L,(-4L)},{0xCE25L,0x953EL,0xD37EL,0xAE64L,(-1L)},{1L,(-4L),0xB2E6L,0xA1DEL,0x2B7CL}},{{0x8E08L,(-1L),0xD37EL,(-1L),0L},{0xCFA8L,0xEE38L,(-1L),(-1L),0xEE38L},{(-1L),0xDFBEL,0xAE64L,0xCE25L,0x47DCL},{0L,0xC939L,8L,1L,0x3E1AL},{0xD37EL,5L,7L,0x8E08L,1L}},{{0L,(-7L),0xA1DEL,0xCFA8L,0x7E0DL},{(-1L),1L,0x27D1L,0xC7EDL,1L},{(-1L),3L,(-4L),(-6L),0x2B7CL},{1L,(-1L),0xDFBEL,0x953EL,0xAE64L},{0xADFAL,0xCFA8L,0L,(-6L),0x3E1AL}},{{(-1L),1L,0xA581L,0xC7EDL,0xA581L},{0x24BCL,0x24BCL,0xB2E6L,(-1L),0xCFA8L},{0x658BL,0x953EL,7L,1L,0xC7EDL},{3L,0x1D62L,0xEE38L,0xADFAL,0xA1DEL},{1L,0x953EL,5L,(-1L),0xDFBEL}},{{0x17B8L,0x24BCL,0xADFAL,0x24BCL,0x17B8L},{0xD37EL,1L,(-1L),0x658BL,0x47DCL},{1L,0xCFA8L,(-6L),3L,0xADFAL},{(-1L),(-1L),0x6842L,1L,0x47DCL},{0xA1DEL,3L,1L,0x17B8L,0x17B8L}}};
    uint64_t l_1652 = 0x686143CC328A8D62LL;
    int i, j, k;
lbl_1518:
    l_1507 &= (l_1506[0][1][3] = (((((safe_mul_func_int64_t_s_s((safe_add_func_int16_t_s_s((p_74 && ((*p_73) || 0xA5ACL)), ((((*l_1497) = &g_57) == &p_72) != (++(*g_548))))), g_1332)) >= (safe_mul_func_uint8_t_u_u((safe_unary_minus_func_int64_t_s((((((p_74 & g_342[6]) , ((*l_1504) = ((0xFE302A86ABC8A477LL & p_74) | p_74))) | p_74) && 1UL) | l_1505[2][5][3]))), p_74))) , p_74) < g_1332) >= p_74));
    if ((((g_313 && (safe_rshift_func_uint16_t_u_u(((*g_548) = ((*p_73) && (*p_72))), p_74))) || ((safe_sub_func_int32_t_s_s(5L, ((((--(*l_1504)) || ((((**g_1434) >= ((safe_sub_func_int64_t_s_s(l_1506[0][1][3], 0UL)) & (safe_sub_func_int8_t_s_s(0xBFL, p_74)))) <= p_74) , g_58)) != 7L) > p_74))) && 0x79EC771DL)) == 255UL))
    { /* block id: 768 */
lbl_1603:
        if (g_101)
            goto lbl_1518;
    }
    else
    { /* block id: 770 */
        uint32_t ***l_1529 = (void*)0;
        uint8_t *l_1530 = (void*)0;
        uint8_t *l_1531 = (void*)0;
        int32_t l_1532 = 0L;
        int64_t *l_1540 = &g_344[3][4][0];
        uint64_t *l_1557 = &g_1166;
        uint32_t *l_1611 = &g_342[9];
        uint32_t **l_1610 = &l_1611;
        int64_t l_1613[6][3] = {{0L,0x65AF2C8DE94E1F08LL,0L},{0L,0x65AF2C8DE94E1F08LL,0L},{0L,0x65AF2C8DE94E1F08LL,0L},{0L,0x65AF2C8DE94E1F08LL,0L},{0L,0x65AF2C8DE94E1F08LL,0L},{0L,0x65AF2C8DE94E1F08LL,0L}};
        int32_t l_1622[2];
        int8_t l_1625 = (-2L);
        uint16_t l_1626 = 0xDBD1L;
        int i, j;
        for (i = 0; i < 2; i++)
            l_1622[i] = 0x07F3E67AL;
        for (g_51 = (-18); (g_51 != 13); g_51++)
        { /* block id: 773 */
            return (*g_548);
        }
        (**g_958) &= (safe_lshift_func_int16_t_s_u((safe_mul_func_uint64_t_u_u(((*l_1504) = p_74), ((**g_1434) <= ((*g_57) = ((l_1532 = (p_74 & (((g_19 | ((*g_1492) <= (safe_unary_minus_func_uint8_t_u(255UL)))) == (*p_73)) > (safe_sub_func_uint16_t_u_u((l_1528 == l_1529), 0x7023L))))) <= 0x56L))))), (*g_548)));
        if ((safe_rshift_func_uint64_t_u_u(((*l_1557) ^= ((0x9FB09483397BCF15LL != 0x9C3B017E84BD01EFLL) && (safe_lshift_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s(l_1506[2][0][4], (((((((((*g_57) = l_1505[3][3][3]) , (+((((*l_1540) = (p_74 && ((void*)0 == &l_1504))) <= ((((((((safe_lshift_func_int32_t_s_u((safe_lshift_func_uint32_t_u_s((((((safe_div_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u(((((*l_1504) = ((safe_sub_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(l_1532, (((l_1532 || 9L) > p_74) & g_342[9]))), 0x223BL)) && p_74)) & 0x72DE649666A8FE31LL) & p_74), 4)), 0x48L)), p_74)) > l_1532) | 0xEC6F90D7L) >= g_406[0]) <= 0UL), p_74)), 31)) , (-7L)) , 0xFFEC5A05L) != p_74) <= g_313) , p_74) & (-3L)) && 0x99ECEFFDL)) , l_1505[2][5][3]))) & 4294967295UL) & 0UL) ^ 0x73L) , 0x382E34B23F48ACBDLL) , &l_1532) == (void*)0))) ^ (**g_1434)), 6)))), 50)))
        { /* block id: 784 */
            int32_t *l_1559 = &g_711;
            int32_t **l_1558 = &l_1559;
            int32_t ***l_1560 = (void*)0;
            int32_t ***l_1561 = &l_1558;
            int32_t l_1577[10][3] = {{(-9L),0x07207F26L,1L},{(-9L),(-9L),(-9L)},{(-9L),0x34A94E02L,(-10L)},{(-9L),0x07207F26L,1L},{(-9L),(-9L),(-9L)},{(-9L),0x34A94E02L,(-10L)},{(-9L),0x07207F26L,1L},{(-9L),(-9L),(-9L)},{(-9L),0x34A94E02L,(-10L)},{(-9L),0x07207F26L,1L}};
            int32_t *****l_1596 = (void*)0;
            uint32_t *l_1607 = &g_342[5];
            uint32_t **l_1606 = &l_1607;
            int i, j;
            (*l_1561) = l_1558;
            for (g_51 = 5; (g_51 >= 2); g_51 -= 1)
            { /* block id: 788 */
                const int32_t *l_1571 = &g_711;
                const int32_t **l_1570 = &l_1571;
                int32_t l_1578[6][5] = {{0xCC315713L,0x7ED6C51DL,0x7ED6C51DL,0xCC315713L,0xCC315713L},{0xDEB1749CL,0x420D5FAAL,0xDEB1749CL,0x420D5FAAL,0xDEB1749CL},{0xCC315713L,0xCC315713L,0x7ED6C51DL,0x7ED6C51DL,0xCC315713L},{0xA693E56DL,0x420D5FAAL,0xA693E56DL,0x420D5FAAL,0xA693E56DL},{0xCC315713L,0x7ED6C51DL,0x7ED6C51DL,0xCC315713L,0xCC315713L},{0xDEB1749CL,0x420D5FAAL,0xDEB1749CL,0x420D5FAAL,0xDEB1749CL}};
                int8_t *l_1579 = (void*)0;
                int8_t *l_1580 = &g_179[9];
                int i, j;
                g_136[g_51] = (((p_74 , ((((*l_1558) = (**l_1561)) == &p_74) == (((*l_1580) = (safe_rshift_func_uint64_t_u_u(((safe_mod_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u(((*g_548) < (safe_mod_func_int8_t_s_s((&g_1068 != l_1570), (safe_mul_func_uint16_t_u_u((0x57AA25ADL || ((safe_div_func_uint32_t_u_u((((+g_491) , g_1004) && g_342[9]), l_1577[4][0])) & 1UL)), l_1506[0][1][3]))))), 0x2F2F48DF3723BEAELL)) , 4294967293UL), 0xC42E2675L)) < l_1578[1][1]), l_1505[3][3][3]))) < 255UL))) & p_74) >= g_159);
                (**g_958) = l_1577[9][2];
            }
            for (g_191 = 0; (g_191 <= 8); g_191 = safe_add_func_int32_t_s_s(g_191, 9))
            { /* block id: 796 */
                uint32_t l_1585[9][7] = {{0x3D5BBE0BL,1UL,4294967293UL,0x6EB9C038L,4294967291UL,0UL,4294967294UL},{4294967295UL,0x6EB9C038L,0xD663D449L,0x1F386DEAL,4294967293UL,4294967293UL,0x1F386DEAL},{4294967295UL,4294967294UL,4294967295UL,4294967288UL,4294967293UL,4294967294UL,0xF169F349L},{1UL,0UL,0UL,4294967294UL,4294967291UL,0xA61893E0L,0xFE5B53E2L},{4294967294UL,0UL,0UL,1UL,4294967295UL,4294967294UL,4294967294UL},{4294967288UL,4294967295UL,4294967294UL,4294967295UL,4294967288UL,4294967293UL,4294967294UL},{0x1F386DEAL,0xD663D449L,0xD663D449L,4294967294UL,0UL,1UL,0UL},{0xD663D449L,0xA61893E0L,4294967294UL,0UL,0xF169F349L,0x6EB9C038L,0xFE5B53E2L},{0UL,4294967294UL,0xE875CAD2L,0xFE5B53E2L,0xE875CAD2L,4294967294UL,0UL}};
                int32_t l_1589 = 0x91FB12B4L;
                int32_t ** const ***l_1600 = &g_1598;
                int i, j;
                l_1577[1][1] = ((safe_add_func_int8_t_s_s(p_74, l_1585[2][4])) >= (((0xA8FA354FL > l_1505[3][2][4]) == ((p_74 , p_74) < (0xF5F2A19FL == (safe_div_func_int8_t_s_s((-7L), ((((((g_1104 = (((-1L) | 0xB9E5663E2505AC47LL) , 4294967291UL)) > l_1585[2][4]) > l_1577[1][1]) | l_1588) != 0xF6A2AE891EDD967ELL) , g_342[9])))))) , 0x8C09BB046478E8D5LL));
                if ((**g_958))
                    continue;
                l_1589 = l_1506[2][1][0];
                if ((safe_mod_func_uint32_t_u_u((safe_div_func_int16_t_s_s((g_14 <= ((((&g_1434 != (l_1585[1][5] , &g_1434)) || 0x25A568715D383C0ALL) && g_136[5]) > ((safe_mul_func_uint32_t_u_u((l_1596 == (l_1600 = g_1597)), p_74)) && 0x08A8522DL))), (*g_1492))), 1UL)))
                { /* block id: 802 */
                    uint32_t **l_1609 = &l_1607;
                    uint32_t ***l_1608[7][6] = {{&l_1609,&l_1609,&l_1606,&l_1609,&l_1606,&l_1609},{&l_1606,&l_1606,&l_1609,&l_1609,&l_1606,&l_1606},{&l_1609,&l_1606,&l_1609,&l_1606,&l_1609,&l_1609},{&l_1606,&l_1606,&l_1606,&l_1606,&l_1606,&l_1606},{&l_1606,&l_1606,&l_1606,&l_1606,&l_1606,&l_1606},{&l_1609,&l_1609,&l_1606,&l_1609,&l_1606,&l_1609},{&l_1606,&l_1606,&l_1609,&l_1609,&l_1606,&l_1606}};
                    int i, j;
                    for (l_1588 = 0; (l_1588 != (-9)); l_1588--)
                    { /* block id: 805 */
                        if (g_101)
                            goto lbl_1603;
                        return p_74;
                    }
                    (****g_1598) = 0x96DC80B4L;
                    if ((((*l_1540) = ((++g_101) >= p_74)) <= ((l_1505[2][5][3] , ((((p_74 , l_1606) == (l_1610 = (((*g_548) = 0xE3DAL) , (void*)0))) , ((*l_1561) = g_1612)) != &g_1068)) & (0x2F92CCB621546CAALL > l_1507))))
                    { /* block id: 815 */
                        return p_74;
                    }
                    else
                    { /* block id: 817 */
                        uint16_t l_1614[10][4];
                        int i, j;
                        for (i = 0; i < 10; i++)
                        {
                            for (j = 0; j < 4; j++)
                                l_1614[i][j] = 0x7C9CL;
                        }
                        (**g_958) = ((p_74 , 0xCA6178AC9237A03ALL) > ((*l_1504) = l_1613[0][2]));
                        ++l_1614[8][1];
                        l_1617[0][0]--;
                    }
                }
                else
                { /* block id: 823 */
                    (*g_1321) = (safe_rshift_func_uint16_t_u_s(l_1613[0][2], 1));
                }
            }
        }
        else
        { /* block id: 827 */
            int32_t *l_1623 = &l_1506[0][1][3];
            int32_t *l_1624[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t ***l_1637[6] = {&g_958,&g_958,&g_958,&g_958,&g_958,&g_958};
            int8_t l_1638 = 0x94L;
            int i;
            --l_1626;
            (*g_1321) |= p_74;
            (**g_958) = ((safe_mul_func_uint32_t_u_u((l_1623 != &l_1622[0]), (safe_lshift_func_int32_t_s_s(((safe_mul_func_uint16_t_u_u((((((l_1532 = (p_74 >= ((((p_74 ^ (((((++g_342[9]) , (**g_993)) == (l_1622[1] , l_1637[3])) || p_74) <= (0UL | l_1622[1]))) & g_406[1]) || 0x38L) > l_1638))) & 65535UL) , 253UL) && g_342[9]) & 0xDA2D9EC804A5B5EELL), 0xE6C3L)) <= l_1613[2][1]), 30)))) <= 1L);
            (*g_958) = (****g_1597);
        }
        l_1640++;
    }
    l_1652--;
    return p_74;
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_410 g_136 g_745 g_746 g_599 g_57 g_58 g_191 g_251 g_993 g_914 g_548 g_406 g_179 g_313 g_958 g_676 g_677 g_678 g_1004 g_101
 * writes: g_54 g_136 g_344 g_191 g_251 g_993 g_1004 g_406 g_678 g_101
 */
static int16_t * func_75(uint32_t  p_76, int16_t  p_77, int32_t * p_78, int16_t * p_79, uint32_t  p_80)
{ /* block id: 350 */
    uint32_t l_729 = 0x948A0987L;
    int32_t **l_737 = &g_410;
    int32_t ***l_736[10];
    int16_t **l_740 = &g_57;
    int16_t ***l_739[6][7][6] = {{{&l_740,(void*)0,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,(void*)0,&l_740,&l_740},{(void*)0,&l_740,&l_740,&l_740,&l_740,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,(void*)0,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{(void*)0,&l_740,&l_740,&l_740,&l_740,&l_740}},{{(void*)0,&l_740,&l_740,&l_740,(void*)0,&l_740},{(void*)0,&l_740,&l_740,&l_740,(void*)0,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{(void*)0,&l_740,(void*)0,(void*)0,&l_740,(void*)0},{&l_740,(void*)0,&l_740,&l_740,&l_740,&l_740}},{{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,(void*)0,&l_740,&l_740,&l_740},{(void*)0,&l_740,&l_740,&l_740,&l_740,&l_740},{(void*)0,(void*)0,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,(void*)0,&l_740}},{{&l_740,(void*)0,&l_740,(void*)0,&l_740,&l_740},{(void*)0,(void*)0,&l_740,&l_740,(void*)0,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,(void*)0,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,(void*)0,&l_740}},{{&l_740,(void*)0,(void*)0,(void*)0,&l_740,&l_740},{&l_740,(void*)0,&l_740,&l_740,(void*)0,&l_740},{(void*)0,&l_740,(void*)0,(void*)0,&l_740,(void*)0},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{(void*)0,&l_740,&l_740,&l_740,&l_740,&l_740},{(void*)0,&l_740,&l_740,(void*)0,&l_740,&l_740},{&l_740,(void*)0,&l_740,&l_740,(void*)0,&l_740}},{{&l_740,(void*)0,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,(void*)0,&l_740,&l_740,(void*)0,&l_740},{&l_740,&l_740,&l_740,&l_740,(void*)0,&l_740},{&l_740,&l_740,(void*)0,(void*)0,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740},{&l_740,&l_740,&l_740,&l_740,&l_740,&l_740}}};
    int16_t ****l_738[5] = {&l_739[2][6][5],&l_739[2][6][5],&l_739[2][6][5],&l_739[2][6][5],&l_739[2][6][5]};
    int16_t *****l_741 = (void*)0;
    int16_t *****l_742 = (void*)0;
    int16_t *****l_743[5];
    int16_t ****l_744 = &l_739[2][6][5];
    uint8_t *l_748[6][6][3] = {{{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251}},{{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251}},{{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_251,&g_14,&g_251},{(void*)0,&g_14,(void*)0},{&g_14,&g_251,&g_14}},{{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14}},{{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14}},{{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14},{&g_251,(void*)0,&g_251},{&g_14,&g_251,&g_14}}};
    int64_t *l_757 = (void*)0;
    int64_t *l_758 = &g_344[6][3][0];
    uint32_t *l_759 = &l_729;
    uint32_t *l_760[9][1];
    int32_t l_797 = 0x5033AC4DL;
    uint32_t l_857 = 0xEE63EDA4L;
    uint32_t l_895 = 0UL;
    int32_t ***** const l_996 = &g_994[1];
    uint32_t * const *l_1023 = &l_760[1][0];
    uint32_t * const **l_1022[3];
    uint32_t * const ***l_1021 = &l_1022[0];
    uint32_t * const ****l_1020 = &l_1021;
    uint32_t **l_1037 = &l_760[2][0];
    uint8_t l_1152 = 255UL;
    const int16_t *l_1189 = &g_58;
    const int16_t **l_1188 = &l_1189;
    uint16_t **l_1265 = &g_548;
    int8_t l_1362 = 3L;
    uint32_t l_1363 = 0xE62B6D33L;
    int64_t l_1369 = 0x70DAD07AC9282514LL;
    int64_t l_1487 = (-1L);
    int64_t l_1488[1][9] = {{(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L,(-3L)}};
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_736[i] = &l_737;
    for (i = 0; i < 5; i++)
        l_743[i] = &l_738[2];
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
            l_760[i][j] = &g_710;
    }
    for (i = 0; i < 3; i++)
        l_1022[i] = &l_1023;
    for (g_54 = (-21); (g_54 > 39); g_54++)
    { /* block id: 353 */
        (*p_78) ^= ((*g_410) ^= 0xEA46531FL);
        --l_729;
    }
    if (((*p_78) = (p_79 == ((g_54 = (safe_div_func_uint8_t_u_u(((**l_737) = ((l_736[3] == &l_737) | ((l_744 = l_738[4]) != g_745))), (safe_add_func_uint32_t_u_u(((((((*l_759) = (safe_div_func_uint32_t_u_u((((void*)0 != (*g_745)) <= (0x316550D286FEB075LL >= ((*l_758) = ((safe_mod_func_uint32_t_u_u(((&l_736[3] != &l_736[8]) && (**g_599)), p_76)) & p_77)))), 0xB613D06FL))) , (void*)0) == l_748[0][0][0]) | p_76) , p_80), 0xB7CF0EF5L))))) , p_79))))
    { /* block id: 364 */
        int32_t l_780 = 0xEB76F88AL;
        int32_t l_782 = 8L;
        int32_t l_785 = 0xBED2329AL;
        int32_t l_787 = 4L;
        int32_t l_788 = 0x399928EEL;
        int32_t l_789 = (-5L);
        int32_t l_792 = 5L;
        int32_t l_796[7][7][1] = {{{(-1L)},{0x07AE015FL},{0x2F5F1C1CL},{9L},{0x2F5F1C1CL},{0x07AE015FL},{(-1L)}},{{0x851140EEL},{(-10L)},{1L},{1L},{(-10L)},{0x851140EEL},{(-1L)}},{{0x07AE015FL},{0x2F5F1C1CL},{9L},{0x2F5F1C1CL},{0x07AE015FL},{(-1L)},{0x851140EEL}},{{(-10L)},{1L},{1L},{(-10L)},{0x851140EEL},{(-1L)},{0x07AE015FL}},{{0x2F5F1C1CL},{9L},{0x2F5F1C1CL},{0x07AE015FL},{(-1L)},{0x851140EEL},{(-10L)}},{{1L},{1L},{(-10L)},{0x851140EEL},{(-1L)},{0x07AE015FL},{0x2F5F1C1CL}},{{9L},{0x2F5F1C1CL},{0x07AE015FL},{(-1L)},{0x851140EEL},{(-10L)},{1L}}};
        int32_t l_800 = (-1L);
        int32_t l_894[10] = {4L,1L,4L,1L,4L,1L,4L,1L,4L,1L};
        int32_t *l_897[10] = {&l_785,&l_785,&l_785,&l_785,&l_785,&l_785,&l_785,&l_785,&l_785,&l_785};
        uint32_t *****l_907 = &g_675;
        uint32_t l_915 = 0UL;
        uint64_t l_979 = 0x080686BE184738D3LL;
        int i, j, k;
        for (g_191 = (-24); (g_191 != 7); ++g_191)
        { /* block id: 367 */
            int32_t *l_776[10][9] = {{&g_711,(void*)0,&g_711,&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711},{&g_711,(void*)0,&g_711,&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711},{&g_711,&g_711,&g_711,&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711},{&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711,&g_711,(void*)0,&g_711},{&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711,&g_711,(void*)0,&g_711},{&g_711,(void*)0,&g_711,&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711},{&g_711,&g_711,&g_711,(void*)0,&g_711,&g_711,(void*)0,&g_711,(void*)0},{(void*)0,&g_711,&g_711,&g_711,&g_711,(void*)0,&g_711,&g_711,&g_711},{&g_711,&g_711,(void*)0,&g_711,&g_711,&g_711,&g_711,&g_711,&g_711},{&g_711,&g_711,&g_711,(void*)0,&g_711,&g_711,&g_711,&g_711,(void*)0}};
            int32_t l_783 = 4L;
            int32_t l_784 = 0xD67F4E36L;
            int32_t l_793 = 0x746ACA57L;
            int32_t l_794[2];
            int32_t *l_845 = &l_800;
            int64_t *l_855[9][10][2] = {{{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]}},{{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]}},{{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]}},{{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]}},{{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0}},{{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]}},{{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]}},{{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[5][8][0],&g_344[5][8][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[5][8][0]},{&g_344[5][8][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]}},{{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{&g_344[6][3][0],(void*)0},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]},{&g_344[6][3][0],&g_344[6][3][0]},{(void*)0,&g_344[6][3][0]}}};
            int16_t *l_862 = &g_51;
            int32_t *l_898[5];
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_794[i] = 0x6D6E8113L;
            for (i = 0; i < 5; i++)
                l_898[i] = &l_792;
        }
    }
    else
    { /* block id: 481 */
        uint64_t l_1005[5] = {0xDBF23944499C6030LL,0xDBF23944499C6030LL,0xDBF23944499C6030LL,0xDBF23944499C6030LL,0xDBF23944499C6030LL};
        int32_t l_1006 = 1L;
        int32_t *l_1019 = &g_711;
        int32_t **l_1018 = &l_1019;
        uint64_t *l_1028[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int i;
        for (g_251 = 0; (g_251 != 48); ++g_251)
        { /* block id: 484 */
            int16_t l_992 = (-1L);
            int64_t *l_1003 = &g_1004;
            (*g_410) = (((l_1006 = ((safe_mod_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint64_t_u_u(0x08C881F6D03A8AB7LL, 18)), (safe_mod_func_int8_t_s_s((((((((((*p_78) == l_992) <= ((*g_548) = (((((g_993 = g_993) != l_996) == ((safe_rshift_func_uint64_t_u_u(((safe_mod_func_int8_t_s_s(((safe_div_func_uint64_t_u_u(1UL, 0x3795F4277CE03C57LL)) >= (p_76 | ((*l_1003) = ((*l_758) = (g_914[0] || l_992))))), l_1005[0])) | 249UL), 20)) == (*g_548))) != p_77) >= 9UL))) < p_80) == (**l_737)) >= g_179[9]) < l_992) && g_136[5]) && (*g_548)), p_80)))) <= p_77), g_313)) , p_80)) > l_1005[0]) ^ p_77);
            (**g_958) = (*p_78);
        }
        (**g_958) ^= (((**g_676) = (**g_676)) == ((safe_add_func_uint64_t_u_u((l_1006 = ((safe_unary_minus_func_int16_t_s((safe_lshift_func_uint32_t_u_u((safe_rshift_func_int64_t_s_s(1L, 41)), (safe_div_func_uint32_t_u_u((safe_add_func_uint16_t_u_u(((((*l_1018) = p_78) != (void*)0) >= (l_1020 == (void*)0)), (*p_79))), ((((((((safe_mod_func_uint8_t_u_u((((-1L) ^ ((safe_sub_func_uint16_t_u_u(p_76, (*g_548))) , g_1004)) , 253UL), 0x77L)) == g_179[0]) > (*p_79)) , 1L) , 1L) && 7L) & l_1006) , (*p_78)))))))) < g_406[1])), g_179[9])) , p_78));
    }
    for (g_101 = 21; (g_101 < 24); g_101 = safe_add_func_int16_t_s_s(g_101, 4))
    { /* block id: 500 */
        int32_t l_1031[8][4] = {{0xBEDFD9D7L,0xC2A8DB56L,(-8L),(-1L)},{(-1L),0xC2A8DB56L,0xC2A8DB56L,(-1L)},{0xBEDFD9D7L,0xC2A8DB56L,(-8L),(-1L)},{(-1L),0xC2A8DB56L,0xC2A8DB56L,(-1L)},{0xBEDFD9D7L,0xC2A8DB56L,(-8L),(-1L)},{(-1L),0xC2A8DB56L,0xC2A8DB56L,(-1L)},{0xBEDFD9D7L,0xC2A8DB56L,(-8L),(-1L)},{(-1L),0xC2A8DB56L,0xC2A8DB56L,(-1L)}};
        uint32_t **l_1036[2];
        int32_t l_1087 = 0x98A83DB0L;
        int32_t l_1089 = 0L;
        int32_t l_1120 = (-10L);
        int32_t l_1151 = 4L;
        int32_t l_1177 = 4L;
        int16_t *****l_1181 = &l_738[4];
        uint64_t *l_1207[5][7] = {{&g_101,&g_101,&g_101,(void*)0,&g_101,&g_101,&g_101},{&g_1166,&g_1166,(void*)0,&g_1166,&g_1166,&g_1166,&g_1166},{&g_101,&g_1166,&g_101,&g_101,&g_101,&g_101,&g_1166},{&g_1166,&g_1166,(void*)0,(void*)0,&g_1166,&g_1166,&g_1166},{&g_101,&g_101,&g_101,&g_101,&g_1166,&g_101,&g_101}};
        uint16_t l_1246 = 65527UL;
        int32_t l_1292 = 0xD2461BEAL;
        int32_t l_1360 = 0xD16866C6L;
        int32_t l_1396 = 0xAEEC58A8L;
        uint32_t l_1399[3];
        const uint32_t l_1486 = 0UL;
        uint16_t l_1489 = 0xA3FDL;
        int i, j;
        for (i = 0; i < 2; i++)
            l_1036[i] = &g_678;
        for (i = 0; i < 3; i++)
            l_1399[i] = 0x88A427BCL;
    }
    return &g_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_58 g_342
 * writes: g_54 g_58
 */
static uint32_t  func_81(int16_t * p_82, int16_t  p_83, const uint16_t  p_84, int16_t * p_85)
{ /* block id: 37 */
    uint64_t l_164 = 0x280801E7C2DC33B3LL;
    int32_t *l_177 = (void*)0;
    int32_t l_192[4] = {4L,4L,4L,4L};
    int32_t l_312 = (-1L);
    uint8_t l_366[4];
    uint32_t ***l_426 = (void*)0;
    uint32_t ****l_425 = &l_426;
    uint32_t *****l_424[5] = {&l_425,&l_425,&l_425,&l_425,&l_425};
    int8_t l_440 = 8L;
    const int32_t l_478[5] = {0xE47F3CA4L,0xE47F3CA4L,0xE47F3CA4L,0xE47F3CA4L,0xE47F3CA4L};
    uint16_t *l_547[9][5][3] = {{{&g_406[1],(void*)0,&g_48},{&g_406[3],&g_406[1],&g_406[3]},{(void*)0,(void*)0,&g_406[3]},{&g_406[2],&g_406[0],&g_48},{&g_48,&g_406[3],&g_406[2]}},{{(void*)0,(void*)0,&g_406[4]},{&g_48,(void*)0,&g_406[1]},{&g_406[2],&g_406[2],&g_406[1]},{(void*)0,&g_406[2],&g_406[0]},{&g_406[3],(void*)0,&g_406[2]}},{{&g_406[1],(void*)0,&g_406[1]},{&g_406[1],&g_406[3],&g_406[2]},{&g_406[0],&g_406[0],&g_406[0]},{&g_406[1],(void*)0,&g_406[1]},{&g_406[1],&g_406[1],&g_406[1]}},{{&g_406[0],(void*)0,&g_406[4]},{&g_406[1],&g_406[1],&g_406[2]},{&g_406[1],(void*)0,&g_48},{&g_406[3],&g_406[1],&g_406[3]},{(void*)0,(void*)0,&g_406[3]}},{{&g_406[2],&g_406[0],&g_48},{&g_48,&g_406[3],&g_406[2]},{(void*)0,(void*)0,&g_406[4]},{&g_48,(void*)0,(void*)0},{&g_406[1],&g_406[1],(void*)0}},{{&g_406[0],&g_406[1],&g_406[2]},{&g_406[1],&g_406[2],&g_406[1]},{(void*)0,&g_406[1],&g_48},{(void*)0,&g_406[1],&g_406[1]},{&g_406[1],&g_406[2],&g_406[2]}},{{&g_406[4],&g_406[0],(void*)0},{&g_406[4],(void*)0,(void*)0},{&g_406[1],&g_406[0],(void*)0},{(void*)0,(void*)0,&g_406[1]},{(void*)0,&g_406[0],&g_406[3]}},{{&g_406[1],(void*)0,&g_406[1]},{&g_406[0],&g_406[0],&g_406[1]},{&g_406[1],&g_406[2],&g_406[3]},{&g_406[3],&g_406[1],&g_406[1]},{&g_406[0],&g_406[1],(void*)0}},{{&g_406[3],&g_406[2],(void*)0},{&g_406[1],&g_406[1],(void*)0},{&g_406[0],&g_406[1],&g_406[2]},{&g_406[1],&g_406[2],&g_406[1]},{(void*)0,&g_406[1],&g_48}}};
    uint32_t l_572 = 3UL;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_366[i] = 0xC2L;
lbl_505:
    for (g_54 = 27; (g_54 >= 49); g_54++)
    { /* block id: 40 */
        int32_t *l_175 = &g_53;
        int32_t **l_176 = &l_175;
        int8_t *l_178 = &g_179[9];
        int16_t **l_183[7] = {&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57};
        int32_t l_210 = 1L;
        int32_t l_212 = (-6L);
        int32_t l_213 = 0x47FA4D0AL;
        int32_t l_216[5] = {0x0CAFA75CL,0x0CAFA75CL,0x0CAFA75CL,0x0CAFA75CL,0x0CAFA75CL};
        uint8_t l_270 = 0x4EL;
        const volatile uint32_t * volatile * volatile *l_385 = &g_382;
        int16_t * const *l_388 = &g_57;
        int16_t * const **l_387 = &l_388;
        int16_t * const ***l_386 = &l_387;
        uint16_t *l_398 = &g_48;
        int32_t *l_409 = &l_213;
        int i;
    }
    for (g_58 = 18; (g_58 <= (-13)); g_58 = safe_sub_func_int16_t_s_s(g_58, 1))
    { /* block id: 187 */
        for (g_54 = 0; (g_54 == 41); ++g_54)
        { /* block id: 190 */
            return p_83;
        }
        if (p_84)
            break;
    }
    for (p_83 = 3; (p_83 >= 0); p_83 -= 1)
    { /* block id: 197 */
        uint32_t ***l_423 = (void*)0;
        uint32_t ****l_422 = &l_423;
        uint32_t *****l_421 = &l_422;
        int32_t l_442 = 1L;
        int32_t l_443 = (-1L);
        uint32_t l_460 = 18446744073709551615UL;
        int32_t * const l_490 = &g_491;
        int32_t * const *l_489 = &l_490;
        int32_t * const **l_488[5][4] = {{&l_489,&l_489,&l_489,&l_489},{&l_489,&l_489,&l_489,&l_489},{&l_489,&l_489,&l_489,&l_489},{&l_489,&l_489,&l_489,&l_489},{&l_489,&l_489,&l_489,&l_489}};
        int32_t * const ***l_487[5] = {&l_488[0][0],&l_488[0][0],&l_488[0][0],&l_488[0][0],&l_488[0][0]};
        uint64_t *l_523 = &g_101;
        int8_t l_721[7][10] = {{1L,0xD3L,9L,9L,0xD3L,1L,0xCBL,1L,0xD3L,9L},{0x7AL,0xF1L,0x7AL,9L,0xCBL,0xCBL,9L,0x7AL,0xF1L,0x7AL},{0x7AL,1L,0xF1L,0xD3L,0xF1L,1L,0x7AL,0x7AL,1L,0xF1L},{1L,0x7AL,0x7AL,1L,0xF1L,0xD3L,0xF1L,1L,0x7AL,0x7AL},{0xF1L,0x7AL,9L,0xCBL,0xCBL,9L,0x7AL,0xF1L,0x7AL,9L},{0xD3L,1L,0xCBL,1L,0xD3L,9L,9L,0xD3L,1L,0xCBL},{0xF1L,0xF1L,0xCBL,0xD3L,(-1L),0xD3L,0xCBL,0xF1L,0xF1L,0xCBL}};
        int16_t l_722 = 0x0663L;
        int i, j;
    }
    if (p_84)
        goto lbl_505;
    return g_342[9];
}


/* ------------------------------------------ */
/* 
 * reads : g_53
 * writes:
 */
static int8_t  func_87(int16_t  p_88, int32_t * p_89, int16_t ** p_90)
{ /* block id: 34 */
    int32_t *l_149 = (void*)0;
    int32_t *l_150 = &g_136[5];
    int32_t *l_151 = &g_136[5];
    int32_t *l_152 = &g_136[5];
    int32_t *l_153[8] = {&g_136[4],(void*)0,(void*)0,&g_136[4],(void*)0,(void*)0,&g_136[4],(void*)0};
    uint32_t l_154 = 0x1985D36CL;
    int i;
    l_154--;
    return g_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_53 g_58 g_57 g_101 g_14 g_19 g_48 g_54
 * writes: g_53 g_54 g_58 g_51 g_48 g_136
 */
static uint8_t  func_93(int16_t ** p_94, uint16_t  p_95, uint16_t  p_96)
{ /* block id: 14 */
    int64_t l_118 = 1L;
    int32_t *l_128 = &g_53;
    uint32_t l_148 = 18446744073709551612UL;
    for (g_53 = 0; (g_53 >= 14); g_53++)
    { /* block id: 17 */
        int16_t *l_119 = &g_58;
        int32_t l_120 = 0x0F2F45F9L;
        uint32_t *l_129 = &g_54;
        int16_t *l_130 = &g_51;
        uint64_t l_131 = 0x55A17A538DB7D616LL;
        uint32_t l_132 = 18446744073709551606UL;
        int8_t *l_133 = (void*)0;
        int32_t *l_134 = (void*)0;
        int32_t *l_135 = &g_136[5];
        (*l_135) = (~(l_120 = ((g_48 ^= ((safe_div_func_uint16_t_u_u((--p_96), (safe_mul_func_uint8_t_u_u((((((l_118 >= (((l_119 != (void*)0) >= g_58) , (l_120 & (((safe_sub_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_u((+((((p_95 & (((*l_130) = ((*g_57) = (safe_mod_func_int32_t_s_s((-1L), ((*l_129) = ((l_128 != l_128) , (*l_128))))))) || (*l_128))) | (*l_128)) & l_131) , 0x0D37901AL)), g_101)) < (*l_128)) == 0UL), l_120)) || g_14) || l_132)))) != (*l_128)) ^ g_19) < (*l_128)) >= 0L), l_132)))) , 0x73E5L)) || p_95)));
    }
    for (g_54 = 0; (g_54 != 53); g_54++)
    { /* block id: 28 */
        uint8_t l_144 = 0x77L;
        const int8_t l_147 = 0x3EL;
        g_53 = (safe_mod_func_int16_t_s_s(((*g_57) = ((safe_div_func_int16_t_s_s((**p_94), (*g_57))) , (-1L))), (+(0xD800L || (g_48 = (((l_144 , (g_53 && ((void*)0 != l_128))) >= (((safe_rshift_func_int16_t_s_s((*l_128), l_147)) , l_128) == &g_54)) != l_144))))));
    }
    return l_148;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_136[i], "g_136[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_159, "g_159", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_179[i], "g_179[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_223, "g_223", print_hash_value);
    transparent_crc(g_224, "g_224", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_251, "g_251", print_hash_value);
    transparent_crc(g_313, "g_313", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_342[i], "g_342[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_344[i][j][k], "g_344[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_406[i], "g_406[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_491, "g_491", print_hash_value);
    transparent_crc(g_607, "g_607", print_hash_value);
    transparent_crc(g_710, "g_710", print_hash_value);
    transparent_crc(g_711, "g_711", print_hash_value);
    transparent_crc(g_798, "g_798", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_914[i], "g_914[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1004, "g_1004", print_hash_value);
    transparent_crc(g_1069, "g_1069", print_hash_value);
    transparent_crc(g_1104, "g_1104", print_hash_value);
    transparent_crc(g_1166, "g_1166", print_hash_value);
    transparent_crc(g_1329, "g_1329", print_hash_value);
    transparent_crc(g_1332, "g_1332", print_hash_value);
    transparent_crc(g_1475, "g_1475", print_hash_value);
    transparent_crc(g_1727, "g_1727", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 375
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 73
   depth: 2, occurrence: 19
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 34, occurrence: 2
   depth: 46, occurrence: 2
   depth: 48, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 324

XXX times a variable address is taken: 803
XXX times a pointer is dereferenced on RHS: 215
breakdown:
   depth: 1, occurrence: 151
   depth: 2, occurrence: 46
   depth: 3, occurrence: 16
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 236
breakdown:
   depth: 1, occurrence: 189
   depth: 2, occurrence: 41
   depth: 3, occurrence: 2
   depth: 4, occurrence: 4
XXX times a pointer is compared with null: 35
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 10
XXX times a pointer is qualified to be dereferenced: 4854

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 599
   level: 2, occurrence: 213
   level: 3, occurrence: 62
   level: 4, occurrence: 63
   level: 5, occurrence: 44
XXX number of pointers point to pointers: 147
XXX number of pointers point to scalars: 177
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.1
XXX average alias set size: 1.43

XXX times a non-volatile is read: 1468
XXX times a non-volatile is write: 772
XXX times a volatile is read: 12
XXX    times read thru a pointer: 11
XXX times a volatile is write: 3
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 99.3

XXX forward jumps: 0
XXX backward jumps: 10

XXX stmts: 76
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 17
   depth: 2, occurrence: 11
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 6

XXX percentage a fresh-made variable is used: 16.3
XXX percentage an existing variable is used: 83.7
********************* end of statistics **********************/

