/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 2ceb80e
 * Options:   --no-paranoid --null-ptr-deref-prob 0 --dangling-ptr-deref-prob 0.832 --return-dead-pointer --dangling-global-pointers --bitfields --packed-struct --annotated-arith-wrappers --relax-anlayses-conditions --relax-anlayses-prob /home/user42/git/MinCond/scripts/WA-v1-general/seedsProbs/probs_WeakenSafeAnalyse_test.txt --relax-anlayses-seed 3172827853 --seed 3172827853
 * Seed:      3172827853
 */

#include "csmith.h"


static long __undefined;

/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_9;
static volatile uint32_t g_21[3];
static int64_t g_51;
static int16_t g_53;
static uint32_t g_55;
static int16_t g_59[1][8] = {{0x87BBL,0x87BBL,0x87BBL,0x87BBL,0x87BBL,0x87BBL,0x87BBL,0x87BBL}};
static int32_t g_88 = 0xE2F045C7L;
static uint8_t g_96;
static uint16_t g_115;
static uint8_t g_162;
static int8_t g_164 = 5L;
static int16_t g_195;
static uint32_t g_208 = 18446744073709551615UL;
static uint8_t g_212;
static volatile int64_t g_228[3][1];
static volatile int64_t *g_227;
static volatile int64_t **g_226;
static int8_t g_230[6][9][4];
static int32_t g_261[6];
static int32_t *g_260;
static int8_t g_278[1][2][4];
static int8_t g_281;
static uint32_t g_282 = 0xF8106236L;
static volatile int32_t g_293[3][3][1];
static volatile int32_t *g_292;
static volatile int32_t * volatile * const g_291 = &g_292;
static uint32_t g_296[2][10];
static int64_t g_307;
static int32_t g_309[7];
static uint8_t g_310;
static int32_t * const g_326 = (void*)0;
static int32_t * const *g_325;
static uint64_t g_329;
static int32_t g_333;
static uint8_t g_336;
static uint64_t *g_384;
static const uint32_t g_408[7] = {0x5FD2D398L,0x5FD2D398L,0x5FD2D398L,0x5FD2D398L,0x5FD2D398L,0x5FD2D398L,0x5FD2D398L};
static uint64_t g_435;
static int32_t *g_461;
static uint32_t g_485;
static int8_t g_530;
static int8_t g_532 = (-2L);
static uint32_t g_533;
static uint16_t g_560;
static uint8_t g_614;
static int64_t g_675;
static int16_t g_676 = 0x20F4L;
static int32_t g_679;
static int8_t g_680;
static int32_t g_681;
static int8_t g_682[10][5][5];
static uint8_t g_683;
static int32_t g_686;
static int16_t g_687;
static uint32_t g_688;
static int32_t *g_691;
static uint8_t *g_707;
static uint8_t **g_706[10][4];
static uint32_t *g_722 = (void*)0;
static uint32_t **g_721[9][7][2];
static uint16_t g_737;
static int32_t *** volatile *g_766[3];
static int16_t *g_880[6] = {&g_53,&g_53,&g_53,&g_53,&g_53,&g_53};
static uint8_t ***g_890;
static uint8_t ****g_889;
static uint16_t *g_919[2][8][1] = {{{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737}},{{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737},{&g_737}}};
static int64_t g_926[1];
static int8_t g_949[1];
static int64_t g_955[8];
static uint64_t g_956 = 3UL;
static int16_t g_977 = 0xF820L;
static uint32_t g_978;
static int16_t g_1034;
static int8_t g_1038;
static uint32_t g_1039 = 0xDA39F7B2L;
static int32_t **g_1081 = &g_461;
static int16_t g_1132;
static uint16_t g_1134;
static uint64_t * const *g_1197;
static int32_t g_1248;
static int8_t g_1249;
static uint64_t g_1250;
static int32_t g_1285;
static int32_t g_1311;
static uint32_t g_1450[3][2];
static int32_t g_1486;
static int32_t g_1543;
static int64_t g_1548;
static int8_t g_1549 = 0xCDL;
static uint16_t g_1550[7][8];
static uint32_t g_1577 = 0xC3101F04L;
static int16_t g_1586;
static uint16_t g_1605;
static volatile int32_t **g_1663;
static volatile int32_t *** volatile g_1662;/* VOLATILE GLOBAL g_1662 */
static volatile int32_t *** volatile * volatile g_1661 = &g_1662;/* VOLATILE GLOBAL g_1661 */
static volatile int32_t *** volatile * volatile *g_1660;
static int32_t ***g_1734;
static int32_t ****g_1733[2] = {&g_1734,&g_1734};
static int32_t *****g_1732 = &g_1733[1];
static int16_t **g_1798[9];
static uint32_t ***g_1885;
static uint32_t **** volatile g_1884;/* VOLATILE GLOBAL g_1884 */
static volatile int8_t * volatile * volatile g_1889 = (void*)0;/* VOLATILE GLOBAL g_1889 */
static uint64_t g_1898;
static volatile int8_t g_1901[9];
static const volatile int8_t *g_1900 = &g_1901[8];
static const volatile int8_t * volatile *g_1899;
static volatile uint32_t g_1925;/* VOLATILE GLOBAL g_1925 */
static uint8_t *****g_1999;
static int8_t * const g_2076 = &g_278[0][0][2];
static int8_t * const *g_2075;
static const int32_t *g_2148;
static const int32_t ** volatile g_2147[8];
static const int32_t ** volatile g_2150;/* VOLATILE GLOBAL g_2150 */
static const int32_t ** volatile g_2151;/* VOLATILE GLOBAL g_2151 */
static volatile int32_t g_2368[6][7][6];
static int32_t g_2534 = 0x9D536C3AL;
static const int32_t ** volatile g_2571;/* VOLATILE GLOBAL g_2571 */
static uint32_t * const **g_2585;
static const uint64_t *g_2655;
static const uint64_t * const *g_2654;
static uint32_t *g_2698 = &g_533;
static int32_t **g_2733;
static int32_t ***g_2732 = &g_2733;
static uint64_t **g_2798;
static uint64_t ***g_2797 = &g_2798;
static const int32_t *g_2815;
static const int32_t **g_2814;
static int8_t ** volatile * volatile *g_2820;
static int8_t ** volatile * volatile * volatile * volatile g_2819[3];


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int64_t  func_14(int64_t  p_15, int16_t * p_16);
static int16_t * func_17(uint16_t  p_18, int16_t * const  p_19, int16_t * p_20);
static int32_t  func_29(uint8_t  p_30, int16_t * p_31, int64_t  p_32, uint32_t  p_33, int16_t * p_34);
static uint8_t  func_35(int16_t * p_36);
static int16_t * func_37(int32_t  p_38, int16_t * const  p_39, int16_t * p_40, int64_t  p_41);
static uint8_t  func_61(uint8_t  p_62, uint64_t  p_63, int16_t * p_64);
static int8_t  func_65(int8_t  p_66);
static const uint8_t  func_69(int32_t * p_70);
static int32_t * func_71(int64_t  p_72);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_21 g_53 g_55 g_560 g_707 g_614 g_336 g_1034 g_59 g_485 g_384 g_329 g_1450 g_1577 g_956 g_532 g_1586 g_51 g_88 g_96 g_162 g_208 g_212 g_164 g_226 g_230 g_260 g_261 g_282 g_291 g_115 g_296 g_310 g_325 g_278 g_333 g_326 g_309 g_435 g_533 g_683 g_688 g_1081 g_1605 g_1249 g_461 g_1250 g_1548 g_1132 g_1197 g_679 g_1660 g_889 g_890 g_408 g_1732 g_227 g_676 g_1663 g_292 g_307 g_1661 g_1662 g_293 g_1884 g_1889 g_1898 g_1899 g_955 g_686 g_1925 g_1733 g_1734 g_926 g_978 g_682 g_228 g_281 g_2075 g_1550 g_1900 g_1901 g_1039 g_2076 g_2151 g_2148 g_1248 g_737 g_681 g_1486 g_1038 g_919 g_1798 g_880 g_722 g_195 g_766 g_1999 g_2571 g_1885 g_706 g_2585 g_1543 g_2732 g_2814 g_2819
 * writes: g_9 g_51 g_53 g_59 g_686 g_88 g_1034 g_485 g_560 g_333 g_1039 g_1450 g_1577 g_955 g_1548 g_96 g_115 g_164 g_208 g_212 g_230 g_282 g_296 g_310 g_325 g_336 g_260 g_329 g_384 g_55 g_435 g_195 g_532 g_461 g_683 g_688 g_614 g_1605 g_1249 g_1250 g_679 g_949 g_691 g_1732 g_1311 g_890 g_676 g_1132 g_292 g_307 g_721 g_281 g_1885 g_926 g_261 g_737 g_533 g_293 g_1999 g_956 g_1733 g_2075 g_1550 g_2148 g_978 g_681 g_278 g_1248 g_1486 g_1038 g_722 g_675 g_1798 g_2585 g_1898 g_706 g_2733 g_2814
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_7[9][10] = {{(-5L),0x47597A61L,(-5L),0x047D2038L,0x3735B263L,0x047D2038L,(-5L),0x047D2038L,1L,0L},{(-1L),0x047D2038L,0xE164CAF1L,0x047D2038L,(-1L),0x47597A61L,(-1L),0x047D2038L,0xE164CAF1L,0x047D2038L},{(-5L),0L,1L,0x047D2038L,1L,0L,(-5L),0L,1L,0x047D2038L},{0x7B051AF7L,0x047D2038L,0x7B051AF7L,0L,(-1L),0L,0x7B051AF7L,0x047D2038L,0x7B051AF7L,0L},{(-5L),0x047D2038L,0x3735B263L,0x047D2038L,(-5L),0x47597A61L,(-5L),0x047D2038L,0x3735B263L,0x047D2038L},{(-1L),0L,0x7B051AF7L,0x047D2038L,0x7B051AF7L,0L,(-1L),0L,0x7B051AF7L,0x047D2038L},{1L,0x047D2038L,1L,0L,(-5L),0L,1L,0x047D2038L,1L,0L},{(-1L),0x047D2038L,0xE164CAF1L,0x047D2038L,(-1L),0x47597A61L,(-1L),0x047D2038L,0xE164CAF1L,0x047D2038L},{(-5L),0L,1L,0x047D2038L,1L,0L,(-5L),0L,1L,0x047D2038L}};
    int16_t *l_8;
    int64_t *l_50 = &g_51;
    int16_t *l_52;
    uint16_t l_54;
    int32_t *l_56;
    int32_t *l_57;
    int32_t *l_58[6][7];
    const uint64_t l_60 = 0UL;
    int16_t *l_1813;
    uint64_t l_2637[10][10][2];
    uint32_t l_2638;
    uint64_t **l_2657[8];
    int8_t ***l_2694;
    int8_t *** const *l_2693;
    uint16_t l_2722;
    int16_t l_2728;
    int64_t **l_2762;
    int64_t ***l_2761;
    uint16_t l_2763[10][2];
    int32_t **l_2813;
    int8_t l_2823;
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
            l_58[i][j] = (void*)0;
    }
    l_2638 = ((*l_57) = (+(((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*0*//* ___SAFE__OP */((l_2637[6][7][1] &= (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*1*//* ___SAFE__OP */(((*l_8) = l_7[7][3]), (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*2*//* ___SAFE__OP */((((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*3*//* ___SAFE__OP */((l_7[1][5] & func_14(l_7[3][9], func_17(((g_21[1] >= (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*4*//* ___SAFE__OP */((!(safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*5*//* ___SAFE__OP */(0x20L, ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*6*//* ___SAFE__OP */(func_29(func_35(func_37(((((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*7*//* ___SAFE__OP */(((g_59[0][6] = (((l_54 = (((*l_52) ^= (((*l_50) = (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*8*//* ___SAFE__OP */((((0x4373L < (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*9*//* ___SAFE__OP */(1UL, l_7[7][3]))) | l_7[3][7]) && (-9L)), 4UL))) && l_7[7][3])) , 0x6302L)) | 0x15EAL) == g_55)) > 0UL), l_60)) == 1UL) , 0xCDD5L) & 0x70A2L), l_8, l_8, (*l_57))), l_8, g_560, (*l_57), &g_1034), (-6L))) , (*l_57))))), (*l_56)))) != 0xE0L), l_52, l_1813))), 6)) <= (*l_57)) != (*l_56)), (*l_57)))))), 2)) >= (*l_56)) & 0L)));
    if ((9UL != (*l_56)))
    { /* block id: 1217 */
        return (*g_384);
    }
    else
    { /* block id: 1219 */
        int32_t l_2641[1];
        int32_t l_2644;
        int32_t ***l_2734;
        int64_t ****l_2769;
        int32_t l_2776;
        int16_t l_2778;
        uint64_t l_2780;
        int16_t * const *l_2788 = &l_1813;
        int16_t * const **l_2787;
        uint64_t ***l_2799;
        int32_t ** const l_2812 = (void*)0;
        const int32_t ***l_2816;
        uint16_t *l_2821;
        uint16_t *l_2822;
        int i;
        for (i = 0; i < 1; i++)
            l_2641[i] = 0xAE4A9557L;
        (*g_1081) = &l_2641[0];
        for (g_1577 = (-7); (g_1577 <= 9); g_1577++)
        { /* block id: 1224 */
            int32_t l_2645;
            int32_t l_2650;
            int32_t *** const l_2683 = (void*)0;
            int32_t *** const *l_2682;
            int32_t l_2690 = 0L;
            const uint32_t *l_2699[3][8][5] = {{{&g_978,&g_485,&g_978,(void*)0,&g_533},{&g_296[1][6],&g_1039,&g_296[0][9],&g_1039,&g_1039},{&g_978,&g_485,(void*)0,&g_485,&g_978},{&g_1039,&g_1039,&g_296[0][9],&g_1039,&g_296[1][6]},{&g_533,(void*)0,&g_978,&g_485,&g_978},{&g_296[1][6],&g_296[1][6],&g_1039,&g_1039,&g_296[1][6]},{&g_208,&g_485,&g_208,(void*)0,&g_978},{&g_296[1][6],&g_296[0][9],&g_296[0][9],&g_296[1][6],&g_1039}},{{&g_533,&g_485,&g_208,&g_485,&g_533},{&g_1039,&g_296[1][6],&g_296[0][9],&g_296[0][9],&g_296[1][6]},{&g_978,(void*)0,&g_208,&g_485,&g_208},{&g_296[1][6],&g_1039,&g_1039,&g_296[1][6],&g_296[1][6]},{&g_978,&g_485,&g_978,(void*)0,&g_533},{&g_296[1][6],&g_1039,&g_296[0][9],&g_1039,&g_1039},{&g_978,&g_485,(void*)0,&g_485,&g_978},{&g_1039,&g_1039,&g_296[0][9],&g_1039,&g_296[1][6]}},{{&g_533,(void*)0,&g_978,&g_485,&g_978},{&g_296[1][6],&g_296[1][6],&g_1039,&g_1039,&g_296[1][6]},{&g_208,&g_485,&g_208,(void*)0,&g_978},{&g_296[1][6],&g_296[0][9],&g_296[0][9],&g_296[1][6],&g_1039},{&g_533,&g_485,&g_208,&g_485,&g_533},{&g_1039,&g_296[1][6],&g_296[0][9],&g_1039,&g_1039},{&g_208,&g_296[0][4],(void*)0,(void*)0,(void*)0},{&g_1039,&g_296[0][9],&g_1039,&g_1039,&g_1039}}};
            int32_t ***l_2744;
            int64_t **l_2803 = (void*)0;
            int i, j, k;
        }
        (***g_1662) = (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*10*//* ___SAFE__OP */(((*l_2822) |= (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*11*//* ___SAFE__OP */(((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*12*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*13*//* ___SAFE__OP */((((l_2812 == (void*)0) < ((l_2813 = ((*g_2732) = l_2813)) != ((*l_2816) = g_2814))) < (((((**g_1197) > (**g_1197)) & (--g_1898)) , g_2819[2]) != (void*)0)), l_2644)), 0xC9451BB6L)) , (*l_57)), 1L))), l_2823));
    }
    return (*l_57);
}


/* ------------------------------------------ */
/* 
 * reads : g_292 g_293 g_1732 g_1733 g_1734 g_291 g_1197 g_384 g_329 g_1249 g_1660 g_1661 g_1662 g_1663 g_926 g_956 g_333 g_978 g_96 g_1081 g_682 g_686 g_227 g_228 g_310 g_707 g_614 g_281 g_2075 g_1034 g_1550 g_1899 g_1900 g_1901 g_1039 g_226 g_560 g_461 g_2076 g_278 g_2151 g_309 g_55 g_261 g_1605 g_336 g_51 g_53 g_2148 g_88 g_1248 g_296 g_1486 g_1038 g_919 g_1798 g_880 g_722 g_195 g_766 g_1999 g_889 g_890 g_282 g_208 g_2571 g_1884 g_1885 g_706 g_2585 g_1250 g_1543 g_1898 g_737 g_533 g_681
 * writes: g_926 g_261 g_560 g_737 g_281 g_384 g_533 g_333 g_293 g_1999 g_329 g_956 g_461 g_686 g_310 g_614 g_1733 g_2075 g_1605 g_1550 g_282 g_683 g_2148 g_307 g_978 g_55 g_681 g_336 g_51 g_278 g_955 g_1249 g_53 g_1577 g_1248 g_1486 g_1038 g_722 g_292 g_195 g_675 g_1798 g_296 g_485 g_208 g_688 g_115 g_2585 g_1250 g_1898 g_706 g_1450
 */
static int64_t  func_14(int64_t  p_15, int16_t * p_16)
{ /* block id: 878 */
    int32_t ***l_1935;
    uint8_t *l_2015;
    int32_t l_2025;
    int32_t l_2029[7][8][3];
    int32_t ****l_2070;
    uint8_t l_2074 = 0UL;
    int64_t l_2079;
    uint8_t l_2080;
    int32_t ***l_2107;
    uint32_t l_2202;
    uint64_t **l_2214;
    uint16_t l_2261;
    int8_t **l_2270;
    int32_t l_2277;
    int16_t ***l_2328;
    int32_t l_2365;
    int64_t *l_2461;
    int64_t **l_2460;
    int64_t ***l_2459 = &l_2460;
    int64_t ****l_2458;
    uint32_t l_2462;
    const int32_t *l_2570 = &l_2277;
    const uint32_t ** const * const l_2589 = (void*)0;
    int i, j, k;
    if ((*g_292))
    { /* block id: 879 */
        uint8_t l_1940 = 0xBFL;
        int64_t *l_1943;
        int32_t *l_1946;
        int32_t l_1949;
        uint64_t l_2014[5][10][5];
        int32_t l_2027[10][1][8];
        int32_t ****l_2067[1][6] = {{&l_1935,&l_1935,&l_1935,&l_1935,&l_1935,&l_1935}};
        uint32_t l_2071[3];
        int64_t l_2078[2];
        int32_t ***l_2093;
        int32_t l_2108[6];
        uint8_t l_2208[8] = {0xDFL,251UL,0xDFL,0xDFL,251UL,0xDFL,0xDFL,251UL};
        uint8_t *** const *l_2249;
        uint8_t *** const ** const l_2248[9][9][3] = {{{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0}},{{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249}},{{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0}},{{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249}},{{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0}},{{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249}},{{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0}},{{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249}},{{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0},{&l_2249,&l_2249,&l_2249},{(void*)0,(void*)0,(void*)0}}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2071[i] = 0UL;
        for (i = 0; i < 2; i++)
            l_2078[i] = 0xF38DAEB92A4DB933LL;
        l_1949 &= (((p_15 > (safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*14*//* ___SAFE__OP */(((!(l_1935 == (**g_1732))) ^ 2UL), 3))) & ((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*15*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*16*//* ___SAFE__OP */(((**g_291) , l_1940), (safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*17*//* ___SAFE__OP */((((*l_1943) = p_15) >= (((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*18*//* ___SAFE__OP */((((*l_1946) = p_15) , (safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*19*//* ___SAFE__OP */(l_1940, l_1940))), 0x0B388BB74D3A5756LL)) >= 1UL) ^ p_15)), (**g_1197))))), g_1249)) < 3UL)) >= p_15);
lbl_2112:
        for (g_560 = 7; (g_560 >= 15); g_560++)
        { /* block id: 885 */
            uint32_t l_1957[10][6];
            int8_t l_1965 = 0L;
            uint8_t *****l_1996[8][2];
            int32_t *l_2006;
            uint8_t l_2011;
            int32_t l_2021;
            int32_t l_2024;
            int32_t l_2026[3];
            const uint32_t l_2037 = 0x7DC24930L;
            int i, j;
            for (i = 0; i < 3; i++)
                l_2026[i] = 0x1213A06CL;
            for (g_737 = 0; (g_737 < 35); g_737 = safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*20*//* ___SAFE__OP */(g_737, 1))
            { /* block id: 888 */
                uint32_t l_1956;
                int8_t *l_1961;
                uint64_t **l_1964;
                int32_t *l_1992;
                uint8_t *****l_1997;
                int32_t *l_2019;
                int32_t l_2020;
                int32_t l_2028;
                int32_t l_2030;
                int32_t l_2031[5][7][7];
                const int32_t l_2073 = 0xA4000828L;
                int i, j, k;
                if (((*****g_1660) < ((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*21*//* ___SAFE__OP */((l_1956 && (l_1957[2][3] > (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*22*//* ___SAFE__OP */(((((!(l_1957[2][3] || (((*l_1961) = g_926[0]) > 0x05L))) > (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*23*//* ___SAFE__OP */((3UL < ((((((((*l_1964) = &g_956) != (void*)0) ^ l_1965) == l_1957[6][5]) <= p_15) && 0x10945AA1C38334E1LL) & g_956)), p_15))) < l_1940) ^ p_15), l_1940)))), l_1956)) , 1L)))
                { /* block id: 891 */
                    int16_t l_1969 = (-1L);
                    int32_t *l_1993;
                    uint8_t *****l_1998;
                    for (g_533 = 23; (g_533 < 13); --g_533)
                    { /* block id: 894 */
                        int32_t *l_1968;
                        uint32_t l_2005;
                        (**g_291) = ((*l_1968) ^= p_15);
                        (**g_291) = (((l_1969 < (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*24*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*25*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*26*//* ___SAFE__OP */(((*g_384) = (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*27*//* ___SAFE__OP */((l_1969 <= (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*28*//* ___SAFE__OP */((((safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*29*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*30*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*31*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*32*//* ___SAFE__OP */(((((safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*33*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*34*//* ___SAFE__OP */((l_1992 != l_1993), (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*35*//* ___SAFE__OP */(((((l_1997 = l_1996[1][0]) != (g_1999 = l_1998)) > (safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*36*//* ___SAFE__OP */(((*l_1961) = ((*l_1968) ^ (safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*37*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*38*//* ___SAFE__OP */((l_1956 && 65534UL), p_15)), p_15))))))) < 0UL), (**g_291))))), l_1956)) , (*l_1968)) < l_1969) ^ g_978), p_15)) ^ l_1957[9][2]), l_1940)), p_15)), 14)) || 1L) > l_1957[3][4]), 0x1CEF4871L))), p_15))), l_2005)), 1UL)) < 0L), g_96))) , (void*)0) != (void*)0);
                        if ((*g_292))
                            continue;
                    }
                    (**l_1935) = &l_1949;
                    (**l_1935) = l_2006;
                    for (g_956 = 0; (g_956 <= 4); g_956 += 1)
                    { /* block id: 908 */
                        uint64_t *l_2012 = (void*)0;
                        uint64_t *l_2013;
                        uint8_t * const l_2018[8][10][3] = {{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}},{{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011},{&g_96,&g_96,&g_96},{&l_2011,&l_2011,&l_2011}}};
                        int i, j, k;
                        (**g_1663) ^= (((((g_682[(g_956 + 1)][g_956][g_956] , (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*39*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*40*//* ___SAFE__OP */((l_2014[0][9][0] = ((*l_2013) |= (((*l_2006) ^= l_1949) != l_2011))), 44)), 0UL))) < ((0UL || p_15) ^ ((l_2015 != ((p_15 == (l_1940 >= 0xA6ABL)) , l_2018[6][4][1])) < 0x05L))) | p_15) == g_682[(g_956 + 1)][g_956][g_956]) , p_15);
                        return (*g_227);
                    }
                }
                else
                { /* block id: 915 */
                    int32_t *l_2022;
                    int32_t *l_2023[5];
                    uint32_t l_2032;
                    int32_t ****l_2068;
                    int32_t *****l_2069;
                    uint16_t *l_2072[8][3] = {{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737},{&g_560,&g_737,&g_737}};
                    int8_t * const **l_2077;
                    int i, j;
                    l_2019 = &l_1949;
                    ++l_2032;
                    (**g_291) = ((*l_2006) = (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*41*//* ___SAFE__OP */(l_2037, (((l_1949 != (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*42*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*43*//* ___SAFE__OP */((0x35L | (((((*l_2077) = ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*44*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*45*//* ___SAFE__OP */((((*l_1961) &= (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*46*//* ___SAFE__OP */(((*g_707) |= (p_15 , (--(*l_2015)))), (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*47*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*48*//* ___SAFE__OP */((!(((*l_2022) = ((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*49*//* ___SAFE__OP */((((**g_1197)++) <= 3L), p_15)) >= (safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*50*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*51*//* ___SAFE__OP */(((((*g_227) & (safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*52*//* ___SAFE__OP */(((safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*53*//* ___SAFE__OP */((((*g_1732) = l_2067[0][4]) != (l_2070 = l_2068)), p_15)) & (*l_2006)), p_15))) , l_2071[2]) | p_15), 2)), 6)))) >= l_2073)), p_15)), l_2074))))) ^ p_15), (-1L))), 0x7B814FACL)) , g_2075)) == (void*)0) == p_15) ^ p_15)), g_1034)), 0xF63CC03946C29A7DLL))) && (*l_2022)) , p_15))));
                }
                l_2080--;
                return (*l_2006);
            }
        }
        for (g_1605 = (-23); (g_1605 >= 34); g_1605++)
        { /* block id: 935 */
            int32_t *l_2085;
            int32_t l_2167;
            int16_t l_2169;
            int32_t l_2170;
            int32_t l_2171[4];
            uint16_t l_2172 = 0x173EL;
            int32_t **l_2186[1];
            int i;
            for (i = 0; i < 4; i++)
                l_2171[i] = 0xD8D3E995L;
            for (i = 0; i < 1; i++)
                l_2186[i] = (void*)0;
            (***l_2070) = l_2085;
            if (p_15)
            { /* block id: 937 */
                int16_t l_2104;
                uint16_t *l_2105;
                uint16_t *l_2106;
                int32_t l_2109;
                l_2109 &= ((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*54*//* ___SAFE__OP */((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*55*//* ___SAFE__OP */(((((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*56*//* ___SAFE__OP */((~5L), (((((l_2093 == ((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*57*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*58*//* ___SAFE__OP */(p_15, ((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*59*//* ___SAFE__OP */(((((**g_1197) < 18446744073709551612UL) & p_15) <= 0xEFL), p_15)) , ((*l_2106) &= ((((safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*60*//* ___SAFE__OP */((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*61*//* ___SAFE__OP */((l_2104 > (*g_707)), p_15)), p_15)) , p_15) != p_15) , p_15))))), p_15)) , l_2107)) | (**g_1899)) < p_15) && p_15) >= g_1039))) && p_15) || l_2108[1]) < 0UL), p_15)), 1)) & p_15);
                return (**g_226);
            }
            else
            { /* block id: 941 */
                int64_t l_2110;
                int32_t l_2111 = 7L;
                l_2111 = (l_2110 = (***g_1662));
                (*****g_1660) &= p_15;
                if (g_560)
                    goto lbl_2112;
            }
            if ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*62*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*63*//* ___SAFE__OP */(p_15, p_15)), p_15)))
            { /* block id: 947 */
                int32_t *l_2121 = &l_2029[0][4][2];
                uint32_t l_2143;
                int16_t l_2158;
                int32_t l_2163;
                int32_t l_2165;
                int32_t l_2168;
                int32_t l_2204;
                int32_t l_2205;
                int32_t l_2206;
                int32_t l_2207[9] = {0x9B783009L,(-1L),(-1L),0x9B783009L,(-1L),(-1L),0x9B783009L,(-1L),(-1L)};
                int i;
                for (g_282 = 2; (g_282 > 10); g_282 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*64*//* ___SAFE__OP */(g_282, 4))
                { /* block id: 950 */
                    uint8_t l_2124;
                    const uint32_t l_2141 = 0x43B21ECBL;
                    const int32_t *l_2145 = (void*)0;
                    const int32_t **l_2146;
                    const int32_t **l_2149;
                    int64_t *l_2160;
                    int32_t l_2161 = 1L;
                    uint32_t *l_2162[3];
                    int32_t l_2164 = 0x97096C7CL;
                    int32_t l_2166[10][2];
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_2162[i] = &l_2143;
                    for (g_683 = 0; (g_683 == 54); ++g_683)
                    { /* block id: 953 */
                        uint16_t *l_2131 = &g_737;
                        int32_t l_2142[7];
                        int32_t l_2144;
                        int i;
                        for (i = 0; i < 7; i++)
                            l_2142[i] = 0xACEE2ADBL;
                        l_2085 = ((**l_1935) = l_2121);
                        l_2144 |= (safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*65*//* ___SAFE__OP */(((*l_2085) ^ (l_2124 , p_15)), (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*66*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*67*//* ___SAFE__OP */((((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*68*//* ___SAFE__OP */(((*l_2131) = (1UL <= p_15)), (((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*69*//* ___SAFE__OP */((0x13L & ((1L || (((*l_1943) = ((((+(((*g_461) != (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*70*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*71*//* ___SAFE__OP */((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*72*//* ___SAFE__OP */(l_2141, (*l_2121))), 18446744073709551607UL)) >= 6L), (*g_227)))) , l_2142[4])) ^ 0xE0413379L) == p_15) > p_15)) == p_15)) & (**g_2075))), l_2143)) , (*g_1900)) ^ 255UL))) != 4294967295UL) || (*l_2121)), p_15)), 1UL))));
                    }
                    (*g_1081) = (***l_2070);
                    (*g_2151) = l_2145;
                    (*l_2121) ^= (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*73*//* ___SAFE__OP */(((l_2166[5][1] ^= ((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*74*//* ___SAFE__OP */((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*75*//* ___SAFE__OP */(((*l_1943) = (*g_227)), ((*l_2160) = (l_2158 & (safe_unary_minus_func_int32_t_s/* ___REMOVE_SAFE__OP *//*76*//* ___SAFE__OP */((((*g_2076) & p_15) <= 4L))))))), (l_2172++))) != (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*77*//* ___SAFE__OP */((p_15 || (((-1L) != (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*78*//* ___SAFE__OP */((0x71L | p_15), 1UL))) , p_15)), p_15)))) < p_15), 0x36033605BCFC5350LL));
                }
                if ((g_1550[0][0] , p_15))
                { /* block id: 968 */
                    for (g_978 = 0; (g_978 <= 1); g_978 += 1)
                    { /* block id: 971 */
                        int i;
                        return g_309[g_978];
                    }
                    for (g_55 = 0; (g_55 >= 44); ++g_55)
                    { /* block id: 976 */
                        int32_t *l_2181[10][8][2];
                        int i, j, k;
                        l_2181[1][1][0] = l_2181[8][2][1];
                    }
                    return (*l_2121);
                }
                else
                { /* block id: 980 */
                    int32_t **l_2188;
                    int32_t l_2193[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2193[i] = 0x90D68998L;
                    if (((*l_2121) = (*l_2121)))
                    { /* block id: 982 */
                        int32_t ***l_2187;
                        int32_t l_2200;
                        uint16_t *l_2201 = &g_737;
                        int32_t l_2203[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2203[i] = 1L;
                        if (p_15)
                            break;
                        l_2165 |= (safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*79*//* ___SAFE__OP */((p_15 <= (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*80*//* ___SAFE__OP */(((((0x7BCF6D2AACFDC4DFLL | (((*l_2187) = l_2186[0]) == l_2188)) & p_15) ^ (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*81*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*82*//* ___SAFE__OP */(l_2193[1], 2)), (p_15 || ((255UL | ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*83*//* ___SAFE__OP */((((*g_384) = (safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*84*//* ___SAFE__OP */((((*l_2201) = (((((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*85*//* ___SAFE__OP */(l_2200, p_15)) < 0xDE63L) != (*l_2121)) && 0x2A23451F9169A022LL) > (*g_1900))) < (*l_2121)), p_15))) , p_15), 0x10F64FC5L)) | g_278[0][0][2])) >= l_2202))))) && (*l_2121)), g_261[5]))), p_15));
                        l_2208[3]++;
                        return p_15;
                    }
                    else
                    { /* block id: 990 */
                        return (*l_2121);
                    }
                }
            }
            else
            { /* block id: 994 */
                int16_t l_2213[4][7][5];
                uint64_t ***l_2215 = &l_2214;
                int i, j, k;
                for (g_681 = 0; (g_681 > (-20)); g_681 = safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*86*//* ___SAFE__OP */(g_681, 5))
                { /* block id: 997 */
                    return p_15;
                }
                l_2213[0][1][0] ^= (l_2171[0] = (-5L));
                (*l_2215) = l_2214;
            }
        }
        for (g_1605 = 0; (g_1605 > 56); g_1605 = safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*87*//* ___SAFE__OP */(g_1605, 8))
        { /* block id: 1007 */
            uint8_t l_2233;
            int32_t l_2251;
            int32_t l_2255 = 0L;
            int32_t l_2256;
            int32_t l_2257 = 0x44996E9BL;
            int32_t l_2260;
            if ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*88*//* ___SAFE__OP */(p_15, ((&g_1550[2][1] != (void*)0) && (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*89*//* ___SAFE__OP */(4UL, 9UL))))))
            { /* block id: 1008 */
                uint32_t l_2222;
                if (g_1605)
                    goto lbl_2112;
                l_2222 |= (****g_1661);
                for (g_333 = 0; (g_333 > (-29)); --g_333)
                { /* block id: 1013 */
                    uint32_t l_2225[3][5][4];
                    int i, j, k;
                    for (g_336 = 1; (g_336 <= 7); g_336 += 1)
                    { /* block id: 1016 */
                        int i;
                        l_2225[1][4][3]++;
                        (**g_291) ^= (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*90*//* ___SAFE__OP */((0xD595B0FAL > (safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*91*//* ___SAFE__OP */(l_2208[g_336]))), (safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*92*//* ___SAFE__OP */((l_2233 , p_15), (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*93*//* ___SAFE__OP */(((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*94*//* ___SAFE__OP */(p_15, 0xC9FBA9A1L)) || ((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*95*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*96*//* ___SAFE__OP */((65535UL < 0x580DL), (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*97*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*98*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*99*//* ___SAFE__OP */(((void*)0 == l_2248[8][1][0]), l_2222)) || l_2233), p_15)), p_15)))), p_15)) || 0xDADD595796EF3886LL)), 0xF3L))))));
                        if (p_15)
                            break;
                        if ((**g_291))
                            break;
                    }
                    return l_2233;
                }
                return (**g_226);
            }
            else
            { /* block id: 1025 */
                int32_t l_2250[8];
                int32_t l_2252;
                int32_t l_2253;
                int32_t l_2254;
                int32_t l_2258;
                int32_t l_2259;
                int i;
                --l_2261;
            }
        }
    }
    else
    { /* block id: 1029 */
        int16_t l_2282;
        int32_t l_2283;
        int64_t ***l_2295;
        for (g_51 = 0; (g_51 <= 3); g_51 += 1)
        { /* block id: 1032 */
            int64_t *l_2267;
            int64_t **l_2266;
            int64_t ***l_2265;
            int64_t ****l_2264;
            const int32_t l_2276 = 0xD0C935E1L;
            uint16_t *l_2284;
            uint16_t *l_2285;
            uint16_t *l_2286;
            int8_t *l_2293;
            int32_t *l_2294;
            int i;
            (**g_1663) = (((((*l_2264) = (void*)0) == ((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*100*//* ___SAFE__OP */(((l_2270 == l_2270) != ((*l_2294) = (safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*101*//* ___SAFE__OP */(((((**g_2075) = g_1901[(g_51 / 2)]) & ((((((l_2277 ^= (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*102*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*103*//* ___SAFE__OP */(l_2276, 17)), p_15))) , (((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*104*//* ___SAFE__OP */(((((**g_1197) = ((((*l_2286) = (safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*105*//* ___SAFE__OP */((l_2283 &= l_2282), l_2282))) , ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*106*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*107*//* ___SAFE__OP */(((*l_2267) = (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*108*//* ___SAFE__OP */((0x03FEC9C6L && l_2282), l_2276))), 18446744073709551615UL)), l_2283)) ^ l_2276)) <= l_2282)) < 0L) ^ 0xD986L), p_15)) || p_15) , 0UL)) == 0xA4L) || l_2276) , (*g_2075)) != l_2293)) , l_2282))))), p_15)) , l_2295)) >= l_2282) && 1UL);
            for (g_1249 = 3; (g_1249 >= 0); g_1249 -= 1)
            { /* block id: 1044 */
                int8_t l_2321 = 0L;
                uint32_t *l_2322;
                int32_t l_2327;
                for (g_53 = 3; (g_53 >= 0); g_53 -= 1)
                { /* block id: 1047 */
                    for (g_956 = 0; (g_956 <= 3); g_956 += 1)
                    { /* block id: 1050 */
                        return p_15;
                    }
                    if ((**g_2151))
                        continue;
                }
                l_2214 = &g_384;
                (*l_2294) ^= ((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*109*//* ___SAFE__OP */(((l_2283 ^ (65529UL <= p_15)) , (l_2327 = (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*110*//* ___SAFE__OP */(4294967289UL, (safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*111*//* ___SAFE__OP */((0x1EL <= (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*112*//* ___SAFE__OP */(((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*113*//* ___SAFE__OP */(((*g_707) = ((l_2283 || ((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*114*//* ___SAFE__OP */((((((safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*115*//* ___SAFE__OP */((safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*116*//* ___SAFE__OP */((l_2283 = (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*117*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*118*//* ___SAFE__OP */((((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*119*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*120*//* ___SAFE__OP */(((++(*l_2322)) < p_15), 3)), (*g_1900))) != (safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*121*//* ___SAFE__OP */(l_2321, 9))) == l_2283), p_15)), p_15))))), 5)) ^ p_15) , (**g_1197)) != g_1248) , 1L), p_15)) | 4294967291UL)) ^ 1UL)), l_2321)) , 1UL), 15))), p_15)))))), p_15)) || 0x6EL);
            }
        }
    }
    l_2328 = &g_1798[1];
lbl_2525:
    for (g_978 = 0; (g_978 <= 0); g_978 += 1)
    { /* block id: 1067 */
        int32_t *l_2329;
        int32_t l_2359 = 1L;
        int32_t l_2363;
        int32_t l_2366 = 0x86DBF4FFL;
        int32_t l_2367 = 0x78BFAB52L;
        int32_t l_2369 = (-7L);
        int32_t l_2370;
        int32_t l_2371;
        int32_t l_2372 = 9L;
        int32_t l_2373 = (-6L);
        int32_t l_2374;
        int32_t l_2375;
        uint16_t *l_2392[1];
        int16_t l_2394;
        int32_t *****l_2428;
        int8_t ***l_2445;
        int8_t ****l_2444;
        int i;
        for (i = 0; i < 1; i++)
            l_2392[i] = (void*)0;
        (**l_1935) = l_2329;
        for (g_956 = 0; (g_956 <= 1); g_956 += 1)
        { /* block id: 1071 */
            uint32_t ****l_2345;
            uint32_t *****l_2344 = &l_2345;
            int16_t l_2358;
            int32_t l_2360[1];
            int32_t *l_2361;
            int32_t *l_2362[1][8][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
            uint64_t **l_2364;
            uint8_t l_2376;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_2360[i] = 0x0290AD0FL;
            for (l_2079 = 0; l_2079 < 1; l_2079 += 1)
            {
                for (g_1577 = 0; g_1577 < 2; g_1577 += 1)
                {
                    for (g_1248 = 0; g_1248 < 4; g_1248 += 1)
                    {
                        g_278[l_2079][g_1577][g_1248] = 8L;
                    }
                }
            }
            if ((l_2363 ^= (0xCB32L > ((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*122*//* ___SAFE__OP */(((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*123*//* ___SAFE__OP */((g_228[(g_978 + 2)][g_978] || ((((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*124*//* ___SAFE__OP */(((l_2360[0] = (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*125*//* ___SAFE__OP */((((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*126*//* ___SAFE__OP */(0x6D97E089D7B7A355LL, g_296[g_978][(g_956 * 2)])) < ((((***l_1935) = 0x79C47CB640E21A07LL) > (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*127*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*128*//* ___SAFE__OP */((l_2344 != ((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*129*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*130*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*131*//* ___SAFE__OP */(0x19B03260BBDB0E92LL, 0x8BB3C9A909F27A54LL)), (((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*132*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*133*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*134*//* ___SAFE__OP */((p_15 > 0x07761984717B9E4BLL), p_15)), p_15)) , p_15), 0xAAA169EBL)) | 0xBE2AAD49L) | 0x4BFFL))) , (*g_1900)), p_15)) , (void*)0)), l_2358)), (-3L)))) <= l_2359)) && p_15), l_2358))) , (*l_2329)), p_15)) | 0xC6L) , (**g_1197)) > p_15)), p_15)) < 0x9EE224E60D4417CELL), 65535UL)) , 65531UL))))
            { /* block id: 1076 */
                l_2364 = l_2364;
            }
            else
            { /* block id: 1078 */
                (**l_1935) = (void*)0;
                if (p_15)
                    break;
            }
            l_2376--;
            return (*l_2329);
        }
        for (g_1038 = 0; (g_1038 <= 0); g_1038 += 1)
        { /* block id: 1087 */
            int32_t l_2385;
            uint16_t ** const l_2386 = &g_919[1][6][0];
            uint32_t **l_2390;
            uint32_t *l_2391;
            int64_t *l_2393;
            int32_t **l_2408;
            int32_t l_2419;
            int32_t l_2420[3];
            int i, j;
            for (i = 0; i < 3; i++)
                l_2420[i] = 1L;
            if ((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*135*//* ___SAFE__OP */((((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*136*//* ___SAFE__OP */(((((g_228[(g_1038 + 1)][g_1038] , ((**l_2214)++)) < (*l_2329)) == ((((l_2385 , l_2386) == &g_919[0][5][0]) != ((*l_2393) = (+(((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*137*//* ___SAFE__OP */(((l_2391 = ((*l_2390) = &l_2202)) == (p_15 , (void*)0)), 48)) == ((((p_15 != (*g_2076)) | 3UL) , l_2392[0]) == (*l_2386))) && 65535UL)))) <= l_2394)) || (**g_1899)), 255UL)) & 0xE8A70777C3BDE2ACLL) , 0L), 0xFF2EL)))
            { /* block id: 1092 */
                (****g_1660) = (**g_1662);
            }
            else
            { /* block id: 1094 */
                int64_t l_2398;
                uint16_t *l_2401[1];
                int32_t **l_2409[7];
                int32_t l_2414 = 0x404CEEDCL;
                int32_t l_2417;
                int32_t l_2418;
                int32_t l_2421;
                int32_t l_2422;
                int8_t ***l_2443[9];
                int8_t ****l_2442;
                int8_t *****l_2441[4][6];
                int i, j;
                for (i = 0; i < 1; i++)
                    l_2401[i] = &g_1550[1][5];
                for (i = 0; i < 7; i++)
                    l_2409[i] = (void*)0;
                for (i = 0; i < 9; i++)
                    l_2443[i] = &l_2270;
                for (g_1248 = 3; (g_1248 >= 0); g_1248 -= 1)
                { /* block id: 1097 */
                    const uint16_t * const l_2400 = &l_2261;
                    int32_t l_2410;
                    int16_t l_2427;
                    int i, j, k;
                    if (((0xDCC85F18C3911CF4LL ^ (((((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*138*//* ___SAFE__OP */((g_293[(g_1038 + 2)][g_1038][g_978] && (&l_2385 != ((+(l_2410 = ((4294967295UL < (l_2398 >= (+((***l_2328) = (l_2400 != l_2401[0]))))) != ((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*139*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*140*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*141*//* ___SAFE__OP */(((l_2408 == l_2409[6]) ^ 65529UL), (*l_2329))) , (*g_722)), p_15)), g_228[(g_978 + 2)][g_1038])) != p_15)))) , (void*)0))), 25)) < p_15) >= l_2398) , 0xADE81ED416CE3444LL) >= 5UL)) , 2L))
                    { /* block id: 1100 */
                        int32_t *l_2411;
                        int32_t *l_2412;
                        int32_t *l_2413;
                        int32_t *l_2415;
                        int32_t *l_2416[9][10][2];
                        uint8_t l_2423[9][5] = {{0x01L,0UL,0UL,0x01L,0x23L},{250UL,1UL,2UL,255UL,0x0DL},{0xD1L,1UL,0x23L,1UL,0x83L},{0x1BL,1UL,0xD7L,0x0DL,248UL},{0x23L,0x01L,0UL,0UL,0x01L},{1UL,246UL,3UL,1UL,248UL},{0x37L,0UL,0x83L,1UL,0x83L},{248UL,248UL,0x1BL,1UL,250UL},{0x37L,0xD1L,0x23L,0UL,0UL}};
                        int i, j, k;
                        --l_2423[5][1];
                    }
                    else
                    { /* block id: 1102 */
                        volatile int32_t *l_2426 = &g_293[0][2][0];
                        l_2426 = (***g_1661);
                        (*****g_1660) |= (l_2427 > (*g_722));
                    }
                }
                l_2371 &= ((*l_2329) = ((l_2421 ^= (((***l_2328) ^= (&g_1733[1] == l_2428)) , (g_228[(g_1038 + 1)][g_1038] > (((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*142*//* ___SAFE__OP */((l_2419 = p_15), ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*143*//* ___SAFE__OP */(((*l_2393) = l_2420[2]), ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*144*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*145*//* ___SAFE__OP */(((**l_2386) = p_15), (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*146*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*147*//* ___SAFE__OP */(((-1L) >= (4294967294UL && ((l_2385 = ((void*)0 != g_766[1])) , p_15))), p_15)), 0xE9B0152DL)))), (-5L))) | p_15))) , (-1L)))) , (void*)0) == (void*)0)))) >= 0x5EEFL));
                l_2444 = (void*)0;
            }
            (**l_1935) = (**l_1935);
        }
    }
    for (g_282 = 0; (g_282 > 57); g_282 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*148*//* ___SAFE__OP */(g_282, 7))
    { /* block id: 1122 */
        int8_t l_2450;
        int64_t *l_2457;
        uint8_t **** const l_2463 = &g_890;
        int32_t *l_2464;
        int16_t **l_2477[3];
        uint32_t *l_2478;
        uint32_t *l_2479;
        int32_t *l_2480;
        int32_t *l_2481;
        int32_t *l_2482;
        int32_t *l_2483;
        int32_t **l_2493;
        int32_t ****l_2494;
        uint64_t l_2508;
        int32_t l_2528;
        int32_t l_2529;
        int32_t l_2530;
        int32_t l_2531;
        int32_t l_2532[10][1][6];
        uint64_t l_2548;
        int64_t l_2612[8];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2477[i] = &g_880[2];
        (*g_1081) = (((***l_2328) = ((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*149*//* ___SAFE__OP */((((l_2450 && (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*150*//* ___SAFE__OP */((-1L), ((((((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*151*//* ___SAFE__OP */(((((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*152*//* ___SAFE__OP */((((*l_2457) = 1L) > ((void*)0 != &g_485)), 7)) , l_2458) == (void*)0) >= (l_2462 , ((l_2463 != (*g_1999)) | 0UL))), l_2450)) | 0x466FDFBBL) && p_15) , p_15) , l_2450) , 0x73AAL)))) , p_15) & p_15), 3)) , 1L)) , l_2464);
        (**g_1663) = ((*l_2483) |= ((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*153*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*154*//* ___SAFE__OP */(((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*155*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*156*//* ___SAFE__OP */(p_15, (p_15 , 4294967291UL))), (**g_1663))) , ((*l_2481) = ((((*l_2479) = ((*l_2464) = ((((*g_384) > (**g_226)) || (((***l_1935) && (safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*157*//* ___SAFE__OP */(((((((((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*158*//* ___SAFE__OP */(p_15, 5)) > (((*l_2328) = &g_880[2]) != l_2477[0])) , (***l_1935)) < p_15) == 4294967289UL) >= 18446744073709551615UL) , (*l_2464)) , (**g_1899)), 2))) >= (*l_2464))) , p_15))) , 0x83204D2BL) && p_15))), 5L)) , (***l_1935)), 9UL)) ^ p_15));
        if (((safe_unary_minus_func_uint8_t_u/* ___REMOVE_SAFE__OP *//*159*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*160*//* ___SAFE__OP */(0x58L, ((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*161*//* ___SAFE__OP */((p_15 | (((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*162*//* ___SAFE__OP */(p_15, (safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*163*//* ___SAFE__OP */((l_2493 != l_2493), (((((*l_2494) = &l_2493) != ((((&l_2107 != &l_2107) | ((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*164*//* ___SAFE__OP */((((~(((*g_2076) | (****l_2070)) , (****l_2070))) <= (****l_2070)) ^ (****l_2070)), p_15)) == p_15)) , (*l_2464)) , &l_2493)) , p_15) & p_15))))) == p_15) , 8L)), p_15)) < (*g_2076)))))) <= 6UL))
        { /* block id: 1133 */
            uint32_t *l_2502[2][10][7];
            uint32_t l_2503;
            uint16_t *l_2509;
            uint16_t *l_2510;
            int32_t l_2511;
            uint64_t *l_2512;
            uint64_t *l_2513;
            int32_t l_2524 = 0x98BEEC3BL;
            int32_t l_2526;
            int32_t l_2533[8];
            int i, j, k;
            l_2029[0][4][2] ^= ((((*l_2481) , (**g_1999)) != (void*)0) , (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*165*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*166*//* ___SAFE__OP */(((****l_2070) = (l_2503 = ((***l_1935) | (*g_384)))), (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*167*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*168*//* ___SAFE__OP */(((*l_2510) ^= l_2508), (0x49EA53BF4EBF7E9ELL || (--(*l_2513))))) <= (p_15 < ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*169*//* ___SAFE__OP */(0x648E3D20L, l_2511)) , 0x20D39A1FL))), 1L)))), p_15)));
            if ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*170*//* ___SAFE__OP */(p_15, (&g_533 == (void*)0))))
            { /* block id: 1139 */
                if ((*l_2481))
                    break;
                return (***l_1935);
            }
            else
            { /* block id: 1142 */
                int32_t *l_2527[7][7][3];
                uint32_t l_2535;
                int i, j, k;
                for (g_485 = 0; (g_485 <= 5); g_485 = safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*171*//* ___SAFE__OP */(g_485, 6))
                { /* block id: 1145 */
                    for (g_1249 = 0; (g_1249 < 19); ++g_1249)
                    { /* block id: 1148 */
                        return l_2524;
                    }
                    if ((*g_461))
                        break;
                    if (l_2524)
                        continue;
                }
                if (g_282)
                    goto lbl_2525;
                ++l_2535;
            }
        }
        else
        { /* block id: 1157 */
            uint8_t l_2538;
            int32_t l_2545;
            int32_t l_2547 = 0x7C8AD55DL;
            uint16_t **l_2609;
            uint8_t **l_2622;
            l_2538--;
            for (g_1486 = 0; (g_1486 <= 4); g_1486 += 1)
            { /* block id: 1161 */
                int64_t l_2541[3];
                int32_t *l_2542 = &g_686;
                int32_t *l_2543;
                int32_t *l_2544[9];
                int32_t l_2546;
                int32_t l_2555;
                uint16_t *l_2562 = &l_2261;
                int i;
                for (i = 0; i < 3; i++)
                    l_2541[i] = (-8L);
                l_2548++;
                for (g_208 = 0; (g_208 <= 5); g_208 += 1)
                { /* block id: 1165 */
                    uint32_t *l_2551 = (void*)0;
                    uint32_t *l_2552;
                    uint32_t *l_2553;
                    uint32_t *l_2556;
                    uint16_t *l_2561 = &g_1550[6][1];
                    int i;
                    (**g_291) = ((g_1901[g_1486] <= (((*l_2553) = g_261[g_208]) ^ ((*l_2556) ^= (!l_2555)))) & (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*172*//* ___SAFE__OP */(((*l_2543) = (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*173*//* ___SAFE__OP */(((l_2561 != l_2562) | ((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*174*//* ___SAFE__OP */((p_15 && ((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*175*//* ___SAFE__OP */((g_261[g_208] < (((*g_2076) & (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*176*//* ___SAFE__OP */(g_926[0], 0x568E7AC055B41805LL))) && (*l_2542))), (-3L))) ^ 252UL)), p_15)) , p_15)), p_15))), l_2545)));
                }
                for (l_2261 = 0; (l_2261 <= 4); l_2261 += 1)
                { /* block id: 1173 */
                    const int32_t *l_2569[4];
                    uint32_t ***l_2583;
                    uint16_t **l_2610;
                    int32_t l_2613;
                    int i;
                    for (i = 0; i < 4; i++)
                        l_2569[i] = &l_2025;
                    if (g_1901[g_1486])
                    { /* block id: 1174 */
                        (**l_1935) = &l_2545;
                        l_2570 = l_2569[1];
                        (*g_2571) = l_2569[3];
                    }
                    else
                    { /* block id: 1178 */
                        uint32_t l_2576 = 0x5E09DB5BL;
                        uint16_t *l_2577;
                        uint8_t **l_2584[7];
                        uint32_t * const ***l_2586 = &g_2585;
                        uint32_t * const **l_2588;
                        uint32_t * const ***l_2587;
                        int32_t *l_2596;
                        uint64_t *l_2611;
                        int i;
                        (*l_2542) = ((((**g_226) & (((*g_2076) , ((*l_2464) , ((0x0FL ^ (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*177*//* ___SAFE__OP */(((*l_2577) = ((safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*178*//* ___SAFE__OP */((l_2576 || ((((((*l_2570) , p_15) <= p_15) < ((((p_15 != p_15) , (*l_2481)) == (*l_2483)) , p_15)) >= g_53) >= l_2576)), 4)) , p_15)), (***l_1935)))) > (*g_384)))) > (***l_1935))) == l_2576) , 0xC9785EC6L);
                        (*l_2543) &= (safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*179*//* ___SAFE__OP */((((safe_unary_minus_func_uint8_t_u/* ___REMOVE_SAFE__OP *//*180*//* ___SAFE__OP */(p_15)) | (l_2547 = ((***l_2328) = l_2576))) & ((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*181*//* ___SAFE__OP */(0xFAC3L, 15)) <= (l_2583 != (*g_1884)))), (p_15 && ((((*l_2587) = ((*l_2586) = ((l_2584[6] != (**l_2463)) , g_2585))) != l_2589) & p_15))));
                        (*l_2483) ^= (((l_2613 ^= ((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*182*//* ___SAFE__OP */(((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*183*//* ___SAFE__OP */(((***l_2328) |= ((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*184*//* ___SAFE__OP */((((*l_2457) = (&l_2545 == l_2596)) ^ (-1L)), (**g_1197))) && l_2545)), (0xC71544CBL != (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*185*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*186*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*187*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*188*//* ___SAFE__OP */((0x257CL > ((*l_2481) | (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*189*//* ___SAFE__OP */((l_2547 = ((((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*190*//* ___SAFE__OP */(((*l_2611) |= (((l_2610 = l_2609) == &g_919[0][7][0]) > (*l_2596))), 30)) <= p_15) > (*l_2543)) >= l_2612[2])), 0x1DFD58D48762EDC8LL)))), 7L)) , (**g_226)), g_1543)), g_682[4][3][4])), (*l_2596)))))) || (**g_2075)), 0xA8335178E21E83D1LL)) <= 0L)) , (**g_1899)) | p_15);
                    }
                    (*****g_1660) &= (**g_1081);
                    for (g_1898 = 0; (g_1898 <= 2); g_1898 += 1)
                    { /* block id: 1197 */
                        (**g_1663) = (*g_292);
                    }
                    for (g_329 = 0; (g_329 <= 4); g_329 += 1)
                    { /* block id: 1202 */
                        uint16_t l_2634[2][10];
                        uint32_t *l_2635;
                        uint64_t *l_2636;
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 10; j++)
                                l_2634[i][j] = 0x096FL;
                        }
                        (**g_1663) = ((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*191*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*192*//* ___SAFE__OP */((p_15 & ((*l_2636) = ((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*193*//* ___SAFE__OP */((p_15 < ((((**l_2463) = (void*)0) == ((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*194*//* ___SAFE__OP */(p_15, 0L)) , l_2622)) , 0x6A17L)), 2)) > (safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*195*//* ___SAFE__OP */(((*g_707) = (((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*196*//* ___SAFE__OP */(((*l_2635) = (((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*197*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*198*//* ___SAFE__OP */((+((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*199*//* ___SAFE__OP */(((*g_227) | ((((*l_2464) , l_2538) && (*g_707)) < l_2634[0][8])), (*l_2543))) <= p_15)), (*g_707))), p_15)) , 0x7FC6ADC05C0CC7F1LL) <= 6UL)), 19)) && (***l_1935)) , p_15)), 7))))), p_15)), p_15)) ^ p_15);
                    }
                }
            }
        }
    }
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_282 g_291 g_292 g_1661 g_1662 g_1663 g_53 g_293 g_384 g_329 g_1660 g_333 g_1884 g_1889 g_1898 g_1899 g_955 g_707 g_614 g_55 g_686 g_1925
 * writes: g_282 g_281 g_679 g_292 g_51 g_310 g_1885 g_461 g_686 g_55
 */
static int16_t * func_17(uint16_t  p_18, int16_t * const  p_19, int16_t * p_20)
{ /* block id: 832 */
    uint8_t l_1822;
    int64_t *l_1829;
    int32_t **l_1831;
    int32_t l_1856;
    int16_t l_1868;
    const int64_t *l_1873[2];
    const int64_t **l_1872;
    uint16_t l_1902;
    int32_t *l_1903;
    uint32_t *l_1918;
    int32_t *l_1926[6];
    uint16_t l_1927;
    int i;
    for (i = 0; i < 2; i++)
        l_1873[i] = &g_926[0];
    for (g_282 = 0; (g_282 >= 33); g_282++)
    { /* block id: 835 */
        uint32_t l_1823;
        int32_t ***l_1843;
        int32_t l_1857;
        int64_t **l_1871;
        for (g_281 = (-20); (g_281 >= 22); g_281++)
        { /* block id: 838 */
            int32_t l_1827;
            uint64_t l_1840;
            int32_t l_1874 = 7L;
            uint32_t ****l_1887[2];
            int i;
            for (i = 0; i < 2; i++)
                l_1887[i] = &g_1885;
            for (g_679 = (-20); (g_679 >= 1); g_679++)
            { /* block id: 841 */
                (*g_291) = (*g_291);
            }
            for (g_51 = 0; (g_51 == (-3)); g_51--)
            { /* block id: 846 */
                int64_t *l_1828 = &g_926[0];
                int32_t **l_1830;
                int64_t l_1832;
                int32_t l_1833 = (-1L);
                uint32_t *l_1838 = (void*)0;
                uint32_t *l_1839[1];
                uint32_t *****l_1888;
                uint8_t l_1895[8];
                int i;
                for (i = 0; i < 1; i++)
                    l_1839[i] = &g_1450[2][0];
                for (i = 0; i < 8; i++)
                    l_1895[i] = 0x2DL;
                l_1833 = (l_1822 , (l_1823 == ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*200*//* ___SAFE__OP */((!(p_18 ^= l_1827)), (l_1828 != l_1829))) > ((((l_1831 = l_1830) != (**g_1661)) , l_1832) && l_1832))));
                l_1857 ^= (l_1856 = (((void*)0 == &g_722) , ((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*201*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*202*//* ___SAFE__OP */((l_1840 = p_18), 9)), (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*203*//* ___SAFE__OP */(3L, 0xF8L)))) != ((l_1843 == (void*)0) & (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*204*//* ___SAFE__OP */(((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*205*//* ___SAFE__OP */(0x5962E1A6L, (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*206*//* ___SAFE__OP */((((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*207*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*208*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*209*//* ___SAFE__OP */((p_18 == l_1823), l_1827)) , 0xE768L), (*p_19))), 4)) & p_18) > l_1823), (**g_291))))) > (*g_384)), (-1L)))))));
                if ((safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*210*//* ___SAFE__OP */(l_1823, (((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*211*//* ___SAFE__OP */(((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*212*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*213*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*214*//* ___SAFE__OP */(((((l_1868 && (safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*215*//* ___SAFE__OP */((l_1871 == l_1872), 5))) ^ 7UL) == (l_1874 = (*****g_1660))) | (l_1857 >= ((-1L) < ((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*216*//* ___SAFE__OP */((((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*217*//* ___SAFE__OP */(18446744073709551615UL, l_1857)) != g_333) < l_1856), 27)) | (*p_20))))), l_1856)), 0x6FL)) || 1UL), (-1L))) < 0xED42L), 252UL)) || p_18) > 0UL))))
                { /* block id: 854 */
                    uint32_t ***l_1881 = (void*)0;
                    int16_t *l_1886;
                    for (g_310 = 0; (g_310 >= 38); g_310 = safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*218*//* ___SAFE__OP */(g_310, 2))
                    { /* block id: 857 */
                        uint32_t ****l_1882;
                        uint32_t ****l_1883;
                        (*g_1884) = ((*l_1882) = l_1881);
                    }
                    return l_1886;
                }
                else
                { /* block id: 862 */
                    (*l_1830) = &l_1857;
                }
                l_1874 &= (((*l_1888) = l_1887[0]) != ((((void*)0 != g_1889) <= (l_1857 && ((safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*219*//* ___SAFE__OP */((((safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*220*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*221*//* ___SAFE__OP */(l_1895[0], (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*222*//* ___SAFE__OP */(0x8D291169L, g_1898)))) < ((g_1899 == (void*)0) < 9L)), l_1902)) > 5L) || g_955[6]))) >= l_1857))) , &g_1885));
            }
        }
        (****g_1660) = (***g_1661);
    }
    l_1856 = ((*l_1903) = p_18);
    l_1856 ^= ((p_18 | p_18) , (((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*223*//* ___SAFE__OP */((*g_707), (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*224*//* ___SAFE__OP */(p_18, (((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*225*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*226*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*227*//* ___SAFE__OP */(((((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*228*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*229*//* ___SAFE__OP */(((*l_1903) = (--(*l_1918))), (((+(0x9E99BA03L < (~(p_19 != &l_1868)))) | p_18) ^ (safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*230*//* ___SAFE__OP */((p_18 != (-4L)), p_18))))), p_18)) ^ p_18) > 1L) , (*l_1903)), 1)) , (*p_19)), 6)), p_18)) > p_18) , p_18))))) >= g_1925) >= (-1L)));
    l_1927--;
    return &l_1868;
}


/* ------------------------------------------ */
/* 
 * reads : g_707 g_614 g_336 g_1034 g_59 g_485 g_384 g_329 g_1450 g_1577 g_956 g_532 g_1586 g_51 g_88 g_55 g_53 g_96 g_162 g_208 g_212 g_164 g_226 g_230 g_260 g_261 g_282 g_291 g_115 g_296 g_310 g_325 g_278 g_333 g_326 g_309 g_435 g_533 g_683 g_688 g_1081 g_1605 g_1249 g_461 g_1250 g_1548 g_1132 g_1197 g_679 g_1660 g_889 g_890 g_408 g_1732 g_227 g_676 g_1663 g_292 g_307
 * writes: g_686 g_88 g_59 g_1034 g_485 g_560 g_333 g_1039 g_1450 g_1577 g_955 g_1548 g_96 g_115 g_164 g_208 g_212 g_230 g_282 g_296 g_310 g_325 g_51 g_336 g_260 g_329 g_384 g_55 g_435 g_195 g_532 g_461 g_683 g_688 g_614 g_1605 g_1249 g_1250 g_679 g_949 g_691 g_1732 g_1311 g_890 g_676 g_1132 g_292 g_307 g_721
 */
static int32_t  func_29(uint8_t  p_30, int16_t * p_31, int64_t  p_32, uint32_t  p_33, int16_t * p_34)
{ /* block id: 593 */
    int8_t l_1380;
    uint16_t *l_1383;
    uint16_t l_1390;
    int16_t *l_1391 = &g_1034;
    uint16_t **l_1392[6][3];
    uint16_t *l_1393;
    int32_t *l_1394;
    int32_t *l_1395[1][10][3] = {{{(void*)0,(void*)0,(void*)0},{&g_88,&g_333,&g_88},{(void*)0,(void*)0,(void*)0},{&g_88,&g_333,&g_88},{(void*)0,(void*)0,(void*)0},{&g_88,&g_333,&g_88},{(void*)0,(void*)0,(void*)0},{&g_88,&g_333,&g_88},{(void*)0,(void*)0,(void*)0},{&g_88,&g_333,&g_88}}};
    uint8_t l_1396;
    int16_t *l_1397;
    int16_t l_1399;
    int16_t *l_1400[1];
    uint32_t l_1401;
    uint32_t l_1402[7][9];
    int8_t l_1433;
    int32_t ** const **l_1525;
    int32_t ***l_1674;
    uint32_t l_1689;
    uint8_t l_1694;
    uint8_t ***l_1744;
    int32_t l_1749;
    const uint32_t *l_1757;
    uint64_t l_1760;
    uint32_t **l_1769;
    int32_t l_1795;
    int16_t **l_1803 = &g_880[2];
    uint32_t ***l_1809 = &g_721[4][1][0];
    uint32_t ****l_1808[7][6][3];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1400[i] = &g_9;
    g_88 = (g_686 = (l_1380 > (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*231*//* ___SAFE__OP */((l_1380 , (((l_1383 = &g_1134) != (l_1393 = func_37(p_33, ((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*232*//* ___SAFE__OP */(0xDFL, (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*233*//* ___SAFE__OP */(((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*234*//* ___SAFE__OP */((&g_880[0] != (void*)0), ((l_1380 & (l_1390 != 0x051AL)) , 0x06L))) | 0xDA8C860AL) && p_30) >= p_30), (*g_707))))) , &g_53), l_1391, g_336))) & (*p_34))), 255UL))));
    l_1396 = p_32;
    if (((l_1401 = ((*p_34) = ((((*l_1397) |= (*p_34)) , ((safe_unary_minus_func_int64_t_s/* ___REMOVE_SAFE__OP *//*235*//* ___SAFE__OP */(0x0B762F4C09C9AD62LL)) || l_1399)) != p_30))) >= ((p_30 ^ (4UL == p_32)) , l_1402[2][3])))
    { /* block id: 602 */
        int32_t l_1405[5];
        int8_t *l_1478 = &g_530;
        uint32_t l_1492[3];
        int32_t l_1545;
        int8_t l_1561;
        uint16_t l_1570;
        int i;
        for (i = 0; i < 3; i++)
            l_1492[i] = 0x88A427BCL;
lbl_1573:
        for (g_485 = 0; (g_485 > 4); g_485++)
        { /* block id: 605 */
            int64_t l_1424[7] = {0L,0L,0L,0L,0L,0L,0L};
            int32_t l_1449;
            int64_t l_1455[7];
            uint32_t *l_1476[10][1][1] = {{{(void*)0}},{{&g_1450[2][0]}},{{(void*)0}},{{&g_1450[2][0]}},{{(void*)0}},{{&g_1450[2][0]}},{{(void*)0}},{{&g_1450[2][0]}},{{(void*)0}},{{&g_1450[2][0]}}};
            int32_t * const *l_1520;
            int32_t *l_1541 = &l_1405[1];
            uint8_t **l_1571;
            uint16_t l_1572;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_1455[i] = 0L;
            l_1405[1] ^= p_33;
            for (l_1399 = 0; (l_1399 != 19); l_1399++)
            { /* block id: 609 */
                int32_t l_1432;
                int32_t l_1447;
                int32_t l_1448[10];
                int i;
                for (g_560 = 0; (g_560 <= 0); g_560 += 1)
                { /* block id: 612 */
                    int8_t l_1434;
                    int32_t l_1435;
                    if ((!((safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*236*//* ___SAFE__OP */(g_485, (((((((~((~((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*237*//* ___SAFE__OP */(((((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*238*//* ___SAFE__OP */((~0x0F758E2D411DC920LL), 2L)) , ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*239*//* ___SAFE__OP */(0x62D71EC4L, (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*240*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*241*//* ___SAFE__OP */(l_1424[6], 6)) | l_1424[5]), p_33)))) != 65535UL)) >= ((*l_1391) = ((~(((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*242*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*243*//* ___SAFE__OP */(((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*244*//* ___SAFE__OP */(l_1432, l_1433)) & p_32), l_1424[6])), 0xA55166AFL)) || p_30) > l_1432)) == p_33))) >= l_1434), p_33)) == p_33)) , 3UL)) ^ (*g_384)) & 0L) <= 0x4BL) , (-10L)) >= l_1405[1]) == p_33))) <= l_1432)))
                    { /* block id: 614 */
                        uint32_t l_1436 = 0x8D25925AL;
                        l_1435 = p_33;
                        if (l_1436)
                            break;
                        if (g_329)
                            goto lbl_1573;
                    }
                    else
                    { /* block id: 617 */
                        uint32_t *l_1441;
                        l_1435 = (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*245*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*246*//* ___SAFE__OP */(((p_30 , l_1441) != &g_208), p_33)), (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*247*//* ___SAFE__OP */((7UL ^ (-5L)), ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*248*//* ___SAFE__OP */((g_333 = l_1405[1]), (l_1405[2] , p_32))) || 0x12B0F8F1L)))));
                    }
                }
                for (g_1039 = 0; (g_1039 <= 2); g_1039 += 1)
                { /* block id: 624 */
                    int16_t l_1446 = 0xC775L;
                    ++g_1450[2][0];
                }
            }
        }
        for (p_30 = 0; (p_30 <= 9); p_30 = safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*249*//* ___SAFE__OP */(p_30, 6))
        { /* block id: 694 */
            int16_t l_1576;
            g_1577++;
            g_333 = l_1405[3];
        }
        l_1405[0] &= (((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*250*//* ___SAFE__OP */(g_956, g_532)) < 255UL) == p_30);
    }
    else
    { /* block id: 699 */
        int64_t *l_1587;
        int32_t l_1588;
        int64_t *l_1589 = &g_955[4];
        int64_t *l_1590;
        int32_t *l_1648;
        uint64_t l_1653;
        int64_t l_1677[6][3];
        int16_t **l_1701;
        int64_t l_1725;
        int32_t *l_1727;
        int i, j;
        (*g_1081) = func_71(((*l_1590) = (safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*251*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*252*//* ___SAFE__OP */(0x6D543CD353B7805ALL, (-1L))), (((*l_1587) = g_1586) <= (l_1588 >= (*p_34)))))));
        if (l_1433)
            goto lbl_1591;
lbl_1591:
        (*g_1081) = &l_1588;
lbl_1750:
        if (l_1588)
        { /* block id: 705 */
            uint64_t l_1594;
            int32_t l_1597;
            uint32_t *l_1600 = &l_1401;
            int32_t l_1601;
            int32_t l_1603;
            int32_t l_1604[6];
            int32_t ***l_1646;
            uint8_t *** const *l_1651;
            uint8_t *** const **l_1650 = &l_1651;
            uint8_t l_1678[9][9];
            int32_t l_1693;
            int32_t *l_1745;
            int i, j;
            if ((safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*253*//* ___SAFE__OP */(l_1594, (p_30 > ((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*254*//* ___SAFE__OP */((((p_32 <= l_1597) >= ((*g_707) = ((*p_34) > (((*l_1600) &= (0x09L || (((p_32 , func_37(p_32, &g_9, &g_977, g_532)) == (void*)0) , 9L))) >= 0x7023AB69L)))) | p_33), 0x5688L)) != g_230[5][4][0])))))
            { /* block id: 708 */
                int32_t l_1602[5][1][9] = {{{1L,3L,(-6L),0x439948A6L,3L,0x178BB622L,0xFFD0ECB3L,0x178BB622L,3L}},{{1L,0x3EE36336L,0x3EE36336L,1L,3L,3L,(-8L),0x178BB622L,0x3EE36336L}},{{(-8L),3L,0xB8B2EEF2L,1L,0xC945711BL,3L,0xFFD0ECB3L,3L,3L}},{{1L,0x178BB622L,3L,1L,3L,0x178BB622L,1L,0x3EE36336L,0x178BB622L}},{{1L,0x178BB622L,0xB8B2EEF2L,1L,3L,(-6L),0x439948A6L,3L,0x178BB622L}}};
                int i, j, k;
                if (g_956)
                    goto lbl_1591;
                ++g_1605;
                for (g_1249 = 3; (g_1249 >= 0); g_1249 -= 1)
                { /* block id: 713 */
                    int i;
                    (*g_461) &= g_261[(g_1249 + 1)];
                    if ((*g_461))
                        continue;
                    for (g_1250 = 0; (g_1250 <= 2); g_1250 += 1)
                    { /* block id: 718 */
                        return p_33;
                    }
                }
            }
            else
            { /* block id: 722 */
                (**g_1081) ^= l_1594;
            }
            if (g_53)
                goto lbl_1750;
            for (g_1548 = 0; (g_1548 == 17); g_1548 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*255*//* ___SAFE__OP */(g_1548, 1))
            { /* block id: 727 */
                uint32_t l_1612;
                uint8_t ****l_1633;
                int32_t *l_1647;
                int32_t l_1652[9][3][1];
                const uint8_t *l_1666 = &l_1396;
                const uint8_t **l_1665;
                const uint8_t ***l_1664[1][9];
                int64_t *l_1737;
                const int32_t l_1740 = 0xA065A1A9L;
                int i, j, k;
                for (g_683 = 0; (g_683 <= 0); g_683 += 1)
                { /* block id: 730 */
                    int16_t l_1610;
                    l_1588 = (l_1610 , (*g_461));
                    (**g_1081) &= 0x995109A2L;
                    return (*g_461);
                }
                if ((~l_1612))
                { /* block id: 735 */
                    int8_t l_1619 = 1L;
                    int32_t l_1626[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1626[i] = 0xB8A6CD5BL;
                    l_1604[3] |= (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*256*//* ___SAFE__OP */((0x57AA25ADL || ((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*257*//* ___SAFE__OP */((((+g_1132) , (**g_1197)) && (+(l_1619 &= l_1612))), l_1612)) & (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*258*//* ___SAFE__OP */(0x4DL, ((1L == (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*259*//* ___SAFE__OP */((p_32 & (((void*)0 == &g_1577) ^ 0xC42E2675C08E3727LL)), (*p_34)))) == (*p_34)))))), l_1612));
                    l_1626[0] = (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*260*//* ___SAFE__OP */(p_33, 0x84A693E56D52518CLL));
                    (*g_461) = ((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*261*//* ___SAFE__OP */((*g_707), ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*262*//* ___SAFE__OP */(l_1612, (((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*263*//* ___SAFE__OP */(p_32, ((l_1646 = ((((((void*)0 != l_1633) > (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*264*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*265*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*266*//* ___SAFE__OP */((p_33 , ((l_1604[4] != (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*267*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*268*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*269*//* ___SAFE__OP */((+((p_30 , (0xA8FA354FL > l_1626[0])) | p_30)))), l_1626[0])), g_679))) , 4294967289UL)), 4294967295UL)) != 0xDB1BL), 25)), 0x122F48B7L))) != 5L) > (-1L)) , (void*)0)) == (void*)0))) >= (*g_384)) > (**g_1197)))) , (-5L)))) && 0L);
                }
                else
                { /* block id: 741 */
                    uint8_t *****l_1649;
                    uint16_t **l_1667;
                    int32_t l_1672;
                    int8_t *l_1679;
                    int8_t *l_1680[9];
                    int32_t l_1695;
                    int32_t **l_1700;
                    int16_t **l_1726;
                    int i;
                    l_1648 = l_1647;
                    if ((*l_1648))
                    { /* block id: 743 */
                        (**g_1081) = ((l_1649 = &l_1633) == (l_1650 = l_1650));
                        ++l_1653;
                        (*g_1081) = (void*)0;
                    }
                    else
                    { /* block id: 749 */
                        (*l_1648) = (**g_1081);
                    }
                    (*l_1648) = (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*270*//* ___SAFE__OP */((((**g_1197) = ((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*271*//* ___SAFE__OP */(((void*)0 != g_1660), 0x15L)) && ((((*g_889) != l_1664[0][1]) || (-3L)) , (((((p_32 , (void*)0) == l_1667) , 0xC3BAL) == p_32) == 0x22L)))) , p_33), p_33));
                    if ((l_1601 = (safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*272*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*273*//* ___SAFE__OP */(l_1672, (((~(((*g_384) |= ((g_949[0] = ((7UL == (((l_1674 == (void*)0) ^ (p_30 , ((*l_1648) = (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*274*//* ___SAFE__OP */((*l_1647), (l_1678[0][0] = l_1677[0][2])))))) ^ ((*l_1679) = (p_32 < ((((void*)0 == p_31) & p_32) , p_30))))) < l_1672)) | p_33)) | g_282)) != p_30) , 1L))), g_408[2]))))
                    { /* block id: 760 */
                        int8_t l_1692;
                        int32_t **l_1696;
                        int32_t **l_1697;
                        (*l_1697) = ((*l_1696) = ((*g_1081) = (*g_1081)));
                        return p_32;
                    }
                    else
                    { /* block id: 772 */
                        int16_t ***l_1702;
                        int32_t l_1714;
                        int32_t *** const *l_1736;
                        int32_t *** const **l_1735;
                        int32_t *l_1743;
                        l_1672 &= ((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*275*//* ___SAFE__OP */((((*l_1702) = (((void*)0 != l_1700) , l_1701)) == (l_1726 = ((~((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*276*//* ___SAFE__OP */((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*277*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*278*//* ___SAFE__OP */(((((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*279*//* ___SAFE__OP */(((*l_1647) != (**g_1197)), (*l_1647))) != (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*280*//* ___SAFE__OP */((0UL | l_1714), (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*281*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*282*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*283*//* ___SAFE__OP */((l_1725 = (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*284*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*285*//* ___SAFE__OP */(l_1714, (*g_707))), g_435))), 0xB8L)), 57)), p_30))))) > (*l_1648)) == p_32), (-1L))), (*l_1648))), (-2L))) ^ p_32)) , &g_880[0]))), g_533)) & 0xEF9EFA40L);
                        g_691 = ((*g_1081) = l_1727);
                        (*g_889) = (((*l_1743) = (((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*286*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*287*//* ___SAFE__OP */((*g_384), (((0x6780C653L & ((*l_1600) = ((g_1732 = g_1732) == l_1735))) , (l_1737 == (*g_226))) >= l_1695))) | (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*288*//* ___SAFE__OP */(((*l_1647) = (l_1740 > (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*289*//* ___SAFE__OP */(p_30, (*l_1647))))), 59))), p_30)) ^ 0UL) , p_30)) , l_1744);
                    }
                }
                l_1745 = &l_1652[0][0][0];
            }
        }
        else
        { /* block id: 788 */
            int32_t *l_1746;
            l_1648 = (l_1727 = ((*g_1081) = l_1746));
            for (g_676 = 0; (g_676 <= (-21)); g_676 = safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*290*//* ___SAFE__OP */(g_676, 2))
            { /* block id: 794 */
                return (*l_1648);
            }
            l_1749 ^= ((*l_1727) = p_33);
        }
        for (g_1132 = 0; (g_1132 <= 0); g_1132 += 1)
        { /* block id: 803 */
            int8_t *l_1756;
            int8_t **l_1755;
            int32_t l_1761 = (-9L);
            uint32_t **l_1762;
            int i;
            (*g_1663) = (*g_1663);
            if (p_32)
                continue;
            (*g_1663) = ((*g_707) , (*g_1663));
        }
    }
    for (g_307 = 0; (g_307 <= 0); g_307 += 1)
    { /* block id: 817 */
        uint16_t l_1763;
        uint32_t **l_1768;
        uint32_t ***l_1770[7][10][3] = {{{&g_721[4][1][0],&l_1768,&l_1769},{&g_721[2][3][0],&l_1768,&l_1769},{&l_1768,&g_721[4][1][0],&g_721[4][1][0]},{&l_1768,&l_1769,&l_1769},{&g_721[3][5][1],&l_1769,&l_1769},{&g_721[4][1][0],&l_1768,(void*)0},{(void*)0,&g_721[4][1][0],&l_1768},{&l_1769,&l_1768,&g_721[5][4][1]},{&l_1769,&l_1769,&l_1768},{&l_1769,&l_1769,&l_1769}},{{&g_721[4][1][0],&g_721[4][1][0],&l_1768},{&l_1769,&l_1768,&g_721[4][1][0]},{&l_1769,&l_1768,&g_721[4][1][0]},{(void*)0,&g_721[8][4][1],&g_721[4][1][0]},{(void*)0,&l_1769,&g_721[4][1][0]},{&g_721[5][4][1],&g_721[4][1][0],&g_721[4][1][0]},{&g_721[3][5][1],&l_1769,&l_1768},{&l_1769,&g_721[4][1][0],&l_1769},{&l_1768,&l_1769,&l_1768},{&g_721[4][1][0],&g_721[4][1][0],&g_721[5][4][1]}},{{&g_721[4][1][0],&l_1769,&l_1768},{&g_721[4][1][0],&g_721[8][4][1],(void*)0},{&g_721[4][1][0],&l_1768,&g_721[6][4][0]},{&g_721[4][1][0],&g_721[8][4][1],&g_721[5][4][1]},{&g_721[4][1][0],&g_721[4][1][0],&g_721[4][1][0]},{&l_1769,&g_721[4][1][0],&g_721[4][1][0]},{(void*)0,&g_721[4][1][0],&g_721[6][4][0]},{&l_1768,&l_1768,&l_1769},{&l_1769,&l_1769,&l_1769},{&g_721[4][1][0],&l_1768,&l_1769}},{{&g_721[4][1][0],&g_721[4][1][0],&l_1768},{&g_721[5][4][1],&g_721[4][1][0],&l_1769},{&l_1768,&g_721[4][1][0],&g_721[4][1][0]},{&g_721[4][1][0],&g_721[8][4][1],&g_721[4][1][0]},{&g_721[4][1][0],&g_721[4][1][0],&l_1768},{&l_1769,&g_721[4][1][0],(void*)0},{&l_1769,&g_721[6][4][0],&l_1768},{&l_1769,&l_1768,&g_721[4][1][0]},{(void*)0,&l_1768,&g_721[4][1][0]},{&l_1769,&g_721[4][4][0],&l_1769}},{{&g_721[4][1][0],&l_1768,&l_1768},{&g_721[4][1][0],&l_1768,&l_1769},{&g_721[3][5][1],&g_721[4][1][0],&l_1769},{(void*)0,&g_721[4][1][0],&l_1769},{&g_721[3][5][1],&g_721[4][1][0],&g_721[6][4][0]},{&g_721[4][1][0],&g_721[8][4][1],&g_721[4][1][0]},{&g_721[4][1][0],&l_1768,&g_721[4][1][0]},{&l_1769,&g_721[4][1][0],&g_721[5][4][1]},{(void*)0,&g_721[4][1][0],&g_721[6][4][0]},{&l_1769,&l_1768,&g_721[4][1][0]}},{{&l_1769,&g_721[4][2][0],&l_1769},{&l_1769,&l_1768,&l_1768},{&g_721[4][1][0],&g_721[4][1][0],&l_1768},{&g_721[4][1][0],&g_721[4][1][0],&l_1769},{&l_1768,&l_1768,&g_721[4][1][0]},{&g_721[5][4][1],&g_721[8][4][1],&g_721[4][1][0]},{&g_721[4][1][0],&g_721[4][1][0],&l_1768},{&g_721[4][1][0],&g_721[4][1][0],&g_721[4][1][0]},{&l_1769,&g_721[4][1][0],&l_1768},{&l_1768,&l_1768,&g_721[4][1][0]}},{{(void*)0,&l_1768,&g_721[4][1][0]},{&l_1769,&g_721[4][4][0],&l_1769},{&g_721[4][1][0],&l_1768,&l_1768},{&g_721[4][1][0],&l_1768,&l_1768},{&g_721[3][5][1],&g_721[6][4][0],&l_1769},{&g_721[4][1][0],&g_721[4][1][0],&g_721[4][1][0]},{&g_721[3][5][1],&g_721[4][1][0],&g_721[6][4][0]},{&g_721[4][1][0],&g_721[8][4][1],&g_721[5][4][1]},{&g_721[4][1][0],&g_721[4][1][0],&g_721[4][1][0]},{&l_1769,&g_721[4][1][0],&g_721[4][1][0]}}};
        int32_t l_1796;
        int32_t l_1797;
        int16_t ***l_1799;
        int16_t ***l_1800;
        int16_t ***l_1801;
        int16_t ***l_1802[10][9][2] = {{{&g_1798[8],&g_1798[1]},{&g_1798[0],&g_1798[1]},{(void*)0,&g_1798[0]},{&g_1798[1],&g_1798[1]},{&g_1798[1],&g_1798[0]},{(void*)0,&g_1798[1]},{&g_1798[0],&g_1798[1]},{&g_1798[8],&g_1798[4]},{&g_1798[1],&g_1798[8]}},{{&g_1798[8],&g_1798[8]},{&g_1798[1],&g_1798[4]},{&g_1798[8],&g_1798[1]},{&g_1798[0],&g_1798[1]},{(void*)0,&g_1798[0]},{&g_1798[1],&g_1798[1]},{&g_1798[1],&g_1798[0]},{(void*)0,&g_1798[1]},{&g_1798[0],&g_1798[1]}},{{&g_1798[8],&g_1798[4]},{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[8]},{&g_1798[1],&g_1798[4]},{&g_1798[8],&g_1798[1]},{&g_1798[0],&g_1798[1]},{&g_1798[8],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[4],&g_1798[1]}},{{&g_1798[8],&g_1798[8]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]},{&g_1798[8],(void*)0},{(void*)0,(void*)0},{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[1]}},{{&g_1798[4],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[8],&g_1798[8]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]},{&g_1798[8],(void*)0},{(void*)0,(void*)0},{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0}},{{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[8],&g_1798[8]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]},{&g_1798[8],(void*)0},{(void*)0,(void*)0}},{{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[8],&g_1798[8]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]}},{{&g_1798[8],(void*)0},{(void*)0,(void*)0},{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[4],&g_1798[1]},{&g_1798[8],&g_1798[8]}},{{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]},{&g_1798[8],(void*)0},{(void*)0,(void*)0},{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[8]},{&g_1798[8],&g_1798[1]},{&g_1798[4],&g_1798[1]}},{{&g_1798[4],&g_1798[1]},{&g_1798[8],&g_1798[8]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[1]},{&g_1798[8],(void*)0},{(void*)0,(void*)0},{&g_1798[8],&g_1798[1]},{&g_1798[1],(void*)0},{&g_1798[1],&g_1798[8]}}};
        int32_t l_1812 = 4L;
        int i, j, k;
        l_1763++;
        l_1797 = ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*291*//* ___SAFE__OP */(((l_1768 == (g_721[4][1][0] = l_1769)) < ((*l_1397) = ((((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*292*//* ___SAFE__OP */(((l_1763 && l_1763) , p_33), 6)) , (((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*293*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*294*//* ___SAFE__OP */((((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*295*//* ___SAFE__OP */((l_1796 = ((((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*296*//* ___SAFE__OP */((p_32 >= (((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*297*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*298*//* ___SAFE__OP */((p_33 & (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*299*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*300*//* ___SAFE__OP */((p_33 | (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*301*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*302*//* ___SAFE__OP */((((!(l_1795 || (**g_1197))) == l_1763) | l_1763), 0x2CE162E9L)), g_1586))), p_32)), 0x5BF4L))), (*p_34))) ^ p_33))) , p_32) > (*p_34))), p_32)) && 18446744073709551611UL) | 0x1A134EF5L) || 0x10B134FEL)), 0x9BC5EF1AL)) , 0xA5L) && (-1L)), l_1763)), 0L)) , 1L) , 1UL)) >= p_33) && 0L))), p_33)) > p_33);
        (*g_1081) = (g_88 , &l_1796);
    }
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_35(int16_t * p_36)
{ /* block id: 552 */
    uint64_t l_1287;
    uint8_t l_1310;
    int32_t ** const l_1321 = &g_260;
    int32_t ** const *l_1320 = &l_1321;
    int32_t ** const **l_1319[4][9][7];
    int32_t ** const ***l_1318 = &l_1319[2][7][2];
    int32_t *l_1324[2][5][3];
    int32_t l_1337;
    uint32_t l_1344;
    int8_t l_1367 = 0L;
    uint64_t l_1379;
    int i, j, k;
    return l_1379;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t * func_37(int32_t  p_38, int16_t * const  p_39, int16_t * p_40, int64_t  p_41)
{ /* block id: 6 */
    int64_t l_73;
    uint8_t * const *l_749;
    uint8_t * const **l_748;
    int32_t l_752;
    int32_t *l_1203;
    uint32_t l_1213;
    uint32_t ***l_1234;
    int64_t l_1238[8][7][1] = {{{0L},{0x3A2A987C5604226BLL},{0x971BB441E0CD38B8LL},{1L},{0x6A18B78D9E0FF1CCLL},{0L},{0L}},{{0x6A18B78D9E0FF1CCLL},{1L},{0x971BB441E0CD38B8LL},{0x3A2A987C5604226BLL},{0L},{0x971BB441E0CD38B8LL},{0xDD351D67A530A767LL}},{{0x971BB441E0CD38B8LL},{0L},{0x3A2A987C5604226BLL},{0x971BB441E0CD38B8LL},{1L},{0x6A18B78D9E0FF1CCLL},{0L}},{{0L},{0x6A18B78D9E0FF1CCLL},{1L},{0x971BB441E0CD38B8LL},{0x3A2A987C5604226BLL},{0L},{0x971BB441E0CD38B8LL}},{{0xDD351D67A530A767LL},{0x971BB441E0CD38B8LL},{0L},{0x3A2A987C5604226BLL},{0x971BB441E0CD38B8LL},{1L},{0x6A18B78D9E0FF1CCLL}},{{0L},{0L},{0x6A18B78D9E0FF1CCLL},{1L},{0x971BB441E0CD38B8LL},{0x3A2A987C5604226BLL},{0L}},{{0x971BB441E0CD38B8LL},{0xDD351D67A530A767LL},{0x971BB441E0CD38B8LL},{0L},{0x3A2A987C5604226BLL},{0x971BB441E0CD38B8LL},{1L}},{{0x6A18B78D9E0FF1CCLL},{0L},{0L},{0x6A18B78D9E0FF1CCLL},{1L},{0x971BB441E0CD38B8LL},{0x3A2A987C5604226BLL}}};
    int32_t l_1247;
    int32_t l_1262;
    int32_t l_1263 = 0x5815F858L;
    int16_t *l_1286;
    int i, j, k;
    return l_1286;
}


/* ------------------------------------------ */
/* 
 * reads : g_707 g_614 g_688 g_766 g_53 g_309 g_59 g_55 g_384 g_329 g_533 g_115 g_560 g_325 g_326 g_461 g_679 g_296 g_96 g_281 g_307 g_949 g_282 g_956 g_978 g_1039 g_51 g_955 g_681 g_162 g_336 g_1134 g_1081 g_435 g_333
 * writes: g_614 g_683 g_737 g_296 g_307 g_55 g_329 g_53 g_691 g_560 g_88 g_230 g_461 g_281 g_51 g_919 g_282 g_956 g_949 g_978 g_687 g_688 g_955 g_1039 g_1081 g_1134
 */
static uint8_t  func_61(uint8_t  p_62, uint64_t  p_63, int16_t * p_64)
{ /* block id: 290 */
    int32_t l_761;
    uint64_t l_767 = 0xDF965B165BED2329LL;
    uint32_t *l_768[10][6];
    int32_t l_769;
    int32_t l_770[10];
    uint16_t l_771 = 0UL;
    uint8_t *l_778;
    uint16_t *l_779 = &l_771;
    int64_t *l_780;
    uint32_t ***l_803;
    uint64_t l_804;
    int32_t *l_805;
    uint64_t *l_806 = &g_329;
    uint16_t l_807 = 7UL;
    int64_t l_841;
    int32_t **l_846[2][4][5];
    int32_t ***l_845;
    int32_t ****l_844[3][8] = {{&l_845,&l_845,&l_845,&l_845,&l_845,&l_845,&l_845,&l_845},{(void*)0,&l_845,(void*)0,&l_845,&l_845,&l_845,&l_845,&l_845},{&l_845,&l_845,&l_845,&l_845,&l_845,(void*)0,&l_845,(void*)0}};
    int16_t *l_884;
    int32_t ***l_898[7][4][4];
    uint64_t l_928 = 6UL;
    int32_t l_954 = 0xEB7009EAL;
    uint32_t **l_1124;
    int32_t l_1200;
    int i, j, k;
    l_770[2] = (((*l_780) = (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*303*//* ___SAFE__OP */(((*g_707)--), ((g_296[0][9] = (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*304*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*305*//* ___SAFE__OP */(g_688, (l_761 <= ((((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*306*//* ___SAFE__OP */((p_62 >= (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*307*//* ___SAFE__OP */(((((void*)0 == g_766[1]) , 7UL) != l_767), (l_771++)))), ((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*308*//* ___SAFE__OP */(((g_737 = (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*309*//* ___SAFE__OP */(((*l_778) = (l_768[7][0] != (void*)0)), p_63))) || 65535UL), 7)) , 0x606C6648L))) , l_770[4]) , 0x833BL) > (*p_64))))), (-1L)))) , g_309[5])))) && g_59[0][7]);
    for (l_769 = 2; (l_769 <= 9); l_769 += 1)
    { /* block id: 300 */
        if (p_63)
            break;
        return p_62;
    }
    for (g_55 = 0; (g_55 <= 40); ++g_55)
    { /* block id: 306 */
        uint64_t *l_787;
        uint64_t *l_788;
        int32_t l_791[4];
        uint8_t **l_798;
        int32_t l_799[8][1][3];
        int32_t *l_800;
        int i, j, k;
        if (l_770[4])
            break;
        (*l_800) |= (l_799[0][0][1] = (((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*310*//* ___SAFE__OP */(((*g_384)++), ((*l_788) = p_63))) > ((*p_64) = (l_771 < ((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*311*//* ___SAFE__OP */((251UL < l_791[1]), 0x5133L)) != (0x3802423B6204B567LL <= ((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*312*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*313*//* ___SAFE__OP */(l_770[4], (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*314*//* ___SAFE__OP */((((&g_707 == l_798) , p_63) || l_791[0]), (-3L))))), l_791[1])) || (*g_707))))))) , 0L));
        (*l_800) &= (-10L);
    }
    if ((((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*315*//* ___SAFE__OP */((l_803 == l_803), (((*l_805) ^= l_804) >= l_769))) , l_806) != (l_807 , &g_329)))
    { /* block id: 316 */
        return p_63;
    }
    else
    { /* block id: 318 */
        int32_t *l_808 = &l_770[9];
        const int16_t l_809 = 0x90FCL;
        uint64_t l_866[5][10];
        int16_t *l_876;
        uint8_t ****l_893;
        uint32_t l_915;
        int32_t l_927;
        int32_t ***l_935[2][8][1];
        uint32_t l_939 = 0x57E45E76L;
        int32_t l_943;
        int32_t l_944;
        int32_t l_945;
        uint64_t * const *l_1196[7][3];
        int i, j, k;
        (*l_805) |= 0xBBBB0B33L;
        l_808 = &l_761;
        if (l_809)
        { /* block id: 321 */
            int32_t l_818;
            uint8_t ***l_888;
            uint8_t ****l_887;
            int32_t ** const *l_897;
            uint32_t l_913[2];
            int32_t l_921;
            int32_t l_922;
            int32_t l_925;
            int64_t **l_964[3][4];
            int64_t ***l_963 = &l_964[2][1];
            int8_t *l_965 = &g_949[0];
            int32_t *l_1002;
            int32_t l_1130[10];
            int8_t l_1131;
            int i, j;
            for (i = 0; i < 2; i++)
                l_913[i] = 0UL;
            if (((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*316*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*317*//* ___SAFE__OP */((&g_227 != ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*318*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*319*//* ___SAFE__OP */((l_818 & (((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*320*//* ___SAFE__OP */(0x3E6FL, (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*321*//* ___SAFE__OP */(((((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*322*//* ___SAFE__OP */((~(p_63 = ((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*323*//* ___SAFE__OP */(p_63, (*l_808))) <= 0x47BF3ADEBBA0BB51LL))), ((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*324*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*325*//* ___SAFE__OP */(((*g_384) = (safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*326*//* ___SAFE__OP */((((l_818 < (*l_808)) , (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*327*//* ___SAFE__OP */(((((-1L) | (*l_805)) & 0x2D8FL) ^ 18446744073709551611UL), g_533))) , g_55), (*g_384)))), g_115)), (*l_805))) == 0x9160619AL))) <= 0x95FDA6C1888BB591LL) & 255UL) >= (*l_808)), 1UL)))) | 1UL) | 0x93D96A8B81D8FD53LL)), (*l_808))), (*l_805))) , (void*)0)), p_62)) || p_63), 18446744073709551609UL)) , p_62))
            { /* block id: 324 */
                int32_t **l_836;
                int32_t **l_837;
                (*l_837) = (void*)0;
            }
            else
            { /* block id: 326 */
                int32_t ***l_849[6][5] = {{&l_846[1][3][3],&l_846[1][3][3],&l_846[1][0][2],&l_846[1][0][2],&l_846[1][3][3]},{&l_846[0][0][0],&l_846[0][3][0],&l_846[0][0][0],&l_846[0][3][0],&l_846[0][0][0]},{&l_846[1][3][3],&l_846[1][0][2],&l_846[1][0][2],&l_846[1][3][3],&l_846[1][3][3]},{(void*)0,&l_846[0][3][0],(void*)0,&l_846[0][3][0],(void*)0},{&l_846[1][3][3],&l_846[1][3][3],&l_846[1][0][2],&l_846[1][0][2],&l_846[1][3][3]},{&l_846[0][0][0],&l_846[0][3][0],&l_846[0][0][0],&l_846[0][3][0],&l_846[0][0][0]}};
                uint8_t ** const *l_856[5];
                int32_t l_909;
                int32_t **l_912;
                int32_t ***l_911[5];
                int32_t *****l_917 = &l_844[1][3];
                int i, j;
                for (i = 0; i < 5; i++)
                    l_911[i] = &l_912;
                for (g_560 = 0; (g_560 <= 3); g_560 += 1)
                { /* block id: 329 */
                    uint32_t l_862[8][2];
                    int8_t *l_910;
                    int64_t *l_914;
                    uint16_t *l_918;
                    int32_t l_942;
                    uint16_t l_946[3][6][10] = {{{65535UL,4UL,7UL,6UL,7UL,4UL,65535UL,0x24DDL,0xC7D8L,0x0093L},{0xAC69L,0x818AL,1UL,0UL,6UL,0x0093L,0x19FAL,65526UL,2UL,0x24DDL},{4UL,0x818AL,0x0093L,65535UL,65528UL,65528UL,65535UL,0x0093L,0x818AL,4UL},{0xC7D8L,4UL,0x9FA6L,0xAC69L,65526UL,65535UL,8UL,0UL,0x19FAL,6UL},{0x9FA6L,0x5DACL,0UL,4UL,65526UL,0x818AL,2UL,0x818AL,65526UL,4UL},{65526UL,8UL,65526UL,0xC7D8L,65528UL,0xAC69L,6UL,0UL,7UL,0x24DDL}},{{8UL,65528UL,2UL,0x9FA6L,6UL,1UL,0x0093L,0UL,0UL,0x0093L},{0x19FAL,7UL,65526UL,65526UL,7UL,0x19FAL,0UL,0x818AL,0xE62CL,2UL},{0x5DACL,1UL,0UL,8UL,0UL,7UL,1UL,0UL,65535UL,0x9FA6L},{0x5DACL,0x0093L,0x9FA6L,0x19FAL,4UL,0x19FAL,0x9FA6L,0x0093L,0x5DACL,0xE62CL},{0x19FAL,0x9FA6L,0x0093L,0x5DACL,0xE62CL,1UL,65528UL,65526UL,0x24DDL,0UL},{8UL,0UL,1UL,0x5DACL,0x24DDL,0xAC69L,0xAC69L,0x24DDL,0x5DACL,1UL}},{{65526UL,65526UL,7UL,0x19FAL,0UL,0x818AL,0xE62CL,2UL,65535UL,0xC7D8L},{0x9FA6L,2UL,65528UL,8UL,0xAC69L,65535UL,0xE62CL,0x19FAL,0xE62CL,65535UL},{0x818AL,0x24DDL,1UL,0x24DDL,0x818AL,7UL,0x9FA6L,1UL,0x19FAL,2UL},{8UL,0x19FAL,0xAC69L,0xC7D8L,1UL,65528UL,7UL,0x5DACL,2UL,2UL},{0x9FA6L,0xC7D8L,8UL,0x818AL,0x818AL,8UL,0xC7D8L,0x9FA6L,0x24DDL,1UL},{1UL,65528UL,0x0093L,8UL,0x9FA6L,0x5DACL,0UL,4UL,65526UL,0x818AL}}};
                    int i, j, k;
                    for (g_88 = 3; (g_88 >= 0); g_88 -= 1)
                    { /* block id: 332 */
                        uint8_t **l_838;
                        (*l_805) = (((*l_838) = (void*)0) != (void*)0);
                        return l_818;
                    }
                    if (((*l_808) = ((((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*328*//* ___SAFE__OP */(l_841, 9)) & (p_62 || ((*l_808) ^ ((++(*l_779)) < ((*p_64) = 3L))))) , (2UL >= ((void*)0 != l_844[1][6]))) >= (safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*329*//* ___SAFE__OP */(((*l_808) || ((g_230[5][3][1] = (p_63 > 0UL)) || 0x48L)))))))
                    { /* block id: 341 */
                        int32_t **l_848 = &l_805;
                        (*l_848) = (*g_325);
                        return p_63;
                    }
                    else
                    { /* block id: 344 */
                        int32_t **l_850;
                        uint8_t ** const **l_857;
                        uint32_t *l_860;
                        uint32_t **l_861;
                        int16_t **l_877;
                        int16_t **l_878;
                        int16_t **l_879;
                        int16_t **l_881 = &g_880[0];
                        int16_t **l_882;
                        int16_t **l_883;
                        uint8_t *****l_891;
                        uint8_t *****l_892 = (void*)0;
                        int8_t *l_894;
                        (*l_850) = ((*l_805) , &l_761);
                        (*g_461) = (+p_62);
                        (*l_808) ^= ((g_679 < (safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*330*//* ___SAFE__OP */((((*l_780) = g_296[0][2]) , (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*331*//* ___SAFE__OP */((((*l_857) = l_856[2]) == (void*)0), (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*332*//* ___SAFE__OP */((p_62 , ((((*l_861) = l_860) != (l_862[1][1] , &l_862[1][1])) != p_62)), p_62))))), 4))) ^ l_818);
                        (*l_850) = &l_770[4];
                    }
                    if (((((*l_914) = ((*l_780) &= (+(((((g_309[1] ^ (((1UL & (((~0x85L) , ((((l_897 != l_898[0][2][0]) , (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*333*//* ___SAFE__OP */(((((((g_296[1][6] < (safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*334*//* ___SAFE__OP */(l_862[5][0], 6))) & ((*l_910) |= ((((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*335*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*336*//* ___SAFE__OP */(l_862[1][0], (((*l_808) = (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*337*//* ___SAFE__OP */(((*l_805) = 4294967295UL), l_909))) | p_63))), p_62)) , (*p_64)) , (*p_64)) > g_96))) , (void*)0) == l_911[2]) <= (-1L)) >= (*p_64)), 0xE0224F56L))) ^ 65531UL) >= (-1L))) , 0x38L)) == 5UL) , 0xD4L)) ^ p_63) , l_913[1]) < l_913[0]) , (*p_64))))) != l_915) > (-1L)))
                    { /* block id: 367 */
                        return l_913[1];
                    }
                    else
                    { /* block id: 369 */
                        int64_t l_916;
                        int32_t ***** const l_920 = &l_844[1][6];
                        int32_t l_923;
                        int32_t l_924;
                        (*l_805) |= (l_913[1] , l_916);
                        (*l_805) = p_62;
                        (*l_808) ^= (l_917 != (((g_919[1][2][0] = l_918) != (void*)0) , l_920));
                        ++l_928;
                    }
                    if (((((safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*338*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*339*//* ___SAFE__OP */(((void*)0 == l_876), ((*l_805) > ((p_62 , ((void*)0 != l_935[1][3][0])) == (!(*l_805)))))), ((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*340*//* ___SAFE__OP */(((((p_63 > ((p_62 > (*l_808)) , (*g_384))) != p_62) ^ p_63) <= l_939), p_62)) & 0x57L))) , l_862[1][1]) || 0L) , (*g_461)))
                    { /* block id: 376 */
                        (*g_461) = (*l_808);
                        if (p_62)
                            break;
                        l_922 ^= (*g_461);
                    }
                    else
                    { /* block id: 380 */
                        int32_t l_940;
                        int32_t l_941;
                        l_946[0][0][5]--;
                        return g_949[0];
                    }
                    for (p_62 = 0; (p_62 <= 3); p_62 += 1)
                    { /* block id: 386 */
                        return (*l_808);
                    }
                }
                return p_62;
            }
            for (g_282 = 0; (g_282 == 25); g_282++)
            { /* block id: 394 */
                int32_t *l_952;
                int32_t *l_953[10];
                int i;
                g_956++;
            }
            if (((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*341*//* ___SAFE__OP */((*l_805), (((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*342*//* ___SAFE__OP */(((((*l_963) = &l_780) == (((void*)0 != l_935[1][3][0]) , &g_227)) , ((*l_965) &= (-3L))), ((((*l_808) = 0xC6497B49L) && (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*343*//* ___SAFE__OP */(((+0x8740ECCFL) || (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*344*//* ___SAFE__OP */((*p_64), l_925))), 0x909EL))) , p_62))) <= (*g_384)) | (*l_805)))) <= 1L))
            { /* block id: 400 */
                int32_t *l_971;
                int32_t *l_972;
                int32_t *l_973;
                int32_t *l_974 = &l_925;
                int32_t *l_975;
                int32_t *l_976[7][10];
                int i, j;
                g_978--;
            }
            else
            { /* block id: 402 */
                const int32_t l_983 = 0x8F094A09L;
                uint16_t *l_992;
                uint16_t *l_993 = &g_737;
                int32_t l_996 = 0x51B4118AL;
                if ((l_925 = ((&p_62 != ((((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*345*//* ___SAFE__OP */(((*l_876) = (l_921 &= (l_983 <= (*g_707)))), l_983)) && (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*346*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*347*//* ___SAFE__OP */((((*l_845) = (*l_845)) != (void*)0), (((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*348*//* ___SAFE__OP */(((*l_993) = ((*l_992) = ((*l_779)++))), (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*349*//* ___SAFE__OP */((p_63 < ((l_996 &= ((*l_805) = ((*l_808) = 0xBCEBAD95L))) != 0x5EAEBEB3L)), l_983)))) ^ 3L) , p_63))), 8UL))) ^ 0x44L) , &p_62)) || 1UL)))
                { /* block id: 413 */
                    int32_t **l_1001 = (void*)0;
                    for (g_688 = 16; (g_688 > 39); g_688 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*350*//* ___SAFE__OP */(g_688, 2))
                    { /* block id: 416 */
                        int32_t *l_999;
                        int32_t **l_1000;
                        (*l_1000) = l_999;
                        (*l_808) |= l_983;
                        if ((*l_805))
                            continue;
                        if (p_62)
                            continue;
                    }
                    l_1002 = &l_943;
                    return l_983;
                }
                else
                { /* block id: 424 */
                    int16_t l_1026;
                    uint64_t *l_1031;
                    int32_t l_1035;
                    int32_t l_1036;
                    int32_t l_1037;
                    int32_t **l_1061[9];
                    int i;
                    if (((*g_384) , ((safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*351*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*352*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*353*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*354*//* ___SAFE__OP */((*g_384), (p_63 == (safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*355*//* ___SAFE__OP */(p_62, 12))))), (((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*356*//* ___SAFE__OP */(((*l_1031) = (((*l_805) = (!p_62)) & (+(safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*357*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*358*//* ___SAFE__OP */(((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*359*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*360*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*361*//* ___SAFE__OP */((((***l_963) &= l_1026) != (l_996 ^= (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*362*//* ___SAFE__OP */((l_1026 >= (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*363*//* ___SAFE__OP */((((0x091440DD70A836E0LL != (g_955[6] = ((((p_62 <= 0x59DEL) , (void*)0) != &g_737) , 0x02574CD8571B6259LL))) , (*p_64)) < (*l_808)), (-2L)))), (*g_384))))), (-3L))), l_954)), p_63)) > (*l_808)), p_63)), 1L))))), 8)) == l_1026) <= l_983))) > (*p_64)), 0xDCL)))) , p_62)))
                    { /* block id: 430 */
                        int32_t *l_1032 = &l_954;
                        int32_t *l_1033[5][5];
                        int i, j;
                        for (i = 0; i < 5; i++)
                        {
                            for (j = 0; j < 5; j++)
                                l_1033[i][j] = &l_769;
                        }
                        --g_1039;
                        (*l_808) |= (((*l_1002) || p_62) && l_996);
                    }
                    else
                    { /* block id: 433 */
                        (*l_805) ^= (-1L);
                    }
                    g_691 = ((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*364*//* ___SAFE__OP */(((*l_965) |= ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*365*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*366*//* ___SAFE__OP */((1UL && ((*g_384) & ((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*367*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*368*//* ___SAFE__OP */(0x27L, (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*369*//* ___SAFE__OP */(((g_307 | (safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*370*//* ___SAFE__OP */(((((*l_805) > ((~(((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*371*//* ___SAFE__OP */((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*372*//* ___SAFE__OP */(g_51, p_63)), 0x15A6EFB2L)) , (0xD097L < 0x4A4BL)) | p_62)) != 0x3860L)) >= (*l_1002)) && 0UL), 1))) , p_62), 0L)))) < p_62), 4294967295UL)) >= p_63))), 0x4E12CD85L)), 0x2A9AB1CD94B0C695LL)) & g_955[6])), 0x08L)) , (void*)0);
                }
            }
            for (l_928 = (-7); (l_928 != 58); ++l_928)
            { /* block id: 442 */
                uint32_t l_1090[2];
                int32_t *l_1137;
                int32_t ***l_1159;
                int32_t ****l_1158;
                int32_t l_1171 = 0xE9F52A6CL;
                int32_t ** const ** const l_1199 = &l_897;
                int i;
                for (i = 0; i < 2; i++)
                    l_1090[i] = 0UL;
                if (((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*373*//* ___SAFE__OP */(p_62, 1UL)) != 4UL))
                { /* block id: 443 */
                    uint32_t l_1078 = 3UL;
                    int32_t **l_1080;
                    int32_t ***l_1079;
                    uint64_t *l_1089[10];
                    int i;
                    for (i = 0; i < 10; i++)
                        l_1089[i] = &g_956;
                    (*l_805) = (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*374*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*375*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*376*//* ___SAFE__OP */(0x08C881F6D03A8AB7LL, 18)), (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*377*//* ___SAFE__OP */(((((((((p_62 == 0xDA76AB82L) <= ((*l_779) = ((((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*378*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*379*//* ___SAFE__OP */((((*g_707) = l_1078) <= ((((*l_1079) = &g_691) == (g_1081 = &l_808)) , (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*380*//* ___SAFE__OP */((+(((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*381*//* ___SAFE__OP */((*g_384), (0xC578AE9AL | (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*382*//* ___SAFE__OP */((p_63 = (g_329 || (*l_805))), (*l_808)))))) | 6UL) != (*l_1002))), g_96)))), (*l_805))), (*p_64))) , 0x94L) < g_681) < (*p_64)))) < 249UL) == 4294967292UL) >= l_1090[1]) < 9L) && p_62) && p_63), (*l_1002))))) <= g_162), (*g_384)));
                }
                else
                { /* block id: 450 */
                    int16_t ***l_1115;
                    int16_t ***l_1116;
                    int16_t **l_1118;
                    int16_t ***l_1117;
                    uint32_t ***l_1122;
                    uint32_t ***l_1123;
                    uint32_t *l_1125;
                    int32_t l_1133;
                    uint32_t l_1138;
                    int16_t l_1157;
                    if ((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*383*//* ___SAFE__OP */(g_336, (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*384*//* ___SAFE__OP */((*g_384), ((~((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*385*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*386*//* ___SAFE__OP */((*l_1002), (safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*387*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*388*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*389*//* ___SAFE__OP */((((*g_707) || ((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*390*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*391*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*392*//* ___SAFE__OP */(1L, 41)), (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*393*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*394*//* ___SAFE__OP */(((((*l_1117) = &g_880[1]) != &p_64) >= (((*l_1125) &= (~((*l_808) != ((l_1124 = &g_722) == (void*)0)))) , (*l_1002))), (-1L))), (-1L))))))) < (*g_707))) | (*p_64)), (*l_805))), 0x7747A35DL)), p_63)))), 1L)) && 1L)) & 7UL))))))
                    { /* block id: 454 */
                        int32_t *l_1126 = &l_922;
                        int32_t *l_1127;
                        int32_t *l_1128;
                        int32_t *l_1129[3][3][10];
                        int i, j, k;
                        (*l_1002) |= p_63;
                        ++g_1134;
                        l_1137 = (*g_1081);
                        (*l_1128) = ((l_1138 , (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*395*//* ___SAFE__OP */(((+((p_62 <= (((*l_805) & (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*396*//* ___SAFE__OP */((1L | g_435), ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*397*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*398*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*399*//* ___SAFE__OP */((((l_943 = ((((*l_808) = (((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*400*//* ___SAFE__OP */((0UL & 6UL), (*l_1127))) , (+(safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*401*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*402*//* ___SAFE__OP */((0x8F9C5944L ^ 0UL), p_62)), (*g_384))))) | (*l_1126))) == l_1157) , (-1L))) , (void*)0) == (void*)0), (*l_1002))), 32)), p_63)) & (*l_1128))))) , 0xADE22D22L)) & g_1134)) | p_62), l_1138))) > p_62);
                    }
                    else
                    { /* block id: 461 */
                        int32_t *****l_1160;
                        (*l_1160) = l_1158;
                    }
                }
                (*l_808) &= (*l_1002);
                for (g_307 = 0; (g_307 >= 0); g_307 -= 1)
                { /* block id: 468 */
                    uint16_t l_1172;
                }
                if (l_1200)
                    continue;
            }
        }
        else
        { /* block id: 488 */
            (*l_808) |= 0xC8584C25L;
        }
        for (l_928 = (-21); (l_928 <= 31); ++l_928)
        { /* block id: 493 */
            (*g_1081) = &l_944;
            if (p_63)
                break;
        }
    }
    return (*g_707);
}


/* ------------------------------------------ */
/* 
 * reads : g_55
 * writes:
 */
static int8_t  func_65(int8_t  p_66)
{ /* block id: 288 */
    return g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_333 g_325 g_326 g_680 g_195 g_461 g_679 g_737 g_707 g_614
 * writes: g_679 g_333 g_461 g_721 g_737
 */
static const uint8_t  func_69(int32_t * p_70)
{ /* block id: 267 */
    const uint32_t l_692 = 0xAC8CD26BL;
    int32_t l_693;
    uint8_t *l_705 = (void*)0;
    uint8_t ** const l_704 = &l_705;
    uint32_t *l_719 = (void*)0;
    uint32_t **l_718 = &l_719;
    int32_t l_725 = (-1L);
    uint32_t l_731 = 0xCC1A141EL;
    int32_t l_732;
    int32_t l_733[6][7];
    int32_t *l_734;
    int32_t *l_735;
    int32_t *l_736[1][5][7];
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
            l_733[i][j] = 0L;
    }
    l_693 |= (g_679 = (l_692 , l_692));
    for (g_333 = (-4); (g_333 != (-11)); g_333--)
    { /* block id: 272 */
        int32_t *l_696;
        int32_t **l_697;
        uint8_t ***l_708;
        uint64_t **l_711;
        uint32_t *l_714 = &g_282;
        int32_t **l_715;
        uint32_t ***l_720[6];
        uint32_t **l_723[4][7];
        int8_t *l_724[8][10];
        int i, j;
        for (i = 0; i < 6; i++)
            l_720[i] = &l_718;
        (*l_697) = l_696;
        (*l_715) = (*g_325);
        l_693 = ((*g_461) = (l_693 <= ((g_680 & ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*403*//* ___SAFE__OP */((((-2L) & (((l_725 = ((g_721[4][1][0] = l_718) != (l_723[0][4] = &g_722))) > ((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*404*//* ___SAFE__OP */(0UL, l_692)) < (~((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*405*//* ___SAFE__OP */((((((((l_693 < 0xBACA6208L) , &g_260) != (void*)0) != 0xB9ADL) <= 0x8EB3A8C486B5046BLL) > l_692) , 0xF5L), l_693)) , g_195)))) >= l_692)) | (**l_697)), l_693)) & l_692)) , l_731)));
        l_693 &= l_692;
    }
    g_737++;
    return (*g_707);
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_51 g_88 g_55 g_53 g_96 g_115 g_162 g_208 g_164 g_212 g_226 g_230 g_260 g_261 g_282 g_291 g_296 g_310 g_325 g_336 g_278 g_333 g_326 g_329 g_384 g_309 g_435 g_485 g_533 g_614 g_683 g_688
 * writes: g_88 g_96 g_115 g_164 g_208 g_212 g_230 g_282 g_296 g_310 g_325 g_51 g_336 g_260 g_59 g_329 g_384 g_55 g_435 g_195 g_532 g_461 g_683 g_688
 */
static int32_t * func_71(int64_t  p_72)
{ /* block id: 7 */
    uint32_t l_84;
    int32_t *l_87;
    int64_t *l_92;
    uint32_t l_93[10][8];
    int16_t *l_128;
    uint16_t *l_137[10];
    int32_t l_200;
    int32_t l_211 = (-7L);
    uint8_t l_215 = 0x74L;
    int32_t l_334;
    int32_t l_335;
    const int8_t l_523 = 0L;
    int32_t l_528;
    const int32_t ***l_571;
    const int32_t ****l_570;
    int32_t l_677;
    int32_t l_678;
    int i, j;
    if ((g_59[0][6] , 1L))
    { /* block id: 8 */
        const int16_t *l_89 = &g_59[0][7];
        int32_t l_90[9];
        int16_t *l_91;
        uint8_t *l_94 = (void*)0;
        uint8_t *l_95;
        int32_t **l_294;
        int32_t *l_330 = &l_90[7];
        const int16_t *l_366;
        int i;
        for (i = 0; i < 9; i++)
            l_90[i] = (-1L);
        (*l_87) = (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*406*//* ___SAFE__OP */(((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*407*//* ___SAFE__OP */((1L || ((((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*408*//* ___SAFE__OP */(((((((g_51 < (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*409*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*410*//* ___SAFE__OP */(((l_84 == (p_72 | l_84)) && ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*411*//* ___SAFE__OP */(((((l_87 != l_87) , (((((*l_87) , l_89) != l_89) <= 0x0ADFL) , 1L)) , 1UL) > 0xDEFDL), g_88)) == 0x6ED2L)), 65531UL)) && l_90[7]), g_55))) >= l_90[7]) , (*l_87)) <= 0x24A3AAF9L) & p_72) > 0xA751A550L), 2UL)) > (*l_87)) > (*l_87)) , p_72)), p_72)) , (-1L)) , (void*)0) != l_89), g_53));
        if ((((*l_95) = (((((l_91 != (void*)0) >= g_55) , l_92) != (void*)0) & l_93[9][7])) || (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*412*//* ___SAFE__OP */((((((*l_87) == ((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*413*//* ___SAFE__OP */((!(safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*414*//* ___SAFE__OP */(l_90[1], 4))), 0xE551B120L)) , (-1L))) < 4294967288UL) > (*l_87)) <= 0x20855C5DL), (*l_87)))))
        { /* block id: 11 */
            int64_t * const l_109 = (void*)0;
            int32_t l_112;
            uint16_t *l_113;
            uint16_t *l_114[6][7][6];
            uint16_t l_152;
            int32_t l_207;
            int32_t l_259;
            int32_t **l_355;
            uint32_t *l_356;
            uint8_t *l_357[9][9][2];
            int32_t l_392;
            int i, j, k;
            if ((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*415*//* ___SAFE__OP */((g_96 , ((*l_87) >= (18446744073709551615UL == ((+(0xD800L || (g_115 = (((l_90[2] , ((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*416*//* ___SAFE__OP */(((void*)0 != l_109), (g_55 , (safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*417*//* ___SAFE__OP */(l_90[6], 5))))) ^ 0xD993L)) >= l_112) != l_112)))) , 0xE0CC22E4BCF314C7LL)))), l_90[7])))
            { /* block id: 13 */
                int32_t *l_116 = &l_90[3];
                (*l_116) = ((*l_87) = g_51);
            }
            else
            { /* block id: 16 */
                int16_t *l_129;
                int64_t **l_140;
                int32_t l_141[9][8];
                int32_t *l_142;
                int32_t *l_222;
                int8_t *l_246;
                int i, j;
                if ((((l_90[3] ^= ((((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*418*//* ___SAFE__OP */(((+p_72) < (((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*419*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*420*//* ___SAFE__OP */(((((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*421*//* ___SAFE__OP */(((*l_87) = (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*422*//* ___SAFE__OP */(p_72, ((l_128 != l_129) , (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*423*//* ___SAFE__OP */((~(safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*424*//* ___SAFE__OP */(0x8F82D9EA51855DDALL, 32))), ((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*425*//* ___SAFE__OP */(g_51, ((l_137[4] = l_91) == ((safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*426*//* ___SAFE__OP */((((*l_140) = &g_51) != ((l_112 == p_72) , (void*)0)), 5)) , (void*)0)))) || g_51))))))), p_72)) & 0x92870E6FL) > l_141[1][4]) <= 1L), 0x6CL)), l_141[1][4])) <= p_72) ^ 0xFF3C4299L)), 3)) ^ p_72) != g_59[0][6]) , p_72)) , l_112) <= 0L))
                { /* block id: 21 */
                    uint16_t l_153 = 5UL;
                    int32_t *l_175;
                    int32_t *l_176;
                    int32_t *l_177;
                    int32_t *l_178;
                    int32_t *l_179 = &l_90[6];
                    int32_t *l_180;
                    int32_t *l_181;
                    int32_t *l_182;
                    int32_t *l_183;
                    int32_t *l_184;
                    int32_t *l_185 = &l_141[1][4];
                    int32_t *l_186;
                    int32_t *l_187 = &l_112;
                    int32_t *l_188;
                    int32_t *l_189;
                    int32_t *l_190 = &l_90[7];
                    int32_t *l_191;
                    int32_t *l_192;
                    int32_t l_193;
                    int32_t *l_194;
                    int32_t *l_196;
                    int32_t *l_197;
                    int32_t *l_198;
                    int32_t *l_199;
                    int32_t *l_201 = &l_90[7];
                    int32_t *l_202 = (void*)0;
                    int32_t *l_203;
                    int32_t *l_204;
                    int32_t l_205;
                    int32_t *l_206[7][7][5];
                    int i, j, k;
                    for (g_115 = 0; (g_115 <= 5); g_115 += 1)
                    { /* block id: 24 */
                        int8_t *l_163;
                        int8_t *l_165;
                        int8_t *l_166 = &g_164;
                        int8_t *l_167;
                        int8_t *l_168;
                        int8_t *l_169;
                        int8_t *l_170 = &g_164;
                        int8_t *l_171[1];
                        int32_t *l_172 = &l_141[1][1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_171[i] = &g_164;
                        (*l_172) |= ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*427*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*428*//* ___SAFE__OP */(((l_112 = ((*l_163) = ((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*429*//* ___SAFE__OP */((((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*430*//* ___SAFE__OP */(((+l_152) && (l_153 | (safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*431*//* ___SAFE__OP */((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*432*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*433*//* ___SAFE__OP */(p_72, g_59[0][3])) && (((0x70L <= 1L) ^ (!p_72)) != (!((p_72 , (*l_87)) >= 0x0A0F738818BC76B6LL)))), g_162)), g_88)))), p_72)) < p_72) >= p_72), p_72)) > l_112))) && (*l_87)), 11)), 3L)) ^ l_90[0]);
                        g_88 = ((*l_172) = (safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*434*//* ___SAFE__OP */(g_53, p_72)));
                    }
                    g_208--;
                    for (g_164 = 0; (g_164 <= 0); g_164 += 1)
                    { /* block id: 34 */
                        int32_t **l_223;
                        int8_t *l_229[9] = {&g_230[5][4][0],&g_230[5][4][0],&g_164,&g_230[5][4][0],&g_230[5][4][0],&g_164,&g_230[5][4][0],&g_230[5][4][0],&g_164};
                        uint8_t l_231 = 1UL;
                        uint32_t *l_232;
                        int i;
                        g_212++;
                        (*l_186) &= (l_215 != ((4UL || (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*435*//* ___SAFE__OP */((0x69L ^ (((l_137[(g_164 + 6)] == ((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*436*//* ___SAFE__OP */(((((((*l_223) = l_222) == &g_88) | (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*437*//* ___SAFE__OP */(g_212, (((*l_232) ^= ((p_72 && (l_231 ^= ((void*)0 != g_226))) <= 252UL)) <= g_55)))) , p_72) ^ 0UL), 0x0A1DD1C3DC9B2812LL)) , l_137[(g_164 + 6)])) || p_72) == (-2L))), (-3L)))) , 0xC4L));
                        if (l_90[8])
                            continue;
                    }
                }
                else
                { /* block id: 42 */
                    int32_t **l_233;
                    int32_t **l_234;
                    (*l_234) = &g_88;
                }
                if (((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*438*//* ___SAFE__OP */((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*439*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*440*//* ___SAFE__OP */(((~1UL) , ((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*441*//* ___SAFE__OP */(((l_90[0] | p_72) & (((g_115 = g_212) , (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*442*//* ___SAFE__OP */(((*l_246) = (~(-1L))), ((((void*)0 != (*l_140)) || l_207) || ((((++(*l_95)) || (safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*443*//* ___SAFE__OP */((&g_96 != (void*)0), (*l_222)))) & 6UL) , g_59[0][1]))))) != p_72)), p_72)) > p_72)))), l_152)), g_88)) & p_72))
                { /* block id: 48 */
                    int32_t * const l_251 = &g_88;
                    uint8_t l_274;
                    int32_t l_277;
                    int32_t l_279;
                    int32_t l_280;
                    if (g_59[0][6])
                    { /* block id: 49 */
                        int32_t **l_252 = &l_222;
                        int32_t l_273;
                        int32_t *l_275;
                        (*l_252) = l_251;
                        (*l_275) |= (safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*444*//* ___SAFE__OP */(0x333C25EC4CE350B0LL, (l_274 = ((g_230[5][4][0] ^ (((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*445*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*446*//* ___SAFE__OP */(l_259, ((*l_222) = ((void*)0 == g_260)))) , (((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*447*//* ___SAFE__OP */(l_90[7], ((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*448*//* ___SAFE__OP */(((*l_251) != ((g_261[0] & ((((((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*449*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*450*//* ___SAFE__OP */(((((!((((((g_164 <= (**l_252)) , g_55) , (*l_140)) != &p_72) != p_72) , 9UL)) != 0x980EBB6C139F92E5LL) , 0x11AC779DL) == (*l_222)), l_112)), p_72)) >= p_72) & g_230[2][8][1]) , l_273) | p_72) > p_72)) ^ l_112)), 3L)) != 1UL))) == 249UL) > p_72)), p_72)) | p_72) , (*l_87))) >= l_90[7]))));
                        return &g_88;
                    }
                    else
                    { /* block id: 55 */
                        int32_t *l_276[9][7];
                        int32_t ***l_295;
                        int i, j;
                        g_282--;
                        (*l_222) = (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*451*//* ___SAFE__OP */((((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*452*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*453*//* ___SAFE__OP */(((void*)0 != g_291), (0xFE1010FDL >= (((246UL < (p_72 < 0xA875L)) , (-8L)) , (((l_112 = (((((*l_295) = l_294) != &l_87) || 4UL) , 0xBDB5L)) ^ p_72) > 65529UL))))), g_115)) && 0x5450BA36C0485674LL) & l_90[7]), g_53));
                        g_296[1][6]--;
                    }
                    for (p_72 = 0; (p_72 == 19); p_72 = safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*454*//* ___SAFE__OP */(p_72, 4))
                    { /* block id: 64 */
                        int32_t *l_301;
                        int32_t *l_302 = &l_112;
                        int32_t *l_303 = &g_88;
                        int32_t *l_304;
                        int32_t *l_305;
                        int32_t *l_306;
                        int32_t *l_308[9];
                        uint64_t *l_327;
                        uint64_t *l_328[7];
                        int i;
                        --g_310;
                        (*l_306) = ((+g_261[3]) <= ((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*455*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*456*//* ___SAFE__OP */(((void*)0 == l_129), g_55)))) >= ((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*457*//* ___SAFE__OP */(((*l_95)++), p_72)) || (((*l_302) = (((*l_301) = (safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*458*//* ___SAFE__OP */((((&l_87 != (g_325 = g_325)) , (((*l_92) &= (((void*)0 != &l_274) ^ 1L)) || p_72)) , 0x230A18AAL), 5))) , 18446744073709551613UL)) | p_72))));
                    }
                    return l_330;
                }
                else
                { /* block id: 74 */
                    int32_t *l_331;
                    int32_t *l_332[6];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_332[i] = &l_141[1][4];
                    g_336++;
                }
                (*l_222) |= (g_115 <= p_72);
            }
            if ((((l_330 != &l_93[9][7]) <= ((*l_87) = ((*l_95)++))) <= ((((l_259 , (safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*459*//* ___SAFE__OP */(g_278[0][0][2], (9L | ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*460*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*461*//* ___SAFE__OP */((l_112 = (((((*l_128) = (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*462*//* ___SAFE__OP */((~l_207), (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*463*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*464*//* ___SAFE__OP */((+((((*l_330) = (((((*l_355) = l_330) != (void*)0) ^ p_72) != 5UL)) , (void*)0) != l_356)), 0xFFL)), 15))))) , 0x1D82569CL) && p_72) , p_72)), l_207)), 0x1FA1F5F7L)) | 0xBEL))))) || g_162) ^ g_55) , 65535UL)))
            { /* block id: 85 */
lbl_395:
                for (g_310 = (-23); (g_310 == 58); ++g_310)
                { /* block id: 88 */
                    return &g_88;
                }
            }
            else
            { /* block id: 91 */
                int32_t *l_370;
                int8_t *l_371;
                uint64_t *l_372;
                (*l_330) &= ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*465*//* ___SAFE__OP */(((((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*466*//* ___SAFE__OP */(((*l_372) |= (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*467*//* ___SAFE__OP */((l_207 || (l_89 == l_366)), ((((~g_333) < ((((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*468*//* ___SAFE__OP */((*l_87), ((g_208 , (*g_325)) != l_370))) , 0x528BL) ^ (*l_370)) , p_72)) , l_357[4][7][1]) != l_371)))), 13)) < g_164) <= 0xA89DACE0L) > 1L), p_72)) < p_72);
            }
            if (l_112)
            { /* block id: 95 */
                int32_t l_373;
                uint8_t *l_411;
                int32_t l_433;
                if ((l_373 ^ (g_208 != ((*l_87) > ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*469*//* ___SAFE__OP */(((((*l_330) |= p_72) || (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*470*//* ___SAFE__OP */(g_208, (+((8UL | ((*l_330) = (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*471*//* ___SAFE__OP */((((-4L) && p_72) , l_112), g_208)))) , g_212))))) , 0x454D5258L), p_72)) == 0xA3543B83L)))))
                { /* block id: 98 */
                    uint64_t *l_383;
                    uint64_t **l_382[5];
                    int i;
                    (*l_330) &= ((g_384 = ((safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*472*//* ___SAFE__OP */((*l_87))) , &g_329)) == (((((((l_373 <= p_72) <= (safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*473*//* ___SAFE__OP */((**l_294)))) < g_53) != (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*474*//* ___SAFE__OP */(l_373, (p_72 >= ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*475*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*476*//* ___SAFE__OP */(p_72, 0xF3L)), 4294967295UL)) || 0UL))))) & l_392) >= l_373) , l_109));
                    return &g_88;
                }
                else
                { /* block id: 102 */
                    int64_t l_396;
                    uint8_t *l_404;
                    const uint32_t *l_407 = &g_408[4];
                    const uint32_t **l_406;
                    uint8_t **l_410[2][7];
                    int32_t *l_412 = (void*)0;
                    int32_t l_413;
                    uint8_t l_423;
                    int32_t l_434;
                    int i, j;
                    for (l_211 = 0; (l_211 != 21); ++l_211)
                    { /* block id: 105 */
                        if (l_215)
                            goto lbl_395;
                        if (l_396)
                            break;
                    }
lbl_424:
                    l_413 = (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*477*//* ___SAFE__OP */((((*g_384)++) ^ (((~(safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*478*//* ___SAFE__OP */(g_309[6], 5))) , l_404) == (void*)0)), (safe_unary_minus_func_int32_t_s/* ___REMOVE_SAFE__OP *//*479*//* ___SAFE__OP */(((*l_330) = ((**l_294) = ((&g_55 == ((*l_406) = &l_93[7][4])) ^ (+((l_411 = l_357[0][5][0]) == &g_162)))))))));
                    if (((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*480*//* ___SAFE__OP */(l_259, 0L)) || ((((*l_356) ^= (*l_87)) > (l_423 = (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*481*//* ___SAFE__OP */(((((*l_87) < (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*482*//* ___SAFE__OP */(2UL, (-2L)))) , (((l_335 = (((*l_330) = (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*483*//* ___SAFE__OP */(l_112, (+0x973525537350418DLL)))) , (*l_87))) , 0x36L) != g_53)) , 0xB8L), p_72)))) ^ l_373)))
                    { /* block id: 119 */
                        return &l_207;
                    }
                    else
                    { /* block id: 121 */
                        int8_t l_425[7];
                        int32_t *l_426;
                        int32_t *l_427;
                        int32_t *l_428;
                        int32_t *l_429 = &l_373;
                        int32_t *l_430 = &l_207;
                        int32_t *l_431;
                        int32_t *l_432[10];
                        int i;
                        if (g_88)
                            goto lbl_424;
                        g_435--;
                    }
                }
                for (l_211 = 6; (l_211 >= 2); l_211 -= 1)
                { /* block id: 128 */
                    int32_t *l_438 = &l_433;
                    return l_438;
                }
            }
            else
            { /* block id: 131 */
                (*l_330) |= (~((*l_87) | (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*484*//* ___SAFE__OP */(5UL, (*l_87)))));
            }
            (*l_330) = (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*485*//* ___SAFE__OP */(((~0xB7L) > ((p_72 , (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*486*//* ___SAFE__OP */(0L, 1L))) > ((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*487*//* ___SAFE__OP */(g_59[0][6], 20)) > (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*488*//* ___SAFE__OP */(p_72, (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*489*//* ___SAFE__OP */((g_261[3] || (((l_207 = (l_207 , ((g_195 = g_230[5][4][0]) != g_212))) , 0x2522L) , (*l_330))), p_72))))))), g_162));
        }
        else
        { /* block id: 137 */
            int32_t **l_453 = (void*)0;
            int32_t **l_454;
            (*l_294) = (*l_294);
            (*l_454) = (*g_325);
            for (l_200 = 9; (l_200 >= 0); l_200 -= 1)
            { /* block id: 142 */
                int32_t *l_455[5][6][8];
                int i, j, k;
                return l_455[1][2][7];
            }
        }
    }
    else
    { /* block id: 146 */
        uint8_t l_475[3][6][9];
        int32_t l_529[1][7][9];
        int32_t l_602 = 5L;
        int i, j, k;
        (*l_87) = (-6L);
        for (g_329 = 28; (g_329 < 54); g_329 = safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*490*//* ___SAFE__OP */(g_329, 6))
        { /* block id: 150 */
            int32_t *l_460;
            int32_t l_484[8];
            int64_t *l_509[4];
            uint32_t l_559;
            const int32_t ****l_573[2][10];
            int i, j;
            for (i = 0; i < 4; i++)
                l_509[i] = &g_307;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 10; j++)
                    l_573[i][j] = &l_571;
            }
        }
    }
    for (g_212 = 0; (g_212 == 58); g_212 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*491*//* ___SAFE__OP */(g_212, 9))
    { /* block id: 230 */
        uint8_t *l_622;
        uint8_t *l_623 = (void*)0;
        uint8_t *l_624 = &g_336;
        int32_t l_642;
        uint32_t *l_643;
        uint32_t *l_644;
        uint32_t *l_645;
        uint32_t *l_646;
        uint32_t *l_647;
        uint32_t *l_648[5][4][1];
        int32_t l_674[5] = {1L,1L,1L,1L,1L};
        int i, j, k;
        l_642 = ((5L > ((g_485 ^ (p_72 && p_72)) | ((((((++(*l_624)) & g_282) == 0x71DBE1186687D776LL) && (*l_87)) | (!(safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*492*//* ___SAFE__OP */(((*g_384) = (safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*493*//* ___SAFE__OP */(((((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*494*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*495*//* ___SAFE__OP */(0xC3L, (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*496*//* ___SAFE__OP */((l_200 = (((*l_643) |= ((((safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*497*//* ___SAFE__OP */((((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*498*//* ___SAFE__OP */(((((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*499*//* ___SAFE__OP */((((void*)0 == l_92) < l_642), 0x110BC2D0L)) | p_72) , l_642) ^ p_72), 5)) > g_533) || g_485))) >= 0x68L) , l_642) | g_212)) ^ p_72)), 1L)))), 255UL)) , 3L) < g_59[0][0]) | 0x951D44C4L) , l_642) == p_72)))), 0xE490DEB2BAB7EF2FLL)))) && 1UL))) > l_642);
        (*l_87) &= l_642;
        for (g_336 = 0; (g_336 == 41); g_336 = safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*500*//* ___SAFE__OP */(g_336, 1))
        { /* block id: 239 */
            int32_t *l_663;
            int32_t *l_672;
            int32_t *l_673[3];
            int i;
            for (i = 0; i < 3; i++)
                l_673[i] = &g_88;
            for (g_532 = 0; (g_532 == (-18)); g_532--)
            { /* block id: 242 */
                uint32_t l_662;
                for (g_96 = 0; (g_96 <= 0); g_96 += 1)
                { /* block id: 245 */
                    uint64_t l_659;
                    int32_t **l_664;
                    int i;
                    g_461 = ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*501*//* ___SAFE__OP */(((((&g_260 != &g_260) != ((((((l_642 , (0x46A4L & (!((~(((*l_87) &= l_659) ^ l_642)) && ((((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*502*//* ___SAFE__OP */((p_72 <= (g_435 <= (p_72 == g_162))), l_642)) || 1L) ^ 255UL) != 6UL))))) != 4UL) || l_659) & 4UL) > 4294967288UL) != p_72)) >= p_72) != g_53), g_310)) , (*g_325));
                    if ((*l_87))
                        break;
                    (*l_664) = (l_662 , l_663);
                }
                if (l_642)
                    continue;
                for (g_164 = 0; (g_164 >= 16); ++g_164)
                { /* block id: 254 */
                    (*l_87) = (g_162 && (+((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*503*//* ___SAFE__OP */(p_72, g_614)) & ((*l_643) = (safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*504*//* ___SAFE__OP */(p_72, (*g_384)))))));
                }
                if (p_72)
                    continue;
            }
            g_683++;
            ++g_688;
        }
        if ((*l_87))
            continue;
    }
    return &l_334;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_21[i], "g_21[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_59[i][j], "g_59[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    transparent_crc(g_208, "g_208", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_228[i][j], "g_228[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_230[i][j][k], "g_230[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_261[i], "g_261[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_278[i][j][k], "g_278[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_293[i][j][k], "g_293[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_296[i][j], "g_296[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_307, "g_307", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_309[i], "g_309[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_310, "g_310", print_hash_value);
    transparent_crc(g_329, "g_329", print_hash_value);
    transparent_crc(g_333, "g_333", print_hash_value);
    transparent_crc(g_336, "g_336", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_408[i], "g_408[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_435, "g_435", print_hash_value);
    transparent_crc(g_485, "g_485", print_hash_value);
    transparent_crc(g_530, "g_530", print_hash_value);
    transparent_crc(g_532, "g_532", print_hash_value);
    transparent_crc(g_533, "g_533", print_hash_value);
    transparent_crc(g_560, "g_560", print_hash_value);
    transparent_crc(g_614, "g_614", print_hash_value);
    transparent_crc(g_675, "g_675", print_hash_value);
    transparent_crc(g_676, "g_676", print_hash_value);
    transparent_crc(g_679, "g_679", print_hash_value);
    transparent_crc(g_680, "g_680", print_hash_value);
    transparent_crc(g_681, "g_681", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_682[i][j][k], "g_682[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_683, "g_683", print_hash_value);
    transparent_crc(g_686, "g_686", print_hash_value);
    transparent_crc(g_687, "g_687", print_hash_value);
    transparent_crc(g_688, "g_688", print_hash_value);
    transparent_crc(g_737, "g_737", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_926[i], "g_926[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_949[i], "g_949[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_955[i], "g_955[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_956, "g_956", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_978, "g_978", print_hash_value);
    transparent_crc(g_1034, "g_1034", print_hash_value);
    transparent_crc(g_1038, "g_1038", print_hash_value);
    transparent_crc(g_1039, "g_1039", print_hash_value);
    transparent_crc(g_1132, "g_1132", print_hash_value);
    transparent_crc(g_1134, "g_1134", print_hash_value);
    transparent_crc(g_1248, "g_1248", print_hash_value);
    transparent_crc(g_1249, "g_1249", print_hash_value);
    transparent_crc(g_1250, "g_1250", print_hash_value);
    transparent_crc(g_1285, "g_1285", print_hash_value);
    transparent_crc(g_1311, "g_1311", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1450[i][j], "g_1450[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1486, "g_1486", print_hash_value);
    transparent_crc(g_1543, "g_1543", print_hash_value);
    transparent_crc(g_1548, "g_1548", print_hash_value);
    transparent_crc(g_1549, "g_1549", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1550[i][j], "g_1550[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1577, "g_1577", print_hash_value);
    transparent_crc(g_1586, "g_1586", print_hash_value);
    transparent_crc(g_1605, "g_1605", print_hash_value);
    transparent_crc(g_1898, "g_1898", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1901[i], "g_1901[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1925, "g_1925", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_2368[i][j][k], "g_2368[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2534, "g_2534", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 679
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 52
breakdown:
   depth: 1, occurrence: 377
   depth: 2, occurrence: 93
   depth: 3, occurrence: 10
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 2
   depth: 11, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 6
   depth: 17, occurrence: 3
   depth: 18, occurrence: 3
   depth: 19, occurrence: 6
   depth: 20, occurrence: 5
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 23, occurrence: 4
   depth: 24, occurrence: 5
   depth: 25, occurrence: 3
   depth: 26, occurrence: 6
   depth: 27, occurrence: 4
   depth: 28, occurrence: 3
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 4
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 36, occurrence: 3
   depth: 37, occurrence: 2
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 41, occurrence: 1
   depth: 52, occurrence: 1

XXX total number of pointers: 647

XXX times a variable address is taken: 1391
XXX times a pointer is dereferenced on RHS: 394
breakdown:
   depth: 1, occurrence: 310
   depth: 2, occurrence: 61
   depth: 3, occurrence: 15
   depth: 4, occurrence: 5
   depth: 5, occurrence: 3
XXX times a pointer is dereferenced on LHS: 385
breakdown:
   depth: 1, occurrence: 328
   depth: 2, occurrence: 41
   depth: 3, occurrence: 9
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
XXX times a pointer is compared with null: 55
XXX times a pointer is compared with address of another variable: 12
XXX times a pointer is compared with another pointer: 18
XXX times a pointer is qualified to be dereferenced: 9240

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2515
   level: 2, occurrence: 461
   level: 3, occurrence: 146
   level: 4, occurrence: 77
   level: 5, occurrence: 58
XXX number of pointers point to pointers: 289
XXX number of pointers point to scalars: 358
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.4
XXX average alias set size: 1.47

XXX times a non-volatile is read: 2290
XXX times a non-volatile is write: 1165
XXX times a volatile is read: 90
XXX    times read thru a pointer: 65
XXX times a volatile is write: 45
XXX    times written thru a pointer: 40
XXX times a volatile is available for access: 856
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 3
XXX backward jumps: 11

XXX stmts: 380
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 50
   depth: 2, occurrence: 49
   depth: 3, occurrence: 75
   depth: 4, occurrence: 78
   depth: 5, occurrence: 95

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
********************* end of statistics **********************/

