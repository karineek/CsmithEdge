/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 2ceb80e
 * Options:   --seed 4231343982
 * Seed:      4231343982
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int8_t * f0;
   uint16_t  f1;
   signed f2 : 11;
   int8_t  f3;
   uint32_t  f4;
};

union U1 {
   int32_t  f0;
   int32_t  f1;
   uint32_t  f2;
   int32_t  f3;
   unsigned f4 : 11;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[5] = {1L,1L,1L,1L,1L};
static volatile int32_t g_3 = 7L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4[5] = {0L,0L,0L,0L,0L};
static int32_t g_10 = 0xEE28FDEBL;
static int32_t * volatile g_9 = &g_10;/* VOLATILE GLOBAL g_9 */
static union U1 g_37 = {-8L};
static uint16_t g_50 = 1UL;
static int32_t g_57 = 0x44C9CADCL;
static uint32_t g_75 = 0xEF6E88F3L;
static const int8_t g_100 = 0x4EL;
static uint32_t g_131 = 18446744073709551615UL;
static int8_t g_137[7] = {(-1L),(-1L),0x3BL,(-1L),(-1L),0x3BL,(-1L)};
static int8_t *g_136 = &g_137[0];
static int8_t g_170 = 0x6FL;
static uint32_t g_175 = 4294967293UL;
static int64_t g_179[7] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
static int64_t *g_180 = (void*)0;
static uint8_t g_195 = 0xE5L;
static uint64_t g_235 = 1UL;
static int32_t g_262[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
static uint16_t *g_267 = &g_50;
static int16_t g_283 = 0x6B29L;
static uint32_t *g_343[10][5] = {{&g_75,&g_175,&g_175,&g_175,&g_175},{(void*)0,&g_75,&g_75,(void*)0,&g_75},{(void*)0,&g_175,&g_75,&g_175,&g_75},{&g_175,&g_75,&g_75,&g_175,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_175,&g_75,&g_175},{&g_75,&g_75,&g_75,&g_75,&g_175},{&g_175,&g_75,&g_175,&g_175,&g_75}};
static uint32_t **g_342 = &g_343[4][3];
static uint8_t *g_349 = &g_195;
static uint8_t *g_350[6] = {&g_195,&g_195,&g_195,&g_195,&g_195,&g_195};
static union U0 g_369 = {0};
static union U0 *g_368 = &g_369;
static const int32_t g_381 = 1L;
static int32_t *g_403 = (void*)0;
static int32_t ** volatile g_402[10][3][7] = {{{&g_403,(void*)0,&g_403,&g_403,&g_403,(void*)0,&g_403},{&g_403,&g_403,(void*)0,&g_403,(void*)0,(void*)0,(void*)0},{&g_403,&g_403,&g_403,&g_403,&g_403,(void*)0,&g_403}},{{(void*)0,&g_403,(void*)0,&g_403,&g_403,&g_403,&g_403},{&g_403,&g_403,&g_403,(void*)0,&g_403,(void*)0,&g_403},{(void*)0,&g_403,&g_403,(void*)0,(void*)0,&g_403,&g_403}},{{&g_403,(void*)0,(void*)0,&g_403,(void*)0,(void*)0,&g_403},{&g_403,(void*)0,(void*)0,(void*)0,(void*)0,&g_403,(void*)0},{&g_403,&g_403,&g_403,&g_403,&g_403,(void*)0,&g_403}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_403,(void*)0,&g_403},{(void*)0,&g_403,(void*)0,(void*)0,&g_403,(void*)0,(void*)0},{(void*)0,(void*)0,&g_403,&g_403,(void*)0,&g_403,&g_403}},{{&g_403,(void*)0,&g_403,&g_403,&g_403,(void*)0,&g_403},{&g_403,&g_403,(void*)0,&g_403,(void*)0,(void*)0,(void*)0},{&g_403,&g_403,&g_403,&g_403,&g_403,(void*)0,&g_403}},{{(void*)0,&g_403,(void*)0,&g_403,&g_403,&g_403,&g_403},{&g_403,&g_403,&g_403,(void*)0,&g_403,(void*)0,&g_403},{(void*)0,&g_403,&g_403,(void*)0,(void*)0,&g_403,&g_403}},{{&g_403,(void*)0,(void*)0,&g_403,(void*)0,(void*)0,&g_403},{&g_403,(void*)0,(void*)0,(void*)0,(void*)0,&g_403,(void*)0},{&g_403,&g_403,&g_403,&g_403,&g_403,(void*)0,&g_403}},{{(void*)0,&g_403,&g_403,&g_403,&g_403,&g_403,(void*)0},{&g_403,(void*)0,&g_403,(void*)0,(void*)0,(void*)0,&g_403},{&g_403,&g_403,&g_403,(void*)0,&g_403,(void*)0,(void*)0}},{{&g_403,(void*)0,&g_403,(void*)0,&g_403,(void*)0,&g_403},{&g_403,(void*)0,&g_403,&g_403,&g_403,&g_403,&g_403},{(void*)0,(void*)0,&g_403,(void*)0,(void*)0,&g_403,(void*)0}},{{&g_403,&g_403,&g_403,(void*)0,&g_403,&g_403,(void*)0},{&g_403,(void*)0,&g_403,(void*)0,&g_403,(void*)0,&g_403},{&g_403,(void*)0,&g_403,&g_403,&g_403,&g_403,(void*)0}}};
static int32_t ** volatile g_404 = &g_403;/* VOLATILE GLOBAL g_404 */
static volatile uint8_t g_408 = 0xE1L;/* VOLATILE GLOBAL g_408 */
static const volatile uint8_t * volatile g_407 = &g_408;/* VOLATILE GLOBAL g_407 */
static const volatile uint8_t * volatile * volatile g_406 = &g_407;/* VOLATILE GLOBAL g_406 */
static const volatile uint8_t * volatile * volatile *g_405 = &g_406;
static int32_t ** const  volatile g_421 = &g_403;/* VOLATILE GLOBAL g_421 */
static uint32_t *g_443 = &g_75;
static int32_t * volatile g_453 = &g_262[6];/* VOLATILE GLOBAL g_453 */
static const volatile uint8_t * volatile * volatile **g_482[8][8] = {{&g_405,&g_405,&g_405,&g_405,&g_405,(void*)0,(void*)0,&g_405},{&g_405,&g_405,&g_405,&g_405,(void*)0,&g_405,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,(void*)0,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405},{&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405}};
static const volatile uint8_t * volatile * volatile *** volatile g_481 = &g_482[6][7];/* VOLATILE GLOBAL g_481 */
static int16_t g_518 = 0L;
static int32_t ** volatile g_523 = &g_403;/* VOLATILE GLOBAL g_523 */
static int8_t g_598 = 0L;
static uint32_t g_599 = 0x67AF3AADL;
static uint32_t * volatile * volatile *g_638 = (void*)0;
static uint32_t * volatile * volatile ** const g_637 = &g_638;
static uint64_t *g_694 = &g_235;
static uint8_t ****g_727 = (void*)0;
static uint8_t ***** volatile g_726 = &g_727;/* VOLATILE GLOBAL g_726 */
static uint32_t g_805 = 0x3765770CL;
static int64_t g_817 = 7L;
static volatile uint16_t g_821 = 0x0B04L;/* VOLATILE GLOBAL g_821 */
static int8_t g_909 = 1L;
static int32_t ** volatile g_913 = &g_403;/* VOLATILE GLOBAL g_913 */
static const volatile int8_t g_930 = 0x3EL;/* VOLATILE GLOBAL g_930 */
static int32_t ** volatile g_997 = &g_403;/* VOLATILE GLOBAL g_997 */
static int64_t g_1045 = 0xAD2FE4A231562067LL;
static uint64_t g_1051 = 7UL;
static int32_t ** volatile g_1074 = &g_403;/* VOLATILE GLOBAL g_1074 */
static volatile int64_t g_1090 = 0x065DA01D4AF05E10LL;/* VOLATILE GLOBAL g_1090 */
static union U1 g_1097 = {0xE128845CL};
static uint8_t g_1106 = 255UL;
static volatile uint32_t g_1110 = 0xFB0E6015L;/* VOLATILE GLOBAL g_1110 */
static int32_t ** volatile g_1135[9][1][1] = {{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}},{{&g_403}}};
static int32_t ** volatile g_1136 = &g_403;/* VOLATILE GLOBAL g_1136 */
static int32_t * volatile g_1151 = (void*)0;/* VOLATILE GLOBAL g_1151 */
static uint64_t g_1162[5] = {18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL};
static volatile uint64_t g_1173[7][5] = {{0UL,0xC92A7105761AF913LL,0xC92A7105761AF913LL,0UL,0xC92A7105761AF913LL},{0xF60BEBB6096CA10ELL,0xF60BEBB6096CA10ELL,0x3F3729EFB2009ABELL,0xF60BEBB6096CA10ELL,0xF60BEBB6096CA10ELL},{0xC92A7105761AF913LL,0UL,0xC92A7105761AF913LL,0xC92A7105761AF913LL,0UL},{0xF60BEBB6096CA10ELL,18446744073709551612UL,18446744073709551612UL,0xF60BEBB6096CA10ELL,18446744073709551612UL},{0UL,0UL,0x87FDF801E2A6D870LL,0UL,0UL},{18446744073709551612UL,0xF60BEBB6096CA10ELL,18446744073709551612UL,18446744073709551612UL,0xF60BEBB6096CA10ELL},{0UL,0xC92A7105761AF913LL,0xC92A7105761AF913LL,0UL,0xC92A7105761AF913LL}};
static int32_t * volatile g_1176[3][1][10] = {{{&g_1097.f0,&g_4[3],&g_57,&g_4[3],&g_1097.f0,&g_262[0],&g_262[0],&g_1097.f0,&g_4[3],&g_57}},{{&g_262[3],&g_262[3],&g_57,&g_1097.f0,(void*)0,&g_262[0],&g_262[3],(void*)0,(void*)0,&g_262[3]}},{{&g_10,&g_262[0],&g_57,&g_57,&g_262[0],&g_10,&g_262[3],&g_10,&g_262[0],&g_57}}};
static int32_t * volatile g_1177 = &g_57;/* VOLATILE GLOBAL g_1177 */
static union U0 ** volatile g_1180 = (void*)0;/* VOLATILE GLOBAL g_1180 */
static union U0 ** volatile g_1181 = &g_368;/* VOLATILE GLOBAL g_1181 */
static volatile union U1 g_1202 = {-4L};/* VOLATILE GLOBAL g_1202 */
static volatile union U1 *g_1201 = &g_1202;
static volatile union U1 ** volatile g_1200[2] = {&g_1201,&g_1201};
static int32_t ** volatile g_1221 = &g_403;/* VOLATILE GLOBAL g_1221 */
static int32_t *g_1226 = &g_4[3];
static uint8_t g_1257 = 252UL;
static uint64_t *g_1282 = (void*)0;
static int8_t g_1318[9][7] = {{(-10L),(-1L),0x50L,0xF9L,0x95L,0x16L,0x6DL},{3L,7L,0L,0x6DL,(-1L),0x34L,(-1L)},{0x50L,5L,(-1L),0L,0x4EL,0L,(-1L)},{5L,5L,(-10L),0x3EL,(-1L),0x2FL,0x6DL},{0xB1L,0x07L,0x16L,7L,(-1L),0xE5L,3L},{0x3EL,0x2FL,0xD8L,0x95L,(-1L),(-1L),0xB0L},{0xD8L,0x4BL,0xE5L,(-1L),0x4EL,0x3EL,0x3EL},{(-1L),0xACL,0xE5L,0xACL,(-1L),0xB0L,(-1L)},{0x4BL,0x6DL,0xD8L,(-10L),0x95L,3L,0xE5L}};
static int64_t g_1326 = 0x496BBD2D728634E5LL;
static int32_t ** volatile g_1417 = &g_1226;/* VOLATILE GLOBAL g_1417 */
static uint8_t g_1419 = 3UL;
static const uint64_t g_1432[3] = {0xD62AC960254EBAABLL,0xD62AC960254EBAABLL,0xD62AC960254EBAABLL};
static const uint64_t *g_1431 = &g_1432[2];
static uint32_t ****g_1442 = (void*)0;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static const int32_t  func_17(int32_t  p_18, uint64_t  p_19, int8_t * p_20, union U1  p_21);
static int8_t * func_23(int32_t * p_24, union U1  p_25, union U0  p_26);
static int32_t * func_27(uint64_t  p_28, int32_t  p_29, int32_t  p_30);
static union U1  func_31(int32_t  p_32, union U1  p_33, uint64_t  p_34, int32_t  p_35, int64_t  p_36);
static uint32_t  func_63(int32_t * p_64);
static int32_t  func_66(const int64_t  p_67, uint64_t  p_68, uint16_t * p_69, int32_t * p_70);
static int8_t * func_78(uint8_t  p_79, uint32_t * p_80, uint32_t  p_81);
static int16_t  func_82(int8_t * p_83);
static int8_t * func_84(uint64_t  p_85, int32_t  p_86, const int8_t * p_87, uint16_t  p_88, const int32_t  p_89);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_10 g_37.f0 g_817 g_1110
 * writes: g_4 g_10 g_37.f0 g_817
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_22 = 1L;
    union U1 l_1003 = {-1L};
    int32_t l_1193 = (-1L);
    int32_t l_1195[1][2][3] = {{{0x7A0D834CL,(-2L),0x7A0D834CL},{0x7A0D834CL,(-2L),0x7A0D834CL}}};
    int32_t l_1196 = 0xAA4E35C2L;
    uint32_t l_1203 = 0xDCCFA5C5L;
    union U1 *l_1205 = &l_1003;
    union U1 **l_1204 = &l_1205;
    uint8_t l_1224[2];
    int32_t *l_1227 = &l_1195[0][1][2];
    uint16_t l_1263 = 0x6DB2L;
    int32_t l_1283 = 0xD5FC5197L;
    uint8_t l_1327 = 0x3AL;
    int32_t l_1342[5] = {0x3DF9782AL,0x3DF9782AL,0x3DF9782AL,0x3DF9782AL,0x3DF9782AL};
    const int32_t * const l_1343 = &g_262[2];
    uint8_t **** const *l_1353 = &g_727;
    union U0 l_1355 = {0};
    uint8_t l_1371 = 1UL;
    uint8_t *****l_1379[9][8][3] = {{{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,(void*)0,&g_727},{(void*)0,(void*)0,&g_727},{&g_727,&g_727,(void*)0},{&g_727,(void*)0,&g_727},{&g_727,&g_727,&g_727}},{{&g_727,(void*)0,&g_727},{(void*)0,&g_727,&g_727},{&g_727,&g_727,&g_727},{(void*)0,&g_727,&g_727},{(void*)0,&g_727,(void*)0},{&g_727,(void*)0,&g_727},{&g_727,&g_727,&g_727},{&g_727,(void*)0,&g_727}},{{&g_727,&g_727,&g_727},{&g_727,(void*)0,(void*)0},{&g_727,(void*)0,&g_727},{&g_727,&g_727,&g_727},{(void*)0,&g_727,(void*)0},{(void*)0,&g_727,(void*)0},{&g_727,&g_727,&g_727},{(void*)0,&g_727,&g_727}},{{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{(void*)0,&g_727,&g_727},{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727}},{{&g_727,&g_727,&g_727},{(void*)0,(void*)0,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727}},{{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,(void*)0}},{{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,(void*)0,(void*)0},{&g_727,&g_727,&g_727},{&g_727,(void*)0,&g_727},{&g_727,(void*)0,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727}},{{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,(void*)0},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_727},{(void*)0,&g_727,&g_727}},{{(void*)0,(void*)0,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727},{&g_727,&g_727,&g_727}}};
    uint16_t **l_1394 = &g_267;
    uint16_t l_1422 = 0xEC04L;
    uint64_t l_1458 = 0xBCD28C3B57E9D0EDLL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1224[i] = 246UL;
    for (g_4[3] = 1; (g_4[3] <= 16); g_4[3] = safe_add_func_int8_t_s_s(g_4[3], 2))
    { /* block id: 3 */
        int8_t l_7 = (-1L);
        int32_t *l_8 = (void*)0;
        int32_t l_1184 = 0x74F780C1L;
        int32_t l_1189 = 0L;
        int32_t l_1194[5][8] = {{0x531D0681L,1L,1L,0x531D0681L,0x337A2600L,(-1L),(-1L),1L},{(-1L),(-1L),(-7L),1L,(-1L),0xA8E986FBL,(-1L),1L},{(-1L),(-1L),(-1L),1L,(-1L),(-1L),0x337A2600L,0x531D0681L},{0x96CB223CL,1L,0x947983E2L,(-1L),0L,0L,(-1L),0x947983E2L},{0x96CB223CL,0x96CB223CL,0xA8E986FBL,1L,(-1L),(-1L),0x96CB223CL,(-1L)}};
        uint32_t *l_1236 = (void*)0;
        int32_t l_1237 = 1L;
        union U0 l_1261 = {0};
        uint16_t l_1285 = 8UL;
        const uint8_t l_1288 = 255UL;
        int8_t l_1300 = 0x50L;
        uint16_t l_1319 = 0UL;
        const uint64_t *l_1428 = &g_1051;
        uint32_t ***l_1440[3];
        int i, j;
        for (i = 0; i < 3; i++)
            l_1440[i] = &g_342;
        (*g_9) ^= l_7;
        for (g_10 = 0; (g_10 >= 14); ++g_10)
        { /* block id: 7 */
            uint8_t l_47 = 0x14L;
            uint16_t *l_48 = (void*)0;
            uint16_t *l_49 = &g_50;
            union U1 l_1001 = {0x78C82212L};
            union U0 l_1004 = {0};
            int32_t l_1178 = 0xE29DF73AL;
            int64_t *l_1179 = &g_1045;
            int32_t l_1190[5][4] = {{0xFFD67E01L,3L,0xFFD67E01L,0xFFD67E01L},{3L,3L,1L,3L},{3L,0xFFD67E01L,0xFFD67E01L,3L},{0xFFD67E01L,3L,0xFFD67E01L,0xFFD67E01L},{3L,3L,1L,3L}};
            int i, j;
        }
        for (g_37.f0 = 6; (g_37.f0 >= 0); g_37.f0 -= 1)
        { /* block id: 675 */
            int32_t l_1255[8][10][3] = {{{0x8310A24EL,(-2L),0xDBC27AF1L},{0x5A565684L,0x5A565684L,0xDBC27AF1L},{(-2L),0x8310A24EL,(-8L)},{(-1L),0x5A565684L,(-1L)},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L}},{{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL}},{{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L}},{{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)}},{{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L}},{{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL}},{{0x8310A24EL,(-1L),(-6L)},{(-1L),0x8310A24EL,0x8310A24EL},{(-6L),0x8310A24EL,0xDBC27AF1L},{(-8L),(-1L),0x5A565684L},{(-6L),(-6L),0x5A565684L},{(-1L),(-8L),0xDBC27AF1L},{0x8310A24EL,(-6L),0x8310A24EL},{0x8310A24EL,(-1L),(-2L)},{0x8310A24EL,(-8L),(-8L)},{(-2L),(-8L),0x5A565684L}},{{0xDBC27AF1L,0x8310A24EL,(-6L)},{(-2L),(-2L),(-6L)},{0x8310A24EL,0xDBC27AF1L,0x5A565684L},{(-8L),(-2L),(-8L)},{(-8L),0x8310A24EL,(-2L)},{0x8310A24EL,(-8L),(-8L)},{(-2L),(-8L),0x5A565684L},{0xDBC27AF1L,0x8310A24EL,(-6L)},{(-2L),(-2L),(-6L)},{0x8310A24EL,0xDBC27AF1L,0x5A565684L}}};
            const uint8_t l_1262 = 246UL;
            uint16_t l_1273 = 65535UL;
            const uint32_t l_1287 = 0xA10B8400L;
            int32_t l_1345[5][6] = {{0xB2D14429L,(-1L),(-1L),0xB2D14429L,(-10L),0xB2D14429L},{0xB2D14429L,(-10L),0xB2D14429L,(-1L),(-1L),0xB2D14429L},{0x905E6153L,0x905E6153L,(-1L),0x3E364AC1L,(-1L),0x905E6153L},{(-1L),(-10L),0x3E364AC1L,0x3E364AC1L,(-10L),(-1L)},{0x905E6153L,(-1L),0x3E364AC1L,(-1L),0x905E6153L,0x905E6153L}};
            uint64_t l_1356[8] = {0xBB133BD4CE252CD6LL,18446744073709551613UL,18446744073709551613UL,0xBB133BD4CE252CD6LL,18446744073709551613UL,18446744073709551613UL,0xBB133BD4CE252CD6LL,18446744073709551613UL};
            uint32_t l_1376 = 0x393CB531L;
            uint64_t l_1411 = 18446744073709551615UL;
            uint32_t l_1412 = 0x724D920DL;
            int32_t *l_1415 = &l_1193;
            int16_t *l_1423 = &g_283;
            uint64_t **l_1427 = &g_1282;
            const uint64_t **l_1429 = (void*)0;
            const uint64_t **l_1430[10] = {&l_1428,&l_1428,&l_1428,&l_1428,&l_1428,&l_1428,&l_1428,&l_1428,&l_1428,&l_1428};
            uint8_t **l_1433[7][3] = {{&g_349,&g_350[1],&g_350[1]},{&g_349,&g_350[1],&g_350[1]},{&g_350[5],&g_349,&g_350[1]},{&g_349,&g_349,&g_350[1]},{&g_349,&g_350[5],&g_350[1]},{&g_350[1],&g_349,&g_350[1]},{&g_350[1],&g_349,&g_349}};
            uint32_t ***l_1439[6][10] = {{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342,&g_342}};
            uint32_t ****l_1438 = &l_1439[3][6];
            uint32_t *****l_1441[1][4][2];
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    for (k = 0; k < 2; k++)
                        l_1441[i][j][k] = (void*)0;
                }
            }
        }
    }
    for (g_817 = (-18); (g_817 == (-11)); ++g_817)
    { /* block id: 766 */
        int32_t *l_1454 = &l_1196;
        int32_t *l_1455 = &g_4[2];
        int32_t *l_1456 = &g_262[8];
        int32_t *l_1457[3];
        int i;
        for (i = 0; i < 3; i++)
            l_1457[i] = &l_1193;
        l_1458--;
    }
    return g_1110;
}


/* ------------------------------------------ */
/* 
 * reads : g_131 g_2 g_50 g_349 g_195 g_342 g_343 g_694 g_235 g_1051 g_1110 g_518 g_179 g_1136 g_1106 g_403 g_137 g_598 g_267 g_262 g_1162 g_1173 g_136 g_1177
 * writes: g_131 g_235 g_195 g_2 g_1051 g_1106 g_518 g_137 g_598 g_403 g_262 g_1162 g_57
 */
static const int32_t  func_17(int32_t  p_18, uint64_t  p_19, int8_t * p_20, union U1  p_21)
{ /* block id: 608 */
    int16_t l_1111 = 0L;
    int32_t l_1127[2][2];
    uint16_t l_1134 = 0UL;
    uint8_t ***l_1141 = (void*)0;
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
            l_1127[i][j] = 0L;
    }
    for (g_131 = 0; (g_131 <= 4); g_131 += 1)
    { /* block id: 611 */
        uint8_t *l_1105[7][2] = {{&g_1106,&g_1106},{&g_1106,&g_1106},{&g_1106,&g_1106},{&g_1106,&g_1106},{&g_1106,&g_1106},{&g_1106,&g_1106},{&g_1106,&g_1106}};
        int32_t l_1107 = 0L;
        uint8_t l_1115 = 0xADL;
        uint64_t l_1175 = 0UL;
        int i, j;
        g_2[g_131] = (p_21 , (g_2[g_131] == (l_1107 = ((*g_349) = (g_50 > (~(safe_div_func_uint8_t_u_u((*g_349), (safe_rshift_func_uint64_t_u_s(((*g_694) |= ((void*)0 != (*g_342))), g_50))))))))));
        for (p_21.f2 = 0; (p_21.f2 <= 5); p_21.f2 += 1)
        { /* block id: 618 */
            uint32_t ***l_1118 = &g_342;
            int32_t l_1126 = (-2L);
            for (g_1051 = 0; (g_1051 <= 7); g_1051 += 1)
            { /* block id: 621 */
                const uint32_t l_1120[5] = {0x92E03680L,0x92E03680L,0x92E03680L,0x92E03680L,0x92E03680L};
                uint8_t l_1128 = 248UL;
                uint64_t *l_1161 = &g_1162[4];
                int32_t *l_1174 = &l_1127[0][0];
                int i;
                for (g_1106 = 0; (g_1106 <= 5); g_1106 += 1)
                { /* block id: 624 */
                    int16_t *l_1112 = &g_518;
                    uint32_t ***l_1119 = &g_342;
                    uint16_t l_1149 = 65535UL;
                    if ((safe_mod_func_uint16_t_u_u(((g_1110 , ((*l_1112) |= l_1111)) <= (safe_add_func_uint16_t_u_u(0x9272L, ((((*p_20) = l_1115) < ((safe_rshift_func_int64_t_s_u(l_1115, p_21.f2)) <= (l_1111 >= (l_1118 == (l_1115 , l_1119))))) < l_1120[4])))), p_21.f2)))
                    { /* block id: 627 */
                        int32_t *l_1121 = &g_262[4];
                        int32_t *l_1122 = &g_262[4];
                        int32_t *l_1123 = &g_37.f0;
                        int32_t *l_1124 = &l_1107;
                        int32_t *l_1125[1][2];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_1125[i][j] = &g_1097.f0;
                        }
                        l_1128--;
                        return p_18;
                    }
                    else
                    { /* block id: 630 */
                        int32_t *l_1131 = &g_1097.f1;
                        int32_t *l_1132 = &g_1097.f3;
                        int32_t *l_1133[4];
                        uint8_t **l_1140 = &l_1105[0][0];
                        uint8_t *** const l_1139 = &l_1140;
                        int32_t l_1144 = 0x7CE96C4AL;
                        int32_t *l_1150 = (void*)0;
                        int32_t *l_1152 = &g_262[2];
                        int i, j;
                        for (i = 0; i < 4; i++)
                            l_1133[i] = (void*)0;
                        (*g_1136) = ((l_1134 ^= g_179[6]) , &l_1107);
                        (*l_1152) |= ((safe_div_func_int8_t_s_s(((((l_1139 == l_1141) | (safe_mul_func_int32_t_s_s(((*g_403) = l_1144), ((safe_sub_func_int8_t_s_s((*p_20), ((-1L) && ((p_19 || (safe_mod_func_uint16_t_u_u((*g_267), g_137[4]))) < (-2L))))) || l_1149)))) >= p_21.f2) > 0xD804AD5AL), 0x6EL)) == (-4L));
                    }
                    l_1126 &= p_18;
                    if (p_18)
                        break;
                }
                l_1126 = (p_21.f2 || ((*g_136) = ((((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint64_t_u_u((((safe_mod_func_uint64_t_u_u((*g_694), ((--(*l_1161)) && 0x68B1A9D31D95B945LL))) , (+((((safe_add_func_uint64_t_u_u((g_195 , (((*l_1174) = (safe_mod_func_int8_t_s_s((((p_21.f2 > (0UL & (((0xB9FB1196442A37AALL || ((safe_div_func_uint8_t_u_u(((~((*g_349) && l_1127[1][0])) , g_1173[5][2]), 0x82L)) <= 0xDB34L)) == p_19) && 0x36D3A17107CC74A1LL))) , 0x42E8L) == 0xFC08L), 0x58L))) == l_1111)), 1UL)) < g_179[4]) | 0x89CE96485F003E32LL) , 1UL))) > 0L), 7)), l_1175)) && 0L) , p_18) != 0x6ACABC9FL)));
            }
            return l_1134;
        }
        (*g_1177) = l_1134;
    }
    return l_1111;
}


/* ------------------------------------------ */
/* 
 * reads : g_443 g_75 g_131 g_694 g_235 g_137 g_57 g_598 g_37.f1
 * writes: g_75 g_57 g_598 g_37.f1
 */
static int8_t * func_23(int32_t * p_24, union U1  p_25, union U0  p_26)
{ /* block id: 533 */
    int32_t l_1005[8] = {(-1L),0xCE0707EDL,(-1L),(-1L),0xCE0707EDL,(-6L),(-6L),(-1L)};
    int64_t l_1018 = 0x3673714D7ABD21E0LL;
    uint64_t l_1019 = 5UL;
    int32_t *l_1020 = &g_57;
    uint64_t l_1076 = 18446744073709551607UL;
    int32_t l_1081 = 0x10B5EE1BL;
    int32_t l_1082 = 0x503B8305L;
    int64_t l_1083 = 0x6782C5E18654E381LL;
    int32_t l_1088[8][2] = {{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL},{0xA71CA6DEL,0xA71CA6DEL}};
    int64_t l_1095 = 2L;
    int8_t *l_1096 = &g_598;
    int i, j;
    (*l_1020) &= ((((((*g_443)++) > ((((l_1005[7] || ((safe_mod_func_int16_t_s_s(l_1005[7], p_25.f0)) != l_1005[7])) | (l_1005[7] ^ ((safe_lshift_func_uint16_t_u_s((p_25.f0 > (g_131 < ((((((safe_add_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint16_t_u_u((l_1005[3] <= ((*g_694) || (*g_694))), 0L)) > l_1005[5]), l_1018)), 4294967293UL)) ^ 0xFBL) ^ 0x55DB9B1FL) > p_25.f0) , l_1018) <= l_1005[7]))), g_137[0])) < l_1018))) , l_1019) , p_25.f0)) , 0x9827L) , (void*)0) == p_24);
    for (p_25.f1 = 0; (p_25.f1 > 8); p_25.f1 = safe_add_func_uint32_t_u_u(p_25.f1, 7))
    { /* block id: 538 */
        int32_t l_1059[2];
        int32_t l_1089 = 0L;
        uint32_t l_1091 = 1UL;
        int8_t *l_1094 = &g_137[1];
        int i;
        for (i = 0; i < 2; i++)
            l_1059[i] = 8L;
        for (g_598 = 2; (g_598 >= 0); g_598 -= 1)
        { /* block id: 541 */
            uint16_t l_1058 = 0UL;
            int32_t l_1084 = 0x1B32A7B4L;
            int32_t l_1086 = 0x32D44D7CL;
            int32_t l_1087[8][6] = {{0L,0x02654A8DL,0x02654A8DL,0L,0x5824D31CL,3L},{0L,(-5L),0xDE2E5FA0L,0xF21DBF41L,3L,7L},{0x4D7EAC02L,1L,(-1L),(-1L),3L,0xEB14F63CL},{0x5824D31CL,(-5L),0L,(-5L),0x5824D31CL,(-1L)},{(-1L),0x02654A8DL,0x3DD96CB9L,3L,0L,0x4D7EAC02L},{0x3DD96CB9L,(-8L),0x5824D31CL,0x02654A8DL,0x1AB99F77L,0x4D7EAC02L},{(-1L),0xEB14F63CL,0x3DD96CB9L,0x3DD96CB9L,0xEB14F63CL,(-1L)},{0x1AB99F77L,0xF21DBF41L,0L,3L,(-1L),0xEB14F63CL}};
            int i, j;
            for (g_37.f1 = 0; (g_37.f1 <= 2); g_37.f1 += 1)
            { /* block id: 544 */
                uint64_t l_1056 = 0xAE5872E82A09B898LL;
                int32_t *l_1077 = &l_1059[0];
                int32_t *l_1078 = (void*)0;
                int32_t *l_1079 = (void*)0;
                int32_t *l_1080[3];
                int32_t l_1085 = 1L;
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_1080[i] = &g_262[4];
            }
            for (l_1084 = 0; (l_1084 <= 2); l_1084 += 1)
            { /* block id: 600 */
                return l_1094;
            }
        }
        if ((*l_1020))
            continue;
        if (l_1095)
            break;
    }
    return l_1096;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_27(uint64_t  p_28, int32_t  p_29, int32_t  p_30)
{ /* block id: 531 */
    int32_t *l_1002 = (void*)0;
    return l_1002;
}


/* ------------------------------------------ */
/* 
 * reads : g_342 g_343 g_267 g_50 g_407 g_408 g_453 g_262 g_100 g_195 g_283 g_136 g_137 g_235 g_2 g_726 g_599 g_179 g_37 g_694 g_4 g_175 g_481 g_482 g_10 g_805 g_9 g_821 g_518 g_349 g_598 g_909 g_37.f0 g_913 g_930 g_817 g_443 g_403 g_421 g_997
 * writes: g_37.f2 g_343 g_443 g_262 g_235 g_37.f1 g_57 g_727 g_137 g_179 g_403 g_2 g_50 g_37.f0 g_805 g_821 g_283 g_75
 */
static union U1  func_31(int32_t  p_32, union U1  p_33, uint64_t  p_34, int32_t  p_35, int64_t  p_36)
{ /* block id: 9 */
    uint64_t l_60 = 0xA4B1F059960698B4LL;
    const int32_t * const *l_378 = (void*)0;
    const volatile uint8_t * volatile * volatile *l_409 = &g_406;
    int32_t l_410 = (-9L);
    int32_t l_411 = 0xCA559DDDL;
    int32_t l_413 = (-2L);
    uint32_t ***l_431 = &g_342;
    uint32_t ***l_432 = &g_342;
    uint16_t **l_446 = (void*)0;
    int8_t l_449 = 0xCFL;
    uint32_t l_543 = 0xE158E6A8L;
    const uint32_t l_559 = 0x2B95A193L;
    union U1 l_588 = {-1L};
    uint32_t l_721 = 4294967292UL;
    uint32_t l_722[4][3][7] = {{{1UL,0UL,0x137CCD58L,0x137CCD58L,0UL,1UL,9UL},{0x91A257AFL,4294967290UL,0x44669197L,4294967295UL,4294967295UL,0x44669197L,4294967290UL},{0UL,9UL,1UL,0UL,0x137CCD58L,0x137CCD58L,0UL}},{{4294967287UL,4294967290UL,4294967287UL,0x695EDF25L,4294967290UL,0UL,0UL},{9UL,0UL,0x8D1BF73EL,0UL,9UL,0x8D1BF73EL,0x48C0F9CBL},{4294967295UL,0UL,0x695EDF25L,4294967295UL,0x695EDF25L,0UL,4294967295UL}},{{1UL,0x48C0F9CBL,9UL,0x137CCD58L,0x48C0F9CBL,0x137CCD58L,9UL},{4294967295UL,4294967295UL,0x44669197L,4294967290UL,0x91A257AFL,0x44669197L,0x91A257AFL},{9UL,9UL,9UL,9UL,0x137CCD58L,1UL,9UL}},{{4294967287UL,0x91A257AFL,0x695EDF25L,0x695EDF25L,0x91A257AFL,4294967287UL,0UL},{0UL,9UL,0x8D1BF73EL,0x48C0F9CBL,0x48C0F9CBL,0x8D1BF73EL,9UL},{0x91A257AFL,0UL,4294967287UL,0x91A257AFL,0x695EDF25L,0x695EDF25L,0x91A257AFL}}};
    int32_t l_769 = 0x654BD667L;
    int32_t l_772 = (-1L);
    int32_t l_778 = 0x0C1AF16EL;
    int32_t l_781[9][2][10] = {{{6L,1L,6L,0x49BB807AL,1L,(-3L),(-3L),1L,0x49BB807AL,6L},{0x057DF74FL,0x057DF74FL,0x4D53C66FL,1L,2L,0x4D53C66FL,2L,1L,0x4D53C66FL,0x057DF74FL}},{{2L,(-3L),6L,2L,0x49BB807AL,0x49BB807AL,2L,6L,(-3L),2L},{6L,0x057DF74FL,(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL,(-3L),0x057DF74FL,6L,6L}},{{0x49BB807AL,(-3L),0x057DF74FL,6L,6L,0x057DF74FL,(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL},{6L,0x4D53C66FL,(-1L),6L,(-1L),0x4D53C66FL,6L,0x6A3BBE9BL,0x6A3BBE9BL,6L}},{{0x6A3BBE9BL,0x49BB807AL,(-1L),(-1L),0x49BB807AL,0x6A3BBE9BL,0x4D53C66FL,0x49BB807AL,0x4D53C66FL,0x6A3BBE9BL},{(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL,(-3L),0x057DF74FL,6L,6L,0x057DF74FL,(-3L)}},{{(-3L),0x4D53C66FL,0x4D53C66FL,(-3L),(-1L),0x6A3BBE9BL,(-3L),0x6A3BBE9BL,(-1L),(-3L)},{0x6A3BBE9BL,(-3L),0x6A3BBE9BL,(-1L),(-3L),0x4D53C66FL,0x4D53C66FL,(-3L),(-1L),0x6A3BBE9BL}},{{6L,6L,0x057DF74FL,(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL,(-3L),0x057DF74FL,6L},{0x49BB807AL,0x4D53C66FL,0x6A3BBE9BL,0x49BB807AL,(-1L),(-1L),0x49BB807AL,0x6A3BBE9BL,0x4D53C66FL,0x49BB807AL}},{{0x6A3BBE9BL,6L,0x4D53C66FL,(-1L),6L,(-1L),0x4D53C66FL,6L,0x6A3BBE9BL,0x6A3BBE9BL},{0x49BB807AL,(-3L),0x057DF74FL,6L,6L,0x057DF74FL,(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL}},{{6L,0x4D53C66FL,(-1L),6L,(-1L),0x4D53C66FL,6L,0x6A3BBE9BL,0x6A3BBE9BL,6L},{0x6A3BBE9BL,0x49BB807AL,(-1L),(-1L),0x49BB807AL,0x6A3BBE9BL,0x4D53C66FL,0x49BB807AL,0x4D53C66FL,0x6A3BBE9BL}},{{(-3L),0x49BB807AL,0x057DF74FL,0x49BB807AL,(-3L),0x057DF74FL,6L,6L,0x057DF74FL,(-3L)},{(-3L),0x4D53C66FL,0x4D53C66FL,(-3L),(-1L),0x6A3BBE9BL,(-3L),0x6A3BBE9BL,(-1L),(-3L)}}};
    int32_t l_783 = 0x2AFDC20AL;
    uint64_t **l_799 = (void*)0;
    int64_t l_818 = 0xB5271D173694B8E2LL;
    uint8_t **l_839 = &g_350[1];
    uint8_t ***l_838[4];
    uint64_t l_847[1][7] = {{1UL,7UL,1UL,1UL,7UL,1UL,1UL}};
    uint64_t l_897 = 0x0A38140524EAD01DLL;
    volatile int32_t *l_996[9] = {&g_2[3],&g_2[3],&g_3,&g_2[3],&g_2[3],&g_3,&g_2[3],&g_2[3],&g_3};
    union U1 *l_1000 = &l_588;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_838[i] = &l_839;
    for (p_36 = 0; (p_36 > 18); p_36 = safe_add_func_uint64_t_u_u(p_36, 1))
    { /* block id: 12 */
        int32_t *l_65 = &g_4[0];
        union U0 l_422 = {0};
        for (g_37.f2 = 0; (g_37.f2 > 6); ++g_37.f2)
        { /* block id: 15 */
            int32_t *l_55 = (void*)0;
            int32_t *l_56 = &g_57;
            int32_t *l_58 = &g_57;
            int32_t *l_59[2][7][3] = {{{&g_4[1],&g_4[4],&g_4[1]},{&g_4[3],&g_57,&g_57},{&g_57,&g_4[4],&g_4[3]},{&g_4[3],&g_4[3],&g_57},{&g_4[1],&g_4[1],&g_4[1]},{&g_4[3],&g_57,&g_10},{&g_57,&g_4[1],&g_4[3]}},{{&g_4[3],&g_4[3],&g_10},{&g_4[1],&g_4[4],&g_4[1]},{&g_4[3],&g_57,&g_57},{&g_57,&g_4[4],&g_4[3]},{&g_4[3],&g_4[3],&g_57},{&g_4[1],&g_4[1],&g_4[1]},{&g_4[3],&g_57,&g_10}}};
            const int32_t * const l_380 = &g_381;
            const int32_t * const *l_379 = &l_380;
            uint32_t l_418[9];
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_418[i] = 4294967295UL;
            ++l_60;
        }
    }
    if ((((safe_lshift_func_uint8_t_u_u(((l_410 = ((safe_add_func_uint64_t_u_u(0x45967417D791A89DLL, ((safe_mod_func_int32_t_s_s((l_410 > (((((**l_432) = (*g_342)) != (g_443 = &g_75)) <= ((safe_mul_func_int32_t_s_s(p_35, (l_446 == &g_267))) || ((p_36 , (safe_lshift_func_int32_t_s_s(0xCE88BC9AL, p_35))) ^ 0L))) , (*g_267))), l_413)) < l_449))) , 0xCDD0L)) >= p_33.f0), (*g_407))) ^ 9UL) > l_60))
    { /* block id: 171 */
        uint32_t l_452 = 0xD9B008D2L;
        int32_t l_472 = 0xB3827801L;
        int32_t l_473 = 0xB189075BL;
        uint64_t *l_474 = &g_235;
        int32_t *l_475[2][5][2] = {{{&l_410,&l_410},{&l_410,&l_411},{&g_262[4],(void*)0},{&l_411,(void*)0},{&g_262[4],&l_411}},{{&l_410,&l_410},{&l_410,&l_411},{&g_262[4],(void*)0},{&l_411,(void*)0},{&g_262[4],&l_411}}};
        int i, j, k;
        (*g_453) &= (safe_sub_func_int16_t_s_s(l_452, (0x9421CC5BL && 0x1E485413L)));
        p_32 = (safe_sub_func_int16_t_s_s((((*g_267) > p_34) < (-3L)), ((safe_add_func_int64_t_s_s(g_262[4], ((*l_474) &= (safe_mul_func_uint16_t_u_u(((l_473 = (safe_lshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_u(((+((1UL & (safe_mul_func_uint8_t_u_u(p_32, (safe_add_func_int8_t_s_s((l_472 = (safe_sub_func_uint8_t_u_u(((safe_unary_minus_func_uint16_t_u(((l_452 == ((g_100 ^ 0xE66D47B57BE5BDCALL) ^ g_195)) != 0x87L))) > g_283), 0x54L))), (*g_136)))))) , 0xBDB2L)) < (*g_267)), (*g_267))), 5))) , l_472), p_32))))) != 0x8E72DA09L)));
    }
    else
    { /* block id: 177 */
        uint32_t ****l_479 = &l_431;
        int32_t l_521[8][10][3] = {{{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L}},{{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L}},{{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L}},{{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L}},{{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L}},{{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L}},{{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L}},{{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L}}};
        union U1 *l_528 = &g_37;
        int32_t l_580 = (-1L);
        int32_t l_585 = (-10L);
        uint8_t l_689 = 0x9FL;
        uint8_t **l_725[5] = {&g_349,&g_349,&g_349,&g_349,&g_349};
        uint8_t ***l_724 = &l_725[4];
        uint8_t ****l_723 = &l_724;
        int8_t l_804 = 0xD8L;
        int32_t *l_872 = &g_37.f0;
        int32_t *l_873[1];
        int32_t l_951 = 0x53BF7712L;
        union U0 **l_957 = &g_368;
        int32_t l_962 = 7L;
        int16_t l_988 = 0x8EC5L;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_873[i] = &l_781[1][0][6];
        for (l_410 = 0; (l_410 <= 4); l_410 += 1)
        { /* block id: 180 */
            volatile int32_t *l_478 = &g_2[1];
            union U1 l_527 = {-2L};
            union U0 *l_554 = &g_369;
            uint16_t *l_556 = &g_50;
            uint8_t *l_635[3];
            uint32_t ****l_636 = &l_432;
            int32_t l_679 = 3L;
            uint64_t l_744 = 1UL;
            int32_t l_775 = 0x9F17F60AL;
            int32_t l_777[6][5][2] = {{{2L,8L},{4L,0xD58814BDL},{(-7L),(-6L)},{0x4156876EL,(-6L)},{(-7L),0xD58814BDL}},{{4L,8L},{2L,2L},{0xD58814BDL,0x4156876EL},{0xBB183ABFL,(-5L)},{(-2L),(-6L)}},{{0x9A975A27L,(-2L)},{0x2B4FD698L,(-7L)},{0x2B4FD698L,(-2L)},{0x9A975A27L,(-6L)},{(-2L),(-5L)}},{{0xBB183ABFL,0x4156876EL},{0xD58814BDL,2L},{2L,8L},{4L,0xD58814BDL},{(-7L),(-6L)}},{{0x4156876EL,(-6L)},{(-7L),0xD58814BDL},{4L,8L},{2L,2L},{0xD58814BDL,0x4156876EL}},{{0xBB183ABFL,(-5L)},{(-2L),(-6L)},{0x9A975A27L,(-2L)},{0x2B4FD698L,(-7L)},{0x2B4FD698L,(-2L)}}};
            uint8_t l_784 = 255UL;
            int64_t **l_808 = &g_180;
            int32_t l_816[7];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_635[i] = &g_195;
            for (i = 0; i < 7; i++)
                l_816[i] = 0x92F532AFL;
            for (g_37.f1 = 0; (g_37.f1 <= 8); g_37.f1 += 1)
            { /* block id: 183 */
                volatile int32_t *l_477[7][8][2] = {{{&g_3,(void*)0},{&g_2[0],&g_2[1]},{(void*)0,(void*)0},{&g_3,&g_3},{&g_3,&g_2[1]},{&g_2[1],&g_2[l_410]},{&g_2[1],(void*)0},{&g_2[1],&g_3}},{{(void*)0,(void*)0},{&g_2[l_410],&g_2[1]},{&g_3,(void*)0},{(void*)0,&g_2[0]},{&g_2[1],&g_2[3]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_2[l_410],&g_3}},{{&g_2[3],&g_3},{&g_3,(void*)0},{&g_2[l_410],(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_3,&g_2[l_410]},{&g_3,&g_2[l_410]},{(void*)0,&g_2[1]}},{{&g_3,&g_3},{(void*)0,&g_2[3]},{(void*)0,&g_2[1]},{&g_2[l_410],&g_2[1]},{(void*)0,(void*)0},{&g_3,&g_2[2]},{&g_2[1],(void*)0},{(void*)0,&g_2[3]}},{{(void*)0,(void*)0},{&g_2[3],&g_3},{&g_2[l_410],&g_2[1]},{(void*)0,(void*)0},{&g_3,&g_3},{&g_3,(void*)0},{(void*)0,(void*)0},{&g_2[1],&g_3}},{{&g_2[2],&g_2[2]},{(void*)0,&g_2[1]},{&g_3,&g_2[1]},{&g_2[l_410],&g_2[l_410]},{&g_2[2],&g_2[l_410]},{(void*)0,&g_2[l_410]},{&g_2[1],&g_3},{&g_3,&g_2[1]}},{{&g_2[3],&g_2[1]},{&g_2[3],&g_2[1]},{&g_3,&g_3},{&g_2[1],&g_2[l_410]},{(void*)0,&g_2[l_410]},{&g_2[2],&g_2[l_410]},{&g_2[l_410],&g_2[1]},{&g_3,&g_2[1]}}};
                volatile int32_t **l_476[5] = {&l_477[0][1][1],&l_477[0][1][1],&l_477[0][1][1],&l_477[0][1][1],&l_477[0][1][1]};
                uint16_t l_515 = 65535UL;
                uint16_t *l_555 = &g_369.f1;
                int32_t l_560[4][9][3];
                union U1 *l_571 = &l_527;
                int i, j, k;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 9; j++)
                    {
                        for (k = 0; k < 3; k++)
                            l_560[i][j][k] = (-5L);
                    }
                }
                l_478 = &g_2[l_410];
            }
            for (g_57 = 3; (g_57 >= 0); g_57 -= 1)
            { /* block id: 254 */
                int32_t *l_591 = &l_411;
                int32_t l_596[9][2][1] = {{{9L},{(-8L)}},{{0L},{0L}},{{(-8L)},{9L}},{{0L},{(-8L)}},{{0L},{9L}},{{(-8L)},{0L}},{{0L},{(-8L)}},{{9L},{0L}},{{(-8L)},{0L}}};
                uint16_t l_620[8][3][8] = {{{65526UL,65535UL,0x7B6CL,65526UL,5UL,65535UL,65535UL,65535UL},{1UL,0x63B3L,0x2EC8L,0x2EC8L,0x63B3L,1UL,0x6562L,0UL},{0x5D3FL,0UL,2UL,1UL,0xBFB5L,0x7B6CL,0x7A9DL,0x76F2L}},{{1UL,65535UL,0xA41DL,1UL,8UL,9UL,65531UL,0UL},{65535UL,8UL,0xC15CL,0x2EC8L,0x4F48L,5UL,65535UL,65535UL},{0UL,65535UL,0x5D3FL,65526UL,0xA491L,0UL,0x57A8L,0xA41DL}},{{0x7CEAL,0xD434L,0x830DL,65535UL,1UL,0xEEA3L,0x5D3FL,0UL},{3UL,0xCC45L,0x8116L,0xD1EAL,1UL,0UL,0UL,0x2B98L},{0x8B86L,65535UL,65526UL,1UL,0xD434L,0xBFB5L,65535UL,1UL}},{{0x4F48L,0x938EL,1UL,8UL,0UL,0UL,65535UL,8UL},{1UL,0xA491L,5UL,0xCC45L,0x8B86L,0xA41DL,0x7E42L,65535UL},{0xD313L,0xBFB5L,0xCAE0L,0x18B7L,65535UL,1UL,0x2EC8L,0x0577L}},{{65535UL,0x7A9DL,0x57A8L,65535UL,0x57A8L,0x7A9DL,65535UL,0xA491L},{1UL,65535UL,0x2EC8L,0x5D3FL,0x13B2L,65535UL,65526UL,0UL},{1UL,65535UL,0xA491L,0x0577L,0x13B2L,0xBFB5L,1UL,0UL}},{{0xE6B2L,0UL,8UL,0UL,9UL,0xA20FL,0x7B6CL,65535UL},{0x0577L,0x4F48L,0UL,0x938EL,0xB808L,0xC15CL,0x830DL,0x54A5L},{0xB59CL,0x13B2L,65535UL,1UL,0x7F9BL,0x7E42L,8UL,65535UL}},{{65535UL,0xB59CL,0x4F48L,0xA491L,5UL,65535UL,0xD313L,0x1F02L},{0xD313L,0UL,9UL,65535UL,0x938EL,1UL,0x7CEAL,0x63B3L},{0x7F9BL,0x1F02L,0x1808L,1UL,1UL,1UL,1UL,5UL}},{{0x18B7L,3UL,0xDEA5L,0x7F9BL,0x7CEAL,0x1F02L,0x63B3L,0xE6B2L},{0xEEA3L,65535UL,0xCAE0L,0x1F02L,1UL,0x2EC8L,65531UL,0x8116L},{65535UL,5UL,0xEEA3L,0xD313L,0xD313L,0xEEA3L,5UL,65535UL}}};
                int8_t *l_625 = &g_598;
                int i, j, k;
            }
            if (p_35)
                break;
            if (((*l_478) ^ (l_527.f0 && (l_722[3][2][3] | (*g_267)))))
            { /* block id: 341 */
                const union U0 *l_736[10] = {&g_369,&g_369,&g_369,&g_369,&g_369,&g_369,&g_369,&g_369,&g_369,&g_369};
                int8_t l_739 = 0xFDL;
                const int32_t l_748 = 0L;
                int i;
                (*g_726) = l_723;
                for (p_34 = 0; (p_34 <= 2); p_34 += 1)
                { /* block id: 345 */
                    int64_t *l_747 = &g_179[6];
                    int32_t *l_749 = &g_262[4];
                    int32_t *l_755[8] = {&l_413,&g_57,&l_413,&g_57,&l_413,&g_57,&l_413,&g_57};
                    int i;
                    if (((*l_749) = ((((((*l_747) ^= (safe_add_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((safe_sub_func_int64_t_s_s(1L, ((((void*)0 == l_736[6]) < l_580) < (safe_rshift_func_int32_t_s_u((((((l_739 = p_32) , (((((safe_mod_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((l_744 , (g_599 , 6UL)), (safe_mul_func_int8_t_s_s(((*g_136) = 7L), l_739)))), l_722[3][2][2])) <= l_739) >= (*l_478)) , p_34) | 1UL)) || p_34) , l_635[2]) != (void*)0), p_36))))), 6)), 0x98L)), 1L))) | p_35) < l_748) != p_34) & l_748)))
                    { /* block id: 350 */
                        int32_t **l_750 = (void*)0;
                        int32_t **l_751 = (void*)0;
                        int32_t **l_752 = &l_749;
                        int32_t **l_753 = (void*)0;
                        int32_t **l_754 = &g_403;
                        l_755[6] = ((*l_754) = ((*l_752) = ((*g_136) , &l_410)));
                        return g_37;
                    }
                    else
                    { /* block id: 355 */
                        (*l_478) = ((0x480E98D283F39FECLL == 18446744073709551609UL) > (*g_694));
                        return p_33;
                    }
                }
            }
            else
            { /* block id: 360 */
                int16_t l_758 = (-1L);
                int32_t l_768 = 0x740E523DL;
                int32_t l_770 = 6L;
                int32_t l_771 = 0xCED94427L;
                int32_t l_773 = (-2L);
                int32_t l_774 = 7L;
                int32_t l_776 = 0x516ACD0FL;
                int32_t l_779 = 1L;
                int32_t l_780 = (-1L);
                int32_t l_782 = 0xE47E6908L;
                uint64_t l_813 = 1UL;
                int32_t l_819 = (-1L);
                int32_t l_820 = 0xD7DF77C9L;
                for (p_33.f0 = 2; (p_33.f0 >= 0); p_33.f0 -= 1)
                { /* block id: 363 */
                    (*l_478) = (safe_sub_func_uint16_t_u_u(((-5L) > p_32), ((void*)0 != &g_180)));
                    (*l_478) &= l_521[6][1][1];
                    if (l_758)
                        continue;
                    if ((safe_div_func_uint16_t_u_u((g_4[3] ^ g_175), p_34)))
                    { /* block id: 367 */
                        union U1 **l_761 = (void*)0;
                        union U1 **l_762 = &l_528;
                        (*l_762) = &g_37;
                    }
                    else
                    { /* block id: 369 */
                        (*l_478) = l_585;
                    }
                    for (g_50 = 0; (g_50 <= 2); g_50 += 1)
                    { /* block id: 374 */
                        (*l_478) |= (safe_rshift_func_uint16_t_u_u(((void*)0 == &l_636), 2));
                        return g_37;
                    }
                }
                for (l_744 = 1; (l_744 <= 5); l_744 += 1)
                { /* block id: 381 */
                    int32_t *l_765 = &g_37.f0;
                    int32_t *l_766 = &l_580;
                    int32_t *l_767[10][10] = {{&l_527.f0,&l_527.f0,&l_413,&g_10,&l_679,&g_10,&l_413,&l_527.f0,&l_527.f0,&l_413},{&g_4[2],&g_10,&l_527.f0,&l_527.f0,&g_10,&g_4[2],&l_413,&g_4[2],&g_10,&l_527.f0},{(void*)0,&l_527.f0,(void*)0,&l_527.f0,&l_413,&l_413,&l_527.f0,(void*)0,&l_527.f0,(void*)0},{(void*)0,&g_4[2],&l_527.f0,&g_10,&l_527.f0,&g_4[2],(void*)0,(void*)0,&g_4[2],&l_527.f0},{&g_4[2],(void*)0,(void*)0,&g_4[2],&l_527.f0,&g_10,&l_527.f0,&g_4[2],(void*)0,(void*)0},{&l_527.f0,(void*)0,&l_527.f0,&l_413,&l_413,&l_527.f0,(void*)0,&l_527.f0,(void*)0,&l_527.f0},{&g_10,&g_4[2],&l_413,&g_4[2],&g_10,&l_527.f0,&l_527.f0,&g_10,&g_4[2],&l_413},{&l_527.f0,&l_527.f0,&l_413,&g_10,&l_679,&g_10,&l_413,&l_527.f0,&l_527.f0,&l_413},{&g_4[2],&g_10,&l_527.f0,&l_527.f0,&g_10,(void*)0,&l_527.f0,(void*)0,&l_527.f0,&l_413},{&g_10,&l_679,&g_10,&l_413,&l_527.f0,&l_527.f0,&l_413,&g_10,&l_679,&g_10}};
                    int64_t **l_810 = (void*)0;
                    int i, j;
                    ++l_784;
                    l_777[5][1][1] |= (safe_lshift_func_int16_t_s_s(p_35, (((((((*l_766) = p_33.f0) != ((*l_765) = (safe_div_func_uint16_t_u_u((safe_add_func_int32_t_s_s((0x6FL <= (((*g_481) == &g_405) && (+((((safe_mul_func_int8_t_s_s(1L, (safe_add_func_uint64_t_u_u(0xBBC64855098C238BLL, (safe_unary_minus_func_int8_t_s(((*g_267) || (g_10 , 65527UL)))))))) && p_36) , 0xC047L) | p_32)))), (-1L))), l_779)))) <= p_33.f0) , &g_694) != l_799) < (*g_136))));
                    for (l_449 = 0; (l_449 <= 2); l_449 += 1)
                    { /* block id: 388 */
                        int32_t l_800 = 0L;
                        int32_t l_801 = 0x227DC392L;
                        int32_t l_802[6][8] = {{0x4F305424L,0x4F305424L,0x63F7C9BBL,0x19A762C2L,0x63F7C9BBL,0x4F305424L,0x4F305424L,0x63F7C9BBL},{(-3L),0x63F7C9BBL,0x63F7C9BBL,(-3L),0x4BCBA6B8L,(-3L),0x63F7C9BBL,0x63F7C9BBL},{0x63F7C9BBL,0x4BCBA6B8L,0x19A762C2L,0x19A762C2L,0x4BCBA6B8L,0x63F7C9BBL,0x4BCBA6B8L,0x19A762C2L},{(-3L),0x4BCBA6B8L,(-3L),0x63F7C9BBL,0x63F7C9BBL,(-3L),0x4BCBA6B8L,(-3L)},{0x4F305424L,0x63F7C9BBL,0x19A762C2L,0x63F7C9BBL,0x4F305424L,0x4F305424L,0x63F7C9BBL,0x19A762C2L},{0x4F305424L,0x4F305424L,0x63F7C9BBL,0x19A762C2L,0x63F7C9BBL,0x4F305424L,0x4F305424L,0x63F7C9BBL}};
                        int32_t l_803[3][6] = {{(-1L),7L,(-1L),7L,(-1L),7L},{0x4CE6AB36L,7L,0x4CE6AB36L,7L,0x4CE6AB36L,7L},{(-1L),7L,(-1L),7L,(-1L),7L}};
                        int64_t ***l_809[7][4][6] = {{{(void*)0,&l_808,&l_808,(void*)0,&l_808,&l_808},{&l_808,(void*)0,&l_808,(void*)0,&l_808,&l_808},{(void*)0,&l_808,(void*)0,&l_808,&l_808,(void*)0},{&l_808,(void*)0,&l_808,&l_808,&l_808,(void*)0}},{{&l_808,&l_808,(void*)0,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{(void*)0,&l_808,&l_808,(void*)0,&l_808,&l_808}},{{&l_808,(void*)0,&l_808,(void*)0,&l_808,&l_808},{(void*)0,&l_808,(void*)0,&l_808,&l_808,(void*)0},{&l_808,(void*)0,&l_808,&l_808,&l_808,(void*)0},{&l_808,&l_808,(void*)0,&l_808,&l_808,&l_808}},{{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{(void*)0,&l_808,&l_808,(void*)0,&l_808,&l_808},{&l_808,(void*)0,&l_808,(void*)0,&l_808,&l_808}},{{(void*)0,&l_808,(void*)0,&l_808,&l_808,(void*)0},{&l_808,(void*)0,&l_808,&l_808,&l_808,(void*)0},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,(void*)0,&l_808}},{{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{(void*)0,&l_808,&l_808,&l_808,(void*)0,&l_808},{&l_808,&l_808,&l_808,&l_808,(void*)0,&l_808}},{{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808},{&l_808,&l_808,&l_808,&l_808,(void*)0,&l_808},{&l_808,&l_808,&l_808,&l_808,&l_808,&l_808}}};
                        int i, j, k;
                        --g_805;
                        if (p_33.f0)
                            break;
                        if ((*g_9))
                            continue;
                        l_810 = l_808;
                    }
                }
                for (l_721 = 0; (l_721 <= 2); l_721 += 1)
                { /* block id: 397 */
                    int32_t *l_811 = &l_773;
                    int32_t *l_812[6][3] = {{&l_780,(void*)0,&l_780},{&l_521[2][7][0],(void*)0,&l_521[2][7][0]},{&l_780,(void*)0,&l_780},{&l_521[2][7][0],(void*)0,&l_521[2][7][0]},{&l_780,(void*)0,&l_780},{&l_521[2][7][0],(void*)0,&l_521[2][7][0]}};
                    int i, j;
                    ++l_813;
                    g_821++;
                    for (l_804 = 0; (l_804 <= 2); l_804 += 1)
                    { /* block id: 402 */
                        return l_527;
                    }
                    for (l_413 = 2; (l_413 >= 0); l_413 -= 1)
                    { /* block id: 407 */
                        return l_588;
                    }
                }
            }
            for (p_35 = 2; (p_35 >= 0); p_35 -= 1)
            { /* block id: 414 */
                int32_t *l_826 = &l_778;
                uint8_t ***l_837 = &l_725[4];
                uint16_t *l_846[2];
                int32_t *l_850 = &l_588.f0;
                int i;
                for (i = 0; i < 2; i++)
                    l_846[i] = &g_369.f1;
                l_585 = ((*l_850) = (safe_add_func_int32_t_s_s(((*l_826) |= ((*g_267) < p_32)), (safe_div_func_uint8_t_u_u(((safe_add_func_int64_t_s_s(((safe_rshift_func_int64_t_s_u(((safe_div_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((0UL ^ (l_409 != (l_838[2] = l_837))) == ((p_34 >= ((((*g_694) = (safe_add_func_uint16_t_u_u(((*l_478) || (safe_rshift_func_uint8_t_u_s((~((((+18446744073709551615UL) || (++l_847[0][0])) ^ ((*l_478) == p_36)) ^ g_518)), 2))), 8L))) < 0x421756519CE6A302LL) == (*g_267))) >= 0xC17FL)), p_35)), l_521[1][7][2])) >= 0xBFL), 18)) || 0xB4L), (-4L))) | 0x5F6F67DF11A62C22LL), (*g_349))))));
                for (l_588.f3 = 2; (l_588.f3 >= 0); l_588.f3 -= 1)
                { /* block id: 423 */
                    int i, j, k;
                    (*l_826) ^= (-1L);
                }
            }
        }
        l_778 ^= (l_769 ^= (safe_div_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_s((safe_sub_func_int16_t_s_s((safe_mul_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(((l_580 , 1L) == (safe_mod_func_int8_t_s_s(((*g_136) ^= (-1L)), (((l_521[7][3][0] = (0x01A586E5L || ((safe_sub_func_uint32_t_u_u((((((((safe_sub_func_uint8_t_u_u(0UL, ((((!p_36) & (p_36 > (safe_mod_func_uint8_t_u_u(p_35, 7UL)))) || g_518) >= g_2[0]))) != p_34) == l_449) == p_35) < p_33.f0) , g_179[2]) >= 0xB971L), p_35)) & 0L))) != p_36) , 8UL)))), g_195)), l_804)), 1L)), g_179[6])) , l_689), p_32)));
        (*l_872) = (&l_804 == (((0x8EE43301CCF8637BLL | 0x2B762EB48C95E3B0LL) || (safe_mod_func_int32_t_s_s(p_35, 7UL))) , &l_804));
        for (l_769 = 1; (l_769 >= 0); l_769 -= 1)
        { /* block id: 435 */
            int32_t l_886 = 8L;
            uint32_t **l_908 = &g_443;
            int32_t *l_983 = &g_262[4];
            int64_t **l_992 = &g_180;
            int i;
            if (((*l_872) &= ((*g_453) = (g_2[l_769] != (safe_add_func_int8_t_s_s(((safe_mul_func_int8_t_s_s((safe_sub_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((safe_mul_func_uint64_t_u_u((*g_694), l_886)), (safe_mul_func_int8_t_s_s((safe_sub_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_s(((((safe_div_func_int64_t_s_s((safe_add_func_uint16_t_u_u(l_897, (((safe_lshift_func_int64_t_s_s((safe_mul_func_uint64_t_u_u(((p_34 , ((safe_lshift_func_int64_t_s_u((safe_lshift_func_int16_t_s_s((-10L), ((((safe_mul_func_int16_t_s_s(((p_34 & (*g_267)) | ((((*g_267) >= g_179[6]) | 0x68970C5CDE1377EALL) != p_36)), (*g_267))) && (*g_267)) , 0x2A41L) , g_598))), 16)) || 18446744073709551610UL)) <= p_33.f0), 0x3161826EFA85ECC0LL)), 10)) , p_33.f0) == (*g_349)))), p_34)) && p_33.f0) , l_908) == l_908), g_909)) , l_886) && g_4[2]), p_33.f0)), 0xF0L)))), p_36)), 2L)) || p_35), (*g_136)))))))
            { /* block id: 438 */
                int16_t l_912 = 3L;
                uint32_t l_924 = 4294967295UL;
                int8_t l_927 = 0x15L;
                int32_t l_928 = 0xB1DD07A4L;
                uint64_t l_931 = 0xFD2372F8FA8CC906LL;
                int32_t *l_934 = &l_413;
                union U0 l_967 = {0};
                uint32_t **l_987 = &g_443;
                uint32_t l_989 = 4294967295UL;
                if ((((*g_136) = (safe_lshift_func_uint32_t_u_u(l_912, 2))) ^ 0x5FL))
                { /* block id: 440 */
                    if (p_34)
                        break;
                    (*g_913) = &p_35;
                    return p_33;
                }
                else
                { /* block id: 444 */
                    if (p_33.f0)
                        break;
                    p_35 = (p_33.f0 |= ((*l_872) = p_35));
                }
                p_35 &= l_847[0][0];
                for (l_411 = 0; (l_411 <= 1); l_411 += 1)
                { /* block id: 453 */
                    int32_t l_932 = 0xEC520777L;
                    const uint32_t *l_945 = &g_175;
                    int32_t l_952 = 1L;
                    union U0 *l_980 = (void*)0;
                    int8_t **l_981 = (void*)0;
                    int8_t **l_982 = &g_136;
                    if (l_912)
                    { /* block id: 454 */
                        const uint64_t l_929 = 0xE674A39B03CCDB3CLL;
                        int32_t **l_933[10][4] = {{(void*)0,(void*)0,&l_873[0],&l_872},{(void*)0,&l_873[0],&g_403,&l_873[0]},{(void*)0,(void*)0,&l_872,&l_873[0]},{&l_872,&l_873[0],&l_872,&l_872},{&l_872,(void*)0,&g_403,&l_872},{(void*)0,&l_872,&l_873[0],(void*)0},{&l_872,&l_873[0],&l_873[0],&l_873[0]},{(void*)0,(void*)0,&g_403,&l_873[0]},{&l_872,&l_873[0],&l_872,(void*)0},{&l_872,(void*)0,&l_872,&l_872}};
                        int i, j;
                        (*l_872) = (0x2BAAAB67L | ((safe_div_func_uint32_t_u_u(((*g_443) = (+(((l_932 &= (((*g_267) = ((safe_rshift_func_int32_t_s_s((&p_32 == (((safe_mod_func_int16_t_s_s(((safe_unary_minus_func_int64_t_s(((((p_35 >= (l_886 != (l_928 = (safe_div_func_int16_t_s_s(((g_283 |= ((*g_267) < l_924)) && ((p_36 < (((safe_rshift_func_uint16_t_u_s((*g_267), 10)) , &g_283) == (void*)0)) | 0xDAA8L)), l_927))))) > 0x53CBL) == l_929) >= p_36))) && (*l_872)), g_930)) | l_929) , &p_35)), g_817)) < l_931)) && (*g_267))) <= (*l_872)) && (-1L)))), l_927)) | (*l_872)));
                        l_934 = &p_35;
                        if ((*g_453))
                            continue;
                        l_873[0] = (*g_913);
                    }
                    else
                    { /* block id: 464 */
                        if ((*g_453))
                            break;
                    }
                }
                for (l_411 = 4; (l_411 >= 0); l_411 -= 1)
                { /* block id: 507 */
                    int64_t **l_993 = &g_180;
                    l_989++;
                    if ((l_992 != l_993))
                    { /* block id: 509 */
                        volatile int32_t *l_995 = &g_3;
                        volatile int32_t **l_994[3][2] = {{&l_995,&l_995},{&l_995,&l_995},{&l_995,&l_995}};
                        int i, j;
                        (*l_872) ^= (-6L);
                        l_996[8] = &g_2[l_411];
                    }
                    else
                    { /* block id: 512 */
                        (*l_983) ^= ((void*)0 == l_908);
                    }
                    (*l_934) ^= (*g_9);
                    for (l_543 = 0; (l_543 <= 6); l_543 += 1)
                    { /* block id: 518 */
                        int32_t **l_998[4][4][1] = {{{&l_872},{&l_983},{&l_872},{&l_983}},{{&l_872},{&l_983},{&l_872},{&l_983}},{{&l_872},{&l_983},{&l_872},{&l_983}},{{&l_872},{&l_983},{&l_872},{&l_983}}};
                        int i, j, k;
                        (*g_997) = (*g_421);
                        (*g_913) = (*g_997);
                    }
                }
            }
            else
            { /* block id: 523 */
                union U1 **l_999[8][5][3] = {{{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528}},{{&l_528,&l_528,(void*)0},{(void*)0,&l_528,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528}},{{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528}},{{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528},{(void*)0,&l_528,&l_528},{&l_528,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528}},{{&l_528,&l_528,(void*)0},{&l_528,(void*)0,&l_528},{&l_528,(void*)0,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0}},{{&l_528,&l_528,&l_528},{(void*)0,&l_528,&l_528},{&l_528,(void*)0,(void*)0},{(void*)0,(void*)0,&l_528},{&l_528,&l_528,&l_528}},{{&l_528,&l_528,(void*)0},{&l_528,&l_528,&l_528},{&l_528,&l_528,&l_528},{&l_528,&l_528,(void*)0},{&l_528,(void*)0,&l_528}}};
                int i, j, k;
                l_1000 = &p_33;
                return g_37;
            }
        }
    }
    return g_37;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_75 g_50 g_9 g_10 g_4 g_37.f2 g_3 g_100 g_136 g_137 g_2 g_131 g_175 g_195 g_235 g_170 g_262 g_179 g_342 g_37 g_349
 * writes: g_75 g_131 g_57 g_137 g_175 g_179 g_180 g_2 g_170 g_195 g_136 g_235 g_262 g_267 g_283 g_349 g_350 g_368
 */
static uint32_t  func_63(int32_t * p_64)
{ /* block id: 17 */
    const int16_t l_71[6] = {0xD189L,(-1L),(-1L),0xD189L,(-1L),(-1L)};
    uint32_t *l_74 = &g_75;
    const int8_t *l_99 = &g_100;
    uint32_t *l_199 = &g_175;
    uint32_t **l_198 = &l_199;
    int8_t **l_202 = &g_136;
    int64_t *l_203 = (void*)0;
    int64_t *l_204 = (void*)0;
    int32_t l_205 = 0L;
    uint16_t *l_206 = &g_50;
    int32_t *l_261 = &g_262[4];
    int32_t l_270 = 0L;
    int16_t l_291 = 0L;
    int32_t l_294 = 0L;
    int32_t l_295 = 0L;
    uint8_t l_296[10][6] = {{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL}};
    uint32_t *l_314 = &g_175;
    uint32_t l_353 = 0x207AB9D6L;
    union U0 l_360[9][3][9] = {{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}}};
    uint16_t l_365 = 0x0AACL;
    union U0 *l_367 = (void*)0;
    union U0 **l_366[9][2];
    uint8_t l_370 = 0UL;
    int i, j, k;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
            l_366[i][j] = &l_367;
    }
    if (((*l_261) |= func_66(l_71[2], (g_57 , (safe_sub_func_int64_t_s_s((l_205 = (((*l_74)--) | (((*l_202) = func_78(g_50, ((*l_198) = (func_82(func_84((safe_div_func_uint8_t_u_u(0x46L, l_71[1])), ((((!0x55EA0D0AL) != (safe_sub_func_int32_t_s_s((*g_9), (safe_sub_func_int8_t_s_s(1L, ((safe_rshift_func_uint8_t_u_s((0x7464L || l_71[2]), 1)) | g_10)))))) >= (*p_64)) && 0L), l_99, l_71[2], g_37.f2)) , (void*)0)), l_71[2])) == &g_100))), l_71[2]))), l_206, l_74)))
    { /* block id: 93 */
        uint16_t *l_265[9][5] = {{(void*)0,&g_50,&g_50,&g_50,&g_50},{(void*)0,(void*)0,&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50,(void*)0,&g_50},{&g_50,(void*)0,&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50,(void*)0,&g_50}};
        uint16_t **l_266 = (void*)0;
        int32_t l_268 = 0L;
        int16_t *l_282 = &g_283;
        int32_t l_284 = 0L;
        int32_t l_285 = (-2L);
        int32_t l_287 = 0x15ADDF4BL;
        int32_t l_288 = (-5L);
        int32_t l_289 = 7L;
        int32_t l_290 = 0x0F418198L;
        int32_t l_292 = 0x9FCA5432L;
        int32_t l_293[1];
        int i, j;
        for (i = 0; i < 1; i++)
            l_293[i] = 0x224E523FL;
        if ((((*l_261) >= (safe_add_func_uint16_t_u_u(((1UL > ((((g_267 = l_265[3][3]) == l_265[8][3]) , l_268) <= (safe_unary_minus_func_uint16_t_u(0x364DL)))) ^ l_270), (safe_mul_func_uint16_t_u_u((l_285 ^= (((safe_sub_func_uint64_t_u_u((safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((*l_282) = (!((safe_add_func_int16_t_s_s((g_262[2] <= l_268), 0L)) & 0x0133L))), l_268)), 0L)), l_284)) == 0xFA98CA15L) == l_284)), g_10))))) && 0x40C61073L))
        { /* block id: 97 */
            int32_t *l_286[10] = {&l_268,&g_4[3],&g_4[3],&l_268,&l_285,&l_268,&g_4[3],&g_4[3],&l_268,&l_285};
            const int16_t l_311 = 0L;
            int64_t *l_312 = &g_179[6];
            int i;
            --l_296[8][4];
            l_295 ^= ((~(l_288 < (((safe_mod_func_uint8_t_u_u(g_137[1], ((safe_unary_minus_func_int32_t_s((*p_64))) & ((g_195 && l_289) == (((safe_add_func_uint16_t_u_u(((*l_261) | (safe_mod_func_int64_t_s_s(((*l_312) ^= (g_100 >= (safe_rshift_func_uint64_t_u_s(l_311, 59)))), (safe_unary_minus_func_uint64_t_u((l_314 == (void*)0)))))), g_137[4])) ^ (*l_261)) == g_137[0]))))) >= l_287) , l_284))) & 4UL);
        }
        else
        { /* block id: 101 */
            int32_t **l_315 = &l_261;
            (*l_315) = &l_295;
        }
        (*l_261) = ((void*)0 == &g_9);
        (*l_261) = (*g_9);
    }
    else
    { /* block id: 106 */
        uint32_t l_319[10][8] = {{4UL,18446744073709551609UL,1UL,1UL,18446744073709551609UL,4UL,0UL,0x54FCF9FCL},{0xE61DC0C7L,0x0FB07EE7L,1UL,18446744073709551609UL,0UL,3UL,0UL,0x0FB07EE7L},{0x0A8462B8L,0UL,0UL,18446744073709551609UL,0x54FCF9FCL,0x3A9D8E90L,0xAF26B099L,0x54FCF9FCL},{1UL,0x54FCF9FCL,0xEDBF72F5L,1UL,0x0A8462B8L,0x0FB07EE7L,0xCB2800C3L,0xE61DC0C7L},{0UL,1UL,1UL,0xAF26B099L,1UL,1UL,0UL,0UL},{18446744073709551615UL,1UL,0UL,0x77AF8241L,18446744073709551615UL,0x8D062888L,0x77AF8241L,0UL},{0xEDBF72F5L,0x54FCF9FCL,1UL,1UL,18446744073709551615UL,0xCB2800C3L,4UL,0xAF26B099L},{18446744073709551615UL,1UL,1UL,0UL,1UL,3UL,0x54FCF9FCL,0xCB2800C3L},{0UL,18446744073709551615UL,1UL,0x0A8462B8L,0x0A8462B8L,1UL,18446744073709551615UL,0UL},{1UL,18446744073709551609UL,4UL,0UL,0x54FCF9FCL,1UL,0xEDBF72F5L,0x77AF8241L}};
        int16_t l_344 = (-4L);
        union U1 l_346 = {0x5CE0B114L};
        int32_t l_351 = (-2L);
        int i, j;
        for (l_294 = (-21); (l_294 != (-28)); l_294--)
        { /* block id: 109 */
            int32_t *l_318 = &l_205;
            int16_t *l_324 = &l_291;
            uint8_t *l_332 = &l_296[8][4];
            uint16_t l_335 = 65535UL;
            uint32_t **l_341 = (void*)0;
            uint64_t *l_345 = &g_235;
            uint8_t **l_347 = (void*)0;
            uint8_t **l_348[7] = {&l_332,&l_332,&l_332,&l_332,&l_332,&l_332,&l_332};
            int32_t *l_352 = &g_57;
            int i;
            ++l_319[0][2];
            (*l_352) ^= (safe_mod_func_uint8_t_u_u((&g_283 == l_324), (safe_mod_func_int32_t_s_s((((((safe_mod_func_int32_t_s_s((((g_350[1] = (g_349 = (((((~((((void*)0 == (*l_202)) <= ((*l_345) ^= (safe_add_func_uint32_t_u_u(((((((*l_261) &= ((*l_332) = g_4[3])) != ((safe_add_func_uint8_t_u_u(0x70L, l_335)) == (g_2[1] != (!(safe_add_func_uint32_t_u_u((((safe_sub_func_int64_t_s_s(((l_341 != g_342) & 0x0AL), g_50)) , 1L) , l_344), g_137[0])))))) >= g_131) < g_195) != 0x4CL), 0xEB92BA8EL)))) ^ l_295)) , (-1L)) != 0x220542C8L) , l_346) , &l_296[1][1]))) == &g_195) , l_351), (*p_64))) , l_346.f0) | 6L) || (*p_64)) | (*l_318)), (*l_318)))));
            l_353 = l_319[0][2];
        }
        for (g_175 = (-21); (g_175 == 36); g_175++)
        { /* block id: 121 */
            (*l_261) = (*p_64);
            for (g_235 = (-28); (g_235 >= 55); g_235++)
            { /* block id: 125 */
                (*l_261) |= (*p_64);
            }
            (*l_261) ^= ((void*)0 == &l_199);
        }
    }
    (*l_261) = (safe_add_func_uint64_t_u_u((8L >= (l_360[1][0][1] , (0x14BD3B3BL <= (safe_rshift_func_int8_t_s_u((g_37 , ((++(*g_349)) ^ l_365)), (9L > 9UL)))))), ((*l_261) != 65535UL)));
    g_368 = &l_360[7][0][1];
    return l_370;
}


/* ------------------------------------------ */
/* 
 * reads : g_50 g_4 g_137 g_2 g_75 g_131 g_235 g_175 g_170
 * writes: g_75 g_131 g_235 g_57 g_136 g_170
 */
static int32_t  func_66(const int64_t  p_67, uint64_t  p_68, uint16_t * p_69, int32_t * p_70)
{ /* block id: 62 */
    uint8_t l_207 = 0x30L;
    int16_t l_219 = 0xF869L;
    int32_t l_224[8][8] = {{0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL},{0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L},{0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL},{0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL},{0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L},{0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL},{0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,0xC2F5E6F3L,0x5F2AE77BL,0xC2F5E6F3L,(-1L),0xC2F5E6F3L},{0xC2F5E6F3L,(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L),0xC2F5E6F3L,(-1L)}};
    int32_t l_225[6][7] = {{0x7B1761CDL,0x7B1761CDL,0x68153D3BL,0x7B1761CDL,0x7B1761CDL,0x68153D3BL,0x7B1761CDL},{0x70B35F69L,0x77A5DD5BL,6L,(-8L),6L,0x77A5DD5BL,0x70B35F69L},{(-1L),0x7B1761CDL,(-1L),(-1L),0x7B1761CDL,(-1L),(-1L)},{0x70B35F69L,(-8L),0x52E2E74AL,(-8L),0x70B35F69L,0x2F718E48L,0x70B35F69L},{0x7B1761CDL,(-1L),(-1L),0x7B1761CDL,(-1L),(-1L),0x7B1761CDL},{6L,(-8L),6L,0x77A5DD5BL,0x70B35F69L,0x77A5DD5BL,6L}};
    int64_t l_227 = 0L;
    uint64_t *l_234 = &g_235;
    uint8_t *l_250 = &l_207;
    uint32_t *l_251 = &g_175;
    int8_t **l_252 = &g_136;
    volatile int32_t *l_260 = (void*)0;
    volatile int32_t **l_259 = &l_260;
    int i, j;
    if ((((l_225[1][5] = (l_207 && (0xD11F0E80B645F29CLL || ((l_207 & (safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s(((+((-2L) || (safe_div_func_uint32_t_u_u(((void*)0 == &g_136), (l_224[0][0] ^= ((safe_rshift_func_uint16_t_u_s((((safe_sub_func_uint32_t_u_u(l_219, (safe_rshift_func_int16_t_s_s(((0L != (safe_lshift_func_uint32_t_u_u(((*p_69) < 1L), g_4[0]))) || g_137[5]), l_207)))) != g_2[1]) >= l_219), 2)) && 0x73B9L)))))) , l_224[0][0]), p_68)), 0L))) , p_68)))) <= l_219) > 4294967289UL))
    { /* block id: 65 */
        l_225[5][6] |= l_224[2][4];
        (*p_70) |= (+l_227);
        (*p_70) |= 0x49479A41L;
    }
    else
    { /* block id: 69 */
lbl_255:
        for (g_131 = (-29); (g_131 > 29); ++g_131)
        { /* block id: 72 */
            (*p_70) = (*p_70);
        }
        return (*p_70);
    }
    (*p_70) = (safe_div_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((((*l_252) = func_78((((*l_234)++) | ((((safe_sub_func_int8_t_s_s(l_219, (0xC4L > (safe_lshift_func_uint64_t_u_u((safe_add_func_int8_t_s_s((p_67 || (-2L)), (safe_mod_func_uint32_t_u_u((g_75 , (p_68 | ((*p_70) , ((*l_250) |= (safe_rshift_func_int16_t_s_u((g_175 != (safe_add_func_uint64_t_u_u((((*p_70) ^= 0xDFA724B1L) , l_227), l_219))), 4)))))), l_224[2][4])))), g_137[0]))))) >= p_67) & (-9L)) <= l_225[1][5])), l_251, p_67)) == &g_100), l_225[1][5])) > p_67), p_67));
    for (g_170 = 0; (g_170 != (-24)); g_170 = safe_sub_func_uint64_t_u_u(g_170, 6))
    { /* block id: 84 */
        uint32_t *l_257 = &g_175;
        uint32_t **l_256 = &l_257;
        uint32_t ***l_258 = &l_256;
        if (g_235)
            goto lbl_255;
        (*p_70) |= (l_251 == ((*l_256) = &g_175));
        (*l_258) = &l_251;
    }
    (*l_259) = &g_3;
    return (*p_70);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_57
 */
static int8_t * func_78(uint8_t  p_79, uint32_t * p_80, uint32_t  p_81)
{ /* block id: 57 */
    int32_t *l_200 = &g_57;
    int8_t *l_201 = &g_137[3];
    (*l_200) = ((void*)0 == &g_9);
    return l_201;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_10 g_57 g_136 g_137 g_50 g_4 g_100 g_2 g_131 g_175 g_3 g_195
 * writes: g_57 g_137 g_175 g_179 g_180 g_2 g_170 g_195
 */
static int16_t  func_82(int8_t * p_83)
{ /* block id: 24 */
    int32_t *l_138 = &g_57;
    uint16_t *l_168 = &g_50;
    int8_t *l_169 = &g_170;
    uint32_t l_171 = 18446744073709551613UL;
    int32_t * const l_173 = (void*)0;
    const int32_t l_177 = 0x9EEEF0C4L;
    int64_t *l_181[1];
    int8_t l_185 = 0L;
    int32_t l_187 = (-5L);
    int32_t l_188 = (-4L);
    int32_t l_189[8] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
    int i;
    for (i = 0; i < 1; i++)
        l_181[i] = &g_179[6];
    (*l_138) ^= (*g_9);
    for (g_57 = 0; (g_57 <= 4); g_57 += 1)
    { /* block id: 28 */
        int32_t *l_156 = &g_4[3];
        int32_t **l_155 = &l_156;
        int32_t l_172 = 0x8761BCA9L;
        uint32_t *l_174[9] = {&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175};
        int32_t *l_176 = &l_172;
        union U0 l_193 = {0};
        uint8_t *l_194 = &g_195;
        int i;
        if ((((((safe_add_func_uint32_t_u_u((safe_mod_func_int8_t_s_s(((*g_136) &= 0xBFL), (safe_add_func_uint16_t_u_u(((*l_138) | (safe_lshift_func_int32_t_s_s(((*l_176) = (g_50 && (g_175 ^= (safe_mod_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(((safe_lshift_func_int64_t_s_u(((*l_138) <= ((safe_mul_func_uint16_t_u_u((((*l_155) = &g_10) != ((safe_mul_func_uint64_t_u_u(g_10, (((((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint64_t_u_s((safe_mod_func_uint32_t_u_u((((safe_lshift_func_int16_t_s_u(((!((void*)0 != l_168)) | (l_169 != (void*)0)), g_4[3])) <= g_100) , (*l_138)), (*l_138))), 38)), l_171)) < (*l_138)) && g_2[4]) && (*l_138)) <= l_172))) , l_173)), l_172)) ^ 0xE7CEL)), g_131)) || 0xCA490DA0L), 4)), l_172))))), (*l_138)))), 0L)))), 0x801A4E0CL)) == l_177) | g_50) && g_3) && (*g_9)))
        { /* block id: 33 */
            int64_t *l_178 = &g_179[6];
            int i;
            g_2[g_57] = (((*l_178) = (*l_156)) || ((g_180 = l_178) == l_181[0]));
        }
        else
        { /* block id: 37 */
            int32_t *l_182 = (void*)0;
            int32_t *l_183 = &l_172;
            int32_t *l_184 = &l_172;
            int32_t *l_186[10][10][2] = {{{(void*)0,&g_10},{&l_172,&g_10},{&g_10,&g_57},{&g_10,(void*)0},{(void*)0,&l_172},{&g_4[3],&g_4[2]},{(void*)0,&g_10},{&g_4[4],&g_10},{&l_172,(void*)0},{(void*)0,(void*)0}},{{&l_172,&g_10},{&g_4[4],&g_10},{(void*)0,&g_4[2]},{&g_4[3],&l_172},{(void*)0,(void*)0},{&g_10,&g_57},{&g_10,&g_10},{&l_172,&g_10},{(void*)0,&g_10},{(void*)0,(void*)0}},{{&g_4[3],(void*)0},{&g_10,&g_10},{&g_10,(void*)0},{&g_4[3],(void*)0},{(void*)0,&g_10},{(void*)0,&g_10},{&l_172,&g_10},{&g_10,&g_57},{&g_10,(void*)0},{(void*)0,&l_172}},{{&g_4[3],&g_4[2]},{(void*)0,&g_10},{&g_4[4],&g_10},{&l_172,(void*)0},{(void*)0,(void*)0},{&l_172,&g_10},{&g_4[4],&g_10},{(void*)0,&g_4[2]},{&g_4[3],&l_172},{(void*)0,(void*)0}},{{&g_10,&g_57},{&g_10,&g_10},{&l_172,&g_10},{(void*)0,&g_10},{(void*)0,(void*)0},{&g_4[3],(void*)0},{&g_10,&g_10},{&g_10,(void*)0},{&g_4[3],(void*)0},{(void*)0,&g_10}},{{(void*)0,&g_10},{&l_172,&g_10},{&g_10,&g_57},{&g_10,(void*)0},{(void*)0,&l_172},{&g_4[3],&g_4[2]},{(void*)0,&g_10},{&g_4[4],&g_10},{&l_172,(void*)0},{(void*)0,(void*)0}},{{&l_172,&g_10},{&g_4[2],(void*)0},{&g_57,(void*)0},{&g_4[2],&l_172},{&l_172,&g_10},{&l_172,&g_10},{(void*)0,(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{&l_172,&g_4[4]}},{{(void*)0,&l_172},{&g_10,(void*)0},{&g_10,&l_172},{(void*)0,&g_4[4]},{&l_172,(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{(void*)0,&g_10},{&l_172,&g_10},{&l_172,&l_172}},{{&g_4[2],(void*)0},{&g_57,(void*)0},{&g_4[2],&g_4[3]},{&g_4[3],&g_10},{&l_172,&g_10},{&g_4[3],&g_4[3]},{&g_4[2],(void*)0},{&g_57,(void*)0},{&g_4[2],&l_172},{&l_172,&g_10}},{{&l_172,&g_10},{(void*)0,(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{&l_172,&g_4[4]},{(void*)0,&l_172},{&g_10,(void*)0},{&g_10,&l_172},{(void*)0,&g_4[4]},{&l_172,(void*)0}}};
            uint16_t l_190 = 7UL;
            int i, j, k;
            l_190++;
            if ((*g_9))
                break;
            for (g_170 = 0; (g_170 <= 6); g_170 += 1)
            { /* block id: 42 */
                int i;
                return g_137[(g_57 + 1)];
            }
        }
        (*l_176) = (*l_176);
        (*l_176) = (((*l_194) |= ((*g_9) && (l_193 , 0xF1D82268L))) && 0x18L);
    }
    for (l_171 = (-24); (l_171 < 14); ++l_171)
    { /* block id: 52 */
        return g_50;
    }
    return (*l_138);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_10 g_50 g_100 g_57 g_136
 * writes: g_131 g_57
 */
static int8_t * func_84(uint64_t  p_85, int32_t  p_86, const int8_t * p_87, uint16_t  p_88, const int32_t  p_89)
{ /* block id: 19 */
    uint64_t l_129[10][3][3] = {{{0x9F478261C1CA3632LL,0x49D53036CC05FD73LL,0x28B7FD9B51ECC885LL},{0UL,18446744073709551608UL,0x58AA494CAA1C64ACLL},{0xCFB248F24B1200BALL,18446744073709551608UL,0x49D53036CC05FD73LL}},{{4UL,0x49D53036CC05FD73LL,0x8C5D29228E1FC50ALL},{0x4B6C92F0D9F09F7ALL,18446744073709551608UL,18446744073709551615UL},{18446744073709551612UL,18446744073709551608UL,0xD564CE3E23DE179BLL}},{{0x25C50F45F4D98BCDLL,0x49D53036CC05FD73LL,0x2BF48DF11712D94BLL},{0xA13A23B15C07A264LL,18446744073709551608UL,1UL},{0UL,18446744073709551608UL,18446744073709551608UL}},{{0x9F478261C1CA3632LL,0x49D53036CC05FD73LL,0x28B7FD9B51ECC885LL},{0UL,18446744073709551608UL,0x58AA494CAA1C64ACLL},{0xCFB248F24B1200BALL,18446744073709551608UL,0x49D53036CC05FD73LL}},{{4UL,0x49D53036CC05FD73LL,0x8C5D29228E1FC50ALL},{0x4B6C92F0D9F09F7ALL,18446744073709551608UL,18446744073709551615UL},{18446744073709551612UL,18446744073709551608UL,0xD564CE3E23DE179BLL}},{{0x25C50F45F4D98BCDLL,0x49D53036CC05FD73LL,0x2BF48DF11712D94BLL},{0xA13A23B15C07A264LL,18446744073709551608UL,1UL},{0UL,18446744073709551608UL,18446744073709551608UL}},{{0x9F478261C1CA3632LL,0x49D53036CC05FD73LL,0x28B7FD9B51ECC885LL},{0UL,18446744073709551608UL,0x58AA494CAA1C64ACLL},{0xCFB248F24B1200BALL,18446744073709551608UL,0x49D53036CC05FD73LL}},{{4UL,0x49D53036CC05FD73LL,0x8C5D29228E1FC50ALL},{0x4B6C92F0D9F09F7ALL,18446744073709551608UL,18446744073709551615UL},{18446744073709551612UL,18446744073709551608UL,0xD564CE3E23DE179BLL}},{{0x25C50F45F4D98BCDLL,0x49D53036CC05FD73LL,0x2BF48DF11712D94BLL},{0xA13A23B15C07A264LL,18446744073709551608UL,1UL},{0UL,18446744073709551608UL,18446744073709551608UL}},{{0x9F478261C1CA3632LL,0x49D53036CC05FD73LL,0x28B7FD9B51ECC885LL},{0UL,18446744073709551608UL,0x58AA494CAA1C64ACLL},{0xCFB248F24B1200BALL,18446744073709551608UL,0x49D53036CC05FD73LL}}};
    uint16_t *l_130 = (void*)0;
    int8_t l_134 = 1L;
    int32_t *l_135[4] = {&g_57,&g_57,&g_57,&g_57};
    int i, j, k;
    g_57 ^= (safe_div_func_int16_t_s_s((safe_add_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_add_func_int32_t_s_s((g_3 <= (safe_unary_minus_func_int8_t_s(((~((l_134 = (safe_lshift_func_int16_t_s_s((((~(0x11FE8BE9L ^ (((safe_unary_minus_func_int16_t_s((safe_mul_func_int16_t_s_s((0x51C8L || (safe_rshift_func_uint64_t_u_s((((g_4[3] || (safe_sub_func_int64_t_s_s((safe_sub_func_int64_t_s_s((g_4[3] && (safe_add_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_u(((p_87 != p_87) , (g_131 = l_129[0][2][0])), ((((safe_mul_func_uint64_t_u_u((0UL | 0xB25B5FE4L), 0x49914032C2DE0B6ALL)) || 0xACL) , p_86) < l_129[0][2][0]))) | g_10), p_86))), p_86)), l_129[0][2][0]))) , &p_88) == &g_50), 29))), 65535UL)))) < 0x996C8B9E1FA26B9DLL) && 0x02L))) <= 0xEC0817FF2A7570BALL) & l_129[6][1][2]), 7))) , p_85)) >= g_50)))), l_129[9][2][0])), 0x83L)), 0UL)), 0x5444L)), g_100));
    return g_136;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_37.f0, "g_37.f0", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_137[i], "g_137[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_179[i], "g_179[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_195, "g_195", print_hash_value);
    transparent_crc(g_235, "g_235", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_262[i], "g_262[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_283, "g_283", print_hash_value);
    transparent_crc(g_381, "g_381", print_hash_value);
    transparent_crc(g_408, "g_408", print_hash_value);
    transparent_crc(g_518, "g_518", print_hash_value);
    transparent_crc(g_598, "g_598", print_hash_value);
    transparent_crc(g_599, "g_599", print_hash_value);
    transparent_crc(g_805, "g_805", print_hash_value);
    transparent_crc(g_817, "g_817", print_hash_value);
    transparent_crc(g_821, "g_821", print_hash_value);
    transparent_crc(g_909, "g_909", print_hash_value);
    transparent_crc(g_930, "g_930", print_hash_value);
    transparent_crc(g_1045, "g_1045", print_hash_value);
    transparent_crc(g_1051, "g_1051", print_hash_value);
    transparent_crc(g_1090, "g_1090", print_hash_value);
    transparent_crc(g_1097.f0, "g_1097.f0", print_hash_value);
    transparent_crc(g_1106, "g_1106", print_hash_value);
    transparent_crc(g_1110, "g_1110", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1162[i], "g_1162[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1173[i][j], "g_1173[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1202.f0, "g_1202.f0", print_hash_value);
    transparent_crc(g_1257, "g_1257", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1318[i][j], "g_1318[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1326, "g_1326", print_hash_value);
    transparent_crc(g_1419, "g_1419", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1432[i], "g_1432[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 345
XXX total union variables: 19

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 29
breakdown:
   indirect level: 0, occurrence: 19
   indirect level: 1, occurrence: 7
   indirect level: 2, occurrence: 3
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 16
XXX times a bitfields struct on LHS: 1
XXX times a bitfields struct on RHS: 48
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 38
breakdown:
   depth: 1, occurrence: 156
   depth: 2, occurrence: 44
   depth: 3, occurrence: 7
   depth: 4, occurrence: 4
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 18, occurrence: 1
   depth: 21, occurrence: 2
   depth: 22, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 2

XXX total number of pointers: 365

XXX times a variable address is taken: 713
XXX times a pointer is dereferenced on RHS: 189
breakdown:
   depth: 1, occurrence: 185
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 213
breakdown:
   depth: 1, occurrence: 212
   depth: 2, occurrence: 1
XXX times a pointer is compared with null: 26
XXX times a pointer is compared with address of another variable: 7
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 5014

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 930
   level: 2, occurrence: 77
   level: 3, occurrence: 8
   level: 4, occurrence: 18
   level: 5, occurrence: 2
XXX number of pointers point to pointers: 128
XXX number of pointers point to scalars: 227
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31
XXX average alias set size: 1.39

XXX times a non-volatile is read: 1071
XXX times a non-volatile is write: 588
XXX times a volatile is read: 68
XXX    times read thru a pointer: 22
XXX times a volatile is write: 35
XXX    times written thru a pointer: 9
XXX times a volatile is available for access: 2.12e+03
XXX percentage of non-volatile access: 94.2

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 162
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 34
   depth: 2, occurrence: 25
   depth: 3, occurrence: 19
   depth: 4, occurrence: 27
   depth: 5, occurrence: 28

XXX percentage a fresh-made variable is used: 15.9
XXX percentage an existing variable is used: 84.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

