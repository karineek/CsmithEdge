/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 2ceb80e
 * Options:   --no-paranoid --null-ptr-deref-prob 0.704 --dangling-ptr-deref-prob 0 --bitfields --packed-struct --annotated-arith-wrappers --relax-anlayses-conditions --relax-anlayses-prob //home/user42/git/MinCond/scripts/WA-v1-general/seedsProbs/probs_WeakenSafeAnalyse_test.txt --relax-anlayses-seed 4231343982 --seed 4231343982
 * Seed:      4231343982
 */

#include "csmith.h"


static long __undefined;

/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 1*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 4*/
/* Try to pick different op 4*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 4*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 3*/
/* Try to pick different op 0*/
/* Try to pick different op 2*/
/* Try to pick different op 2*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 1*/
/* Try to pick different op 1*/
/* Try to pick different op 0*/
/* Try to pick different op 0*/
/* Try to pick different op 3*/
/* Try to pick different op 2*/
/* Try to pick different op 0*/
/* --- Struct/Union Declarations --- */
union U0 {
   int8_t * f0;
   uint16_t  f1;
   signed f2 : 11;
   int8_t  f3;
   uint32_t  f4;
};

union U1 {
   int32_t  f0;
   int32_t  f1;
   uint32_t  f2;
   int32_t  f3;
   unsigned f4 : 11;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[5] = {1L,1L,1L,1L,1L};
static volatile int32_t g_3 = 7L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4[5] = {0L,0L,0L,0L,0L};
static int32_t g_10 = 0xEE28FDEBL;
static int32_t * volatile g_9 = &g_10;/* VOLATILE GLOBAL g_9 */
static union U1 g_37 = {-8L};
static uint16_t g_50 = 1UL;
static int32_t g_57;
static uint32_t g_75;
static const int8_t g_100 = 0x4EL;
static uint32_t g_131;
static int8_t g_137[7];
static int8_t *g_136 = &g_137[0];
static int8_t g_170;
static uint32_t g_175 = 4294967293UL;
static int64_t g_179[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int64_t *g_180 = (void*)0;
static uint8_t g_195 = 0xE5L;
static uint64_t g_235 = 1UL;
static int32_t g_262[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
static uint16_t *g_267 = &g_50;
static int16_t g_283 = 0x6B29L;
static uint32_t *g_343[10][5] = {{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_175,(void*)0,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_175,&g_75,&g_175},{&g_75,&g_75,&g_75,&g_75,&g_75},{&g_75,&g_175,&g_75,&g_75,&g_175},{&g_75,&g_75,&g_175,&g_75,&g_175},{&g_75,&g_175,&g_75,&g_175,&g_75},{&g_175,&g_75,&g_75,&g_175,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75}};
static uint32_t **g_342 = &g_343[4][3];
static uint8_t *g_349 = &g_195;
static uint8_t *g_350[6] = {&g_195,&g_195,&g_195,&g_195,&g_195,&g_195};
static union U0 g_369;
static union U0 *g_368 = &g_369;
static const int32_t g_381 = 1L;
static int32_t *g_403;
static int32_t ** volatile g_402[10][3][7];
static int32_t ** volatile g_404;/* VOLATILE GLOBAL g_404 */
static volatile uint8_t g_408;/* VOLATILE GLOBAL g_408 */
static const volatile uint8_t * volatile g_407;/* VOLATILE GLOBAL g_407 */
static const volatile uint8_t * volatile * volatile g_406 = &g_407;/* VOLATILE GLOBAL g_406 */
static const volatile uint8_t * volatile * volatile *g_405 = &g_406;
static int32_t ** const  volatile g_421 = &g_403;/* VOLATILE GLOBAL g_421 */
static uint32_t *g_443 = &g_75;
static int32_t * volatile g_453 = &g_262[6];/* VOLATILE GLOBAL g_453 */
static const volatile uint8_t * volatile * volatile **g_482[8][8];
static const volatile uint8_t * volatile * volatile *** volatile g_481;/* VOLATILE GLOBAL g_481 */
static int16_t g_518 = 0L;
static int32_t ** volatile g_571 = (void*)0;/* VOLATILE GLOBAL g_571 */
static int32_t ** volatile g_572 = &g_403;/* VOLATILE GLOBAL g_572 */
static uint16_t g_598 = 0xF33BL;
static int32_t ** volatile g_623;/* VOLATILE GLOBAL g_623 */
static volatile int16_t g_624;/* VOLATILE GLOBAL g_624 */
static const volatile int32_t *g_628[3];
static int64_t *** volatile g_652;/* VOLATILE GLOBAL g_652 */
static int64_t **g_654 = &g_180;
static volatile uint8_t g_767 = 247UL;/* VOLATILE GLOBAL g_767 */
static int32_t ** const  volatile g_789[7] = {&g_403,&g_403,&g_403,&g_403,&g_403,&g_403,&g_403};
static int32_t ** volatile g_790 = &g_403;/* VOLATILE GLOBAL g_790 */
static int32_t * volatile g_848[4][7] = {{&g_4[3],&g_37.f0,&g_10,&g_262[1],&g_262[6],&g_262[1],&g_10},{(void*)0,(void*)0,&g_262[1],&g_10,&g_262[4],&g_10,&g_4[3]},{&g_10,(void*)0,&g_262[4],&g_10,&g_10,&g_262[4],(void*)0},{&g_262[4],&g_37.f0,(void*)0,&g_10,&g_262[4],&g_262[4],&g_10}};
static int32_t * volatile g_849;/* VOLATILE GLOBAL g_849 */
static union U1 g_851;
static int32_t ** volatile g_875;/* VOLATILE GLOBAL g_875 */
static int32_t * volatile g_876 = &g_37.f0;/* VOLATILE GLOBAL g_876 */
static uint8_t g_897;
static int32_t ** volatile g_986 = (void*)0;/* VOLATILE GLOBAL g_986 */
static int64_t g_1164 = 1L;
static union U1 *g_1168[6][3][4] = {{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}},{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}},{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}},{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}},{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}},{{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37}}};
static union U1 ** volatile g_1167[6] = {&g_1168[2][2][0],&g_1168[2][2][0],&g_1168[2][2][0],&g_1168[2][2][0],&g_1168[2][2][0],&g_1168[2][2][0]};
static union U1 ** volatile g_1169 = (void*)0;/* VOLATILE GLOBAL g_1169 */
static union U1 ** volatile g_1170 = (void*)0;/* VOLATILE GLOBAL g_1170 */
static int16_t *g_1191 = (void*)0;
static int32_t g_1236 = (-1L);
static int16_t **g_1237 = &g_1191;
static uint64_t g_1260[9] = {0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL,0x5C89613804BCF95ALL};
static union U0 ** volatile g_1268 = &g_368;/* VOLATILE GLOBAL g_1268 */
static uint16_t **g_1285 = (void*)0;
static uint32_t ***g_1390[2][6][4] = {{{(void*)0,(void*)0,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342},{&g_342,(void*)0,(void*)0,&g_342},{&g_342,(void*)0,&g_342,&g_342},{(void*)0,&g_342,&g_342,&g_342},{(void*)0,(void*)0,&g_342,&g_342}},{{&g_342,&g_342,&g_342,&g_342},{&g_342,&g_342,(void*)0,&g_342},{&g_342,(void*)0,(void*)0,&g_342},{&g_342,(void*)0,(void*)0,&g_342},{(void*)0,&g_342,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342}}};
static uint32_t ****g_1389;
static uint32_t *****g_1388[10][9] = {{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389}};
static volatile uint32_t g_1398 = 5UL;/* VOLATILE GLOBAL g_1398 */
static uint8_t * const *g_1402 = &g_350[1];
static uint8_t * const **g_1401[1][2] = {{&g_1402,&g_1402}};
static uint8_t * const ***g_1400;
static uint8_t g_1420 = 0x14L;
static int32_t **g_1428;
static int32_t ***g_1427[6][1] = {{&g_1428},{(void*)0},{&g_1428},{&g_1428},{(void*)0},{&g_1428}};
static uint32_t * const *g_1442 = &g_343[0][4];
static uint32_t * const **g_1441 = &g_1442;
static uint32_t * const ***g_1440 = &g_1441;
static uint32_t * const ****g_1439 = &g_1440;
static volatile int64_t g_1517 = (-1L);/* VOLATILE GLOBAL g_1517 */
static int64_t g_1527 = 0x2AC277A67E660D06LL;
static int32_t g_1603[2] = {0x370D96BDL,0x370D96BDL};
static uint8_t g_1659 = 0UL;
static union U0 **g_1730;
static int32_t * volatile g_1744;/* VOLATILE GLOBAL g_1744 */
static volatile int8_t g_1774 = (-9L);/* VOLATILE GLOBAL g_1774 */
static volatile int8_t * volatile g_1773;/* VOLATILE GLOBAL g_1773 */
static volatile int8_t * volatile *g_1772[2][4][7] = {{{&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773},{&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773},{&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773},{(void*)0,&g_1773,&g_1773,(void*)0,&g_1773,&g_1773,&g_1773}},{{&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773},{&g_1773,&g_1773,&g_1773,(void*)0,&g_1773,&g_1773,(void*)0},{&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773,&g_1773}}};
static volatile int8_t * volatile * volatile *g_1771;
static uint32_t g_1811 = 4294967291UL;
static int32_t g_1892 = (-1L);
static volatile int64_t *g_1940 = &g_1517;
static volatile int64_t * volatile *g_1939 = &g_1940;
static volatile int64_t * volatile * volatile * volatile g_1938 = &g_1939;/* VOLATILE GLOBAL g_1938 */
static volatile int64_t * volatile * volatile * volatile * volatile g_1937[7][7][5] = {{{(void*)0,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,(void*)0,&g_1938},{(void*)0,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0}},{{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{(void*)0,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,(void*)0,&g_1938},{&g_1938,&g_1938,&g_1938,(void*)0,&g_1938}},{{(void*)0,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{(void*)0,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938}},{{&g_1938,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,(void*)0,&g_1938},{&g_1938,&g_1938,&g_1938,(void*)0,&g_1938},{(void*)0,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938}},{{(void*)0,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,(void*)0,&g_1938},{&g_1938,&g_1938,&g_1938,(void*)0,&g_1938},{(void*)0,(void*)0,&g_1938,&g_1938,&g_1938}},{{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{(void*)0,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,&g_1938,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,&g_1938,&g_1938}},{{&g_1938,&g_1938,&g_1938,&g_1938,(void*)0},{&g_1938,&g_1938,(void*)0,&g_1938,&g_1938},{(void*)0,&g_1938,&g_1938,(void*)0,&g_1938},{&g_1938,&g_1938,(void*)0,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,(void*)0,&g_1938},{&g_1938,&g_1938,(void*)0,&g_1938,&g_1938},{&g_1938,(void*)0,&g_1938,&g_1938,(void*)0}}};
static int8_t **g_1954;
static int8_t ***g_1953;
static int8_t ****g_1952 = &g_1953;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static const int32_t  func_17(int32_t  p_18, uint64_t  p_19, int8_t * p_20, union U1  p_21);
static int8_t * func_23(int32_t * p_24, union U1  p_25, union U0  p_26);
static int32_t * func_27(uint64_t  p_28, int32_t  p_29, int32_t  p_30);
static union U1  func_31(int32_t  p_32, union U1  p_33, uint64_t  p_34, int32_t  p_35, int64_t  p_36);
static uint32_t  func_63(int32_t * p_64);
static int32_t  func_66(const int64_t  p_67, uint64_t  p_68, uint16_t * p_69, int32_t * p_70);
static int8_t * func_78(uint8_t  p_79, uint32_t * p_80, uint32_t  p_81);
static int16_t  func_82(int8_t * p_83);
static int8_t * func_84(uint64_t  p_85, int32_t  p_86, const int8_t * p_87, uint16_t  p_88, const int32_t  p_89);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_10 g_1527 g_37.f2 g_137 g_267 g_50 g_1659 g_57 g_1402 g_350 g_195 g_849 g_1771 g_518 g_136 g_1773 g_1774 g_1811 g_349 g_1428 g_453 g_262 g_1603 g_1400 g_1401 g_403 g_654 g_180 g_443 g_75 g_1260 g_1268 g_368 g_369 g_481 g_482 g_179 g_897 g_1236 g_407 g_408 g_1164 g_1892 g_2 g_1389 g_1390 g_1398 g_1940 g_1517
 * writes: g_4 g_10 g_1527 g_37.f2 g_1237 g_57 g_1168 g_137 g_50 g_1659 g_851.f0 g_851.f3 g_403 g_1603 g_75 g_1260 g_1236 g_170 g_1164 g_368 g_131 g_1937 g_1952
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_22 = 1L;
    uint32_t l_846;
    union U1 l_1490[9] = {{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}};
    uint8_t **l_1570[2];
    uint8_t ***l_1569 = &l_1570[1];
    uint8_t ****l_1568[5][7] = {{(void*)0,&l_1569,&l_1569,(void*)0,&l_1569,(void*)0,&l_1569},{&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569},{&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569},{(void*)0,&l_1569,(void*)0,&l_1569,&l_1569,(void*)0,&l_1569},{&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569,&l_1569}};
    int32_t l_1593[1][4][4];
    int32_t l_1601[1];
    uint16_t l_1605 = 65535UL;
    int8_t l_1710 = 0xB3L;
    int32_t l_1717;
    uint32_t **l_1820 = (void*)0;
    union U1 l_1871;
    int64_t ***l_1945 = (void*)0;
    int8_t **l_1951;
    int8_t ***l_1950 = &l_1951;
    int8_t ****l_1949;
    union U0 *l_1960 = (void*)0;
    int32_t l_1970 = 0xFF13D391L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1570[i] = &g_349;
    for (i = 0; i < 1; i++)
        l_1601[i] = 1L;
lbl_1816:
    for (g_4[3] = 1; (g_4[3] <= 16); g_4[3] = safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*0*//* ___SAFE__OP */(g_4[3], 2))
    { /* block id: 3 */
        int8_t l_7;
        int32_t *l_8 = (void*)0;
        int16_t l_1530 = 0L;
        const union U0 l_1550 = {0};
        union U0 *l_1563[9];
        union U0 **l_1564 = (void*)0;
        union U0 **l_1565 = &l_1563[6];
        const union U1 l_1566 = {0x36E1126DL};
        uint32_t l_1669;
        int8_t l_1671 = 0xB3L;
        uint32_t l_1722 = 0UL;
        uint32_t l_1734;
        int32_t l_1746[1][1][4] = {{{0L,0L,0L,0L}}};
        int32_t l_1747 = 0xD70BCBA6L;
        int i, j, k;
        (*g_9) ^= l_7;
        for (g_10 = 0; (g_10 >= 14); ++g_10)
        { /* block id: 7 */
            uint8_t l_47 = 0x14L;
            uint16_t *l_48;
            uint16_t *l_49;
            union U1 *l_845;
            int64_t *l_1526 = &g_1527;
            int32_t l_1532[10] = {0xC8CECF49L,0x0EECCB5EL,0xC8CECF49L,0x0EECCB5EL,0xC8CECF49L,0x0EECCB5EL,0xC8CECF49L,0x0EECCB5EL,0xC8CECF49L,0x0EECCB5EL};
            union U0 *l_1553[6] = {&g_369,&g_369,&g_369,&g_369,&g_369,&g_369};
            int i;
        }
    }
    for (g_1527 = 2; (g_1527 >= 0); g_1527 -= 1)
    { /* block id: 741 */
        int16_t **l_1760 = &g_1191;
        int32_t l_1761;
        uint16_t l_1793 = 65527UL;
        int32_t l_1812 = 0L;
        union U0 *l_1814 = &g_369;
        uint32_t *l_1885[9];
        int32_t l_1910 = 0xF4219EBCL;
        int32_t l_1911 = 0xE8B8BAC6L;
        uint8_t l_1912 = 0UL;
        const int32_t *l_1930 = &g_10;
        const int32_t **l_1929;
        const int32_t ***l_1928 = &l_1929;
        const int32_t ****l_1927[6][1];
        uint64_t l_1931 = 18446744073709551613UL;
        int64_t ***l_1944 = &g_654;
        int i, j;
        for (i = 0; i < 9; i++)
            l_1885[i] = &g_1811;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 1; j++)
                l_1927[i][j] = &l_1928;
        }
        for (g_37.f2 = 0; (g_37.f2 <= 2); g_37.f2 += 1)
        { /* block id: 744 */
            int32_t *l_1751;
            uint16_t ***l_1753;
            int16_t **l_1754 = &g_1191;
            int16_t ***l_1755[1];
            int32_t l_1790[8][6][5] = {{{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)}},{{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)}},{{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)},{1L,(-1L),0x03647B66L,0x2679DBF4L,(-1L)},{(-5L),(-10L),(-10L),(-5L),(-2L)}},{{1L,(-1L),1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)}},{{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)}},{{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)}},{{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)}},{{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)},{1L,0x2679DBF4L,1L,0x4B85B7B2L,6L},{0x9BD71B11L,(-5L),(-5L),0x9BD71B11L,(-9L)}}};
            uint32_t **l_1819;
            union U0 * const l_1821 = &g_369;
            int32_t *l_1907 = &g_1892;
            int32_t *l_1908;
            int32_t *l_1909[7] = {&l_1601[0],&l_1717,&l_1601[0],&l_1601[0],&l_1717,&l_1601[0],&l_1601[0]};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1755[i] = &g_1237;
            l_1751 = l_1751;
            (*l_1751) ^= ((~(0xBAL | ((void*)0 == l_1753))) | ((((g_1237 = l_1754) == &g_1191) >= g_137[(g_37.f2 - 3)]) > ((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*1*//* ___SAFE__OP */(((g_137[0] & 0x1DE721FC7DC68304LL) , (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*2*//* ___SAFE__OP */(((l_1760 != &g_1191) , 0x96040FB710EF653CLL), l_1761))), (*g_267))) != g_1659)));
            if ((*l_1751))
            { /* block id: 748 */
                union U1 **l_1762 = &g_1168[0][0][3];
                int8_t *l_1763[10] = {(void*)0,(void*)0,&g_170,&g_170,&g_170,(void*)0,(void*)0,&g_170,&g_170,&g_170};
                int32_t l_1764;
                int i;
                (*l_1762) = (void*)0;
                (*l_1751) = ((((*g_267) = ((l_1764 = (g_137[(g_37.f2 - 4)] &= (((0xF565F7B0L <= l_846) , (void*)0) == l_1751))) != (**g_1402))) > 0L) < 0xBEL);
                return (*l_1751);
            }
            else
            { /* block id: 755 */
                uint16_t l_1766 = 65526UL;
                int8_t **l_1776 = (void*)0;
                int8_t ***l_1775[1][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int16_t l_1791;
                int16_t l_1810;
                uint8_t **l_1823 = &g_350[3];
                const union U0 l_1876[3] = {{0},{0},{0}};
                int32_t **l_1889 = &l_1751;
                int64_t *l_1898;
                union U0 **l_1902 = &g_368;
                uint32_t *l_1905[5];
                int32_t *l_1906 = &l_1761;
                int i, j;
                for (g_1659 = 0; (g_1659 <= 2); g_1659 += 1)
                { /* block id: 758 */
                    int32_t l_1765 = 0xC60E819BL;
                    int i, j, k;
                    l_1601[0] ^= l_1765;
                    if (l_1761)
                        break;
                    for (g_851.f0 = 0; (g_851.f0 <= 2); g_851.f0 += 1)
                    { /* block id: 763 */
                        int32_t *l_1769[1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_1769[i] = &l_1601[0];
                        ++l_1766;
                        (*l_1751) = l_1717;
                        l_1761 ^= (*g_849);
                    }
                }
                if ((*l_1751))
                { /* block id: 769 */
                    int8_t l_1770 = 4L;
                    int8_t ****l_1777 = &l_1775[0][4];
                    int32_t l_1789 = 4L;
                    int32_t l_1792 = 0x59C51880L;
                    if (((l_1770 , g_1771) == ((*l_1777) = l_1775[0][4])))
                    { /* block id: 771 */
                        int32_t *l_1778 = &l_1761;
                        int32_t *l_1779;
                        int32_t *l_1780 = (void*)0;
                        int32_t *l_1781 = &g_262[4];
                        int32_t *l_1782;
                        int32_t *l_1783;
                        int32_t *l_1784 = &g_1236;
                        int32_t *l_1785 = &g_262[4];
                        int32_t *l_1786 = &g_851.f0;
                        int32_t *l_1787 = &l_1601[0];
                        int32_t *l_1788[4][8][2] = {{{&g_4[1],&g_4[1]},{&l_1490[2].f0,&g_4[1]},{&g_4[1],&l_1601[0]},{(void*)0,&g_57},{&l_1490[2].f0,(void*)0},{&g_57,&l_1601[0]},{&g_57,(void*)0},{&l_1490[2].f0,&g_57}},{{(void*)0,&l_1601[0]},{&l_1490[2].f0,&l_1490[2].f0},{&g_57,&l_1490[2].f0},{&l_1490[2].f0,&l_1717},{&l_1601[0],&g_4[3]},{&g_57,&l_1601[0]},{&g_4[3],&l_1717},{&g_4[3],&l_1601[0]}},{{&g_57,&g_4[3]},{&l_1601[0],&l_1717},{&l_1490[2].f0,&l_1490[2].f0},{&g_57,&l_1490[2].f0},{&l_1490[2].f0,&l_1717},{&l_1601[0],&g_4[3]},{&g_57,&l_1601[0]},{&g_4[3],&l_1717}},{{&g_4[3],&l_1601[0]},{&g_57,&g_4[3]},{&l_1601[0],&l_1717},{&l_1490[2].f0,&l_1490[2].f0},{&g_57,&l_1490[2].f0},{&l_1490[2].f0,&l_1717},{&l_1601[0],&g_4[3]},{&g_57,&l_1601[0]}}};
                        int i, j, k;
                        ++l_1793;
                    }
                    else
                    { /* block id: 773 */
                        int16_t *l_1805;
                        int32_t *l_1813[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1813[i] = (void*)0;
                        (*g_1428) = func_27(g_518, (g_851.f3 = (safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*3*//* ___SAFE__OP */((l_1812 &= ((l_1766 | (*g_136)) && ((l_1761 != (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*4*//* ___SAFE__OP */(4294967295UL, (safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*5*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*6*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*7*//* ___SAFE__OP */((((void*)0 != l_1805) != ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*8*//* ___SAFE__OP */(((*g_1773) && ((((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*9*//* ___SAFE__OP */((l_1791 & (*g_267)), l_1810)) ^ (-1L)) , (*l_1751)) ^ l_1761)), l_1792)) >= l_1717)), g_1811)), (*l_1751)))))))) & l_846))), (*l_1751)))), l_1761);
                    }
                    for (l_1605 = 0; (l_1605 <= 6); l_1605 += 1)
                    { /* block id: 780 */
                        union U0 *l_1815 = &g_369;
                        (*l_1751) = ((*l_1751) == (l_1814 != l_1815));
                        if (l_1766)
                            goto lbl_1816;
                    }
                }
                else
                { /* block id: 784 */
                    uint8_t l_1824 = 2UL;
                    union U0 l_1846;
                    union U1 l_1867 = {-6L};
                    int32_t ***l_1888[8];
                    int64_t l_1890[10] = {0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL,0x93AE2B7DBD4AEEB8LL};
                    int64_t *l_1891 = (void*)0;
                    int i;
                    if (l_1793)
                    { /* block id: 785 */
                        int32_t *l_1822 = &l_1490[2].f3;
                        int32_t l_1825;
                        (*g_1428) = func_27((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*10*//* ___SAFE__OP */((*g_453), (l_1819 != l_1820))), (g_1603[1] |= ((void*)0 == l_1821)), (((((65535UL < (-8L)) | (l_1823 != (**g_1400))) || l_1824) >= l_1825) , 0x2E225F9BL));
                        (**g_1428) = (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*11*//* ___SAFE__OP */(l_1812, 4294967295UL));
                        (*g_403) ^= ((*l_1751) != (((l_1601[0] >= (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*12*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*13*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*14*//* ___SAFE__OP */(((*g_443) &= ((~0xC21C7646AC3832CDLL) & ((7UL <= 0x16E08395CBE179AFLL) == (safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*15*//* ___SAFE__OP */(((*g_654) != ((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*16*//* ___SAFE__OP */((~((*l_1751) < (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*17*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*18*//* ___SAFE__OP */(((*g_136) ^ 0xE3L), 2)), 12)))), l_1825)) , (*g_654))), 31))))), 0x2E70B086L)), l_1710)) <= 0x4FL), 0x8D10F987L))) , (*l_1751)) , l_1793));
                        (*l_1751) = l_1812;
                    }
                    else
                    { /* block id: 792 */
                        uint64_t *l_1848 = (void*)0;
                        uint64_t *l_1849 = &g_1260[0];
                        int32_t l_1868 = 0L;
                        int32_t l_1869[2][5][9] = {{{0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL},{0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L},{0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL},{0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L},{0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL}},{{0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L},{0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL},{0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L},{0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL,0xF4A3E3BDL},{0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L,0x001EBC01L}}};
                        int32_t *l_1870 = &g_1236;
                        int i, j, k;
                        (*l_1870) &= ((l_1846 , ((safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*19*//* ___SAFE__OP */(((++(*l_1849)) < (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*20*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*21*//* ___SAFE__OP */(0x81719F49L, ((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*22*//* ___SAFE__OP */(((((*l_1751) = ((0x0FC1L ^ ((**g_1268) , (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*23*//* ___SAFE__OP */((((l_1868 = (l_1766 , ((l_1593[0][1][2] , (((((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*24*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*25*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*26*//* ___SAFE__OP */((*g_267), 15)))), (safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*27*//* ___SAFE__OP */(((l_1867 , (*g_481)) == &g_1401[0][0]), 17)))) == l_1868) || l_846) <= l_1810) <= g_179[6])) && (*g_267)))) >= g_897) ^ l_1869[1][2][5]), g_57)))) , (-9L))) == (-7L)) <= 0UL), l_1793)) < l_1761))) | 0x55L), l_1869[1][2][3]))))) ^ 253UL)) >= (*g_136));
                    }
                    l_1761 = (l_1871 , ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*28*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*29*//* ___SAFE__OP */(((l_1793 | (l_1791 == (l_1876[1] , (((0L & ((((*l_1751) = ((safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*30*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*31*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*32*//* ___SAFE__OP */(((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*33*//* ___SAFE__OP */((((g_170 = ((*g_136) ^= (((((void*)0 != l_1885[8]) > (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*34*//* ___SAFE__OP */(((l_1889 = (void*)0) == (void*)0), l_1605))) >= l_1791) != (*g_407)))) || (*g_349)) >= 0xC986L), (*l_1751))) && (*g_267)), l_1871.f0)), 0xC2DCL)) < 18446744073709551615UL), l_1890[6])) | l_1601[0])) < l_1810) | 0xD248125BAA0FEE44LL)) & l_1490[2].f0) | g_1164)))) == 0x17F8L), g_1260[7])), l_1812)) , g_1892));
                }
                if (l_1761)
                    continue;
                (*l_1751) = ((l_1605 == l_1793) , ((*l_1906) |= (safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*35*//* ___SAFE__OP */((l_1601[0] = (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*36*//* ___SAFE__OP */(((g_131 = ((safe_unary_minus_func_int64_t_s/* ___REMOVE_SAFE__OP *//*37*//* ___SAFE__OP */(((*l_1898) &= g_2[1]))) >= (safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*38*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*39*//* ___SAFE__OP */((*l_1751), (((((*l_1902) = &g_369) != (void*)0) < (6L != (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*40*//* ___SAFE__OP */(0L, (*g_136))))) & 4294967289UL))))))) , g_4[3]), g_179[6]))), (*g_443)))));
            }
            ++l_1912;
        }
        for (l_1812 = 0; (l_1812 <= 2); l_1812 += 1)
        { /* block id: 816 */
            uint32_t l_1922;
            int32_t *l_1932 = &l_1601[0];
            (*l_1932) = ((!(safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*41*//* ___SAFE__OP */(l_1912, (l_1710 & ((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*42*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*43*//* ___SAFE__OP */((l_1871.f0 , 65529UL), (((l_1922 > ((void*)0 == (*g_1389))) < 0x5BCCL) && ((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*44*//* ___SAFE__OP */(((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*45*//* ___SAFE__OP */((&g_1427[0][0] == l_1927[1][0]), l_1931)) & l_1871.f0), l_1922)) < (**g_1402))))), l_22)) , (*g_267)))))) && 4UL);
            for (g_131 = 0; (g_131 <= 0); g_131 += 1)
            { /* block id: 820 */
                int64_t * const *l_1936 = &g_180;
                int64_t * const **l_1935[1][1];
                int64_t * const ***l_1934[5][3] = {{&l_1935[0][0],&l_1935[0][0],&l_1935[0][0]},{&l_1935[0][0],&l_1935[0][0],&l_1935[0][0]},{&l_1935[0][0],&l_1935[0][0],&l_1935[0][0]},{&l_1935[0][0],&l_1935[0][0],&l_1935[0][0]},{&l_1935[0][0],&l_1935[0][0],&l_1935[0][0]}};
                int64_t * const ****l_1933[1];
                union U1 *l_1943 = &l_1490[2];
                int32_t l_1948 = (-4L);
                uint64_t l_1958 = 0UL;
                union U0 **l_1961 = (void*)0;
                uint16_t *l_1962 = &g_50;
                uint8_t l_1969 = 249UL;
                uint32_t l_1971 = 4294967295UL;
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_1935[i][j] = &l_1936;
                }
                for (i = 0; i < 1; i++)
                    l_1933[i] = &l_1934[3][1];
                g_1937[0][1][3] = (void*)0;
                l_1948 ^= (safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*46*//* ___SAFE__OP */(((*g_136) |= (l_1943 == (((((l_1944 == l_1945) , (*g_1400)) == (void*)0) || ((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*47*//* ___SAFE__OP */(5L, ((((&g_1427[(g_1527 + 3)][g_131] == &g_1427[l_1812][g_131]) , g_1398) && 0x143A7F1D425963C0LL) && 0x7676AD3BC1740BA2LL))) <= l_1605)) , &l_1490[5]))), 3));
                g_1952 = l_1949;
                (**l_1928) = func_27(g_1236, ((!(*g_1940)) == ((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*48*//* ___SAFE__OP */((*l_1932), l_1958)) >= (safe_unary_minus_func_uint32_t_u/* ___REMOVE_SAFE__OP *//*49*//* ___SAFE__OP */(((l_1960 != (g_368 = l_1814)) , (l_1962 != (void*)0)))))), (l_1971 |= (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*50*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*51*//* ___SAFE__OP */((((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*52*//* ___SAFE__OP */(l_1490[2].f0, (*g_267))) > l_1969) == l_1970), l_1871.f0)), (*g_136)))));
            }
        }
    }
    return l_1593[0][1][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_131 g_267 g_50
 * writes: g_131
 */
static const int32_t  func_17(int32_t  p_18, uint64_t  p_19, int8_t * p_20, union U1  p_21)
{ /* block id: 622 */
    uint32_t l_1511;
    int32_t l_1514[3];
    int16_t l_1515 = 0x3941L;
    int32_t l_1516;
    int16_t l_1519[9][4];
    int32_t l_1520[2];
    int32_t l_1521 = 0x82CB4E41L;
    int i, j;
    for (i = 0; i < 3; i++)
        l_1514[i] = 0x60B61FD7L;
    for (i = 0; i < 2; i++)
        l_1520[i] = (-1L);
    for (p_21.f0 = (-15); (p_21.f0 <= (-19)); --p_21.f0)
    { /* block id: 625 */
        for (g_131 = (-9); (g_131 < 5); ++g_131)
        { /* block id: 628 */
            int32_t l_1501 = 0xB5ED8BD2L;
            l_1501 = (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*53*//* ___SAFE__OP */((*g_267), (safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*54*//* ___SAFE__OP */(p_18, (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*55*//* ___SAFE__OP */(1UL, 4))))));
        }
        return p_19;
    }
    for (p_18 = 4; (p_18 >= 0); p_18 -= 1)
    { /* block id: 635 */
        int64_t l_1502 = 1L;
        int32_t *l_1503 = &g_851.f0;
        int32_t *l_1504 = &g_851.f0;
        int32_t *l_1505 = (void*)0;
        int32_t *l_1506;
        int32_t *l_1507;
        int32_t *l_1508 = (void*)0;
        int32_t *l_1509 = &g_262[4];
        int32_t *l_1510[1];
        int8_t l_1518;
        int32_t l_1522[2][7][7] = {{{(-2L),(-5L),0x7BBCD446L,(-10L),(-1L),0x8A4AE6C3L,0x8A4AE6C3L},{0x486FA143L,0x42365D76L,1L,0x42365D76L,0x486FA143L,(-6L),0L},{(-1L),(-10L),0x7BBCD446L,(-5L),(-2L),0x8A4AE6C3L,0x9F6350F7L},{1L,0x42365D76L,0x00F16B97L,(-4L),0x486FA143L,0L,0L},{(-1L),0x4710F86CL,0L,0x4710F86CL,0x8A4AE6C3L,0x581DB23FL,0x7BBCD446L},{0L,(-1L),0xE106EBC6L,0x91BB1628L,(-6L),1L,0x00F16B97L},{0x3FD04C40L,0x4710F86CL,0x7A875850L,(-1L),0x8A4AE6C3L,1L,1L}},{{0L,0x91BB1628L,1L,0x91BB1628L,0L,0xC9428063L,0x00F16B97L},{0x8A4AE6C3L,(-1L),0x7A875850L,0x4710F86CL,0x3FD04C40L,1L,0x7BBCD446L},{(-6L),0x91BB1628L,0xE106EBC6L,(-1L),0L,1L,1L},{0x8A4AE6C3L,0x4710F86CL,0L,0x4710F86CL,0x8A4AE6C3L,0x581DB23FL,0x7BBCD446L},{0L,(-1L),0xE106EBC6L,0x91BB1628L,(-6L),1L,0x00F16B97L},{0x3FD04C40L,0x4710F86CL,0x7A875850L,(-1L),0x8A4AE6C3L,1L,1L},{0L,0x91BB1628L,1L,0x91BB1628L,0L,0xC9428063L,0x00F16B97L}}};
        uint32_t l_1523[4][3][9] = {{{1UL,1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,18446744073709551610UL},{0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL},{0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L}},{{1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551613UL,18446744073709551610UL,18446744073709551610UL,18446744073709551613UL,18446744073709551615UL,18446744073709551613UL,18446744073709551610UL,18446744073709551610UL},{1UL,1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,18446744073709551610UL}},{{0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL},{0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L},{1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL}},{{18446744073709551615UL,18446744073709551613UL,18446744073709551610UL,18446744073709551610UL,18446744073709551613UL,18446744073709551615UL,18446744073709551613UL,18446744073709551610UL,18446744073709551610UL},{1UL,1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,1UL,1UL,18446744073709551615UL,18446744073709551610UL},{0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL,18446744073709551615UL,0x0BA97193L,18446744073709551613UL,0x0BA97193L,18446744073709551615UL}}};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1510[i] = &g_851.f0;
        l_1511++;
        --l_1523[1][1][5];
    }
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_179 g_283 g_136 g_137 g_4 g_875 g_876 g_349 g_195 g_267 g_50 g_851 g_381 g_406 g_407 g_408 g_518 g_405 g_598 g_849 g_37 g_37.f0 g_443 g_75 g_453 g_262 g_170 g_2 g_57 g_897 g_790 g_403 g_235 g_175 g_1191 g_1236 g_37.f2 g_572 g_1260 g_1164 g_1268 g_100 g_9
 * writes: g_179 g_851.f1 g_37.f0 g_403 g_195 g_50 g_170 g_235 g_137 g_349 g_350 g_598 g_57 g_518 g_369.f3 g_75 g_2 g_343 g_897 g_262 g_851.f0 g_1191 g_1164 g_1237 g_37.f2 g_368 g_1285 g_37.f3 g_1168 g_1388
 */
static int8_t * func_23(int32_t * p_24, union U1  p_25, union U0  p_26)
{ /* block id: 364 */
    int32_t l_856 = 0x7105761AL;
    int32_t * const l_859 = &g_10;
    int8_t *l_863;
    int64_t *l_865 = &g_179[4];
    int32_t l_877 = 3L;
    uint32_t ***l_923;
    uint32_t ****l_922[2][9][9] = {{{&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923},{(void*)0,&l_923,&l_923,(void*)0,(void*)0,(void*)0,&l_923,&l_923,&l_923},{&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923},{(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,&l_923,(void*)0,&l_923},{&l_923,&l_923,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923},{&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923},{(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,&l_923,(void*)0,&l_923},{&l_923,&l_923,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923},{&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923},{(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,&l_923,(void*)0,&l_923},{&l_923,&l_923,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923},{&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923,&l_923},{(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,&l_923,(void*)0,&l_923},{&l_923,&l_923,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_923,(void*)0,&l_923,&l_923,&l_923}}};
    int32_t **l_1004 = &g_403;
    int32_t ***l_1003;
    uint32_t **l_1009;
    int32_t l_1013 = (-6L);
    int32_t l_1014[4];
    uint32_t l_1091 = 7UL;
    int32_t *l_1092 = &g_262[4];
    uint32_t l_1247[4] = {0x537D0DADL,0x537D0DADL,0x537D0DADL,0x537D0DADL};
    uint16_t *l_1279 = (void*)0;
    int16_t l_1306[2];
    int64_t l_1314;
    uint64_t l_1315 = 0x2673067B2C85F4F2LL;
    union U1 l_1344[2] = {{0x843A30BCL},{0x843A30BCL}};
    int16_t **l_1349[2][3];
    const uint32_t l_1453 = 4294967295UL;
    int32_t l_1483[7][7];
    int8_t *l_1489 = &g_170;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1014[i] = 0x8E9E6979L;
    for (i = 0; i < 2; i++)
        l_1306[i] = 0x1758L;
    if (((((((((*l_865) &= ((1L && ((safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*56*//* ___SAFE__OP */((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*57*//* ___SAFE__OP */(l_856, (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*58*//* ___SAFE__OP */(p_25.f0, ((void*)0 == l_859))))), (~(*l_859)))) < (safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*59*//* ___SAFE__OP */(((void*)0 != l_863), 3)))) < (~0x07CCL))) < 0xFC08462058697C81LL) | (*l_859)) , g_283) , 1L) == (*g_136)) & 0x89CE96485F003E32LL))
    { /* block id: 366 */
        uint16_t l_872 = 0xF31FL;
        int32_t l_898 = 0x7833CA77L;
        int32_t l_903[10][5][2] = {{{0xA1CF45E2L,(-1L)},{0x7C92F1ACL,(-1L)},{0xA1CF45E2L,0xA1CF45E2L},{0x57F121B5L,0xA5EC1E9CL},{1L,0x4234ACD2L}},{{0xB3ECFF88L,0x31B10659L},{(-1L),0xB3ECFF88L},{0xBAA8D180L,(-1L)},{0xBAA8D180L,0xB3ECFF88L},{(-1L),0x31B10659L}},{{0xB3ECFF88L,0x4234ACD2L},{1L,0xA5EC1E9CL},{0x57F121B5L,0xA1CF45E2L},{0xA1CF45E2L,(-1L)},{0x7C92F1ACL,(-1L)}},{{0xA1CF45E2L,0xA1CF45E2L},{0x57F121B5L,0xA5EC1E9CL},{1L,0x4234ACD2L},{0xB3ECFF88L,0x03B7C01CL},{0x7C92F1ACL,0x57F121B5L}},{{0x4234ACD2L,0xB3ECFF88L},{0x4234ACD2L,0x57F121B5L},{0x7C92F1ACL,0x03B7C01CL},{0x57F121B5L,(-1L)},{0xBAA8D180L,0x31B10659L}},{{0xA5EC1E9CL,(-1L)},{(-1L),0x7C92F1ACL},{0xA1CF45E2L,0x7C92F1ACL},{(-1L),(-1L)},{0xA5EC1E9CL,0x31B10659L}},{{0xBAA8D180L,(-1L)},{0x57F121B5L,0x03B7C01CL},{0x7C92F1ACL,0x57F121B5L},{0x4234ACD2L,0xB3ECFF88L},{0x4234ACD2L,0x57F121B5L}},{{0x7C92F1ACL,0x03B7C01CL},{0x57F121B5L,(-1L)},{0xBAA8D180L,0x31B10659L},{0xA5EC1E9CL,(-1L)},{(-1L),0x7C92F1ACL}},{{0xA1CF45E2L,0x7C92F1ACL},{(-1L),(-1L)},{0xA5EC1E9CL,0x31B10659L},{0xBAA8D180L,(-1L)},{0x57F121B5L,0x03B7C01CL}},{{0x7C92F1ACL,0x57F121B5L},{0x4234ACD2L,0xB3ECFF88L},{0x4234ACD2L,0x57F121B5L},{0x7C92F1ACL,0x03B7C01CL},{0x57F121B5L,(-1L)}}};
        uint32_t l_937;
        uint32_t *****l_1007 = &l_922[0][1][3];
        int32_t **l_1069 = (void*)0;
        int8_t l_1115[4][4];
        int32_t l_1116[2][3];
        int64_t **l_1118 = &l_865;
        int16_t *l_1190;
        uint8_t **l_1195 = &g_350[0];
        uint8_t ** const * const l_1194[4][8] = {{&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195},{&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195},{&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195},{&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195,&l_1195}};
        uint8_t ** const * const *l_1193;
        uint8_t ** const * const **l_1192 = &l_1193;
        uint8_t *l_1215 = &g_195;
        uint8_t *l_1216;
        uint8_t ** const l_1214[4] = {&l_1216,&l_1216,&l_1216,&l_1216};
        uint8_t ** const *l_1213 = &l_1214[0];
        uint8_t ** const **l_1212[8] = {&l_1213,&l_1213,&l_1213,&l_1213,&l_1213,&l_1213,&l_1213,&l_1213};
        union U1 l_1248;
        uint16_t l_1386[10][3][8] = {{{0UL,0UL,1UL,0UL,1UL,0xE8FDL,0xE8FDL,1UL},{8UL,65535UL,65535UL,8UL,5UL,0x4DBCL,0xA6EAL,0xF0F8L},{65535UL,5UL,0UL,0xE227L,0x0E40L,1UL,1UL,0UL}},{{0xC988L,5UL,3UL,1UL,65535UL,0x4DBCL,0x0E40L,0xC988L},{0x4227L,65535UL,0xE227L,1UL,8UL,0xE8FDL,65535UL,65526UL},{0xDD71L,0UL,0xA6EAL,0x3F99L,0xA6EAL,0UL,0xDD71L,65535UL}},{{8UL,1UL,65527UL,2UL,0UL,8UL,1UL,0xF0F8L},{1UL,1UL,0xE5F7L,0UL,0UL,65527UL,1UL,0x3F99L},{8UL,0x1830L,65535UL,0xF0F8L,0xA6EAL,0x4DBCL,5UL,8UL}},{{0xDD71L,0xA6EAL,0UL,65527UL,8UL,8UL,65527UL,0UL},{0x4227L,0x4227L,1UL,1UL,8UL,65527UL,0xA6EAL,0x0B7FL},{65535UL,0x4DBCL,3UL,65526UL,0x4227L,0xE5F7L,0x4DBCL,0x0B7FL}},{{0x4DBCL,0xDD71L,2UL,1UL,0x66C7L,65535UL,0UL,0UL},{0UL,0xE8FDL,0xE5F7L,3UL,2UL,0UL,0x4227L,0UL},{65527UL,65535UL,5UL,65535UL,65527UL,1UL,3UL,1UL}},{{65535UL,1UL,0x4DBCL,0x1830L,0x0B7FL,65527UL,65535UL,65535UL},{0x3F99L,0x0B7FL,0x4DBCL,0xE5F7L,0x4227L,65526UL,3UL,0x4DBCL},{0x0B7FL,0x66C7L,5UL,1UL,0UL,2UL,0x4227L,2UL}},{{65535UL,0UL,0xE5F7L,0xC988L,0xC988L,0xE5F7L,0UL,65535UL},{1UL,65535UL,2UL,2UL,65535UL,65535UL,0x4DBCL,0UL},{65535UL,65527UL,3UL,0x0E40L,2UL,65535UL,0xA6EAL,65535UL}},{{0xE227L,65535UL,0xC988L,0UL,0xE8FDL,0xE5F7L,3UL,2UL},{65535UL,0UL,0UL,0x1830L,0x66C7L,2UL,0x66C7L,0x1830L},{0x3F99L,0x66C7L,0x3F99L,3UL,0xC988L,65526UL,8UL,0x3F99L}},{{65535UL,0x0B7FL,5UL,2UL,0xF0F8L,65527UL,0xC988L,2UL},{65535UL,1UL,3UL,5UL,0xC988L,1UL,1UL,0x0B7FL},{0x3F99L,65535UL,0x0B7FL,0xE227L,0x66C7L,0UL,0x4DBCL,0x4DBCL}},{{65535UL,0xE8FDL,0x0E40L,0x0E40L,0xE8FDL,65535UL,0x4227L,0x1830L},{0xE227L,0xDD71L,65526UL,65535UL,2UL,0xE5F7L,8UL,0xE227L},{65535UL,0x4DBCL,0UL,65535UL,65535UL,65527UL,0x0B7FL,0x1830L}}};
        int8_t l_1424 = 0x4FL;
        int64_t l_1484 = (-1L);
        int i, j, k;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 3; j++)
                l_1116[i][j] = 0xD8F83E92L;
        }
        for (p_25.f1 = 0; (p_25.f1 < (-7)); p_25.f1 = safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*60*//* ___SAFE__OP */(p_25.f1, 3))
        { /* block id: 369 */
            int16_t l_870;
            int32_t l_871 = 0x642B3967L;
            for (g_851.f1 = 0; (g_851.f1 <= 6); g_851.f1 += 1)
            { /* block id: 372 */
                int32_t *l_868 = &g_37.f0;
                int32_t *l_869[3][1][10] = {{{&g_262[8],&g_262[4],&g_262[8],&g_4[3],&g_4[3],&g_4[3],&g_4[3],&g_262[8],&g_262[4],&g_262[8]}},{{&g_262[8],&g_262[6],&g_262[4],&g_262[4],&g_262[4],&g_262[6],&g_262[8],&g_262[8],&g_262[6],&g_262[4]}},{{&g_262[6],&g_262[8],&g_262[8],&g_262[6],&g_262[4],&g_262[4],&g_262[4],&g_262[6],&g_262[8],&g_262[8]}}};
                int i, j, k;
                for (g_37.f0 = 0; (g_37.f0 <= 6); g_37.f0 += 1)
                { /* block id: 375 */
                    if ((*p_24))
                        break;
                }
                l_872++;
                (*g_875) = p_24;
            }
            (*g_876) = (*l_859);
        }
        if (l_877)
        { /* block id: 383 */
            int32_t l_888[6][10][4];
            uint16_t * const l_895[4][6] = {{(void*)0,&l_872,(void*)0,&l_872,(void*)0,&l_872},{(void*)0,&l_872,(void*)0,&l_872,(void*)0,&l_872},{(void*)0,&l_872,(void*)0,&l_872,(void*)0,&l_872},{(void*)0,&l_872,(void*)0,&l_872,(void*)0,&l_872}};
            uint8_t *l_896[4][4][3] = {{{(void*)0,&g_897,&g_897},{&g_897,&g_897,&g_897},{&g_897,(void*)0,(void*)0},{&g_897,&g_897,&g_897}},{{&g_897,&g_897,&g_897},{&g_897,&g_897,&g_897},{&g_897,&g_897,(void*)0},{(void*)0,&g_897,&g_897}},{{&g_897,&g_897,&g_897},{&g_897,(void*)0,(void*)0},{&g_897,&g_897,&g_897},{&g_897,&g_897,&g_897}},{{&g_897,&g_897,&g_897},{&g_897,&g_897,(void*)0},{(void*)0,&g_897,&g_897},{&g_897,&g_897,&g_897}}};
            int32_t l_901 = 1L;
            int8_t *l_902[4][6] = {{(void*)0,&g_170,&g_170,(void*)0,&g_170,&g_170},{(void*)0,&g_170,&g_170,(void*)0,&g_170,&g_170},{(void*)0,&g_170,&g_170,(void*)0,&g_170,&g_170},{(void*)0,&g_170,&g_170,(void*)0,&g_170,&g_170}};
            uint64_t *l_904 = (void*)0;
            int i, j, k;
            p_25.f0 = ((g_235 = ((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*61*//* ___SAFE__OP */(((++(*g_349)) == (((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*62*//* ___SAFE__OP */((((*g_267)--) <= (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*63*//* ___SAFE__OP */((*g_136), (*l_859)))), (l_888[3][8][3] == (l_903[0][0][0] = (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*64*//* ___SAFE__OP */(((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*65*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*66*//* ___SAFE__OP */((*l_859), (l_898 = (l_895[2][0] == &l_872)))) <= (g_170 = (((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*67*//* ___SAFE__OP */((p_25.f1 > p_25.f1), l_901)) && 0x4FAB09B2L) | (*g_136)))), l_872)) ^ (*p_24)), (*p_24))))))) , p_25.f1) < 0x0BE8L)), 0)) & p_25.f1)) | 0x8B1394D3E8714854LL);
        }
        else
        { /* block id: 391 */
            int32_t *l_924 = &l_903[0][0][0];
            union U0 l_957 = {0};
            int64_t **l_998 = &l_865;
            uint32_t *****l_1006;
            int32_t l_1017 = (-10L);
            int32_t l_1020 = 0L;
            int32_t l_1021 = 0x66938220L;
            int32_t l_1022 = 0x91624045L;
            int32_t l_1023 = 0x3D06DBF3L;
            int32_t l_1025[2][9][6] = {{{(-9L),0x9C610CACL,(-3L),0x4B8E94F1L,0x3EF86388L,0x09FC31C7L},{2L,9L,0x34CE5E84L,0x6217ECF1L,0x34CE5E84L,9L},{(-3L),7L,0xEEE1AFF2L,0x9C610CACL,0x15663A92L,0xA1B6221CL},{7L,0x11469EBEL,0x4B988A53L,0x09FC31C7L,0x170CD774L,4L},{0L,0x11469EBEL,0x249D51D4L,0xDBE99D3DL,0x15663A92L,0x86BAB8FDL},{0xA1B6221CL,7L,0x6E2635A6L,8L,0x34CE5E84L,0x2833551CL},{1L,9L,0x7610CF40L,(-3L),0x3EF86388L,0x7720C34DL},{0x7720C34DL,0x9C610CACL,0xA01207CEL,(-1L),0x09FC31C7L,1L},{9L,1L,(-9L),0x5EA54F00L,0x5EA54F00L,(-9L)}},{{0x2610ACB5L,0x2610ACB5L,(-1L),0L,7L,0x9C610CACL},{0x34CE5E84L,1L,0x170CD774L,0x11469EBEL,(-9L),(-1L)},{1L,0x34CE5E84L,0x170CD774L,0x7610CF40L,0x2610ACB5L,0x9C610CACL},{0x69E03DA0L,0x7610CF40L,(-1L),4L,0x86BAB8FDL,(-9L)},{4L,0x86BAB8FDL,(-9L),1L,2L,1L},{0x249D51D4L,(-1L),0xA01207CEL,1L,0x6217ECF1L,0x7720C34DL},{0x6217ECF1L,0x4B33BFF3L,0x7610CF40L,0x2833551CL,(-1L),0x2833551CL},{0x6E2635A6L,0x7720C34DL,0x6E2635A6L,0x4B988A53L,0x6E2635A6L,(-5L)},{4L,0x11469EBEL,1L,1L,2L,1L}}};
            union U0 l_1090;
            int8_t *l_1093 = &g_170;
            int32_t l_1204 = (-6L);
            int16_t * const *l_1238 = &l_1190;
            int32_t *l_1250 = &l_903[2][2][1];
            int32_t *l_1251;
            int32_t *l_1252 = &l_1025[1][5][5];
            int32_t *l_1253 = &l_1025[1][5][5];
            int32_t *l_1254[4];
            uint64_t l_1255 = 0xBCD28C3B57E9D0EDLL;
            int32_t l_1265;
            uint8_t *****l_1295 = (void*)0;
            union U1 *l_1348 = &g_851;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_1254[i] = &g_851.f0;
            if ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*68*//* ___SAFE__OP */(p_25.f1, ((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*69*//* ___SAFE__OP */((+((*g_136) = (*g_136))), 0xD29EL)) , ((((((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*70*//* ___SAFE__OP */(((*l_924) |= ((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*71*//* ___SAFE__OP */(0x30L, (((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*72*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*73*//* ___SAFE__OP */((l_898 = ((*l_865) |= (safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*74*//* ___SAFE__OP */((*l_859), ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*75*//* ___SAFE__OP */((g_851 , 0L), ((void*)0 != l_922[0][5][5]))) != p_25.f1))))), p_25.f1)), g_381)) , p_25.f1) > (*l_859)))) != (**g_406))), 5L)) & 4294967292UL) != 65528UL) || g_518) < 4294967293UL) & (*g_136))))))
            { /* block id: 396 */
                uint16_t *l_933 = (void*)0;
                uint16_t *l_934;
                uint16_t *l_935 = &g_369.f1;
                uint16_t *l_936[9][4] = {{&l_872,(void*)0,(void*)0,&l_872},{(void*)0,&l_872,&g_50,&g_50},{&g_369.f1,&g_369.f1,&g_598,&g_50},{&g_369.f1,(void*)0,&g_50,&g_369.f1},{(void*)0,&g_50,(void*)0,&g_50},{&l_872,&g_50,&g_598,&g_369.f1},{&g_50,(void*)0,(void*)0,&g_50},{(void*)0,&g_369.f1,(void*)0,&g_50},{&g_50,&l_872,&g_598,&l_872}};
                uint8_t **l_943 = (void*)0;
                uint8_t **l_944;
                uint8_t **l_945[9][6][4] = {{{&g_350[5],(void*)0,&g_350[0],&g_350[1]},{&g_350[1],&g_350[1],&g_350[1],(void*)0},{&g_350[1],&g_350[5],&g_350[1],&g_350[5]},{&g_350[1],&g_350[0],&g_350[0],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[1],&g_350[5],&g_350[4],&g_350[1]}},{{&g_350[1],&g_350[1],&g_350[0],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[1],&g_350[1],&g_350[1],&g_350[1]},{&g_350[1],&g_350[0],&g_350[1],&g_350[5]},{&g_350[1],&g_350[1],&g_350[0],&g_350[1]},{&g_350[5],&g_350[1],(void*)0,&g_350[5]}},{{&g_350[1],&g_350[0],&g_350[1],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[5],&g_350[1],&g_350[5],&g_350[1]},{&g_350[1],&g_350[1],&g_350[1],&g_350[1]},{(void*)0,&g_350[5],&g_350[1],&g_350[0]},{&g_350[1],&g_350[1],&g_350[5],&g_350[1]}},{{&g_350[5],&g_350[0],&g_350[0],&g_350[5]},{&g_350[0],&g_350[5],&g_350[1],(void*)0},{&g_350[1],&g_350[1],(void*)0,&g_350[1]},{&g_350[5],(void*)0,&g_350[0],&g_350[1]},{&g_350[1],&g_350[1],&g_350[1],(void*)0},{&g_350[1],&g_350[5],&g_350[1],&g_350[5]}},{{&g_350[1],&g_350[0],&g_350[0],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[1],&g_350[5],&g_350[4],&g_350[1]},{&g_350[1],&g_350[1],&g_350[0],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[1],&g_350[1],&g_350[1],&g_350[1]}},{{&g_350[1],&g_350[0],&g_350[1],&g_350[5]},{&g_350[1],&g_350[1],&g_350[0],&g_350[1]},{&g_350[5],&g_350[1],(void*)0,&g_350[5]},{&g_350[1],&g_350[0],&g_350[1],&g_350[1]},{&g_350[0],&g_350[1],&g_350[0],&g_350[0]},{&g_350[5],&g_350[1],&g_350[5],&g_350[1]}},{{&g_350[1],(void*)0,&g_350[4],&g_350[0]},{&g_350[5],&g_350[0],&g_350[4],(void*)0},{(void*)0,(void*)0,&g_350[1],&g_350[1]},{&g_350[0],(void*)0,(void*)0,&g_350[0]},{(void*)0,&g_350[0],(void*)0,&g_350[5]},{(void*)0,(void*)0,&g_350[1],&g_350[1]}},{{&g_350[0],&g_350[5],&g_350[1],&g_350[1]},{(void*)0,(void*)0,&g_350[4],&g_350[5]},{&g_350[0],&g_350[0],&g_350[1],&g_350[0]},{(void*)0,(void*)0,&g_350[1],&g_350[1]},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_350[0],&g_350[2],&g_350[0]}},{{(void*)0,(void*)0,(void*)0,&g_350[1]},{(void*)0,&g_350[0],&g_350[1],&g_350[1]},{(void*)0,(void*)0,&g_350[1],&g_350[0]},{&g_350[0],(void*)0,&g_350[4],&g_350[0]},{(void*)0,(void*)0,&g_350[1],&g_350[4]},{&g_350[0],(void*)0,&g_350[1],&g_350[0]}}};
                uint8_t *l_946 = &g_897;
                int32_t l_960 = 0xC89CE751L;
                int32_t *l_985 = &l_877;
                uint32_t **l_1008 = (void*)0;
                int32_t l_1011 = 0L;
                int32_t l_1012;
                int32_t l_1016 = 0x66277CFDL;
                int32_t l_1019[8][2] = {{(-9L),8L},{0xB039BCDFL,8L},{(-9L),0x6FF09861L},{0x6FF09861L,(-9L)},{8L,0xB039BCDFL},{8L,(-9L)},{0x6FF09861L,0x6FF09861L},{(-9L),8L}};
                uint16_t l_1035 = 0UL;
                uint16_t l_1040 = 65531UL;
                union U0 *l_1058[7] = {&g_369,(void*)0,&g_369,&g_369,(void*)0,&g_369,&g_369};
                union U0 *l_1059 = &l_957;
                int i, j, k;
                (*g_849) = (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*76*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*77*//* ___SAFE__OP */(p_25.f1, ((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*78*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*79*//* ___SAFE__OP */((((*p_24) | ((*g_267) & (l_937++))) , (*l_859)), (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*80*//* ___SAFE__OP */((g_598 ^= (l_903[7][1][0] ^= (((safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*81*//* ___SAFE__OP */(((g_350[2] = ((*l_944) = l_863)) == l_946))) | g_10) < (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*82*//* ___SAFE__OP */((***g_405), ((void*)0 != &l_859)))))), g_518)))) , (*l_924)), 0x99BCL)) && 9L))), p_25.f1));
                for (g_50 = 0; (g_50 >= 2); g_50 = safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*83*//* ___SAFE__OP */(g_50, 3))
                { /* block id: 405 */
                    uint32_t l_982 = 0xDD76BA4FL;
                    for (l_937 = (-6); (l_937 == 4); l_937 = safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*84*//* ___SAFE__OP */(l_937, 4))
                    { /* block id: 408 */
                        uint32_t l_981 = 0xAEF4F52BL;
                        int16_t *l_983 = &g_518;
                        int8_t *l_984 = &g_369.f3;
                        int32_t **l_987;
                        int32_t **l_988 = &l_985;
                        (*l_924) = (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*85*//* ___SAFE__OP */((p_26 , (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*86*//* ___SAFE__OP */(((l_957 = p_26) , 7UL), (safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*87*//* ___SAFE__OP */(l_960, 22))))), (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*88*//* ___SAFE__OP */((((*l_984) = ((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*89*//* ___SAFE__OP */(l_960, 7)) , (((*l_983) = ((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*90*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*91*//* ___SAFE__OP */((((((p_25 = g_37) , (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*92*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*93*//* ___SAFE__OP */(((((**l_944) = (l_903[0][0][0] < ((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*94*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*95*//* ___SAFE__OP */((4L > ((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*96*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*97*//* ___SAFE__OP */((*g_407), l_981)), (*g_267))) >= l_982)), 1)), l_960)) < (*l_859)))) , l_937) & (*l_859)), l_872)) < 4294967295UL), l_982))) , (*l_924)) & (*l_924)) , g_179[6]), l_903[0][0][0])) || g_195), 6)) >= (*l_924))) > (*l_859)))) == 0xC4L), l_937))));
                        (*l_988) = l_985;
                        if ((*l_924))
                            break;
                        if ((*p_24))
                            break;
                    }
                }
                if ((*l_985))
                { /* block id: 420 */
                    int64_t **l_997;
                    int8_t *l_1005[5][6] = {{(void*)0,&g_137[5],(void*)0,&g_137[6],&g_137[6],(void*)0},{&g_137[0],&g_137[0],&g_137[6],&g_369.f3,&g_137[6],&g_137[0]},{&g_137[6],&g_137[5],&g_369.f3,&g_369.f3,&g_137[5],&g_137[6]},{&g_137[0],&g_137[6],&g_369.f3,&g_137[6],&g_137[0],&g_137[0]},{(void*)0,&g_137[6],&g_137[6],(void*)0,&g_137[5],(void*)0}};
                    int32_t l_1015;
                    int32_t l_1018 = 6L;
                    int32_t l_1024 = 0x3ADE1FABL;
                    int32_t l_1026;
                    int32_t l_1027 = 3L;
                    int32_t l_1028;
                    int32_t l_1029 = (-7L);
                    int32_t l_1030 = 1L;
                    int32_t l_1031 = 0xBF9B326BL;
                    uint32_t l_1032[10] = {8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL};
                    int i, j;
                    if (((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*98*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*99*//* ___SAFE__OP */((((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*100*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*101*//* ___SAFE__OP */(((l_997 != l_998) | ((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*102*//* ___SAFE__OP */((0L <= (g_137[0] || ((*g_267) || ((void*)0 != l_1003)))), 15)) <= (g_369.f3 = (g_170 = (l_903[9][3][1] < (*g_267)))))), 1L)), 60)) , l_1006) != l_1007), 0)), (*g_136))) , 0x1E649E83L))
                    { /* block id: 423 */
                        int32_t *l_1010[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        (*l_924) &= 0xF8CB843AL;
                        l_1009 = l_1008;
                        ++l_1032[2];
                        l_1035++;
                    }
                    else
                    { /* block id: 428 */
                        return l_946;
                    }
                }
                else
                { /* block id: 431 */
                    uint8_t l_1050 = 0x1EL;
                    const uint32_t *****l_1057 = (void*)0;
                    (*l_985) = (*l_985);
                    for (g_37.f0 = 1; (g_37.f0 >= 0); g_37.f0 -= 1)
                    { /* block id: 435 */
                        int64_t l_1041[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1041[i] = 0x331ECFB48BDDF6ABLL;
                        (*l_924) = (l_1041[0] &= (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*103*//* ___SAFE__OP */(l_1040, (((*l_985) = 0x3D76D7E9L) <= (*p_24)))));
                        (*l_924) &= (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*104*//* ___SAFE__OP */(0xF335DDF242587AE4LL, 57));
                        (*l_985) = ((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*105*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*106*//* ___SAFE__OP */(((**l_998) |= ((0xD6L ^ (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*107*//* ___SAFE__OP */((-1L), ((g_4[3] >= (l_1050 <= (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*108*//* ___SAFE__OP */((*g_443), l_1050)))) , (safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*109*//* ___SAFE__OP */(((((((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*110*//* ___SAFE__OP */((0x80L <= (*g_136)), (((void*)0 != l_1057) >= l_1050))) >= l_903[0][0][0]) || 0x3FB9D0E1107FCF62LL) < (*g_443)) ^ (*l_859)) <= (-3L)), (*l_924))))))) , 0x202DA61C4AEA53A5LL)), g_4[2])), 8)) || 18446744073709551615UL);
                    }
                    l_1059 = l_1058[2];
                    (*l_1004) = &l_1017;
                }
            }
            else
            { /* block id: 446 */
                int8_t l_1066 = 1L;
                int32_t *l_1070 = (void*)0;
                int32_t *l_1071 = &g_37.f0;
                int32_t *l_1072 = (void*)0;
                int32_t *l_1073;
                int32_t *l_1074 = &l_1025[1][5][5];
                union U0 l_1106;
                uint16_t *l_1166[6];
                uint8_t ****l_1209 = (void*)0;
                union U1 l_1246 = {0xFCB952A8L};
                union U0 * const l_1249 = &l_1090;
                int i;
                for (i = 0; i < 6; i++)
                    l_1166[i] = &l_872;
                (*l_924) &= ((void*)0 != &g_235);
                (*l_1074) |= (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*111*//* ___SAFE__OP */(0xC183ADB39C1589F7LL, ((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*112*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*113*//* ___SAFE__OP */(((*g_349)--), 6)), (((((*g_453) == 4294967295UL) < p_25.f1) > (((((((((((p_25.f1 , (((g_179[6] ^ ((*g_443) = 0x24BB269DL)) ^ (((void*)0 == &g_235) , p_25.f1)) , l_898)) != 1UL) >= 0xB185B7C3570607A4LL) < 0xBAL) , l_863) != l_863) , &g_628[2]) != l_1069) , (*g_267)) ^ (*l_924)) ^ p_25.f1)) | (-7L)))) != 5UL)));
                for (g_170 = 0; (g_170 <= 1); g_170 += 1)
                { /* block id: 453 */
                    uint32_t **l_1096 = &g_343[9][1];
                    int32_t l_1160 = (-1L);
                    union U1 *l_1171[1][6][6] = {{{(void*)0,&g_37,&g_851,&g_37,&g_37,&g_851},{(void*)0,(void*)0,&g_37,&g_37,(void*)0,&g_37},{&g_37,(void*)0,&g_37,&g_851,&g_37,&g_37},{&g_37,&g_37,&g_37,&g_37,(void*)0,&g_37},{&g_37,&g_37,&g_37,&g_37,&g_37,&g_851},{&g_37,&g_37,&g_851,&g_851,&g_37,&g_37}}};
                    int16_t *l_1189;
                    int16_t **l_1188;
                    int8_t **l_1203 = &g_136;
                    int8_t ***l_1202 = &l_1203;
                    uint8_t ** const **l_1211 = (void*)0;
                    uint8_t ** const ***l_1210[2][5] = {{&l_1211,&l_1211,&l_1211,&l_1211,&l_1211},{&l_1211,&l_1211,(void*)0,&l_1211,&l_1211}};
                    int64_t *l_1235 = &g_1164;
                    int16_t * const *l_1240 = (void*)0;
                    int i, j, k;
                    for (l_898 = 0; (l_898 <= 4); l_898 += 1)
                    { /* block id: 456 */
                        const int8_t l_1086[5][8] = {{0x16L,(-5L),0x97L,0x97L,(-5L),0x8CL,0xFAL,(-5L)},{0x8CL,0x1FL,0xE4L,0x97L,0xFAL,0x97L,0xE4L,0x1FL},{(-5L),0xE4L,0x16L,0x97L,(-5L),0xBBL,0xBBL,(-5L)},{0x2FL,(-5L),(-5L),0x2FL,(-5L),0x1FL,0xBBL,0x8CL},{0xE4L,0x2FL,0x16L,0xBBL,0x16L,0x2FL,0xE4L,0xFAL}};
                        int i, j;
                        g_2[l_898] = ((*l_1071) = (safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*114*//* ___SAFE__OP */((&l_922[0][6][7] == l_1007), (((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*115*//* ___SAFE__OP */(((*l_924) & (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*116*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*117*//* ___SAFE__OP */((~(((((((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*118*//* ___SAFE__OP */(((l_1086[1][3] != ((p_25 , ((+(safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*119*//* ___SAFE__OP */(((l_1090 , ((*g_349) = p_25.f1)) ^ ((void*)0 == &g_343[4][3])), g_2[1]))) <= 0x30497252L)) && (*l_859))) , (*g_136)), 252UL)) ^ 0L) ^ p_25.f1) != 0x4A17L) && 0x6C93L) <= 0xAEFA98C8L) != l_1091)), g_179[6])), (*g_443)))), l_1086[1][3])) ^ p_25.f1) >= p_25.f1))));
                        if ((*p_24))
                            continue;
                        (*l_1004) = l_1092;
                        return l_1093;
                    }
                    if ((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*120*//* ___SAFE__OP */((l_1096 != (void*)0), ((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*121*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*122*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*123*//* ___SAFE__OP */(((*g_267) = (safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*124*//* ___SAFE__OP */((((safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*125*//* ___SAFE__OP */(p_25.f1, (*p_24))) | (*g_349)) <= (*g_136)), ((((void*)0 != &g_482[7][2]) & (0x5EEBL > (*g_267))) > (-1L))))), g_57)), 0L)) & (*p_24)))) | g_170))))
                    { /* block id: 465 */
                        uint64_t *l_1109 = (void*)0;
                        uint64_t *l_1110;
                        uint64_t *l_1111[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int32_t l_1117 = (-8L);
                        int32_t l_1119[5];
                        uint16_t *l_1139 = &l_957.f1;
                        uint8_t *l_1149 = &g_897;
                        union U0 *l_1159;
                        int8_t *l_1161 = (void*)0;
                        int8_t *l_1162[10][3][4];
                        int64_t *l_1163[10][1][10];
                        int32_t l_1165 = 1L;
                        int i, j, k;
                        for (i = 0; i < 5; i++)
                            l_1119[i] = 0x7A7E01B5L;
                        (**l_1003) = func_27((l_1119[2] ^= ((((*l_1096) = p_24) == (void*)0) >= (l_1106 , ((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*126*//* ___SAFE__OP */(1UL, (g_235 = p_25.f1))) >= ((!(((**l_998) &= (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*127*//* ___SAFE__OP */(l_1115[1][1], (l_1116[0][1] ^ ((p_25.f1 != (((l_1117 , 0xD7L) , l_1118) != &l_865)) > g_75))))) ^ 1L)) , (*l_924)))))), g_4[3], (*g_453));
                        (*l_1073) = (safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*128*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*129*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*130*//* ___SAFE__OP */((g_4[2] , (l_1117 = (g_37 , (safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*131*//* ___SAFE__OP */(((*l_924) = (((*l_1092) = ((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*132*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*133*//* ___SAFE__OP */((p_26.f3 = (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*134*//* ___SAFE__OP */(((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*135*//* ___SAFE__OP */(((*g_349) = (~(l_1119[2] ^= (0x48B4EB688413E2A0LL < (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*136*//* ___SAFE__OP */((*g_267), 0x23DFL)))))), (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*137*//* ___SAFE__OP */(((((((((((!(safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*138*//* ___SAFE__OP */((-1L), (0x34025E78L & (safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*139*//* ___SAFE__OP */(((**l_998) &= ((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*140*//* ___SAFE__OP */(((((*l_1149)--) , (((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*141*//* ___SAFE__OP */((*g_443), (((safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*142*//* ___SAFE__OP */((((*g_136) |= (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*143*//* ___SAFE__OP */((!((&l_998 != &g_654) ^ 0x2B1173EA0B7CF1B2LL)), (**g_790)))) ^ 0xEBL), p_25.f1)) | (*g_267)) && (*l_1092)))) ^ (*p_24)) && (*l_1092))) <= 0xDA8BC114L), p_25.f1)) == (*l_924))), p_25.f1)))))) || p_25.f1) | 0UL) , p_25.f1) , l_1159) == l_1159) == 0xE1L) || (-7L)) != 4294967295UL) < p_25.f1), 18446744073709551613UL)))) ^ g_235), l_1160))), p_25.f1)), p_25.f1)) & p_25.f1)) == (*p_24))), 16))))), 9)), l_1165)), 6));
                        (*l_1092) ^= (((void*)0 == l_1166[5]) <= (p_25.f1 > 0xD3850949L));
                    }
                    else
                    { /* block id: 482 */
                        if ((*l_1092))
                            break;
                        l_1171[0][2][3] = &p_25;
                    }
                    (*l_1071) = (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*144*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*145*//* ___SAFE__OP */((++(*g_267)), 13)) | (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*146*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*147*//* ___SAFE__OP */((*l_924), 0xADD5E73AL)) <= ((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*148*//* ___SAFE__OP */((*l_1074), (((*l_865) = (((((*l_1188) = &g_518) != (g_1191 = l_1190)) <= ((void*)0 == l_1192)) > (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*149*//* ___SAFE__OP */(5L, (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*150*//* ___SAFE__OP */((((*l_1092) ^= (safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*151*//* ___SAFE__OP */((((*l_1202) = (void*)0) == (void*)0), 0))) && (*p_24)), (**g_406))))))) == l_1204))) < g_235)), p_25.f1))), g_175));
                    if (((((((((((*l_1071) = (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*152*//* ___SAFE__OP */((***g_405), (*g_136)))) , ((((((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*153*//* ___SAFE__OP */((l_1209 != (l_1212[5] = (void*)0)), 28)) == (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*154*//* ___SAFE__OP */((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*155*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*156*//* ___SAFE__OP */(((*l_1235) = (safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*157*//* ___SAFE__OP */((p_25.f1 <= (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*158*//* ___SAFE__OP */((((((((**l_998) = (((safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*159*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*160*//* ___SAFE__OP */(250UL, p_25.f1)), ((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*161*//* ___SAFE__OP */(((((*g_267) | (((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*162*//* ___SAFE__OP */(p_25.f1, 1UL)) , 0x76L) , p_25.f1)) > l_1160) <= (-2L)), (**g_406))) , p_25.f1))) == (*g_267)) , l_1160)) || 1L) , 18446744073709551614UL) , 0xDDL) | 255UL) || (*g_1191)), 1L))), 25))), p_25.f1)) != g_1236), (*g_267))), (*g_1191)))) & p_25.f1) || 1UL) , 0x7A52L) || p_25.f1)) > (*p_24)) == p_25.f1) <= (*p_24)) && (*g_136)) && (*p_24)) <= g_175) <= 255UL))
                    { /* block id: 497 */
                        return l_863;
                    }
                    else
                    { /* block id: 499 */
                        int16_t * const **l_1239[8][5] = {{(void*)0,&l_1238,(void*)0,&l_1238,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238},{(void*)0,&l_1238,&l_1238,&l_1238,&l_1238},{&l_1238,&l_1238,(void*)0,&l_1238,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238},{(void*)0,&l_1238,&l_1238,&l_1238,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}};
                        int32_t l_1245 = (-3L);
                        int i, j;
                        (**l_1003) = (void*)0;
                        (*l_1004) = func_27((p_25.f1 && ((((((((g_1237 = &g_1191) == (l_1240 = l_1238)) <= p_25.f1) <= 1L) >= (safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*163*//* ___SAFE__OP */(((void*)0 == &p_25), 0xC4L))) , l_1248) , (*l_1188)) == l_1166[5])), (*l_1092), (*p_24));
                        (*l_1092) |= ((l_1249 != &l_1090) , (p_25.f1 > (*g_136)));
                    }
                    for (g_37.f2 = 0; (g_37.f2 <= 1); g_37.f2 += 1)
                    { /* block id: 508 */
                        (**l_1003) = (*g_790);
                    }
                }
            }
            l_1255++;
            (*g_572) = (void*)0;
            if ((((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*164*//* ___SAFE__OP */((((*l_1190) = g_1260[3]) , ((*l_924) <= g_1164)), 4)) == (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*165*//* ___SAFE__OP */(0x6A1AL, 6L))) ^ (l_1265 &= ((*l_859) , (((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*166*//* ___SAFE__OP */((((*l_1250) , 0L) | (*p_24)), (*l_924))) | (-6L)) > (*l_1251))))))
            { /* block id: 517 */
                uint16_t *l_1275[5];
                const int32_t l_1286 = 0x674C0684L;
                int32_t l_1296 = (-1L);
                int32_t l_1300 = 0x57A53A71L;
                int32_t l_1302 = 1L;
                int32_t l_1303 = 0L;
                int32_t l_1304;
                int32_t l_1305 = 0xF89DD991L;
                int16_t l_1307 = 0x96FFL;
                int32_t l_1308 = 0xB43FB3C6L;
                int32_t l_1309 = 0x207CFF00L;
                int32_t l_1310 = (-1L);
                int32_t l_1312[7];
                int64_t l_1313 = 0xB006B8C83769AB2ELL;
                int i;
                for (i = 0; i < 5; i++)
                    l_1275[i] = &g_598;
                for (l_877 = (-26); (l_877 == (-10)); l_877 = safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*167*//* ___SAFE__OP */(l_877, 8))
                { /* block id: 520 */
                    int32_t *l_1271 = &l_1021;
                    int32_t l_1297 = 5L;
                    int32_t l_1298 = 0xD4EB95DCL;
                    int32_t l_1299;
                    int32_t l_1301[10];
                    int16_t l_1311 = (-9L);
                    int i;
                    for (i = 0; i < 10; i++)
                        l_1301[i] = 0xE29FBD2AL;
                    (*g_1268) = &g_369;
                    for (g_37.f2 = 10; (g_37.f2 != 20); g_37.f2++)
                    { /* block id: 524 */
                        int16_t l_1274 = (-1L);
                        uint16_t **l_1276 = (void*)0;
                        uint16_t **l_1277 = (void*)0;
                        uint16_t **l_1278[4][6] = {{&g_267,&g_267,&g_267,&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267,&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267,&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267,&g_267,&g_267,&g_267}};
                        uint16_t ***l_1284;
                        int i, j;
                        p_24 = l_1271;
                        (*l_1004) = p_24;
                        (*l_1253) ^= ((**g_572) | (((*l_1251) = (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*168*//* ___SAFE__OP */((7L <= ((((l_1279 = (l_1274 , l_1275[1])) == &l_872) >= ((l_1278[3][0] != (g_1285 = ((*l_1284) = ((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*169*//* ___SAFE__OP */(((0xD22BC701L & (*l_1250)) || (safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*170*//* ___SAFE__OP */((((*l_1251) , (*p_24)) ^ (*g_443)), 22))), (*l_1251))) , &g_267)))) && l_1286)) != (*l_1250))), l_1286))) >= (*g_443)));
                    }
                    (*l_1250) &= ((((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*171*//* ___SAFE__OP */((*l_859), ((((**l_1118) = ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*172*//* ___SAFE__OP */(0xE4E90463L, (*g_443))) , (*l_859))) < (safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*173*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*174*//* ___SAFE__OP */(0x0F4DL, 1)), 33))) && (((((*g_443) = (*l_1271)) || (*g_453)) , ((0L ^ ((l_1295 != (void*)0) & (*l_1271))) , l_1286)) & (*l_1251))))) != (*l_1252)) , &g_1285) != &g_1285);
                    ++l_1315;
                }
            }
            else
            { /* block id: 538 */
                int32_t l_1339[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                int i;
                for (p_25.f1 = 4; (p_25.f1 == (-21)); p_25.f1 = safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*175*//* ___SAFE__OP */(p_25.f1, 4))
                { /* block id: 541 */
                    uint64_t *l_1320;
                    uint64_t *l_1321 = &g_235;
                    int32_t l_1334 = 0x97BB1181L;
                    (*l_1253) = (*p_24);
                    (**l_1003) = func_27(((*l_1321) |= p_25.f1), (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*176*//* ___SAFE__OP */(0xD2BAL, p_25.f1)), ((--(*g_443)) || (((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*177*//* ___SAFE__OP */((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*178*//* ___SAFE__OP */(((l_1339[4] &= (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*179*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*180*//* ___SAFE__OP */((p_25.f1 | p_25.f1), l_1334)) , 0x18C9BAA5L), (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*181*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*182*//* ___SAFE__OP */((*p_24), (p_26.f4 = ((*l_1252) & 1L)))), l_1334))))) != l_1334), 0x7CL)), 0x49L)) && l_1339[4]) || l_1334)));
                    for (g_75 = 1; (g_75 == 10); g_75++)
                    { /* block id: 550 */
                        (*l_1092) = ((*l_1253) = 0xB19FA490L);
                    }
                    for (g_37.f3 = 19; (g_37.f3 >= (-2)); g_37.f3 = safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*183*//* ___SAFE__OP */(g_37.f3, 5))
                    { /* block id: 556 */
                        union U1 **l_1345;
                        union U1 *l_1347 = &l_1344[1];
                        union U1 **l_1346[9] = {&l_1347,&l_1347,&l_1347,&l_1347,&l_1347,&l_1347,&l_1347,&l_1347,&l_1347};
                        int16_t ***l_1350 = (void*)0;
                        int16_t ***l_1351 = &l_1349[0][2];
                        uint32_t *l_1352[10][3] = {{&l_937,(void*)0,&g_75},{&l_1247[2],&l_1247[2],&g_175},{&l_937,(void*)0,&g_75},{&l_1247[2],&l_1247[2],&g_175},{&l_937,(void*)0,&g_75},{&l_1247[2],&l_1247[2],&g_175},{&l_937,(void*)0,&g_75},{&l_1247[2],&l_1247[2],&g_175},{&l_937,(void*)0,&g_75},{&l_1247[2],&l_1247[2],&g_175}};
                        int32_t l_1361[6][10][2] = {{{(-8L),(-10L)},{3L,1L},{0L,0L},{0x63FE976CL,0xFE3B231AL},{0xC092F8BAL,0xFE3B231AL},{0x63FE976CL,0L},{0L,1L},{3L,(-10L)},{(-8L),1L},{(-1L),0x0D624082L}},{{0xBC85F4DBL,(-1L)},{0L,0x345F398CL},{0x3BA3BBCEL,0L},{0xBC85F4DBL,0xFE3B231AL},{0L,1L},{1L,(-1L)},{3L,0L},{1L,0L},{(-8L),0x0D624082L},{0xC092F8BAL,8L}},{{0x2035DAD1L,0xCB3C432CL},{0xC092F8BAL,0xC092F8BAL},{0xEA1DE81EL,0xBC85F4DBL},{1L,0L},{(-3L),8L},{(-4L),(-3L)},{0x9A55E02AL,0x31BF32C5L},{0x9A55E02AL,(-3L)},{(-4L),8L},{(-3L),0L}},{{1L,0xBC85F4DBL},{0xEA1DE81EL,0xC092F8BAL},{0xC092F8BAL,0xCB3C432CL},{0x2035DAD1L,8L},{0x784904EEL,0x345F398CL},{(-1L),0xCB3C432CL},{0x9A55E02AL,0L},{0xEA1DE81EL,(-1L)},{0x2035DAD1L,0L},{0xBC85F4DBL,3L}},{{(-4L),0xBC85F4DBL},{0xC092F8BAL,0x31BF32C5L},{0L,(-1L)},{(-4L),0x345F398CL},{(-1L),0L},{(-1L),(-3L)},{0xEA1DE81EL,0x9A55E02AL},{0L,0xCB3C432CL},{1L,3L},{0x784904EEL,3L}},{{1L,0xCB3C432CL},{0L,0x9A55E02AL},{0xEA1DE81EL,(-3L)},{(-1L),0L},{(-1L),0x345F398CL},{(-4L),(-1L)},{0L,0x31BF32C5L},{0xC092F8BAL,0xBC85F4DBL},{(-4L),3L},{0xBC85F4DBL,0L}}};
                        int i, j, k;
                        l_1348 = ((*l_1345) = (l_1344[0] , &l_1248));
                        (*l_1351) = l_1349[0][2];
                        (*l_1252) = (l_1352[9][1] != ((((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*184*//* ___SAFE__OP */(((g_518 ^= (((*l_865) = (&l_1347 != ((1L < (+(g_2[1] , (safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*185*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*186*//* ___SAFE__OP */((((*l_1092) = (*g_849)) , p_25.f1), 6)) == (((((((p_25 , &g_1260[3]) == (void*)0) , (-1L)) != 0UL) == l_1334) <= g_4[3]) >= l_1334))))))) , (void*)0))) ^ g_175)) <= 0xD36FL), 28)) || l_1334) , l_1361[1][5][1]) , (void*)0));
                    }
                }
            }
        }
        for (l_898 = 25; (l_898 >= 2); l_898 = safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*187*//* ___SAFE__OP */(l_898, 1))
        { /* block id: 570 */
            uint8_t l_1365;
            uint16_t l_1374 = 4UL;
            int16_t *** const l_1391 = &g_1237;
            int32_t l_1404;
            int32_t l_1405[9][6] = {{(-5L),0xAE834484L,0xAE834484L,(-5L),0L,0x88AEBA43L},{(-10L),0x88AEBA43L,0x6A50D583L,4L,1L,4L},{0L,4L,0L,1L,1L,(-1L)},{0x6A50D583L,0x88AEBA43L,(-10L),0L,0L,(-10L)},{0xAE834484L,0xAE834484L,(-5L),0L,0x88AEBA43L,1L},{0x6A50D583L,(-5L),(-1L),1L,(-1L),(-5L)},{0L,0x6A50D583L,(-1L),4L,0xAE834484L,1L},{(-10L),4L,(-5L),(-5L),4L,(-10L)},{(-5L),4L,(-10L),1L,0xAE834484L,(-1L)}};
            int32_t ***l_1429 = (void*)0;
            int16_t l_1434[2][6][6] = {{{1L,0xC01EL,5L,0xC01EL,1L,0xC01EL},{0x290DL,(-1L),0x290DL,0xC01EL,0x290DL,(-1L)},{1L,(-1L),5L,(-1L),1L,(-1L)},{0x290DL,0xC01EL,0x290DL,(-1L),0x290DL,0xC01EL},{1L,0xC01EL,5L,0xC01EL,1L,0xC01EL},{0x290DL,(-1L),0x290DL,0xC01EL,0x290DL,(-1L)}},{{1L,(-1L),5L,(-1L),1L,(-1L)},{0x290DL,0xC01EL,0x290DL,(-1L),0x290DL,0xC01EL},{1L,0xC01EL,5L,0xC01EL,1L,0xC01EL},{0x290DL,(-1L),0x290DL,0xC01EL,0x290DL,(-1L)},{1L,(-1L),5L,(-1L),1L,(-1L)},{0x290DL,0xC01EL,0x290DL,(-1L),0x290DL,0xC01EL}}};
            int16_t l_1458 = 8L;
            int32_t l_1481 = 6L;
            int32_t l_1485;
            int i, j, k;
            for (g_235 = 0; (g_235 <= 8); g_235 += 1)
            { /* block id: 573 */
                int16_t l_1364 = 0xEC69L;
                (*l_1092) |= (((l_1364 > g_100) >= l_1364) != (((l_1364 & 0x184CBF56L) && (((l_1365 , (&g_343[9][4] != (void*)0)) == (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*188*//* ___SAFE__OP */((-1L), (*g_267)))) < 0x05L)) && g_137[5]));
            }
            (*l_1092) |= (*l_859);
            for (g_57 = 1; (g_57 >= 0); g_57 -= 1)
            { /* block id: 579 */
                uint16_t *l_1383;
                int32_t l_1384[10];
                int32_t *l_1385[9];
                int16_t l_1387;
                int8_t *l_1395 = (void*)0;
                int8_t **l_1396;
                int32_t *l_1397[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint8_t * const ****l_1403[2][6] = {{&g_1400,&g_1400,&g_1400,&g_1400,&g_1400,&g_1400},{&g_1400,&g_1400,&g_1400,&g_1400,&g_1400,&g_1400}};
                int8_t *l_1421 = &l_1115[1][2];
                int64_t ** const *l_1435 = (void*)0;
                uint32_t **l_1457[10][1][2];
                int8_t l_1482 = 0x74L;
                int i, j, k;
                for (i = 0; i < 9; i++)
                    l_1385[i] = (void*)0;
                l_1387 ^= (safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*189*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*190*//* ___SAFE__OP */(l_1365, (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*191*//* ___SAFE__OP */(((l_1365 & (l_1374++)) , (~g_175)), ((p_25 , (l_903[7][4][1] = ((*l_1092) = ((l_1365 == (safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*192*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*193*//* ___SAFE__OP */(((p_26 , 0x9563C2CCL) < (((((((((((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*194*//* ___SAFE__OP */(l_1365, (g_381 || g_1236))) , &g_1191) != &l_1190) != 9L) , l_1365) , l_1383) != &g_598) > l_1384[0]) , l_1384[0]) , l_1384[4]) , l_1365)), (*l_1092)))))) | l_1365)))) | l_1386[1][1][5]))))) != (*g_9)), 22));
                g_1388[6][5] = l_1007;
            }
        }
    }
    else
    { /* block id: 618 */
        return l_1489;
    }
    return &g_137[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_349 g_195 g_849 g_137
 * writes: g_57
 */
static int32_t * func_27(uint64_t  p_28, int32_t  p_29, int32_t  p_30)
{ /* block id: 361 */
    uint8_t l_847 = 0xF3L;
    int32_t *l_850[2];
    int i;
    for (i = 0; i < 2; i++)
        l_850[i] = &g_4[3];
    (*g_849) = (l_847 && (*g_349));
    return l_850[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_342 g_343 g_267 g_50 g_407 g_408 g_453 g_262 g_100 g_195 g_283 g_136 g_137 g_235 g_481 g_37.f1 g_443 g_75 g_518 g_4 g_2 g_37 g_10 g_421 g_403 g_572 g_37.f0 g_9 g_598 g_349 g_406 g_623 g_628 g_175 g_767 g_179 g_790
 * writes: g_37.f2 g_343 g_443 g_262 g_235 g_37.f1 g_482 g_75 g_283 g_518 g_179 g_403 g_37.f0 g_2 g_628 g_654 g_175 g_50 g_598
 */
static union U1  func_31(int32_t  p_32, union U1  p_33, uint64_t  p_34, int32_t  p_35, int64_t  p_36)
{ /* block id: 9 */
    uint64_t l_60 = 0xA4B1F059960698B4LL;
    const int32_t * const *l_378 = (void*)0;
    const volatile uint8_t * volatile * volatile *l_409 = &g_406;
    int32_t l_410 = (-9L);
    int32_t l_411 = 0xCA559DDDL;
    int32_t l_413 = (-2L);
    uint32_t ***l_431 = &g_342;
    uint32_t ***l_432;
    uint16_t **l_446 = (void*)0;
    int8_t l_449;
    int32_t l_541;
    int32_t l_542;
    int32_t l_544;
    int8_t l_546 = 1L;
    uint32_t l_570 = 0x594CD33DL;
    int16_t l_574 = (-6L);
    uint8_t l_577;
    volatile int32_t *l_580 = (void*)0;
    union U0 l_586 = {0};
    int16_t l_646 = 0x75BDL;
    uint64_t l_647 = 18446744073709551615UL;
    const int16_t l_669 = 1L;
    uint32_t l_675;
    int8_t l_710 = 1L;
    int32_t l_723;
    int32_t l_724 = 1L;
    int32_t l_725 = 0L;
    int32_t l_727 = 1L;
    int32_t l_728 = (-1L);
    int32_t l_729 = 0x8A460ED6L;
    int32_t l_731;
    int32_t l_732;
    int32_t l_733[10][6][4] = {{{0x52D66EC8L,0x8BD37BB3L,0xE9F8604EL,0x3D0A9C86L},{0x52D66EC8L,0xFABE7828L,0xB3DAE249L,0x00C75402L},{0x82A09B89L,0x3D0A9C86L,(-7L),0x12F9F613L},{3L,(-1L),0x9F75405DL,0x8BD37BB3L},{(-1L),0xFABE7828L,0xFABE7828L,(-1L)},{(-7L),0x52D66EC8L,1L,(-7L)}},{{0x29C58FB8L,0x65DE52D7L,0x9F75405DL,3L},{1L,0x9D735510L,(-1L),3L},{0x82A09B89L,0x65DE52D7L,0x12F9F613L,(-7L)},{0x8BD37BB3L,0x52D66EC8L,0xE9F8604EL,(-1L)},{0x00C75402L,0xFABE7828L,(-7L),0x8BD37BB3L},{0x82A09B89L,(-1L),0x82A09B89L,0x12F9F613L}},{{0x65DE52D7L,0x3D0A9C86L,0x9F75405DL,0x00C75402L},{0x3D0A9C86L,0xFABE7828L,0x9D735510L,0x3D0A9C86L},{(-7L),0x8BD37BB3L,0x9D735510L,(-7L)},{0x3D0A9C86L,3L,0x9F75405DL,0x65DE52D7L},{0x65DE52D7L,0x9D735510L,0x82A09B89L,1L},{0x82A09B89L,1L,(-7L),(-7L)}},{{0x00C75402L,0x00C75402L,0xE9F8604EL,0x29C58FB8L},{0x8BD37BB3L,0xFABE7828L,0x12F9F613L,0x52D66EC8L},{0x82A09B89L,0x29C58FB8L,(-1L),0x12F9F613L},{1L,0x29C58FB8L,0x9F75405DL,0x52D66EC8L},{0x29C58FB8L,0xFABE7828L,1L,0x29C58FB8L},{(-7L),0x00C75402L,0xFABE7828L,(-7L)}},{{(-1L),1L,0x9F75405DL,1L},{3L,0x9D735510L,(-7L),0x65DE52D7L},{0x82A09B89L,3L,0xB3DAE249L,(-7L)},{0x52D66EC8L,0x8BD37BB3L,0xE9F8604EL,0x3D0A9C86L},{0x52D66EC8L,0xFABE7828L,0xB3DAE249L,0x00C75402L},{0x82A09B89L,0x3D0A9C86L,(-7L),0x12F9F613L}},{{3L,(-1L),0x9F75405DL,0x8BD37BB3L},{(-1L),0xFABE7828L,0xFABE7828L,(-1L)},{(-7L),0x52D66EC8L,1L,(-7L)},{0x29C58FB8L,0x65DE52D7L,0x9F75405DL,3L},{1L,0x9D735510L,(-1L),3L},{0x82A09B89L,0x65DE52D7L,0x12F9F613L,(-7L)}},{{0x8BD37BB3L,0x52D66EC8L,0xE9F8604EL,(-1L)},{0x00C75402L,0xFABE7828L,(-7L),0x8BD37BB3L},{0x82A09B89L,1L,4L,0L},{0x12F9F613L,0x9D735510L,0x52D66EC8L,(-1L)},{0x9D735510L,0x0A6D6866L,0x9F75405DL,0x9D735510L},{0x10EB4B93L,(-7L),0x9F75405DL,1L}},{{0x9D735510L,(-7L),0x52D66EC8L,0x12F9F613L},{0x12F9F613L,0x9F75405DL,4L,0xB3DAE249L},{4L,0xB3DAE249L,1L,1L},{(-1L),(-1L),0x8BD37BB3L,0xFABE7828L},{(-7L),0x0A6D6866L,0L,0x82A09B89L},{4L,0xFABE7828L,8L,0L}},{{0xB3DAE249L,0xFABE7828L,0x52D66EC8L,0x82A09B89L},{0xFABE7828L,0x0A6D6866L,0xE9F8604EL,0xFABE7828L},{0x10EB4B93L,(-1L),0x0A6D6866L,1L},{1L,0xB3DAE249L,0x52D66EC8L,0xB3DAE249L},{(-7L),0x9F75405DL,0x10EB4B93L,0x12F9F613L},{4L,(-7L),6L,1L}},{{0x82A09B89L,(-7L),0x8BD37BB3L,0x9D735510L},{0x82A09B89L,0x0A6D6866L,6L,(-1L)},{4L,0x9D735510L,0x10EB4B93L,0L},{(-7L),1L,0x52D66EC8L,(-7L)},{1L,0x0A6D6866L,0x0A6D6866L,1L},{0x10EB4B93L,0x82A09B89L,0xE9F8604EL,1L}}};
    int32_t l_746[10][3][1] = {{{1L},{0xA5173CDDL},{0x82CCD542L}},{{(-1L)},{(-1L)},{0x82CCD542L}},{{0xA5173CDDL},{1L},{0xA5173CDDL}},{{0x82CCD542L},{(-1L)},{(-1L)}},{{0x82CCD542L},{0xA5173CDDL},{1L}},{{0xA5173CDDL},{0x82CCD542L},{(-1L)}},{{(-1L)},{0x82CCD542L},{0xA5173CDDL}},{{1L},{0xA5173CDDL},{0x82CCD542L}},{{(-1L)},{(-1L)},{0x82CCD542L}},{{0xA5173CDDL},{1L},{0xA5173CDDL}}};
    union U0 **l_751[4][4][5];
    int32_t **l_805 = &g_403;
    const uint32_t *l_812 = &g_175;
    const uint32_t **l_811 = &l_812;
    const uint32_t ***l_810[10][2][1];
    const uint32_t **** const l_809 = &l_810[8][0][0];
    uint16_t l_843;
    int i, j, k;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
                l_810[i][j][k] = &l_811;
        }
    }
lbl_550:
    for (p_36 = 0; (p_36 > 18); p_36 = safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*195*//* ___SAFE__OP */(p_36, 1))
    { /* block id: 12 */
        int32_t *l_65 = &g_4[0];
        union U0 l_422 = {0};
        for (g_37.f2 = 0; (g_37.f2 > 6); ++g_37.f2)
        { /* block id: 15 */
            int32_t *l_55;
            int32_t *l_56 = &g_57;
            int32_t *l_58 = &g_57;
            int32_t *l_59[2][7][3] = {{{&g_4[3],&g_4[3],&g_10},{&g_4[1],&g_4[4],&g_4[1]},{&g_4[3],&g_57,&g_57},{&g_57,&g_4[4],&g_4[3]},{&g_4[3],&g_4[3],&g_57},{&g_4[1],&g_4[1],&g_4[1]},{&g_4[3],&g_57,&g_10}},{{&g_57,&g_4[1],&g_4[3]},{&g_4[3],&g_4[3],&g_10},{&g_4[1],&g_4[4],&g_4[1]},{&g_4[3],&g_57,&g_57},{&g_57,&g_4[4],&g_4[3]},{&g_4[3],&g_4[3],&g_57},{&g_4[1],&g_4[1],&g_4[1]}}};
            const int32_t * const l_380 = &g_381;
            const int32_t * const *l_379 = &l_380;
            uint32_t l_418[9];
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_418[i] = 4294967295UL;
            ++l_60;
        }
    }
    if ((((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*196*//* ___SAFE__OP */(((l_410 = ((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*197*//* ___SAFE__OP */(0x45967417D791A89DLL, ((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*198*//* ___SAFE__OP */((l_410 > (((((**l_432) = (*g_342)) != (g_443 = &g_75)) <= ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*199*//* ___SAFE__OP */(p_35, (l_446 == &g_267))) || ((p_36 , (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*200*//* ___SAFE__OP */(0xCE88BC9AL, p_35))) ^ 0L))) , (*g_267))), l_413)) < l_449))) , 0xCDD0L)) >= p_33.f0), (*g_407))) ^ 9UL) > l_60))
    { /* block id: 171 */
        uint32_t l_452 = 0xD9B008D2L;
        int32_t l_472 = 0xB3827801L;
        int32_t l_473 = 0xB189075BL;
        uint64_t *l_474;
        int32_t *l_475[2][5][2] = {{{(void*)0,(void*)0},{&l_410,&g_262[4]},{(void*)0,&g_262[4]},{&l_410,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{&l_410,&g_262[4]},{(void*)0,&g_262[4]},{&l_410,(void*)0},{(void*)0,(void*)0}}};
        int i, j, k;
lbl_522:
        (*g_453) &= (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*201*//* ___SAFE__OP */(l_452, (0x9421CC5BL && 0x1E485413L)));
        p_32 = (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*202*//* ___SAFE__OP */((((*g_267) > p_34) < (-3L)), ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*203*//* ___SAFE__OP */(g_262[4], ((*l_474) &= (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*204*//* ___SAFE__OP */(((l_473 = (safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*205*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*206*//* ___SAFE__OP */(((+((1UL & (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*207*//* ___SAFE__OP */(p_32, (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*208*//* ___SAFE__OP */((l_472 = (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*209*//* ___SAFE__OP */(((safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*210*//* ___SAFE__OP */(((l_452 == ((g_100 ^ 0xE66D47B57BE5BDCALL) ^ g_195)) != 0x87L))) > g_283), 0x54L))), (*g_136)))))) , 0xBDB2L)) < (*g_267)), (*g_267))), 5))) , l_472), p_32))))) != 0x8E72DA09L)));
    }
    else
    { /* block id: 177 */
        uint32_t ****l_479;
        int32_t l_521[8][10][3] = {{{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L}},{{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L}},{{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L}},{{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L}},{{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L}},{{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L}},{{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L}},{{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L},{0L,0x77471809L,0x77471809L},{0x02F5DE10L,(-1L),0x02F5DE10L},{0L,0L,0x77471809L},{0xDCA65F81L,(-1L),0xDCA65F81L}}};
        int32_t l_532 = (-7L);
        int32_t l_533[5];
        int32_t l_536[9][1];
        int64_t **l_650[9];
        int16_t l_719 = (-10L);
        int16_t l_726 = 0x8EC5L;
        uint8_t **l_785[4][5][1] = {{{&g_350[1]},{(void*)0},{(void*)0},{&g_350[1]},{(void*)0}},{{(void*)0},{&g_350[1]},{(void*)0},{(void*)0},{&g_350[1]}},{{(void*)0},{(void*)0},{&g_350[1]},{(void*)0},{(void*)0}},{{&g_350[1]},{(void*)0},{(void*)0},{&g_350[1]},{(void*)0}}};
        int32_t *l_791 = (void*)0;
        int32_t *l_792 = &l_410;
        int32_t *l_793 = &l_723;
        int32_t *l_794;
        int32_t *l_795 = &l_727;
        int32_t *l_796;
        int32_t *l_797[7][9] = {{&l_723,&l_728,&l_727,&l_521[2][3][1],&l_733[2][0][1],&l_544,&l_544,&l_521[3][2][2],(void*)0},{&l_723,&l_724,(void*)0,(void*)0,&g_4[3],&g_4[3],(void*)0,(void*)0,&l_724},{&l_728,&l_544,&l_723,(void*)0,&l_541,(void*)0,(void*)0,&l_728,(void*)0},{&l_733[2][0][1],(void*)0,&g_4[3],&l_521[2][3][1],&l_731,(void*)0,&l_733[6][4][2],&l_413,&l_733[6][4][2]},{&l_413,&l_544,&l_411,&l_411,&l_544,&l_413,&l_727,&l_724,&l_733[6][4][2]},{&l_731,&l_724,&l_728,&l_521[3][2][2],&l_728,(void*)0,&l_413,&l_411,(void*)0},{&l_521[3][2][2],&l_728,&l_724,&l_731,&l_727,&l_733[2][0][1],&l_727,&l_731,&l_724}};
        uint8_t l_798;
        uint32_t l_844 = 0x6E068A08L;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_533[i] = 6L;
        for (i = 0; i < 9; i++)
            l_650[i] = &g_180;
        for (l_410 = 0; (l_410 <= 4); l_410 += 1)
        { /* block id: 180 */
            volatile int32_t *l_478 = &g_2[1];
            int32_t l_531 = 0xE1934669L;
            int32_t l_535 = (-5L);
            int32_t l_538 = 6L;
            int32_t l_539 = 0xF9C4AC58L;
            int32_t l_543;
            uint8_t **l_557[4][10] = {{&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349},{&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349},{&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349},{&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349}};
            uint8_t ***l_556[9][7] = {{&l_557[3][7],&l_557[0][9],&l_557[0][9],(void*)0,&l_557[0][9],(void*)0,&l_557[0][9]},{&l_557[3][1],&l_557[3][1],(void*)0,&l_557[0][9],&l_557[0][9],&l_557[2][4],&l_557[3][7]},{&l_557[3][7],(void*)0,(void*)0,(void*)0,(void*)0,&l_557[3][7],&l_557[0][9]},{&l_557[1][7],(void*)0,&l_557[0][9],&l_557[0][9],&l_557[0][9],&l_557[0][9],&l_557[0][9]},{&l_557[0][9],&l_557[0][9],(void*)0,&l_557[0][9],&l_557[0][9],&l_557[3][7],&l_557[0][9]},{&l_557[0][9],&l_557[3][1],&l_557[3][7],&l_557[0][9],&l_557[3][7],&l_557[3][1],&l_557[0][9]},{&l_557[3][1],(void*)0,&l_557[0][9],&l_557[0][9],&l_557[2][4],&l_557[3][7],&l_557[2][4]},{&l_557[3][1],&l_557[2][4],&l_557[2][4],&l_557[3][1],(void*)0,&l_557[1][7],&l_557[0][9]},{&l_557[0][9],&l_557[1][7],&l_557[0][9],(void*)0,(void*)0,&l_557[0][9],&l_557[1][7]}};
            uint8_t ****l_555;
            uint8_t l_562[4][4][4] = {{{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL}},{{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL}},{{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL}},{{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL},{0x0CL,0x0CL,0x3AL,0x3AL}}};
            union U0 l_563 = {0};
            uint8_t l_566 = 255UL;
            int32_t l_575 = 1L;
            int32_t l_576[6][10] = {{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L},{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L},{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L},{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L},{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L},{1L,0L,(-1L),0L,1L,1L,0L,(-1L),0L,1L}};
            int16_t l_599 = 0x63D8L;
            uint32_t ****l_657 = &l_432;
            int i, j, k;
            for (g_37.f1 = 0; (g_37.f1 <= 8); g_37.f1 += 1)
            { /* block id: 183 */
                volatile int32_t *l_477[7][8][2] = {{{&g_2[0],&g_2[l_410]},{(void*)0,(void*)0},{&g_2[l_410],&g_2[l_410]},{&g_3,&g_3},{(void*)0,&g_2[1]},{&g_2[l_410],&g_2[l_410]},{(void*)0,&g_2[3]},{&g_3,(void*)0}},{{(void*)0,&g_2[1]},{(void*)0,(void*)0},{&g_2[l_410],&g_2[l_410]},{&g_2[1],&g_2[1]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_2[l_410],&g_2[1]},{(void*)0,(void*)0}},{{&g_2[1],(void*)0},{(void*)0,&g_2[1]},{&g_2[l_410],&g_2[l_410]},{&g_2[l_410],&g_2[1]},{(void*)0,&g_3},{&g_2[1],(void*)0},{&g_3,&g_2[0]},{(void*)0,&g_2[1]}},{{&g_2[1],&g_2[l_410]},{&g_2[l_410],&g_2[l_410]},{&g_3,(void*)0},{&g_2[1],(void*)0},{&g_2[l_410],&g_3},{&g_3,&g_2[1]},{(void*)0,(void*)0},{&g_3,&g_2[1]}},{{&g_3,&g_2[l_410]},{(void*)0,(void*)0},{&g_2[2],&g_2[1]},{&g_2[1],&g_2[l_410]},{&g_3,&g_3},{&g_2[0],&g_2[1]},{(void*)0,&g_3},{&g_2[1],&g_2[l_410]}},{{&g_2[0],&g_2[0]},{&g_2[1],&g_2[2]},{&g_3,&g_2[l_410]},{&g_3,&g_2[l_410]},{&g_3,&g_2[2]},{&g_2[1],&g_2[0]},{&g_2[0],&g_2[l_410]},{&g_2[1],&g_3}},{{(void*)0,&g_2[1]},{&g_2[0],&g_3},{&g_3,&g_2[l_410]},{&g_2[1],&g_2[1]},{&g_2[2],(void*)0},{(void*)0,&g_2[l_410]},{&g_3,&g_2[1]},{&g_3,(void*)0}}};
                volatile int32_t **l_476[5];
                uint16_t l_515 = 65535UL;
                int8_t l_545 = (-1L);
                int i, j, k;
                l_478 = &g_2[l_410];
                for (l_60 = 0; (l_60 <= 4); l_60 += 1)
                { /* block id: 187 */
                    uint8_t **l_487;
                    uint64_t l_514[10][7][3] = {{{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL},{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL},{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL},{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL},{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL}},{{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL},{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL},{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL},{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL},{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL}},{{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL},{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL},{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL},{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL},{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL}},{{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL},{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL},{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL},{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL},{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL}},{{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL},{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x17C92054137E1939LL},{0x19A32693A10A6D18LL,0xC8516E9539AAE6CBLL,1UL},{0xC2EEBBADC442C092LL,0x17C92054137E1939LL,1UL},{1UL,0xC8516E9539AAE6CBLL,0xC8516E9539AAE6CBLL}},{{0x3377F6E0C2E72DC9LL,0x17C92054137E1939LL,0xB8096836F60C46DELL},{0x5FB24FD56F73BD5ELL,0xC8516E9539AAE6CBLL,0x3E622E1E5BECB555LL},{1UL,0x17C92054137E1939LL,0x222518352B957F12LL},{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL},{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL},{0xC8516E9539AAE6CBLL,0x463DE3613C404A4CLL,0x463DE3613C404A4CLL},{1UL,0x222518352B957F12LL,0x912B29C7893BD8DBLL}},{{1UL,0x463DE3613C404A4CLL,0x5689A9F81F4668C9LL},{0x17C92054137E1939LL,0x222518352B957F12LL,0x222518352B957F12LL},{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL},{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL},{0xC8516E9539AAE6CBLL,0x463DE3613C404A4CLL,0x463DE3613C404A4CLL},{1UL,0x222518352B957F12LL,0x912B29C7893BD8DBLL},{1UL,0x463DE3613C404A4CLL,0x5689A9F81F4668C9LL}},{{0x17C92054137E1939LL,0x222518352B957F12LL,0x222518352B957F12LL},{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL},{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL},{0xC8516E9539AAE6CBLL,0x463DE3613C404A4CLL,0x463DE3613C404A4CLL},{1UL,0x222518352B957F12LL,0x912B29C7893BD8DBLL},{1UL,0x463DE3613C404A4CLL,0x5689A9F81F4668C9LL},{0x17C92054137E1939LL,0x222518352B957F12LL,0x222518352B957F12LL}},{{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL},{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL},{0xC8516E9539AAE6CBLL,0x463DE3613C404A4CLL,0x463DE3613C404A4CLL},{1UL,0x222518352B957F12LL,0x912B29C7893BD8DBLL},{1UL,0x463DE3613C404A4CLL,0x5689A9F81F4668C9LL},{0x17C92054137E1939LL,0x222518352B957F12LL,0x222518352B957F12LL},{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL}},{{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL},{0xC8516E9539AAE6CBLL,0x463DE3613C404A4CLL,0x463DE3613C404A4CLL},{1UL,0x222518352B957F12LL,0x912B29C7893BD8DBLL},{1UL,0x463DE3613C404A4CLL,0x5689A9F81F4668C9LL},{0x17C92054137E1939LL,0x222518352B957F12LL,0x222518352B957F12LL},{0x3E622E1E5BECB555LL,0x463DE3613C404A4CLL,0xDC35C49650F0EF7ALL},{0xB8096836F60C46DELL,0x222518352B957F12LL,0xD715F2161BBA088DLL}}};
                    int16_t *l_516 = &g_283;
                    int16_t *l_517 = &g_518;
                    int32_t *l_519;
                    uint64_t *l_520 = &l_514[8][4][0];
                    int8_t *l_530 = &g_137[(l_60 + 2)];
                    int32_t l_534 = (-1L);
                    int32_t l_537[10];
                    int32_t l_540;
                    uint32_t l_547 = 0x0EB353DAL;
                    int i, j, k;
                    for (p_33.f2 = 0; (p_33.f2 <= 1); p_33.f2 += 1)
                    { /* block id: 190 */
                        uint32_t *****l_480;
                        (*l_480) = l_479;
                        (*g_481) = &g_405;
                    }
                    if ((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*211*//* ___SAFE__OP */(((safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*212*//* ___SAFE__OP */((&g_283 == (void*)0), (g_137[(l_60 + 2)] != ((void*)0 == l_487)))) , ((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*213*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*214*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*215*//* ___SAFE__OP */(((*l_520) = (g_262[g_37.f1] | (g_262[(l_410 - 3)] >= ((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*216*//* ___SAFE__OP */((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*217*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*218*//* ___SAFE__OP */(((*g_443)--), ((*l_519) |= ((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*219*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*220*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*221*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*222*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*223*//* ___SAFE__OP */(((*l_517) &= ((*l_516) = (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*224*//* ___SAFE__OP */(l_514[8][5][1], (l_515 = p_33.f2))))), (*g_267))), p_35)), 0x1E547E43L)), g_4[3])) | p_33.f2), 0)) < 65533UL)))), 1L)), p_36)) < 0L)))), (*l_478))), l_521[1][7][2])) & 0x5BE39B7CD2B70932LL), 247UL)) , p_36)), 2L)))
                    { /* block id: 200 */
                        int64_t l_523 = 0L;
                        uint8_t l_524 = 255UL;
                        if (p_36)
                            goto lbl_522;
                        ++l_524;
                        return g_37;
                    }
                    else
                    { /* block id: 204 */
                        int8_t **l_529[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_529[i] = &g_136;
                        (*l_519) = (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*225*//* ___SAFE__OP */(((*g_407) < ((((l_530 = (void*)0) == (void*)0) | l_531) | (*g_136))), 65530UL));
                    }
                    l_547++;
                }
                if (g_37.f1)
                    goto lbl_550;
                for (p_34 = 0; (p_34 <= 4); p_34 += 1)
                { /* block id: 213 */
                    uint8_t *****l_558 = (void*)0;
                    uint8_t ****l_559 = (void*)0;
                    int32_t *l_567[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int64_t *l_568 = (void*)0;
                    int64_t *l_569 = &g_179[6];
                    int i, j;
                    (*g_572) = ((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*226*//* ___SAFE__OP */((g_137[p_34] ^ (p_33.f4 = ((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*227*//* ___SAFE__OP */(((g_262[(p_34 / 1)] , (void*)0) != (l_559 = l_555)), ((*g_136) != (((++(*g_443)) <= (l_521[0][1][0] = ((((*l_569) = (l_562[2][3][2] == ((l_563 , (l_521[0][4][2] < ((((p_32 = (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*228*//* ___SAFE__OP */(((*l_478) || l_566), (-1L)))) , p_35) > g_10) || 65532UL))) || p_32))) ^ 0x55D4A9CED94427F6LL) > p_36))) , l_570)))) >= 0x76E6B65B423D3334LL))), 0x218A68623BAE886FLL)) , (*g_421));
                }
            }
            for (g_37.f0 = 3; (g_37.f0 >= 0); g_37.f0 -= 1)
            { /* block id: 225 */
                int32_t *l_573[8][7][4];
                uint32_t l_597 = 0UL;
                int i, j, k;
                --l_577;
                l_580 = &g_2[(g_37.f0 / 1)];
                (*l_580) = (!(g_2[(g_37.f0 + 1)] , (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*229*//* ___SAFE__OP */((p_34 != (p_33.f4 = (safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*230*//* ___SAFE__OP */((((*g_136) < p_32) & (*l_580)), ((((l_586 , &g_179[1]) != (((((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*231*//* ___SAFE__OP */(1UL, l_562[2][3][2])) ^ p_34) ^ p_35) ^ 0xCF25B94AL) || 0x9EB4L) , l_575) , &p_36)) == p_32) , (-10L)))))), l_543))));
                for (l_570 = 0; (l_570 <= 2); l_570 += 1)
                { /* block id: 232 */
                    int16_t l_589 = 0x2A07L;
                    uint32_t l_590[5][5][3] = {{{0x604D7991L,1UL,0x604D7991L},{0xADF56308L,0UL,0xB34EE707L},{0x630B3F9DL,0x630B3F9DL,18446744073709551615UL},{18446744073709551615UL,0UL,0UL},{18446744073709551615UL,1UL,0UL}},{{18446744073709551615UL,9UL,18446744073709551615UL},{0x630B3F9DL,18446744073709551615UL,0UL},{0xADF56308L,0xADF56308L,0UL},{0x604D7991L,18446744073709551615UL,18446744073709551615UL},{0UL,9UL,0xB34EE707L}},{{0x604D7991L,1UL,0x604D7991L},{0xADF56308L,0UL,0xB34EE707L},{0x630B3F9DL,0x630B3F9DL,18446744073709551615UL},{18446744073709551615UL,0UL,0UL},{18446744073709551615UL,1UL,0UL}},{{18446744073709551615UL,9UL,18446744073709551615UL},{0x630B3F9DL,18446744073709551615UL,0UL},{0xADF56308L,0xADF56308L,0UL},{0x604D7991L,18446744073709551615UL,18446744073709551615UL},{0UL,9UL,0xB34EE707L}},{{0x604D7991L,1UL,0x604D7991L},{0xADF56308L,0UL,0xB34EE707L},{0x630B3F9DL,0x630B3F9DL,18446744073709551615UL},{18446744073709551615UL,0UL,0UL},{18446744073709551615UL,1UL,0UL}}};
                    union U1 l_611 = {0L};
                    int32_t l_612[7] = {0x3822965BL,0x3822965BL,0x3822965BL,0x3822965BL,0x3822965BL,0x3822965BL,0x3822965BL};
                    uint16_t l_625 = 0x9E8DL;
                    int i, j, k;
                    (*l_580) = l_589;
                    g_262[4] |= (g_37 , ((*g_136) != (((((((l_590[2][0][1] , 0x6BL) & 0xBAL) || ((g_283 , ((((((*g_443) ^= (l_576[3][8] ^= (l_536[8][0] |= (((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*232*//* ___SAFE__OP */(((((safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*233*//* ___SAFE__OP */((0x94D5D3047AECDB17LL == 6L), (((safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*234*//* ___SAFE__OP */((-1L), p_32)) <= l_597) , (*g_9)))) , g_598) , 0xE2B50C5FL) != l_533[3]), 0x36L)) ^ 0x9285L) && (*g_136))))) == 3L) <= (*g_349)) ^ l_533[3]) <= l_590[2][0][1])) == p_36)) == (*g_349)) && (*g_267)) ^ l_599) > l_599)));
                    for (p_33.f0 = 0; (p_33.f0 <= 5); p_33.f0 += 1)
                    { /* block id: 240 */
                        int32_t **l_600 = &l_573[7][4][2];
                        (*l_600) = &p_35;
                    }
                    if (((l_589 >= g_4[4]) , ((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*235*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*236*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*237*//* ___SAFE__OP */(((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*238*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*239*//* ___SAFE__OP */((l_611 , g_262[4]), 11)), ((l_612[2] ^= 4294967295UL) , (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*240*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*241*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*242*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*243*//* ___SAFE__OP */((0x9D07L == l_536[2][0]), l_589)) < (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*244*//* ___SAFE__OP */(p_33.f0, l_590[2][0][1]))), p_33.f0)), p_34)), (**g_406)))))) | 0xB0D1BF560169BA07LL), 4294967288UL)) ^ (-1L)), l_532)), (-1L))) || g_598)))
                    { /* block id: 244 */
                        (*g_623) = &l_576[1][8];
                        (*l_580) |= p_34;
                        return g_37;
                    }
                    else
                    { /* block id: 248 */
                        const volatile int32_t **l_629 = (void*)0;
                        const volatile int32_t **l_630;
                        const volatile int32_t **l_631 = &g_628[2];
                        int i, j, k;
                        --l_625;
                        (*l_631) = g_628[2];
                    }
                }
            }
            for (l_60 = 0; (l_60 == 49); ++l_60)
            { /* block id: 256 */
                int32_t *l_634 = &l_576[4][6];
                int32_t *l_635 = &l_542;
                int32_t *l_636 = &l_521[1][2][0];
                int32_t *l_637 = &l_521[1][2][2];
                int32_t *l_638 = &l_536[3][0];
                int32_t *l_639;
                int32_t *l_640 = &g_37.f0;
                int32_t *l_641 = &l_521[0][5][2];
                int32_t *l_642 = &g_262[1];
                int32_t *l_643 = &l_539;
                int32_t *l_644 = &g_57;
                int32_t *l_645[10];
                int64_t ***l_651 = &l_650[7];
                int64_t ***l_653 = (void*)0;
                uint32_t *****l_658 = &l_479;
                int i;
                for (i = 0; i < 10; i++)
                    l_645[i] = (void*)0;
                l_647++;
                if (l_410)
                    goto lbl_550;
                g_654 = ((*l_651) = l_650[8]);
                (*l_658) = ((p_35 || (p_35 <= 0UL)) , l_657);
            }
            if (p_34)
            { /* block id: 263 */
                uint8_t l_670 = 0UL;
                int32_t *l_673 = (void*)0;
                int32_t *l_674[7] = {(void*)0,&l_544,&l_544,(void*)0,&l_544,&l_544,&l_544};
                int i;
                for (l_577 = 0; (l_577 <= 4); l_577 += 1)
                { /* block id: 266 */
                    int i;
                    p_33.f0 = (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*245*//* ___SAFE__OP */((0x80A61DA4L == (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*246*//* ___SAFE__OP */(((l_533[l_410] && (l_533[l_577] && (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*247*//* ___SAFE__OP */(0x7138L, (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*248*//* ___SAFE__OP */(0x6F3A8DB3L, l_533[l_577])))))) >= (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*249*//* ___SAFE__OP */((l_669 , (*l_478)), ((-1L) || 0xE926697539DC0F7FLL)))), l_533[l_577]))), g_75));
                    (*l_478) ^= p_34;
                    ++l_670;
                }
                l_675++;
                return g_37;
            }
            else
            { /* block id: 273 */
                int64_t l_678 = 0x7668AD302A235F98LL;
                if (l_678)
                    break;
            }
        }
        for (l_542 = 7; (l_542 >= 0); l_542 -= 1)
        { /* block id: 279 */
            union U1 l_686[2];
            uint64_t l_699[7];
            int32_t l_711 = 0L;
            int32_t l_714;
            int64_t l_715[7] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
            int32_t l_716[7][6][6];
            uint64_t l_764 = 18446744073709551615UL;
            int i, j, k;
            for (l_411 = 6; (l_411 >= 0); l_411 -= 1)
            { /* block id: 282 */
                uint16_t l_683 = 65530UL;
                int32_t l_698 = (-8L);
                int32_t l_712 = 0x59E65326L;
                int32_t l_713[7];
                uint64_t l_737[10];
                int i;
                for (p_35 = 0; (p_35 <= 7); p_35 += 1)
                { /* block id: 285 */
                    uint32_t l_680 = 1UL;
                    for (g_175 = 0; (g_175 <= 7); g_175 += 1)
                    { /* block id: 288 */
                        int32_t *l_679[1][4][7] = {{{(void*)0,&g_4[3],&l_541,&g_4[3],(void*)0,&l_411,(void*)0},{&g_10,&g_37.f0,&g_37.f0,&g_10,&g_37.f0,&g_37.f0,&g_10},{&l_544,&g_4[3],&l_544,&l_521[1][7][2],(void*)0,&l_521[1][7][2],&l_544},{&g_10,&g_10,&l_536[1][0],&g_10,&g_10,&l_536[1][0],&g_10}}};
                        int i, j, k;
                        l_680--;
                        l_683--;
                    }
                    return l_686[1];
                }
                if ((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*250*//* ___SAFE__OP */(((p_34 || p_32) & l_683), l_533[3])))
                { /* block id: 294 */
                    int16_t l_697 = 0x3E5AL;
                    int32_t l_717;
                    int32_t l_718;
                    int32_t l_721 = 0L;
                    int32_t l_722[6];
                    int16_t l_730 = 0x5382L;
                    int64_t l_735 = 0x6782C5E18654E381LL;
                    union U0 * const *l_740 = &g_368;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_722[i] = (-7L);
                    if (p_36)
                    { /* block id: 295 */
                        int32_t *l_689 = &l_536[3][0];
                        int32_t *l_690 = (void*)0;
                        int32_t *l_691 = &l_521[1][7][2];
                        int32_t *l_692 = &l_536[6][0];
                        int32_t *l_693 = &l_686[1].f0;
                        int32_t *l_694 = &l_544;
                        int32_t *l_695;
                        int32_t *l_696[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_696[i] = (void*)0;
                        l_699[5]++;
                    }
                    else
                    { /* block id: 297 */
                        int32_t *l_702 = &l_698;
                        int32_t *l_703;
                        int32_t *l_704;
                        int32_t *l_705;
                        int32_t *l_706;
                        int32_t *l_707 = &l_521[7][2][1];
                        int32_t *l_708;
                        int32_t *l_709[4][8] = {{&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0]},{&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0]},{&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0]},{&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0],&l_521[4][7][0],&l_536[6][0]}};
                        int32_t l_720 = 0x53BF7712L;
                        int64_t l_734;
                        int32_t l_736 = 1L;
                        int i, j;
                        l_737[2]--;
                        if (p_34)
                            break;
                        l_698 &= (0x40D2F2B9F6919E49LL >= (l_740 != (((+(-4L)) < (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*251*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*252*//* ___SAFE__OP */((l_746[1][2][0] && (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*253*//* ___SAFE__OP */(0xEA5F6A49L, (p_34 != (safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*254*//* ___SAFE__OP */((0xB085A1B8L != (*g_443)), ((*g_267) = ((g_50 | p_35) <= l_717)))))))), p_32)), (*l_706)))) , l_751[1][3][1])));
                    }
                    for (g_283 = (-7); (g_283 == (-1)); g_283 = safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*255*//* ___SAFE__OP */(g_283, 4))
                    { /* block id: 305 */
                        if (l_717)
                            goto lbl_550;
                    }
                    if (l_698)
                        break;
                }
                else
                { /* block id: 309 */
                    l_714 = (l_714 , p_32);
                }
                for (g_598 = 2; (g_598 <= 6); g_598 += 1)
                { /* block id: 314 */
                    int32_t *l_754;
                    int32_t *l_755;
                    int32_t *l_756;
                    int32_t *l_757 = (void*)0;
                    int32_t *l_758 = (void*)0;
                    int32_t *l_759 = &l_521[1][7][2];
                    int32_t *l_760 = &g_262[4];
                    int32_t *l_761 = &l_711;
                    int32_t *l_762;
                    int32_t *l_763[4][4][2] = {{{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]}},{{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]}},{{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]}},{{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]},{(void*)0,&g_262[4]}}};
                    int i, j, k;
                    l_764++;
                }
            }
            if (g_767)
                break;
            for (l_413 = (-29); (l_413 != 6); l_413 = safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*256*//* ___SAFE__OP */(l_413, 1))
            { /* block id: 321 */
                int16_t *l_772 = &g_518;
                int32_t *l_784 = &l_716[6][0][4];
                uint8_t l_788;
                for (g_518 = 0; (g_518 >= (-26)); g_518 = safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*257*//* ___SAFE__OP */(g_518, 1))
                { /* block id: 324 */
                    return g_37;
                }
                (*g_572) = ((((p_32 || ((*l_772) = p_32)) , ((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*258*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u/* ___REMOVE_SAFE__OP *//*259*//* ___SAFE__OP */((((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*260*//* ___SAFE__OP */((g_37 , (!(safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*261*//* ___SAFE__OP */(p_32, (((p_36 = (safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*262*//* ___SAFE__OP */((g_179[5] ^= ((~((*l_784) = p_36)) , p_36)), (((void*)0 == l_785[1][0][0]) || (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*263*//* ___SAFE__OP */((3L != p_36), p_35)))))) > p_34) && l_788))))), 0UL)) == (*g_443)) && l_719))), p_34)) < (-1L))) , 0xD9ABF6F0L) , &p_32);
                return l_686[1];
            }
            (*g_790) = (*g_623);
        }
        l_798++;
        for (l_449 = 0; (l_449 < 12); l_449 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*264*//* ___SAFE__OP */(l_449, 5))
        { /* block id: 339 */
            int32_t ***l_806 = &l_805;
            int32_t **l_808;
            int32_t ***l_807 = &l_808;
            int16_t l_836[5];
            int i;
            for (i = 0; i < 5; i++)
                l_836[i] = 0L;
            (*l_795) = ((((((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*265*//* ___SAFE__OP */(p_32, ((((*l_807) = ((*l_806) = l_805)) != &g_9) , g_408))) , l_809) == (void*)0) > (((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*266*//* ___SAFE__OP */(l_541, (~(0x630FL >= (!((+p_34) || p_35)))))) & p_32) , 255UL)) && p_34) <= 0xD12CD32BL);
            for (l_710 = 0; (l_710 > 15); l_710++)
            { /* block id: 345 */
                p_35 = 0xA5AAE23DL;
            }
            (*l_792) ^= (safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*267*//* ___SAFE__OP */((p_35 != (0x3FA9D866L & (((((*g_267) = 0x6FB0L) ^ (&g_789[3] == (void*)0)) | 0xDFL) == (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*268*//* ___SAFE__OP */(p_32, p_35))))), 19));
            for (g_518 = 0; (g_518 <= 6); g_518 += 1)
            { /* block id: 352 */
                (*l_796) &= ((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*269*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*270*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*271*//* ___SAFE__OP */((0UL && (safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*272*//* ___SAFE__OP */(g_4[2], (((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*273*//* ___SAFE__OP */((((*l_805) = (void*)0) == &p_35), (safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*274*//* ___SAFE__OP */(l_836[1], ((safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*275*//* ___SAFE__OP */(((*l_795) >= (((((((((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*276*//* ___SAFE__OP */((((((-1L) && ((p_35 || (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*277*//* ___SAFE__OP */((*g_267), g_408))) < 0x0DL)) < l_843) , p_36) , 0xD8L), p_34)) < g_137[0]) < 0x6E1BL) ^ (-4L)) , 6UL) >= (*g_136)) & 255UL) == p_32) || l_844)), 9)) || 0x52EDL))))) ^ g_137[0]) & p_36)))), p_36)), p_32)) >= 0x271FF07AL), p_36)) , p_32);
                return p_33;
            }
        }
    }
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_75 g_50 g_9 g_10 g_4 g_37.f2 g_3 g_100 g_136 g_137 g_2 g_131 g_175 g_195 g_235 g_170 g_262 g_179 g_342 g_37 g_349
 * writes: g_75 g_131 g_57 g_137 g_175 g_179 g_180 g_2 g_170 g_195 g_136 g_235 g_262 g_267 g_283 g_349 g_350 g_368
 */
static uint32_t  func_63(int32_t * p_64)
{ /* block id: 17 */
    const int16_t l_71[6] = {0xD189L,9L,0xD189L,0xD189L,9L,0xD189L};
    uint32_t *l_74 = &g_75;
    const int8_t *l_99;
    uint32_t *l_199;
    uint32_t **l_198 = &l_199;
    int8_t **l_202 = &g_136;
    int64_t *l_203 = (void*)0;
    int64_t *l_204;
    int32_t l_205 = 0L;
    uint16_t *l_206 = &g_50;
    int32_t *l_261 = &g_262[4];
    int32_t l_270 = 0L;
    int16_t l_291;
    int32_t l_294;
    int32_t l_295;
    uint8_t l_296[10][6] = {{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL},{0x0BL,0x0BL,0x0BL,0x0BL,0x0BL,0x0BL}};
    uint32_t *l_314 = &g_175;
    uint32_t l_353;
    union U0 l_360[9][3][9] = {{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}}};
    uint16_t l_365 = 0x0AACL;
    union U0 *l_367 = (void*)0;
    union U0 **l_366[9][2];
    uint8_t l_370 = 0UL;
    int i, j, k;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
            l_366[i][j] = &l_367;
    }
    if (((*l_261) |= func_66(l_71[2], (g_57 , (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*278*//* ___SAFE__OP */((l_205 = (((*l_74)--) | (((*l_202) = func_78(g_50, ((*l_198) = (func_82(func_84((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*279*//* ___SAFE__OP */(0x46L, l_71[1])), ((((!0x55EA0D0AL) != (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*280*//* ___SAFE__OP */((*g_9), (safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*281*//* ___SAFE__OP */(1L, ((safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*282*//* ___SAFE__OP */((0x7464L || l_71[2]), 1)) | g_10)))))) >= (*p_64)) && 0L), l_99, l_71[2], g_37.f2)) , (void*)0)), l_71[2])) == &g_100))), l_71[2]))), l_206, l_74)))
    { /* block id: 93 */
        uint16_t *l_265[9][5];
        uint16_t **l_266;
        int32_t l_268;
        int16_t *l_282 = &g_283;
        int32_t l_284 = 0L;
        int32_t l_285 = (-2L);
        int32_t l_287;
        int32_t l_288 = (-5L);
        int32_t l_289;
        int32_t l_290 = 0x0F418198L;
        int32_t l_292 = 0x9FCA5432L;
        int32_t l_293[1];
        int i, j;
        for (i = 0; i < 1; i++)
            l_293[i] = 0x224E523FL;
        if ((((*l_261) >= (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*283*//* ___SAFE__OP */(((1UL > ((((g_267 = l_265[3][3]) == l_265[8][3]) , l_268) <= (safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*284*//* ___SAFE__OP */(0x364DL)))) ^ l_270), (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*285*//* ___SAFE__OP */((l_285 ^= (((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*286*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*287*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*288*//* ___SAFE__OP */(((*l_282) = (!((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*289*//* ___SAFE__OP */((g_262[2] <= l_268), 0L)) & 0x0133L))), l_268)), 0L)), l_284)) == 0xFA98CA15L) == l_284)), g_10))))) && 0x40C61073L))
        { /* block id: 97 */
            int32_t *l_286[10];
            const int16_t l_311 = 0L;
            int64_t *l_312 = &g_179[6];
            int i;
            --l_296[8][4];
            l_295 ^= ((~(l_288 < (((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*290*//* ___SAFE__OP */(g_137[1], ((safe_unary_minus_func_int32_t_s/* ___REMOVE_SAFE__OP *//*291*//* ___SAFE__OP */((*p_64))) & ((g_195 && l_289) == (((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*292*//* ___SAFE__OP */(((*l_261) | (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*293*//* ___SAFE__OP */(((*l_312) ^= (g_100 >= (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*294*//* ___SAFE__OP */(l_311, 59)))), (safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*295*//* ___SAFE__OP */((l_314 == (void*)0)))))), g_137[4])) ^ (*l_261)) == g_137[0]))))) >= l_287) , l_284))) & 4UL);
        }
        else
        { /* block id: 101 */
            int32_t **l_315 = &l_261;
            (*l_315) = &l_295;
        }
        (*l_261) = ((void*)0 == &g_9);
        (*l_261) = (*g_9);
    }
    else
    { /* block id: 106 */
        uint32_t l_319[10][8];
        int16_t l_344 = (-4L);
        union U1 l_346;
        int32_t l_351 = (-2L);
        int i, j;
        for (l_294 = (-21); (l_294 != (-28)); l_294--)
        { /* block id: 109 */
            int32_t *l_318 = &l_205;
            int16_t *l_324 = &l_291;
            uint8_t *l_332 = &l_296[8][4];
            uint16_t l_335 = 65535UL;
            uint32_t **l_341;
            uint64_t *l_345 = &g_235;
            uint8_t **l_347;
            uint8_t **l_348[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t *l_352 = &g_57;
            int i;
            ++l_319[0][2];
            (*l_352) ^= (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*296*//* ___SAFE__OP */((&g_283 == l_324), (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*297*//* ___SAFE__OP */((((((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*298*//* ___SAFE__OP */((((g_350[1] = (g_349 = (((((~((((void*)0 == (*l_202)) <= ((*l_345) ^= (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*299*//* ___SAFE__OP */(((((((*l_261) &= ((*l_332) = g_4[3])) != ((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*300*//* ___SAFE__OP */(0x70L, l_335)) == (g_2[1] != (!(safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*301*//* ___SAFE__OP */((((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*302*//* ___SAFE__OP */(((l_341 != g_342) & 0x0AL), g_50)) , 1L) , l_344), g_137[0])))))) >= g_131) < g_195) != 0x4CL), 0xEB92BA8EL)))) ^ l_295)) , (-1L)) != 0x220542C8L) , l_346) , &l_296[1][1]))) == &g_195) , l_351), (*p_64))) , l_346.f0) | 6L) || (*p_64)) | (*l_318)), (*l_318)))));
            l_353 = l_319[0][2];
        }
        for (g_175 = (-21); (g_175 == 36); g_175++)
        { /* block id: 121 */
            (*l_261) = (*p_64);
            for (g_235 = (-28); (g_235 >= 55); g_235++)
            { /* block id: 125 */
                (*l_261) |= (*p_64);
            }
            (*l_261) ^= ((void*)0 == &l_199);
        }
    }
    (*l_261) = (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*303*//* ___SAFE__OP */((8L >= (l_360[1][0][1] , (0x14BD3B3BL <= (safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*304*//* ___SAFE__OP */((g_37 , ((++(*g_349)) ^ l_365)), (9L > 9UL)))))), ((*l_261) != 65535UL)));
    g_368 = &l_360[7][0][1];
    return l_370;
}


/* ------------------------------------------ */
/* 
 * reads : g_50 g_4 g_137 g_2 g_75 g_131 g_235 g_175 g_170
 * writes: g_75 g_131 g_235 g_57 g_136 g_170
 */
static int32_t  func_66(const int64_t  p_67, uint64_t  p_68, uint16_t * p_69, int32_t * p_70)
{ /* block id: 62 */
    uint8_t l_207 = 0x30L;
    int16_t l_219 = 0xF869L;
    int32_t l_224[8][8] = {{(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L)},{0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L)},{(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL},{(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L)},{0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L)},{(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL},{(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L),0xC2F5E6F3L,(-1L),(-1L)},{0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L),0x5F2AE77BL,0x5F2AE77BL,(-1L)}};
    int32_t l_225[6][7];
    int64_t l_227 = 0L;
    uint64_t *l_234 = &g_235;
    uint8_t *l_250 = &l_207;
    uint32_t *l_251;
    int8_t **l_252 = &g_136;
    volatile int32_t *l_260 = (void*)0;
    volatile int32_t **l_259 = &l_260;
    int i, j;
    if ((((l_225[1][5] = (l_207 && (0xD11F0E80B645F29CLL || ((l_207 & (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*305*//* ___SAFE__OP */((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*306*//* ___SAFE__OP */(((+((-2L) || (safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*307*//* ___SAFE__OP */(((void*)0 == &g_136), (l_224[0][0] ^= ((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*308*//* ___SAFE__OP */((((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*309*//* ___SAFE__OP */(l_219, (safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*310*//* ___SAFE__OP */(((0L != (safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*311*//* ___SAFE__OP */(((*p_69) < 1L), g_4[0]))) || g_137[5]), l_207)))) != g_2[1]) >= l_219), 2)) && 0x73B9L)))))) , l_224[0][0]), p_68)), 0L))) , p_68)))) <= l_219) > 4294967289UL))
    { /* block id: 65 */
        l_225[5][6] |= l_224[2][4];
        (*p_70) |= (+l_227);
        (*p_70) |= 0x49479A41L;
    }
    else
    { /* block id: 69 */
lbl_255:
        for (g_131 = (-29); (g_131 > 29); ++g_131)
        { /* block id: 72 */
            (*p_70) = (*p_70);
        }
        return (*p_70);
    }
    (*p_70) = (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*312*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*313*//* ___SAFE__OP */((((*l_252) = func_78((((*l_234)++) | ((((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*314*//* ___SAFE__OP */(l_219, (0xC4L > (safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*315*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*316*//* ___SAFE__OP */((p_67 || (-2L)), (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*317*//* ___SAFE__OP */((g_75 , (p_68 | ((*p_70) , ((*l_250) |= (safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*318*//* ___SAFE__OP */((g_175 != (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*319*//* ___SAFE__OP */((((*p_70) ^= 0xDFA724B1L) , l_227), l_219))), 4)))))), l_224[2][4])))), g_137[0]))))) >= p_67) & (-9L)) <= l_225[1][5])), l_251, p_67)) == &g_100), l_225[1][5])) > p_67), p_67));
    for (g_170 = 0; (g_170 != (-24)); g_170 = safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*320*//* ___SAFE__OP */(g_170, 6))
    { /* block id: 84 */
        uint32_t *l_257 = &g_175;
        uint32_t **l_256;
        uint32_t ***l_258 = &l_256;
        if (g_235)
            goto lbl_255;
        (*p_70) |= (l_251 == ((*l_256) = &g_175));
        (*l_258) = &l_251;
    }
    (*l_259) = &g_3;
    return (*p_70);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_57
 */
static int8_t * func_78(uint8_t  p_79, uint32_t * p_80, uint32_t  p_81)
{ /* block id: 57 */
    int32_t *l_200;
    int8_t *l_201;
    (*l_200) = ((void*)0 == &g_9);
    return l_201;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_10 g_57 g_136 g_137 g_50 g_4 g_100 g_2 g_131 g_175 g_3 g_195
 * writes: g_57 g_137 g_175 g_179 g_180 g_2 g_170 g_195
 */
static int16_t  func_82(int8_t * p_83)
{ /* block id: 24 */
    int32_t *l_138;
    uint16_t *l_168;
    int8_t *l_169 = &g_170;
    uint32_t l_171;
    int32_t * const l_173 = (void*)0;
    const int32_t l_177 = 0x9EEEF0C4L;
    int64_t *l_181[1];
    int8_t l_185 = 0L;
    int32_t l_187 = (-5L);
    int32_t l_188;
    int32_t l_189[8] = {8L,0xDC9179A2L,8L,0xDC9179A2L,8L,0xDC9179A2L,8L,0xDC9179A2L};
    int i;
    for (i = 0; i < 1; i++)
        l_181[i] = &g_179[6];
    (*l_138) ^= (*g_9);
    for (g_57 = 0; (g_57 <= 4); g_57 += 1)
    { /* block id: 28 */
        int32_t *l_156;
        int32_t **l_155 = &l_156;
        int32_t l_172;
        uint32_t *l_174[9] = {&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175};
        int32_t *l_176;
        union U0 l_193 = {0};
        uint8_t *l_194 = &g_195;
        int i;
        if ((((((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*321*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*322*//* ___SAFE__OP */(((*g_136) &= 0xBFL), (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*323*//* ___SAFE__OP */(((*l_138) | (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*324*//* ___SAFE__OP */(((*l_176) = (g_50 && (g_175 ^= (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*325*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*326*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*327*//* ___SAFE__OP */(((*l_138) <= ((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*328*//* ___SAFE__OP */((((*l_155) = &g_10) != ((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*329*//* ___SAFE__OP */(g_10, (((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*330*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*331*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*332*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*333*//* ___SAFE__OP */(((!((void*)0 != l_168)) | (l_169 != (void*)0)), g_4[3])) <= g_100) , (*l_138)), (*l_138))), 38)), l_171)) < (*l_138)) && g_2[4]) && (*l_138)) <= l_172))) , l_173)), l_172)) ^ 0xE7CEL)), g_131)) || 0xCA490DA0L), 4)), l_172))))), (*l_138)))), 0L)))), 0x801A4E0CL)) == l_177) | g_50) && g_3) && (*g_9)))
        { /* block id: 33 */
            int64_t *l_178 = &g_179[6];
            int i;
            g_2[g_57] = (((*l_178) = (*l_156)) || ((g_180 = l_178) == l_181[0]));
        }
        else
        { /* block id: 37 */
            int32_t *l_182 = (void*)0;
            int32_t *l_183;
            int32_t *l_184 = &l_172;
            int32_t *l_186[10][10][2] = {{{(void*)0,&g_4[2]},{&g_10,&g_10},{(void*)0,&l_172},{&g_4[3],(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{&g_10,(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{&g_4[3],&l_172}},{{(void*)0,&g_10},{&g_10,&g_4[2]},{(void*)0,&g_4[2]},{(void*)0,(void*)0},{&g_4[3],(void*)0},{&l_172,&g_10},{&g_10,&g_57},{(void*)0,&g_10},{&l_172,(void*)0},{&l_172,&g_10}},{{(void*)0,&g_57},{&g_10,&g_10},{&l_172,(void*)0},{&g_4[3],(void*)0},{(void*)0,&g_4[2]},{(void*)0,&g_4[2]},{&g_10,&g_10},{(void*)0,&l_172},{&g_4[3],(void*)0},{&g_10,&g_4[3]}},{{&g_10,(void*)0},{&g_10,(void*)0},{&g_10,&g_4[3]},{&g_10,(void*)0},{&g_4[3],&l_172},{(void*)0,&g_10},{&g_10,&g_4[2]},{(void*)0,(void*)0},{&g_10,&g_10},{(void*)0,(void*)0}},{{&l_172,&g_4[3]},{&g_10,&g_10},{&g_4[4],&g_10},{&g_4[3],&g_10},{&g_4[3],&g_10},{&g_4[4],&g_10},{&g_10,&g_4[3]},{&l_172,(void*)0},{(void*)0,&g_10},{&g_10,(void*)0}},{{&g_10,(void*)0},{&g_10,&g_4[3]},{&g_10,&l_172},{&g_4[2],&g_10},{&l_172,(void*)0},{(void*)0,&l_172},{&g_10,&l_172},{(void*)0,(void*)0},{&l_172,&g_10},{&g_4[2],&l_172}},{{&g_10,&g_4[3]},{&g_10,(void*)0},{&g_10,(void*)0},{&g_10,&g_10},{(void*)0,(void*)0},{&l_172,&g_4[3]},{&g_10,&g_10},{&g_4[4],&g_10},{&g_4[3],&g_10},{&g_4[3],&g_10}},{{&g_4[4],&g_10},{&g_10,&g_4[3]},{&l_172,(void*)0},{(void*)0,&g_10},{&g_10,(void*)0},{&g_10,(void*)0},{&g_10,&g_4[3]},{&g_10,&l_172},{&g_4[2],&g_10},{&l_172,(void*)0}},{{(void*)0,&l_172},{&g_10,&l_172},{(void*)0,(void*)0},{&l_172,&g_10},{&g_4[2],&l_172},{&g_10,&g_4[3]},{&g_10,(void*)0},{&g_10,(void*)0},{&g_10,&g_10},{(void*)0,(void*)0}},{{&l_172,&g_4[3]},{&g_10,&g_10},{&g_4[4],&g_10},{&g_4[3],&g_10},{&g_4[3],&g_10},{&g_4[4],&g_10},{&g_10,&g_4[3]},{&l_172,(void*)0},{(void*)0,&g_10},{&g_10,(void*)0}}};
            uint16_t l_190 = 7UL;
            int i, j, k;
            l_190++;
            if ((*g_9))
                break;
            for (g_170 = 0; (g_170 <= 6); g_170 += 1)
            { /* block id: 42 */
                int i;
                return g_137[(g_57 * 1)];
            }
        }
        (*l_176) = (*l_176);
        (*l_176) = (((*l_194) |= ((*g_9) && (l_193 , 0xF1D82268L))) && 0x18L);
    }
    for (l_171 = (-24); (l_171 < 14); ++l_171)
    { /* block id: 52 */
        return g_50;
    }
    return (*l_138);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_10 g_50 g_100 g_57 g_136
 * writes: g_131 g_57
 */
static int8_t * func_84(uint64_t  p_85, int32_t  p_86, const int8_t * p_87, uint16_t  p_88, const int32_t  p_89)
{ /* block id: 19 */
    uint64_t l_129[10][3][3];
    uint16_t *l_130 = (void*)0;
    int8_t l_134 = 1L;
    int32_t *l_135[4] = {&g_57,&g_57,&g_57,&g_57};
    int i, j, k;
    g_57 ^= (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*334*//* ___SAFE__OP */((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*335*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*336*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*337*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*338*//* ___SAFE__OP */((g_3 <= (safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*339*//* ___SAFE__OP */(((~((l_134 = (safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*340*//* ___SAFE__OP */((((~(0x11FE8BE9L ^ (((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*341*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*342*//* ___SAFE__OP */((0x51C8L || (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*343*//* ___SAFE__OP */((((g_4[3] || (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*344*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*345*//* ___SAFE__OP */((g_4[3] && (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*346*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*347*//* ___SAFE__OP */(((p_87 != p_87) , (g_131 = l_129[0][2][0])), ((((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*348*//* ___SAFE__OP */((0UL | 0xB25B5FE4L), 0x49914032C2DE0B6ALL)) || 0xACL) , p_86) < l_129[0][2][0]))) | g_10), p_86))), p_86)), l_129[0][2][0]))) , &p_88) == &g_50), 29))), 65535UL)))) < 0x996C8B9E1FA26B9DLL) && 0x02L))) <= 0xEC0817FF2A7570BALL) & l_129[6][1][2]), 7))) , p_85)) >= g_50)))), l_129[9][2][0])), 0x83L)), 0UL)), 0x5444L)), g_100));
    return g_136;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_137[i], "g_137[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_179[i], "g_179[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_195, "g_195", print_hash_value);
    transparent_crc(g_235, "g_235", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_262[i], "g_262[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_283, "g_283", print_hash_value);
    transparent_crc(g_381, "g_381", print_hash_value);
    transparent_crc(g_408, "g_408", print_hash_value);
    transparent_crc(g_518, "g_518", print_hash_value);
    transparent_crc(g_598, "g_598", print_hash_value);
    transparent_crc(g_624, "g_624", print_hash_value);
    transparent_crc(g_767, "g_767", print_hash_value);
    transparent_crc(g_897, "g_897", print_hash_value);
    transparent_crc(g_1164, "g_1164", print_hash_value);
    transparent_crc(g_1236, "g_1236", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1260[i], "g_1260[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1398, "g_1398", print_hash_value);
    transparent_crc(g_1420, "g_1420", print_hash_value);
    transparent_crc(g_1517, "g_1517", print_hash_value);
    transparent_crc(g_1527, "g_1527", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1603[i], "g_1603[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1659, "g_1659", print_hash_value);
    transparent_crc(g_1774, "g_1774", print_hash_value);
    transparent_crc(g_1811, "g_1811", print_hash_value);
    transparent_crc(g_1892, "g_1892", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 505
XXX total union variables: 24

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 42
breakdown:
   indirect level: 0, occurrence: 24
   indirect level: 1, occurrence: 14
   indirect level: 2, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 30
XXX times a bitfields struct on LHS: 2
XXX times a bitfields struct on RHS: 54
XXX times a single bitfield on LHS: 2
XXX times a single bitfield on RHS: 0

XXX max expression depth: 52
breakdown:
   depth: 1, occurrence: 279
   depth: 2, occurrence: 70
   depth: 3, occurrence: 4
   depth: 4, occurrence: 6
   depth: 5, occurrence: 3
   depth: 7, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 2
   depth: 14, occurrence: 1
   depth: 15, occurrence: 4
   depth: 16, occurrence: 3
   depth: 17, occurrence: 3
   depth: 18, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 4
   depth: 22, occurrence: 5
   depth: 24, occurrence: 3
   depth: 25, occurrence: 4
   depth: 27, occurrence: 3
   depth: 28, occurrence: 1
   depth: 29, occurrence: 2
   depth: 30, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 4
   depth: 36, occurrence: 1
   depth: 37, occurrence: 2
   depth: 38, occurrence: 1
   depth: 45, occurrence: 1
   depth: 52, occurrence: 1

XXX total number of pointers: 501

XXX times a variable address is taken: 1121
XXX times a pointer is dereferenced on RHS: 267
breakdown:
   depth: 1, occurrence: 246
   depth: 2, occurrence: 16
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 236
breakdown:
   depth: 1, occurrence: 220
   depth: 2, occurrence: 16
XXX times a pointer is compared with null: 42
XXX times a pointer is compared with address of another variable: 9
XXX times a pointer is compared with another pointer: 16
XXX times a pointer is qualified to be dereferenced: 8042

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1362
   level: 2, occurrence: 227
   level: 3, occurrence: 57
   level: 4, occurrence: 17
   level: 5, occurrence: 10
XXX number of pointers point to pointers: 189
XXX number of pointers point to scalars: 294
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 35.3
XXX average alias set size: 1.44

XXX times a non-volatile is read: 1369
XXX times a non-volatile is write: 702
XXX times a volatile is read: 87
XXX    times read thru a pointer: 27
XXX times a volatile is write: 24
XXX    times written thru a pointer: 4
XXX times a volatile is available for access: 1.91e+03
XXX percentage of non-volatile access: 94.9

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 272
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 36
   depth: 2, occurrence: 44
   depth: 3, occurrence: 52
   depth: 4, occurrence: 46
   depth: 5, occurrence: 64

XXX percentage a fresh-made variable is used: 15.8
XXX percentage an existing variable is used: 84.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

