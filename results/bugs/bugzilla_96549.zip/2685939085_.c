#include <stdio.h>
long c = -1L;
long b = 0L;
int main(void) {
  if (3L > (short) ((c ^= (b = 1L)) * 3L))
    printf("hello ");
  printf("world!\n");
  return 0;
}
