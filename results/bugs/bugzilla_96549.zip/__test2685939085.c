/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: d619b03
 * Options:   --seed 2685939085 --bitfields --packed-struct
 * Seed:      2685939085
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[4][4][10] = {{{0xEF7D2668L,(-1L),1L,0xE77DD688L,(-1L),0x589FE57FL,0x6E6C8CACL,(-1L),(-6L),0xC43CC9F1L},{0xEF7D2668L,(-1L),0x16B471DFL,0xECB302AFL,(-1L),0x790E8648L,0xC43CC9F1L,0x4C90D297L,(-9L),0x9CF30836L},{0x790E8648L,0xC43CC9F1L,0x4C90D297L,(-9L),0x9CF30836L,(-1L),0x35B263D1L,0xB13ECA4FL,0L,1L},{0x123D4A1CL,0x0E164CAFL,0xE5878ED7L,0xF3E76E5BL,0x8EF6B8F3L,3L,1L,0x038E85A7L,0x16B471DFL,(-1L)}},{{0xCC9CA319L,(-1L),(-1L),3L,0x83D1F0DFL,0x04157736L,0xECB302AFL,0xCC9CA319L,0x589FE57FL,0xCC9CA319L},{(-4L),(-3L),(-6L),7L,(-6L),(-3L),(-4L),0x9CF30836L,0x35B263D1L,0x80031AA0L},{0L,(-6L),0x589FE57FL,0L,(-1L),0xFDA0E60FL,0xA61EEFB6L,0xECB302AFL,3L,0x9CF30836L},{1L,(-6L),5L,(-6L),0x790E8648L,(-9L),(-4L),0x80031AA0L,(-3L),0xB4956E74L}},{{0x04157736L,(-3L),0xF3E76E5BL,(-1L),(-1L),0xB13ECA4FL,0xECB302AFL,4L,0xE5878ED7L,0x4F4E7975L},{0x83D1F0DFL,0L,1L,0x80031AA0L,0x9CF30836L,(-1L),5L,0L,0x16B471DFL,0xE77DD688L},{0x4F4E7975L,0x9CF30836L,0xB13ECA4FL,0x3CA4D9A5L,1L,0x589FE57FL,(-9L),1L,0L,0L},{3L,(-1L),0L,0xEF7D2668L,0xEF7D2668L,0L,(-1L),3L,0L,4L}},{{1L,(-6L),0xE77DD688L,0x4C90D297L,0x35B263D1L,0xECB302AFL,0x3CA4D9A5L,(-1L),9L,0xEF7D2668L},{0x63588C55L,0xE5878ED7L,0xE77DD688L,0x35B263D1L,(-9L),(-1L),(-1L),3L,1L,(-1L)},{0x83A7EF23L,0xA61EEFB6L,0L,4L,5L,0x0E164CAFL,0xC43CC9F1L,1L,7L,0x04157736L},{0xC39C9D94L,(-9L),0xB13ECA4FL,0x04157736L,(-1L),7L,0xEF7D2668L,0L,0x9CF30836L,0xFDA0E60FL}}};
static volatile int32_t * const  volatile g_3 = (void*)0;/* VOLATILE GLOBAL g_3 */
static volatile int64_t g_4 = 0x451DBA1DD79339B8LL;/* VOLATILE GLOBAL g_4 */
static int32_t g_17 = 0x4AEC7014L;
static int32_t g_21[10] = {0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL,0xBC97DE2EL};
static uint8_t g_69[2][9] = {{0x83L,0x83L,0x83L,0x83L,0x83L,0x83L,0x83L,0x83L,0x83L},{8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL}};
static uint8_t g_76[9][3][6] = {{{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,1UL,1UL,0x7EL,1UL,1UL}},{{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,1UL,1UL,0x7EL,1UL,1UL}},{{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,1UL,1UL,0x7EL,1UL,1UL},{0x7EL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}},{{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL},{1UL,0xEEL,0xEEL,1UL,0xEEL,0xEEL}}};
static int8_t g_82[4] = {0xD5L,0xD5L,0xD5L,0xD5L};
static int32_t g_91[2] = {0L,0L};
static int32_t *g_90[10] = {&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1],&g_91[1]};
static int32_t g_92 = 0x4979765BL;
static int32_t g_100[1] = {(-1L)};
static uint64_t g_113 = 3UL;
static int64_t g_148 = 0L;
static uint32_t g_151 = 0x68AEAC46L;
static uint32_t g_211[6][9] = {{0UL,0xD95422EFL,9UL,0xD95422EFL,0UL,1UL,0UL,0xD95422EFL,9UL},{0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L},{0UL,0xD95422EFL,9UL,0xD95422EFL,0UL,1UL,0UL,0xD95422EFL,9UL},{0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L},{0UL,0xD95422EFL,9UL,0xD95422EFL,0UL,1UL,0UL,0xD95422EFL,9UL},{0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L,0xC6C6E832L,0xC6C6E832L,0xF922F530L}};
static const uint32_t g_213 = 0xE63C6DC1L;
static uint32_t g_225 = 0xDE736438L;
static int16_t g_279 = (-1L);
static uint16_t g_281 = 0x5FBCL;
static int32_t ** volatile g_292[8] = {&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2]};
static int32_t ** volatile *g_291 = &g_292[0];
static volatile int8_t g_295[10] = {0xA8L,0x03L,0xA8L,0xA8L,0x03L,0xA8L,0xA8L,0x03L,0xA8L,0xA8L};
static volatile int8_t *g_294 = &g_295[3];
static volatile int8_t **g_293[3] = {&g_294,&g_294,&g_294};
static uint8_t g_372[2][5] = {{0xC6L,0xC6L,0UL,0xC6L,0xC6L},{0xE0L,0xC6L,0xE0L,0xE0L,0xC6L}};
static int16_t g_375 = 0xF4B6L;
static int32_t g_405 = 0x392EB8E7L;
static int32_t *g_424 = &g_100[0];
static const int32_t *g_497 = &g_100[0];
static const uint16_t *g_514 = (void*)0;
static uint32_t g_521 = 1UL;
static volatile int16_t g_538 = 0x9B05L;/* VOLATILE GLOBAL g_538 */
static volatile int32_t *g_542 = &g_2[3][2][5];
static volatile int32_t **g_541 = &g_542;
static int64_t *g_615 = &g_148;
static int64_t **g_614 = &g_615;
static int64_t ***g_613 = &g_614;
static uint8_t g_681 = 0xEFL;
static int8_t **g_709 = (void*)0;
static int8_t ***g_708 = &g_709;
static int64_t g_734[3][6][5] = {{{0xE54F1593C817D2B6LL,0L,6L,0x84CA640034EFB0D6LL,0L},{0xD39C4AEFF8043815LL,0L,0x84CA640034EFB0D6LL,(-5L),0x84CA640034EFB0D6LL},{0x84CA640034EFB0D6LL,0x84CA640034EFB0D6LL,(-8L),6L,0xA12508C236650BF5LL},{0x84CA640034EFB0D6LL,4L,0xA12508C236650BF5LL,4L,1L},{0xD39C4AEFF8043815LL,0x1B46C63147EDC9F1LL,0L,0x9C2D0CB8DB6711C1LL,0xA09E37570A2DD9A0LL},{0xE54F1593C817D2B6LL,4L,4L,0xE54F1593C817D2B6LL,9L}},{{0L,0x84CA640034EFB0D6LL,4L,0xA12508C236650BF5LL,4L},{0xA12508C236650BF5LL,0L,0L,0xD39C4AEFF8043815LL,4L},{0x1B46C63147EDC9F1LL,0L,0xA12508C236650BF5LL,0xA12508C236650BF5LL,0L},{1L,(-5L),(-8L),0xE54F1593C817D2B6LL,0L},{0L,0xA09E37570A2DD9A0LL,0x84CA640034EFB0D6LL,0x9C2D0CB8DB6711C1LL,4L},{(-5L),0x9C2D0CB8DB6711C1LL,6L,4L,4L}},{{0L,(-8L),0L,6L,9L},{1L,(-8L),0xD39C4AEFF8043815LL,(-5L),0xA09E37570A2DD9A0LL},{0x1B46C63147EDC9F1LL,0x9C2D0CB8DB6711C1LL,4L,0x84CA640034EFB0D6LL,1L},{0xA12508C236650BF5LL,0xA09E37570A2DD9A0LL,0xD39C4AEFF8043815LL,0xA09E37570A2DD9A0LL,0xA12508C236650BF5LL},{0L,(-5L),0L,0xA09E37570A2DD9A0LL,0x84CA640034EFB0D6LL},{0xE54F1593C817D2B6LL,0L,6L,0x84CA640034EFB0D6LL,0L}}};
static volatile int32_t g_769[2][10] = {{0x015B8711L,0x6239D471L,3L,0x015B8711L,0x6886D8EEL,0x6886D8EEL,0x015B8711L,3L,0x6239D471L,0x015B8711L},{3L,(-3L),0x6239D471L,0x6886D8EEL,(-3L),0x6886D8EEL,0x6239D471L,(-3L),3L,3L}};
static volatile int32_t *g_768 = &g_769[0][5];
static int16_t g_771 = 0L;
static int8_t g_788[9][6] = {{0xB2L,(-1L),(-1L),0xB2L,0x4AL,0xB2L},{0xB2L,0x4AL,0xB2L,(-1L),(-1L),0xB2L},{0x21L,0x21L,(-1L),5L,(-1L),0x21L},{(-1L),0x4AL,5L,5L,0x4AL,(-1L)},{0x21L,(-1L),5L,(-1L),0x21L,0x21L},{0xB2L,(-1L),(-1L),0xB2L,0x4AL,0xB2L},{0xB2L,0x4AL,0xB2L,(-1L),(-1L),0xB2L},{0x21L,0x21L,(-1L),5L,(-1L),0x21L},{(-1L),0x4AL,5L,5L,0x4AL,(-1L)}};
static int32_t g_791 = 0x5369B690L;
static uint32_t *g_937 = &g_521;
static int8_t g_941 = 0xCCL;
static volatile uint32_t g_943[2][2] = {{0xE6F8510EL,0xE6F8510EL},{0xE6F8510EL,0xE6F8510EL}};
static int64_t g_988 = 0xE79E4398D6B5C614LL;
static uint32_t g_1005 = 0x346F0D7DL;
static int16_t g_1007 = (-10L);
static volatile int8_t ** volatile **g_1013 = (void*)0;
static volatile int8_t ** volatile ** volatile * volatile g_1012 = &g_1013;/* VOLATILE GLOBAL g_1012 */
static int32_t *g_1066 = &g_405;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_9(int32_t * p_10, int64_t  p_11, int32_t * p_12, int32_t * p_13);
static int32_t * func_14(int32_t * p_15);
static const int8_t  func_36(int32_t * p_37, int32_t * p_38, int32_t * p_39, int32_t  p_40);
static uint16_t  func_45(int32_t * p_46, uint32_t  p_47);
static int32_t * func_49(int32_t  p_50);
static int32_t  func_51(int32_t  p_52, uint8_t  p_53, uint16_t  p_54, int32_t * p_55);
static uint8_t  func_60(int32_t * p_61, uint32_t  p_62, int8_t  p_63);
static int32_t * func_64(uint8_t  p_65, const uint8_t  p_66, int32_t * p_67);
static int32_t * func_70(uint8_t  p_71, int32_t  p_72, uint8_t * p_73);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_17 g_213 g_424 g_76 g_148 g_211 g_21 g_372 g_405 g_151 g_91 g_281 g_225 g_375 g_521 g_279 g_291 g_292 g_100 g_541 g_294 g_295 g_69 g_708 g_613 g_614 g_615 g_734 g_497 g_768 g_771 g_82 g_791 g_788 g_542 g_681 g_92 g_769 g_709 g_113 g_941 g_943 g_937 g_1005 g_1007 g_1012 g_988
 * writes: g_4 g_17 g_82 g_100 g_113 g_497 g_514 g_148 g_76 g_21 g_521 g_279 g_90 g_151 g_708 g_225 g_734 g_771 g_375 g_372 g_788 g_681 g_92 g_211 g_769 g_791 g_281 g_937 g_941 g_614 g_1066
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5[9];
    int32_t *l_20[10] = {&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4],&g_21[4]};
    uint16_t * const l_850[9][10] = {{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,(void*)0,(void*)0,&g_281},{&g_281,&g_281,(void*)0,(void*)0,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,(void*)0,(void*)0,&g_281},{&g_281,&g_281,(void*)0,(void*)0,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281}};
    int64_t ****l_853[4][7];
    int32_t l_898[3];
    int64_t l_970[5][9][3] = {{{0xEA60B8E78F8AEC27LL,1L,0L},{(-1L),(-1L),0x20E017A3931FCBB8LL},{1L,0xEA60B8E78F8AEC27LL,3L},{0x11922EF58A7F8F89LL,(-1L),0x11922EF58A7F8F89LL},{3L,1L,(-2L)},{(-1L),0x11922EF58A7F8F89LL,0x11922EF58A7F8F89LL},{(-2L),3L,3L},{4L,(-1L),0x20E017A3931FCBB8LL},{(-2L),(-2L),0L}},{{(-1L),4L,0L},{3L,(-2L),3L},{0x11922EF58A7F8F89LL,(-1L),(-1L)},{1L,3L,3L},{(-1L),0x11922EF58A7F8F89LL,0L},{0xEA60B8E78F8AEC27LL,1L,0L},{(-1L),(-1L),0x20E017A3931FCBB8LL},{1L,0xEA60B8E78F8AEC27LL,3L},{0x11922EF58A7F8F89LL,(-1L),0x11922EF58A7F8F89LL}},{{3L,1L,(-2L)},{(-1L),0x11922EF58A7F8F89LL,0x11922EF58A7F8F89LL},{(-2L),3L,3L},{4L,(-1L),0x20E017A3931FCBB8LL},{(-2L),(-2L),0L},{(-1L),4L,0L},{3L,(-2L),3L},{0x11922EF58A7F8F89LL,(-1L),(-1L)},{1L,3L,3L}},{{(-1L),0x11922EF58A7F8F89LL,0L},{0xEA60B8E78F8AEC27LL,1L,0L},{(-1L),(-1L),(-1L)},{3L,3L,0L},{4L,0x2E13DF0B5B9B4DADLL,4L},{0xEA60B8E78F8AEC27LL,3L,(-5L)},{0x11922EF58A7F8F89LL,4L,4L},{(-5L),0xEA60B8E78F8AEC27LL,0L},{0L,0x11922EF58A7F8F89LL,(-1L)}},{{(-5L),(-5L),(-2L)},{0x11922EF58A7F8F89LL,0L,0x20E017A3931FCBB8LL},{0xEA60B8E78F8AEC27LL,(-5L),0xEA60B8E78F8AEC27LL},{4L,0x11922EF58A7F8F89LL,0x2E13DF0B5B9B4DADLL},{3L,0xEA60B8E78F8AEC27LL,0xEA60B8E78F8AEC27LL},{0x2E13DF0B5B9B4DADLL,4L,0x20E017A3931FCBB8LL},{3L,3L,(-2L)},{0x2E13DF0B5B9B4DADLL,0x2E13DF0B5B9B4DADLL,(-1L)},{3L,3L,0L}}};
    int32_t l_983 = 1L;
    int8_t ****l_1004 = (void*)0;
    const int16_t l_1014 = 3L;
    uint32_t l_1052[8][1][5] = {{{4294967295UL,4294967293UL,1UL,0xAB954E04L,4294967288UL}},{{4294967290UL,1UL,1UL,1UL,1UL}},{{4294967295UL,4294967293UL,1UL,0xAB954E04L,4294967288UL}},{{4294967290UL,1UL,1UL,1UL,1UL}},{{4294967295UL,4294967293UL,1UL,0xAB954E04L,4294967288UL}},{{4294967290UL,1UL,1UL,1UL,1UL}},{{4294967295UL,4294967293UL,1UL,0xAB954E04L,4294967288UL}},{{4294967290UL,1UL,1UL,1UL,1UL}}};
    int32_t l_1053 = 0x840365D2L;
    uint64_t l_1083 = 0xA39678E64B3E1171LL;
    uint32_t l_1084 = 0UL;
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_5[i] = (-4L);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
            l_853[i][j] = &g_613;
    }
    for (i = 0; i < 3; i++)
        l_898[i] = 0xD43C28EBL;
    g_4 = g_2[3][2][5];
    if (g_4)
    { /* block id: 2 */
        uint64_t l_8 = 0x0B56BF5EE879096ALL;
        int32_t *l_16 = &g_17;
        int16_t *l_770 = &g_771;
        const int32_t l_772 = 1L;
        int8_t l_789 = 0L;
        int32_t *l_804 = (void*)0;
        int32_t **l_803 = &l_804;
        int32_t l_809 = 0x0EB561FDL;
        int8_t l_810 = (-1L);
        int32_t l_812 = 0x0C4E1C50L;
        uint32_t l_836 = 4294967291UL;
        uint64_t l_860 = 8UL;
        int32_t *l_927 = (void*)0;
        int16_t l_963 = 0xF0D6L;
        int32_t l_967 = 0x58077DE4L;
        int32_t l_969 = 0x6362BBE2L;
        int32_t l_975 = 0x421113EEL;
        int32_t l_978[2];
        int32_t l_984 = 0x1198CC7CL;
        int8_t ****l_1001 = &g_708;
        uint8_t l_1021 = 2UL;
        int32_t **l_1028 = (void*)0;
        int32_t ***l_1027[3];
        int16_t *l_1077[5] = {&g_1007,&g_1007,&g_1007,&g_1007,&g_1007};
        int16_t **l_1078 = &l_1077[1];
        int16_t **l_1079 = &l_770;
        uint64_t *l_1082 = &l_860;
        int16_t l_1085 = (-10L);
        int i;
        for (i = 0; i < 2; i++)
            l_978[i] = 0x360F8306L;
        for (i = 0; i < 3; i++)
            l_1027[i] = &l_1028;
        if ((l_5[5] , (((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*0*//* ___SAFE__OP */(((((((*l_770) |= ((l_8 ^= 0x25996FD0L) , (((func_9(func_14(l_16), g_4, l_16, l_20[0]) >= g_372[0][4]) , (void*)0) == g_768))) > g_405) || 0xD9L) & 0xE4L) ^ l_772), 0xC328B50FL)) , 0x1110DA39L) | 0L)))
        { /* block id: 362 */
            int8_t l_775 = 8L;
            uint8_t *l_783 = &g_372[0][2];
            int32_t **l_784 = (void*)0;
            int32_t ***l_785 = (void*)0;
            int32_t ***l_786 = &l_784;
            int8_t *l_787[5][5] = {{&g_788[4][4],&l_775,&g_788[7][5],&g_788[7][5],&l_775},{&g_788[4][4],&l_775,&g_788[7][5],&g_788[7][5],&l_775},{&g_788[4][4],&l_775,&g_788[7][5],&g_788[7][5],&l_775},{&g_788[4][4],&l_775,&g_788[7][5],&g_788[7][5],&l_775},{&g_788[4][4],&l_775,&g_788[7][5],&g_788[7][5],&l_775}};
            uint64_t *l_790 = &g_113;
            int32_t l_811 = (-10L);
            uint16_t l_813 = 0x7AD5L;
            uint32_t l_835 = 6UL;
            int16_t l_838 = 9L;
            int32_t l_839[9][5] = {{0x120CD20CL,0x75D9B696L,(-1L),5L,1L},{0L,0xCCD747A4L,0x260BE2BEL,0x260BE2BEL,0xCCD747A4L},{0x120CD20CL,0x75D9B696L,(-1L),5L,1L},{0L,0xCCD747A4L,0x260BE2BEL,0x260BE2BEL,0xCCD747A4L},{0x120CD20CL,0x75D9B696L,(-1L),5L,1L},{0L,0xCCD747A4L,0x260BE2BEL,0x260BE2BEL,0xCCD747A4L},{0x120CD20CL,0x75D9B696L,(-1L),5L,1L},{0L,0xCCD747A4L,0x260BE2BEL,0x260BE2BEL,0xCCD747A4L},{0x120CD20CL,0x75D9B696L,(-1L),5L,1L}};
            int64_t ***l_881 = &g_614;
            int i, j;
            if (((g_82[1] < ((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*1*//* ___SAFE__OP */(l_775, 15)) , ((((*l_790) = (((((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*2*//* ___SAFE__OP */((g_375 = l_775), (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*3*//* ___SAFE__OP */((*l_16), ((**g_614) ^= ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*4*//* ___SAFE__OP */(0xE00EA982B0608B22LL, g_372[1][4])) , (!(((*l_783) = l_775) && (g_788[1][4] = ((((*l_786) = l_784) != (*g_291)) && g_100[0])))))))))) != 0UL) , 4294967286UL) , l_789) ^ 0x2CD8L)) == g_82[2]) , g_734[1][5][4]))) <= g_791))
            { /* block id: 369 */
                int32_t l_808 = (-5L);
                (*l_16) = ((g_82[1] &= (((((*g_615) | (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*5*//* ___SAFE__OP */((((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*6*//* ___SAFE__OP */((+(g_372[1][4] >= g_148)), (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*7*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*8*//* ___SAFE__OP */(((***g_613) , (((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*9*//* ___SAFE__OP */((((((void*)0 == l_803) >= g_279) == (2UL & ((((+((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*10*//* ___SAFE__OP */(g_91[1], l_808)) != (*g_294))) <= 0UL) || g_21[5]) & 1L))) & g_100[0]), 0x8443B260L)) | g_279) & l_808)), 20)), 0xE23795F4277CE03CLL)))) , (*g_615)) == l_808), (**g_614)))) ^ g_788[5][1]) ^ 0L) < (*l_16))) < g_405);
            }
            else
            { /* block id: 372 */
                return (**g_541);
            }
            ++l_813;
            for (g_681 = 0; (g_681 != 1); g_681++)
            { /* block id: 378 */
                const int16_t l_837 = (-6L);
                int8_t **l_855 = &l_787[3][2];
                int32_t l_856 = (-3L);
                for (g_92 = 0; (g_92 <= 3); g_92 += 1)
                { /* block id: 381 */
                    const uint16_t l_823 = 1UL;
                    int64_t * const l_840[4] = {&g_148,&g_148,&g_148,&g_148};
                    int32_t l_872[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_872[i] = 0L;
                    if ((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*11*//* ___SAFE__OP */(0x1E0AB1A7530A5FC8LL, (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*12*//* ___SAFE__OP */((~l_823), ((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*13*//* ___SAFE__OP */(((*l_16) & (((*g_614) != (((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*14*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*15*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*16*//* ___SAFE__OP */(((*g_497) , ((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*17*//* ___SAFE__OP */((!(((0x20L | g_82[1]) , ((((l_835 > 65527UL) == (*g_424)) | g_69[0][4]) && l_836)) & l_837)), (*l_16))) >= (*g_424))), l_823)), 9L)) & l_838), l_839[0][1])) , 0xB60FA524L) , l_840[0])) ^ l_837)), (*l_16))) <= l_837))))))
                    { /* block id: 382 */
                        uint16_t *l_852[2];
                        uint16_t **l_851 = &l_852[1];
                        int32_t l_854 = 1L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_852[i] = &l_813;
                        l_856 = ((((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*18*//* ___SAFE__OP */(((l_837 ^ ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*19*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*20*//* ___SAFE__OP */(((l_837 <= g_769[0][6]) | ((safe_unary_minus_func_int64_t_s/* ___REMOVE_SAFE__OP *//*21*//* ___SAFE__OP */((((l_850[5][2] != ((*l_851) = l_770)) == ((void*)0 != l_853[1][0])) ^ l_854))) == (***g_613))), 13)), 0xB1933743EE76585ELL)) && 4L)) & g_148), 1L)) & l_854) , (*g_708)) == l_855);
                    }
                    else
                    { /* block id: 385 */
                        uint32_t *l_871 = &l_836;
                        uint32_t *l_892[7][4][2] = {{{&l_836,&l_836},{&l_836,&l_836},{&g_211[5][7],&l_836},{&l_836,&l_836}},{{&l_836,&g_211[2][3]},{&l_836,(void*)0},{&l_835,&g_225},{&l_836,&l_835}},{{&g_211[2][3],(void*)0},{&g_211[2][3],&l_835},{&l_836,&g_225},{&l_835,(void*)0}},{{&l_836,&g_211[2][3]},{&g_211[2][3],(void*)0},{(void*)0,&g_211[5][7]},{&l_836,&g_211[5][7]}},{{(void*)0,(void*)0},{&g_211[2][3],&g_225},{&g_211[2][3],&l_836},{&l_836,&g_521}},{{&g_211[5][7],&l_836},{(void*)0,&l_835},{(void*)0,&l_836},{&g_211[5][7],&g_521}},{{&l_836,&l_836},{&g_211[2][3],&g_225},{&g_211[2][3],(void*)0},{(void*)0,&g_211[5][7]}}};
                        int32_t l_893 = 0x6A439D30L;
                        int i, j, k;
                        l_872[0] ^= (((*g_424) , (!(safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*22*//* ___SAFE__OP */((((**l_855) |= (l_860 | ((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*23*//* ___SAFE__OP */((((g_734[1][4][4] <= (&g_281 != (void*)0)) <= (safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*24*//* ___SAFE__OP */(((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*25*//* ___SAFE__OP */(((*l_790) = (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*26*//* ___SAFE__OP */(((void*)0 == &g_211[2][3]), (&g_211[2][3] == (l_871 = (void*)0))))), g_2[3][2][5])) <= 7UL), g_91[0]))) ^ (*l_16)), 1L)) ^ l_823))) && l_823), (*l_16))))) , l_856);
                        (*g_768) = (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*27*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*28*//* ___SAFE__OP */(((*l_770) ^= (((l_872[0] , (safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*29*//* ___SAFE__OP */(4294967295UL, ((*g_424) = (safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*30*//* ___SAFE__OP */((((((void*)0 != l_881) , ((*l_16) >= (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*31*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*32*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*33*//* ___SAFE__OP */(((*g_615) = 0x8AFAC0C11730DF7BLL), 0L)) , ((safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*34*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*35*//* ___SAFE__OP */(((-5L) != ((g_211[2][3]--) , (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*36*//* ___SAFE__OP */(l_893, 0x925041B3C70DD7BBLL)))), l_856)), l_893)) , l_823)), g_151)) , l_893), 31)))) && (-6L)) != l_893), l_893)))))) != 1UL) & 0x94L)), 65532UL)), g_4));
                        if ((*g_497))
                            break;
                    }
                    return (**g_541);
                }
                for (g_148 = 0; (g_148 <= 7); g_148 += 1)
                { /* block id: 401 */
                    return (*g_542);
                }
                l_898[0] = (*l_16);
            }
        }
        else
        { /* block id: 406 */
            int64_t l_899 = 4L;
            int32_t l_900 = 0xC08A76A3L;
            int8_t l_924 = (-2L);
            l_900 ^= (l_899 = ((*g_424) ^= (*l_16)));
            for (g_375 = 0; (g_375 == (-6)); g_375 = safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*37*//* ___SAFE__OP */(g_375, 7))
            { /* block id: 412 */
                int8_t *l_921 = &g_82[1];
                const int32_t l_922 = 0L;
                int32_t l_923[6][1][3] = {{{0xCB13C9E3L,0x1C6DAB85L,0xCB13C9E3L}},{{0xCB13C9E3L,0x605E05F4L,0x1C6DAB85L}},{{0x605E05F4L,0xCB13C9E3L,0xCB13C9E3L}},{{0x1C6DAB85L,0xCB13C9E3L,0x665EAAA5L}},{{0xFA04855AL,0x605E05F4L,0x2E142F56L}},{{0x1C6DAB85L,0x1C6DAB85L,0x2E142F56L}}};
                int i, j, k;
                (*g_768) = (((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*38*//* ___SAFE__OP */((***g_613), (-8L))) < ((safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*39*//* ___SAFE__OP */((!(((l_923[4][0][2] = ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*40*//* ___SAFE__OP */((g_771 | ((~(*l_16)) || 0UL)), g_148)) , ((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*41*//* ___SAFE__OP */(((*l_921) = (0xED18C384D236094FLL <= (safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*42*//* ___SAFE__OP */((*g_294), (((safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*43*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*44*//* ___SAFE__OP */(((250UL < (-8L)) && g_788[5][0]), 9)), (*g_615))) == (*l_16)) || 0xC86AL))))), l_922)) && l_900))) , (*g_708)) == &l_921)), 5)) , l_924)) >= l_900);
            }
            (*g_424) = (&g_708 != &g_708);
            (*l_16) = ((*g_424) = l_899);
        }
        for (l_8 = 28; (l_8 < 44); l_8++)
        { /* block id: 423 */
            (**g_291) = l_927;
        }
        for (g_791 = 2; (g_791 >= 0); g_791 -= 1)
        { /* block id: 428 */
            const uint32_t *l_936 = &g_211[2][3];
            int32_t l_942 = (-2L);
            int8_t l_958 = 0xEAL;
            int32_t l_961 = 0L;
            int32_t l_972 = 0xB9F0FF4DL;
            int32_t l_974 = 0xEB26F3BCL;
            int32_t l_976[7];
            int64_t **l_1051 = &g_615;
            int i;
            for (i = 0; i < 7; i++)
                l_976[i] = 8L;
            if ((*l_16))
                break;
            for (g_113 = 0; (g_113 <= 5); g_113 += 1)
            { /* block id: 432 */
                uint32_t *l_935 = &g_211[2][3];
                uint32_t **l_934 = &l_935;
                uint64_t *l_940 = (void*)0;
                uint32_t l_950 = 6UL;
                int32_t l_957 = 1L;
                int32_t l_965 = 0x3D0EE696L;
                int32_t l_968 = 0L;
                int32_t l_973 = 0xA7BB0108L;
                int32_t l_977 = 0xB439595BL;
                int32_t l_981 = 0x183B23FAL;
                int32_t l_986[2][7][1] = {{{0xAFAB1B58L},{0xAFAB1B58L},{0xCE22189EL},{0xAFAB1B58L},{0xAFAB1B58L},{0xCE22189EL},{0xAFAB1B58L}},{{0xAFAB1B58L},{0xCE22189EL},{0xAFAB1B58L},{0xAFAB1B58L},{0xCE22189EL},{0xAFAB1B58L},{0xAFAB1B58L}}};
                int32_t **l_993 = &l_804;
                int16_t l_1006 = (-9L);
                int8_t l_1008 = 0x54L;
                int8_t l_1015 = 0xB6L;
                int i, j, k;
                (*g_424) |= (((g_281++) | g_211[g_113][g_791]) != (((**g_614) >= (safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*45*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*46*//* ___SAFE__OP */((((*l_934) = &l_836) == l_936), ((((*l_770) |= (-1L)) ^ 0xBFECL) != (((g_225 &= (((((g_937 = &g_521) == &g_211[2][3]) & (((((*l_16) = (safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*47*//* ___SAFE__OP */((g_941 ^= g_91[1]), g_211[g_113][g_791]))) && l_942) , g_943[1][0]) , g_213)) | g_151) ^ l_942)) == 0x2898C017L) < 2UL)))), 4))) | g_82[1]));
                if ((*g_768))
                { /* block id: 441 */
                    int32_t l_951 = 0x2D9D14A5L;
                    uint8_t l_952[10] = {0xCEL,1UL,0xCEL,0xCEL,1UL,0xCEL,0xCEL,1UL,0xCEL,0xCEL};
                    int8_t *l_955 = &g_82[1];
                    int16_t l_956 = (-1L);
                    int32_t l_959 = (-1L);
                    int32_t l_960 = (-1L);
                    int32_t l_962 = 1L;
                    int64_t l_964 = (-7L);
                    int32_t l_966 = 0xF64DA314L;
                    int32_t l_971 = 0x149B6FBAL;
                    int32_t l_979 = (-4L);
                    int32_t l_980 = 0x6276EF02L;
                    int32_t l_982 = (-1L);
                    int32_t l_985 = 0x3FE5D168L;
                    int32_t l_987[6];
                    uint32_t l_989 = 0xCFBD25E1L;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_987[i] = 7L;
                    l_951 &= ((((g_100[0] & ((g_211[g_113][g_791] ^ (l_942 , ((*l_935) = g_211[g_113][(g_113 + 3)]))) | ((safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*48*//* ___SAFE__OP */(0x3AFE366C727DA4ACLL, ((***g_613) = (-7L)))) || (((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*49*//* ___SAFE__OP */((((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*50*//* ___SAFE__OP */(g_148, g_943[1][0])) | ((&g_614 == (void*)0) , g_211[g_113][g_791])) , g_148), (-9L))) & l_950) , g_943[0][0])))) >= (*l_16)) > l_942) & (*g_424));
                    if (l_952[0])
                        break;
                    l_957 ^= ((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*51*//* ___SAFE__OP */(((*l_955) = (&g_542 != (void*)0)), ((g_211[g_113][(g_113 + 3)] , ((**g_614) = ((&g_613 == (void*)0) ^ (((((((g_788[6][5] > (g_281 = l_951)) > 0xD6C2L) , 1L) && g_769[1][1]) , (-1L)) != 6L) == l_956)))) ^ g_113))) ^ (*l_16));
                    l_989--;
                }
                else
                { /* block id: 451 */
                    int32_t **l_992[10] = {&l_16,&l_16,&l_16,&l_16,&l_16,&l_16,&l_16,&l_16,&l_16,&l_16};
                    int32_t ***l_994 = &l_993;
                    int8_t ****l_1002 = &g_708;
                    int8_t *****l_1003[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1003[i] = &l_1002;
                    l_20[0] = ((**g_291) = (void*)0);
                    (*g_424) = ((&g_542 == ((*l_994) = l_993)) , ((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*52*//* ___SAFE__OP */((*g_294), (4294967295UL || ((((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*53*//* ___SAFE__OP */((l_981 < ((void*)0 != &l_804)), 10)) || (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*54*//* ___SAFE__OP */(((**l_934) |= (l_1001 == (l_1004 = l_1002))), 27))) & (*g_937)) , (-4L))))) , g_1005));
                    (*g_424) |= (((*g_291) == ((((0xDFL != ((0xD2L >= ((g_281 = ((((((l_1006 > g_92) & ((18446744073709551612UL ^ g_213) && g_21[4])) <= (g_211[(g_791 + 2)][g_791] , g_375)) && g_1007) == l_976[6]) > g_372[0][2])) | l_976[1])) >= 0UL)) != g_151) , 0L) , &g_497)) <= (*l_16));
                    if ((*l_16))
                        continue;
                }
                if (((*l_16) >= ((void*)0 != l_936)))
                { /* block id: 462 */
                    uint32_t l_1009 = 0UL;
                    (*g_424) = g_211[g_113][(g_113 + 3)];
                    l_1009++;
                    (*g_768) = (((g_1012 == (l_1009 , &g_1013)) < l_974) | l_1014);
                    return l_1015;
                }
                else
                { /* block id: 467 */
                    uint32_t l_1030 = 1UL;
                    int32_t l_1031 = 0x590EC08EL;
                    int32_t l_1050 = 0x1E786F46L;
                    int32_t l_1067 = 0x363F9C27L;
                    for (l_965 = 9; (l_965 >= 3); l_965 -= 1)
                    { /* block id: 470 */
                        uint8_t *l_1018 = &g_76[6][0][0];
                        int32_t l_1026 = 0L;
                        uint32_t l_1029 = 0xF4F59241L;
                        int8_t *l_1068 = &l_810;
                        l_1031 ^= (l_972 & (8UL ^ ((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*55*//* ___SAFE__OP */(((((*l_1018)++) && ((6UL < l_1021) , (((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*56*//* ___SAFE__OP */(((*g_424) &= 0x4BEB79F5L), (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*57*//* ___SAFE__OP */(l_1026, ((void*)0 != l_1027[2]))))) & (((g_113 > (*l_16)) || 0x2FB395513A39326FLL) > 0x12L)) , l_972))) , l_1029), l_1030)) , g_295[7])));
                        (*l_16) = l_1030;
                        l_1053 = (l_1031 ^ (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*58*//* ___SAFE__OP */(((((((*g_613) = ((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*59*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*60*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*61*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*62*//* ___SAFE__OP */((((*l_934) = func_14(&l_961)) == l_20[8]), (safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*63*//* ___SAFE__OP */((l_974 == (((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*64*//* ___SAFE__OP */(((g_788[4][1] <= (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*65*//* ___SAFE__OP */(1L, (4294967290UL && (((*l_1018) = (safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*66*//* ___SAFE__OP */(l_1029, 0x31E4L))) , l_981))))) != l_986[1][4][0]), 38)) <= l_1050) || 0xC2L)), g_91[1])))), (*g_768))), g_211[2][3])), 15)) , l_1051)) == (void*)0) & g_100[0]) , l_1052[0][0][3]) >= l_976[2]), 23)));
                        (*g_424) = (0L || ((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*67*//* ___SAFE__OP */(((*l_1068) &= (4UL >= (((((+(&l_836 != (void*)0)) || (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*68*//* ___SAFE__OP */((((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*69*//* ___SAFE__OP */((((*l_770) = ((safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*70*//* ___SAFE__OP */(l_961, ((((safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*71*//* ___SAFE__OP */((((~(*g_937)) != (((g_1066 = &g_405) == (*g_541)) , g_295[3])) && g_2[3][2][5]), l_1008)) , (void*)0) != &g_614) != 0x6374015D6E6DB081LL))) && l_981)) > 0x9515L), 8)) | g_113) >= 18446744073709551615UL), l_1067))) < 8UL) , l_1030) ^ 7UL))), g_69[0][0])) & l_1026));
                    }
                    for (g_148 = 0; (g_148 <= 9); g_148 += 1)
                    { /* block id: 486 */
                        (*g_768) = 2L;
                    }
                }
            }
        }
        if ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*72*//* ___SAFE__OP */((((((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*73*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*74*//* ___SAFE__OP */(((((((*g_294) < (((g_771 ^ (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*75*//* ___SAFE__OP */((g_279 |= 0x82FCL), (((((*l_1078) = &l_963) == ((*l_1079) = (void*)0)) , (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*76*//* ___SAFE__OP */(((((*l_1082) ^= g_375) <= (*g_615)) , (((*g_497) && (*g_937)) && 4294967289UL)), g_791))) , 0xCF8FL)))) >= (*g_937)) ^ l_1083)) , g_279) >= (-1L)) < g_82[1]) ^ 0x82L), g_988)) , 18446744073709551615UL), g_788[1][4])) , (*l_16)) , &g_113) == &l_8) , l_1084), (*l_16))))
        { /* block id: 496 */
            int32_t l_1086 = 5L;
            int32_t l_1087 = 1L;
            int32_t l_1088 = 0x27C25169L;
            int64_t l_1089 = 0x3E46414C8080D6EELL;
            int32_t l_1090 = 0xFFDE636DL;
            int32_t l_1091 = 0L;
            uint32_t l_1092 = 18446744073709551610UL;
            --l_1092;
        }
        else
        { /* block id: 498 */
            int64_t l_1095 = 0xDF12D73AA19B56E1LL;
            int32_t l_1096 = 0x75C8BE2BL;
            uint32_t l_1097 = 5UL;
            l_1097++;
        }
    }
    else
    { /* block id: 501 */
        int8_t l_1102[9][9][3] = {{{0x17L,0xB7L,7L},{0xB7L,(-3L),0xBDL},{0xE1L,(-3L),0L},{0L,0xB7L,0x67L},{0xFDL,0xFDL,8L},{0x46L,0L,0x2CL},{0x59L,0xDCL,0xBDL},{0x17L,7L,0xE1L},{0x88L,0x59L,0xBDL}},{{0xFDL,1L,0x2CL},{(-7L),0xB7L,8L},{7L,0xDCL,0x67L},{0x46L,0x09L,0L},{1L,7L,0xBDL},{1L,0x88L,7L},{0x46L,0x59L,0x59L},{7L,(-3L),(-5L)},{(-7L),7L,1L}},{{0xFDL,7L,0x67L},{0x88L,0L,0x2CL},{0x17L,7L,0x59L},{0x59L,7L,0x4FL},{0x46L,(-3L),0x17L},{0xFDL,0x59L,(-5L)},{0L,0x88L,8L},{0xE1L,7L,8L},{0xB7L,0x09L,(-5L)}},{{0x17L,0xDCL,0x17L},{1L,0xB7L,0x4FL},{0x88L,1L,0x59L},{0xE1L,0x59L,0x2CL},{0L,7L,0x67L},{0xE1L,0xDCL,1L},{0x88L,0L,(-5L)},{1L,0xFDL,0x59L},{0x17L,0xB7L,7L}},{{0x17L,0L,0x09L},{0L,0L,0x67L},{0x2CL,0x17L,0xDCL},{0xD4L,0xD4L,0xE1L},{0xBDL,0L,1L},{(-7L),0xC3L,0x09L},{4L,1L,0L},{0x59L,(-7L),0x09L},{0xD4L,0L,1L}},{{(-5L),0x17L,0xE1L},{0xD0L,0xC3L,0xDCL},{0xBDL,0L,0x67L},{0L,0xD0L,0x09L},{0L,0x59L,0xD0L},{0xBDL,(-7L),(-7L)},{0xD0L,0L,1L},{(-5L),1L,0x4FL},{0xD4L,0xD0L,0xDCL}},{{0x59L,0x2CL,1L},{4L,0xD0L,(-7L)},{(-7L),1L,0x49L},{0xBDL,0L,4L},{0xD4L,(-7L),1L},{0x2CL,0x59L,0xE1L},{0L,0xD0L,0xE1L},{0x17L,0L,1L},{4L,0xC3L,4L}},{{0L,0x17L,0x49L},{0x59L,0L,(-7L)},{0L,(-7L),1L},{0L,1L,0xDCL},{0L,0xC3L,0x4FL},{0x59L,0L,1L},{0L,0xD4L,(-7L)},{4L,0x17L,0xD0L},{0x17L,0L,0x09L}},{{0L,0L,0x67L},{0x2CL,0x17L,0xDCL},{0xD4L,0xD4L,0xE1L},{0xBDL,0L,1L},{(-7L),0xC3L,0x09L},{4L,1L,0L},{0x59L,(-7L),0x09L},{0xD4L,0L,1L},{(-5L),0x17L,0xE1L}}};
        int32_t l_1103 = 0x887D9FE4L;
        int32_t l_1104 = 0x34DB572DL;
        uint16_t l_1105 = 1UL;
        int i, j, k;
        (*g_768) = ((*g_424) = (safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*77*//* ___SAFE__OP */((*g_615), l_1102[1][8][0])));
        l_1105--;
    }
    return (**g_541);
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_213 g_424 g_76 g_148 g_211 g_21 g_372 g_405 g_151 g_91 g_281 g_225 g_375 g_521 g_17 g_279 g_291 g_292 g_100 g_541 g_294 g_295 g_69 g_708 g_613 g_614 g_615 g_734 g_497
 * writes: g_82 g_100 g_113 g_497 g_514 g_148 g_76 g_21 g_521 g_279 g_17 g_90 g_151 g_708 g_225 g_734
 */
static int32_t  func_9(int32_t * p_10, int64_t  p_11, int32_t * p_12, int32_t * p_13)
{ /* block id: 7 */
    int32_t *l_48 = (void*)0;
    int16_t *l_516[4] = {&g_375,&g_375,&g_375,&g_375};
    int32_t l_517 = 0x61F2432EL;
    int32_t l_518 = 0xB3ED9705L;
    uint32_t *l_519 = (void*)0;
    uint32_t *l_520 = &g_521;
    int32_t *l_569[6] = {&g_92,&g_92,&g_92,&g_92,&g_92,&g_92};
    int32_t **l_568 = &l_569[2];
    int32_t l_573 = 0x9D1EA1CDL;
    int32_t l_574[2];
    int16_t l_575 = 8L;
    int8_t l_577 = 8L;
    int64_t *l_612 = &g_148;
    int64_t **l_611 = &l_612;
    int64_t ***l_610 = &l_611;
    const uint8_t *l_670 = &g_69[1][5];
    const uint8_t **l_669 = &l_670;
    int32_t **l_716 = &g_90[4];
    int32_t ***l_715[4][4] = {{&l_716,&l_716,&l_716,&l_716},{&l_716,&l_716,&l_716,&l_716},{&l_716,&l_716,&l_716,&l_716},{&l_716,&l_716,&l_716,&l_716}};
    uint8_t l_765 = 0x4CL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_574[i] = 0xF6F3142EL;
    if ((0x58D3L > (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*78*//* ___SAFE__OP */((g_279 ^= (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*79*//* ___SAFE__OP */((g_4 > p_11), (safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*80*//* ___SAFE__OP */(((*l_520) ^= ((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*81*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*82*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*83*//* ___SAFE__OP */(((void*)0 == p_12), (l_517 |= (func_36(p_13, p_13, &g_21[4], (safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*84*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*85*//* ___SAFE__OP */(func_45(l_48, p_11), g_211[1][8])), 1L))) < 0xD5L)))), p_11)) == 0UL), l_518)) | 253UL)), (*p_12)))))), 4UL))))
    { /* block id: 242 */
        int64_t l_524[8][3] = {{1L,(-1L),0L},{0x022EDB7039A31A2CLL,0x022EDB7039A31A2CLL,1L},{0x7967F707F69FEBE9LL,(-1L),(-1L)},{1L,0xAD8F2AD4530274EDLL,3L},{0x7967F707F69FEBE9LL,0x4136C637AD3B3413LL,0x7967F707F69FEBE9LL},{0x022EDB7039A31A2CLL,1L,3L},{1L,1L,(-1L)},{(-1L),1L,1L}};
        int32_t l_525 = 0L;
        int32_t l_526 = 1L;
        int32_t l_528 = (-8L);
        uint32_t l_529 = 18446744073709551613UL;
        uint64_t l_548 = 0x22088F212AA7D534LL;
        int i, j;
        for (l_517 = 0; (l_517 <= 9); l_517 += 1)
        { /* block id: 245 */
            int32_t l_522 = 1L;
            int32_t *l_523[6][5][5] = {{{&g_21[l_517],&g_17,(void*)0,&g_100[0],&g_21[l_517]},{&g_21[4],&g_100[0],(void*)0,&g_100[0],&g_100[0]},{&g_21[4],&l_517,&l_517,(void*)0,&g_17},{&g_21[4],&g_17,&l_522,&g_21[l_517],&l_522},{&g_21[l_517],&g_91[1],(void*)0,&g_100[0],&g_17}},{{&g_100[0],&l_522,&g_91[1],&g_100[0],&g_100[0]},{&g_100[0],&g_100[0],&g_21[l_517],&g_21[l_517],&g_100[0]},{&g_100[0],&g_17,&g_91[1],(void*)0,&l_517},{&g_91[0],&g_17,(void*)0,&g_100[0],&g_91[1]},{&g_21[l_517],&g_100[0],&l_522,&l_518,&g_100[0]}},{{&g_91[0],&l_522,&l_517,&g_17,&g_100[0]},{&g_100[0],&g_91[1],(void*)0,&g_91[1],&g_91[1]},{&g_100[0],&g_17,&g_100[0],&g_17,&l_517},{&g_100[0],&l_517,&g_100[0],&l_518,&g_100[0]},{&g_21[l_517],&g_100[0],(void*)0,&g_100[0],&g_100[0]}},{{&g_21[4],&l_517,&l_517,(void*)0,&g_17},{&g_21[4],&g_17,&l_522,&g_21[l_517],&l_522},{&g_21[l_517],&g_91[1],(void*)0,&g_100[0],&g_17},{&g_100[0],&l_522,&g_91[1],&g_100[0],&g_100[0]},{&g_100[0],&g_100[0],&g_21[l_517],&g_21[l_517],&g_100[0]}},{{&g_100[0],&g_17,&g_91[1],(void*)0,&l_517},{&g_91[0],&g_17,(void*)0,&g_100[0],&g_91[1]},{&g_21[l_517],&g_100[0],&l_522,&l_518,&g_100[0]},{&g_91[0],&l_522,&l_517,&g_17,&g_100[0]},{&g_100[0],&g_91[1],(void*)0,&g_91[1],&g_91[1]}},{{&g_100[0],&g_17,&g_100[0],&g_17,&l_517},{&g_100[0],&l_517,&g_100[0],&l_518,&g_100[0]},{&g_21[l_517],&g_100[0],(void*)0,&g_100[0],&g_100[0]},{&g_21[4],&l_517,&l_517,(void*)0,&g_17},{&g_21[4],&g_17,&l_522,&g_21[l_517],&l_522}}};
            int64_t l_527 = 3L;
            int i, j, k;
            l_529++;
            if (g_21[l_517])
            { /* block id: 247 */
                uint8_t *l_535 = &g_69[1][1];
                uint8_t **l_534[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_534[i] = &l_535;
                for (l_522 = 9; (l_522 >= 0); l_522 -= 1)
                { /* block id: 250 */
                    int i;
                    (*p_12) &= (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*86*//* ___SAFE__OP */(g_21[l_522], ((void*)0 != l_534[0])));
                }
                (*g_424) ^= ((-1L) < ((p_11 != (((**g_291) = (void*)0) == &g_100[0])) && 9L));
            }
            else
            { /* block id: 256 */
                (*g_424) = (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*87*//* ___SAFE__OP */((((((g_541 != &g_542) && p_11) != (((void*)0 != &p_11) != l_525)) , (safe_unary_minus_func_int64_t_s/* ___REMOVE_SAFE__OP *//*88*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*89*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*90*//* ___SAFE__OP */(((((*g_294) < p_11) || 0x16BD02CFL) && g_69[0][0]), (-8L))) >= p_11), l_524[7][0])) > l_529)))) ^ 1UL), g_21[4]));
            }
            if ((*p_12))
                break;
        }
        ++l_548;
        (**g_291) = (void*)0;
    }
    else
    { /* block id: 263 */
        return (*p_13);
    }
    for (g_151 = 0; (g_151 < 56); g_151 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*91*//* ___SAFE__OP */(g_151, 3))
    { /* block id: 268 */
        uint16_t l_558[4][8] = {{0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL},{0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL},{0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL},{0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL,0xAA9EL,65530UL}};
        int8_t *l_560 = &g_82[1];
        int8_t **l_559 = &l_560;
        int8_t ***l_561 = &l_559;
        int32_t l_562 = 0xFFD0C9D7L;
        int i, j;
        (*p_13) &= (safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*92*//* ___SAFE__OP */(((p_11 < ((((*l_561) = ((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*93*//* ___SAFE__OP */((!p_11), l_558[1][0])) , l_559)) != (void*)0) , ((l_562 = g_17) || (p_11 & (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*94*//* ___SAFE__OP */((!(safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*95*//* ___SAFE__OP */((((-9L) < ((l_558[1][0] , l_568) != &l_569[1])) , l_558[1][0]), l_562))), (*g_294))))))) & 0L), p_11));
        return (*p_12);
    }
    for (l_518 = 0; (l_518 < (-29)); l_518--)
    { /* block id: 276 */
        int32_t *l_572[7][7][1] = {{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}},{{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]},{&g_100[0]}}};
        int32_t l_576 = 1L;
        uint32_t l_578 = 0UL;
        int16_t l_684 = 1L;
        int8_t ***l_707 = (void*)0;
        int8_t ****l_710 = &g_708;
        uint32_t l_717 = 0x526E5890L;
        int i, j, k;
        ++l_578;
        for (p_11 = 12; (p_11 != 12); p_11 = safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*96*//* ___SAFE__OP */(p_11, 5))
        { /* block id: 280 */
            (**g_291) = &l_576;
            (*p_13) = ((g_521 = 0xD2329A7DL) , (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*97*//* ___SAFE__OP */(p_11, (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*98*//* ___SAFE__OP */(0xB1L, (g_213 >= 6L))))));
        }
        for (l_576 = (-28); (l_576 >= (-21)); l_576++)
        { /* block id: 287 */
            uint16_t l_591 = 0x431EL;
            int64_t *l_608 = &g_148;
            int64_t **l_607 = &l_608;
            int64_t ***l_606 = &l_607;
            int64_t ****l_609 = &l_606;
            int32_t l_620 = (-1L);
            uint16_t l_621 = 1UL;
            int32_t l_631 = 1L;
            int32_t l_634 = 0xB2B08DC3L;
            int32_t l_639 = 8L;
            int32_t l_641 = 0L;
            int32_t l_645[7];
            int64_t **l_702 = &l_612;
            int i;
            for (i = 0; i < 7; i++)
                l_645[i] = 0x90FCFD14L;
        }
        if (((*g_424) = ((p_10 == (void*)0) || (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*99*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*100*//* ___SAFE__OP */(((l_707 != ((*l_710) = g_708)) & (((4294967286UL & 1UL) ^ (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*101*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*102*//* ___SAFE__OP */((l_715[2][2] != (void*)0), 1)) , (l_717 & 1L)), p_11))) , g_211[3][6])), (*p_13))), p_11)))))
        { /* block id: 328 */
            int8_t l_764 = 0xE4L;
            for (g_225 = 0; (g_225 <= 7); g_225 += 1)
            { /* block id: 331 */
                uint32_t l_719 = 0x1D8AE693L;
                int16_t *l_754 = &l_575;
                for (l_578 = 2; (l_578 <= 7); l_578 += 1)
                { /* block id: 334 */
                    for (g_17 = 7; (g_17 >= 0); g_17 -= 1)
                    { /* block id: 337 */
                        int32_t l_718 = 0L;
                        const int16_t *l_724 = &g_279;
                        int64_t *l_733 = &g_734[1][5][4];
                        int i;
                        (*g_424) &= l_718;
                        l_719++;
                        (*g_424) = ((p_11 || (safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*103*//* ___SAFE__OP */(((l_724 != ((g_405 != (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*104*//* ___SAFE__OP */(((&g_279 == ((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*105*//* ___SAFE__OP */((g_21[8] == (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*106*//* ___SAFE__OP */((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*107*//* ___SAFE__OP */(((*l_733) |= (***g_613)), ((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*108*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*109*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*110*//* ___SAFE__OP */(l_719, ((p_11 || p_11) == (*p_13)))) == p_11), 18446744073709551610UL)), l_719)) < p_11))), (***g_613)))), p_11)) , &g_375)) , 0x3FBC3809L), 0xF51B4118L))) , &g_538)) <= (*p_12)), p_11))) > (*g_497));
                    }
                }
                for (g_17 = 0; (g_17 == (-15)); --g_17)
                { /* block id: 346 */
                    int16_t **l_755 = &l_516[2];
                    int16_t **l_756 = &l_754;
                    int32_t l_757 = 2L;
                    for (g_113 = 0; g_113 < 1; g_113 += 1)
                    {
                        g_100[g_113] = 0xBEA9A7D0L;
                    }
                    (*p_13) = (((((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*111*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*112*//* ___SAFE__OP */(((p_11 | (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*113*//* ___SAFE__OP */((((**g_614) = (+(safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*114*//* ___SAFE__OP */(p_11, 13)))) && ((((*l_756) = ((*l_755) = l_754)) == (l_757 , &g_375)) <= 0xAD5DL)), p_11))) | (((((p_11 < 9L) <= (*p_13)) , l_757) && g_295[3]) ^ 0L)), p_11)), 15)) && (*p_12)) || l_757) , 1UL) != p_11);
                }
            }
            (*g_424) ^= ((*p_13) |= (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*115*//* ___SAFE__OP */(((p_12 != l_572[4][5][0]) , (((void*)0 != &l_516[1]) == (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*116*//* ___SAFE__OP */((-2L), (g_734[0][5][0] | (*g_497)))))), ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*117*//* ___SAFE__OP */(((*g_615) , (((((((void*)0 == &g_372[0][2]) & l_764) , 1L) & p_11) , p_10) != (void*)0)), 0UL)) != (*p_12)))));
        }
        else
        { /* block id: 356 */
            l_765++;
        }
    }
    return (*p_12);
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_91 g_100 g_21
 * writes: g_17 g_91 g_100 g_21
 */
static int32_t * func_14(int32_t * p_15)
{ /* block id: 4 */
    uint8_t l_18 = 8UL;
    int32_t *l_19 = (void*)0;
    (*p_15) &= l_18;
    return l_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_151 g_76 g_91 g_281 g_225 g_375 g_21
 * writes: g_497 g_514 g_148 g_76 g_21
 */
static const int8_t  func_36(int32_t * p_37, int32_t * p_38, int32_t * p_39, int32_t  p_40)
{ /* block id: 231 */
    int32_t **l_489[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t *l_492 = (void*)0;
    int64_t *l_493[9][3] = {{(void*)0,&g_148,&g_148},{(void*)0,(void*)0,&g_148},{&g_148,&g_148,&g_148},{&g_148,&g_148,&g_148},{&g_148,&g_148,&g_148},{(void*)0,&g_148,&g_148},{(void*)0,(void*)0,&g_148},{&g_148,&g_148,&g_148},{&g_148,&g_148,&g_148}};
    const int32_t *l_494 = &g_91[1];
    const int32_t **l_495 = (void*)0;
    const int32_t **l_496[2];
    uint8_t *l_501 = &g_76[2][2][3];
    uint8_t **l_500 = &l_501;
    const int8_t *l_509[3][4] = {{&g_82[1],&g_82[3],&g_82[1],&g_82[3]},{&g_82[1],&g_82[3],&g_82[1],&g_82[3]},{&g_82[1],&g_82[3],&g_82[1],&g_82[3]}};
    const int8_t **l_508 = &l_509[2][2];
    int32_t l_515 = 1L;
    int i, j;
    for (i = 0; i < 2; i++)
        l_496[i] = &l_494;
    g_497 = l_494;
    (*p_37) |= (safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*118*//* ___SAFE__OP */((((g_151 , l_500) != &l_501) , ((((*l_501) = (0L || (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*119*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*120*//* ___SAFE__OP */((g_148 = ((((((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*121*//* ___SAFE__OP */((l_508 != &l_509[2][2]), g_76[8][2][0])) || (*l_494)) >= ((((((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*122*//* ___SAFE__OP */((safe_div_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*123*//* ___SAFE__OP */((((g_514 = (p_40 , &g_281)) != (void*)0) , (-8L)), g_281)), p_40)) | 0x9D43FC32L) > g_91[1]) | l_515) ^ 0xDFL) == g_225)) != p_40) ^ g_375) || p_40)), (*l_494))), 1L)))) ^ 0L) , 0xD8DBL)), 10));
    return g_91[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_213 g_424 g_76 g_148 g_211 g_21 g_372 g_405
 * writes: g_82 g_100 g_113
 */
static uint16_t  func_45(int32_t * p_46, uint32_t  p_47)
{ /* block id: 8 */
    uint8_t *l_68[7][4] = {{&g_69[0][0],&g_69[0][0],&g_69[0][0],&g_69[0][0]},{&g_69[0][0],&g_69[0][0],&g_69[0][0],&g_69[0][0]},{&g_69[0][0],&g_69[0][0],(void*)0,&g_69[0][0]},{&g_69[0][0],&g_69[0][0],&g_69[0][0],&g_69[0][0]},{&g_69[0][0],&g_69[0][0],&g_69[0][0],&g_69[0][0]},{&g_69[0][0],&g_69[0][0],(void*)0,&g_69[0][0]},{&g_69[0][0],&g_69[0][0],&g_69[0][0],&g_69[0][0]}};
    uint8_t *l_75 = &g_76[8][2][0];
    int8_t *l_81 = &g_82[1];
    int32_t l_87 = (-1L);
    int32_t **l_437[6] = {&g_424,&g_424,&g_424,&g_424,&g_424,&g_424};
    int32_t *l_465 = &g_92;
    int32_t **l_466 = &l_465;
    int8_t l_472[1];
    int32_t l_473 = 1L;
    int64_t l_474 = 0x8FD500D0F22BE44ALL;
    int32_t l_475 = 0L;
    uint64_t *l_476[7];
    uint32_t l_477 = 0UL;
    int i, j;
    for (i = 0; i < 1; i++)
        l_472[i] = 1L;
    for (i = 0; i < 7; i++)
        l_476[i] = &g_113;
    p_46 = p_46;
    l_477 = (p_47 < ((g_113 = ((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*124*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*125*//* ___SAFE__OP */(((*l_81) = ((void*)0 != &p_46)), p_47)), (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*126*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*127*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*128*//* ___SAFE__OP */(p_47, (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*129*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*130*//* ___SAFE__OP */((((l_475 ^= (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*131*//* ___SAFE__OP */(((((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*132*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*133*//* ___SAFE__OP */(((((safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*134*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*135*//* ___SAFE__OP */((l_472[0] = ((((*g_424) = (((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*136*//* ___SAFE__OP */((p_46 == ((*l_466) = l_465)), g_213)) & (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*137*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*138*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*139*//* ___SAFE__OP */(p_47, 0x1BE6L)))), p_47))) , 1L)) && g_76[8][2][0]) , g_148)), g_211[4][1])) < l_473))) , (-10L)) <= p_47) <= g_148), 0x3EL)), 7UL)) , 0L) , 0xFB5DL) == l_474), g_21[4]))) , g_21[8]) != g_76[3][0][0]), 7)) == 3L), 255UL)))) && 1UL), g_21[4])), 0UL)))) < g_372[0][2])) >= 0x8CE08B016F9D15D6LL));
    return g_405;
}


/* ------------------------------------------ */
/* 
 * reads : g_100 g_76 g_148 g_21 g_213 g_69 g_92 g_225 g_17 g_82 g_113 g_279 g_91 g_281 g_211 g_151 g_372 g_90
 * writes: g_76 g_113 g_82 g_148 g_92 g_211 g_17 g_225 g_90 g_279 g_281 g_69 g_372 g_91 g_375 g_405 g_424
 */
static int32_t * func_49(int32_t  p_50)
{ /* block id: 76 */
    int32_t **l_179[10] = {&g_90[0],&g_90[2],&g_90[0],&g_90[2],&g_90[0],&g_90[2],&g_90[0],&g_90[2],&g_90[0],&g_90[2]};
    uint8_t *l_180 = &g_76[8][2][0];
    uint64_t *l_181[10][8] = {{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{&g_113,&g_113,(void*)0,&g_113,&g_113,&g_113,&g_113,&g_113},{(void*)0,(void*)0,&g_113,&g_113,&g_113,(void*)0,(void*)0,&g_113},{&g_113,&g_113,&g_113,(void*)0,&g_113,&g_113,&g_113,&g_113},{&g_113,&g_113,&g_113,&g_113,&g_113,(void*)0,(void*)0,&g_113},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{(void*)0,(void*)0,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{&g_113,&g_113,(void*)0,(void*)0,&g_113,&g_113,(void*)0,&g_113},{(void*)0,&g_113,&g_113,(void*)0,&g_113,&g_113,(void*)0,&g_113},{(void*)0,&g_113,&g_113,&g_113,(void*)0,&g_113,&g_113,&g_113}};
    int8_t *l_196 = &g_82[0];
    int64_t l_197 = (-1L);
    int32_t l_214 = (-9L);
    const uint32_t *l_298[4][1][9] = {{{&g_213,(void*)0,&g_213,(void*)0,&g_211[1][2],(void*)0,&g_213,(void*)0,&g_213}},{{(void*)0,&g_211[2][3],(void*)0,(void*)0,&g_211[2][3],(void*)0,(void*)0,&g_211[2][3],(void*)0}},{{&g_213,(void*)0,&g_213,(void*)0,&g_211[1][2],(void*)0,&g_213,(void*)0,&g_213}},{{(void*)0,&g_211[2][3],(void*)0,(void*)0,&g_211[2][3],(void*)0,(void*)0,&g_211[2][3],(void*)0}}};
    int64_t *l_318 = &g_148;
    int64_t **l_317 = &l_318;
    uint32_t l_351[3][7] = {{1UL,0xB502D3D8L,1UL,1UL,0xB502D3D8L,1UL,1UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551613UL,18446744073709551615UL,18446744073709551615UL,18446744073709551613UL,18446744073709551615UL},{0xB502D3D8L,1UL,1UL,0xB502D3D8L,1UL,1UL,0xB502D3D8L}};
    int i, j, k;
    l_197 ^= ((g_113 = (l_179[7] == (((0x57L || ((*l_180) &= g_100[0])) && (p_50 || p_50)) , (g_148 , l_179[7])))) > (safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*140*//* ___SAFE__OP */((+(((((safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*141*//* ___SAFE__OP */(((*l_196) = (~((p_50 >= (safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*142*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*143*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*144*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*145*//* ___SAFE__OP */(((g_21[7] , p_50) | 0xF8L), p_50)), p_50)), g_148)), 5))) , g_21[4]))), p_50)) >= p_50) , 0x627C589AL) >= p_50) >= p_50)), p_50)));
lbl_305:
    for (g_148 = 0; (g_148 <= (-29)); g_148--)
    { /* block id: 83 */
        const uint32_t *l_212 = &g_213;
        int32_t *l_215[9][5][4] = {{{&l_214,&g_17,&g_17,&l_214},{&g_91[1],&g_100[0],&l_214,&g_100[0]},{&g_91[1],&g_100[0],&g_21[4],&g_21[3]},{&g_91[0],&g_91[1],(void*)0,&g_21[3]},{&g_100[0],&g_100[0],&l_214,&g_100[0]}},{{&g_91[1],&g_100[0],&g_91[1],&l_214},{(void*)0,&g_17,(void*)0,&g_100[0]},{&g_21[3],&g_91[1],&g_100[0],&g_17},{&l_214,&g_21[0],&g_100[0],&g_91[1]},{&g_21[3],&g_21[4],(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_91[1],&l_214},{&g_91[1],&l_214,&l_214,&g_100[0]},{&g_100[0],&g_91[1],(void*)0,&l_214},{&g_91[0],&g_91[1],&g_21[4],&g_100[0]},{&g_91[1],&l_214,&l_214,&l_214}},{{&g_91[1],(void*)0,&g_17,(void*)0},{&l_214,&g_21[4],&g_21[0],&g_91[1]},{(void*)0,&g_21[0],&g_91[1],&g_17},{(void*)0,&g_91[1],&g_21[0],&g_100[0]},{&l_214,&g_17,&g_17,&l_214}},{{&g_91[1],&g_100[0],&l_214,&g_100[0]},{&g_91[1],&g_100[0],&g_21[4],&g_21[3]},{&g_91[0],&g_91[1],(void*)0,&g_21[3]},{&g_100[0],&g_100[0],&l_214,&g_100[0]},{&g_91[1],&g_100[0],&g_91[1],&l_214}},{{(void*)0,&g_17,(void*)0,&g_100[0]},{&g_21[3],&g_91[1],&g_100[0],&g_17},{&l_214,&g_21[0],&g_100[0],&g_91[1]},{&g_21[3],&g_21[4],(void*)0,(void*)0},{(void*)0,&g_91[0],&g_91[1],&g_17}},{{&g_91[1],&g_17,&g_91[1],&g_21[0]},{&g_21[0],&l_214,&g_91[0],&g_91[1]},{&g_17,&l_214,&g_100[0],&g_21[0]},{&l_214,&g_17,&g_91[1],&g_17},{&g_100[0],&g_91[0],(void*)0,&l_214}},{{&g_91[1],&g_91[1],&g_21[3],&g_21[4]},{&l_214,&g_21[3],&l_214,(void*)0},{&l_214,&g_91[1],&g_21[3],&l_214},{&g_91[1],(void*)0,(void*)0,&g_91[1]},{&g_100[0],&g_21[0],&g_91[1],(void*)0}},{{&l_214,&l_214,&g_100[0],&g_100[0]},{&g_17,&g_21[4],&g_91[0],&g_100[0]},{&g_21[0],&l_214,&g_91[1],(void*)0},{&g_91[1],&g_21[0],&g_91[1],&g_91[1]},{&g_91[0],(void*)0,&l_214,&l_214}}};
        uint8_t *l_228 = &g_76[1][2][2];
        int i, j, k;
        for (p_50 = 0; (p_50 <= 16); p_50 = safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*146*//* ___SAFE__OP */(p_50, 7))
        { /* block id: 86 */
            int32_t **l_208[4];
            int i;
            for (i = 0; i < 4; i++)
                l_208[i] = &g_90[2];
            for (g_92 = 10; (g_92 < (-4)); g_92 = safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*147*//* ___SAFE__OP */(g_92, 4))
            { /* block id: 89 */
                int32_t ***l_209[10];
                uint32_t *l_210 = &g_211[2][3];
                int i;
                for (i = 0; i < 10; i++)
                    l_209[i] = &l_179[0];
                l_214 = ((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*148*//* ___SAFE__OP */((l_208[3] != (l_179[7] = (void*)0)), ((*l_210) = p_50))) != ((void*)0 != l_212));
                return &g_100[0];
            }
        }
        for (g_17 = 0; (g_17 <= 10); g_17++)
        { /* block id: 98 */
            int8_t l_221 = 2L;
            l_215[2][4][1] = func_70((+((((safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*149*//* ___SAFE__OP */(l_221, ((safe_rshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*150*//* ___SAFE__OP */((g_76[8][2][0] || (safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*151*//* ___SAFE__OP */((g_225 = 0x9598L)))), 19)) > (safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*152*//* ___SAFE__OP */(p_50, (l_179[7] != (void*)0)))))) <= g_213) & 0x8C434FA4L) ^ g_69[0][0])), l_221, l_228);
        }
    }
lbl_422:
    for (l_197 = 0; (l_197 <= 12); l_197++)
    { /* block id: 105 */
        uint32_t l_231 = 18446744073709551615UL;
        int32_t l_252 = 0xCC484957L;
        uint16_t l_302 = 0x1CF7L;
        l_231 ^= p_50;
        for (g_113 = 25; (g_113 >= 3); g_113--)
        { /* block id: 109 */
            uint32_t l_236 = 0x92E53F40L;
            int32_t l_244 = (-6L);
            int8_t *l_245 = &g_82[3];
            int32_t l_248 = 0x3F1FFCACL;
            int64_t l_255 = 3L;
            if ((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*153*//* ___SAFE__OP */(((p_50 | (((l_236 = l_231) ^ ((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*154*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s/* ___REMOVE_SAFE__OP *//*155*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*156*//* ___SAFE__OP */((p_50 | (l_244 = (safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*157*//* ___SAFE__OP */(l_244, (0xDA1883B8L >= ((l_245 == &g_82[1]) >= g_92)))))), ((((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*158*//* ___SAFE__OP */(l_248, g_76[8][2][0])) ^ g_76[3][0][2]) & 0x09L) ^ 1L))))), 1UL)) , g_225)) >= g_17)) < p_50), 0x172FL)))
            { /* block id: 112 */
                int32_t l_270 = 0x701A609BL;
                int32_t l_282 = (-1L);
                uint32_t *l_297 = &g_211[4][2];
                for (g_225 = 0; (g_225 >= 28); ++g_225)
                { /* block id: 115 */
                    int8_t **l_251 = &l_245;
                    int32_t l_253[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_253[i] = (-3L);
                    if ((l_253[1] = (l_252 = ((&g_82[2] == ((*l_251) = &g_82[1])) , 0x56F44BDAL))))
                    { /* block id: 119 */
                        const uint32_t l_254[8] = {0xF63B3740L,0xF63B3740L,0xF63B3740L,0xF63B3740L,0xF63B3740L,0xF63B3740L,0xF63B3740L,0xF63B3740L};
                        int32_t l_265 = 0x01A3D08DL;
                        int16_t *l_277 = (void*)0;
                        int16_t *l_278 = &g_279;
                        uint16_t *l_280 = &g_281;
                        int i;
                        l_252 &= p_50;
                        l_255 = l_254[7];
                        l_282 &= (safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*159*//* ___SAFE__OP */(((void*)0 == &g_90[8]), (((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*160*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*161*//* ___SAFE__OP */(((((safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*162*//* ___SAFE__OP */((+((l_265 &= 0x4497D976L) >= (((l_252 < 4L) > (((((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*163*//* ___SAFE__OP */((((*l_280) &= (((((((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*164*//* ___SAFE__OP */(((*l_278) |= (((l_270 && 0x21D3A323L) != (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*165*//* ___SAFE__OP */(4294967286UL, (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*166*//* ___SAFE__OP */(((*l_196) |= (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*167*//* ___SAFE__OP */((g_213 || p_50), 0x16L))), g_113))))) , 0L)), l_253[1])) | g_213) & p_50) ^ 0x769E7B83F1A1F52BLL) , (void*)0) != &g_113) ^ g_91[0])) < 65535UL), p_50)) || l_252) ^ l_270) > g_21[2]) >= l_252)) , 0x156E5381L))), p_50)) , p_50) == g_211[2][3]) > 0x208D1ECEL), p_50)) && p_50), p_50)) , 0x065AF7AC0CD27E44LL) != g_151)));
                    }
                    else
                    { /* block id: 127 */
                        int32_t *l_299 = &g_91[1];
                        int32_t l_300 = (-7L);
                        int32_t l_301[10][5] = {{0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L},{0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL},{0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L},{0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL},{0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L},{0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL},{0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L},{0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL},{0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L,0x2D4A61B7L},{0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL,0xE946A76BL}};
                        int i, j;
                        l_299 = &l_248;
                        l_302++;
                        if (p_50)
                            break;
                        if (l_270)
                            continue;
                    }
                    if (l_302)
                        goto lbl_305;
                }
            }
            else
            { /* block id: 136 */
                int16_t *l_308[4][10][6] = {{{&g_279,(void*)0,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,(void*)0,(void*)0,(void*)0,&g_279},{&g_279,&g_279,(void*)0,(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279,(void*)0,(void*)0,&g_279},{&g_279,&g_279,(void*)0,&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279,(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279,(void*)0,&g_279,&g_279},{&g_279,(void*)0,(void*)0,&g_279,&g_279,&g_279},{(void*)0,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279}},{{(void*)0,&g_279,(void*)0,&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279,&g_279,(void*)0,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,(void*)0},{&g_279,(void*)0,&g_279,(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279,(void*)0,&g_279,&g_279},{&g_279,(void*)0,(void*)0,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279}},{{&g_279,&g_279,(void*)0,&g_279,(void*)0,&g_279},{&g_279,(void*)0,(void*)0,(void*)0,&g_279,(void*)0},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,(void*)0},{&g_279,(void*)0,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,&g_279,&g_279,&g_279},{&g_279,(void*)0,(void*)0,(void*)0,(void*)0,&g_279},{&g_279,&g_279,&g_279,&g_279,(void*)0,&g_279}},{{&g_279,&g_279,&g_279,&g_279,(void*)0,&g_279},{&g_279,&g_279,(void*)0,&g_279,&g_279,(void*)0},{&g_279,&g_279,&g_279,&g_279,(void*)0,&g_279},{&g_279,&g_279,&g_279,(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279,(void*)0,&g_279,&g_279},{&g_279,(void*)0,&g_279,&g_279,(void*)0,(void*)0},{&g_279,(void*)0,(void*)0,&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279,&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279,(void*)0,&g_279,&g_279},{&g_279,&g_279,(void*)0,&g_279,&g_279,&g_279}}};
                uint64_t l_309 = 18446744073709551615UL;
                int32_t *l_310 = &g_92;
                int32_t *l_311 = &l_244;
                int i, j, k;
                l_311 = func_70(((((-1L) >= (g_279 = (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*168*//* ___SAFE__OP */(g_76[8][2][0], p_50)))) , l_245) == (void*)0), ((*l_310) = l_309), &g_69[1][7]);
            }
        }
    }
    for (p_50 = 0; (p_50 >= 10); p_50 = safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*169*//* ___SAFE__OP */(p_50, 7))
    { /* block id: 145 */
        int32_t *l_314 = &g_91[1];
        int32_t l_344 = 0L;
        uint16_t l_373 = 65535UL;
        int32_t *l_421[2];
        int64_t l_429 = 3L;
        int i;
        for (i = 0; i < 2; i++)
            l_421[i] = &g_100[0];
        l_314 = l_314;
        for (g_148 = 3; (g_148 == (-9)); g_148--)
        { /* block id: 149 */
            for (g_281 = 2; (g_281 <= 9); g_281 += 1)
            { /* block id: 152 */
                int64_t ***l_319 = &l_317;
                (*l_319) = l_317;
            }
        }
        for (l_214 = 9; (l_214 >= 0); l_214 -= 1)
        { /* block id: 158 */
            int32_t l_346 = 5L;
            int32_t l_352 = 0L;
            uint8_t *l_362 = &g_76[6][2][4];
            for (g_148 = 8; (g_148 >= 0); g_148 -= 1)
            { /* block id: 161 */
                uint64_t l_328 = 0xE4CF603A90A0045BLL;
                int16_t *l_343 = &g_279;
                uint32_t *l_345 = &g_211[2][3];
                uint32_t *l_347 = &g_225;
                uint8_t *l_348 = &g_69[0][1];
                uint8_t l_349 = 1UL;
                int64_t *l_350[8][8][4] = {{{&l_197,&l_197,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,(void*)0,&l_197,(void*)0},{(void*)0,(void*)0,&l_197,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0}},{{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,&l_197}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_197,&l_197,&l_197,(void*)0},{&l_197,(void*)0,(void*)0,(void*)0},{(void*)0,&l_197,&l_197,&l_197},{&l_197,(void*)0,&l_197,&l_197},{(void*)0,(void*)0,&l_197,&l_197}},{{(void*)0,(void*)0,(void*)0,&l_197},{(void*)0,&l_197,&l_197,(void*)0},{(void*)0,&l_197,&l_197,&l_197},{&l_197,(void*)0,&l_197,&l_197},{(void*)0,(void*)0,&l_197,&l_197},{(void*)0,(void*)0,(void*)0,&l_197},{(void*)0,&l_197,&l_197,(void*)0},{(void*)0,&l_197,&l_197,&l_197}}};
                int32_t l_366 = 0x91D7C01FL;
                int i, j, k;
                l_352 ^= ((((l_351[0][5] = ((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*170*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*171*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*172*//* ___SAFE__OP */((((*l_196) = (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*173*//* ___SAFE__OP */((*l_314), 11))) & (((*l_348) = ((l_328 > (*l_314)) || (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*174*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*175*//* ___SAFE__OP */(((*l_180) = ((safe_unary_minus_func_int32_t_s/* ___REMOVE_SAFE__OP *//*176*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*177*//* ___SAFE__OP */((*l_314), (((*l_347) = (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*178*//* ___SAFE__OP */(((((0x82L & (((*l_345) = ((((-9L) > (((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*179*//* ___SAFE__OP */(((0xB276342CL > (safe_unary_minus_func_uint8_t_u/* ___REMOVE_SAFE__OP *//*180*//* ___SAFE__OP */((1L & (((*l_343) = ((g_113--) , g_91[1])) , l_344))))) ^ 0UL), p_50)) , (-8L)) == l_328)) , 0x3C1AL) > g_91[0])) >= g_76[8][2][0])) & (*l_314)) & l_346) , (-1L)), 12))) || p_50))) < g_76[7][0][2]))) < 255UL)), p_50)), (-1L))))) > l_346)), 0xCD60B231EA6511E1LL)), g_91[1])), l_349)) , p_50)) , g_100[0]) && g_76[7][2][4]) >= 0UL);
                for (g_225 = 3; (g_225 <= 9); g_225 += 1)
                { /* block id: 173 */
                    int i;
                    if (l_346)
                    { /* block id: 174 */
                        uint8_t **l_363 = &l_362;
                        uint8_t **l_364 = (void*)0;
                        uint8_t **l_365 = &l_180;
                        int16_t *l_374[3][7] = {{&g_375,(void*)0,(void*)0,&g_375,(void*)0,(void*)0,&g_375},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_375,&g_375,(void*)0,&g_375,&g_375,(void*)0,&g_375}};
                        int32_t *l_376 = &g_91[1];
                        int i, j;
                        l_352 = (7UL & (safe_unary_minus_func_uint64_t_u/* ___REMOVE_SAFE__OP *//*181*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*182*//* ___SAFE__OP */((g_213 || ((!((g_375 = ((+((((safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*183*//* ___SAFE__OP */(((~((*l_343) ^= (!((l_366 &= (((*l_363) = l_362) != ((*l_365) = (void*)0))) >= (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*184*//* ___SAFE__OP */(((l_298[2][0][6] != &g_92) != ((*l_314) = ((g_372[0][2] = (~((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*185*//* ___SAFE__OP */(g_100[0], (0xA285L >= g_113))) <= 0xAF54L))) < p_50))), 30)))))) < 0xA1L), 0UL)) && (*l_314)) != (-10L)) == l_373)) & 0x398F459FL)) == g_92)) != 0x2B780CC1CDA1E984LL)), 35)))));
                        return l_376;
                    }
                    else
                    { /* block id: 184 */
                        uint8_t l_391 = 0xE0L;
                        int32_t *l_404 = (void*)0;
                        int32_t **l_403 = &l_404;
                        int32_t l_406 = 0x0CE07EB1L;
                        (*l_314) |= (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*186*//* ___SAFE__OP */((g_82[1] = (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*187*//* ___SAFE__OP */((g_69[0][5] ^ (g_82[2] == (-2L))), p_50))), 0x14L));
                        l_406 = ((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*188*//* ___SAFE__OP */((((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*189*//* ___SAFE__OP */((((((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*190*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*191*//* ___SAFE__OP */(p_50, 6)) || 0xE7F411A97A598A38LL), (safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*192*//* ___SAFE__OP */((((l_391 |= (-1L)) != (+((g_113 ^= g_69[1][2]) <= (((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*193*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*194*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*195*//* ___SAFE__OP */(((l_349 != (((*l_345) = (safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*196*//* ___SAFE__OP */(((((g_405 = (((g_82[1] != (-1L)) , (((*l_403) = &g_92) == &p_50)) | 0x10342B1AL)) || p_50) == l_349) ^ g_281), 7))) == 1UL)) | 0xD19E72E9L), g_69[0][2])) != 0L), p_50)), 3L)) , g_82[1]) , g_281)))) < p_50), p_50)))) < 1L) < p_50) | g_100[0]) || p_50), 0x2DADL)) && g_76[0][2][5]) , p_50), g_372[0][2])) < 4UL);
                    }
                    if ((!(safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*197*//* ___SAFE__OP */(((~(safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*198*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*199*//* ___SAFE__OP */((p_50 , (!7L)), (((--(*l_345)) || p_50) == p_50))), (p_50 , (l_366 |= (&l_349 != &g_372[1][4])))))) , (g_213 && g_92)), 7))))
                    { /* block id: 196 */
                        uint16_t l_418[5] = {0xB132L,0xB132L,0xB132L,0xB132L,0xB132L};
                        int i;
                        g_90[g_225] = &l_344;
                        ++l_418[0];
                        return l_421[1];
                    }
                    else
                    { /* block id: 200 */
                        int16_t l_423 = 1L;
                        if (g_279)
                            goto lbl_422;
                        (*l_314) = l_423;
                        (*l_314) |= p_50;
                        g_424 = (g_90[(g_148 + 1)] = g_90[(g_148 + 1)]);
                    }
                }
            }
        }
        for (g_279 = 0; (g_279 <= 3); ++g_279)
        { /* block id: 212 */
            int64_t l_432[8][9] = {{0xD906CE609FFAB7EALL,0L,9L,(-6L),0xBBF3BCAA90B541A9LL,9L,0x18971EB0DDA2389FLL,0x3663DE434C83E276LL,0x35C065375967B103LL},{(-7L),(-1L),9L,(-10L),(-10L),9L,(-1L),(-7L),0x35C065375967B103LL},{0x3663DE434C83E276LL,0x18971EB0DDA2389FLL,9L,0xBBF3BCAA90B541A9LL,(-6L),9L,0L,0xD906CE609FFAB7EALL,0x35C065375967B103LL},{0xD906CE609FFAB7EALL,0L,9L,(-6L),0xBBF3BCAA90B541A9LL,9L,0x18971EB0DDA2389FLL,0x3663DE434C83E276LL,0x35C065375967B103LL},{(-7L),(-1L),9L,(-10L),(-10L),9L,(-1L),(-7L),0x35C065375967B103LL},{0x3663DE434C83E276LL,0x18971EB0DDA2389FLL,9L,0xBBF3BCAA90B541A9LL,(-6L),9L,0L,0xD906CE609FFAB7EALL,0x35C065375967B103LL},{0xD906CE609FFAB7EALL,0L,9L,(-6L),0xBBF3BCAA90B541A9LL,9L,0x18971EB0DDA2389FLL,0x3663DE434C83E276LL,0x35C065375967B103LL},{(-7L),(-1L),9L,(-10L),(-10L),9L,(-1L),(-7L),0x35C065375967B103LL}};
            int32_t l_433 = 0x9E25946AL;
            int i, j;
            for (l_344 = 0; (l_344 <= (-20)); l_344--)
            { /* block id: 215 */
                int16_t l_430 = 0L;
                int32_t l_431[7];
                uint8_t l_434 = 0UL;
                int i;
                for (i = 0; i < 7; i++)
                    l_431[i] = 0xE8A2E5FBL;
                ++l_434;
            }
        }
    }
    return &g_21[4];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_113 g_17 g_69
 */
static int32_t  func_51(int32_t  p_52, uint8_t  p_53, uint16_t  p_54, int32_t * p_55)
{ /* block id: 73 */
    int32_t l_178 = (-2L);
    for (g_113 = 0; g_113 < 2; g_113 += 1)
    {
        for (g_17 = 0; g_17 < 9; g_17 += 1)
        {
            g_69[g_113][g_17] = 250UL;
        }
    }
    return l_178;
}


/* ------------------------------------------ */
/* 
 * reads : g_92 g_113
 * writes: g_92
 */
static uint8_t  func_60(int32_t * p_61, uint32_t  p_62, int8_t  p_63)
{ /* block id: 66 */
    int16_t l_166[4][3] = {{0L,0x14A8L,0L},{1L,0x8F5FL,(-5L)},{1L,1L,0x8F5FL},{0L,0x8F5FL,0x8F5FL}};
    int32_t l_167 = 0L;
    int32_t l_168 = 0L;
    int32_t l_169 = 0xB26997C5L;
    int32_t l_170 = 0xC15DE777L;
    int16_t l_171 = (-1L);
    int32_t l_172 = 0x8516656BL;
    int32_t l_173 = 0L;
    int32_t l_174[6] = {0xC5C6358EL,0xC5C6358EL,0xC5C6358EL,0xC5C6358EL,0xC5C6358EL,0xC5C6358EL};
    uint32_t l_175 = 0xD5C39C69L;
    int i, j;
    for (g_92 = 0; (g_92 < 25); g_92 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*200*//* ___SAFE__OP */(g_92, 7))
    { /* block id: 69 */
        int32_t *l_165[7] = {&g_17,&g_17,&g_17,&g_17,&g_17,&g_17,&g_17};
        int i;
        l_175--;
    }
    return g_113;
}


/* ------------------------------------------ */
/* 
 * reads : g_92 g_17 g_76 g_91 g_21 g_69 g_82 g_151
 * writes: g_17 g_91 g_92 g_90 g_100 g_76 g_113 g_148 g_151
 */
static int32_t * func_64(uint8_t  p_65, const uint8_t  p_66, int32_t * p_67)
{ /* block id: 15 */
    int8_t l_93 = (-1L);
    int32_t l_111 = 0L;
    int32_t l_153 = (-7L);
    uint32_t l_159 = 0x834275C0L;
    int32_t *l_162 = &g_21[4];
    if (l_93)
    { /* block id: 16 */
        int32_t *l_94 = &g_91[1];
        uint32_t l_116 = 4294967293UL;
        (*l_94) = ((*p_67) = 0xA91624B3L);
        for (g_92 = 0; (g_92 >= 13); g_92 = safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*201*//* ___SAFE__OP */(g_92, 5))
        { /* block id: 21 */
            int64_t l_101 = 0x8DAB47FCA77B6811LL;
            for (l_93 = 0; l_93 < 2; l_93 += 1)
            {
                g_91[l_93] = (-1L);
            }
            if ((*p_67))
            { /* block id: 23 */
                int32_t **l_97 = &g_90[2];
                (*l_97) = (void*)0;
            }
            else
            { /* block id: 25 */
                int32_t **l_102[9][8] = {{&g_90[2],&l_94,&l_94,&g_90[4],&l_94,&l_94,&l_94,&l_94},{&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[2],&g_90[4],&g_90[2]},{&l_94,(void*)0,&g_90[6],&l_94,&g_90[4],&l_94,&g_90[2],&g_90[6]},{&l_94,(void*)0,&g_90[6],&l_94,&l_94,&l_94,&l_94,&g_90[6]},{(void*)0,(void*)0,&g_90[4],&l_94,&l_94,&g_90[4],&g_90[2],(void*)0},{(void*)0,&l_94,&g_90[2],&l_94,&g_90[2],&g_90[2],&g_90[6],(void*)0},{&l_94,&l_94,(void*)0,&l_94,(void*)0,&l_94,&l_94,&g_90[6]},{&g_90[6],&l_94,&l_94,&l_94,&l_94,(void*)0,&g_90[2],&g_90[6]},{&g_90[2],&g_90[6],&l_94,&l_94,&l_94,&g_90[2],&g_90[2],&l_94}};
                uint64_t *l_112 = &g_113;
                int i, j;
                for (l_93 = 28; (l_93 >= (-29)); l_93 = safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*202*//* ___SAFE__OP */(l_93, 1))
                { /* block id: 28 */
                    for (p_65 = 0; p_65 < 9; p_65 += 1)
                    {
                        for (g_17 = 0; g_17 < 3; g_17 += 1)
                        {
                            for (g_100[0] = 0; g_100[0] < 6; g_100[0] += 1)
                            {
                                g_76[p_65][g_17][g_100[0]] = 0UL;
                            }
                        }
                    }
                    l_101 |= l_93;
                }
                g_90[8] = p_67;
                (*p_67) |= (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*203*//* ___SAFE__OP */(g_76[8][2][0], ((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*204*//* ___SAFE__OP */((p_66 & p_66), (((((void*)0 == p_67) , (void*)0) != ((((*l_94) == (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*205*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*206*//* ___SAFE__OP */((((*l_112) = (l_111 |= g_76[8][2][0])) < (safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*207*//* ___SAFE__OP */(g_21[6], 5))), (*l_94))), l_116))) > p_66) , &p_66)) , 9L))) , 0xEB5BL)));
            }
        }
    }
    else
    { /* block id: 38 */
        return p_67;
    }
    for (g_17 = 0; (g_17 == (-12)); g_17 = safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*208*//* ___SAFE__OP */(g_17, 6))
    { /* block id: 43 */
        int32_t l_135[8][10][3] = {{{(-10L),0x9266F03DL,0xE36A8F31L},{0xBA81857DL,(-7L),(-1L)},{0L,0xB8F82D9EL,(-4L)},{0xBA81857DL,0xBA81857DL,0L},{(-10L),0x84A0DC95L,0x3E8B2B7EL},{0xE54A6601L,1L,(-7L)},{0x1E69A061L,0xB8F82D9EL,0x4F71DE7DL},{0x07845806L,0xE54A6601L,(-7L)},{(-1L),0x9266F03DL,0x3E8B2B7EL},{(-4L),0x0C101F13L,0L}},{{0x4F71DE7DL,1L,(-4L)},{0x07845806L,(-4L),(-1L)},{0xE36A8F31L,1L,0xE36A8F31L},{0xE54A6601L,0x0C101F13L,1L},{1L,0x9266F03DL,0x1E69A061L},{0xBA81857DL,0xE54A6601L,(-1L)},{(-1L),0xB8F82D9EL,0x31660C04L},{0xBA81857DL,1L,0L},{1L,0x84A0DC95L,0xB3E5AADBL},{0xE54A6601L,0xBA81857DL,(-7L)}},{{0xE36A8F31L,0xB8F82D9EL,(-1L)},{0x07845806L,(-7L),(-7L)},{0x4F71DE7DL,0x9266F03DL,0xB3E5AADBL},{(-4L),0x07845806L,0L},{(-1L),1L,0x31660C04L},{0x07845806L,(-9L),(-1L)},{0x1E69A061L,1L,0x1E69A061L},{0xE54A6601L,0x07845806L,1L},{(-10L),0x9266F03DL,0xE36A8F31L},{0xBA81857DL,(-7L),(-1L)}},{{0L,0xB8F82D9EL,(-4L)},{0xBA81857DL,0xBA81857DL,0L},{(-10L),0x84A0DC95L,0x3E8B2B7EL},{0xE54A6601L,1L,(-7L)},{0x1E69A061L,0xB8F82D9EL,0x4F71DE7DL},{0x07845806L,0xE54A6601L,(-7L)},{(-1L),0x9266F03DL,0x3E8B2B7EL},{(-4L),0x0C101F13L,0L},{0x4F71DE7DL,1L,(-4L)},{0x07845806L,(-4L),(-1L)}},{{0xE36A8F31L,1L,0xE36A8F31L},{0xE54A6601L,0x0C101F13L,1L},{1L,0x9266F03DL,0x1E69A061L},{0xBA81857DL,0xE54A6601L,(-1L)},{(-1L),0xB8F82D9EL,0x31660C04L},{0xBA81857DL,1L,0L},{1L,0x84A0DC95L,0xB3E5AADBL},{0xE54A6601L,0xE8C7AEF2L,(-9L)},{(-1L),0x9266F03DL,(-1L)},{0xE54A6601L,(-9L),(-9L)}},{{0x9F05F928L,0x84A0DC95L,(-4L)},{1L,0xE54A6601L,1L},{(-1L),0x92B5330BL,(-1L)},{0xE54A6601L,(-1L),0L},{0L,0x92B5330BL,0L},{(-4L),0xE54A6601L,(-4L)},{0xE36A8F31L,0x84A0DC95L,(-1L)},{0xE8C7AEF2L,(-9L),0L},{0xB3E5AADBL,0x9266F03DL,0x4F71DE7DL},{0xE8C7AEF2L,0xE8C7AEF2L,1L}},{{0xE36A8F31L,0L,0x31660C04L},{(-4L),(-4L),(-9L)},{0L,0x9266F03DL,0x9F05F928L},{0xE54A6601L,(-4L),(-9L)},{(-1L),0x84A0DC95L,0x31660C04L},{1L,(-7L),1L},{0x9F05F928L,0x92B5330BL,0x4F71DE7DL},{0xE54A6601L,1L,0L},{(-1L),0x92B5330BL,(-1L)},{(-4L),(-7L),(-4L)}},{{0x1E69A061L,0x84A0DC95L,0L},{0xE8C7AEF2L,(-4L),0L},{0x3E8B2B7EL,0x9266F03DL,(-1L)},{0xE8C7AEF2L,(-4L),1L},{0x1E69A061L,0L,(-4L)},{(-4L),0xE8C7AEF2L,(-9L)},{(-1L),0x9266F03DL,(-1L)},{0xE54A6601L,(-9L),(-9L)},{0x9F05F928L,0x84A0DC95L,(-4L)},{1L,0xE54A6601L,1L}}};
        int i, j, k;
        for (p_65 = 29; (p_65 <= 5); --p_65)
        { /* block id: 46 */
            int32_t *l_140[8][9] = {{&g_100[0],&g_100[0],&g_21[1],&g_91[1],&g_17,&g_91[1],&g_21[1],&g_100[0],&g_100[0]},{(void*)0,&g_100[0],&g_100[0],&g_91[1],&g_100[0],&g_100[0],(void*)0,(void*)0,&g_100[0]},{&g_91[1],&g_100[0],&g_21[1],&g_100[0],&g_91[1],&l_111,&l_111,&g_91[1],&g_100[0]},{(void*)0,&g_100[0],(void*)0,&l_111,&g_21[1],&g_21[1],&l_111,(void*)0,&g_100[0]},{&g_100[0],(void*)0,&l_111,&g_21[1],&g_21[1],&l_111,(void*)0,&g_100[0],(void*)0},{&g_100[0],&g_91[1],&l_111,&l_111,&g_91[1],&g_100[0],&g_21[1],&g_100[0],&g_91[1]},{&g_100[0],(void*)0,(void*)0,&g_100[0],&g_100[0],&g_91[1],&g_100[0],&g_100[0],(void*)0},{&g_100[0],&g_100[0],&g_21[1],&g_91[1],&g_17,&g_91[1],&g_21[1],&g_100[0],&g_100[0]}};
            int32_t **l_141 = &l_140[7][4];
            int8_t *l_145 = &g_82[1];
            int8_t **l_144 = &l_145;
            int64_t *l_146 = (void*)0;
            int64_t *l_147 = &g_148;
            int32_t *l_149 = &l_111;
            uint32_t *l_150 = &g_151;
            int i, j;
            if (((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*209*//* ___SAFE__OP */((~(!(safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*210*//* ___SAFE__OP */(((((*l_150) ^= (g_92 == ((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*211*//* ___SAFE__OP */(0xCCL, (safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*212*//* ___SAFE__OP */((((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*213*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*214*//* ___SAFE__OP */(g_76[4][0][2], (l_135[2][4][2] <= ((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*215*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*216*//* ___SAFE__OP */((((*l_141) = l_140[7][4]) == &l_111), ((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*217*//* ___SAFE__OP */(((*l_149) = ((l_141 == &g_90[7]) > ((*l_147) = (((*l_144) = &g_82[1]) == &g_82[3])))), (*p_67))) < g_91[1]))) > 0x6FL), g_69[1][6])) , p_65)))), 1UL)) <= g_82[2]) , l_135[2][4][2]), 0xA721C5E8018D861CLL)))) >= (*p_67)))) , p_67) == (void*)0), l_135[2][4][2])))), p_66)) >= l_93))
            { /* block id: 52 */
                uint32_t l_152 = 1UL;
                int32_t l_154 = 0xAFDD340CL;
                if (l_152)
                    break;
                l_153 = ((*l_149) = (*p_67));
                l_154 = (*p_67);
                return p_67;
            }
            else
            { /* block id: 58 */
                return p_67;
            }
        }
        if ((*p_67))
            break;
    }
    (*p_67) = ((((safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*218*//* ___SAFE__OP */(0x6202L, (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*219*//* ___SAFE__OP */((p_65 , l_111), l_159)))) , (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*220*//* ___SAFE__OP */((&g_82[2] != &l_93), ((void*)0 == &g_148)))) ^ (g_76[1][2][5] , 18446744073709551614UL)) < (*p_67));
    return l_162;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_90 g_92
 */
static int32_t * func_70(uint8_t  p_71, int32_t  p_72, uint8_t * p_73)
{ /* block id: 11 */
    int32_t *l_89 = &g_21[7];
    int32_t **l_88[6][9] = {{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89}};
    int i, j;
    g_90[2] = &g_21[2];
    g_92 = 0xF5A0A6BDL;
    return &g_17;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_21[i], "g_21[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_69[i][j], "g_69[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_76[i][j][k], "g_76[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_82[i], "g_82[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_91[i], "g_91[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_92, "g_92", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_100[i], "g_100[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_211[i][j], "g_211[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_279, "g_279", print_hash_value);
    transparent_crc(g_281, "g_281", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_295[i], "g_295[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_372[i][j], "g_372[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_375, "g_375", print_hash_value);
    transparent_crc(g_405, "g_405", print_hash_value);
    transparent_crc(g_521, "g_521", print_hash_value);
    transparent_crc(g_538, "g_538", print_hash_value);
    transparent_crc(g_681, "g_681", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_734[i][j][k], "g_734[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_769[i][j], "g_769[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_771, "g_771", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_788[i][j], "g_788[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_791, "g_791", print_hash_value);
    transparent_crc(g_941, "g_941", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_943[i][j], "g_943[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_988, "g_988", print_hash_value);
    transparent_crc(g_1005, "g_1005", print_hash_value);
    transparent_crc(g_1007, "g_1007", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 305
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 170
   depth: 2, occurrence: 45
   depth: 3, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 5
   depth: 19, occurrence: 1
   depth: 20, occurrence: 4
   depth: 21, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 5
   depth: 25, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 5
   depth: 30, occurrence: 3
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 41, occurrence: 1
   depth: 44, occurrence: 1

XXX total number of pointers: 189

XXX times a variable address is taken: 478
XXX times a pointer is dereferenced on RHS: 107
breakdown:
   depth: 1, occurrence: 94
   depth: 2, occurrence: 7
   depth: 3, occurrence: 6
XXX times a pointer is dereferenced on LHS: 131
breakdown:
   depth: 1, occurrence: 115
   depth: 2, occurrence: 15
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 32
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 5
XXX times a pointer is qualified to be dereferenced: 4536

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 553
   level: 2, occurrence: 69
   level: 3, occurrence: 65
   level: 4, occurrence: 1
XXX number of pointers point to pointers: 72
XXX number of pointers point to scalars: 117
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.5
XXX average alias set size: 1.47

XXX times a non-volatile is read: 816
XXX times a non-volatile is write: 410
XXX times a volatile is read: 36
XXX    times read thru a pointer: 16
XXX times a volatile is write: 16
XXX    times written thru a pointer: 15
XXX times a volatile is available for access: 551
XXX percentage of non-volatile access: 95.9

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 178
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 30
   depth: 2, occurrence: 29
   depth: 3, occurrence: 31
   depth: 4, occurrence: 27
   depth: 5, occurrence: 30

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
********************* end of statistics **********************/

