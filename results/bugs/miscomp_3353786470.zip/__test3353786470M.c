/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 3353786470 --bitfields --packed-struct
 * Seed:      3353786470
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile unsigned f0 : 1;
   uint32_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t *g_13 = (void*)0;
static const int32_t g_22 = 0L;
static int32_t g_30 = (-8L);
static int32_t *g_29 = &g_30;
static uint64_t g_39[6][9][4] = {{{0x799115BA09F94EB4LL,0x5D5EC7E011B55E97LL,0UL,18446744073709551612UL},{1UL,0x5D5EC7E011B55E97LL,0xBFD33F116E8CFB99LL,0x7E7F6F8F643D9D76LL},{0x5D5EC7E011B55E97LL,0x8A514227F44FB66CLL,0x9A9D0127420EA1BCLL,0x22BB76E0E3F56F60LL},{0xB9D72FAF72239D13LL,1UL,1UL,0x4E630971CF717C92LL},{6UL,0UL,0x361030FACFA70DAELL,0x8E7029BB2D3F5771LL},{0xCC6B0C40B387E8D9LL,1UL,0x35292FD4AE77DDBALL,0x9457720F84B0F4F2LL},{0x361030FACFA70DAELL,1UL,0x8A514227F44FB66CLL,18446744073709551615UL},{1UL,0x799115BA09F94EB4LL,0x7E7F6F8F643D9D76LL,1UL},{0x8E7029BB2D3F5771LL,0x35292FD4AE77DDBALL,0x714BA09A164E62B5LL,0x35292FD4AE77DDBALL}},{{0x8A514227F44FB66CLL,0x714BA09A164E62B5LL,18446744073709551607UL,1UL},{1UL,0UL,0xB299B5F277F141C5LL,1UL},{0x22BB76E0E3F56F60LL,18446744073709551607UL,0x9257DE97EE8C4B05LL,0x361030FACFA70DAELL},{0xCC6B0C40B387E8D9LL,0x8A514227F44FB66CLL,1UL,1UL},{18446744073709551609UL,0x361030FACFA70DAELL,4UL,0xF800085869896260LL},{0x4E630971CF717C92LL,6UL,18446744073709551615UL,0x9A9D0127420EA1BCLL},{0x88A3D85AA7F794FCLL,0x352A55CCBD95D606LL,18446744073709551612UL,0x4E630971CF717C92LL},{0x9A9D0127420EA1BCLL,18446744073709551607UL,0x4E630971CF717C92LL,1UL},{0xB9D72FAF72239D13LL,0x35292FD4AE77DDBALL,0UL,0x06C165AAE70C30F1LL}},{{0x352A55CCBD95D606LL,0UL,0xB9D72FAF72239D13LL,0xCE7EF2A96A4AF129LL},{0x8E7029BB2D3F5771LL,18446744073709551609UL,18446744073709551609UL,0x8E7029BB2D3F5771LL},{18446744073709551607UL,18446744073709551612UL,0xCE7EF2A96A4AF129LL,0UL},{0x799115BA09F94EB4LL,1UL,18446744073709551607UL,0x8A514227F44FB66CLL},{0x9257DE97EE8C4B05LL,0xF800085869896260LL,18446744073709551611UL,0x8A514227F44FB66CLL},{1UL,1UL,0xBFD33F116E8CFB99LL,0UL},{0x06C165AAE70C30F1LL,18446744073709551612UL,1UL,0x8E7029BB2D3F5771LL},{0x232038BE40E81688LL,18446744073709551609UL,0x5D5EC7E011B55E97LL,0xCE7EF2A96A4AF129LL},{18446744073709551607UL,0UL,0x714BA09A164E62B5LL,0x06C165AAE70C30F1LL}},{{1UL,0x35292FD4AE77DDBALL,0x9457720F84B0F4F2LL,1UL},{6UL,18446744073709551607UL,0x88A3D85AA7F794FCLL,0x4E630971CF717C92LL},{0x5D5EC7E011B55E97LL,0x352A55CCBD95D606LL,0x799115BA09F94EB4LL,0x9A9D0127420EA1BCLL},{0x7E7F6F8F643D9D76LL,6UL,0x7E7F6F8F643D9D76LL,0xF800085869896260LL},{0xF800085869896260LL,0x361030FACFA70DAELL,1UL,1UL},{18446744073709551615UL,0x8A514227F44FB66CLL,1UL,0x361030FACFA70DAELL},{18446744073709551615UL,4UL,1UL,0x232038BE40E81688LL},{18446744073709551615UL,0x9A4575F7F77771FDLL,1UL,0x714BA09A164E62B5LL},{0xF800085869896260LL,18446744073709551615UL,0x7E7F6F8F643D9D76LL,0UL}},{{0x7E7F6F8F643D9D76LL,0UL,0x799115BA09F94EB4LL,18446744073709551609UL},{0x5D5EC7E011B55E97LL,1UL,0x88A3D85AA7F794FCLL,18446744073709551615UL},{6UL,0x714BA09A164E62B5LL,0x9457720F84B0F4F2LL,1UL},{1UL,0x9257DE97EE8C4B05LL,0x714BA09A164E62B5LL,0x88A3D85AA7F794FCLL},{18446744073709551607UL,18446744073709551611UL,0x5D5EC7E011B55E97LL,0x5D5EC7E011B55E97LL},{0x232038BE40E81688LL,0x232038BE40E81688LL,1UL,0xCC6B0C40B387E8D9LL},{0x06C165AAE70C30F1LL,0x4E630971CF717C92LL,0xBFD33F116E8CFB99LL,18446744073709551612UL},{1UL,0x799115BA09F94EB4LL,18446744073709551611UL,0xBFD33F116E8CFB99LL},{0x9257DE97EE8C4B05LL,0x799115BA09F94EB4LL,18446744073709551607UL,18446744073709551612UL}},{{0x799115BA09F94EB4LL,0x4E630971CF717C92LL,0xCE7EF2A96A4AF129LL,0xCC6B0C40B387E8D9LL},{18446744073709551607UL,0x232038BE40E81688LL,18446744073709551609UL,0x5D5EC7E011B55E97LL},{0x8E7029BB2D3F5771LL,18446744073709551611UL,0xB9D72FAF72239D13LL,0x88A3D85AA7F794FCLL},{0x352A55CCBD95D606LL,0x9257DE97EE8C4B05LL,0UL,1UL},{0xB9D72FAF72239D13LL,0x714BA09A164E62B5LL,0x4E630971CF717C92LL,18446744073709551615UL},{0x9A9D0127420EA1BCLL,1UL,18446744073709551612UL,18446744073709551609UL},{0x88A3D85AA7F794FCLL,0UL,18446744073709551615UL,0UL},{0x4E630971CF717C92LL,18446744073709551615UL,4UL,0x714BA09A164E62B5LL},{18446744073709551609UL,0x9A4575F7F77771FDLL,1UL,0x232038BE40E81688LL}}};
static int64_t g_48 = (-4L);
static int8_t g_76[5] = {(-9L),(-9L),(-9L),(-9L),(-9L)};
static volatile int32_t g_85 = 9L;/* VOLATILE GLOBAL g_85 */
static int32_t g_86 = 1L;
static uint32_t g_125 = 0UL;
static const int16_t g_126 = 1L;
static volatile int32_t * volatile * volatile g_160 = &g_13;/* VOLATILE GLOBAL g_160 */
static volatile int32_t * volatile * volatile * volatile g_159[2] = {&g_160,&g_160};
static uint8_t g_163 = 0xB8L;
static uint32_t g_190[3] = {3UL,3UL,3UL};
static volatile int64_t * volatile *g_206 = (void*)0;
static int32_t g_225 = 0x3487E90FL;
static uint16_t g_238 = 0x2E0EL;
static union U0 g_240[6][6][4] = {{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}},{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}},{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}},{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}},{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}},{{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}},{{1UL},{1UL},{1UL},{1UL}}}};
static int8_t g_260 = 0x1BL;
static int16_t g_261[10][7][3] = {{{0xBBFCL,(-5L),0x3E28L},{(-3L),0x8543L,0x3E28L},{0x62F8L,1L,(-1L)},{0x1E0DL,0L,6L},{1L,1L,9L},{0xFA52L,0x8543L,0x3D80L},{0xFA52L,(-5L),0xEFC4L}},{{1L,0xBBFCL,0x4E7EL},{0x1E0DL,0xFA52L,0xEFC4L},{0x62F8L,(-7L),0x3D80L},{(-3L),(-7L),9L},{0xBBFCL,0xFA52L,6L},{0xD60CL,0xBBFCL,(-1L)},{0xBBFCL,(-5L),0x3E28L}},{{(-3L),0x8543L,0x3E28L},{0x62F8L,1L,(-1L)},{0x1E0DL,0L,6L},{1L,1L,9L},{0xFA52L,0x8543L,0x3D80L},{1L,0xE774L,0x8543L},{1L,0xF301L,0xBBFCL}},{{0x25B0L,1L,0x8543L},{0L,0x3F2BL,0x943EL},{0xB6B2L,0x3F2BL,0xFA52L},{0xF301L,1L,(-3L)},{(-1L),0xF301L,0xD60CL},{0xF301L,0xE774L,0L},{0xB6B2L,0xC694L,0L}},{{0L,1L,0xD60CL},{0x25B0L,0xD99BL,(-3L)},{1L,1L,0xFA52L},{1L,0xC694L,0x943EL},{1L,0xE774L,0x8543L},{1L,0xF301L,0xBBFCL},{0x25B0L,1L,0x8543L}},{{0L,0x3F2BL,0x943EL},{0xB6B2L,0x3F2BL,0xFA52L},{0xF301L,1L,(-3L)},{(-1L),0xF301L,0xD60CL},{0xF301L,0xE774L,0L},{0xB6B2L,0xC694L,0L},{0L,1L,0xD60CL}},{{0x25B0L,0xD99BL,(-3L)},{1L,1L,0xFA52L},{1L,0xC694L,0x943EL},{1L,0xE774L,0x8543L},{1L,0xF301L,0xBBFCL},{0x25B0L,1L,0x8543L},{0L,0x3F2BL,0x943EL}},{{0xB6B2L,0x3F2BL,0xFA52L},{0xF301L,1L,(-3L)},{(-1L),0xF301L,0xD60CL},{0xF301L,0xE774L,0L},{0xB6B2L,0xC694L,0L},{0L,1L,0xD60CL},{0x25B0L,0xD99BL,(-3L)}},{{1L,1L,0xFA52L},{1L,0xC694L,0x943EL},{1L,0xE774L,0x8543L},{1L,0xF301L,0xBBFCL},{0x25B0L,1L,0x8543L},{0L,0x3F2BL,0x943EL},{0xB6B2L,0x3F2BL,0xFA52L}},{{0xF301L,1L,(-3L)},{(-1L),0xF301L,0xD60CL},{0xF301L,0xE774L,0L},{0xB6B2L,0xC694L,0L},{0L,1L,0xD60CL},{0x25B0L,0xD99BL,(-3L)},{1L,1L,0xFA52L}}};
static int16_t g_263[7][9][4] = {{{(-2L),0L,0xDDC7L,(-1L)},{1L,0x7A1DL,3L,0x0A27L},{(-1L),1L,0x7A1DL,0xC6F1L},{0x0BE2L,1L,8L,(-2L)},{0xB101L,1L,0L,0x0092L},{(-1L),(-2L),0x2749L,0x2749L},{0L,0L,0xDDC7L,0x7C15L},{1L,(-1L),0x6785L,(-1L)},{0xC0CDL,0x0BE2L,(-9L),0x6785L}},{{1L,0x0BE2L,1L,0L},{0x27A0L,0x62F8L,0xAB42L,3L},{0x78CEL,0x3BB0L,5L,2L},{0x7A1DL,0x2749L,0xC9FBL,0x6785L},{0x8BC2L,0xAB42L,(-1L),0x2749L},{0x3773L,0x0029L,0xA6FDL,1L},{0x3BB0L,0x2E95L,0xC9FBL,1L},{0L,5L,0x8DCBL,0L},{0x78CEL,0x7A1DL,4L,0xDCAFL}},{{(-1L),(-2L),1L,0x5551L},{0x7A1DL,0xB3F4L,0xDDC7L,0L},{4L,0x3BB0L,8L,0xDCAFL},{3L,0x0029L,0L,0x0029L},{0x8BC2L,5L,0x9FADL,0x5CAFL},{0x5C3BL,(-1L),0x8DCBL,1L},{0x2E95L,0L,9L,3L},{0x2E95L,0xAB42L,0x8DCBL,0x5551L},{0x5C3BL,3L,0x9FADL,2L}},{{0x8BC2L,(-2L),0L,(-9L)},{3L,0x62F8L,8L,0x7A1DL},{4L,0x2E95L,0xDDC7L,0xA6FDL},{0x7A1DL,(-1L),1L,0x0029L},{(-1L),0x62F8L,4L,0x2749L},{0x78CEL,0x8BC2L,0x8DCBL,2L},{0L,(-9L),0xC9FBL,0L},{0x3BB0L,0xAB42L,0xA6FDL,(-9L)},{0x3773L,0x7A1DL,(-1L),1L}},{{0x8BC2L,0x27A0L,0xC9FBL,0xC0CDL},{0x7A1DL,5L,5L,0x7A1DL},{0x78CEL,0L,0xAB42L,0xDCAFL},{0x27A0L,0x8BC2L,1L,0x6785L},{0x0029L,0xB3F4L,0x9FADL,0x6785L},{4L,0x8BC2L,0xA6FDL,0xDCAFL},{(-9L),0L,0L,0x7A1DL},{0x3BB0L,5L,2L,0xC0CDL},{0x5C3BL,0x27A0L,0x78CEL,1L}},{{(-1L),0x7A1DL,9L,(-9L)},{0x27A0L,0xAB42L,5L,0L},{0x5C3BL,(-9L),0xDDC7L,2L},{(-2L),0x8BC2L,0L,0x2749L},{0x2749L,0x62F8L,(-1L),0x0029L},{4L,(-1L),2L,0xA6FDL},{0L,0x2E95L,1L,0x7A1DL},{0x2E95L,0x62F8L,(-1L),(-9L)},{0x78CEL,(-2L),0x78CEL,2L}},{{0x0029L,3L,0xC9FBL,0x5551L},{(-2L),0xAB42L,8L,3L},{0x3773L,0L,8L,1L},{(-2L),0xDCAFL,0xC0CDL,(-1L)},{0x8DCBL,0x9F37L,0x0092L,0x8DCBL},{0x0092L,0x8DCBL,0L,0x0A27L},{0x3773L,8L,(-9L),8L},{0x78CEL,0xC9FBL,1L,(-1L)},{1L,0L,(-8L),0x0A27L}}};
static int8_t g_265 = 0xCFL;
static int32_t g_266 = (-8L);
static volatile union U0 g_285 = {0xF3C7403AL};/* VOLATILE GLOBAL g_285 */
static const int32_t *g_309[1][1][6] = {{{(void*)0,(void*)0,&g_225,(void*)0,(void*)0,&g_225}}};
static const int32_t ** volatile g_308[5] = {&g_309[0][0][3],&g_309[0][0][3],&g_309[0][0][3],&g_309[0][0][3],&g_309[0][0][3]};
static uint32_t *g_337[2] = {&g_190[0],&g_190[0]};
static uint64_t g_339 = 0x8D4A9802F6E727C3LL;
static union U0 *g_354 = &g_240[3][5][0];
static union U0 * volatile *g_353 = &g_354;
static uint64_t *g_366 = &g_39[2][2][2];
static union U0 g_375 = {4294967295UL};/* VOLATILE GLOBAL g_375 */
static volatile union U0 g_381 = {1UL};/* VOLATILE GLOBAL g_381 */
static int32_t *g_385 = &g_86;
static int32_t **g_384 = &g_385;
static int32_t ***g_383 = &g_384;
static int64_t g_443 = 1L;
static int8_t *g_553 = (void*)0;
static int8_t **g_552[5][4][7] = {{{(void*)0,&g_553,&g_553,&g_553,&g_553,(void*)0,&g_553},{(void*)0,&g_553,&g_553,&g_553,&g_553,&g_553,(void*)0},{&g_553,(void*)0,&g_553,(void*)0,(void*)0,&g_553,&g_553},{&g_553,&g_553,(void*)0,&g_553,&g_553,&g_553,(void*)0}},{{&g_553,(void*)0,(void*)0,&g_553,&g_553,&g_553,&g_553},{&g_553,&g_553,&g_553,&g_553,&g_553,(void*)0,&g_553},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_553,&g_553},{&g_553,&g_553,&g_553,&g_553,(void*)0,(void*)0,(void*)0}},{{&g_553,(void*)0,&g_553,&g_553,&g_553,&g_553,&g_553},{&g_553,&g_553,&g_553,&g_553,&g_553,&g_553,&g_553},{(void*)0,&g_553,(void*)0,&g_553,&g_553,&g_553,&g_553},{(void*)0,(void*)0,(void*)0,&g_553,&g_553,&g_553,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_553,&g_553,&g_553,&g_553},{(void*)0,(void*)0,&g_553,(void*)0,&g_553,&g_553,(void*)0},{(void*)0,&g_553,(void*)0,&g_553,(void*)0,&g_553,&g_553},{(void*)0,&g_553,(void*)0,(void*)0,&g_553,(void*)0,&g_553}},{{&g_553,&g_553,&g_553,(void*)0,(void*)0,&g_553,(void*)0},{&g_553,&g_553,&g_553,(void*)0,&g_553,(void*)0,&g_553},{&g_553,&g_553,&g_553,&g_553,&g_553,&g_553,&g_553},{(void*)0,&g_553,&g_553,&g_553,&g_553,&g_553,(void*)0}}};
static uint16_t *g_570 = (void*)0;
static uint16_t **g_569 = &g_570;
static volatile union U0 g_627 = {1UL};/* VOLATILE GLOBAL g_627 */
static int64_t ** const  volatile *g_641 = (void*)0;
static int64_t ** const  volatile ** volatile g_640[7][4][9] = {{{(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,(void*)0,&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641}},{{&g_641,(void*)0,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,(void*)0,(void*)0},{&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641,(void*)0}},{{&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641,(void*)0},{&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641}},{{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,(void*)0,&g_641,(void*)0,(void*)0,&g_641,(void*)0,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641},{&g_641,(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641}},{{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,(void*)0,&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641},{&g_641,(void*)0,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,(void*)0,(void*)0}},{{&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641,(void*)0},{&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641,(void*)0,&g_641,&g_641}},{{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641,(void*)0,(void*)0},{&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,(void*)0,(void*)0,(void*)0,(void*)0,&g_641,&g_641,&g_641}}};
static int64_t ** const  volatile ** volatile * volatile g_642[5] = {&g_640[2][1][1],&g_640[2][1][1],&g_640[2][1][1],&g_640[2][1][1],&g_640[2][1][1]};
static uint32_t g_644 = 0xA933919DL;
static int32_t * volatile g_742 = &g_266;/* VOLATILE GLOBAL g_742 */
static const volatile uint32_t g_781 = 0xD95AE71CL;/* VOLATILE GLOBAL g_781 */
static int32_t g_782 = (-1L);
static union U0 g_821[3] = {{0x70DAA265L},{0x70DAA265L},{0x70DAA265L}};
static union U0 g_868[7][2] = {{{4294967295UL},{0x55067634L}},{{0x55067634L},{4294967295UL}},{{0x55067634L},{0x55067634L}},{{4294967295UL},{0x55067634L}},{{0x55067634L},{4294967295UL}},{{0x55067634L},{0x55067634L}},{{4294967295UL},{0x55067634L}}};
static volatile uint32_t g_901 = 0xA17F0322L;/* VOLATILE GLOBAL g_901 */
static volatile uint32_t * volatile g_900 = &g_901;/* VOLATILE GLOBAL g_900 */
static volatile uint32_t * volatile *g_899[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile uint32_t * volatile **g_898[9][8] = {{(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0},{(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0},{(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0,&g_899[2],&g_899[2],(void*)0}};
static volatile uint32_t * volatile *** volatile g_903 = &g_898[7][3];/* VOLATILE GLOBAL g_903 */
static int32_t * const ** const  volatile g_925 = (void*)0;/* VOLATILE GLOBAL g_925 */
static uint32_t *g_1057 = &g_240[3][5][0].f1;
static uint32_t *g_1058 = &g_644;
static uint32_t **g_1115 = &g_1057;
static uint32_t ***g_1114 = &g_1115;
static int32_t g_1117[9][4][2] = {{{0x6EC2CEA7L,0xF34DD0DDL},{0xFBAB4D93L,0x6EC2CEA7L},{9L,9L},{9L,0x6EC2CEA7L}},{{0xFBAB4D93L,0xF34DD0DDL},{0x6EC2CEA7L,0xF34DD0DDL},{0xFBAB4D93L,0x6EC2CEA7L},{9L,9L}},{{9L,0x6EC2CEA7L},{0xFBAB4D93L,0xF34DD0DDL},{0x6EC2CEA7L,0xF34DD0DDL},{0xFBAB4D93L,0x6EC2CEA7L}},{{9L,9L},{9L,0x6EC2CEA7L},{0xFBAB4D93L,0xF34DD0DDL},{0x6EC2CEA7L,0xF34DD0DDL}},{{0xFBAB4D93L,0x6EC2CEA7L},{9L,9L},{9L,0x6EC2CEA7L},{0xFBAB4D93L,0xF34DD0DDL}},{{0x6EC2CEA7L,9L},{(-1L),0xFBAB4D93L},{0x6EC2CEA7L,0x6EC2CEA7L},{0x6EC2CEA7L,0xFBAB4D93L}},{{(-1L),9L},{0xFBAB4D93L,9L},{(-1L),0xFBAB4D93L},{0x6EC2CEA7L,0x6EC2CEA7L}},{{0x6EC2CEA7L,0xFBAB4D93L},{(-1L),9L},{0xFBAB4D93L,9L},{(-1L),0xFBAB4D93L}},{{0x6EC2CEA7L,0x6EC2CEA7L},{0x6EC2CEA7L,0xFBAB4D93L},{(-1L),9L},{0xFBAB4D93L,9L}}};
static uint32_t * const * const *g_1131 = (void*)0;
static volatile uint32_t g_1153 = 0xF69CBCD3L;/* VOLATILE GLOBAL g_1153 */
static uint32_t **g_1175 = &g_337[1];
static uint32_t ***g_1174 = &g_1175;
static uint32_t ***g_1176[5][6][1] = {{{&g_1175},{&g_1175},{&g_1175},{&g_1175},{(void*)0},{&g_1175}},{{&g_1175},{&g_1175},{&g_1175},{&g_1175},{&g_1175},{&g_1175}},{{(void*)0},{&g_1175},{&g_1175},{&g_1175},{&g_1175},{(void*)0}},{{&g_1175},{&g_1175},{&g_1175},{&g_1175},{&g_1175},{&g_1175}},{{&g_1175},{(void*)0},{&g_1175},{&g_1175},{&g_1175},{&g_1175}}};
static int32_t *g_1191 = &g_86;
static uint8_t g_1209 = 0xE5L;
static uint32_t ****g_1243[1] = {&g_1176[1][0][0]};
static uint32_t *****g_1242 = &g_1243[0];
static volatile union U0 g_1285 = {0x4C49F9C2L};/* VOLATILE GLOBAL g_1285 */
static union U0 g_1335 = {1UL};/* VOLATILE GLOBAL g_1335 */
static union U0 **g_1352 = &g_354;
static union U0 ***g_1351 = &g_1352;
static union U0 *g_1358 = (void*)0;
static union U0 ** const g_1357 = &g_1358;
static union U0 ** const *g_1356 = &g_1357;
static volatile uint64_t g_1361 = 0x0B4F8A96134BB432LL;/* VOLATILE GLOBAL g_1361 */
static volatile int16_t g_1399 = 0x7E25L;/* VOLATILE GLOBAL g_1399 */
static volatile int16_t * volatile g_1398 = &g_1399;/* VOLATILE GLOBAL g_1398 */
static volatile int16_t * volatile *g_1397 = &g_1398;
static volatile int16_t * volatile ** volatile g_1396 = &g_1397;/* VOLATILE GLOBAL g_1396 */
static int8_t g_1414 = 0L;
static int64_t g_1429 = 0xA3A001A3104A3473LL;
static volatile int8_t g_1431 = 0xBBL;/* VOLATILE GLOBAL g_1431 */
static uint64_t g_1432 = 18446744073709551615UL;
static union U0 g_1453[10][8] = {{{0UL},{6UL},{0UL},{0xFB0B133FL},{4294967295UL},{0UL},{1UL},{0UL}},{{4294967295UL},{0xFB0B133FL},{0UL},{0xFB0B133FL},{4294967295UL},{0xD32E4356L},{4294967295UL},{2UL}},{{4294967295UL},{0xD32E4356L},{4294967295UL},{2UL},{4294967295UL},{0xD32E4356L},{4294967295UL},{0xFB0B133FL}},{{0UL},{0xFB0B133FL},{4294967295UL},{0UL},{1UL},{0UL},{4294967295UL},{0xFB0B133FL}},{{4294967295UL},{6UL},{0UL},{2UL},{1UL},{0xFB0B133FL},{1UL},{2UL}},{{0UL},{6UL},{0UL},{0xFB0B133FL},{4294967295UL},{0UL},{1UL},{0UL}},{{4294967295UL},{0xFB0B133FL},{0UL},{0xFB0B133FL},{4294967295UL},{0xD32E4356L},{4294967295UL},{2UL}},{{4294967295UL},{0xD32E4356L},{4294967295UL},{2UL},{4294967295UL},{0xD32E4356L},{4294967295UL},{0xFB0B133FL}},{{0UL},{0xFB0B133FL},{4294967295UL},{0UL},{1UL},{0UL},{4294967295UL},{0xFB0B133FL}},{{4294967295UL},{6UL},{0UL},{2UL},{1UL},{0xFB0B133FL},{1UL},{2UL}}};
static volatile union U0 g_1476[8][6][5] = {{{{0x100F1B4CL},{4294967295UL},{0UL},{0x9FF1CD71L},{0x7520E9B0L}},{{0x50022CDEL},{0xB7B5C1C3L},{0x3A5136AAL},{1UL},{1UL}},{{0x1E3A23E4L},{0x100F1B4CL},{0x1E3A23E4L},{0x98F384FCL},{0x80D52304L}},{{0xB7B5C1C3L},{0x2533FDB0L},{0UL},{8UL},{4294967290UL}},{{1UL},{0xEE0CD71DL},{1UL},{7UL},{0x18DD381CL}},{{0UL},{1UL},{0UL},{4294967290UL},{4294967295UL}}},{{{0xE0EC6EF6L},{0UL},{0x1E3A23E4L},{4294967295UL},{1UL}},{{4294967295UL},{1UL},{0x3A5136AAL},{4294967290UL},{0xA7037573L}},{{0xB6AEF16BL},{1UL},{0UL},{4UL},{4294967295UL}},{{4294967295UL},{0UL},{4UL},{0x50022CDEL},{0xECA8C061L}},{{0xD198E021L},{0xB6AEF16BL},{0xE0EC6EF6L},{0x98F384FCL},{1UL}},{{0xAEF557C5L},{0UL},{0x695FE93CL},{0x3ABEE2E5L},{0x0A235185L}}},{{{0xD3147F5EL},{0UL},{0x5CFC9302L},{0x93F0F263L},{4294967291UL}},{{0x2533FDB0L},{0xCF9F87D7L},{0xB7B5C1C3L},{0xCF9F87D7L},{0x2533FDB0L}},{{0xA304DE5DL},{0UL},{4294967291UL},{0x5CFC9302L},{0xB6AEF16BL}},{{4294967290UL},{0xE0967EABL},{0x955D6033L},{3UL},{4294967295UL}},{{1UL},{0x0C7EA507L},{0x100F1B4CL},{0UL},{0xB6AEF16BL}},{{0xE5B79E63L},{3UL},{0x1FBC2A0CL},{0xE5B79E63L},{0x2533FDB0L}}},{{{0xB6AEF16BL},{0UL},{0x0A751982L},{1UL},{4294967291UL}},{{0x88129A5CL},{0x2533FDB0L},{0x7761ED67L},{1UL},{0x0A235185L}},{{0x0A751982L},{0x61F63D60L},{0UL},{0x514F3A68L},{1UL}},{{0x56135B2BL},{0x3A5136AAL},{0xE0967EABL},{0x50AD67D4L},{0xECA8C061L}},{{0x61F63D60L},{0xD3147F5EL},{2UL},{0UL},{4294967288UL}},{{4294967295UL},{0xD4AF490DL},{0xAEF557C5L},{0x1FBC2A0CL},{4294967287UL}}},{{{0UL},{0x514F3A68L},{1UL},{4294967288UL},{1UL}},{{4294967289UL},{4294967289UL},{0xA7037573L},{0xCF9F87D7L},{1UL}},{{4294967291UL},{0x7520E9B0L},{0UL},{0xF2A355ACL},{0xD198E021L}},{{0x10190E9BL},{0xAED40F0CL},{0xBF15BC41L},{4294967290UL},{0x955D6033L}},{{0xBFDCF762L},{0x7520E9B0L},{0x48591715L},{0x98F384FCL},{0x7520E9B0L}},{{0x33F9C75CL},{4294967289UL},{0x1FBC2A0CL},{4294967295UL},{0UL}}},{{{0x0C7EA507L},{0x514F3A68L},{0x18199809L},{0xBFDCF762L},{0xF2A355ACL}},{{0xCF9F87D7L},{0xD4AF490DL},{0x50022CDEL},{0x0A235185L},{0x50AD67D4L}},{{0xC9858009L},{0xD3147F5EL},{4294967291UL},{0UL},{0x0C7EA507L}},{{4294967287UL},{0x3A5136AAL},{0xE5B79E63L},{4UL},{0xBF15BC41L}},{{0xBFDCF762L},{0x61F63D60L},{1UL},{0UL},{1UL}},{{4294967295UL},{0x2533FDB0L},{0x695FE93CL},{0x3A5136AAL},{4294967289UL}}},{{{0x1E3A23E4L},{0UL},{0UL},{0x1E3A23E4L},{0xC9858009L}},{{4294967289UL},{3UL},{4294967295UL},{0UL},{0x50AD67D4L}},{{4294967293UL},{0x0C7EA507L},{0x7672542AL},{1UL},{0x93F0F263L}},{{0UL},{0xE0967EABL},{0xF94671A2L},{0UL},{1UL}},{{0x61F63D60L},{0UL},{0x18DD381CL},{0x1E3A23E4L},{0x7520E9B0L}},{{0xE0967EABL},{0xCF9F87D7L},{4294967288UL},{0x3A5136AAL},{4UL}}},{{{0x98F384FCL},{0UL},{0xC9858009L},{0UL},{0xA304DE5DL}},{{0x88129A5CL},{0UL},{4294967288UL},{4UL},{1UL}},{{0x7672542AL},{0xB6AEF16BL},{0xBD960DACL},{0UL},{4294967295UL}},{{0x50AD67D4L},{0xECA8C061L},{0xF94671A2L},{0x0A235185L},{0x33F9C75CL}},{{1UL},{0x93F0F263L},{0xE1333B46L},{0xBFDCF762L},{4294967288UL}},{{0x3ABEE2E5L},{0x8B62DF1CL},{4294967295UL},{4294967295UL},{0xAED40F0CL}}}};
static volatile int32_t g_1507 = 0L;/* VOLATILE GLOBAL g_1507 */
static uint32_t g_1596 = 0x95FEC12DL;
static const volatile uint32_t g_1628 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1628 */
static union U0 g_1631 = {0x9FD68A30L};/* VOLATILE GLOBAL g_1631 */
static volatile uint8_t g_1655 = 6UL;/* VOLATILE GLOBAL g_1655 */
static volatile uint8_t *g_1654 = &g_1655;
static volatile uint8_t * volatile *g_1653[4] = {&g_1654,&g_1654,&g_1654,&g_1654};
static volatile uint16_t g_1668[2][1][10] = {{{0x92A7L,65535UL,0xDE5AL,65535UL,65535UL,65535UL,0xDE5AL,65535UL,0x92A7L,0x92A7L}},{{2UL,0x059BL,0x06A1L,65535UL,65535UL,0x06A1L,0x059BL,2UL,0x06A1L,2UL}}};
static int32_t g_1688 = 0x256D4258L;
static int8_t ***g_1727 = &g_552[3][2][4];
static int8_t **** volatile g_1726 = &g_1727;/* VOLATILE GLOBAL g_1726 */
static union U0 g_1734[4] = {{1UL},{1UL},{1UL},{1UL}};
static const uint64_t g_1744 = 1UL;
static union U0 g_1754 = {4294967295UL};/* VOLATILE GLOBAL g_1754 */
static volatile int32_t g_1777 = (-1L);/* VOLATILE GLOBAL g_1777 */
static volatile int32_t *g_1870 = &g_1777;
static volatile int32_t ** volatile g_1871 = &g_13;/* VOLATILE GLOBAL g_1871 */
static union U0 ** volatile g_1875 = &g_354;/* VOLATILE GLOBAL g_1875 */
static int32_t g_2031 = (-6L);
static int32_t *g_2067 = &g_1688;
static uint32_t * const **g_2112[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const volatile union U0 g_2125 = {4294967289UL};/* VOLATILE GLOBAL g_2125 */
static uint32_t g_2148[1] = {0xAFF3D751L};
static int64_t *g_2256 = &g_1429;
static int64_t **g_2255 = &g_2256;
static volatile int32_t * volatile * volatile g_2262 = &g_13;/* VOLATILE GLOBAL g_2262 */
static int32_t **g_2309 = &g_385;
static union U0 g_2320 = {1UL};/* VOLATILE GLOBAL g_2320 */
static volatile int8_t g_2378[6][5][7] = {{{(-2L),1L,0x5CL,1L,(-2L),(-6L),0x50L},{0L,0L,9L,0xC6L,0x52L,0xC6L,8L},{1L,(-6L),(-3L),7L,1L,(-2L),3L},{0L,0xC6L,0x95L,0xF9L,0x95L,0xC6L,0L},{(-2L),(-1L),0x85L,0x50L,1L,(-1L),0x5CL}},{{0L,0xF1L,(-1L),(-5L),0L,0xAFL,0xA2L},{(-3L),3L,0x85L,0x41L,(-1L),0x41L,0x85L},{0L,(-6L),0x95L,0x16L,0x33L,0x21L,2L},{(-1L),0x04L,(-3L),0x85L,0x5CL,3L,(-6L)},{1L,0xC6L,9L,0x13L,0x33L,0x86L,0x33L}},{{3L,0x5CL,0x5CL,3L,(-1L),(-7L),(-3L)},{0x52L,0x21L,0xF2L,0x42L,0L,0L,(-1L)},{0x85L,(-3L),0x04L,(-1L),1L,1L,(-3L)},{(-1L),1L,0L,(-6L),0x95L,0x16L,0x33L},{0x41L,0x85L,3L,(-3L),1L,3L,(-6L)}},{{(-1L),1L,0xD6L,0x9EL,0x52L,0xBBL,2L},{0x50L,0x85L,(-1L),(-2L),(-2L),(-1L),0x85L},{0L,1L,0xD8L,0xBBL,0x0EL,0L,0xA2L},{7L,(-3L),(-6L),1L,(-7L),0x71L,0x5CL},{0xD8L,0x21L,0xA2L,0xBBL,0xD6L,0xF1L,0L}},{{1L,0x5CL,1L,(-2L),(-6L),0x50L,3L},{0xDEL,0xC6L,0x33L,0x9EL,0xD8L,1L,0x33L},{0xB5L,0x41L,(-3L),0x50L,(-7L),0x85L,0x85L},{9L,0L,1L,0L,9L,1L,(-1L)},{0x71L,(-6L),3L,0x5CL,0x85L,(-3L),0x04L}},{{0xA2L,1L,0x52L,0x14L,0L,0x21L,8L},{0x71L,0x5CL,(-3L),3L,(-3L),0x5CL,0x71L},{9L,0x9EL,0x49L,(-5L),0x0EL,0xC6L,1L},{0xB5L,0x91L,7L,(-2L),3L,0x04L,(-6L)},{0x52L,0xF1L,0x49L,(-6L),0L,(-6L),0x49L}}};
static const int32_t ** volatile g_2434 = &g_309[0][0][5];/* VOLATILE GLOBAL g_2434 */
static int32_t ** volatile g_2448[4] = {&g_29,&g_29,&g_29,&g_29};
static int32_t ** volatile g_2449 = (void*)0;/* VOLATILE GLOBAL g_2449 */
static int32_t ** volatile g_2450 = &g_1191;/* VOLATILE GLOBAL g_2450 */
static volatile union U0 g_2453 = {4UL};/* VOLATILE GLOBAL g_2453 */
static int32_t * const g_2457 = (void*)0;
static int32_t * const *g_2456 = &g_2457;
static int32_t * const *g_2458 = &g_1191;
static uint16_t g_2483 = 65526UL;
static union U0 g_2491 = {0xC298B309L};/* VOLATILE GLOBAL g_2491 */
static union U0 g_2515 = {0xABDAC233L};/* VOLATILE GLOBAL g_2515 */
static volatile int16_t * volatile **g_2545 = (void*)0;
static volatile int16_t * volatile *** volatile g_2544 = &g_2545;/* VOLATILE GLOBAL g_2544 */
static union U0 g_2554 = {0UL};/* VOLATILE GLOBAL g_2554 */
static int8_t * const *g_2623 = &g_553;
static int8_t * const **g_2622 = &g_2623;
static uint32_t g_2682 = 0x229A5A3BL;
static uint8_t *g_2741 = (void*)0;
static uint8_t **g_2740[2] = {&g_2741,&g_2741};
static uint8_t *** volatile g_2739 = &g_2740[0];/* VOLATILE GLOBAL g_2739 */
static const uint32_t g_2772 = 0xB8E342A3L;
static int32_t ** volatile g_2817 = &g_385;/* VOLATILE GLOBAL g_2817 */
static volatile union U0 g_2847[3] = {{0xEC709742L},{0xEC709742L},{0xEC709742L}};
static volatile int32_t * volatile * volatile g_2893 = &g_13;/* VOLATILE GLOBAL g_2893 */
static union U0 g_2898 = {1UL};/* VOLATILE GLOBAL g_2898 */
static uint16_t g_3015 = 0x3634L;


/* --- FORWARD DECLARATIONS --- */
static const int16_t  func_1(void);
static uint64_t  func_23(int32_t * p_24, int32_t * const  p_25, int32_t * p_26, uint32_t  p_27, int32_t  p_28);
static uint32_t  func_31(int32_t * const * p_32, int32_t * p_33, int32_t ** p_34, int32_t  p_35, int32_t * p_36);
static int32_t ** func_37(int32_t * p_38);
static int64_t  func_50(int16_t  p_51, int32_t * p_52, uint16_t  p_53, uint8_t  p_54, const uint32_t  p_55);
static const uint32_t  func_71(uint16_t  p_72, int32_t * p_73, int32_t  p_74);
static uint8_t  func_77(int64_t  p_78, int8_t  p_79, int64_t  p_80, int32_t ** p_81);
static int64_t  func_82(const int32_t * p_83);
static uint32_t  func_93(int32_t * p_94, uint8_t  p_95, const int32_t * p_96, int32_t ** p_97, int32_t ** p_98);
static int32_t  func_100(int32_t * p_101, uint8_t  p_102);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_22 g_29 g_30 g_1396 g_1397 g_1398 g_1399 g_385 g_1191 g_39 g_383 g_384 g_86 g_1870 g_225 g_1174 g_2309 g_1335.f1 g_2434 g_1351 g_2450 g_2453 g_1117 g_366 g_1209 g_1175 g_337 g_900 g_901 g_2739 g_2740 g_263 g_2256 g_1429 g_160 g_2893 g_1688 g_2898 g_2622 g_2623 g_1777 g_2458 g_3015 g_2255 g_190 g_163
 * writes: g_30 g_48 g_86 g_163 g_1431 g_1507 g_261 g_225 g_265 g_1777 g_1335.f1 g_266 g_2031 g_76 g_1175 g_1432 g_309 g_1352 g_1191 g_1351 g_2456 g_2458 g_39 g_1209 g_190 g_13 g_1688 g_2740 g_385 g_443 g_1429 g_3015
 */
static const int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_4 = (-1L);
    uint32_t l_5 = 0x162C9CC1L;
    uint32_t l_2769 = 0xFF64B500L;
    uint32_t l_2792 = 0xCCD4F23DL;
    union U0 *l_2816 = (void*)0;
    uint32_t **l_2824 = &g_1058;
    int8_t * const ** const *l_2848 = &g_2622;
    int32_t l_2868 = 1L;
    uint32_t l_2869 = 18446744073709551606UL;
    int32_t l_2921 = 0xF335B8ABL;
    int32_t l_2922 = (-7L);
    uint64_t l_2982 = 1UL;
    int32_t l_3012 = (-1L);
    int16_t l_3013 = 0x2ED0L;
    int32_t l_3039 = (-3L);
    int8_t l_3041 = (-4L);
    if ((l_5 = (safe_mod_func_uint64_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */(l_4, 0xEDC7555B7CEFA9D1LL))))
    { /* block id: 2 */
        int32_t *l_8 = &l_4;
        int8_t l_2791 = 0x5FL;
        int32_t l_2795 = 3L;
        int32_t l_2796 = 0x4776F9E7L;
        uint32_t l_2811 = 0x4691EF41L;
        uint32_t ***l_2835 = &g_1115;
        const int8_t * const l_2852[7][10] = {{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260},{&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260,&g_76[0],&g_260}};
        const int8_t * const *l_2851 = &l_2852[4][7];
        const int8_t * const **l_2850 = &l_2851;
        const int8_t * const ***l_2849 = &l_2850;
        int i, j;
        if ((safe_div_func_int8_t_s_s_unsafe_macro/*1*//* ___SAFE__OP */((((*l_8) ^= 1L) > (safe_mul_func_uint16_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_u((g_13 == l_8), 60)) , ((((*g_366) = ((safe_mul_func_uint8_t_u_u_unsafe_macro/*4*//* ___SAFE__OP */((1L && (safe_sub_func_int16_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */(l_5, (safe_lshift_func_uint8_t_u_s_unsafe_macro/*6*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*7*//* ___SAFE__OP */(((g_22 < 0x4AL) || func_23(g_29, l_8, &g_30, g_30, l_5)), 8UL)), 2))))), l_5)) , 2UL)) && 0L) <= 0x658DL)), l_2769))), 0x19L)))
        { /* block id: 1165 */
            uint64_t l_2776 = 0UL;
            uint8_t l_2777[8];
            int32_t l_2804 = 6L;
            uint8_t *l_2870 = &l_2777[4];
            int i;
            for (i = 0; i < 8; i++)
                l_2777[i] = 1UL;
            for (g_1209 = 0; (g_1209 <= 1); g_1209 += 1)
            { /* block id: 1168 */
                const uint32_t *l_2771[8] = {&g_2772,&g_2772,&g_2772,&g_2772,&g_2772,&g_2772,&g_2772,&g_2772};
                const uint32_t **l_2770 = &l_2771[4];
                int32_t l_2794 = 0xBBBFFE47L;
                int32_t l_2809[9][8][3] = {{{4L,0x7AF3EF03L,4L},{4L,0x2BA82DF5L,1L},{(-9L),(-9L),0x51133A4DL},{(-1L),4L,0x8F12B490L},{0xB3B59E56L,(-1L),5L},{1L,0x1780C6A4L,0x2BA82DF5L},{0x624845C5L,0xB3B59E56L,5L},{0xF3FD8282L,0x71082345L,0x8F12B490L}},{{0x9D597843L,0xAF9049F8L,0x51133A4DL},{(-1L),1L,1L},{0L,0xF5D8D3FFL,4L},{(-1L),1L,0x20D1A133L},{1L,0xB35EE080L,(-10L)},{0x71082345L,1L,(-8L)},{1L,0x1C270AF8L,(-1L)},{0x1780C6A4L,(-1L),(-8L)}},{{5L,(-1L),(-1L)},{0x21257416L,0x71082345L,1L},{0L,0x71082345L,0x64849010L},{1L,(-1L),7L},{9L,(-1L),8L},{0x1C270AF8L,7L,5L},{0x0A76F957L,0x8F12B490L,0x7AF3EF03L},{0x2BA82DF5L,7L,7L}},{{0x64849010L,0xFC5B52FCL,0x9D597843L},{(-10L),1L,1L},{1L,(-1L),1L},{0x9D597843L,5L,(-9L)},{1L,0x352BE63CL,0x5732C6AAL},{4L,8L,(-1L)},{1L,(-1L),0xF3FD8282L},{4L,0xB8EE73EEL,(-1L)}},{{1L,0L,0x20D1A133L},{0x9D597843L,0xF3FD8282L,0x91C2DD4FL},{1L,0xAF9049F8L,0L},{(-10L),0xA401E36FL,2L},{0x64849010L,0x7AF3EF03L,(-10L)},{0x2BA82DF5L,1L,6L},{0x0A76F957L,6L,6L},{0x1C270AF8L,(-1L),4L}},{{9L,0x624845C5L,0x352BE63CL},{1L,4L,1L},{0L,0x2BA82DF5L,1L},{0x21257416L,0xB35EE080L,0x352BE63CL},{5L,(-1L),4L},{0x1780C6A4L,(-9L),6L},{2L,0xE34129FEL,6L},{0x352BE63CL,9L,(-10L)}},{{(-1L),0xFA38EB52L,2L},{0xB8EE73EEL,0xF38F75F5L,0L},{(-1L),0x91C2DD4FL,0x91C2DD4FL},{0xF38F75F5L,4L,0x20D1A133L},{0xFEEAED3EL,0xB3B59E56L,(-1L)},{0L,0xF5D8D3FFL,0xF3FD8282L},{1L,0L,(-1L)},{0L,0xF5D8D3FFL,0x5732C6AAL}},{{8L,0xB3B59E56L,(-9L)},{9L,4L,1L},{0xF3FD8282L,0x91C2DD4FL,1L},{1L,0xF38F75F5L,0x9D597843L},{0L,0xFA38EB52L,7L},{0x20D1A133L,9L,0x7AF3EF03L},{0xFC5B52FCL,0xE34129FEL,5L},{0x91C2DD4FL,(-9L),8L}},{{(-1L),(-1L),7L},{(-1L),0xB35EE080L,0x64849010L},{0xB3B59E56L,0x2BA82DF5L,1L},{0xB3B59E56L,4L,(-1L)},{(-1L),0x624845C5L,(-8L)},{(-1L),(-1L),(-1L)},{0x91C2DD4FL,6L,1L},{0xFC5B52FCL,1L,6L}}};
                uint8_t **l_2814 = &g_2741;
                uint32_t l_2840[3];
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_2840[i] = 0x9F569350L;
            }
            (*g_29) = ((***g_383) = ((*l_8) , (((safe_lshift_func_int32_t_s_s_unsafe_macro/*8*//* ___SAFE__OP */((*l_8), (((*l_8) == (((*l_2870) = (~(safe_add_func_uint16_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */(0x46E7L, ((((*l_8) & 255UL) && ((5L >= (safe_div_func_int16_t_s_s_unsafe_macro/*10*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*11*//* ___SAFE__OP */((l_2868 = ((**g_1175) = (((safe_mul_func_uint64_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */((*g_366), (*g_366))) , 0x90E2L) , l_2776))), (*l_8))), l_2869))) != 0x59CC176CA2731A63LL)) | l_5))))) >= l_2869)) | (*g_900)))) , (**g_2309)) ^ (-6L))));
        }
        else
        { /* block id: 1228 */
            const int32_t l_2892[6][2] = {{(-7L),(-7L)},{(-7L),(-7L)},{(-7L),(-7L)},{(-7L),(-7L)},{(-7L),(-7L)},{(-7L),(-7L)}};
            int i, j;
            (*g_2893) = ((safe_mod_func_uint64_t_u_u_unsafe_macro/*13*//* ___SAFE__OP */((l_2792 | ((*l_8) && (((safe_lshift_func_int8_t_s_u_unsafe_macro/*14*//* ___SAFE__OP */(0L, 3)) != (*l_8)) > (4294967295UL < ((safe_sub_func_uint8_t_u_u_unsafe_macro/*15*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*16*//* ___SAFE__OP */((((*g_2739) != &g_2741) & ((safe_lshift_func_uint64_t_u_u(0x36F4E9507573406FLL, 51)) >= (((safe_rshift_func_uint64_t_u_u_unsafe_macro/*18*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s_unsafe_macro/*20*//* ___SAFE__OP */((~(-6L)), l_2892[1][0])) <= l_2892[1][0]), 0xFB00C059L)) ^ g_263[6][3][0]), (*g_366))) || (-1L)) , l_2892[1][0]))), l_2892[1][0])), l_2792)) == (*l_8)))))), (*g_2256))) , (*g_160));
        }
    }
    else
    { /* block id: 1231 */
        uint64_t l_2899 = 0UL;
        int32_t l_2930 = 0xA0DE0AA0L;
        int8_t ***l_3004 = (void*)0;
        uint16_t l_3009 = 65534UL;
        union U0 ***l_3038 = (void*)0;
        int32_t l_3040 = (-3L);
        uint32_t l_3042 = 6UL;
        for (g_1688 = 0; (g_1688 >= (-3)); --g_1688)
        { /* block id: 1234 */
            int32_t l_2896 = 0x93A52479L;
            uint8_t *l_2967 = (void*)0;
            int32_t l_2980 = 0x5037C3EDL;
            int8_t ***l_3006 = &g_552[1][3][4];
            for (l_4 = 0; (l_4 <= 1); l_4 += 1)
            { /* block id: 1237 */
                uint16_t ***l_2917 = &g_569;
                int32_t l_2920 = 0L;
                uint16_t *l_2981[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_2981[i] = &g_238;
                if (l_2896)
                { /* block id: 1238 */
                    union U0 ****l_2908 = &g_1351;
                    int32_t l_2918 = (-9L);
                    int64_t l_2939 = 0x87DEB37FBDF51DE6LL;
                    int i;
                    if ((!(g_2898 , l_2899)))
                    { /* block id: 1239 */
                        union U0 * const *l_2911[10][2][4] = {{{&g_354,&g_1358,&g_1358,&g_354},{&g_1358,&g_354,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_354,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_354,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_354,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_354,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_354,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_354,&g_1358}},{{&g_1358,&g_1358,&g_1358,&g_1358},{&g_1358,&g_1358,&g_1358,&g_1358}}};
                        union U0 * const **l_2910[9] = {&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0],&l_2911[9][1][0]};
                        union U0 * const ***l_2909 = &l_2910[0];
                        int32_t l_2912 = 0xBBD672F8L;
                        int i, j, k;
                        (***g_383) = ((((safe_sub_func_uint32_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */(((*g_2622) != ((safe_mod_func_uint32_t_u_u_unsafe_macro/*22*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*23*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */(((l_2908 == l_2909) && (*g_1398)), l_2912)), g_263[5][5][0])), (safe_add_func_int8_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */(l_2899, (safe_mul_func_int64_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */(((l_2912 , l_2917) != (void*)0), 0x22A4C5CAF3987DF6LL)))))) , (void*)0)), l_4)) <= l_2918) | l_2918) , (*g_1870));
                        (**g_384) = (+(l_2896 , l_2912));
                        if (l_2920)
                            continue;
                    }
                    else
                    { /* block id: 1243 */
                        int32_t *l_2923 = (void*)0;
                        int32_t *l_2924 = &l_2922;
                        int32_t *l_2925 = (void*)0;
                        int32_t *l_2926 = &l_2922;
                        int32_t *l_2927 = (void*)0;
                        int32_t *l_2928 = &l_2920;
                        int32_t *l_2929 = &g_86;
                        int32_t *l_2931 = &l_2930;
                        int32_t l_2932 = (-4L);
                        int32_t *l_2933 = &l_2921;
                        int32_t *l_2934 = &g_86;
                        int32_t *l_2935 = &l_2921;
                        int32_t *l_2936 = &g_2031;
                        int32_t *l_2937 = (void*)0;
                        int32_t *l_2938[7];
                        uint32_t l_2940 = 0xD94AF1E7L;
                        int i;
                        for (i = 0; i < 7; i++)
                            l_2938[i] = &g_1117[3][1][1];
                        l_2940++;
                        (*l_2924) &= 1L;
                    }
                }
                else
                { /* block id: 1247 */
                    uint8_t ***l_2946 = &g_2740[0];
                    int32_t *l_2953 = &l_2896;
                    if (((*g_29) = (safe_div_func_int64_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */((((safe_unary_minus_func_int8_t_s_unsafe_macro/*28*//* ___SAFE__OP */(l_2930)) > ((((*l_2946) = (*g_2739)) != (void*)0) , l_5)) < (((0x6EL ^ (l_2896 == 0x528BD31E24CD956ALL)) >= (!(0L && ((safe_add_func_int32_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */(((**g_2458) = (*g_1191)), l_2899)) <= 0x6CC8L)))) && 0UL)), l_2896))))
                    { /* block id: 1251 */
                        l_2930 &= (*g_385);
                        return l_2920;
                    }
                    else
                    { /* block id: 1254 */
                        int16_t l_2952[1][10][8] = {{{0x417EL,0x417EL,(-1L),0x417EL,0x417EL,(-1L),0x417EL,0x417EL},{(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL},{0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L)},{0x417EL,0x417EL,(-1L),0x417EL,0x417EL,(-1L),0x417EL,0x417EL},{(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL},{0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L)},{0x417EL,0x417EL,(-1L),0x417EL,0x417EL,(-1L),0x417EL,0x417EL},{(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL},{0x417EL,(-4L),(-4L),0x417EL,(-4L),(-4L),0x417EL,(-4L)},{0x417EL,0x417EL,(-1L),0x417EL,0x417EL,(-1L),0x417EL,0x417EL}}};
                        int i, j, k;
                        if (l_2952[0][8][5])
                            break;
                        (*g_384) = l_2953;
                    }
                    (*l_2953) |= (safe_mod_func_int32_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */(l_2899, (~((safe_sub_func_int32_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */(l_5, 4294967294UL)) && l_2920))));
                    return l_2920;
                }
                if (((safe_add_func_int16_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */((0x35ABF46CE3D56BA5LL == ((*g_366) = (safe_add_func_uint16_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */(65535UL, (((**g_384) = ((safe_add_func_uint16_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*35*//* ___SAFE__OP */(((void*)0 != l_2967), 5)), l_2899)) , (safe_rshift_func_uint16_t_u_s_unsafe_macro/*36*//* ___SAFE__OP */((l_2930 = ((**g_1397) ^ (safe_add_func_int16_t_s_s_unsafe_macro/*37*//* ___SAFE__OP */((((-9L) < (l_2896 >= (safe_rshift_func_uint64_t_u_s_unsafe_macro/*38*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*39*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */((l_2980 &= (safe_div_func_int32_t_s_s_unsafe_macro/*41*//* ___SAFE__OP */(l_2899, 1UL))), l_2896)) , l_2920), l_2920)), 35)))) && l_2899), 0xEAB2L)))), l_2920)))) , l_2982))))), l_2921)) < 65535UL))
                { /* block id: 1265 */
                    uint32_t l_2985 = 0xEB39F1E4L;
                    for (g_443 = 0; (g_443 < (-27)); g_443 = safe_sub_func_int32_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */(g_443, 9))
                    { /* block id: 1268 */
                        uint32_t l_2988[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_2988[i] = 0x00C248FDL;
                        l_2985++;
                        (*g_1191) |= l_2988[1];
                    }
                    return l_2985;
                }
                else
                { /* block id: 1273 */
                    int8_t l_2991 = 0x72L;
                    int8_t ****l_3005[10][2][1] = {{{&l_3004},{(void*)0}},{{(void*)0},{&l_3004}},{{(void*)0},{(void*)0}},{{&l_3004},{(void*)0}},{{(void*)0},{&l_3004}},{{(void*)0},{(void*)0}},{{&l_3004},{(void*)0}},{{(void*)0},{&l_3004}},{{(void*)0},{(void*)0}},{{&l_3004},{(void*)0}}};
                    int8_t l_3010 = 1L;
                    uint8_t *l_3011 = &g_1209;
                    int32_t *l_3014[6][9] = {{&g_86,&l_2922,&l_2920,&g_2031,(void*)0,(void*)0,&g_2031,&l_2920,&l_2922},{&l_3012,(void*)0,&l_2980,(void*)0,(void*)0,&g_2031,(void*)0,&l_2980,&l_2980},{&l_2922,&g_1117[2][0][0],&g_2031,(void*)0,&g_2031,&g_1117[2][0][0],&l_2922,&g_2031,&l_2980},{&l_2920,(void*)0,(void*)0,&l_3012,&g_2031,(void*)0,(void*)0,(void*)0,&g_2031},{&l_2920,&g_2031,&g_2031,&l_2920,(void*)0,(void*)0,&l_3012,&g_2031,(void*)0},{&l_2922,&g_2031,&l_2980,&l_3012,&g_1117[2][0][0],&g_1117[2][0][0],&l_3012,&l_2980,&g_2031}};
                    int i, j, k;
                    (*g_29) &= (((l_2980 == (-1L)) && (safe_mod_func_uint32_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((l_2896 = l_2991), l_2930))) != (safe_mul_func_uint8_t_u_u_unsafe_macro/*44*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*45*//* ___SAFE__OP */(((((((*l_3011) = ((safe_mul_func_uint8_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */((((((*g_2256) = ((safe_rshift_func_int64_t_s_s_unsafe_macro/*47*//* ___SAFE__OP */((*g_2256), (safe_sub_func_uint16_t_u_u_unsafe_macro/*48*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */(((l_3006 = l_3004) != (l_2899 , (*l_2848))), ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*50*//* ___SAFE__OP */((((((*g_385) = (((18446744073709551611UL ^ (-1L)) , (*g_385)) && l_2991)) , l_5) , l_3009) && l_2980), 53)) , (**g_1397)))) != l_2991), l_3010)))) < l_2869)) || l_2920) && 0x1B198D74L) & 0x989CE4D6L), l_2991)) == 0L)) & l_3009) ^ l_3012) == l_3009) , l_2922), 0)), l_2980)));
                    g_3015++;
                }
            }
            if (l_2921)
                break;
        }
        (*g_1191) = ((((safe_sub_func_int8_t_s_s_unsafe_macro/*51*//* ___SAFE__OP */(((((((*g_366) = l_4) < (safe_add_func_uint8_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */(l_3009, (safe_lshift_func_uint8_t_u_u_unsafe_macro/*53*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u_unsafe_macro/*54*//* ___SAFE__OP */((((**g_2255) = 1L) != ((safe_div_func_int64_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */(l_2982, (safe_mod_func_uint16_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */((((safe_mul_func_uint16_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */(((l_3040 = ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*58*//* ___SAFE__OP */((((1L ^ (safe_lshift_func_int16_t_s_s_unsafe_macro/*59*//* ___SAFE__OP */((((0xA083L | (((**g_1175) == (l_2930 = (safe_mul_func_uint16_t_u_u_unsafe_macro/*60*//* ___SAFE__OP */((l_3009 || 7UL), l_2921)))) == l_2899)) , l_3038) != l_3038), 10))) >= l_2899) , l_3039), l_2899)) > 0x378FD0F05DE709DALL)) | (**g_1397)), l_2899)) || l_5) , 0xD8DAL), g_163)))) != l_3041)), 2)), 4))))) <= l_4) , 0xC5E859C0L) , l_2899), l_2922)) > l_3042) && l_5) <= l_3042);
    }
    return l_3013;
}


/* ------------------------------------------ */
/* 
 * reads : g_30 g_22 g_29 g_1396 g_1397 g_1398 g_1399 g_385 g_1191 g_39 g_383 g_384 g_86 g_1870 g_225 g_1174 g_2309 g_1335.f1 g_2434 g_1351 g_2450 g_2453 g_1117
 * writes: g_30 g_48 g_86 g_163 g_1431 g_1507 g_261 g_225 g_265 g_1777 g_1335.f1 g_266 g_2031 g_76 g_1175 g_1432 g_309 g_1352 g_1191 g_1351 g_2456 g_2458
 */
static uint64_t  func_23(int32_t * p_24, int32_t * const  p_25, int32_t * p_26, uint32_t  p_27, int32_t  p_28)
{ /* block id: 4 */
    int32_t *l_2430 = &g_1117[6][1][1];
    int32_t * const *l_2455 = (void*)0;
    int32_t * const **l_2454[7] = {&l_2455,&l_2455,&l_2455,&l_2455,&l_2455,&l_2455,&l_2455};
    int64_t **l_2461 = &g_2256;
    int8_t ****l_2466 = &g_1727;
    int8_t *****l_2467 = &l_2466;
    int8_t ****l_2472 = &g_1727;
    int32_t l_2473 = 0x0A391B8CL;
    uint16_t l_2474[3];
    uint8_t *l_2475[4][5] = {{(void*)0,&g_1209,&g_163,&g_163,&g_1209},{&g_1209,&g_163,&g_163,&g_1209,&g_163},{&g_1209,&g_1209,(void*)0,&g_1209,&g_1209},{(void*)0,&g_1209,(void*)0,&g_163,&g_1209}};
    int64_t ***l_2478 = &g_2255;
    int64_t ****l_2477 = &l_2478;
    int64_t *****l_2476 = &l_2477;
    uint32_t l_2479 = 0x9DEE71F5L;
    int32_t l_2480 = 0xD9CC4348L;
    union U0 *l_2490 = &g_2491;
    int32_t l_2499[5];
    int16_t *l_2555[9];
    int16_t l_2663 = (-1L);
    int16_t l_2707 = 0xB946L;
    uint32_t **l_2728[9] = {&g_1057,&g_1057,&g_1057,&g_1057,&g_1057,&g_1057,&g_1057,&g_1057,&g_1057};
    uint32_t ****l_2762 = &g_1174;
    int8_t l_2763 = 0x98L;
    int64_t ****l_2768 = &l_2478;
    int i, j;
    for (i = 0; i < 3; i++)
        l_2474[i] = 0xFAF6L;
    for (i = 0; i < 5; i++)
        l_2499[i] = 0x53EFB3BCL;
    for (i = 0; i < 9; i++)
        l_2555[i] = &g_261[7][4][2];
    g_2458 = ((func_31(func_37(&g_30), l_2430, (*g_383), p_27, (*g_384)) , g_2453) , (g_2456 = func_37(l_2430)));
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_1432 g_2434 g_30 g_29 g_1351 g_385 g_2450
 * writes: g_1432 g_309 g_30 g_1352 g_1191 g_1351
 */
static uint32_t  func_31(int32_t * const * p_32, int32_t * p_33, int32_t ** p_34, int32_t  p_35, int32_t * p_36)
{ /* block id: 1008 */
    uint32_t ***l_2435 = &g_1115;
    union U0 **l_2437 = (void*)0;
    const int16_t l_2444 = 0xCD10L;
    union U0 ****l_2451[5] = {&g_1351,&g_1351,&g_1351,&g_1351,&g_1351};
    union U0 ***l_2452 = (void*)0;
    int i;
    for (g_1432 = 0; (g_1432 <= 39); g_1432 = safe_add_func_uint16_t_u_u_unsafe_macro/*61*//* ___SAFE__OP */(g_1432, 5))
    { /* block id: 1011 */
        const int32_t *l_2433 = &g_30;
        int32_t l_2445 = 0xAD31C045L;
        int8_t *l_2446 = &g_265;
        int32_t **l_2447[9][6] = {{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0},{&g_385,&g_385,(void*)0,&g_385,&g_385,(void*)0}};
        int i, j;
        (*g_2434) = l_2433;
        if ((*l_2433))
            continue;
        (*g_29) = (l_2435 != (void*)0);
        (*g_2450) = ((&g_1397 == (((!((*l_2433) , (((*g_1351) = l_2437) != l_2437))) > (safe_sub_func_uint64_t_u_u_unsafe_macro/*62*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*63*//* ___SAFE__OP */(((safe_mul_func_uint32_t_u_u_unsafe_macro/*64*//* ___SAFE__OP */(((l_2444 || (((l_2445 &= (-1L)) , (void*)0) != l_2446)) <= (*l_2433)), (-3L))) != 0x57126551609B5F3FLL), 13)), 0x9B15BCE0FD3D7687LL))) , &g_1397)) , (*p_32));
    }
    l_2452 = (g_1351 = &g_1352);
    return l_2444;
}


/* ------------------------------------------ */
/* 
 * reads : g_30 g_22 g_29 g_1396 g_1397 g_1398 g_1399 g_385 g_1191 g_39 g_383 g_384 g_86 g_1870 g_225 g_266 g_1174 g_2309 g_265 g_1335.f1 g_1117
 * writes: g_30 g_48 g_86 g_163 g_1431 g_1507 g_261 g_225 g_265 g_1777 g_1335.f1 g_266 g_2031 g_76 g_1175
 */
static int32_t ** func_37(int32_t * p_38)
{ /* block id: 5 */
    int8_t l_49 = (-6L);
    int32_t *l_56 = &g_30;
    int32_t l_1828 = 0xCBD27537L;
    const int64_t *l_1855 = &g_48;
    const int64_t **l_1854 = &l_1855;
    const int64_t ***l_1853 = &l_1854;
    const int64_t ****l_1852 = &l_1853;
    const int64_t *****l_1851 = &l_1852;
    uint32_t ***l_1900 = &g_1115;
    const int8_t l_1906[10][1] = {{1L},{1L},{0x38L},{1L},{1L},{0x38L},{1L},{1L},{0x38L},{1L}};
    int32_t l_1986 = 6L;
    int32_t l_1987 = (-1L);
    int32_t l_1994 = 0L;
    uint32_t **l_2053 = (void*)0;
    int32_t l_2143 = 0xE1B57AECL;
    int32_t l_2145 = 8L;
    int32_t l_2146[5][7][6] = {{{0x892CCDA7L,0xC9024FA7L,0x32C73602L,7L,(-4L),0x71054C00L},{(-1L),0x892CCDA7L,0x32C73602L,0xE6BDC89AL,0x7D47D35CL,0xA1A9DD9FL},{(-1L),0xE6BDC89AL,0x71054C00L,0x4272FBD0L,0L,0x765767B0L},{0x4272FBD0L,0L,0x765767B0L,0x9F4CE80CL,0x8D9F41B7L,0x4272FBD0L},{0x9CFBB5D3L,(-1L),0x88003CD5L,0x72C57AD7L,0x88003CD5L,(-1L)},{0x88003CD5L,0x0B6A26ACL,7L,(-6L),(-4L),0x9F4CE80CL},{0x7D47D35CL,0x88003CD5L,(-6L),0x8D9F41B7L,0xD1881C8BL,0x9F4CE80CL}},{{0x72C57AD7L,(-1L),(-1L),(-6L),0x7D47D35CL,(-1L)},{0x32C73602L,0xA1A9DD9FL,0x72C57AD7L,0L,(-1L),7L},{0x9F4CE80CL,0x892CCDA7L,0xB2CDC3BBL,0x0B6A26ACL,0x765767B0L,0x71054C00L},{0L,0L,(-4L),(-4L),0L,0L},{0x8D9F41B7L,0L,0L,0x765767B0L,(-1L),0x892CCDA7L},{2L,(-1L),(-1L),(-1L),0x7D47D35CL,(-6L)},{2L,0xD1881C8BL,(-1L),0x765767B0L,0x4272FBD0L,7L}},{{0x8D9F41B7L,(-1L),(-1L),(-4L),0xB2CDC3BBL,0x88003CD5L},{0L,0xA1A9DD9FL,0L,0x0B6A26ACL,0xD1881C8BL,0x765767B0L},{0x9F4CE80CL,0L,0xC9024FA7L,0L,0x9F4CE80CL,0x71054C00L},{0x32C73602L,0x765767B0L,(-1L),(-6L),0L,0x32C73602L},{0x72C57AD7L,0x9CFBB5D3L,2L,0x765767B0L,(-1L),0x32C73602L},{(-1L),0x8D9F41B7L,(-1L),0xC9024FA7L,0xB2CDC3BBL,0x71054C00L},{(-1L),0xD1881C8BL,0xC9024FA7L,5L,(-1L),0x765767B0L}},{{0x8D9F41B7L,(-1L),0L,(-1L),0x88003CD5L,0x88003CD5L},{0x32C73602L,(-1L),(-1L),0x32C73602L,0xD1881C8BL,7L},{7L,0x9CFBB5D3L,(-1L),0L,0x765767B0L,(-6L)},{0x892CCDA7L,0x9F4CE80CL,(-1L),(-4L),0x765767B0L,0x892CCDA7L},{(-1L),0x9CFBB5D3L,0L,5L,0xD1881C8BL,0L},{(-1L),(-1L),(-4L),0xB2CDC3BBL,0x88003CD5L,0x71054C00L},{2L,(-1L),0xB2CDC3BBL,7L,(-1L),7L}},{{0x72C57AD7L,0xD1881C8BL,0x72C57AD7L,(-1L),0xB2CDC3BBL,(-1L)},{0x892CCDA7L,0x8D9F41B7L,(-1L),0x0B6A26ACL,(-1L),0x9F4CE80CL},{0x765767B0L,0x9CFBB5D3L,0xC9024FA7L,0x0B6A26ACL,0L,(-1L)},{0x892CCDA7L,0x765767B0L,(-4L),(-1L),0x9F4CE80CL,0x892CCDA7L},{0x72C57AD7L,0L,(-1L),7L,0xD1881C8BL,0x32C73602L},{2L,0xA1A9DD9FL,(-6L),0xB2CDC3BBL,0xB2CDC3BBL,(-6L)},{(-1L),(-1L),0xB2CDC3BBL,5L,0x4272FBD0L,0x9F4CE80CL}}};
    int16_t l_2187[8] = {0xC241L,0xCD53L,0xC241L,0xCD53L,0xC241L,0xCD53L,0xC241L,0xCD53L};
    uint32_t l_2220 = 0UL;
    int64_t l_2299 = 0L;
    int32_t **l_2314 = (void*)0;
    uint16_t *l_2325 = &g_238;
    union U0 ***l_2367 = &g_1352;
    int i, j, k;
lbl_2089:
    for (g_30 = 3; (g_30 >= 0); g_30 -= 1)
    { /* block id: 8 */
        uint32_t l_57[3];
        const int64_t l_1873 = 0x9CF9DA9C94389ABALL;
        union U0 * const l_1874 = (void*)0;
        int8_t ***l_1896 = (void*)0;
        int32_t l_1959 = 0L;
        int32_t l_1985[4][5][10] = {{{1L,0L,1L,0x3E6A81F9L,(-7L),0xE3051C43L,8L,0xDB5BC3CCL,0x0FBCB848L,(-1L)},{0x579AB518L,0xB0EF42E8L,0x82E9411CL,(-1L),0x7BAD97A1L,0L,0x0FBCB848L,0x4A5C29EFL,0x82E9411CL,(-1L)},{0x3F43B8B1L,(-5L),1L,1L,0xDB5BC3CCL,0xDB5BC3CCL,1L,1L,(-5L),0x3F43B8B1L},{0x3E6A81F9L,0x4A5C29EFL,2L,0L,(-1L),0x887ABE26L,0x3F43B8B1L,0xE3051C43L,0L,0L},{0L,0xF6B2470AL,(-1L),0x4A5C29EFL,(-1L),(-4L),0xBA305A60L,(-3L),0xB0EF42E8L,0x3F43B8B1L}},{{(-1L),0x3F43B8B1L,0x10DB1335L,(-1L),0xDB5BC3CCL,0x10066AE9L,(-1L),(-1L),0xE3051C43L,(-1L)},{(-1L),0L,0L,(-3L),0x7BAD97A1L,0x10DB1335L,4L,1L,0x4A5C29EFL,0L},{0x44921A59L,0L,0x604E1848L,(-1L),0x579AB518L,(-1L),0x604E1848L,0L,0x44921A59L,0x0FBCB848L},{0L,0L,1L,0xC96311E6L,(-4L),0x4A5C29EFL,0x6E9A2A64L,0x887ABE26L,0x82E9411CL,0x10DB1335L},{(-1L),0x44921A59L,0xB0EF42E8L,0xC96311E6L,0L,0xDB5BC3CCL,(-1L),0xF6B2470AL,0x44921A59L,1L}},{{0xE3051C43L,0x887ABE26L,2L,(-1L),0xBA305A60L,(-1L),1L,0xB0EF42E8L,0x4A5C29EFL,0L},{0x887ABE26L,0xB0EF42E8L,0x3E6A81F9L,(-3L),(-7L),0L,0xBA305A60L,0L,0xE3051C43L,0xE3051C43L},{2L,0x3E6A81F9L,(-1L),(-1L),(-1L),(-1L),0x3E6A81F9L,2L,0xB0EF42E8L,1L},{(-1L),(-3L),(-1L),0x4A5C29EFL,0L,1L,8L,1L,0L,(-1L)},{0xBA305A60L,(-7L),(-1L),0L,0x579AB518L,1L,1L,2L,(-5L),0x6E9A2A64L}},{{(-1L),0L,(-1L),1L,1L,(-3L),0xDB5BC3CCL,0L,0x82E9411CL,8L},{1L,0xBA305A60L,0x3E6A81F9L,8L,1L,0xDB5BC3CCL,0x10DB1335L,0xB0EF42E8L,0xBA305A60L,0xB0EF42E8L},{0xB0EF42E8L,0L,2L,1L,2L,0L,0xB0EF42E8L,0xF6B2470AL,0x887ABE26L,0L},{0x4A5C29EFL,0xE3051C43L,0xB0EF42E8L,0L,(-5L),0x82E9411CL,0xBA305A60L,0x887ABE26L,0x3E6A81F9L,0xF6B2470AL},{0L,0xE3051C43L,1L,(-1L),0x6E9A2A64L,8L,0xB0EF42E8L,0L,0xF6B2470AL,0x10066AE9L}}};
        uint64_t l_1988 = 18446744073709551614UL;
        int64_t l_1993 = 0x519AA1E498DC2CB0LL;
        uint16_t l_1996 = 7UL;
        uint32_t l_2005 = 18446744073709551614UL;
        uint64_t l_2014 = 0x278C5B600F736D4ALL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_57[i] = 18446744073709551611UL;
        (*g_385) = (safe_add_func_uint16_t_u_u_unsafe_macro/*65*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*66*//* ___SAFE__OP */((((safe_sub_func_uint16_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */((g_48 = 0xF4L), g_30)), (((l_49 , (void*)0) == ((4UL <= ((func_50(l_49, l_56, l_57[2], g_22, l_57[2]) <= l_57[2]) != (*l_56))) , p_38)) , l_57[0]))) && l_57[2]) != l_57[2]), (***g_1396))), 0L));
        for (g_163 = 0; g_163 < 10; g_163 += 1)
        {
            for (g_1431 = 0; g_1431 < 7; g_1431 += 1)
            {
                for (g_1507 = 0; g_1507 < 3; g_1507 += 1)
                {
                    g_261[g_163][g_1431][g_1507] = 1L;
                }
            }
        }
        for (g_225 = 0; (g_225 <= 3); g_225 += 1)
        { /* block id: 749 */
            uint32_t l_1833[6][5] = {{0x7EFB54CDL,0x1A023525L,0x7EFB54CDL,18446744073709551611UL,0x7EFB54CDL},{0xC63FA94AL,0x14DD76C2L,0xC63FA94AL,0x7EFB54CDL,0x7EFB54CDL},{0xC63FA94AL,0x14DD76C2L,0xC63FA94AL,0x7EFB54CDL,0x7EFB54CDL},{0xC63FA94AL,0x14DD76C2L,0xC63FA94AL,0x7EFB54CDL,0x7EFB54CDL},{0xC63FA94AL,0x14DD76C2L,0xC63FA94AL,0x7EFB54CDL,0x7EFB54CDL},{0xC63FA94AL,0x14DD76C2L,0xC63FA94AL,0x7EFB54CDL,0x7EFB54CDL}};
            int32_t l_1885 = 0x19B06C7AL;
            uint32_t *l_1926[8] = {&g_125,(void*)0,&g_125,(void*)0,&g_125,(void*)0,&g_125,(void*)0};
            int16_t l_1983 = (-9L);
            int32_t l_1984[3][6][4] = {{{(-9L),0x0110B326L,1L,0x91A56C00L},{(-1L),0xCFDB88F6L,1L,0xC1237D8FL},{(-9L),0x1642F05CL,0L,0x1642F05CL},{1L,0x0110B326L,(-1L),0x1642F05CL},{(-1L),0x1642F05CL,0xCF766147L,0xC1237D8FL},{1L,0xCFDB88F6L,0L,0x91A56C00L}},{{1L,0x0110B326L,0xCF766147L,0xCFDB88F6L},{(-1L),0x91A56C00L,(-1L),0xC1237D8FL},{1L,0x91A56C00L,0L,0xCFDB88F6L},{(-9L),0x0110B326L,1L,0x91A56C00L},{(-1L),0xCFDB88F6L,1L,0xC1237D8FL},{(-9L),0x1642F05CL,0L,0x1642F05CL}},{{1L,0x0110B326L,(-1L),0x1642F05CL},{(-1L),0x1642F05CL,0xCF766147L,0xC1237D8FL},{1L,0xCFDB88F6L,0L,0x91A56C00L},{1L,0x0110B326L,0xCF766147L,0xCFDB88F6L},{(-1L),0x91A56C00L,(-1L),0xC1237D8FL},{1L,0x91A56C00L,0L,0xCFDB88F6L}}};
            uint16_t **l_2072 = &g_570;
            int i, j, k;
            for (g_265 = 0; (g_265 <= 3); g_265 += 1)
            { /* block id: 752 */
                int8_t *l_1827[4] = {&g_260,&g_260,&g_260,&g_260};
                union U0 **l_1849[5][8][1] = {{{&g_1358},{(void*)0},{&g_354},{&g_354},{&g_354},{(void*)0},{&g_1358},{&g_354}},{{(void*)0},{&g_354},{(void*)0},{(void*)0},{&g_354},{(void*)0},{&g_354},{&g_1358}},{{(void*)0},{&g_354},{&g_354},{&g_354},{(void*)0},{&g_1358},{&g_354},{(void*)0}},{{&g_354},{(void*)0},{(void*)0},{&g_354},{(void*)0},{&g_354},{&g_1358},{(void*)0}},{{&g_354},{&g_354},{&g_354},{(void*)0},{&g_1358},{&g_354},{(void*)0},{&g_354}}};
                uint8_t *l_1857 = &g_163;
                uint8_t **l_1856 = &l_1857;
                int32_t l_1905[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
                uint32_t l_1958 = 0UL;
                int i, j, k;
            }
            for (l_1994 = 0; (l_1994 <= 3); l_1994 += 1)
            { /* block id: 828 */
                int i, j, k;
                (*g_1191) = 0L;
                (*g_1870) = ((***g_383) |= g_39[g_30][(g_30 + 1)][g_30]);
                if (g_39[(l_1994 + 1)][(l_1994 + 4)][g_225])
                    break;
            }
        }
        if (g_225)
            goto lbl_2429;
    }
lbl_2429:
    for (g_1335.f1 = (-18); (g_1335.f1 < 42); g_1335.f1 = safe_add_func_uint16_t_u_u_unsafe_macro/*69*//* ___SAFE__OP */(g_1335.f1, 4))
    { /* block id: 838 */
        uint16_t l_2086 = 3UL;
        uint32_t ****l_2124 = &g_1114;
        uint32_t **l_2127 = &g_337[1];
        int32_t l_2136 = 0xE9C6D944L;
        int32_t l_2137 = 0x14522ACCL;
        int32_t l_2139[6][7][5] = {{{1L,(-7L),1L,0L,0x3FBFD9A1L},{0xD9496B4EL,1L,1L,0xD23D3CB8L,0x14B41DD7L},{(-3L),6L,0xABD3A322L,0x46D34038L,0x2FD30EC7L},{2L,6L,1L,0xF16E558CL,0xDCAE6E41L},{0xDCAE6E41L,0x14B41DD7L,0x61813B70L,6L,5L},{0x3FBFD9A1L,0x0735B0CDL,0L,0x3FBFD9A1L,0xD9496B4EL},{5L,0x0735B0CDL,0L,0L,0x0D5AD1C6L}},{{(-1L),0xBAD932EEL,(-1L),0x14B41DD7L,(-5L)},{1L,0x9FD2EEF3L,8L,0L,0L},{(-1L),(-1L),(-1L),5L,0L},{0x9FD2EEF3L,0L,(-1L),(-1L),0x3B952B02L},{1L,2L,0xD23D3CB8L,5L,0x26272844L},{0x8823AC49L,0L,(-1L),0x3B952B02L,0x14B41DD7L},{8L,(-1L),(-1L),0xF16E558CL,(-1L)}},{{0x0D5AD1C6L,0L,8L,0x61813B70L,0x26272844L},{1L,0x61813B70L,(-1L),0xC5239A4AL,0L},{1L,0x9977C867L,0xABD3A322L,1L,0x9977C867L},{0x26272844L,8L,0x2FD30EC7L,1L,0L},{0xBAD932EEL,0L,1L,0xC5239A4AL,0x61813B70L},{0xF16E558CL,1L,0x3B952B02L,0x61813B70L,5L},{1L,0xF16E558CL,6L,0xF16E558CL,1L}},{{7L,(-1L),5L,0x3B952B02L,8L},{1L,(-1L),0x3B952B02L,5L,1L},{0x31EF988FL,1L,6L,(-1L),8L},{5L,5L,0x1FEAC1DBL,5L,1L},{8L,0x1FEAC1DBL,0xABD3A322L,0L,5L},{(-1L),1L,0xDCAE6E41L,0x14B41DD7L,0x61813B70L},{0xABD3A322L,0x9FD2EEF3L,1L,0L,0L}},{{0x9FD2EEF3L,0x8823AC49L,(-1L),0x0D5AD1C6L,0x9977C867L},{0x9FD2EEF3L,0xF16E558CL,0xD9496B4EL,(-1L),0L},{0xABD3A322L,2L,0xBAD932EEL,0x1FEAC1DBL,0x26272844L},{(-1L),0L,(-1L),0L,(-1L)},{8L,8L,(-3L),0xF16E558CL,0x14B41DD7L},{5L,0L,1L,(-5L),0x26272844L},{0x31EF988FL,(-5L),(-1L),1L,0x3B952B02L}},{{1L,0L,0x3FBFD9A1L,1L,0L},{7L,8L,0x1FEAC1DBL,0xABD3A322L,0L},{1L,0L,1L,1L,(-5L)},{0xF16E558CL,2L,(-10L),0x61813B70L,0x0D5AD1C6L},{0xBAD932EEL,0xF16E558CL,5L,0L,1L},{0x26272844L,0x8823AC49L,5L,0L,(-1L)},{1L,0x9FD2EEF3L,(-10L),5L,0x31EF988FL}}};
        int64_t *l_2154 = &g_48;
        int64_t **l_2153 = &l_2154;
        int64_t ***l_2152 = &l_2153;
        int64_t ****l_2151[5] = {&l_2152,&l_2152,&l_2152,&l_2152,&l_2152};
        int32_t l_2248 = (-1L);
        union U0 *l_2253 = &g_821[2];
        uint16_t l_2274 = 0UL;
        int32_t **l_2311 = &l_56;
        const int8_t l_2415 = 0L;
        uint32_t ***l_2426 = &l_2127;
        const uint64_t l_2428 = 1UL;
        int i, j, k;
        if ((***g_383))
            break;
        for (g_266 = (-7); (g_266 == 15); g_266 = safe_add_func_uint64_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */(g_266, 1))
        { /* block id: 842 */
            int64_t l_2080 = 0x48120DB43D18731DLL;
            int32_t l_2084[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
            uint32_t * const ** const l_2111 = (void*)0;
            int8_t *l_2113 = &g_265;
            int8_t l_2133[1];
            int64_t l_2181[9][3][3] = {{{0L,0L,0xFEA9435F65A4CA1FLL},{0L,0x1E39CDE7C9CB61BBLL,0L},{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL}},{{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)},{0L,0L,0xFEA9435F65A4CA1FLL},{0L,0x1E39CDE7C9CB61BBLL,0L}},{{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL},{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)},{0L,0L,0xFEA9435F65A4CA1FLL}},{{0L,0x1E39CDE7C9CB61BBLL,0L},{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL},{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)}},{{0L,0L,0xFEA9435F65A4CA1FLL},{0L,0x1E39CDE7C9CB61BBLL,0L},{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL}},{{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)},{0L,0L,0xFEA9435F65A4CA1FLL},{0L,0x1E39CDE7C9CB61BBLL,0L}},{{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL},{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)},{0L,0L,0xFEA9435F65A4CA1FLL}},{{0L,0x1E39CDE7C9CB61BBLL,0L},{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL},{(-1L),0x1E39CDE7C9CB61BBLL,(-1L)}},{{0L,0L,0xFEA9435F65A4CA1FLL},{0L,0x1E39CDE7C9CB61BBLL,0L},{0L,0xFEA9435F65A4CA1FLL,0xFEA9435F65A4CA1FLL}}};
            uint32_t l_2182[5][6][8] = {{{0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L,0x9ECE89C9L},{0xA5B06854L,18446744073709551612UL,0x9ECE89C9L,0UL,0x9ECE89C9L,18446744073709551612UL,0xA5B06854L,0xA5B06854L},{18446744073709551612UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,18446744073709551612UL,0x4D27C33DL,18446744073709551612UL},{0UL,18446744073709551612UL,0x4D27C33DL,18446744073709551612UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL},{18446744073709551612UL,0xA5B06854L,0xA5B06854L,18446744073709551612UL,0x9ECE89C9L,0UL,0x9ECE89C9L,18446744073709551612UL},{0xA5B06854L,0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L}},{{0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL,0UL,0UL,0x4D27C33DL,0x9ECE89C9L},{0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L,0x9ECE89C9L},{0xA5B06854L,18446744073709551612UL,0x9ECE89C9L,0UL,0x9ECE89C9L,18446744073709551612UL,0xA5B06854L,0xA5B06854L},{18446744073709551612UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,18446744073709551612UL,0x4D27C33DL,18446744073709551612UL},{0UL,18446744073709551612UL,0x4D27C33DL,18446744073709551612UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL},{18446744073709551612UL,0xA5B06854L,0xA5B06854L,18446744073709551612UL,0x9ECE89C9L,0UL,0x9ECE89C9L,18446744073709551612UL}},{{0xA5B06854L,0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L},{0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL,0UL,0UL,0x9ECE89C9L,0UL},{0UL,0UL,0x4D27C33DL,0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL,0UL},{0UL,0xA5B06854L,0UL,18446744073709551610UL,0UL,0xA5B06854L,0UL,0UL},{0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L,0x9ECE89C9L,0xA5B06854L},{18446744073709551610UL,0xA5B06854L,0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL}},{{0xA5B06854L,0UL,0UL,0xA5B06854L,0UL,18446744073709551610UL,0UL,0xA5B06854L},{0UL,0UL,0UL,0x4D27C33DL,0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL},{0UL,0UL,0x9ECE89C9L,18446744073709551610UL,18446744073709551612UL,18446744073709551610UL,0x9ECE89C9L,0UL},{0UL,0UL,0x4D27C33DL,0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL,0UL},{0UL,0xA5B06854L,0UL,18446744073709551610UL,0UL,0xA5B06854L,0UL,0UL},{0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL,0xA5B06854L,0x9ECE89C9L,0xA5B06854L}},{{18446744073709551610UL,0xA5B06854L,0x9ECE89C9L,0xA5B06854L,18446744073709551610UL,0x4D27C33DL,0x4D27C33DL,18446744073709551610UL},{0xA5B06854L,0UL,0UL,0xA5B06854L,0UL,18446744073709551610UL,0UL,0xA5B06854L},{0UL,0UL,0UL,0x4D27C33DL,0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL},{0UL,0UL,0x9ECE89C9L,18446744073709551610UL,18446744073709551612UL,18446744073709551610UL,0x9ECE89C9L,0UL},{0UL,0UL,0x4D27C33DL,0x9ECE89C9L,0x9ECE89C9L,0x4D27C33DL,0UL,0UL},{0UL,0xA5B06854L,0UL,18446744073709551610UL,0UL,0xA5B06854L,0UL,0UL}}};
            uint16_t l_2279[9][7] = {{65532UL,65532UL,65532UL,65532UL,65532UL,65532UL,65532UL},{0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L},{65532UL,65532UL,65532UL,65532UL,65532UL,65532UL,65532UL},{0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L},{65532UL,65532UL,65532UL,65532UL,65532UL,65532UL,65532UL},{0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L},{65532UL,65532UL,65532UL,65532UL,65532UL,65532UL,65532UL},{0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L,0x5747L},{65532UL,65532UL,65532UL,65532UL,65532UL,65532UL,65532UL}};
            int32_t l_2293[2][10][7] = {{{0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL},{0L,0L,(-9L),7L,(-9L),0L,0L},{0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L},{0L,7L,(-1L),7L,0L,(-1L),0L},{0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL},{(-9L),7L,(-9L),0L,0L,0L,(-9L)},{0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL},{0L,0L,(-9L),7L,(-9L),0L,0L},{0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L},{0L,7L,(-1L),7L,0L,(-1L),0L}},{{0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL},{(-9L),7L,(-9L),0L,0L,0L,(-9L)},{0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL},{0L,0L,(-9L),7L,(-9L),0L,0L},{0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L},{0L,7L,(-1L),7L,0L,(-1L),0L},{0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL,0x48E013D5L,0x48E013D5L,0x0FF2C82BL},{(-9L),7L,(-9L),0L,0L,0L,(-9L)},{0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL,0x0FF2C82BL,0L,0x0FF2C82BL},{0L,0L,(-9L),7L,(-9L),0L,0L}}};
            uint32_t l_2300 = 0UL;
            int32_t **l_2303 = &g_29;
            int32_t l_2305[1];
            int16_t *l_2317 = (void*)0;
            int16_t *l_2318 = &l_2187[5];
            int16_t *l_2319[7] = {&g_261[0][5][2],&g_263[4][2][0],&g_261[0][5][2],&g_261[0][5][2],&g_263[4][2][0],&g_261[0][5][2],&g_261[0][5][2]};
            int8_t l_2346[8];
            uint16_t l_2391 = 0x593AL;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_2133[i] = (-1L);
            for (i = 0; i < 1; i++)
                l_2305[i] = 0x6C3CE99CL;
            for (i = 0; i < 8; i++)
                l_2346[i] = (-9L);
            for (g_2031 = 0; g_2031 < 5; g_2031 += 1)
            {
                g_76[g_2031] = 0x7FL;
            }
        }
        (**g_2309) |= (((l_2053 = l_2053) == ((*l_2426) = ((*g_1174) = l_2127))) ^ (((!(*l_56)) >= ((l_2428 | (**g_1397)) > (**l_2311))) <= 0x35C1L));
        if (g_1335.f1)
            goto lbl_2089;
    }
    (*l_56) = (*p_38);
    return (*g_383);
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_30
 * writes:
 */
static int64_t  func_50(int16_t  p_51, int32_t * p_52, uint16_t  p_53, uint8_t  p_54, const uint32_t  p_55)
{ /* block id: 10 */
    int32_t l_64 = 0xDF6EF7D1L;
    int32_t l_1825 = 0L;
    for (p_54 = 0; (p_54 != 6); p_54++)
    { /* block id: 13 */
        int32_t l_60 = (-1L);
        int32_t l_1787 = 1L;
        int8_t * const *l_1799 = &g_553;
        int8_t * const **l_1798 = &l_1799;
        if (l_60)
            break;
        for (l_60 = 28; (l_60 > (-28)); l_60--)
        { /* block id: 17 */
            int8_t l_63 = 0x76L;
            if ((l_63 , (*g_29)))
            { /* block id: 18 */
                l_64 = (*p_52);
            }
            else
            { /* block id: 20 */
                for (l_64 = 0; (l_64 == (-4)); l_64 = safe_sub_func_uint32_t_u_u_unsafe_macro/*71*//* ___SAFE__OP */(l_64, 1))
                { /* block id: 23 */
                    for (l_63 = 0; (l_63 <= (-3)); l_63 = safe_sub_func_uint32_t_u_u_unsafe_macro/*72*//* ___SAFE__OP */(l_63, 6))
                    { /* block id: 26 */
                        return p_54;
                    }
                    if ((*p_52))
                        break;
                }
            }
            return l_60;
        }
        for (p_53 = 0; (p_53 <= 20); ++p_53)
        { /* block id: 36 */
            uint16_t l_75[7][5][7] = {{{0xF8C0L,65535UL,65534UL,0x697EL,2UL,0xFF55L,1UL},{0UL,0x3341L,65535UL,65535UL,0x3A56L,0xFA8CL,0x1612L},{0xF43AL,65535UL,0x87E1L,0x697EL,65529UL,0xFF55L,0x9AC7L},{0UL,0x3A56L,65535UL,65535UL,0x3A56L,0UL,0x1612L},{0xF8C0L,65535UL,65534UL,0x697EL,2UL,0xFF55L,1UL}},{{0UL,0x3341L,65535UL,65535UL,0x3A56L,0xFA8CL,0x1612L},{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL}},{{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL},{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL}},{{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL},{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL}},{{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL},{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL}},{{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL},{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,65535UL,0x1612L,4UL,65535UL,0x21D2L,0UL}},{{65535UL,0x697EL,0x9AC7L,0xB18EL,0x87E1L,0x0C23L,0x606EL},{0xF0ABL,65535UL,0x1612L,0x1612L,65535UL,0xF0ABL,0UL},{0xD895L,0x697EL,1UL,0xB18EL,65534UL,0x0C23L,65535UL},{0xF0ABL,0x1612L,0UL,0UL,4UL,0x3341L,5UL},{65529UL,0xB18EL,0x606EL,0xFC51L,0x9AC7L,65535UL,6UL}}};
            int32_t l_1801 = 0x1447AEE7L;
            int64_t *l_1805 = &g_1429;
            int8_t *l_1826 = &g_76[4];
            int i, j, k;
        }
    }
    return l_1825;
}


/* ------------------------------------------ */
/* 
 * reads : g_86 g_22 g_1242 g_1243 g_782 g_261 g_366 g_85 g_385 g_384 g_1174 g_1175 g_337 g_190 g_125 g_225 g_1396 g_1191 g_266 g_644 g_163 g_383 g_260 g_1335.f1 g_1432 g_903 g_898 g_30 g_39 g_1453 g_375.f0 g_339 g_1476 g_1397 g_1507 g_1429 g_1398 g_1399 g_900 g_901 g_1476.f0 g_238 g_443 g_1628 g_1631 g_1058 g_1653 g_1414 g_1668 g_1654 g_1655 g_263 g_29 g_1726 g_1734 g_1744 g_1754 g_1209 g_1176
 * writes: g_86 g_76 g_39 g_339 g_385 g_190 g_125 g_225 g_1396 g_238 g_266 g_644 g_163 g_260 g_1335.f1 g_1432 g_782 g_898 g_1596 g_261 g_1414 g_263 g_1668 g_1727 g_1209 g_1176
 */
static const uint32_t  func_71(uint16_t  p_72, int32_t * p_73, int32_t  p_74)
{ /* block id: 38 */
    const int32_t *l_84 = &g_22;
    uint16_t l_1390 = 65530UL;
    int32_t **l_1391 = (void*)0;
    int32_t l_1437[8][7][3] = {{{0xBBACD5E9L,0x9A99AF9EL,0x7F138002L},{0xB51646B2L,0x6563D0CEL,0xB51646B2L},{0x0CA4B7DEL,0xF41739C4L,0L},{0x0F2F1DF1L,1L,0xB51646B2L},{0L,1L,0x7F138002L},{0L,(-1L),0L},{0L,0xD20E707EL,0L}},{{0x0F2F1DF1L,(-1L),0xBDA9911BL},{0x0CA4B7DEL,0xD20E707EL,0x0CA4B7DEL},{0xB51646B2L,(-1L),0xE0B92048L},{0xBBACD5E9L,1L,0x0CA4B7DEL},{0xE0B92048L,1L,0xBDA9911BL},{0x89E48F71L,0xF41739C4L,0L},{0xE0B92048L,0x6563D0CEL,0L}},{{0xBBACD5E9L,0x9A99AF9EL,0x7F138002L},{0xB51646B2L,0x6563D0CEL,0xB51646B2L},{0x0CA4B7DEL,0xF41739C4L,0L},{0x0F2F1DF1L,1L,0xB51646B2L},{0L,1L,0x7F138002L},{0L,(-1L),0L},{0L,0xD20E707EL,0L}},{{0x0F2F1DF1L,(-1L),0xBDA9911BL},{0x0CA4B7DEL,0xD20E707EL,0x0CA4B7DEL},{0xB51646B2L,(-1L),0xE0B92048L},{0xBBACD5E9L,1L,0x0CA4B7DEL},{0xE0B92048L,1L,0xBDA9911BL},{0x89E48F71L,0xF41739C4L,0L},{0xE0B92048L,0x6563D0CEL,0L}},{{0xBBACD5E9L,0x9A99AF9EL,0x7F138002L},{0xB51646B2L,0x6563D0CEL,0xB51646B2L},{0x0CA4B7DEL,0xF41739C4L,0L},{0x0F2F1DF1L,1L,0xB51646B2L},{0L,1L,0x7F138002L},{0L,(-1L),0L},{0L,0xD20E707EL,0L}},{{0x0F2F1DF1L,(-1L),0xBDA9911BL},{0x0CA4B7DEL,0xD20E707EL,0x0CA4B7DEL},{0xB51646B2L,(-1L),0xE0B92048L},{0xBBACD5E9L,1L,0x0CA4B7DEL},{0xE0B92048L,1L,0xBDA9911BL},{0x89E48F71L,0xF41739C4L,0L},{0xE0B92048L,0x6563D0CEL,0L}},{{0xBBACD5E9L,0x9A99AF9EL,0x7F138002L},{0xB51646B2L,0x6563D0CEL,0xB51646B2L},{0x0CA4B7DEL,0xF41739C4L,0L},{0x0F2F1DF1L,1L,0xB51646B2L},{0L,1L,0x7F138002L},{0L,(-1L),0L},{0L,0xD20E707EL,0L}},{{0x0F2F1DF1L,(-1L),0xBDA9911BL},{0x0CA4B7DEL,0xD20E707EL,0x0CA4B7DEL},{0xB51646B2L,(-1L),0xE0B92048L},{0xBBACD5E9L,1L,0x0CA4B7DEL},{0xE0B92048L,1L,0xBDA9911BL},{0x89E48F71L,0xF41739C4L,0L},{0xE0B92048L,0x6563D0CEL,0L}}};
    int8_t * const l_1440 = &g_1414;
    int32_t ***l_1465 = &g_384;
    uint32_t l_1466 = 0x3ED07CB0L;
    int64_t *l_1571 = &g_443;
    int32_t l_1612[5];
    uint32_t l_1620 = 2UL;
    uint8_t *l_1750 = &g_1209;
    uint8_t **l_1749 = &l_1750;
    int32_t l_1766 = 0x26BE4B28L;
    uint64_t l_1771 = 1UL;
    const uint32_t l_1786 = 0x983A37DEL;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_1612[i] = 0x71A2CCE3L;
    l_1437[2][4][1] |= (p_74 = (func_77(func_82(l_84), p_74, ((((safe_lshift_func_int32_t_s_u_unsafe_macro/*73*//* ___SAFE__OP */(0x760A7B50L, 26)) , ((safe_mul_func_uint8_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */(((void*)0 != &p_73), (((*l_84) <= (safe_add_func_int32_t_s_s_unsafe_macro/*75*//* ___SAFE__OP */((((safe_div_func_int8_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */((((--(***g_1174)) && 7UL) , p_74), (*l_84))) ^ (*l_84)) ^ l_1390), p_74))) || (*l_84)))) >= p_74)) > (*l_84)) , p_72), l_1391) != p_72));
    (**g_383) = &p_74;
    if ((safe_mod_func_uint16_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */(((l_1440 != (void*)0) >= (*g_366)), ((safe_mod_func_uint16_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */((((((safe_sub_func_int64_t_s_s_unsafe_macro/*80*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_s_unsafe_macro/*81*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*82*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s_unsafe_macro/*83*//* ___SAFE__OP */((g_1453[2][3] , (safe_sub_func_int8_t_s_s_unsafe_macro/*84*//* ___SAFE__OP */((~(safe_div_func_uint8_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((((((safe_add_func_uint32_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(((*p_73) == (0UL ^ (safe_add_func_uint32_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */(0x2097DDD6L, (safe_add_func_uint32_t_u_u_unsafe_macro/*88*//* ___SAFE__OP */(((void*)0 != l_1465), 4294967295UL)))))), p_74)) , 0xCA3F4EA8L) || (*l_84)) , g_375.f0) ^ (*l_84)), g_339))), p_72))), l_1466)), (*l_84))), 11)) | (*l_84)), p_74)) <= 0x5DL) , (***l_1465)) , &g_553) == &l_1440), (*l_84))), (*l_84))) , (*l_84)))))
    { /* block id: 594 */
        int32_t l_1473 = 0xC365DC6EL;
        (*g_1191) = (((safe_rshift_func_int8_t_s_u_unsafe_macro/*89*//* ___SAFE__OP */(0x37L, 4)) > p_72) != (safe_sub_func_int64_t_s_s_unsafe_macro/*90*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */(((***l_1465) &= 0xF833L), ((l_1473 < (p_72 < ((((safe_lshift_func_int32_t_s_u_unsafe_macro/*92*//* ___SAFE__OP */((*p_73), 5)) != (g_1476[3][4][4] , (safe_sub_func_uint16_t_u_u_unsafe_macro/*93*//* ___SAFE__OP */((*l_84), g_225)))) | l_1473) , p_72))) , l_1473))) != p_72), (*l_84))));
    }
    else
    { /* block id: 597 */
        uint32_t l_1482 = 0UL;
        union U0 *l_1487 = (void*)0;
        int32_t l_1489 = 0L;
        int32_t l_1509 = 0x47DD3986L;
        int64_t *l_1572 = (void*)0;
        const uint8_t **l_1627 = (void*)0;
        int64_t l_1648 = (-6L);
        int32_t l_1661 = 0x7133DF91L;
        uint8_t l_1662 = 0x68L;
        int32_t l_1686 = (-10L);
        int32_t l_1692 = 1L;
        int32_t l_1693[9] = {0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L,0x312EEAE2L};
        int32_t l_1698 = 0L;
        int64_t **l_1742 = &l_1572;
        int64_t ** const *l_1741 = &l_1742;
        uint64_t l_1774 = 0x8A4844A83E807C28LL;
        int16_t l_1778 = 0x6EF9L;
        uint32_t ***l_1784 = &g_1175;
        int i;
lbl_1687:
        (*g_1191) |= (((((*g_366) ^ (safe_unary_minus_func_int8_t_s_unsafe_macro/*94*//* ___SAFE__OP */((p_72 , ((safe_mod_func_uint16_t_u_u_unsafe_macro/*95*//* ___SAFE__OP */(p_72, (p_74 && 0x10D51D4CL))) & ((((*g_1396) != (void*)0) < 0x8426D703L) < (*g_366))))))) , (*l_84)) == p_74) != (*p_73));
        if (l_1482)
        { /* block id: 599 */
            const int16_t *l_1488 = &g_261[0][5][2];
            int32_t l_1496 = (-1L);
            int64_t l_1506 = 0x5C67CBB526E0BA93LL;
            int32_t l_1508[5][9][3] = {{{1L,1L,0xD1AF89A1L},{0x967F78EAL,5L,0x0CF3B8EBL},{(-1L),(-2L),0x42FB30DCL},{0xF831EE92L,5L,(-1L)},{(-6L),1L,(-1L)},{1L,1L,0L},{(-3L),3L,(-3L)},{1L,0x967F78EAL,4L},{0x815F92B9L,0xD1AF89A1L,0xC2734540L}},{{0xD89FDED3L,0x0CF3B8EBL,0xBC9AD85FL},{0xD1AF89A1L,0x42FB30DCL,(-6L)},{0xD89FDED3L,(-1L),0xCDCC076FL},{0x815F92B9L,(-1L),1L},{1L,0L,0xF831EE92L},{(-3L),(-3L),(-8L)},{1L,4L,(-9L)},{(-6L),0xC2734540L,0x4B90011EL},{0xF831EE92L,0xBC9AD85FL,0xFE06D537L}},{{(-1L),(-6L),0x4B90011EL},{0x967F78EAL,0xCDCC076FL,(-9L)},{0x4F1CAFC6L,1L,(-8L)},{0L,0xF831EE92L,0xF831EE92L},{0x31684025L,(-8L),1L},{1L,(-9L),0xCDCC076FL},{1L,0x4B90011EL,(-6L)},{4L,0xFE06D537L,0xBC9AD85FL},{3L,0x4B90011EL,0xC2734540L}},{{0x0CF3B8EBL,(-9L),4L},{0x05C1D0D7L,(-8L),(-3L)},{0L,0xF831EE92L,0L},{4L,1L,(-1L)},{(-5L),0xCDCC076FL,(-1L)},{0xDD4DB9D4L,(-6L),0x42FB30DCL},{0xCDCC076FL,0xBC9AD85FL,0x0CF3B8EBL},{0xDD4DB9D4L,0xC2734540L,0xD1AF89A1L},{(-5L),4L,0x967F78EAL}},{{4L,(-3L),3L},{0L,0L,1L},{0x05C1D0D7L,(-1L),1L},{0x0CF3B8EBL,(-1L),5L},{3L,0x42FB30DCL,(-2L)},{4L,0x0CF3B8EBL,5L},{1L,0xD1AF89A1L,1L},{1L,0x967F78EAL,1L},{0x31684025L,3L,3L}}};
            const int32_t **l_1538[3][10] = {{&g_309[0][0][3],&l_84,&l_84,&l_84,&l_84,&g_309[0][0][3],&g_309[0][0][1],&g_309[0][0][1],&g_309[0][0][3],&g_309[0][0][1]},{&g_309[0][0][0],&l_84,&g_309[0][0][3],(void*)0,&g_309[0][0][3],&l_84,&g_309[0][0][0],&g_309[0][0][1],&g_309[0][0][3],&g_309[0][0][3]},{&g_309[0][0][0],&g_309[0][0][3],&g_309[0][0][3],&l_84,&l_84,&g_309[0][0][3],&g_309[0][0][3],&g_309[0][0][0],&l_84,&g_309[0][0][1]}};
            int64_t **** const l_1557 = (void*)0;
            union U0 **** const l_1724 = &g_1351;
            int i, j, k;
            if ((safe_sub_func_int64_t_s_s_unsafe_macro/*96*//* ___SAFE__OP */((((*g_366) = 18446744073709551614UL) > 0xF59DC968A80C519FLL), (2L ^ (0UL & 2UL)))))
            { /* block id: 601 */
                int32_t l_1501 = 0x1FCE19F7L;
                int16_t *l_1505 = (void*)0;
                int16_t **l_1504 = &l_1505;
                uint64_t l_1510[1][3][9] = {{{0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL},{18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL},{0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL,0x12A9F661F2E2E5D4LL}}};
                int64_t *l_1573 = &g_443;
                uint8_t l_1606 = 0UL;
                uint32_t *****l_1636 = &g_1243[0];
                int i, j, k;
                if (((((***l_1465) = (((((safe_lshift_func_int8_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */((((void*)0 == l_1487) || ((l_1489 = ((void*)0 != l_1488)) , (safe_add_func_uint16_t_u_u_unsafe_macro/*98*//* ___SAFE__OP */(((l_1496 = ((safe_add_func_int64_t_s_s_unsafe_macro/*99*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*100*//* ___SAFE__OP */(l_1496, (l_1508[1][4][2] = (safe_mul_func_int32_t_s_s_unsafe_macro/*101*//* ___SAFE__OP */(((((safe_rshift_func_int32_t_s_s_unsafe_macro/*102*//* ___SAFE__OP */(((l_1501 , (safe_mul_func_int16_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */((p_72 != (l_1504 != (void*)0)), (***l_1465)))) , l_1506), g_1507)) <= 0UL) , l_1482) , l_1489), l_1501))))), p_74)) , 4294967294UL)) == (*p_73)), (***l_1465))))), 1)) <= g_1429) && p_72) < l_1509) , l_1501)) , (*g_1398)) != l_1510[0][0][6]))
                { /* block id: 606 */
                    int64_t *l_1520 = &l_1506;
                    int64_t **l_1519 = &l_1520;
                    int64_t l_1537 = (-7L);
                    uint32_t ***l_1539 = &g_1115;
                    int32_t l_1547 = 0x77B56919L;
                    uint32_t l_1560[8] = {0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L,0x0DA7CE39L};
                    int32_t *l_1601 = &l_1437[0][5][1];
                    int32_t *l_1602 = &l_1496;
                    int32_t *l_1603 = &l_1508[0][2][2];
                    int32_t *l_1604 = &g_1117[4][3][0];
                    int32_t *l_1605[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1605[i] = (void*)0;
                    if ((((safe_add_func_uint32_t_u_u_unsafe_macro/*104*//* ___SAFE__OP */(0xF22F15BBL, (0x388D0A59A1C42A5ALL < (safe_mul_func_uint16_t_u_u_unsafe_macro/*105*//* ___SAFE__OP */(((l_1508[3][5][0] = (safe_add_func_uint16_t_u_u_unsafe_macro/*106*//* ___SAFE__OP */(p_72, (safe_add_func_int8_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */((((*l_1519) = &l_1506) != (void*)0), (((safe_rshift_func_uint32_t_u_s_unsafe_macro/*108*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*109*//* ___SAFE__OP */(((*g_366) | (safe_add_func_uint16_t_u_u_unsafe_macro/*110*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*111*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*112*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */((((safe_sub_func_uint32_t_u_u_unsafe_macro/*114*//* ___SAFE__OP */(((**g_1175) ^= (safe_rshift_func_int8_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */(p_74, 0))), (*g_900))) < ((((g_163 ^ g_86) || p_72) > p_72) > p_72)) == p_72), (*p_73))), l_1537)), 0x5A6CL)), 0x5806L))), l_1506)), 21)) , l_1538[2][6]) == &p_73)))))) < g_163), p_74))))) > l_1489) <= 0xB9L))
                    { /* block id: 610 */
                        (**g_384) = (0xB4L ^ ((p_74 || ((void*)0 == l_1539)) <= ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*116*//* ___SAFE__OP */(((safe_sub_func_uint8_t_u_u_unsafe_macro/*117*//* ___SAFE__OP */(0xEAL, (((!l_1509) < ((*g_1191) = ((l_1501 ^= p_74) | (l_1547 ^= (((safe_add_func_int64_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */((g_1476[3][4][4].f0 >= 0x0DL), (*g_366))) , 1UL) & (-4L)))))) && 0L))) > 0xAC68L), 56)) || 0xD5BF46FA30D0BFEFLL)));
                        if (g_225)
                            goto lbl_1600;
                    }
                    else
                    { /* block id: 615 */
                        int32_t l_1556 = 0xCBE56B41L;
                        uint16_t *l_1561[8];
                        int16_t *l_1597 = &g_261[4][3][1];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_1561[i] = (void*)0;
                        (**g_384) = ((safe_add_func_uint32_t_u_u_unsafe_macro/*119*//* ___SAFE__OP */((((((safe_lshift_func_int32_t_s_u_unsafe_macro/*120*//* ___SAFE__OP */(0x735E612AL, 5)) == (p_72 != (((*g_1191) = 0x3E2DC988L) == ((safe_sub_func_uint16_t_u_u_unsafe_macro/*121*//* ___SAFE__OP */(((l_1482 < l_1556) , ((l_1557 != (p_74 , l_1557)) & ((safe_mod_func_int64_t_s_s_unsafe_macro/*122*//* ___SAFE__OP */(p_72, p_72)) , 0xC844ACD2DFEF52F7LL))), l_1560[2])) , 4UL)))) == l_1482) <= 0x62C9L) | (**g_1397)), p_72)) & g_238);
                        (*g_1191) &= ((g_238 = p_72) & ((*l_1597) ^= (safe_lshift_func_int16_t_s_u_unsafe_macro/*123*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s_unsafe_macro/*124*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */((((((((safe_div_func_int64_t_s_s_unsafe_macro/*126*//* ___SAFE__OP */((!(g_1596 = (((((*l_1519) = l_1571) == (l_1573 = l_1572)) , (0x8D369CE8ECAA116ALL == (safe_mul_func_uint32_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*128*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */(((l_1556 | 3UL) == ((((*g_366) = (safe_rshift_func_uint32_t_u_s_unsafe_macro/*130*//* ___SAFE__OP */((((((-1L) == (l_1547 = 0x1B35L)) ^ (safe_mod_func_uint32_t_u_u_unsafe_macro/*131*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*132*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*133*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*134*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*135*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*137*//* ___SAFE__OP */(p_74, 0x3CL)), 0x0C4AL)), (*p_73))), p_72)), 0xE383FF49L)), 0x829B849CL)) & l_1482), 0xF939F410L))) > 8UL) < (*g_366)), (*p_73)))) , 0x50L) != 0xF8L)), l_1501)), l_1482)), 0x62C10848L)))) > (***g_1396)))), g_443)) & 1UL) && p_74) < 0x4ACAL) && 251UL) | p_72) == l_1556), p_74)), p_72)) , 0L), p_72))));
                        (***l_1465) = (*p_73);
                        l_1556 = ((***g_383) = 0L);
                    }
lbl_1600:
                    l_1508[3][3][2] ^= (safe_mod_func_int32_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */((l_1509 && l_1482), ((***g_1174) ^= 1UL)));
                    --l_1606;
                    l_1509 &= (safe_unary_minus_func_int8_t_s_unsafe_macro/*139*//* ___SAFE__OP */(((***l_1465) | p_72)));
                }
                else
                { /* block id: 635 */
                    const uint32_t l_1613 = 0xE5B092E3L;
                    if ((safe_add_func_uint32_t_u_u_unsafe_macro/*140*//* ___SAFE__OP */(l_1612[0], p_72)))
                    { /* block id: 636 */
                        (**l_1465) = (void*)0;
                    }
                    else
                    { /* block id: 638 */
                        return l_1613;
                    }
                }
                for (p_74 = 0; (p_74 == 10); p_74 = safe_add_func_int8_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */(p_74, 9))
                { /* block id: 644 */
                    int16_t *l_1634 = (void*)0;
                    uint32_t *****l_1635 = (void*)0;
                    (*g_1191) |= (((((safe_unary_minus_func_int64_t_s_unsafe_macro/*142*//* ___SAFE__OP */(0L)) <= (+p_74)) >= 0x252FL) < (((safe_mod_func_uint64_t_u_u_unsafe_macro/*143*//* ___SAFE__OP */((p_72 < l_1620), (*g_366))) , ((safe_sub_func_int32_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u_unsafe_macro/*145*//* ___SAFE__OP */(((l_1508[1][4][2] = (!(~l_1482))) != ((void*)0 == l_1627)), p_74)) && p_74), l_1501)) && g_1628)) && 3L)) & l_1501);
                    (*g_1191) = (((safe_rshift_func_int8_t_s_s_unsafe_macro/*146*//* ___SAFE__OP */((g_1631 , (p_74 >= ((safe_mul_func_uint16_t_u_u_unsafe_macro/*147*//* ___SAFE__OP */(((((((*l_1504) = l_1634) == (void*)0) , l_1635) != (l_1636 = (void*)0)) != ((*g_366) = ((*g_1058) , (safe_mul_func_uint8_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u_unsafe_macro/*149*//* ___SAFE__OP */((+1L), (((safe_lshift_func_int8_t_s_u_unsafe_macro/*150*//* ___SAFE__OP */(p_74, 3)) < 0UL) || 0xCF2CL))) & 4294967294UL), p_74))))), 0x23A2L)) , (-3L)))), 4)) == g_266) == 0xCF812731L);
                }
            }
            else
            { /* block id: 652 */
                uint8_t *l_1657[3];
                uint8_t **l_1656 = &l_1657[0];
                int32_t l_1660 = 7L;
                int16_t *l_1663 = &g_263[5][5][0];
                int32_t l_1678 = 0x8829B76FL;
                int64_t l_1689 = 1L;
                int8_t ****l_1725 = (void*)0;
                int i;
                for (i = 0; i < 3; i++)
                    l_1657[i] = (void*)0;
                if ((safe_rshift_func_int16_t_s_u_unsafe_macro/*151*//* ___SAFE__OP */(((*l_1663) = (safe_mul_func_int8_t_s_s_unsafe_macro/*152*//* ___SAFE__OP */(l_1648, (safe_rshift_func_uint16_t_u_s_unsafe_macro/*153*//* ___SAFE__OP */(((p_74 , ((safe_sub_func_int8_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */(((((g_1653[0] == (p_72 , l_1656)) != (-10L)) == ((*l_1440) |= ((((((l_1508[3][2][0] |= l_1648) != (l_1509 = ((((((((safe_mod_func_int8_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */(l_1660, (6UL | l_1661))) , (**g_1397)) > l_1482) != p_74) >= 0x3E1CL) <= l_1662) ^ 4294967293UL) == p_74))) & l_1661) && (***l_1465)) || (**g_1397)) != (*g_385)))) <= 0x814A78CAL), 0L)) && (*p_73))) || p_74), 14))))), l_1489)))
                { /* block id: 657 */
                    int32_t *l_1664 = (void*)0;
                    int32_t l_1665 = 6L;
                    int32_t *l_1666 = &g_266;
                    int32_t *l_1667[1][2][4];
                    int8_t *l_1685 = &g_260;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 2; j++)
                        {
                            for (k = 0; k < 4; k++)
                                l_1667[i][j][k] = &g_86;
                        }
                    }
                    --g_1668[1][0][1];
                    if ((l_1686 ^= (((l_1660 ^= 6UL) < ((safe_sub_func_int8_t_s_s_unsafe_macro/*156*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*157*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */((p_72 != ((safe_unary_minus_func_int32_t_s_unsafe_macro/*159*//* ___SAFE__OP */((l_1489 |= (p_74 >= (((*l_84) > p_72) < ((l_1496 = (l_1678 != (*g_366))) < (safe_div_func_int8_t_s_s_unsafe_macro/*160*//* ___SAFE__OP */(((*l_1440) &= p_72), ((safe_sub_func_uint64_t_u_u_unsafe_macro/*161*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*162*//* ___SAFE__OP */(((*l_1685) = p_72), p_74)) , 0x87C225557965D524LL), (-2L))) , p_72))))))))) && p_74)), 2)), l_1509)), (*l_1666))) & 2L)) >= p_74)))
                    { /* block id: 665 */
                        int64_t l_1690 = 0x45C9E0C1EFB2DC07LL;
                        int32_t l_1691 = 0x4C41C350L;
                        int32_t l_1694 = 0L;
                        int32_t l_1695 = 0x760F4B16L;
                        int32_t l_1696 = 0x4B07B66FL;
                        int32_t l_1697[1];
                        uint32_t l_1699 = 0x33D2841EL;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1697[i] = 0x70FD9AEEL;
                        if (p_74)
                            goto lbl_1687;
                        l_1699++;
                        return p_72;
                    }
                    else
                    { /* block id: 669 */
                        (**g_384) &= 0x349183B0L;
                        l_1660 |= ((*l_1666) &= (safe_lshift_func_int32_t_s_u_unsafe_macro/*163*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*164*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*165*//* ___SAFE__OP */(l_1689, l_1686)), (p_74 , (*g_1654)))), 23)));
                        return p_72;
                    }
                }
                else
                { /* block id: 675 */
                    int8_t l_1713 = 4L;
                    (*g_1191) |= ((+(l_1689 ^ (safe_add_func_uint16_t_u_u_unsafe_macro/*166*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u_unsafe_macro/*167*//* ___SAFE__OP */(p_72, (l_1713 = (*g_1654)))) == l_1689), ((*l_1663) ^= g_163))))) && ((safe_div_func_uint64_t_u_u_unsafe_macro/*168*//* ___SAFE__OP */((((+(safe_sub_func_int32_t_s_s_unsafe_macro/*169*//* ___SAFE__OP */(((***g_383) ^= 0xA834AB1FL), (~(l_1489 && ((safe_div_func_int32_t_s_s_unsafe_macro/*170*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*171*//* ___SAFE__OP */(((*l_1663) = l_1693[6]), 3)), ((***g_1174) ^= p_72))) ^ p_72)))))) > p_72) > (*g_29)), p_72)) || 0x19B2L));
                    (**l_1465) = &p_74;
                    (*g_1191) &= ((l_1724 != (void*)0) != (0x35473690CD443355LL | (*g_366)));
                }
                (*g_1726) = &g_552[3][2][4];
            }
        }
        else
        { /* block id: 687 */
            int64_t *** const l_1743 = &l_1742;
            int16_t l_1747 = 1L;
            int32_t *l_1776[4];
            uint32_t l_1779 = 4294967290UL;
            int8_t l_1782 = 0L;
            int i;
            for (i = 0; i < 4; i++)
                l_1776[i] = (void*)0;
lbl_1775:
            for (g_86 = 0; (g_86 > 4); g_86 = safe_add_func_int16_t_s_s_unsafe_macro/*172*//* ___SAFE__OP */(g_86, 1))
            { /* block id: 690 */
                int16_t l_1745 = 0x6D02L;
                uint16_t l_1746[6][3][10] = {{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}},{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}},{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}},{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}},{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}},{{1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L},{0UL,0x5554L,0UL,0x92C8L,1UL,0x92C8L,0UL,0x5554L,0UL,0x92C8L},{1UL,0x5554L,65533UL,0x5554L,1UL,0UL,1UL,0x5554L,65533UL,0x5554L}}};
                uint8_t **l_1751 = &l_1750;
                int i, j, k;
                l_1692 |= (safe_add_func_int32_t_s_s_unsafe_macro/*173*//* ___SAFE__OP */(((((~p_74) ^ (((((+(g_1734[3] , (p_74 && p_72))) || 0x6DC8D03C0D8B25EALL) && (safe_lshift_func_int8_t_s_s_unsafe_macro/*174*//* ___SAFE__OP */((0x67L != (((safe_rshift_func_uint64_t_u_s_unsafe_macro/*175*//* ___SAFE__OP */((((safe_add_func_uint16_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */((p_72 || (((((**g_1175) = ((l_1741 != l_1743) == 1L)) , l_1489) < 0xCA52C598CDBBC5B5LL) >= g_1744)), l_1745)) ^ 0x3B70BA3793E34451LL) , p_74), 36)) , l_1745) , l_1746[5][0][3])), 0))) , 3UL) > l_1747)) < (**g_384)) <= l_1746[5][0][3]), l_1746[2][2][2]));
                l_1751 = ((+l_1746[5][0][3]) , l_1749);
                if ((~(p_72 ^ p_72)))
                { /* block id: 694 */
                    const uint32_t l_1753 = 0xB90DDD18L;
                    (**g_384) ^= (l_1753 ^ (g_1754 , ((**l_1751)--)));
                }
                else
                { /* block id: 697 */
                    l_1774 &= ((safe_add_func_uint64_t_u_u_unsafe_macro/*177*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*178*//* ___SAFE__OP */(p_74, (!l_1648))), (safe_lshift_func_uint8_t_u_s_unsafe_macro/*179*//* ___SAFE__OP */(((**l_1749) |= p_72), 0)))) != ((safe_rshift_func_int64_t_s_u_unsafe_macro/*180*//* ___SAFE__OP */(0xDFA72D3A48FE9407LL, 26)) | (((l_1766 , ((safe_add_func_uint16_t_u_u_unsafe_macro/*181*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_s_unsafe_macro/*182*//* ___SAFE__OP */(l_1746[2][0][9], (l_1771 < (safe_mul_func_uint8_t_u_u_unsafe_macro/*183*//* ___SAFE__OP */(0x19L, (*l_84)))))) & p_74), 0xDE83L)) < (*g_1398))) <= l_1747) < p_72)));
                    if (l_1509)
                        goto lbl_1775;
                }
                (*g_385) = l_1661;
            }
            l_1779--;
            for (g_339 = 0; (g_339 <= 3); g_339 += 1)
            { /* block id: 707 */
                int64_t l_1783 = 2L;
                (**g_384) = l_1782;
                (*g_1191) = (((**g_1242) = (**g_1242)) == ((l_1509 && l_1783) , l_1784));
                (*g_385) = (*p_73);
                for (g_266 = 3; (g_266 >= 0); g_266 -= 1)
                { /* block id: 714 */
                    const uint8_t l_1785 = 0xD0L;
                    for (l_1747 = 4; (l_1747 >= 0); l_1747 -= 1)
                    { /* block id: 717 */
                        (***g_383) = l_1785;
                    }
                    return (***g_1174);
                }
            }
        }
    }
    return l_1786;
}


/* ------------------------------------------ */
/* 
 * reads : g_125 g_225 g_1396 g_1191 g_86 g_266 g_644 g_163 g_383 g_384 g_260 g_1335.f1 g_1432 g_782 g_903 g_898 g_261 g_30
 * writes: g_125 g_225 g_1396 g_86 g_238 g_266 g_644 g_163 g_385 g_260 g_1335.f1 g_1432 g_782 g_898
 */
static uint8_t  func_77(int64_t  p_78, int8_t  p_79, int64_t  p_80, int32_t ** p_81)
{ /* block id: 534 */
    uint8_t l_1406 = 0UL;
    int32_t *l_1412 = &g_30;
    int32_t l_1424 = (-1L);
    int32_t l_1425 = 0x902BC574L;
    int32_t l_1426[4] = {0xDA695D7CL,0xDA695D7CL,0xDA695D7CL,0xDA695D7CL};
    int64_t l_1427 = (-9L);
    int64_t **** const l_1436 = (void*)0;
    int64_t **** const *l_1435 = &l_1436;
    int i;
    for (g_125 = 29; (g_125 >= 60); g_125 = safe_add_func_uint8_t_u_u_unsafe_macro/*184*//* ___SAFE__OP */(g_125, 1))
    { /* block id: 537 */
        const uint64_t *l_1400[6][6][7] = {{{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[5][2][3],&g_339},{&g_39[4][6][1],&g_339,(void*)0,(void*)0,&g_39[1][3][0],&g_39[4][5][0],&g_339},{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[3][5][2],(void*)0},{&g_39[4][6][1],(void*)0,(void*)0,&g_339,&g_39[1][3][0],&g_39[4][0][2],&g_39[4][0][2]},{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[3][5][2],&g_339},{&g_39[1][3][0],&g_339,(void*)0,(void*)0,&g_39[4][6][1],&g_39[4][5][0],&g_39[4][0][2]}},{{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[5][2][3],(void*)0},{&g_39[1][3][0],(void*)0,(void*)0,&g_339,&g_39[4][6][1],&g_39[4][0][2],&g_339},{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[5][2][3],&g_339},{&g_39[4][6][1],&g_339,(void*)0,(void*)0,&g_39[1][3][0],&g_39[4][5][0],&g_339},{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[3][5][2],(void*)0},{&g_39[4][6][1],(void*)0,(void*)0,&g_339,&g_39[1][3][0],&g_39[4][0][2],&g_39[4][0][2]}},{{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[3][5][2],&g_339},{&g_39[1][3][0],&g_339,(void*)0,(void*)0,&g_39[4][6][1],&g_39[4][5][0],&g_39[4][0][2]},{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[5][2][3],(void*)0},{&g_39[1][3][0],(void*)0,(void*)0,&g_339,&g_39[4][6][1],&g_39[4][0][2],&g_339},{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[5][2][3],&g_339},{&g_39[4][6][1],&g_339,(void*)0,(void*)0,&g_39[1][3][0],&g_39[4][5][0],&g_339}},{{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[3][5][2],(void*)0},{&g_39[4][6][1],(void*)0,(void*)0,&g_339,&g_39[1][3][0],&g_39[4][0][2],&g_39[4][0][2]},{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[3][5][2],&g_339},{&g_39[1][3][0],&g_339,(void*)0,(void*)0,&g_39[4][6][1],&g_39[4][5][0],&g_39[4][0][2]},{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[5][2][3],(void*)0},{&g_39[1][3][0],(void*)0,(void*)0,&g_339,&g_39[4][6][1],&g_39[4][0][2],&g_339}},{{&g_339,&g_339,&g_39[5][8][3],&g_339,&g_339,&g_39[5][2][3],&g_339},{&g_39[4][6][1],&g_339,(void*)0,(void*)0,&g_39[1][3][0],&g_39[4][5][0],&g_339},{&g_339,&g_339,&g_39[3][1][0],&g_339,&g_339,&g_39[3][5][2],(void*)0},{&g_39[5][7][3],&g_339,&g_39[4][7][0],(void*)0,&g_39[4][5][0],(void*)0,(void*)0},{&g_39[1][6][2],(void*)0,&g_339,(void*)0,&g_39[1][6][2],&g_339,&g_39[5][8][3]},{&g_39[4][5][0],(void*)0,&g_39[4][7][0],&g_339,&g_39[5][7][3],&g_339,(void*)0}},{{(void*)0,(void*)0,&g_39[2][5][1],(void*)0,(void*)0,(void*)0,&g_39[3][1][0]},{&g_39[4][5][0],&g_339,&g_339,(void*)0,&g_39[5][7][3],(void*)0,(void*)0},{&g_39[1][6][2],(void*)0,&g_339,(void*)0,&g_39[1][6][2],(void*)0,&g_39[5][8][3]},{&g_39[5][7][3],(void*)0,&g_339,&g_339,&g_39[4][5][0],&g_339,(void*)0},{(void*)0,(void*)0,&g_39[2][5][1],(void*)0,(void*)0,&g_339,&g_39[3][1][0]},{&g_39[5][7][3],&g_339,&g_39[4][7][0],(void*)0,&g_39[4][5][0],(void*)0,(void*)0}}};
        int32_t l_1403 = 0x4B6D9554L;
        int i, j, k;
        for (g_225 = 0; (g_225 == (-3)); --g_225)
        { /* block id: 540 */
            uint16_t *l_1404 = &g_238;
            g_1396 = g_1396;
            (*g_1191) &= (-2L);
            (*g_1191) ^= ((((void*)0 == l_1400[3][3][5]) , (((*l_1404) = l_1403) | (0xBAECL > p_78))) >= (!l_1406));
            for (g_266 = 0; (g_266 <= (-12)); g_266 = safe_sub_func_int16_t_s_s_unsafe_macro/*185*//* ___SAFE__OP */(g_266, 5))
            { /* block id: 547 */
                uint32_t l_1411 = 0x684C8557L;
                for (g_644 = (-29); (g_644 > 22); g_644++)
                { /* block id: 550 */
                    (*g_1191) &= l_1411;
                }
                (*g_1191) ^= 1L;
            }
        }
    }
    for (g_163 = 0; (g_163 <= 0); g_163 += 1)
    { /* block id: 559 */
        int16_t l_1413[4] = {0L,0L,0L,0L};
        int i;
        l_1412 = ((**g_383) = l_1412);
        for (g_260 = 0; (g_260 >= 0); g_260 -= 1)
        { /* block id: 564 */
            return l_1413[1];
        }
    }
    for (g_1335.f1 = 0; (g_1335.f1 <= 2); g_1335.f1 += 1)
    { /* block id: 570 */
        int32_t *l_1415 = &g_266;
        int32_t *l_1416 = (void*)0;
        int32_t *l_1417 = &g_266;
        int32_t *l_1418 = &g_86;
        int32_t *l_1419 = &g_86;
        int32_t *l_1420 = &g_266;
        int32_t *l_1421 = (void*)0;
        int32_t *l_1422 = &g_1117[0][0][0];
        int32_t *l_1423[10][7][3] = {{{(void*)0,&g_86,&g_1117[6][1][1]},{&g_30,&g_266,&g_30},{&g_86,(void*)0,(void*)0},{(void*)0,&g_86,&g_30},{&g_86,&g_86,&g_30},{&g_86,&g_86,&g_1117[6][1][1]},{(void*)0,&g_86,&g_225}},{{&g_225,&g_86,&g_1117[7][2][0]},{&g_266,&g_86,&g_266},{(void*)0,&g_86,&g_1117[6][1][1]},{&g_86,(void*)0,(void*)0},{&g_1117[6][1][1],&g_266,&g_225},{&g_225,&g_86,&g_1117[3][3][0]},{&g_86,&g_30,&g_266}},{{&g_1117[3][2][0],&g_1117[3][2][1],(void*)0},{&g_266,&g_266,(void*)0},{&g_1117[8][3][1],&g_86,&g_266},{&g_1117[6][1][1],&g_225,&g_86},{&g_1117[2][0][1],&g_86,&g_266},{&g_86,&g_1117[6][1][1],&g_86},{&g_30,&g_225,&g_266}},{{&g_266,&g_1117[6][1][1],(void*)0},{(void*)0,(void*)0,(void*)0},{&g_225,&g_1117[6][1][1],&g_266},{&g_225,&g_266,&g_1117[3][3][0]},{&g_86,(void*)0,&g_225},{(void*)0,&g_30,(void*)0},{&g_1117[6][1][1],&g_30,&g_1117[6][1][1]}},{{&g_266,&g_1117[3][2][0],&g_266},{&g_1117[2][1][0],&g_266,&g_1117[7][2][0]},{&g_225,&g_266,&g_225},{&g_225,&g_30,&g_1117[6][1][1]},{&g_225,&g_1117[6][1][1],&g_30},{&g_1117[2][1][0],&g_1117[6][1][1],&g_30},{&g_266,&g_86,(void*)0}},{{&g_1117[6][1][1],&g_30,&g_30},{(void*)0,&g_266,&g_1117[6][1][1]},{&g_86,&g_266,&g_225},{&g_225,&g_1117[6][2][0],&g_266},{&g_225,&g_1117[6][1][1],&g_1117[6][1][1]},{(void*)0,(void*)0,&g_225},{&g_30,&g_30,&g_1117[6][1][1]}},{{&g_225,&g_86,&g_1117[2][0][1]},{&g_30,(void*)0,&g_86},{&g_225,&g_86,&g_30},{&g_30,&g_30,&g_266},{&g_86,&g_86,(void*)0},{&g_266,&g_266,&g_225},{&g_1117[2][0][1],(void*)0,&g_225}},{{&g_1117[7][2][0],&g_30,&g_86},{&g_86,&g_1117[3][2][0],(void*)0},{&g_225,&g_266,&g_1117[6][1][1]},{(void*)0,(void*)0,&g_266},{&g_266,(void*)0,&g_1117[2][1][0]},{&g_266,&g_225,&g_225},{&g_30,&g_225,&g_225}},{{(void*)0,&g_266,&g_225},{&g_266,(void*)0,&g_1117[2][1][0]},{&g_1117[3][2][1],&g_1117[2][0][1],&g_266},{&g_30,&g_266,&g_1117[6][1][1]},{&g_266,&g_266,(void*)0},{(void*)0,&g_1117[6][1][1],&g_86},{&g_86,&g_266,&g_225}},{{&g_1117[6][1][1],&g_1117[6][1][1],&g_225},{(void*)0,&g_1117[6][2][0],(void*)0},{&g_225,&g_225,&g_266},{&g_1117[6][3][0],&g_266,&g_30},{(void*)0,&g_30,&g_86},{&g_225,&g_1117[6][1][1],&g_1117[2][0][1]},{(void*)0,&g_86,&g_1117[6][1][1]}}};
        int16_t l_1428 = 0x457EL;
        int8_t l_1430 = 0x5CL;
        int i, j, k;
        g_1432--;
        for (l_1427 = 2; (l_1427 >= 0); l_1427 -= 1)
        { /* block id: 574 */
            for (g_782 = 3; (g_782 >= 0); g_782 -= 1)
            { /* block id: 577 */
                int i, j, k;
                (*g_903) = (*g_903);
                if (g_261[(g_782 + 6)][g_782][g_1335.f1])
                    break;
            }
            if (p_80)
                continue;
            for (p_78 = 0; (p_78 <= 2); p_78 += 1)
            { /* block id: 584 */
                int i, j, k;
                return g_261[(p_78 + 6)][l_1427][g_1335.f1];
            }
        }
    }
    l_1435 = l_1435;
    return (*l_1412);
}


/* ------------------------------------------ */
/* 
 * reads : g_86 g_22 g_1242 g_1243 g_782 g_261 g_366 g_85 g_385 g_384
 * writes: g_86 g_76 g_39 g_339 g_385
 */
static int64_t  func_82(const int32_t * p_83)
{ /* block id: 39 */
    int32_t *l_99 = (void*)0;
    uint32_t ***l_1260 = &g_1175;
    uint8_t l_1271 = 255UL;
    int32_t l_1273 = 0x4A368705L;
    uint32_t l_1289 = 0x4123B0E2L;
    int16_t *l_1324 = &g_263[1][3][1];
    union U0 ** const *l_1354 = &g_1352;
    uint32_t ****l_1371 = &g_1114;
    int8_t *l_1377 = &g_76[1];
    uint64_t *l_1378 = &g_339;
    for (g_86 = (-3); (g_86 >= (-19)); g_86 = safe_sub_func_uint64_t_u_u_unsafe_macro/*186*//* ___SAFE__OP */(g_86, 6))
    { /* block id: 42 */
        int64_t l_1216 = 0x7089F316ACC3B6CELL;
        const int32_t l_1217 = 1L;
        const int32_t **l_1218 = &g_309[0][0][3];
        int32_t *l_1252 = &g_266;
        union U0 ****l_1353 = &g_1351;
        union U0 ** const **l_1355[6][1][1] = {{{&l_1354}},{{&l_1354}},{{&l_1354}},{{&l_1354}},{{&l_1354}},{{&l_1354}}};
        int64_t *l_1362 = &g_443;
        int i, j, k;
    }
    if (g_86)
        goto lbl_1379;
lbl_1379:
    (*g_385) = (safe_mod_func_uint64_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */((l_1273 & (safe_sub_func_uint64_t_u_u_unsafe_macro/*188*//* ___SAFE__OP */(((*l_1378) = ((*g_366) = (safe_sub_func_int32_t_s_s_unsafe_macro/*189*//* ___SAFE__OP */((*p_83), (safe_mul_func_int32_t_s_s_unsafe_macro/*190*//* ___SAFE__OP */((l_1289 == 0xF5A201D63F0E6ADDLL), (((((void*)0 == l_1371) > (65534UL <= (safe_unary_minus_func_int8_t_s_unsafe_macro/*191*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*192*//* ___SAFE__OP */(l_1271, (((((*l_1377) = ((((((*g_1242) != &l_1260) || l_1273) , p_83) != p_83) == l_1289)) && g_782) == g_261[1][0][0]) , 1UL))))))) && l_1289) && 0L))))))), g_85))), l_1271));
    (*g_384) = &l_1273;
    return l_1273;
}


/* ------------------------------------------ */
/* 
 * reads : g_339 g_1174 g_1175 g_337 g_190 g_265 g_366 g_1117 g_22
 * writes: g_339 g_265 g_190 g_260 g_39 g_1117 g_1242
 */
static uint32_t  func_93(int32_t * p_94, uint8_t  p_95, const int32_t * p_96, int32_t ** p_97, int32_t ** p_98)
{ /* block id: 459 */
    uint8_t *l_1230 = &g_1209;
    int32_t l_1240 = 1L;
    uint32_t *****l_1241 = (void*)0;
    for (g_339 = (-5); (g_339 == 20); g_339 = safe_add_func_int16_t_s_s_unsafe_macro/*193*//* ___SAFE__OP */(g_339, 2))
    { /* block id: 462 */
        const uint32_t l_1221[8][7] = {{0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L},{0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL},{0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L},{0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL},{0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L},{0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL},{0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L,0xFC29E887L,0x13E85801L},{0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL,0x9306E6FEL}};
        int32_t l_1222 = 0xAA5A3D62L;
        int8_t *l_1231 = &g_265;
        int8_t *l_1238 = &g_260;
        int32_t *l_1239 = &g_1117[8][3][1];
        int i, j;
        l_1222 |= (((void*)0 == &g_1131) ^ l_1221[7][5]);
        (*l_1239) |= (((*g_366) = (safe_mul_func_int16_t_s_s_unsafe_macro/*194*//* ___SAFE__OP */(((l_1221[6][3] <= (safe_mul_func_int8_t_s_s_unsafe_macro/*195*//* ___SAFE__OP */(((*l_1231) = (safe_mul_func_int16_t_s_s_unsafe_macro/*196*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*197*//* ___SAFE__OP */(((void*)0 == l_1230))), p_95))), (safe_lshift_func_int16_t_s_s_unsafe_macro/*198*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_u_unsafe_macro/*199*//* ___SAFE__OP */((p_95 | ((*l_1238) = ((l_1221[7][5] , ((safe_sub_func_uint8_t_u_u_unsafe_macro/*200*//* ___SAFE__OP */((((***g_1174) &= (p_95 < l_1221[3][2])) , 246UL), l_1221[7][5])) < 0L)) >= 1UL))), 17)) >= 4294967295UL), p_95))))) , g_265), 3L))) == 18446744073709551614UL);
    }
    l_1240 = (*p_96);
    g_1242 = (l_1241 = l_1241);
    return p_95;
}


/* ------------------------------------------ */
/* 
 * reads : g_86 g_39 g_30 g_126 g_22 g_76 g_159 g_125 g_339 g_29 g_353 g_285.f0 g_261 g_265 g_375 g_381 g_383 g_366 g_225 g_384 g_385 g_163 g_260 g_381.f0 g_206 g_240.f0 g_190 g_263 g_266 g_337 g_238 g_742 g_781
 * writes: g_125 g_163 g_339 g_263 g_366 g_238 g_29 g_39 g_385 g_261 g_552 g_260 g_266 g_190 g_225 g_782
 */
static int32_t  func_100(int32_t * p_101, uint8_t  p_102)
{ /* block id: 43 */
    int32_t ** const l_109 = (void*)0;
    int32_t **l_123 = &g_29;
    int32_t ***l_122 = &l_123;
    uint32_t *l_124 = &g_125;
    int64_t l_161 = 0xDBEEBB44E65D69ADLL;
    int32_t l_169[9] = {0x177B9BCBL,0x0ABD1851L,0x177B9BCBL,0x177B9BCBL,0x0ABD1851L,0x177B9BCBL,0x177B9BCBL,0x0ABD1851L,0x177B9BCBL};
    int32_t l_180 = 0xF41E0E37L;
    int64_t l_274[1][10];
    uint8_t l_277 = 0xAFL;
    union U0 *l_350 = &g_240[3][5][0];
    union U0 **l_349[5][7][7];
    int32_t *l_382 = &g_86;
    const uint64_t l_487 = 0x7661A4E2393803AELL;
    uint32_t l_512 = 0x406F166AL;
    int64_t l_520 = 0xB5806814153483DFLL;
    int16_t *l_560[1][8][5] = {{{(void*)0,&g_263[5][5][0],&g_263[4][7][2],&g_263[5][5][0],&g_263[5][5][0]},{&g_263[5][5][0],&g_261[8][6][0],&g_263[5][5][0],&g_263[4][7][2],(void*)0},{&g_261[0][5][2],&g_261[8][6][0],&g_263[5][5][0],(void*)0,&g_263[5][5][0]},{&g_261[0][5][2],&g_263[5][5][0],&g_263[5][5][0],&g_263[5][5][0],&g_261[0][5][2]},{(void*)0,&g_263[5][5][0],&g_263[5][5][0],&g_263[5][5][0],(void*)0},{&g_261[0][5][2],(void*)0,&g_263[5][5][0],&g_263[5][5][0],&g_263[5][5][0]},{&g_263[1][5][1],&g_261[0][5][2],&g_263[4][7][2],&g_263[5][5][0],&g_263[5][5][0]},{(void*)0,(void*)0,&g_263[5][5][0],&g_263[1][5][1],&g_263[5][5][0]}}};
    int32_t l_577 = (-1L);
    const int64_t l_589 = 1L;
    int32_t *l_639 = (void*)0;
    int64_t *l_753 = &g_443;
    int64_t **l_752 = &l_753;
    int64_t ***l_751[3];
    int64_t **** const l_750 = &l_751[1];
    int64_t **** const *l_749 = &l_750;
    const int16_t l_757[8] = {0xA424L,0xA424L,0xA424L,0xA424L,0xA424L,0xA424L,0xA424L,0xA424L};
    int32_t *l_779[6][6] = {{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0},{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0},{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0},{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0},{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0},{(void*)0,&g_225,(void*)0,(void*)0,&g_225,(void*)0}};
    uint32_t l_780 = 0UL;
    int64_t **l_806 = (void*)0;
    uint8_t l_807 = 0x61L;
    int8_t **l_822 = &g_553;
    int64_t l_839[5][10] = {{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)}};
    uint32_t l_849 = 18446744073709551615UL;
    uint8_t l_874 = 253UL;
    int32_t * const *l_928 = (void*)0;
    uint64_t l_968 = 3UL;
    uint32_t l_974 = 0x1914A354L;
    int32_t l_987 = 2L;
    int64_t l_1044 = (-6L);
    uint32_t ***l_1133 = &g_1115;
    uint8_t l_1164 = 255UL;
    int64_t * const *l_1192 = &l_753;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
            l_274[i][j] = 0x39C1A3CEE7E9B0A2LL;
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 7; k++)
                l_349[i][j][k] = &l_350;
        }
    }
    for (i = 0; i < 3; i++)
        l_751[i] = &l_752;
    if ((safe_mul_func_int64_t_s_s_unsafe_macro/*201*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*202*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(((&p_101 != l_109) && (((0xBAL == ((*p_101) && (safe_add_func_int8_t_s_s_unsafe_macro/*204*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*205*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*206*//* ___SAFE__OP */((((*l_124) = ((0x61D1304DL || (safe_div_func_uint32_t_u_u_unsafe_macro/*207*//* ___SAFE__OP */(g_39[2][1][0], (safe_lshift_func_int64_t_s_s_unsafe_macro/*208*//* ___SAFE__OP */(g_30, (safe_add_func_int8_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */(p_102, (((*l_122) = &g_29) == (void*)0)))))))) && 0x0E1B1DC0L)) || g_126), p_102)), g_30)), p_102)))) ^ p_102) ^ p_102)), g_22)) <= p_102), p_102)), 1L)))
    { /* block id: 46 */
        uint8_t l_135[10][6][3] = {{{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL}},{{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L}},{{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL}},{{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L}},{{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL}},{{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L}},{{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL}},{{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L}},{{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL}},{{0UL,1UL,1UL},{0x18L,0x32L,0x18L},{0UL,0UL,1UL},{0x8FL,0x32L,0x8FL},{0UL,1UL,1UL},{0x18L,0x32L,0x18L}}};
        int32_t **l_158 = (void*)0;
        uint8_t *l_162 = &g_163;
        uint32_t l_164[4];
        int32_t l_167 = 0xE6A1E35DL;
        int32_t l_168 = 0x3B03AC48L;
        int32_t l_170 = 0x794C979CL;
        int32_t l_171 = 0x47C53A19L;
        int32_t l_172 = 1L;
        int32_t l_173 = 0xB3BEAB6EL;
        int32_t l_174 = 0x47BEB803L;
        int32_t l_175 = 0x60EB3D4AL;
        int32_t l_176 = 0x3619917FL;
        int32_t l_177 = 2L;
        int32_t l_178 = 0xF498FB1DL;
        int32_t l_179 = 0xD7050356L;
        int32_t l_181[8][1] = {{(-1L)},{(-3L)},{(-1L)},{(-3L)},{(-1L)},{(-3L)},{(-1L)},{(-3L)}};
        uint64_t l_182 = 18446744073709551615UL;
        const uint32_t *l_189[1][9];
        int32_t *l_226 = &l_175;
        uint16_t l_236[2][8] = {{65535UL,65535UL,0x2756L,65535UL,0x2756L,65535UL,65535UL,0x2756L},{0UL,0x2756L,0x2756L,0UL,65535UL,0UL,0x2756L,0x2756L}};
        union U0 *l_239[6] = {&g_240[3][5][0],(void*)0,(void*)0,&g_240[3][5][0],(void*)0,(void*)0};
        int32_t l_273 = 0x64FD8085L;
        int8_t l_419 = 2L;
        uint32_t l_473 = 4294967288UL;
        uint8_t l_508[1][2][2];
        int16_t *l_515 = &g_261[0][5][2];
        uint32_t l_563[10][3] = {{0xE29F5CE1L,0xE29F5CE1L,0xE29F5CE1L},{0x89E46A2AL,9UL,0x89E46A2AL},{0xE29F5CE1L,0xE29F5CE1L,0xE29F5CE1L},{0x89E46A2AL,9UL,0x89E46A2AL},{0xE29F5CE1L,0xE29F5CE1L,0xE29F5CE1L},{0x89E46A2AL,9UL,0x89E46A2AL},{0xE29F5CE1L,0xE29F5CE1L,0xE29F5CE1L},{0x89E46A2AL,9UL,0x89E46A2AL},{0xE29F5CE1L,0xE29F5CE1L,0xE29F5CE1L},{0x89E46A2AL,9UL,0x89E46A2AL}};
        uint64_t l_636[8][1] = {{0xE15DBBECF98BE9E8LL},{2UL},{0xE15DBBECF98BE9E8LL},{2UL},{0xE15DBBECF98BE9E8LL},{2UL},{0xE15DBBECF98BE9E8LL},{2UL}};
        int64_t *l_716 = &l_161;
        int64_t **l_715[3];
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_164[i] = 0x115AF14BL;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 9; j++)
                l_189[i][j] = &g_125;
        }
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
            {
                for (k = 0; k < 2; k++)
                    l_508[i][j][k] = 0x18L;
            }
        }
        for (i = 0; i < 3; i++)
            l_715[i] = &l_716;
        if ((((safe_lshift_func_uint32_t_u_s_unsafe_macro/*210*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*211*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*212*//* ___SAFE__OP */(((((safe_lshift_func_int64_t_s_s_unsafe_macro/*213*//* ___SAFE__OP */(l_135[4][2][2], 25)) >= (((((*l_162) = (safe_mul_func_uint64_t_u_u_unsafe_macro/*214*//* ___SAFE__OP */(p_102, (((safe_sub_func_uint16_t_u_u_unsafe_macro/*215*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*216*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*217*//* ___SAFE__OP */((g_76[4] | p_102), 0)), 4)), (safe_div_func_int32_t_s_s_unsafe_macro/*218*//* ___SAFE__OP */(0xAEB11F9AL, ((safe_add_func_uint16_t_u_u_unsafe_macro/*219*//* ___SAFE__OP */(((((safe_mod_func_uint16_t_u_u_unsafe_macro/*220*//* ___SAFE__OP */(0UL, (safe_add_func_int64_t_s_s_unsafe_macro/*221*//* ___SAFE__OP */(((safe_lshift_func_uint32_t_u_s_unsafe_macro/*222*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*223*//* ___SAFE__OP */(((p_102 , (safe_mul_func_uint16_t_u_u_unsafe_macro/*224*//* ___SAFE__OP */(((((((*l_122) = &g_29) == l_158) , g_159[0]) == (void*)0) , p_102), p_102))) ^ g_76[4]), l_161)) >= (*p_101)), (*p_101))) > g_86), g_30)))) ^ 0x6C70737CL) <= l_135[4][2][2]) & p_102), 0x07CCL)) | 4294967295UL))))) >= p_102) >= (-3L))))) ^ p_102) >= 7UL) < l_164[3])) < 1UL) > 0x1D37L), 8L)), 65527UL)), (*p_101))) | (-1L)) & g_125))
        { /* block id: 49 */
            int64_t l_165[9];
            int32_t *l_166[4];
            uint64_t *l_199 = &l_182;
            int64_t *l_200 = &l_161;
            int64_t *l_201[8];
            uint32_t l_217 = 1UL;
            int8_t *l_284[10] = {&g_265,&g_265,&g_76[4],&g_265,&g_265,&g_76[4],&g_265,&g_265,&g_76[4],&g_265};
            uint32_t l_300 = 0xD64598ADL;
            int i;
            for (i = 0; i < 9; i++)
                l_165[i] = 1L;
            for (i = 0; i < 4; i++)
                l_166[i] = (void*)0;
            for (i = 0; i < 8; i++)
                l_201[i] = &l_165[5];
            l_182++;
        }
        else
        { /* block id: 131 */
            return g_339;
        }
        for (g_339 = 0; (g_339 <= 1); g_339 += 1)
        { /* block id: 136 */
            uint8_t *l_351 = &g_163;
            uint8_t **l_352 = &l_162;
            int32_t l_358 = 0x2AC8EA3EL;
            int16_t *l_359 = (void*)0;
            int16_t *l_360 = &g_263[0][4][3];
            int32_t l_441 = (-1L);
            int32_t l_442 = (-6L);
            int32_t l_444 = 0xDD2896B2L;
            int32_t l_445 = 8L;
            int32_t l_446[9][9] = {{5L,(-4L),0xBC73892AL,0x3E292FA8L,0xBC73892AL,(-4L),5L,(-1L),0x0FABB8BAL},{0xEE907134L,0x8A2227ABL,0x23948133L,0x62190C79L,(-1L),0x84D747E7L,0xFD8D2CE3L,0xEE907134L,0x62190C79L},{0x3945B35EL,0xBC73892AL,(-1L),0x84D747E7L,(-3L),0x7E56094BL,0x23948133L,0xEE907134L,0x1FB2CBE2L},{0xD6A05840L,0xEE907134L,(-7L),0x3624F4D2L,0xBC73892AL,(-9L),0xEE907134L,(-1L),0xEE907134L},{0x3945B35EL,9L,(-7L),(-7L),9L,0x3945B35EL,(-3L),0x594A9BF0L,0xFD8D2CE3L},{(-1L),(-1L),0xEE907134L,0x594A9BF0L,0x13DB2E52L,1L,0xD6A05840L,0x3945B35EL,0L},{0x1FB2CBE2L,0x25C6C34BL,0x7E56094BL,0x84D747E7L,(-3L),0x53A6F66EL,(-3L),0x1FB2CBE2L,0x13DB2E52L},{0x3E292FA8L,0x3945B35EL,0x13DB2E52L,0x53A6F66EL,0x25C6C34BL,0xB7A5742FL,0xEE907134L,0xEE907134L,0xB7A5742FL},{1L,0x3945B35EL,0xDE95CDB9L,0x3945B35EL,1L,(-9L),0x23948133L,0xFD8D2CE3L,0x3945B35EL}};
            union U0 *l_458[9];
            int64_t *l_492[3][6][8] = {{{&g_443,&g_443,&l_161,&l_274[0][2],&l_161,&l_274[0][3],&g_443,&l_274[0][3]},{&l_274[0][4],&l_161,&l_161,&g_443,&g_443,&l_161,&g_443,&g_443},{&l_161,&g_443,&l_161,&l_274[0][3],(void*)0,&g_443,&l_274[0][4],&g_443},{(void*)0,&g_443,&l_274[0][4],&g_443,&l_161,&l_274[0][3],(void*)0,&l_274[0][3]},{(void*)0,&l_274[0][2],&l_161,&l_274[0][2],(void*)0,&l_161,&l_274[0][4],&l_161},{&l_161,&l_274[0][2],&l_161,&l_274[0][3],&g_443,&l_274[0][3],&l_274[0][4],&l_274[0][2]}},{{&l_274[0][4],&g_443,&l_161,&l_161,&l_161,&g_443,&l_274[0][4],&l_274[0][3]},{&g_443,&g_443,&l_161,&l_161,&l_274[0][4],&l_161,(void*)0,&l_274[0][2]},{&l_161,&l_161,&l_274[0][4],&l_274[0][3],&l_274[0][4],&l_274[0][3],&l_274[0][4],&l_161},{&g_443,&g_443,&l_161,&l_274[0][2],&l_161,&l_274[0][3],&g_443,&l_274[0][3]},{&l_274[0][4],&l_161,&l_161,&g_443,&g_443,&l_161,&g_443,&g_443},{&l_161,&g_443,&l_161,&l_274[0][3],(void*)0,&g_443,&l_274[0][4],&g_443}},{{(void*)0,&g_443,&l_274[0][4],&g_443,&l_161,&l_274[0][3],(void*)0,&l_274[0][3]},{(void*)0,&l_274[0][2],&l_161,&l_274[0][2],(void*)0,&l_161,&l_274[0][4],&l_161},{&l_161,&l_274[0][2],&l_161,&l_274[0][3],&g_443,&l_274[0][3],&l_274[0][4],&l_274[0][2]},{&l_274[0][4],&g_443,&l_161,&l_161,&l_161,&g_443,&l_274[0][4],&l_274[0][3]},{&g_443,&g_443,&l_161,&l_161,&l_161,&l_161,&l_274[0][4],&l_274[0][3]},{(void*)0,&l_274[0][3],&l_161,&l_274[0][9],&l_161,&l_274[0][9],&l_161,&l_274[0][3]}}};
            int64_t **l_491 = &l_492[0][5][1];
            uint16_t *l_507 = &l_236[1][7];
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_458[i] = &g_240[5][3][0];
            if ((((safe_mul_func_int8_t_s_s_unsafe_macro/*225*//* ___SAFE__OP */((**l_123), ((safe_rshift_func_int16_t_s_s_unsafe_macro/*226*//* ___SAFE__OP */((+(((safe_mul_func_int16_t_s_s_unsafe_macro/*227*//* ___SAFE__OP */(((*l_360) = ((safe_div_func_int32_t_s_s_unsafe_macro/*228*//* ___SAFE__OP */(((l_349[4][5][1] != (((0xD7D5L < ((l_351 = &p_102) != ((*l_352) = &g_163))) == ((*p_101) != (*p_101))) , g_353)) , (((safe_unary_minus_func_int64_t_s_unsafe_macro/*229*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*230*//* ___SAFE__OP */(g_30, p_102)))) != g_39[1][8][1]) < g_285.f0)), l_358)) == (**l_123))), g_76[0])) <= 4294967286UL) && 0x29L)), 14)) , g_261[1][2][1]))) || 2UL) == g_76[4]))
            { /* block id: 140 */
                union U0 **l_364 = &l_350;
                int32_t l_367 = 0x4C543D13L;
                uint16_t *l_368 = (void*)0;
                int32_t l_369 = (-1L);
                int64_t *l_371 = &l_274[0][9];
                uint32_t *l_372[6][6];
                int i, j;
                for (i = 0; i < 6; i++)
                {
                    for (j = 0; j < 6; j++)
                        l_372[i][j] = &g_190[0];
                }
                (*l_226) = (safe_mul_func_uint64_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */(g_86, (!(((void*)0 == l_364) , (safe_unary_minus_func_int64_t_s_unsafe_macro/*232*//* ___SAFE__OP */((((g_366 = &g_39[3][8][2]) != (((((l_367 = ((*l_124) = ((g_238 = (l_369 &= (l_367 , (((void*)0 == &l_236[0][0]) < 252UL)))) == ((((((*l_371) = ((+g_285.f0) >= 0L)) | p_102) , 1UL) <= 0xF7C3BD085FA09138LL) == (*g_29))))) , g_265) > l_358) <= 0x0CAE74D289BE4ABELL) , &g_339)) != g_22)))))));
                return l_367;
            }
            else
            { /* block id: 149 */
                int32_t **l_378 = &g_29;
                int16_t l_394 = 9L;
                int64_t *l_416 = &l_274[0][8];
                int32_t l_423 = 5L;
                int32_t l_433 = 0x57323E96L;
                int32_t l_440[3];
                uint16_t l_447 = 0UL;
                uint32_t l_464 = 0UL;
                const int64_t *l_484 = (void*)0;
                const int64_t **l_483 = &l_484;
                const int64_t ***l_482 = &l_483;
                int8_t l_488[9];
                uint16_t *l_506[2];
                int i;
                for (i = 0; i < 3; i++)
                    l_440[i] = 1L;
                for (i = 0; i < 9; i++)
                    l_488[i] = 7L;
                for (i = 0; i < 2; i++)
                    l_506[i] = &g_238;
                if ((safe_rshift_func_uint32_t_u_u_unsafe_macro/*233*//* ___SAFE__OP */((g_375 , (safe_div_func_int8_t_s_s_unsafe_macro/*234*//* ___SAFE__OP */((l_378 == ((safe_lshift_func_int8_t_s_s_unsafe_macro/*235*//* ___SAFE__OP */((((g_381 , p_101) == ((*l_123) = l_382)) <= ((((*p_101) <= (&l_378 != g_383)) , (safe_mul_func_int16_t_s_s_unsafe_macro/*236*//* ___SAFE__OP */(((*l_360) = (safe_mul_func_int32_t_s_s_unsafe_macro/*237*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*238*//* ___SAFE__OP */((((safe_sub_func_int64_t_s_s_unsafe_macro/*239*//* ___SAFE__OP */(p_102, l_394)) >= (*g_366)) || 0x19L), (*l_226))), (*p_101)))), g_225))) || p_102)), 0)) , &p_101)), p_102))), p_102)))
                { /* block id: 152 */
                    const uint8_t l_403 = 252UL;
                    int32_t l_417 = 0x092C5E4AL;
                    int32_t *l_424 = &l_177;
                    int32_t *l_425 = &l_358;
                    int32_t *l_426 = &l_178;
                    int32_t *l_427 = &l_175;
                    int32_t *l_428 = &l_169[2];
                    int32_t *l_429 = (void*)0;
                    int32_t *l_430 = &l_171;
                    int32_t *l_431 = &l_169[6];
                    int32_t *l_432 = &l_181[0][0];
                    int32_t *l_434 = &l_175;
                    int32_t *l_435 = (void*)0;
                    int32_t *l_436 = &l_167;
                    int32_t *l_437 = &l_167;
                    int32_t *l_438 = &l_358;
                    int32_t *l_439[6][8] = {{&l_169[5],&l_171,&l_169[5],&l_170,&g_30,&l_173,&l_170,&l_172},{&g_266,&l_358,&l_170,&g_86,(void*)0,&g_30,&g_30,(void*)0},{&g_266,&l_423,&l_423,&g_266,&g_30,&g_86,&l_169[8],&l_173},{&l_169[5],&l_181[0][0],&g_86,&l_170,&l_423,&l_171,&l_173,&l_171},{&l_174,&l_181[0][0],&l_169[8],&l_181[0][0],&l_174,&g_86,&g_266,&l_181[4][0]},{&g_86,&l_423,&l_174,&l_172,(void*)0,&g_30,&l_181[0][0],&l_181[0][0]}};
                    int i, j;
                    for (g_238 = (-11); (g_238 < 30); g_238++)
                    { /* block id: 155 */
                        uint16_t *l_404 = &l_236[0][0];
                        uint16_t *l_405[8][2] = {{&g_238,(void*)0},{&g_238,&g_238},{(void*)0,&g_238},{&g_238,(void*)0},{&g_238,&g_238},{(void*)0,&g_238},{&g_238,(void*)0},{&g_238,&g_238}};
                        int32_t l_418 = 0x659DBCF3L;
                        int64_t *l_420 = &l_161;
                        int i, j;
                        if ((***g_383))
                            break;
                        (*l_226) = ((safe_add_func_int8_t_s_s_unsafe_macro/*240*//* ___SAFE__OP */((((*l_420) &= ((*l_416) = (((((safe_lshift_func_uint16_t_u_u_unsafe_macro/*241*//* ___SAFE__OP */((l_358 = ((*l_404) = ((***l_122) != l_403))), 1)) | (p_102 == ((*g_366) = (p_102 >= (safe_add_func_int8_t_s_s_unsafe_macro/*242*//* ___SAFE__OP */(0x65L, ((safe_sub_func_uint64_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */((((safe_mul_func_uint16_t_u_u_unsafe_macro/*244*//* ___SAFE__OP */((((p_102 < (safe_mod_func_int8_t_s_s_unsafe_macro/*245*//* ___SAFE__OP */((l_417 = ((safe_add_func_uint32_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */((*l_226), (**l_378))) ^ ((void*)0 == l_416))), p_102))) , p_102) > (**l_123)), g_163)) , 1UL) , l_418), (*g_366))) && l_419))))))) <= p_102) > 0UL) , 0x8F0C9E56B5A29B97LL))) == g_260), 0x00L)) , (*p_101));
                        if ((*p_101))
                            break;
                        (*l_226) |= ((***l_122) > p_102);
                    }
                    (*l_226) = (safe_sub_func_uint32_t_u_u_unsafe_macro/*247*//* ___SAFE__OP */(0x8170436DL, (0xB8L & ((void*)0 != &g_263[5][5][0]))));
                    ++l_447;
                }
                else
                { /* block id: 169 */
                    int8_t *l_457 = &g_265;
                    const int32_t l_463 = (-3L);
                    int32_t l_466 = 0x427DF7E9L;
                    union U0 **l_500[7] = {&l_239[3],&l_239[3],&l_239[3],&l_239[3],&l_239[3],&l_239[3],&l_239[3]};
                    int i;
                    if ((*p_101))
                    { /* block id: 170 */
                        int8_t *l_454 = (void*)0;
                        int8_t *l_456 = (void*)0;
                        int8_t **l_455[4][3];
                        int32_t l_465 = 0xE77A5EA8L;
                        uint8_t *l_485 = &l_277;
                        uint16_t *l_486 = &l_447;
                        int i, j;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_455[i][j] = &l_456;
                        }
                        l_466 = (((((safe_add_func_int32_t_s_s_unsafe_macro/*248*//* ___SAFE__OP */((g_30 == (p_102 , (safe_div_func_uint8_t_u_u_unsafe_macro/*249*//* ___SAFE__OP */(((l_454 = &l_419) == (l_457 = l_351)), (((void*)0 != l_458[3]) | (((((**l_378) >= (safe_rshift_func_uint64_t_u_u_unsafe_macro/*250*//* ___SAFE__OP */((*g_366), ((((((((safe_rshift_func_int32_t_s_u_unsafe_macro/*251*//* ___SAFE__OP */((((((0x3BF89C8AA241CF3ALL ^ g_76[4]) , &g_354) != (void*)0) == (**l_378)) || l_463), l_464)) || 0x9DL) > 0x674C4286L) ^ l_465) > g_285.f0) < (**l_378)) == (**l_378)) , 18446744073709551615UL)))) >= l_465) | 0x13EAL) <= g_125)))))), (*p_101))) > 0xBEFD0C13L) <= 65532UL) < l_465) >= 0x401061F75A280EA4LL);
                        l_488[7] &= (safe_lshift_func_uint32_t_u_u_unsafe_macro/*252*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s_unsafe_macro/*253*//* ___SAFE__OP */(p_102, ((&p_102 == &p_102) , (safe_rshift_func_int8_t_s_u_unsafe_macro/*254*//* ___SAFE__OP */((((l_473 == (((((*l_486) = ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*255*//* ___SAFE__OP */(0xBCEA6EE2F7F8A9FBLL, ((safe_rshift_func_uint8_t_u_s_unsafe_macro/*256*//* ___SAFE__OP */(((4L ^ (safe_div_func_uint64_t_u_u_unsafe_macro/*257*//* ___SAFE__OP */((g_381.f0 > ((*l_485) &= ((**l_352) = (safe_rshift_func_uint16_t_u_u_unsafe_macro/*258*//* ___SAFE__OP */((**l_378), ((&g_206 == l_482) , 65528UL)))))), 18446744073709551606UL))) | p_102), 5)) == l_463))) , g_125)) ^ 5L) <= l_466) <= 1UL)) , l_487) == 9L), 1))))) ^ p_102), (*l_382)));
                        if ((**l_378))
                            continue;
                        p_101 = ((**g_383) = &l_445);
                    }
                    else
                    { /* block id: 181 */
                        uint16_t l_505 = 0xA569L;
                        uint8_t l_511 = 7UL;
                        l_508[0][1][1] = ((safe_lshift_func_uint16_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */((l_491 != g_206), 9)) | (0x2CL && ((*l_382) & ((safe_add_func_int64_t_s_s_unsafe_macro/*260*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*261*//* ___SAFE__OP */(((+(safe_mul_func_int32_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */((((l_500[3] != &l_458[3]) & (safe_lshift_func_uint64_t_u_s_unsafe_macro/*263*//* ___SAFE__OP */(((safe_rshift_func_int16_t_s_u_unsafe_macro/*264*//* ___SAFE__OP */(l_505, (g_240[3][5][0].f0 <= (((l_506[0] == l_507) ^ p_102) ^ g_190[0])))) <= (*p_101)), g_22))) == 0xB6FD1A23L), l_463))) , p_102), (-8L))), (*g_366))) & (*g_385)))));
                        l_466 = ((*l_226) = (safe_lshift_func_uint64_t_u_s_unsafe_macro/*265*//* ___SAFE__OP */(p_102, 1)));
                        if (l_511)
                            break;
                    }
                    return (*l_382);
                }
            }
        }
        if ((((((l_512 <= (*l_382)) > 0xBCL) == ((((safe_mod_func_int16_t_s_s_unsafe_macro/*266*//* ___SAFE__OP */((*l_226), ((*l_515) &= 6L))) >= (safe_sub_func_int8_t_s_s_unsafe_macro/*267*//* ___SAFE__OP */(g_285.f0, p_102))) < (g_263[4][5][1] , (((--(*l_162)) != g_260) | p_102))) & (*l_226))) ^ l_520) == 3UL))
        { /* block id: 193 */
            int32_t *l_521 = &l_172;
            int64_t l_523[9];
            int8_t *l_549[6] = {&l_419,&l_419,&g_265,&l_419,&l_419,&g_265};
            int16_t *l_562 = &g_263[5][5][0];
            int i;
            for (i = 0; i < 9; i++)
                l_523[i] = 1L;
            (**g_383) = l_521;
            l_180 ^= (((~(l_167 ^= ((*l_226) <= ((l_523[7] = (*l_521)) > ((*g_366) == p_102))))) , ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*268*//* ___SAFE__OP */((((((safe_add_func_uint16_t_u_u_unsafe_macro/*269*//* ___SAFE__OP */(((void*)0 != l_521), ((***g_383) , g_261[0][5][2]))) , ((safe_div_func_int64_t_s_s_unsafe_macro/*270*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*271*//* ___SAFE__OP */((&l_277 != (void*)0), p_102)), (-2L))) != 0x2D43D6DC3B8AC384LL)) || 0L) , (*l_226)) >= (*g_29)), g_190[2])) , 0x6EE95873L)) , (*p_101));
            for (l_178 = 26; (l_178 <= (-24)); l_178 = safe_sub_func_int64_t_s_s_unsafe_macro/*272*//* ___SAFE__OP */(l_178, 8))
            { /* block id: 200 */
                uint32_t l_534 = 0x9AF8D58AL;
                uint16_t *l_541 = &l_236[0][0];
                int32_t ***l_550[9];
                int i;
                for (i = 0; i < 9; i++)
                    l_550[i] = &l_158;
                l_534++;
                for (l_473 = 0; (l_473 == 8); l_473 = safe_add_func_int64_t_s_s_unsafe_macro/*273*//* ___SAFE__OP */(l_473, 8))
                { /* block id: 204 */
                    uint32_t l_557 = 0x1605E5CBL;
                    int16_t **l_561 = (void*)0;
                    uint32_t *l_568 = &l_164[3];
                    uint32_t *l_578 = &g_190[2];
                    int32_t l_590 = 3L;
                    for (l_512 = (-19); (l_512 > 24); l_512++)
                    { /* block id: 207 */
                        uint16_t **l_542 = &l_541;
                        int8_t **l_551 = &l_549[5];
                        int32_t l_556 = 0x479E8FB1L;
                        (*l_226) = (&l_236[0][0] != ((*l_542) = l_541));
                        (*l_226) = ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*274*//* ___SAFE__OP */((l_534 && 0xD8L), 5)) <= (safe_sub_func_int64_t_s_s_unsafe_macro/*275*//* ___SAFE__OP */(0L, (((void*)0 == l_549[2]) == (l_550[7] != (((*l_124) = (((g_552[3][2][4] = l_551) == (void*)0) || (((safe_mul_func_int8_t_s_s_unsafe_macro/*276*//* ___SAFE__OP */(l_556, 1UL)) & l_557) || g_339))) , l_550[7]))))));
                    }
                }
            }
        }
        else
        { /* block id: 226 */
            int32_t **l_598 = &g_29;
            int32_t l_603 = 0L;
            uint32_t **l_678 = &l_124;
            for (g_260 = 24; (g_260 >= (-28)); g_260--)
            { /* block id: 229 */
                int32_t **l_597 = &l_382;
                uint32_t l_607 = 0xC5FF8E88L;
                uint16_t **l_635 = &g_570;
                int32_t l_704 = 0x905774C3L;
                uint32_t l_711 = 0xB5369158L;
                int64_t *l_714 = &l_161;
                int64_t **l_713 = &l_714;
                for (g_266 = 25; (g_266 > (-21)); --g_266)
                { /* block id: 232 */
                    int32_t l_634 = 0xEF7F81D9L;
                    int32_t ***l_637 = &l_597;
                    int32_t *** const l_638 = &l_158;
                }
                for (l_177 = 0; (l_177 <= 0); l_177 += 1)
                { /* block id: 258 */
                    int8_t l_670[8] = {0L,0L,9L,0L,0L,9L,0L,0L};
                    uint32_t **l_677 = &g_337[1];
                    uint16_t *l_693 = &g_238;
                    uint16_t *l_694[3][5] = {{&l_236[0][0],&l_236[0][0],&l_236[0][0],&l_236[0][0],&l_236[0][0]},{&l_236[0][2],&l_236[0][2],&l_236[0][2],&l_236[0][2],&l_236[0][2]},{&l_236[0][0],&l_236[0][0],&l_236[0][0],&l_236[0][0],&l_236[0][0]}};
                    int32_t l_695[8];
                    int i, j;
                    for (i = 0; i < 8; i++)
                        l_695[i] = 0xC5BFD4BDL;
                    if (((safe_mod_func_uint16_t_u_u_unsafe_macro/*277*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u_unsafe_macro/*278*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */(l_670[7], (safe_rshift_func_int8_t_s_u_unsafe_macro/*280*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*281*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*282*//* ___SAFE__OP */(1UL, ((l_677 == l_678) , (((l_695[2] = (p_102 && (((safe_sub_func_uint16_t_u_u_unsafe_macro/*283*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*284*//* ___SAFE__OP */(((**l_598) , (((*l_382) == ((safe_add_func_int64_t_s_s_unsafe_macro/*285*//* ___SAFE__OP */(((~(((((safe_mul_func_int8_t_s_s_unsafe_macro/*286*//* ___SAFE__OP */((p_102 > ((*l_693) = (safe_div_func_uint16_t_u_u_unsafe_macro/*287*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*288*//* ___SAFE__OP */(((+0xCEL) && (**l_123)), 0x2343557E5EFEA8B2LL)), p_102)))), p_102)) != (*g_385)) && 255UL) > l_670[7]) , 0x04F7B8A3L)) == 0x1E8CEEA165BD3B2CLL), (***l_122))) > p_102)) <= 0x39D9321D2689CBB4LL)), p_102)), g_285.f0)) && g_266) , p_102))) == 0L) ^ 0xFB09842511A1793FLL)))), (*l_226))), g_260)))), 8UL)) , g_339), 0x5316L)) != 0xC0EE9144L))
                    { /* block id: 261 */
                        int64_t *l_700 = &l_274[0][7];
                        int64_t l_712 = (-10L);
                        (*l_598) = (*l_598);
                        (*l_226) = (safe_add_func_uint8_t_u_u_unsafe_macro/*289*//* ___SAFE__OP */(((((safe_sub_func_uint64_t_u_u_unsafe_macro/*290*//* ___SAFE__OP */((((*l_700) ^= (**l_597)) , (((safe_rshift_func_uint16_t_u_s_unsafe_macro/*291*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*292*//* ___SAFE__OP */(((((((l_704 = 1L) & p_102) != ((g_240[3][5][0].f0 , (safe_rshift_func_uint16_t_u_s_unsafe_macro/*293*//* ___SAFE__OP */(((*l_693) = (safe_lshift_func_int8_t_s_u_unsafe_macro/*294*//* ___SAFE__OP */((l_695[2] , ((4294967292UL ^ ((**l_677) = l_695[2])) ^ ((p_102 <= l_711) >= 0UL))), 6))), p_102))) != 0L)) & 0xC6B9AF37L) && l_712) <= (*g_366)))), 7)) , (*g_385)) != 4294967295UL)), p_102)) <= (-9L)) | 0x287E6B98L) , 0xFDL), 1UL));
                    }
                    else
                    { /* block id: 268 */
                        uint8_t *l_731[5][3][2] = {{{(void*)0,&l_135[4][2][2]},{&l_135[4][2][2],(void*)0},{&l_135[4][2][2],&l_135[4][2][2]}},{{(void*)0,&l_135[4][2][2]},{&l_135[4][2][2],(void*)0},{&l_135[4][2][2],&l_135[4][2][2]}},{{(void*)0,&l_135[4][2][2]},{&l_135[4][2][2],(void*)0},{&l_135[4][2][2],&l_135[4][2][2]}},{{(void*)0,&l_135[4][2][2]},{&l_135[4][2][2],(void*)0},{&l_135[4][2][2],&l_135[4][2][2]}},{{(void*)0,&l_135[4][2][2]},{&l_135[4][2][2],(void*)0},{&l_135[4][2][2],&l_135[4][2][2]}}};
                        int32_t l_732 = (-1L);
                        int i, j, k;
                        l_732 = ((((*l_226) = ((l_713 != (l_695[5] , l_715[0])) , ((((**l_123) , p_102) , (safe_mul_func_uint16_t_u_u_unsafe_macro/*295*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*296*//* ___SAFE__OP */(((*g_366) = 0xF5147CA6FE22DEDALL), (((safe_div_func_uint8_t_u_u_unsafe_macro/*297*//* ___SAFE__OP */(((*l_162) = ((**l_598) <= ((safe_mul_func_uint32_t_u_u_unsafe_macro/*298*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*299*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*300*//* ___SAFE__OP */(0L, 10)), (safe_mod_func_uint16_t_u_u_unsafe_macro/*301*//* ___SAFE__OP */(0x53C0L, p_102)))), (**l_597))) | 0x763DL))), g_265)) == (-1L)) || p_102))), p_102))) >= p_102))) == l_732) , (**l_598));
                        if (l_695[2])
                            break;
                    }
                    for (g_339 = 0; (g_339 <= 0); g_339 += 1)
                    { /* block id: 277 */
                        int i, j, k;
                        (*l_226) |= (***l_122);
                        return (*p_101);
                    }
                }
            }
        }
    }
    else
    { /* block id: 284 */
        uint16_t *l_733 = &g_238;
        int32_t l_736 = (-1L);
        int64_t l_741[3][7][2] = {{{0xD2A0BDB8EBB9D20DLL,0xD2A0BDB8EBB9D20DLL},{0x83C409492B8A02D6LL,0L},{0x6AE4D35B60EA2C05LL,0L},{0x83C409492B8A02D6LL,0xD2A0BDB8EBB9D20DLL},{0xD2A0BDB8EBB9D20DLL,0x83C409492B8A02D6LL},{0L,0x6AE4D35B60EA2C05LL},{0L,0x83C409492B8A02D6LL}},{{0xD2A0BDB8EBB9D20DLL,0xD2A0BDB8EBB9D20DLL},{0x83C409492B8A02D6LL,0L},{0x6AE4D35B60EA2C05LL,0L},{0x83C409492B8A02D6LL,0xD2A0BDB8EBB9D20DLL},{0xD2A0BDB8EBB9D20DLL,0x83C409492B8A02D6LL},{0L,0x6AE4D35B60EA2C05LL},{0L,0x83C409492B8A02D6LL}},{{0xD2A0BDB8EBB9D20DLL,0xD2A0BDB8EBB9D20DLL},{0x83C409492B8A02D6LL,0L},{0x6AE4D35B60EA2C05LL,0L},{0x83C409492B8A02D6LL,0xD2A0BDB8EBB9D20DLL},{0xD2A0BDB8EBB9D20DLL,0x83C409492B8A02D6LL},{0L,0x6AE4D35B60EA2C05LL},{0L,0x83C409492B8A02D6LL}}};
        int i, j, k;
        (*g_742) = ((p_102 <= p_102) && ((((++(*l_733)) >= ((((*g_366) &= ((l_736 & p_102) ^ (safe_div_func_uint32_t_u_u_unsafe_macro/*302*//* ___SAFE__OP */(((((void*)0 != (*g_383)) , (**l_123)) , (safe_sub_func_uint16_t_u_u_unsafe_macro/*303*//* ___SAFE__OP */(1UL, g_225))), (***l_122))))) , l_736) ^ 0x05087212L)) != l_736) & l_741[1][1][0]));
        for (g_225 = 0; (g_225 != (-12)); --g_225)
        { /* block id: 290 */
            return (*l_382);
        }
    }
    g_782 = (g_266 |= ((*p_101) != ((*l_124) = (((((safe_add_func_int64_t_s_s_unsafe_macro/*304*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u_unsafe_macro/*305*//* ___SAFE__OP */((&g_640[1][2][3] != ((**l_123) , l_749)), (~(safe_div_func_int8_t_s_s_unsafe_macro/*306*//* ___SAFE__OP */((l_757[7] , (*l_382)), (safe_unary_minus_func_uint8_t_u_unsafe_macro/*307*//* ___SAFE__OP */(((((((((safe_add_func_int32_t_s_s_unsafe_macro/*308*//* ___SAFE__OP */((!(safe_mul_func_int8_t_s_s_unsafe_macro/*309*//* ___SAFE__OP */((*l_382), (!(safe_add_func_uint64_t_u_u_unsafe_macro/*310*//* ___SAFE__OP */(((((p_102 | ((((safe_mod_func_int32_t_s_s_unsafe_macro/*311*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*312*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*313*//* ___SAFE__OP */((g_261[4][6][0] = ((safe_mul_func_uint8_t_u_u_unsafe_macro/*314*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u_unsafe_macro/*315*//* ___SAFE__OP */((((safe_mul_func_uint64_t_u_u_unsafe_macro/*316*//* ___SAFE__OP */(((l_780 = ((**l_750) == (**l_750))) < 1UL), p_102)) <= 255UL) & p_102), p_102)), p_102)) || (***l_122))), g_339)), (***l_122))), (*p_101))) < p_102) > p_102) > p_102)) ^ (*p_101)) <= 247UL) == p_102), p_102)))))), g_781)) || 0x8DF96E5F2DFFD5E4LL) || p_102) || g_261[0][5][2]) , 0x1CL) , p_102) != 0UL) , 0x1EL)))))))), 0xB698ABB335905CC8LL)) , (*l_382)) > 0UL) > p_102) , 0x9BB266CFL))));
    return (*g_29);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_39[i][j][k], "g_39[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_48, "g_48", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_76[i], "g_76[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_190[i], "g_190[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_238, "g_238", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_240[i][j][k].f0, "g_240[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_260, "g_260", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_261[i][j][k], "g_261[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_263[i][j][k], "g_263[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_265, "g_265", print_hash_value);
    transparent_crc(g_266, "g_266", print_hash_value);
    transparent_crc(g_285.f0, "g_285.f0", print_hash_value);
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_375.f0, "g_375.f0", print_hash_value);
    transparent_crc(g_381.f0, "g_381.f0", print_hash_value);
    transparent_crc(g_443, "g_443", print_hash_value);
    transparent_crc(g_627.f0, "g_627.f0", print_hash_value);
    transparent_crc(g_644, "g_644", print_hash_value);
    transparent_crc(g_781, "g_781", print_hash_value);
    transparent_crc(g_782, "g_782", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_821[i].f0, "g_821[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_868[i][j].f0, "g_868[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_901, "g_901", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1117[i][j][k], "g_1117[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1153, "g_1153", print_hash_value);
    transparent_crc(g_1209, "g_1209", print_hash_value);
    transparent_crc(g_1285.f0, "g_1285.f0", print_hash_value);
    transparent_crc(g_1361, "g_1361", print_hash_value);
    transparent_crc(g_1399, "g_1399", print_hash_value);
    transparent_crc(g_1414, "g_1414", print_hash_value);
    transparent_crc(g_1429, "g_1429", print_hash_value);
    transparent_crc(g_1431, "g_1431", print_hash_value);
    transparent_crc(g_1432, "g_1432", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1453[i][j].f0, "g_1453[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1476[i][j][k].f0, "g_1476[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1507, "g_1507", print_hash_value);
    transparent_crc(g_1596, "g_1596", print_hash_value);
    transparent_crc(g_1628, "g_1628", print_hash_value);
    transparent_crc(g_1631.f0, "g_1631.f0", print_hash_value);
    transparent_crc(g_1655, "g_1655", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_1668[i][j][k], "g_1668[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1688, "g_1688", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1734[i].f0, "g_1734[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1744, "g_1744", print_hash_value);
    transparent_crc(g_1754.f0, "g_1754.f0", print_hash_value);
    transparent_crc(g_1777, "g_1777", print_hash_value);
    transparent_crc(g_2031, "g_2031", print_hash_value);
    transparent_crc(g_2125.f0, "g_2125.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2148[i], "g_2148[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2320.f0, "g_2320.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2378[i][j][k], "g_2378[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2453.f0, "g_2453.f0", print_hash_value);
    transparent_crc(g_2483, "g_2483", print_hash_value);
    transparent_crc(g_2491.f0, "g_2491.f0", print_hash_value);
    transparent_crc(g_2515.f0, "g_2515.f0", print_hash_value);
    transparent_crc(g_2554.f0, "g_2554.f0", print_hash_value);
    transparent_crc(g_2682, "g_2682", print_hash_value);
    transparent_crc(g_2772, "g_2772", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2847[i].f0, "g_2847[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2898.f0, "g_2898.f0", print_hash_value);
    transparent_crc(g_3015, "g_3015", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 760
XXX total union variables: 20

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 51
breakdown:
   indirect level: 0, occurrence: 20
   indirect level: 1, occurrence: 9
   indirect level: 2, occurrence: 9
   indirect level: 3, occurrence: 8
   indirect level: 4, occurrence: 5
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 10
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 27
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 15

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 187
   depth: 2, occurrence: 58
   depth: 3, occurrence: 4
   depth: 4, occurrence: 5
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 16, occurrence: 5
   depth: 17, occurrence: 4
   depth: 19, occurrence: 1
   depth: 20, occurrence: 3
   depth: 21, occurrence: 2
   depth: 22, occurrence: 3
   depth: 23, occurrence: 4
   depth: 24, occurrence: 4
   depth: 25, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 3
   depth: 32, occurrence: 1
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 41, occurrence: 1
   depth: 44, occurrence: 2

XXX total number of pointers: 589

XXX times a variable address is taken: 1297
XXX times a pointer is dereferenced on RHS: 534
breakdown:
   depth: 1, occurrence: 386
   depth: 2, occurrence: 108
   depth: 3, occurrence: 39
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 392
breakdown:
   depth: 1, occurrence: 306
   depth: 2, occurrence: 55
   depth: 3, occurrence: 29
   depth: 4, occurrence: 0
   depth: 5, occurrence: 2
XXX times a pointer is compared with null: 60
XXX times a pointer is compared with address of another variable: 14
XXX times a pointer is compared with another pointer: 21
XXX times a pointer is qualified to be dereferenced: 9601

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1672
   level: 2, occurrence: 546
   level: 3, occurrence: 288
   level: 4, occurrence: 26
   level: 5, occurrence: 18
XXX number of pointers point to pointers: 269
XXX number of pointers point to scalars: 307
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.2
XXX average alias set size: 1.32

XXX times a non-volatile is read: 2654
XXX times a non-volatile is write: 1201
XXX times a volatile is read: 137
XXX    times read thru a pointer: 63
XXX times a volatile is write: 34
XXX    times written thru a pointer: 10
XXX times a volatile is available for access: 6.17e+03
XXX percentage of non-volatile access: 95.8

XXX forward jumps: 6
XXX backward jumps: 13

XXX stmts: 210
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 33
   depth: 2, occurrence: 30
   depth: 3, occurrence: 31
   depth: 4, occurrence: 36
   depth: 5, occurrence: 46

XXX percentage a fresh-made variable is used: 16.8
XXX percentage an existing variable is used: 83.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

