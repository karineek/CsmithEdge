/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 1314852191 --bitfields --packed-struct
 * Seed:      1314852191
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   signed f0 : 14;
   const unsigned f1 : 13;
   unsigned f2 : 28;
   volatile signed f3 : 23;
   signed f4 : 12;
   signed f5 : 21;
   signed : 0;
   signed f6 : 19;
   signed f7 : 10;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static const int32_t g_22 = (-10L);
static volatile struct S0 g_23 = {106,29,10392,2764,-0,-28,-271,-16};/* VOLATILE GLOBAL g_23 */
static const int32_t * volatile g_49 = (void*)0;/* VOLATILE GLOBAL g_49 */
static int16_t g_51 = 0x9333L;
static uint32_t g_60 = 2UL;
static int32_t g_62 = 0L;
static int32_t *g_61 = &g_62;
static volatile int64_t g_67 = 0xB411E181F3B01A63LL;/* VOLATILE GLOBAL g_67 */
static volatile uint64_t g_68 = 18446744073709551615UL;/* VOLATILE GLOBAL g_68 */
static uint32_t *g_97[3][3] = {{&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60}};
static struct S0 g_101 = {-77,60,15880,-348,-25,-331,588,-22};/* VOLATILE GLOBAL g_101 */
static struct S0 g_104 = {100,69,2321,-971,56,-605,476,-7};/* VOLATILE GLOBAL g_104 */
static struct S0 g_106[2][7] = {{{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8},{-77,5,10115,-2853,53,-396,-297,8}},{{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13},{-63,15,1373,785,14,-414,-188,-13}}};
static struct S0 *g_105 = &g_106[1][0];
static uint64_t g_113 = 0x41DA8E33F4106BCBLL;
static int32_t **g_115 = (void*)0;
static int32_t *g_117[4] = {&g_62,&g_62,&g_62,&g_62};
static int32_t g_119 = 0x0522FE43L;
static int32_t *g_118[10][6] = {{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119}};
static int8_t g_143 = 0x51L;
static int8_t g_147[1] = {1L};
static struct S0 g_173 = {-22,25,13018,-2803,10,538,-362,-17};/* VOLATILE GLOBAL g_173 */
static uint32_t g_175 = 0x51C6119FL;
static int32_t g_176 = (-3L);
static volatile int8_t g_197 = 0xC6L;/* VOLATILE GLOBAL g_197 */
static int64_t g_224 = 0xDFE5F2ED823630FBLL;
static struct S0 g_248 = {108,60,6386,539,60,298,-80,26};/* VOLATILE GLOBAL g_248 */
static const volatile int32_t g_267 = 0x2024FCC9L;/* VOLATILE GLOBAL g_267 */
static const volatile int32_t g_268[8] = {0x8238ABA1L,0x8238ABA1L,0x8238ABA1L,0x8238ABA1L,0x8238ABA1L,0x8238ABA1L,0x8238ABA1L,0x8238ABA1L};
static volatile int32_t g_269[4] = {(-1L),(-1L),(-1L),(-1L)};
static volatile int32_t g_270 = 0x790414E5L;/* VOLATILE GLOBAL g_270 */
static const volatile int32_t g_271 = (-3L);/* VOLATILE GLOBAL g_271 */
static volatile int32_t g_272 = 1L;/* VOLATILE GLOBAL g_272 */
static volatile int32_t g_273 = 1L;/* VOLATILE GLOBAL g_273 */
static volatile int32_t g_274[9] = {8L,8L,8L,8L,8L,8L,8L,8L,8L};
static const volatile int32_t g_275 = (-1L);/* VOLATILE GLOBAL g_275 */
static volatile int32_t g_276 = 0xA344E1BCL;/* VOLATILE GLOBAL g_276 */
static const volatile int32_t g_277 = 9L;/* VOLATILE GLOBAL g_277 */
static const volatile int32_t g_278 = 0x11DEB276L;/* VOLATILE GLOBAL g_278 */
static const volatile int32_t g_279 = 0xB65A2F4CL;/* VOLATILE GLOBAL g_279 */
static const volatile int32_t g_280 = (-1L);/* VOLATILE GLOBAL g_280 */
static volatile int32_t g_281 = 0L;/* VOLATILE GLOBAL g_281 */
static const volatile int32_t g_282 = 0xA79FEFAFL;/* VOLATILE GLOBAL g_282 */
static const volatile int32_t g_283 = (-1L);/* VOLATILE GLOBAL g_283 */
static const volatile int32_t g_284[3] = {0xCE4DB098L,0xCE4DB098L,0xCE4DB098L};
static const volatile int32_t g_285 = 0x3E130915L;/* VOLATILE GLOBAL g_285 */
static const volatile int32_t g_286[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static const volatile int32_t g_287 = (-4L);/* VOLATILE GLOBAL g_287 */
static const volatile int32_t g_288[3][8] = {{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)}};
static const volatile int32_t g_289 = 0x6DC492EAL;/* VOLATILE GLOBAL g_289 */
static const volatile int32_t g_290 = 0x89723F7FL;/* VOLATILE GLOBAL g_290 */
static const volatile int32_t g_291 = 0x01A16205L;/* VOLATILE GLOBAL g_291 */
static volatile int32_t g_292[7][6][4] = {{{(-8L),0x6B71C90CL,0x58AF8EF0L,0x58AF8EF0L},{0x58AF8EF0L,0x58AF8EF0L,0x6B71C90CL,(-8L)},{(-4L),0L,0xAA30C3C7L,(-1L)},{(-1L),(-8L),(-1L),0xAA30C3C7L},{(-1L),(-8L),0x69F1DDACL,(-1L)},{(-8L),0L,(-1L),(-8L)}},{{0L,0x58AF8EF0L,4L,0x58AF8EF0L},{5L,0x6B71C90CL,(-1L),(-4L)},{0x39C108E1L,0xAA30C3C7L,6L,(-1L)},{4L,(-1L),0x13B23E2CL,(-1L)},{4L,0x69F1DDACL,6L,(-8L)},{0x39C108E1L,(-1L),(-1L),0L}},{{5L,4L,4L,5L},{0L,(-1L),(-1L),0x39C108E1L},{(-8L),6L,0x69F1DDACL,4L},{(-1L),0x13B23E2CL,(-1L),4L},{(-1L),6L,0xAA30C3C7L,0x39C108E1L},{(-4L),(-1L),0x6B71C90CL,5L}},{{0x58AF8EF0L,4L,0x58AF8EF0L,0L},{(-8L),(-1L),0L,(-8L)},{(-1L),0x69F1DDACL,(-8L),(-1L)},{0xAA30C3C7L,(-1L),(-8L),(-1L)},{(-1L),0xAA30C3C7L,0L,(-4L)},{0x58AF8EF0L,0x13B23E2CL,(-7L),(-7L)}},{{(-7L),(-7L),0x13B23E2CL,0x58AF8EF0L},{6L,(-1L),0L,4L},{(-1L),0x39C108E1L,0x6B71C90CL,0L},{0L,0x39C108E1L,(-8L),4L},{0x39C108E1L,(-1L),0L,0x58AF8EF0L},{0xAA30C3C7L,(-7L),0x5B25D61BL,(-7L)}},{{0xCBD10398L,0x13B23E2CL,4L,6L},{(-1L),0L,(-8L),(-1L)},{0x5B25D61BL,0x6B71C90CL,(-1L),0L},{0x5B25D61BL,(-8L),(-8L),0x39C108E1L},{(-1L),0L,4L,0xAA30C3C7L},{0xCBD10398L,0x5B25D61BL,0x5B25D61BL,0xCBD10398L}},{{0xAA30C3C7L,4L,0L,(-1L)},{0x39C108E1L,(-8L),(-8L),0x5B25D61BL},{0L,(-1L),0x6B71C90CL,0x5B25D61BL},{(-1L),(-8L),0L,(-1L)},{6L,4L,0x13B23E2CL,0xCBD10398L},{(-7L),0x5B25D61BL,(-7L),0xAA30C3C7L}}};
static const volatile int32_t g_293 = 0L;/* VOLATILE GLOBAL g_293 */
static const volatile int32_t g_294 = (-1L);/* VOLATILE GLOBAL g_294 */
static volatile int32_t g_295 = 0L;/* VOLATILE GLOBAL g_295 */
static volatile int32_t g_296 = 3L;/* VOLATILE GLOBAL g_296 */
static const volatile int32_t g_297 = 0xDD83D830L;/* VOLATILE GLOBAL g_297 */
static const volatile int32_t *g_266[7][9][4] = {{{&g_274[3],&g_283,&g_294,(void*)0},{&g_297,(void*)0,&g_285,&g_297},{&g_292[4][5][2],(void*)0,&g_282,(void*)0},{&g_293,&g_272,&g_287,&g_268[2]},{(void*)0,&g_280,(void*)0,&g_279},{&g_278,(void*)0,&g_278,(void*)0},{&g_297,&g_281,(void*)0,&g_286[2]},{(void*)0,(void*)0,&g_295,&g_281},{&g_285,&g_272,&g_295,&g_282}},{{(void*)0,&g_276,(void*)0,(void*)0},{&g_297,&g_288[1][1],&g_278,(void*)0},{&g_278,(void*)0,(void*)0,&g_290},{(void*)0,&g_293,&g_287,&g_281},{&g_293,&g_288[1][1],&g_282,&g_279},{&g_292[4][5][2],(void*)0,&g_285,&g_282},{&g_297,(void*)0,&g_294,&g_293},{&g_274[3],(void*)0,(void*)0,&g_274[3]},{&g_292[4][5][2],&g_293,&g_295,(void*)0}},{{&g_281,&g_283,&g_287,(void*)0},{&g_276,&g_280,&g_285,(void*)0},{&g_278,&g_283,&g_290,(void*)0},{&g_286[2],&g_293,(void*)0,&g_274[3]},{(void*)0,(void*)0,&g_282,&g_293},{&g_285,(void*)0,(void*)0,&g_282},{&g_276,(void*)0,(void*)0,&g_279},{&g_274[3],&g_288[1][1],&g_267,&g_281},{&g_278,&g_293,(void*)0,&g_290}},{{(void*)0,(void*)0,&g_287,(void*)0},{(void*)0,&g_288[1][1],&g_291,(void*)0},{&g_277,(void*)0,(void*)0,&g_269[3]},{(void*)0,&g_292[4][5][2],&g_279,&g_267},{(void*)0,&g_294,(void*)0,(void*)0},{&g_277,&g_267,&g_291,(void*)0},{&g_290,&g_280,&g_272,(void*)0},{(void*)0,(void*)0,&g_294,&g_288[1][1]},{(void*)0,&g_292[4][5][2],&g_287,(void*)0}},{{&g_295,&g_290,&g_286[2],&g_282},{(void*)0,&g_294,&g_291,&g_290},{&g_271,&g_270,&g_269[3],&g_269[3]},{&g_285,&g_285,&g_286[2],&g_288[1][1]},{(void*)0,&g_273,&g_275,&g_278},{(void*)0,&g_267,&g_271,&g_275},{(void*)0,&g_267,&g_272,&g_278},{&g_267,&g_273,(void*)0,&g_288[1][1]},{&g_277,&g_285,&g_294,&g_269[3]}},{{&g_295,&g_270,&g_279,&g_290},{&g_282,&g_294,&g_271,&g_282},{&g_277,&g_290,&g_269[3],(void*)0},{&g_278,&g_292[4][5][2],&g_272,&g_288[1][1]},{&g_285,(void*)0,(void*)0,(void*)0},{(void*)0,&g_280,(void*)0,(void*)0},{&g_282,&g_267,&g_286[2],(void*)0},{(void*)0,&g_294,(void*)0,&g_267},{&g_271,&g_292[4][5][2],(void*)0,&g_269[3]}},{{(void*)0,(void*)0,&g_286[2],(void*)0},{&g_282,&g_273,(void*)0,&g_290},{(void*)0,&g_290,(void*)0,&g_275},{&g_285,&g_278,&g_272,&g_267},{&g_278,&g_273,&g_269[3],(void*)0},{&g_277,(void*)0,&g_271,&g_269[3]},{&g_282,&g_280,&g_279,&g_278},{&g_295,&g_294,&g_294,&g_295},{&g_277,&g_278,(void*)0,(void*)0}}};
static int32_t g_299[9] = {0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L,0x64FB9815L};
static int32_t *g_298 = &g_299[0];
static volatile struct S0 g_319 = {-119,60,14806,351,-10,131,-116,-11};/* VOLATILE GLOBAL g_319 */
static volatile struct S0 *g_318[3] = {&g_319,&g_319,&g_319};
static int8_t g_326 = 0x3AL;
static volatile struct S0 g_343 = {-98,51,3429,-627,-38,933,-38,8};/* VOLATILE GLOBAL g_343 */
static uint64_t g_364 = 0x434A620E5CB8B057LL;
static uint16_t g_402 = 1UL;
static volatile int16_t * volatile *g_429 = (void*)0;
static uint32_t g_461 = 0UL;
static volatile uint64_t g_500 = 0xF0D68837EA45691ALL;/* VOLATILE GLOBAL g_500 */
static uint8_t g_535 = 8UL;
static uint8_t *g_534 = &g_535;
static int64_t g_564 = 0x8298CE9C7E11143BLL;
static int32_t ***g_636[9] = {&g_115,&g_115,&g_115,&g_115,&g_115,&g_115,&g_115,&g_115,&g_115};
static uint16_t g_651 = 65527UL;
static int32_t ****g_691[9] = {(void*)0,(void*)0,&g_636[8],(void*)0,(void*)0,&g_636[8],(void*)0,(void*)0,&g_636[8]};
static struct S0 g_735 = {41,16,10236,2800,-61,218,-281,25};/* VOLATILE GLOBAL g_735 */
static uint32_t g_774 = 4UL;
static uint32_t g_811 = 1UL;
static uint32_t *g_823 = &g_461;
static int16_t *g_853 = &g_51;
static int16_t **g_852 = &g_853;
static struct S0 g_867 = {-11,28,11884,-1438,13,986,37,-2};/* VOLATILE GLOBAL g_867 */
static struct S0 g_912 = {-22,59,2960,2693,-4,1276,-258,-22};/* VOLATILE GLOBAL g_912 */
static uint64_t g_996 = 18446744073709551615UL;
static volatile struct S0 g_1047 = {-73,25,807,2383,-47,982,600,17};/* VOLATILE GLOBAL g_1047 */
static int16_t g_1084 = 0xBDA4L;
static const struct S0 g_1097 = {-98,35,1995,-568,41,1392,-513,-17};/* VOLATILE GLOBAL g_1097 */
static uint32_t g_1139[8][4][2] = {{{0xFA1E403FL,0xFA1E403FL},{0x021AC57CL,0xFA1E403FL},{0xFA1E403FL,0x9D9A7D9FL},{0x9AC35526L,4294967294UL}},{{0x021AC57CL,0x9AC35526L},{4294967294UL,0x9D9A7D9FL},{4294967294UL,0x9AC35526L},{0x021AC57CL,4294967294UL}},{{0x9AC35526L,0x9D9A7D9FL},{0xFA1E403FL,0xFA1E403FL},{0x021AC57CL,0xFA1E403FL},{0xFA1E403FL,5UL}},{{0x9D9A7D9FL,0xFB500C09L},{9UL,0x9D9A7D9FL},{0xFB500C09L,5UL},{0xFB500C09L,0x9D9A7D9FL}},{{9UL,0xFB500C09L},{0x9D9A7D9FL,5UL},{0x021AC57CL,0x021AC57CL},{9UL,0x021AC57CL}},{{0x021AC57CL,5UL},{0x9D9A7D9FL,0xFB500C09L},{9UL,0x9D9A7D9FL},{0xFB500C09L,5UL}},{{0xFB500C09L,0x9D9A7D9FL},{9UL,0xFB500C09L},{0x9D9A7D9FL,5UL},{0x021AC57CL,0x021AC57CL}},{{9UL,0x021AC57CL},{0x021AC57CL,5UL},{0x9D9A7D9FL,0xFB500C09L},{9UL,0x9D9A7D9FL}}};
static uint32_t g_1141 = 1UL;
static uint8_t g_1143 = 0x0AL;
static int32_t g_1144[9] = {0xAF83468DL,9L,0xAF83468DL,9L,0xAF83468DL,9L,0xAF83468DL,9L,0xAF83468DL};
static int16_t ***** volatile g_1162 = (void*)0;/* VOLATILE GLOBAL g_1162 */
static volatile uint64_t *g_1189 = &g_500;
static volatile uint64_t ** const  volatile g_1188 = &g_1189;/* VOLATILE GLOBAL g_1188 */
static volatile uint64_t ** const  volatile *g_1187[4][6][7] = {{{&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,&g_1188,(void*)0},{&g_1188,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,(void*)0},{(void*)0,(void*)0,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,(void*)0},{&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,&g_1188,&g_1188},{&g_1188,&g_1188,(void*)0,&g_1188,&g_1188,&g_1188,(void*)0}},{{(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{&g_1188,(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,(void*)0,(void*)0,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,(void*)0,(void*)0,(void*)0},{&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188}},{{(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{&g_1188,(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,(void*)0},{&g_1188,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,&g_1188}},{{&g_1188,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,&g_1188},{(void*)0,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188,&g_1188},{(void*)0,(void*)0,&g_1188,&g_1188,&g_1188,&g_1188,(void*)0},{&g_1188,&g_1188,(void*)0,&g_1188,(void*)0,&g_1188,&g_1188},{&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,(void*)0,&g_1188},{&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188,&g_1188}}};
static volatile uint64_t ** const  volatile g_1191 = (void*)0;/* VOLATILE GLOBAL g_1191 */
static int32_t * volatile g_1192 = &g_1144[5];/* VOLATILE GLOBAL g_1192 */
static int32_t * const  volatile g_1204 = &g_119;/* VOLATILE GLOBAL g_1204 */
static volatile struct S0 g_1244 = {82,19,4178,851,-33,-300,477,5};/* VOLATILE GLOBAL g_1244 */
static uint8_t * volatile * volatile g_1288[10] = {&g_534,&g_534,&g_534,&g_534,&g_534,&g_534,&g_534,&g_534,&g_534,&g_534};
static uint8_t * volatile * volatile *g_1287 = &g_1288[7];
static volatile int16_t * volatile * volatile *g_1315 = &g_429;
static volatile int16_t * volatile * volatile **g_1314 = &g_1315;
static volatile int16_t * volatile * volatile ** const *g_1313 = &g_1314;
static int32_t g_1317[6] = {0xF101A108L,0xF101A108L,0xF101A108L,0xF101A108L,0xF101A108L,0xF101A108L};
static uint16_t g_1339 = 0x0E87L;
static int16_t g_1374 = 0x515CL;
static uint32_t g_1380 = 4294967291UL;
static struct S0 g_1396 = {59,32,10249,-1657,19,379,-130,-12};/* VOLATILE GLOBAL g_1396 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t * func_2(uint8_t  p_3, uint16_t  p_4, int32_t * p_5, uint16_t  p_6);
static uint8_t  func_13(uint8_t  p_14, int8_t  p_15, int32_t  p_16, int32_t * p_17);
static int32_t  func_18(const uint16_t  p_19, uint32_t  p_20, int32_t * p_21);
static int32_t * func_24(int32_t * p_25, uint32_t  p_26, int64_t  p_27);
static int32_t * func_28(int32_t * p_29, int32_t * p_30, int8_t  p_31, int32_t * p_32);
static struct S0  func_33(int32_t  p_34);
static int32_t * func_38(int16_t  p_39, int32_t  p_40, uint64_t  p_41, uint32_t  p_42, int32_t * p_43);
static int16_t  func_44(int16_t  p_45, uint32_t  p_46, const uint64_t  p_47, int32_t * p_48);
static int32_t * func_77(int16_t * p_78, uint64_t  p_79, uint32_t * p_80, int32_t  p_81, const int8_t  p_82);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_22 g_23 g_49 g_51 g_61 g_62 g_68 g_101.f2 g_118 g_104.f0 g_106.f4 g_106.f6 g_104 g_147 g_101.f6 g_143 g_101.f5 g_119 g_248 g_106.f0 g_176 g_266 g_298 g_299 g_274 g_106 g_286 g_318 g_281 g_343 g_279 g_326 g_292 g_272 g_364 g_282 g_402 g_429 g_97 g_273 g_319.f6 g_271 g_173.f1 g_224 g_101.f4 g_500 g_319.f3 g_534 g_173.f4 g_101.f1 g_564 g_535 g_269 g_175 g_268 g_651 g_319.f5 g_173.f0 g_735 g_173.f7 g_319.f7 g_101.f3 g_774 g_811 g_270 g_823 g_461 g_267 g_60 g_852 g_853 g_996 g_173.f5 g_867.f7 g_1097 g_1139 g_1144 g_113 g_912.f0 g_1187 g_1192 g_1141 g_1204 g_1143 g_295 g_912.f4 g_1244 g_296 g_67 g_1287 g_293 g_1313 g_1317 g_1339 g_1288 g_1374 g_1380 g_1314 g_1396
 * writes: g_51 g_60 g_68 g_61 g_97 g_62 g_105 g_113 g_115 g_117 g_143 g_147 g_119 g_118 g_67 g_176 g_274 g_175 g_326 g_299 g_364 g_402 g_173.f2 g_500 g_104.f2 g_534 g_224 g_535 g_564 g_636 g_651 g_691 g_101.f2 g_774 g_461 g_811 g_823 g_852 g_996 g_1084 g_1139 g_735.f2 g_1144 g_1141 g_49 g_1143 g_1339
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int16_t *l_50[6] = {&g_51,&g_51,&g_51,&g_51,&g_51,&g_51};
    int32_t l_52 = 0x602A0500L;
    int32_t l_55 = 0x60A87187L;
    uint32_t *l_59 = &g_60;
    int32_t *l_71 = &l_55;
    int32_t **l_116[8][9][3] = {{{&g_61,(void*)0,&l_71},{&g_61,&g_61,&g_61},{(void*)0,&l_71,&l_71},{&g_61,(void*)0,&g_61},{&l_71,&l_71,&g_61},{(void*)0,&g_61,&g_61},{&g_61,&l_71,&l_71},{&l_71,&g_61,&g_61},{(void*)0,&g_61,&l_71}},{{&l_71,&l_71,&g_61},{(void*)0,&g_61,(void*)0},{(void*)0,&g_61,&l_71},{&l_71,&l_71,(void*)0},{&l_71,&g_61,&l_71},{&g_61,&g_61,&g_61},{&g_61,&l_71,(void*)0},{&l_71,&g_61,&l_71},{(void*)0,&l_71,&g_61}},{{&l_71,(void*)0,&l_71},{&g_61,&l_71,(void*)0},{&g_61,&g_61,&g_61},{&l_71,(void*)0,&l_71},{&l_71,&l_71,(void*)0},{(void*)0,&l_71,(void*)0},{(void*)0,&l_71,&l_71},{&l_71,&g_61,&g_61},{(void*)0,(void*)0,(void*)0}},{{&l_71,&l_71,&l_71},{&g_61,&l_71,&g_61},{(void*)0,&l_71,&l_71},{&l_71,&l_71,(void*)0},{&g_61,&l_71,&g_61},{(void*)0,(void*)0,&l_71},{&g_61,&g_61,(void*)0},{&g_61,&l_71,&l_71},{&l_71,&l_71,(void*)0}},{{&l_71,&l_71,&g_61},{&g_61,(void*)0,&l_71},{&g_61,&g_61,&g_61},{(void*)0,&l_71,&l_71},{&g_61,(void*)0,&g_61},{&l_71,&l_71,&g_61},{(void*)0,&g_61,&g_61},{&g_61,&l_71,&l_71},{&l_71,&g_61,&g_61}},{{(void*)0,&g_61,&l_71},{&l_71,&l_71,&g_61},{(void*)0,&g_61,(void*)0},{&l_71,&g_61,(void*)0},{&l_71,&g_61,&l_71},{(void*)0,&l_71,(void*)0},{(void*)0,&l_71,&l_71},{&l_71,&g_61,&g_61},{&g_61,&l_71,(void*)0}},{{&l_71,&g_61,&l_71},{&g_61,&l_71,&g_61},{&l_71,(void*)0,(void*)0},{(void*)0,&l_71,&g_61},{(void*)0,(void*)0,&g_61},{&l_71,&g_61,&l_71},{&l_71,(void*)0,&l_71},{(void*)0,&g_61,&g_61},{&g_61,&g_61,&g_61}},{{&g_61,&l_71,(void*)0},{(void*)0,(void*)0,&g_61},{&l_71,(void*)0,&l_71},{&g_61,&g_61,(void*)0},{(void*)0,(void*)0,&g_61},{&l_71,(void*)0,&l_71},{&l_71,&l_71,(void*)0},{&l_71,&g_61,&l_71},{&l_71,&g_61,(void*)0}}};
    uint32_t l_262 = 0x0F1316BCL;
    uint64_t l_584[5][8] = {{0xC0179DA47F2A0D95LL,18446744073709551609UL,4UL,0xDFEC583255F64C7BLL,18446744073709551615UL,0xC0179DA47F2A0D95LL,0xC0179DA47F2A0D95LL,18446744073709551615UL},{0x61614DB63832A6E3LL,4UL,4UL,0x61614DB63832A6E3LL,0UL,0UL,18446744073709551615UL,4UL},{18446744073709551615UL,0x5EE380D73766ADA9LL,0xCCA68B84ED5EE4F3LL,0xDA848384B9362B38LL,0x5EE380D73766ADA9LL,0x22474E13E3D5F59ELL,0x5EE380D73766ADA9LL,0xDA848384B9362B38LL},{0UL,0x5EE380D73766ADA9LL,0UL,4UL,18446744073709551615UL,0UL,0UL,0x61614DB63832A6E3LL},{18446744073709551609UL,4UL,0xDFEC583255F64C7BLL,18446744073709551615UL,0xC0179DA47F2A0D95LL,0xC0179DA47F2A0D95LL,18446744073709551615UL,0xDFEC583255F64C7BLL}};
    int64_t l_825 = 0L;
    int32_t *l_1255 = &g_119;
    int16_t l_1298 = 7L;
    int64_t * const l_1301[2][3] = {{&g_564,&g_564,(void*)0},{&g_564,&g_564,(void*)0}};
    int64_t l_1352 = 0xC08C238D02306938LL;
    int32_t l_1375[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint8_t **l_1386 = &g_534;
    int16_t ***l_1390 = &g_852;
    int16_t *** const *l_1389 = &l_1390;
    int16_t *** const **l_1391 = &l_1389;
    int32_t ***l_1397 = (void*)0;
    int8_t *l_1398 = &g_147[0];
    uint8_t l_1399 = 0xC4L;
    int8_t l_1400 = 0xFDL;
    int32_t ***l_1401 = &l_116[6][4][2];
    int32_t *l_1402 = &g_119;
    int i, j, k;
    l_1255 = func_2(((*l_71) = (safe_lshift_func_int32_t_s_u((safe_mul_func_uint8_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(func_13((func_18(g_22, (g_23 , ((g_117[1] = func_24(func_28(((func_33(((g_23.f5 , ((+((((((safe_add_func_int64_t_s_s_unsafe_macro/*3*//* ___SAFE__OP */((((g_117[0] = func_38(func_44((g_51 ^= (l_52 = ((void*)0 == g_49))), ((*l_59) = (safe_mod_func_int32_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */(l_55, (safe_add_func_int8_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */(1L, (safe_unary_minus_func_uint16_t_u_unsafe_macro/*6*//* ___SAFE__OP */(l_55))))))), l_55, g_61), g_62, l_55, l_55, l_71)) != g_118[9][2]) > g_104.f0), g_106[1][0].f4)) <= 0x7DFE4B33A2C9E81ELL) == 65529UL) , 0x47L) < 9L) , 0x2515ED50L)) >= (*l_71))) >= g_104.f0)) , 0x6423F066L) , &g_62), g_118[7][4], g_106[1][0].f0, g_118[9][2]), l_262, g_101.f5)) != g_266[1][7][3])), g_298) , (*g_534)), l_584[4][1], (*l_71), g_298), 1L)), 0x59L)), g_735.f4))), g_173.f0, g_298, l_825);
    for (g_1143 = 0; (g_1143 <= 23); g_1143 = safe_add_func_uint8_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */(g_1143, 8))
    { /* block id: 569 */
        int32_t *l_1258[2];
        uint8_t l_1273 = 1UL;
        int16_t *l_1318 = (void*)0;
        uint32_t l_1325 = 1UL;
        int16_t l_1336 = 6L;
        int16_t l_1353 = 0x38F0L;
        int16_t l_1356 = 1L;
        int16_t l_1371 = 0xBED9L;
        int64_t l_1381 = 9L;
        int i;
        for (i = 0; i < 2; i++)
            l_1258[i] = &l_52;
        l_1258[1] = func_24(l_1258[1], (safe_lshift_func_int32_t_s_s((g_296 && ((0xC2D7BBD47D5E2E18LL == (+(safe_unary_minus_func_uint8_t_u_unsafe_macro/*9*//* ___SAFE__OP */(6UL)))) ^ (0x74C0L || ((0x8D0423DEL >= 0x1C1427CEL) | g_67)))), (*g_298))), g_62);
        for (g_402 = 0; (g_402 <= 13); ++g_402)
        { /* block id: 573 */
            uint8_t **l_1286 = &g_534;
            uint8_t ***l_1285[6][7][2] = {{{&l_1286,&l_1286},{&l_1286,&l_1286},{(void*)0,(void*)0},{(void*)0,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286}},{{&l_1286,(void*)0},{&l_1286,&l_1286},{(void*)0,&l_1286},{&l_1286,&l_1286},{(void*)0,&l_1286},{&l_1286,(void*)0},{&l_1286,&l_1286}},{{&l_1286,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286},{(void*)0,(void*)0},{(void*)0,&l_1286},{&l_1286,&l_1286},{&l_1286,(void*)0}},{{&l_1286,&l_1286},{&l_1286,(void*)0},{&l_1286,&l_1286},{&l_1286,(void*)0},{&l_1286,&l_1286},{&l_1286,&l_1286},{(void*)0,(void*)0}},{{(void*)0,&l_1286},{&l_1286,&l_1286},{(void*)0,(void*)0},{(void*)0,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286}},{{(void*)0,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286},{&l_1286,&l_1286},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1286,&l_1286}}};
            int64_t *l_1289 = &g_224;
            int32_t l_1299 = (-6L);
            const uint16_t l_1300 = 0UL;
            int32_t l_1302 = 0x9C47D116L;
            int8_t *l_1316[9][4][2] = {{{&g_147[0],&g_147[0]},{&g_147[0],(void*)0},{&g_143,(void*)0},{(void*)0,(void*)0}},{{&g_143,(void*)0},{&g_147[0],&g_147[0]},{&g_147[0],(void*)0},{&g_143,(void*)0}},{{(void*)0,(void*)0},{&g_143,(void*)0},{&g_147[0],&g_147[0]},{&g_147[0],(void*)0}},{{&g_143,(void*)0},{(void*)0,(void*)0},{&g_143,(void*)0},{&g_147[0],&g_147[0]}},{{&g_147[0],(void*)0},{&g_143,(void*)0},{(void*)0,(void*)0},{&g_143,(void*)0}},{{&g_147[0],&g_147[0]},{&g_147[0],(void*)0},{&g_143,(void*)0},{(void*)0,(void*)0}},{{&g_143,(void*)0},{&g_147[0],&g_147[0]},{&g_147[0],(void*)0},{&g_143,(void*)0}},{{(void*)0,(void*)0},{&g_143,(void*)0},{&g_147[0],&g_147[0]},{&g_147[0],(void*)0}},{{&g_143,(void*)0},{(void*)0,(void*)0},{&g_143,(void*)0},{&g_147[0],&g_147[0]}}};
            int32_t l_1337[2][1];
            int32_t *l_1354[4];
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1337[i][j] = (-1L);
            }
            for (i = 0; i < 4; i++)
                l_1354[i] = &g_299[6];
            l_1302 |= (safe_mul_func_uint64_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*11*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */((((**g_852) = ((((*g_823)--) < l_1273) && (safe_sub_func_int32_t_s_s_unsafe_macro/*13*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*15*//* ___SAFE__OP */(g_106[1][0].f3, (*g_853))), (((((safe_div_func_int64_t_s_s_unsafe_macro/*16*//* ___SAFE__OP */((252UL || (safe_add_func_uint8_t_u_u_unsafe_macro/*17*//* ___SAFE__OP */((((*l_1289) = ((*l_71) , (safe_unary_minus_func_uint8_t_u_unsafe_macro/*18*//* ___SAFE__OP */((l_1285[1][2][0] == g_1287))))) < ((safe_mod_func_int32_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*20*//* ___SAFE__OP */((-1L), ((*g_298) = (safe_mod_func_int16_t_s_s_unsafe_macro/*21*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*22*//* ___SAFE__OP */(l_1298, l_1299)), l_1300))))), l_1299)) && (*g_853))), (-5L)))), (-1L))) <= 65535UL) , &l_825) == l_1301[0][2]) && l_1299))) <= g_106[1][0].f6), 0xD63C977EL)))) , (*l_71)), 5)) , 0xBF0584E3679F27A7LL), 0x50309E6BD4BDB5EDLL)), g_248.f5));
            if ((safe_sub_func_uint32_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */(((*g_823) = (((g_293 | ((l_1300 >= (safe_sub_func_int16_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */((*g_853), ((safe_div_func_uint64_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */((-1L), 0x86B0L)), (g_106[1][0].f7 , g_735.f1))) >= (safe_mod_func_int8_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */((g_143 = (g_1313 == &g_1314)), 0x7CL)))))) >= 0x4239L)) , l_1300) , (*g_823))), g_1317[3])))
            { /* block id: 581 */
                uint32_t *l_1331 = &g_1139[7][2][1];
                int32_t l_1338 = (-2L);
                uint16_t *l_1351 = &g_1339;
                int32_t *l_1355 = &g_62;
                l_1355 = (l_1354[3] = func_28(&l_1338, &l_1338, g_774, &l_1338));
                return l_1356;
            }
            else
            { /* block id: 590 */
                uint16_t l_1363 = 65528UL;
                int32_t l_1370 = 2L;
                int32_t l_1372[3][4][7] = {{{0x67465BC3L,0x67465BC3L,0x54501A14L,1L,0x91FA42D9L,0L,0xC4A812E9L},{0x15607455L,0xF1E3A0A8L,0x15607455L,0x84673CB4L,2L,0xF1E3A0A8L,2L},{0x58B2B7F5L,1L,1L,0x58B2B7F5L,0x91FA42D9L,0x54501A14L,0xC0240005L},{0x1A02D5D0L,0x9241E278L,0xB56FF9A9L,0x9241E278L,0x1A02D5D0L,0xF1E3A0A8L,0xB56FF9A9L}},{{0L,0x67465BC3L,0xC4A812E9L,0xC4A812E9L,0x67465BC3L,0L,0xC0240005L},{2L,0x84673CB4L,0x15607455L,0xF1E3A0A8L,0x15607455L,0x84673CB4L,2L},{0L,0xC4A812E9L,0xC0240005L,0x58B2B7F5L,0x58B2B7F5L,0xC0240005L,0xC4A812E9L},{0x1A02D5D0L,0x84673CB4L,1L,0x3F40764CL,0x1A02D5D0L,0x3F40764CL,1L}},{{0x58B2B7F5L,0x67465BC3L,0xC0240005L,1L,0L,0L,1L},{0x15607455L,0x9241E278L,0x15607455L,0x3F40764CL,2L,0x9241E278L,2L},{0x67465BC3L,1L,0xC4A812E9L,0x58B2B7F5L,0L,0x54501A14L,0x54501A14L},{0x1A02D5D0L,0xF1E3A0A8L,0xB56FF9A9L,0xF1E3A0A8L,0x1A02D5D0L,0x9241E278L,0xB56FF9A9L}}};
                int i, j, k;
                for (g_1339 = 0; (g_1339 == 30); g_1339++)
                { /* block id: 593 */
                    const int8_t l_1369[4][10][6] = {{{0x2BL,0L,0x3CL,0x0DL,0L,0x06L},{0x23L,0L,0x58L,0L,1L,(-8L)},{0L,0x54L,0x4BL,0x6DL,(-9L),0xFEL},{1L,(-1L),0x05L,0x3CL,0xC8L,0x4BL},{0L,(-2L),0x05L,0x58L,0x54L,0xFEL},{0xC5L,0xFEL,0x4BL,0L,(-10L),(-8L)},{0L,(-10L),(-8L),(-1L),(-3L),(-9L)},{0x6DL,(-8L),1L,(-1L),0xFAL,0xFAL},{0L,(-1L),(-1L),0L,(-2L),(-1L)},{0xC5L,0xD9L,(-9L),0x58L,1L,0x05L}},{{0L,0xC8L,0x54L,0x3CL,1L,(-10L)},{1L,0xD9L,0xFAL,0x6DL,(-2L),0xC0L},{0L,(-1L),0xFAL,0x06L,0xFAL,0xABL},{1L,(-8L),(-2L),0L,(-3L),0xABL},{0x3CL,(-10L),0xFAL,1L,(-10L),0xC0L},{1L,0xFEL,0xFAL,1L,0x54L,(-10L)},{0x58L,(-2L),0x54L,0L,0xC8L,0x05L},{0x58L,(-1L),(-9L),1L,(-9L),(-1L)},{1L,0x54L,(-1L),1L,(-1L),0xFAL},{0x3CL,0x4BL,1L,0L,0xABL,(-9L)}},{{1L,0x4BL,(-8L),0x06L,(-1L),(-8L)},{0L,0x54L,0x4BL,0x6DL,(-9L),0xFEL},{1L,(-1L),0x05L,0x3CL,0xC8L,0x4BL},{0L,(-2L),0x05L,0x58L,0x54L,0xFEL},{0xC5L,0xFEL,0x4BL,0L,(-10L),(-8L)},{0L,(-10L),(-8L),(-1L),(-3L),(-9L)},{0x6DL,(-8L),1L,(-1L),0xFAL,0xFAL},{0L,(-1L),(-1L),0L,(-2L),(-1L)},{0xC5L,0xD9L,(-9L),0x58L,1L,0x05L},{0L,0xC8L,0x54L,0x3CL,1L,(-10L)}},{{1L,0xD9L,0xFAL,0x6DL,(-2L),0xC0L},{0L,(-1L),0xFAL,0x06L,0xFAL,0xABL},{1L,(-8L),(-2L),0L,(-3L),0xABL},{0x3CL,(-10L),0xFAL,1L,0xD0L,0x23L},{(-1L),0x2BL,0L,0xFAL,0L,0xD0L},{(-8L),0x0DL,0L,(-2L),(-1L),5L},{(-8L),0L,0x7AL,0xFAL,0x7AL,0L},{(-1L),0L,0xB4L,0xFAL,0L,0L},{1L,0L,2L,0x54L,(-7L),0x7AL},{0xFAL,0L,1L,(-9L),0L,1L}}};
                    uint8_t **l_1385 = &g_534;
                    int i, j, k;
                    for (l_1273 = 0; (l_1273 < 3); ++l_1273)
                    { /* block id: 596 */
                        int32_t ***l_1373 = &l_116[2][2][1];
                        uint16_t *l_1382[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1382[i] = &g_651;
                        l_1375[1] ^= (((((0L >= (l_1372[2][3][6] = ((safe_lshift_func_int32_t_s_u_unsafe_macro/*28*//* ___SAFE__OP */((l_1363 && ((**g_852) |= 3L)), 11)) < (safe_rshift_func_uint8_t_u_s_unsafe_macro/*29*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*30*//* ___SAFE__OP */((***g_1287), (l_1370 = (+l_1369[1][9][4])))), (l_1371 < g_101.f5)))))) , &l_1258[1]) == ((*l_1373) = (void*)0)) == g_1374) < (*g_823));
                        (*l_1255) = (safe_sub_func_int64_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */(((0xA7C4257C227E1C66LL <= (((((*l_1289) |= ((*l_71) < (safe_lshift_func_uint64_t_u_s_unsafe_macro/*32*//* ___SAFE__OP */(0UL, (((*g_823) ^= l_1370) ^ g_1380))))) ^ l_1381) == (g_147[0] = (((((--g_651) && ((l_1385 != ((l_1369[1][9][4] | ((void*)0 == &g_1339)) , l_1386)) , (*l_71))) >= (*g_1192)) && l_1370) , 0xAAL))) & 1L)) , 0xBFCB05B5FEE95AC8LL), g_101.f2));
                        if (l_1372[2][3][6])
                            continue;
                    }
                }
            }
            if ((*g_1192))
                break;
        }
    }
    (*l_1255) = ((((safe_mul_func_int8_t_s_s_unsafe_macro/*33*//* ___SAFE__OP */(0x4EL, ((*g_1313) != ((*l_1391) = l_1389)))) , (((((*l_1398) = ((safe_mod_func_uint64_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*35*//* ___SAFE__OP */((((g_1396 , (func_33((*g_1192)) , ((*l_71) == (*l_1255)))) != (((1UL ^ (-1L)) , &l_116[2][0][1]) != l_1397)) , (*l_1255)), g_735.f6)), g_1097.f1)) , g_176)) || 0x89L) || l_1399) ^ l_1400)) , l_1401) == &l_116[3][2][1]);
    l_1402 = (void*)0;
    return g_62;
}


/* ------------------------------------------ */
/* 
 * reads : g_823 g_461 g_175 g_62 g_267 g_60 g_364 g_852 g_853 g_299 g_319.f5 g_534 g_535 g_274 g_51 g_996 g_564 g_173.f5 g_224 g_270 g_119 g_867.f7 g_23.f1 g_61 g_101.f2 g_106.f6 g_22 g_104 g_147 g_101.f6 g_143 g_101.f5 g_248 g_1097 g_326 g_298 g_286 g_292 g_1139 g_735.f2 g_1144 g_811 g_113 g_23.f7 g_23.f6 g_106.f0 g_101.f4 g_912.f0 g_1187 g_1192 g_1141 g_1204 g_1143 g_295 g_735.f7 g_912.f4 g_1244
 * writes: g_534 g_852 g_299 g_175 g_274 g_461 g_62 g_996 g_326 g_564 g_535 g_224 g_364 g_61 g_97 g_105 g_113 g_115 g_51 g_143 g_147 g_119 g_1084 g_67 g_176 g_402 g_1139 g_735.f2 g_1144 g_1141 g_49 g_1143 g_651
 */
static int32_t * func_2(uint8_t  p_3, uint16_t  p_4, int32_t * p_5, uint16_t  p_6)
{ /* block id: 394 */
    const uint32_t l_826[2][1] = {{0xC47E3F3DL},{0xC47E3F3DL}};
    int32_t l_842 = 0xF3AF7CC6L;
    int16_t **l_855 = &g_853;
    int8_t *l_876 = &g_326;
    int64_t l_994 = 0x5E927B7CD765327BLL;
    int32_t l_1023 = 0L;
    int32_t l_1028 = (-1L);
    int32_t l_1029 = 0L;
    uint16_t l_1030 = 1UL;
    uint32_t *l_1063[9] = {&g_811,&g_811,&g_811,&g_811,&g_811,&g_811,&g_811,&g_811,&g_811};
    int32_t l_1070[6][5] = {{0x787B05E6L,0x787B05E6L,4L,0x7F7D58C2L,0x87062700L},{(-1L),0x87062700L,(-6L),(-6L),0x87062700L},{0x87062700L,0x002F82FBL,(-1L),0x87062700L,(-6L)},{0x7F7D58C2L,0x87062700L,4L,0x87062700L,0x7F7D58C2L},{(-1L),0x787B05E6L,0x002F82FBL,(-6L),0x787B05E6L},{0x7F7D58C2L,0x002F82FBL,0x002F82FBL,0x7F7D58C2L,(-6L)}};
    int16_t l_1110 = 0x5C57L;
    int32_t l_1159[6] = {0xB7369C33L,0xB7369C33L,1L,0xB7369C33L,0xB7369C33L,1L};
    uint64_t *l_1179 = &g_364;
    uint64_t **l_1178 = &l_1179;
    volatile uint64_t ** const  volatile *l_1190 = &g_1191;
    int32_t *l_1233[7][4] = {{&g_176,&g_176,&l_1159[0],&l_1159[0]},{&g_176,&g_176,&l_1159[2],&g_176},{&g_176,&g_176,&l_1159[2],&g_176},{&g_176,&g_176,&l_1159[0],&l_1159[2]},{&g_176,&g_176,&g_176,&g_176},{&g_176,&g_176,&g_176,&g_176},{&g_176,&g_176,&g_176,&l_1159[0]}};
    int i, j;
    if ((l_826[0][0] ^ (*g_823)))
    { /* block id: 395 */
        const int32_t *l_833 = &g_62;
        const int32_t **l_832 = &l_833;
        const int32_t ***l_831 = &l_832;
        int32_t ***l_834 = &g_115;
        uint8_t **l_841 = &g_534;
        int64_t *l_843 = (void*)0;
        int64_t *l_844[7][8][4] = {{{&g_564,(void*)0,(void*)0,&g_564},{(void*)0,&g_564,&g_564,&g_564},{&g_224,(void*)0,&g_564,&g_564},{&g_224,&g_224,&g_224,&g_224},{(void*)0,&g_564,(void*)0,&g_224},{&g_224,&g_224,&g_224,&g_564},{(void*)0,&g_564,&g_564,&g_564},{&g_564,&g_224,&g_224,&g_224}},{{&g_564,&g_564,(void*)0,&g_224},{&g_564,&g_224,&g_564,&g_564},{&g_564,(void*)0,&g_564,&g_564},{&g_224,&g_564,&g_564,&g_564},{&g_224,(void*)0,&g_564,&g_564},{&g_224,&g_564,&g_564,&g_224},{(void*)0,&g_224,&g_564,(void*)0},{(void*)0,&g_224,(void*)0,&g_224}},{{&g_564,(void*)0,&g_564,&g_564},{&g_224,(void*)0,&g_224,&g_564},{&g_564,(void*)0,&g_224,&g_224},{&g_224,&g_224,&g_224,&g_224},{&g_224,&g_224,&g_224,&g_224},{&g_564,&g_564,&g_224,&g_224},{(void*)0,&g_564,&g_564,&g_224},{&g_564,&g_224,&g_564,&g_564}},{{&g_224,&g_564,&g_564,&g_564},{&g_224,&g_224,&g_224,&g_224},{&g_224,(void*)0,&g_224,(void*)0},{&g_564,&g_564,(void*)0,&g_224},{&g_564,&g_224,&g_564,&g_564},{&g_564,&g_224,(void*)0,&g_564},{&g_224,(void*)0,&g_224,&g_224},{&g_564,&g_564,&g_224,&g_224}},{{(void*)0,&g_224,&g_564,&g_224},{(void*)0,&g_224,&g_564,&g_564},{&g_564,&g_224,&g_564,&g_224},{&g_224,&g_224,&g_564,&g_224},{&g_224,&g_564,&g_224,&g_224},{&g_564,(void*)0,(void*)0,&g_564},{&g_564,&g_224,&g_564,&g_564},{&g_564,&g_224,&g_224,&g_224}},{{&g_564,&g_564,(void*)0,(void*)0},{&g_564,(void*)0,&g_224,&g_224},{&g_564,&g_224,&g_564,&g_564},{(void*)0,&g_564,&g_224,&g_564},{&g_564,&g_224,&g_224,&g_224},{&g_564,&g_564,&g_564,&g_224},{&g_224,&g_564,&g_224,&g_224},{&g_564,&g_224,&g_564,&g_224}},{{&g_564,&g_224,&g_224,(void*)0},{&g_224,&g_224,&g_564,&g_224},{&g_564,(void*)0,&g_224,(void*)0},{&g_564,&g_224,&g_224,(void*)0},{(void*)0,(void*)0,&g_564,&g_224},{&g_564,&g_224,&g_224,&g_564},{&g_564,&g_564,(void*)0,&g_224},{&g_564,&g_564,&g_224,(void*)0}}};
        int32_t l_845 = (-1L);
        int16_t *l_858 = &g_51;
        int32_t l_961 = 0x0E3FE977L;
        int32_t l_979 = 0x9327F59BL;
        int32_t l_981 = (-1L);
        int32_t l_982[9][3][5] = {{{0xE83E5AB5L,0x2E74D72DL,0L,2L,1L},{1L,0xB2F0E7FDL,0x74A600FCL,3L,1L},{1L,0x25F94E9AL,0x7BD52173L,0xE83E5AB5L,0xF54D2D22L}},{{0xE83E5AB5L,8L,(-1L),8L,0xE83E5AB5L},{1L,0L,0x523618A2L,0x13A38B08L,1L},{(-1L),(-5L),(-1L),0x508DA541L,0xB1B4A7E8L}},{{0x25F94E9AL,0L,0xB1B4A7E8L,0L,1L},{0xA780E3C7L,0x508DA541L,0xE77BD59FL,0x630EF020L,0xE83E5AB5L},{1L,0xA780E3C7L,(-5L),0x523618A2L,8L}},{{0L,0xA780E3C7L,9L,0x508DA541L,0x523618A2L},{1L,(-1L),(-5L),0x508DA541L,1L},{4L,0L,1L,0xB2F0E7FDL,0xB2F0E7FDL}},{{0L,0x98A269EEL,0L,(-1L),4L},{1L,(-5L),0xB1B4A7E8L,0x4D4D1262L,0L},{0x2E74D72DL,(-1L),1L,6L,(-5L)}},{{0xA780E3C7L,0x630EF020L,0xB1B4A7E8L,0L,0x278106CEL},{(-1L),0x278106CEL,0L,0x1433D532L,0x397FAAB3L},{0xE83E5AB5L,0L,1L,9L,0L}},{{0x523618A2L,0xE77BD59FL,(-5L),0x630EF020L,(-1L)},{0x98A269EEL,0xE77BD59FL,9L,(-5L),1L},{3L,0L,0L,0L,0L}},{{(-5L),0x278106CEL,(-1L),(-1L),(-5L)},{0x397FAAB3L,0x630EF020L,3L,2L,1L},{0x508DA541L,(-1L),0x7BD52173L,0x13A38B08L,0xB1B4A7E8L}},{{0x397FAAB3L,(-5L),0xB2F0E7FDL,0x2E74D72DL,0x7BD52173L},{(-5L),0x98A269EEL,0x278106CEL,0x523618A2L,8L},{3L,0L,(-1L),1L,6L}}};
        int32_t *l_1046 = &l_982[6][2][1];
        uint16_t l_1079 = 0UL;
        uint64_t *l_1099 = &g_113;
        int8_t l_1160 = 1L;
        int i, j, k;
        if ((safe_mod_func_uint16_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*37*//* ___SAFE__OP */((((l_831 == (l_834 = l_834)) <= ((safe_add_func_uint32_t_u_u_unsafe_macro/*38*//* ___SAFE__OP */(((((((**l_832) > ((**l_832) , (((g_267 , (safe_lshift_func_uint8_t_u_s(252UL, 2))) & 0x71L) != ((**l_832) , (l_845 = (l_842 = ((safe_add_func_int32_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */((((*l_841) = &g_535) == (void*)0), (*g_823))) >= p_6))))))) , g_60) , 0x51D2L) , (**l_832)) == p_6), (***l_831))) < l_826[1][0])) >= p_4), (-1L))), g_364)))
        { /* block id: 400 */
            int16_t ***l_854 = &g_852;
            uint16_t l_865 = 0x524AL;
            int32_t l_895 = (-4L);
            int32_t *l_901 = &g_299[0];
            uint64_t *l_922 = &g_364;
            (*p_5) ^= ((p_3 <= ((safe_sub_func_uint16_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */(((p_4 <= 0x74L) , (safe_div_func_uint32_t_u_u_unsafe_macro/*42*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_s_unsafe_macro/*43*//* ___SAFE__OP */(0xD112F3FFL, 30)) < (((*l_854) = g_852) == l_855)), (safe_add_func_int8_t_s_s_unsafe_macro/*44*//* ___SAFE__OP */((((*l_855) != (l_826[0][0] , l_858)) , p_6), p_3))))), 0x15AAL)) ^ l_826[0][0])) , l_826[0][0]);
            for (g_175 = 0; (g_175 <= 3); g_175 += 1)
            { /* block id: 405 */
                int32_t l_896[8] = {0x8B0A7379L,0x8B0A7379L,1L,0x8B0A7379L,0x8B0A7379L,1L,0x8B0A7379L,0x8B0A7379L};
                int32_t l_913[8][9][3] = {{{3L,0xFF8985BAL,0xCAC16C29L},{(-1L),7L,0xBC52626FL},{0x5808589DL,3L,0xCAC16C29L},{0x6EAE69AAL,1L,0x47508722L},{(-1L),0x33AC4FB4L,0x5808589DL},{0x1987A030L,0x47508722L,1L},{0x451B406BL,(-1L),0xA61958D7L},{0L,0x4F9C084CL,0x3ABC1736L},{1L,(-1L),1L}},{{0x9E40E6E8L,5L,0x4F9C084CL},{(-8L),0x91C7C9E5L,0x6B7896E5L},{0x124ACE62L,0x879BFC3AL,0xF6280FB5L},{(-1L),0xCAC16C29L,(-3L)},{0x124ACE62L,0xB3EB465FL,0x1987A030L},{(-8L),0x1732670EL,0x91C7C9E5L},{0x9E40E6E8L,0x7A1332C7L,(-1L)},{1L,1L,0x33AC4FB4L},{0L,0xCC78A28DL,5L}},{{0x451B406BL,0x8BAC9959L,0x8BAC9959L},{0x1987A030L,0x124ACE62L,1L},{(-1L),7L,(-4L)},{0x6EAE69AAL,(-5L),5L},{0x5808589DL,0xA61958D7L,0x451B406BL},{(-1L),(-5L),0xCC78A28DL},{3L,7L,(-1L)},{1L,0x124ACE62L,0x3CE764E7L},{0x843B9824L,0x8BAC9959L,0x5051D4A5L}},{{(-1L),0xCC78A28DL,4L},{0x8BAC9959L,1L,1L},{0x7A1332C7L,0x7A1332C7L,0xFB61E234L},{1L,0x1732670EL,0x451B406BL},{4L,1L,0x47508722L},{(-1L),(-1L),0L},{0x7A1332C7L,4L,0x47508722L},{1L,0xD6975148L,0x451B406BL},{0xF6280FB5L,0x9E40E6E8L,0x7A1332C7L}},{{0L,0x451B406BL,0x6B7896E5L},{(-1L),0x3ABC1736L,5L},{1L,0x5051D4A5L,0x33AC4FB4L},{0x6EAE69AAL,0xF6280FB5L,0x6EAE69AAL},{0x91C7C9E5L,(-7L),0x5051D4A5L},{0xFB61E234L,(-9L),0x879BFC3AL},{(-8L),0xA61958D7L,0x8BAC9959L},{0x3ABC1736L,0x47508722L,0xBC52626FL},{(-8L),1L,0L}},{{0xFB61E234L,(-1L),(-9L)},{0x91C7C9E5L,0x3F5EFAFFL,0xFF8985BAL},{0x6EAE69AAL,0x4F9C084CL,0x9E40E6E8L},{1L,3L,(-7L)},{(-1L),0xB3EB465FL,0xB3EB465FL},{0L,(-8L),0xD6975148L},{0xF6280FB5L,7L,0xE88AF516L},{1L,7L,1L},{0x7A1332C7L,5L,(-1L)}},{{(-1L),7L,3L},{4L,7L,0x3ABC1736L},{0x6B7896E5L,(-8L),0x34C59B13L},{(-1L),0xB3EB465FL,5L},{0xFF8985BAL,3L,(-3L)},{0xB3EB465FL,0x4F9C084CL,0xCC78A28DL},{0x3F5EFAFFL,0x3F5EFAFFL,0x843B9824L},{0xCC78A28DL,(-1L),0xF6280FB5L},{0xA61958D7L,1L,(-1L)}},{{0x4F9C084CL,0x47508722L,0x124ACE62L},{0x843B9824L,0xA61958D7L,(-1L)},{0xCB552DA0L,(-9L),0xF6280FB5L},{0x451B406BL,(-7L),0x843B9824L},{0xE88AF516L,0xF6280FB5L,0xCC78A28DL},{0x8BAC9959L,0x5051D4A5L,(-3L)},{(-1L),0x3ABC1736L,5L},{0x34C59B13L,0x451B406BL,0x34C59B13L},{1L,0x9E40E6E8L,0x3ABC1736L}}};
                struct S0 *l_943[2][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,&g_101,&g_248,&g_101,(void*)0},{(void*)0,&g_101,(void*)0,&g_106[0][2],&g_735,&g_735,&g_106[0][2],(void*)0}};
                int i, j, k;
            }
        }
        else
        { /* block id: 434 */
            int16_t l_952 = 0x030FL;
            int32_t l_970 = 0L;
            const uint32_t **l_1010 = (void*)0;
            const uint32_t ***l_1011 = (void*)0;
            const uint32_t ***l_1012 = &l_1010;
            uint32_t **l_1014 = &g_823;
            uint32_t ***l_1013 = &l_1014;
            int32_t * const ***l_1019 = (void*)0;
            int32_t * const ****l_1018 = &l_1019;
            int16_t ***l_1022 = &g_852;
            int32_t l_1069 = 0x592F1AA3L;
            int32_t l_1071 = (-1L);
            int32_t l_1072 = (-1L);
            int32_t l_1073 = (-6L);
            int32_t l_1074 = 0x8AD3EB48L;
            int8_t l_1075 = 0x49L;
            int32_t l_1076 = (-9L);
            int32_t l_1077 = 0xCA394A66L;
            int32_t l_1078 = 1L;
            (*p_5) = (safe_div_func_uint32_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */((**l_832), 0x66DE68D2L)), (((void*)0 == &g_691[6]) ^ ((((+(l_952 && (*p_5))) >= (l_858 == ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*48*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */(((safe_sub_func_uint8_t_u_u_unsafe_macro/*50*//* ___SAFE__OP */(((0x8CB71E1BD0CECA0FLL >= (safe_lshift_func_uint64_t_u_u(((*p_5) , 18446744073709551606UL), g_319.f5))) <= p_6), (*g_534))) <= (*g_534)), (-8L))), p_6)) , (void*)0))) == 0x8D3DA004L) , p_3)))) & l_961), l_952));
            for (l_845 = 0; (l_845 != 21); l_845++)
            { /* block id: 438 */
                int32_t l_980 = 1L;
                int32_t l_992 = 0xA4864098L;
                int32_t l_995 = 0x9EF23426L;
                for (p_6 = 0; (p_6 <= 8); p_6 += 1)
                { /* block id: 441 */
                    int i;
                    g_274[p_6] ^= (l_833 != p_5);
                }
                p_5 = p_5;
                for (g_461 = 23; (g_461 != 4); --g_461)
                { /* block id: 447 */
                    uint32_t l_983 = 4294967290UL;
                    int32_t *l_986 = (void*)0;
                    int32_t *l_987 = &g_119;
                    int32_t *l_988 = (void*)0;
                    int32_t *l_989 = &l_842;
                    int32_t *l_990 = (void*)0;
                    int32_t *l_991[2][8] = {{&l_979,&l_979,&l_845,&l_979,&l_979,&l_845,&l_979,&l_979},{&l_970,&l_979,&l_970,&l_970,&l_979,&l_970,&l_970,&l_979}};
                    int32_t l_993 = 0x4D1F7F9EL;
                    int i, j;
                    l_970 = ((255UL != (***l_831)) && ((p_3 && 0xE611127C44BEC8B4LL) , ((safe_div_func_uint16_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */(p_6, (safe_rshift_func_int32_t_s_s((((0xDC4568FBA63BB5BCLL >= p_3) != (0xA7A0L & (*g_853))) | 0L), (*p_5))))) ^ (*g_823))));
                    if ((*p_5))
                        break;
                    for (l_952 = 0; (l_952 > (-7)); l_952 = safe_sub_func_uint32_t_u_u_unsafe_macro/*54*//* ___SAFE__OP */(l_952, 7))
                    { /* block id: 452 */
                        int32_t l_973 = 1L;
                        int32_t *l_974 = &g_119;
                        int32_t *l_975 = &g_62;
                        int32_t *l_976 = &g_299[0];
                        int32_t *l_977 = &g_299[0];
                        int32_t *l_978[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_978[i] = (void*)0;
                        l_983--;
                        (*p_5) = l_842;
                        (*l_975) = l_980;
                    }
                    ++g_996;
                }
            }
            l_1023 |= (safe_lshift_func_int64_t_s_u((g_224 ^= ((*g_534) || ((*g_534) = ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */((((safe_sub_func_int8_t_s_s_unsafe_macro/*57*//* ___SAFE__OP */(((g_564 ^= ((~(p_3--)) < ((*l_876) = l_842))) & (safe_div_func_uint8_t_u_u_unsafe_macro/*58*//* ___SAFE__OP */((((*l_1012) = l_1010) != ((*l_1013) = &g_823)), (safe_unary_minus_func_int32_t_s_unsafe_macro/*59*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_s_unsafe_macro/*60*//* ___SAFE__OP */(1L, 3)) == ((l_1018 == ((g_173.f5 ^ (((*p_5) = (safe_sub_func_int32_t_s_s_unsafe_macro/*61*//* ___SAFE__OP */(((l_826[1][0] < (l_1022 != &g_852)) == p_6), 0x3E6188FCL))) , 0UL)) , &g_691[6])) , (*g_853)))))))), 0x7AL)) <= l_826[0][0]) > (*g_534)), (*g_534))) && (***l_831))))), 50));
            for (g_461 = (-20); (g_461 <= 54); g_461 = safe_add_func_int32_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */(g_461, 8))
            { /* block id: 471 */
                int32_t *l_1026 = &g_119;
                int32_t *l_1027[5];
                int64_t l_1045 = 0x0BE2304CA79E5B8BLL;
                uint64_t **l_1180 = &l_1179;
                int i;
                for (i = 0; i < 5; i++)
                    l_1027[i] = &l_982[3][0][3];
                --l_1030;
                for (g_996 = 0; (g_996 <= 2); g_996 += 1)
                { /* block id: 475 */
                    uint32_t l_1042 = 1UL;
                    uint64_t *l_1043 = (void*)0;
                    uint64_t *l_1044 = &g_364;
                    uint64_t l_1062 = 18446744073709551615UL;
                    int32_t l_1066 = 0x841B4FF9L;
                    int32_t l_1067 = (-1L);
                    int32_t l_1068[9];
                    uint32_t *l_1098 = &l_1042;
                    uint32_t *l_1137 = &g_175;
                    uint32_t *l_1138 = &g_1139[4][1][0];
                    uint32_t *l_1140[7] = {&g_1141,&g_1141,&g_1141,&g_1141,&g_1141,&g_1141,&g_1141};
                    uint8_t *l_1142[5][4] = {{&g_1143,&g_1143,&g_1143,&g_1143},{&g_1143,&g_1143,&g_1143,(void*)0},{&g_1143,&g_1143,(void*)0,(void*)0},{&g_1143,&g_1143,&g_1143,&g_1143},{&g_1143,&g_1143,&g_1143,&g_1143}};
                    int16_t ****l_1161[7] = {&l_1022,&l_1022,&l_1022,&l_1022,&l_1022,&l_1022,&l_1022};
                    uint8_t l_1186 = 0xEEL;
                    int i, j;
                    for (i = 0; i < 9; i++)
                        l_1068[i] = 0L;
                    l_1046 = func_38((l_1030 , p_3), (safe_mod_func_int8_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */((((((((safe_add_func_uint64_t_u_u_unsafe_macro/*64*//* ___SAFE__OP */(((*l_1044) |= ((((p_6 == (p_3 , (safe_rshift_func_int64_t_s_u_unsafe_macro/*65*//* ___SAFE__OP */(l_1028, p_4)))) & (!p_4)) || 0UL) ^ ((safe_mod_func_int64_t_s_s_unsafe_macro/*66*//* ___SAFE__OP */((g_564 = 0x49E9718E89E3FF68LL), g_270)) , l_1042))), 1UL)) > p_4) == 0xAC58A6C6L) & (*l_1026)) != p_3) && l_1045) <= g_867.f7), l_842)), l_994, p_3, p_5);
                    l_1026 = p_5;
                    l_1070[0][2] ^= ((*g_298) = (((safe_lshift_func_uint16_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */((g_402 = ((func_33((*p_5)) , ((((l_1079--) , (safe_mod_func_uint16_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */(65535UL, (g_1084 = ((*g_853) = (*g_853)))))) , (!(***l_831))) < (((safe_unary_minus_func_uint32_t_u_unsafe_macro/*69*//* ___SAFE__OP */(((*l_1098) &= ((((p_4 > (safe_add_func_uint8_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */((((safe_mul_func_uint8_t_u_u_unsafe_macro/*71*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*72*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*73*//* ___SAFE__OP */(((*l_876) ^= (safe_sub_func_uint8_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */(0xAAL, (((g_1097 , func_24(l_1027[4], p_6, (*l_1026))) == (void*)0) ^ p_3)))), p_3)) ^ p_4), (*g_534))), 0xF6L)) | l_1076) , 0UL), g_22))) , (*g_534)) , p_3) , 0x67338FC4L)))) >= (-10L)) & (*l_833)))) > p_6)), 4)) , l_1099) == (void*)0));
                    if ((safe_sub_func_int8_t_s_s_unsafe_macro/*75*//* ___SAFE__OP */(((safe_div_func_uint64_t_u_u_unsafe_macro/*76*//* ___SAFE__OP */(((*l_1044)++), ((((l_1110 = (safe_lshift_func_int8_t_s_u_unsafe_macro/*77*//* ___SAFE__OP */(0L, 1))) || ((*p_5) >= ((safe_mod_func_int16_t_s_s_unsafe_macro/*78*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */((((safe_div_func_int32_t_s_s_unsafe_macro/*80*//* ___SAFE__OP */(((g_564 = (g_224 = (safe_mod_func_int32_t_s_s_unsafe_macro/*81*//* ___SAFE__OP */(((p_3 = (safe_rshift_func_int32_t_s_u_unsafe_macro/*82*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*83*//* ___SAFE__OP */(((l_842 = (l_1070[5][2] = g_286[3])) , (safe_rshift_func_int8_t_s_u_unsafe_macro/*84*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */(p_4, ((safe_rshift_func_int64_t_s_u_unsafe_macro/*86*//* ___SAFE__OP */(((safe_mul_func_uint16_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */((g_292[5][3][3] & 0xB3L), ((**l_855) = 0xDB15L))) & (safe_lshift_func_int16_t_s_u_unsafe_macro/*88*//* ___SAFE__OP */((((safe_lshift_func_int8_t_s_s_unsafe_macro/*89*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*90*//* ___SAFE__OP */((g_735.f2 &= ((*l_1138) ^= ((*l_1137) = ((((*l_1098) = (((*g_534) ^= (p_4 && (g_248.f5 > 0x99L))) , (*g_823))) != (*g_823)) & p_4)))), (*p_5))), 7)) , (**l_832)) <= (**l_832)), 0))), g_299[0])) & l_1030))) > 0x4C1FFB69670B022CLL), p_3))), 4)), 16))) != g_1144[2]), (*p_5))))) & p_6), 0x78238F6EL)) >= g_248.f7) >= 0x7BL), g_811)), p_6)) & g_113))) , g_23.f7) , p_6))) & 0x9B8395E6L), 0x5CL)))
                    { /* block id: 506 */
                        const uint64_t *l_1155 = &g_364;
                        const uint64_t **l_1154 = &l_1155;
                        int32_t l_1158[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                        int16_t *****l_1163 = (void*)0;
                        int16_t *****l_1164 = &l_1161[2];
                        int i;
                        l_1023 = (((((**g_852) ^ ((safe_lshift_func_uint16_t_u_s_unsafe_macro/*91*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u_unsafe_macro/*92*//* ___SAFE__OP */((g_113 = (!l_1070[0][2])), (((((safe_lshift_func_int16_t_s_u_unsafe_macro/*93*//* ___SAFE__OP */((*g_853), (safe_mod_func_int8_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */(((*l_1046) = ((l_1154 == (void*)0) & (l_1028 = (safe_mod_func_int64_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */(p_4, (g_564 = ((((p_4 & l_1158[0]) , p_6) , l_1159[0]) , l_1160))))))), 0xFBL)))) <= l_1158[0]) ^ (**g_852)) , p_3) <= (*g_823)))), 5)) , 0xA24CL)) != p_6) | g_1097.f6) , (*p_5));
                        (*l_1164) = l_1161[1];
                    }
                    else
                    { /* block id: 513 */
                        (*l_832) = p_5;
                        return p_5;
                    }
                    for (l_979 = 2; (l_979 >= 0); l_979 -= 1)
                    { /* block id: 519 */
                        int i, j, k;
                        l_1186 = (l_1072 = (l_982[(l_979 + 1)][g_996][(g_996 + 2)] < (((safe_mod_func_uint16_t_u_u_unsafe_macro/*96*//* ___SAFE__OP */(g_23.f6, (((safe_add_func_int8_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_u_unsafe_macro/*98*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s_unsafe_macro/*99*//* ___SAFE__OP */(p_6, (((+(0x388FL & ((g_564 = ((safe_sub_func_int64_t_s_s_unsafe_macro/*100*//* ___SAFE__OP */(g_143, ((**l_1178) &= (l_1178 == l_1180)))) | (!((((*g_534) , ((safe_sub_func_int32_t_s_s_unsafe_macro/*101*//* ___SAFE__OP */(((*p_5) = ((((((*g_534) = (safe_rshift_func_uint32_t_u_s_unsafe_macro/*102*//* ___SAFE__OP */(0x094CFE5DL, 13))) >= 0x5BL) || g_104.f6) & (*g_853)) , (*p_5))), 0L)) <= g_106[1][0].f0)) < p_3) , (*p_5))))) && 7L))) , g_101.f4) , (*p_5)))), 12)), g_912.f0)) != l_982[(l_979 + 1)][g_996][(g_996 + 2)]) ^ 4294967293UL))) != 3L) <= 1L)));
                    }
                }
            }
        }
        l_1190 = g_1187[1][1][2];
        (*g_1192) |= (((*l_1046) , (void*)0) == l_841);
    }
    else
    { /* block id: 532 */
        const int32_t *l_1205 = &g_299[3];
        const int32_t **l_1206[2][7] = {{&l_1205,&l_1205,&l_1205,&l_1205,&l_1205,&l_1205,&l_1205},{&l_1205,&l_1205,&l_1205,&l_1205,&l_1205,&l_1205,&l_1205}};
        uint32_t **l_1210 = &g_823;
        uint32_t l_1234 = 1UL;
        uint8_t ***l_1247 = (void*)0;
        uint8_t **l_1249 = &g_534;
        uint8_t ***l_1248 = &l_1249;
        uint8_t **l_1251[7] = {&g_534,(void*)0,(void*)0,&g_534,(void*)0,(void*)0,&g_534};
        uint8_t ***l_1250 = &l_1251[1];
        int16_t **l_1252[5][3][3] = {{{&g_853,&g_853,(void*)0},{&g_853,&g_853,(void*)0},{(void*)0,&g_853,&g_853}},{{(void*)0,(void*)0,&g_853},{(void*)0,&g_853,(void*)0},{&g_853,(void*)0,&g_853}},{{&g_853,&g_853,&g_853},{&g_853,(void*)0,(void*)0},{&g_853,&g_853,(void*)0}},{{&g_853,(void*)0,&g_853},{&g_853,&g_853,(void*)0},{&g_853,&g_853,(void*)0}},{{(void*)0,&g_853,&g_853},{(void*)0,(void*)0,&g_853},{(void*)0,&g_853,(void*)0}}};
        int32_t l_1253 = 0x01D46DDDL;
        int32_t l_1254 = 0x054B4905L;
        int i, j, k;
        for (g_1141 = 26; (g_1141 < 33); g_1141 = safe_add_func_int64_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */(g_1141, 6))
        { /* block id: 535 */
            if (((void*)0 != &p_6))
            { /* block id: 536 */
                int8_t l_1202[9];
                int32_t l_1203 = (-9L);
                int i;
                for (i = 0; i < 9; i++)
                    l_1202[i] = 0L;
                l_1203 ^= ((*g_298) &= (safe_mul_func_uint32_t_u_u_unsafe_macro/*104*//* ___SAFE__OP */(p_6, (!(safe_mul_func_int64_t_s_s_unsafe_macro/*105*//* ___SAFE__OP */(l_1028, (p_6 >= ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*106*//* ___SAFE__OP */((l_1202[8] , p_3), 55)) == 0UL))))))));
                (*g_1204) &= ((*p_5) = 0xC8E6CB57L);
            }
            else
            { /* block id: 541 */
                if ((*p_5))
                    break;
                (*g_298) = (*p_5);
            }
        }
        g_49 = l_1205;
        for (g_1143 = 20; (g_1143 != 20); g_1143 = safe_add_func_int8_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */(g_1143, 3))
        { /* block id: 549 */
            uint32_t *l_1209 = &g_1141;
            int32_t *l_1232 = &g_176;
            int32_t **l_1231 = &l_1232;
            int64_t *l_1235 = &l_994;
            (*p_5) = (l_842 &= (0xB1ABD477296C0586LL && ((((*l_1209) ^= (*g_823)) , g_295) > ((l_1210 != &g_823) , ((*l_1235) = (((safe_add_func_uint32_t_u_u_unsafe_macro/*108*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*109*//* ___SAFE__OP */(p_4, (safe_mul_func_int64_t_s_s_unsafe_macro/*110*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_u_unsafe_macro/*111*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u_unsafe_macro/*112*//* ___SAFE__OP */((*l_1205), (safe_rshift_func_int32_t_s_s_unsafe_macro/*113*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s_unsafe_macro/*114*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */((((safe_mod_func_int64_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */((((l_1233[4][3] = ((*l_1231) = (void*)0)) == (l_1234 , p_5)) && (**g_852)), p_4)) || p_4) || g_735.f7), g_173.f5)), 6L)), g_912.f4)) != 0xD6L), (*p_5))))), 16)) , g_147[0]), l_826[0][0])))), (*p_5))) , 0xC66FCE44L) & 0x6D7A99ADL))))));
        }
        l_1254 = ((*p_5) = (p_4 , (l_1253 ^= (((safe_sub_func_uint16_t_u_u_unsafe_macro/*118*//* ___SAFE__OP */((g_651 = ((&g_534 != ((*l_1250) = ((*l_1248) = ((safe_mod_func_int32_t_s_s_unsafe_macro/*119*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*120*//* ___SAFE__OP */(0UL, 0)), (safe_sub_func_uint8_t_u_u_unsafe_macro/*121*//* ___SAFE__OP */((((l_1070[5][2] | 1UL) & (g_1244 , (safe_lshift_func_uint16_t_u_s_unsafe_macro/*122*//* ___SAFE__OP */((&g_651 == &p_6), ((*g_853) = (g_101.f4 & p_4)))))) != l_1070[1][4]), (*g_534))))) , (void*)0)))) && (-1L))), p_4)) , &g_853) != l_1252[1][2][1]))));
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_535 g_299 g_106.f6 g_22 g_104 g_147 g_101.f6 g_143 g_101.f5 g_248 g_101.f4 g_62 g_119 g_269 g_175 g_534 g_106.f2 g_268 g_298 g_651 g_292 g_106.f5 g_319.f5 g_402 g_319.f6 g_173.f0 g_51 g_735 g_173.f7 g_319.f7 g_101.f3 g_224 g_564 g_774 g_811 g_270
 * writes: g_535 g_61 g_51 g_143 g_147 g_119 g_113 g_97 g_62 g_564 g_636 g_402 g_651 g_60 g_299 g_691 g_224 g_175 g_101.f2 g_173.f2 g_774 g_461 g_811 g_823
 */
static uint8_t  func_13(uint8_t  p_14, int8_t  p_15, int32_t  p_16, int32_t * p_17)
{ /* block id: 277 */
    int32_t *l_585 = &g_119;
    int32_t *l_586 = &g_62;
    int32_t *l_587 = &g_299[3];
    int32_t *l_588 = &g_299[0];
    int32_t *l_589 = &g_119;
    int32_t l_590 = 0xB556509BL;
    int32_t *l_591 = &g_62;
    int32_t *l_592 = &g_119;
    int32_t *l_593 = &l_590;
    int32_t *l_594 = &g_299[0];
    int32_t *l_595 = &g_299[3];
    int32_t *l_596 = &g_299[0];
    int32_t *l_597 = &g_299[0];
    int32_t *l_598[9];
    uint32_t l_599 = 18446744073709551612UL;
    struct S0 *l_607 = &g_106[1][3];
    int32_t l_622[4][8] = {{0x24C4DEDEL,0xC5322E21L,(-1L),(-8L),0xC5322E21L,(-8L),(-1L),0xC5322E21L},{1L,(-1L),0x24C4DEDEL,1L,(-8L),(-8L),1L,0x24C4DEDEL},{0xC5322E21L,0xC5322E21L,1L,0xF35BC40AL,1L,1L,1L,0xF35BC40AL},{0x24C4DEDEL,0xF35BC40AL,0x24C4DEDEL,(-8L),0xF35BC40AL,(-1L),(-1L),0xF35BC40AL}};
    int32_t **l_667[1];
    int16_t *l_702 = &g_51;
    uint32_t *l_728 = &g_175;
    uint32_t **l_727[1][3];
    uint8_t l_747 = 0xF8L;
    uint64_t l_750 = 0x83A75AFEB2838237LL;
    int i, j;
    for (i = 0; i < 9; i++)
        l_598[i] = (void*)0;
    for (i = 0; i < 1; i++)
        l_667[i] = &g_118[0][2];
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_727[i][j] = &l_728;
    }
    --l_599;
    for (g_535 = 0; (g_535 < 59); g_535++)
    { /* block id: 281 */
        struct S0 *l_606 = (void*)0;
        int32_t l_608 = 0x7E811D5CL;
        (*l_586) &= ((((safe_lshift_func_int32_t_s_s_unsafe_macro/*123*//* ___SAFE__OP */((l_606 != l_607), 18)) , 0xF69B760AEEFF4FBELL) | ((func_33((*l_587)) , (1UL != (*l_594))) & g_101.f5)) ^ (g_101.f4 >= l_608));
    }
    for (g_119 = 3; (g_119 >= 0); g_119 -= 1)
    { /* block id: 286 */
        uint64_t l_611 = 0x569B85AA3731C6C6LL;
        uint8_t l_623[4][6] = {{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL}};
        int64_t *l_624 = (void*)0;
        int64_t *l_625 = &g_564;
        int32_t ***l_635 = &g_115;
        uint16_t *l_668[1][5][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_402,(void*)0,&g_402,(void*)0,&g_402},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_402,(void*)0,&g_402,(void*)0,&g_402},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
        struct S0 *l_705 = &g_106[1][4];
        int32_t l_723 = (-1L);
        int32_t l_724 = 0L;
        int32_t *****l_739[7] = {&g_691[8],&g_691[1],&g_691[8],&g_691[8],&g_691[1],&g_691[8],&g_691[8]};
        int8_t *l_751 = (void*)0;
        int8_t *l_752[2];
        int32_t *l_753 = &g_176;
        uint16_t *l_760 = &g_402;
        int16_t l_761 = 0xA00CL;
        int64_t l_768 = 0xCF5DFF4559D3496DLL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_752[i] = &g_143;
        if (g_269[g_119])
            break;
        if (((safe_rshift_func_uint16_t_u_u_unsafe_macro/*124*//* ___SAFE__OP */((l_611 ^ (p_14 ^ (safe_sub_func_uint8_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */(((((safe_sub_func_int32_t_s_s_unsafe_macro/*126*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*128*//* ___SAFE__OP */((g_62 <= (((*l_625) = (safe_sub_func_int32_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */(l_622[3][2], l_623[3][2]))) , (*l_589))), (((safe_rshift_func_int16_t_s_s_unsafe_macro/*130*//* ___SAFE__OP */((((*g_534) = (safe_mod_func_int8_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*132*//* ___SAFE__OP */(((+((safe_mod_func_int64_t_s_s_unsafe_macro/*133*//* ___SAFE__OP */(((g_636[8] = l_635) == (void*)0), (safe_mul_func_uint64_t_u_u_unsafe_macro/*134*//* ___SAFE__OP */(((((safe_div_func_int64_t_s_s_unsafe_macro/*135*//* ___SAFE__OP */((g_269[3] & p_14), g_175)) , (*l_586)) && (*l_597)) , p_14), (*l_597))))) && 0xE2941AA371DE1F6ALL)) > g_104.f4), p_16)), p_14))) > g_104.f2), g_101.f6)) , &g_104) == (void*)0))), 15)), p_16)) , 0xE0EC834DL) , l_625) == l_625), g_106[1][0].f2)))), g_147[0])) != (-3L)))
        { /* block id: 291 */
            uint16_t *l_649 = &g_402;
            uint16_t *l_650 = &g_651;
            int32_t *l_665 = (void*)0;
            uint8_t l_722 = 0xFAL;
            int i;
            (*l_586) ^= (((*l_650) = ((*l_649) = (2L <= (((safe_mul_func_uint8_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*137*//* ___SAFE__OP */((p_14 | 0L), (safe_sub_func_uint16_t_u_u_unsafe_macro/*138*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*139*//* ___SAFE__OP */((*g_534), 0x46L)), 0xDF39L)))), (g_268[2] > ((*l_589) != (*g_298))))) , p_15) || p_15)))) , 0xDDB75905L);
            for (g_651 = 0; (g_651 <= 3); g_651 += 1)
            { /* block id: 297 */
                int32_t l_652 = (-3L);
                int32_t ***l_700 = &l_667[0];
                for (g_60 = 0; (g_60 <= 3); g_60 += 1)
                { /* block id: 300 */
                    int32_t **l_666 = &l_598[7];
                    uint32_t *l_669 = &g_461;
                    int i, j, k;
                    if (g_292[g_119][g_651][g_651])
                        break;
                    if (l_652)
                        break;
                    (*l_591) ^= ((*l_588) = ((safe_sub_func_uint16_t_u_u_unsafe_macro/*140*//* ___SAFE__OP */((((((*g_534) = ((((safe_rshift_func_int64_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*142*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*143*//* ___SAFE__OP */((((safe_mod_func_uint16_t_u_u_unsafe_macro/*144*//* ___SAFE__OP */(g_269[g_119], (safe_mod_func_int16_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */((((p_17 == ((*l_666) = l_665)) , (&l_591 != (l_667[0] = &l_598[7]))) , ((-7L) && 0x27CAF80BL)), p_15)))) , (l_668[0][2][1] != (void*)0)) && l_652), p_15)) >= g_248.f4), (*g_534))), 24)) , p_14) , p_16) < g_106[1][0].f2)) , l_669) == &g_175) | g_248.f0), g_22)) || (*l_596)));
                }
                for (l_599 = 0; (l_599 <= 0); l_599 += 1)
                { /* block id: 311 */
                    uint64_t l_671 = 0x615056EDA0BCEA6BLL;
                    int32_t ****l_688 = &g_636[8];
                    int8_t l_701 = (-9L);
                    struct S0 *l_707 = (void*)0;
                    for (g_402 = 0; (g_402 <= 0); g_402 += 1)
                    { /* block id: 314 */
                        int32_t l_670 = 0x40FAD6C0L;
                        int32_t ****l_690 = &g_636[4];
                        int32_t *****l_689[7] = {&l_690,&l_690,&l_690,&l_690,&l_690,&l_690,&l_690};
                        int16_t *l_698 = (void*)0;
                        int16_t *l_699[3][2];
                        struct S0 **l_706[4] = {&l_705,&l_705,&l_705,&l_705};
                        uint32_t *l_717 = (void*)0;
                        uint32_t *l_718 = &g_175;
                        uint32_t *l_721[8][6][5] = {{{(void*)0,(void*)0,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,(void*)0,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,(void*)0,&g_461},{&g_461,&g_461,(void*)0,&g_461,&g_461}},{{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,(void*)0,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,(void*)0},{&g_461,&g_461,&g_461,&g_461,&g_461}},{{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,(void*)0},{&g_461,(void*)0,&g_461,(void*)0,&g_461}},{{&g_461,(void*)0,(void*)0,&g_461,&g_461},{&g_461,&g_461,(void*)0,&g_461,&g_461},{&g_461,&g_461,&g_461,(void*)0,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461}},{{&g_461,(void*)0,&g_461,(void*)0,&g_461},{&g_461,(void*)0,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,(void*)0,&g_461},{(void*)0,&g_461,&g_461,&g_461,&g_461}},{{&g_461,&g_461,(void*)0,&g_461,(void*)0},{&g_461,(void*)0,(void*)0,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,&g_461,(void*)0},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,(void*)0}},{{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,&g_461,&g_461},{&g_461,&g_461,&g_461,(void*)0,&g_461}},{{&g_461,&g_461,&g_461,&g_461,(void*)0},{&g_461,&g_461,(void*)0,&g_461,&g_461},{&g_461,&g_461,&g_461,(void*)0,&g_461},{&g_461,&g_461,&g_461,&g_461,&g_461},{(void*)0,&g_461,&g_461,&g_461,&g_461},{&g_461,(void*)0,&g_461,&g_461,(void*)0}}};
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_699[i][j] = &g_51;
                        }
                        --l_671;
                        (*l_593) = (safe_add_func_int16_t_s_s_unsafe_macro/*146*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*147*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*148*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*149*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*150*//* ___SAFE__OP */(((((safe_sub_func_uint64_t_u_u_unsafe_macro/*151*//* ___SAFE__OP */(l_652, (safe_sub_func_int64_t_s_s_unsafe_macro/*152*//* ___SAFE__OP */((l_688 == (g_691[6] = &l_635)), ((g_106[1][0].f2 < (safe_add_func_int64_t_s_s_unsafe_macro/*153*//* ___SAFE__OP */((0x46C5L < ((p_15 = (((((p_15 && ((((((*l_625) = ((g_51 = ((safe_add_func_int8_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */((((*l_591) &= (safe_mod_func_uint32_t_u_u_unsafe_macro/*155*//* ___SAFE__OP */((p_17 != ((*g_298) , (void*)0)), 0x1B7DD39AL))) , g_106[1][0].f5), p_16)) <= g_319.f5)) ^ (-1L))) , l_700) == &g_115) , 0xF2L) && (-8L))) , l_701) > p_16) ^ p_14) == g_402)) != g_299[0])), 18446744073709551615UL))) >= (*p_17)))))) | 0x0B04474553793FE1LL) , l_702) != (void*)0), p_14)), g_101.f5)), g_106[1][0].f2)), g_106[1][0].f6)), 3UL));
                        l_724 ^= (((((safe_add_func_int32_t_s_s_unsafe_macro/*156*//* ___SAFE__OP */(((*l_597) = ((((l_723 &= ((0xFE8B87D1CDEC4471LL >= (g_224 = (((*l_591) = ((l_705 = l_705) == l_707)) , g_319.f6))) > (safe_div_func_uint64_t_u_u_unsafe_macro/*157*//* ___SAFE__OP */((7L && (((*l_593) |= (*p_17)) > ((((safe_mod_func_int8_t_s_s_unsafe_macro/*158*//* ___SAFE__OP */((~((safe_add_func_uint64_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */((((((*l_718) ^= g_173.f0) >= (((((g_173.f2 = (g_299[0] || ((g_101.f2 = ((safe_lshift_func_int8_t_s_u_unsafe_macro/*160*//* ___SAFE__OP */(((0x00F0D820L != (*p_17)) <= p_16), 3)) , 0UL)) ^ 7L))) , 255UL) || g_104.f6) | g_106[1][0].f6) & 1L)) < l_701) | 7UL), 0x163E8F9C53B61D14LL)) && l_722)), (*g_534))) , g_299[4]) , p_14) >= 0x60499429L))), p_14)))) > 0x5AB89270L) , (-1L)) <= p_15)), (-1L))) , g_106[1][0].f2) || p_14) != g_535) ^ 0x3EL);
                    }
                }
                if ((*p_17))
                    continue;
            }
            for (g_51 = 17; (g_51 <= 10); g_51 = safe_sub_func_int16_t_s_s_unsafe_macro/*161*//* ___SAFE__OP */(g_51, 7))
            { /* block id: 338 */
                return (*g_534);
            }
        }
        else
        { /* block id: 341 */
            int16_t l_736[8] = {(-1L),0L,(-1L),(-1L),0L,(-1L),(-1L),0L};
            int32_t l_746 = 1L;
            int i;
            (*l_593) ^= (*p_17);
            (*p_17) ^= ((void*)0 == l_727[0][1]);
            l_747 ^= (safe_mul_func_int32_t_s_s_unsafe_macro/*162*//* ___SAFE__OP */((p_15 ^ ((safe_div_func_uint16_t_u_u_unsafe_macro/*163*//* ___SAFE__OP */((l_746 = ((253UL > ((safe_mul_func_int32_t_s_s_unsafe_macro/*164*//* ___SAFE__OP */((((*l_597) & ((g_735 , l_736[7]) ^ ((safe_div_func_uint32_t_u_u_unsafe_macro/*165*//* ___SAFE__OP */(1UL, ((g_564 = ((l_739[6] != &g_691[6]) | ((((((((*l_586) = (safe_mul_func_uint16_t_u_u_unsafe_macro/*166*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s_unsafe_macro/*167*//* ___SAFE__OP */(((*l_702) = ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*168*//* ___SAFE__OP */(l_736[7], 15)) ^ p_16)), 0xC0E7L)) & 0xBBE9DB13L), 0x3732L))) | g_173.f7) >= 1L) >= (*l_597)) == 0x70A23E8BL) && 0xCCL) , p_15))) || p_15))) || 9UL))) , 0xC5727F2DL), g_104.f0)) > 1UL)) , 65535UL)), 0x46FAL)) ^ p_14)), 0x9FE0B9CDL));
        }
        if ((safe_mul_func_uint32_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */(l_750, (((((p_15 = (g_147[0] = 0xF1L)) , &p_16) != l_753) || (g_143 = (p_15 = ((((*g_534)++) > g_319.f7) == (safe_div_func_uint16_t_u_u_unsafe_macro/*170*//* ___SAFE__OP */(p_14, ((*l_702) ^= (((((safe_rshift_func_int8_t_s_s_unsafe_macro/*171*//* ___SAFE__OP */((-7L), (((p_15 > (p_16 & 0x5DFC91FFC9CE1A2CLL)) || g_22) , 0x25L))) , &g_651) == l_760) || g_735.f1) >= l_761)))))))) >= g_248.f0))))
        { /* block id: 356 */
            uint32_t l_769 = 4294967286UL;
            const uint8_t l_775 = 0xF9L;
            uint32_t *l_776 = &g_774;
            p_17 = ((((*l_728) |= ((*p_17) & ((safe_add_func_uint32_t_u_u_unsafe_macro/*172*//* ___SAFE__OP */((((*l_776) = (((safe_lshift_func_uint64_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */(g_101.f3, (safe_lshift_func_int32_t_s_s_unsafe_macro/*174*//* ___SAFE__OP */(((((((g_224 != ((void*)0 != &p_17)) & (l_768 == ((*l_586) = (l_769 > (((safe_lshift_func_int8_t_s_u_unsafe_macro/*175*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */(g_564, p_16)), 1)) , (void*)0) != &g_318[2]))))) , (*l_597)) , g_774) & 0L) , l_775), 31)))) , p_15) && l_769)) , 1UL), p_14)) <= (*l_588)))) == 6L) , (void*)0);
            return p_14;
        }
        else
        { /* block id: 362 */
            uint64_t l_795 = 0x9247AAB877602A73LL;
            const int64_t *l_802 = &g_224;
            int32_t **** const l_817 = &g_636[8];
            int16_t *l_822 = &g_51;
            if ((*p_17))
                break;
            for (g_774 = 0; (g_774 != 41); g_774 = safe_add_func_uint8_t_u_u_unsafe_macro/*177*//* ___SAFE__OP */(g_774, 1))
            { /* block id: 366 */
                int16_t **l_793 = &l_702;
                int32_t l_794 = 0xA314B906L;
                uint32_t l_824[3][10] = {{4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL},{4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL},{4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL,4294967287UL,0UL}};
                int i, j;
                (*l_593) = (((safe_add_func_int16_t_s_s_unsafe_macro/*178*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*179*//* ___SAFE__OP */(0x2FDF17A85BC1D618LL, ((*p_17) != ((safe_mod_func_int8_t_s_s_unsafe_macro/*180*//* ___SAFE__OP */((((&l_607 == (void*)0) == ((safe_mod_func_uint8_t_u_u_unsafe_macro/*181*//* ___SAFE__OP */((((*g_534) = (((g_248.f3 , ((*g_534) != p_15)) > ((safe_mod_func_int64_t_s_s_unsafe_macro/*182*//* ___SAFE__OP */(g_173.f7, (((((safe_mod_func_uint16_t_u_u_unsafe_macro/*183*//* ___SAFE__OP */(0UL, g_175)) , (void*)0) != l_793) , 18446744073709551615UL) | 1L))) > (*g_534))) ^ p_16)) <= 1UL), g_119)) || (*p_17))) >= 0x6747DCAE9A43A68ELL), l_794)) , 1L)))), 0xAAD7L)) , 0xFDA62A56L) && 1L);
                (*l_597) = (*p_17);
                (*l_596) = l_795;
                for (g_51 = 2; (g_51 <= 8); g_51 += 1)
                { /* block id: 373 */
                    int64_t **l_800 = (void*)0;
                    int64_t **l_801 = &l_624;
                    int8_t *l_808 = (void*)0;
                    int16_t *l_809[5];
                    int32_t l_810 = (-1L);
                    int i;
                    for (i = 0; i < 5; i++)
                        l_809[i] = &l_761;
                    for (g_461 = 0; (g_461 <= 8); g_461 += 1)
                    { /* block id: 376 */
                        return p_15;
                    }
                    (*l_593) = ((safe_sub_func_uint16_t_u_u_unsafe_macro/*184*//* ___SAFE__OP */(1UL, ((l_794 , (g_811 ^= (l_810 |= (safe_div_func_uint8_t_u_u_unsafe_macro/*185*//* ___SAFE__OP */((((*l_588) = (*p_17)) >= (((*l_801) = &l_768) == l_802)), (l_795 || ((((~(((((safe_mod_func_uint8_t_u_u_unsafe_macro/*186*//* ___SAFE__OP */(250UL, (*g_534))) >= (safe_mod_func_uint8_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */(((l_808 != l_752[1]) <= 4UL), 0x08L))) >= g_248.f3) | g_147[0]) > 0x3315345FL)) <= p_14) || 0xF64F26E87AA96214LL) | 0xDEL))))))) < 1UL))) , 0x28D1DE7BL);
                    (*l_593) = ((~((((((((p_16 >= ((safe_rshift_func_int64_t_s_s_unsafe_macro/*188*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s_unsafe_macro/*189*//* ___SAFE__OP */(0xB724L, ((void*)0 != l_817))) && (g_292[4][5][2] , (safe_add_func_uint16_t_u_u_unsafe_macro/*190*//* ___SAFE__OP */(((((safe_lshift_func_int64_t_s_s_unsafe_macro/*191*//* ___SAFE__OP */(((p_14 , l_753) != (g_823 = &g_175)), 24)) || (*l_591)) > p_16) != l_794), g_270)))), 24)) | 0xFCL)) , p_16) <= (*p_17)) | l_824[0][4]) ^ (-1L)) < g_101.f5) && p_14) <= (*g_534))) ^ 1UL);
                    (*l_593) |= (*p_17);
                }
            }
        }
        return p_14;
    }
    return (*g_534);
}


/* ------------------------------------------ */
/* 
 * reads : g_143 g_298 g_299 g_119 g_274 g_106 g_286 g_318 g_176 g_51 g_147 g_104.f7 g_281 g_248.f1 g_343 g_279 g_326 g_292 g_248.f0 g_104.f2 g_272 g_364 g_282 g_402 g_429 g_104.f5 g_97 g_62 g_101.f6 g_273 g_319.f6 g_271 g_173.f1 g_22 g_104.f4 g_224 g_101.f4 g_500 g_319.f3 g_534 g_248.f2 g_173.f4 g_101.f1 g_564 g_535 g_23.f0
 * writes: g_143 g_62 g_274 g_175 g_147 g_326 g_60 g_119 g_299 g_51 g_113 g_364 g_402 g_105 g_173.f2 g_176 g_500 g_104.f2 g_534 g_224 g_67
 */
static int32_t  func_18(const uint16_t  p_19, uint32_t  p_20, int32_t * p_21)
{ /* block id: 140 */
    uint8_t l_320 = 0x86L;
    int32_t l_321 = 0x78D56A65L;
    struct S0 **l_349 = &g_105;
    int32_t l_352 = 0x325F09CDL;
    int32_t l_371[4] = {0xAEAC3A32L,0xAEAC3A32L,0xAEAC3A32L,0xAEAC3A32L};
    uint8_t *l_382 = (void*)0;
    uint8_t *l_383 = &l_320;
    int8_t l_386 = 0xE7L;
    uint32_t l_388 = 2UL;
    int32_t ***l_392 = (void*)0;
    int32_t ****l_391[1];
    int16_t *l_431[7][1][2] = {{{&g_51,&g_51}},{{&g_51,&g_51}},{{&g_51,&g_51}},{{&g_51,&g_51}},{{&g_51,&g_51}},{{&g_51,&g_51}},{{&g_51,&g_51}}};
    int16_t **l_430[6][9][2] = {{{&l_431[3][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[6][0][0]},{&l_431[4][0][1],(void*)0},{&l_431[0][0][1],&l_431[0][0][1]},{&l_431[6][0][1],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]}},{{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[6][0][1],&l_431[0][0][1]},{&l_431[0][0][1],(void*)0},{&l_431[4][0][1],&l_431[6][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[3][0][0],&l_431[1][0][1]}},{{&l_431[2][0][0],&l_431[1][0][1]},{&l_431[3][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[6][0][0]},{&l_431[4][0][1],(void*)0},{&l_431[0][0][1],&l_431[0][0][1]},{&l_431[6][0][1],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]}},{{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[6][0][1],&l_431[0][0][1]},{&l_431[0][0][1],(void*)0},{&l_431[4][0][1],&l_431[6][0][0]},{&l_431[0][0][0],&l_431[0][0][0]}},{{&l_431[3][0][0],&l_431[1][0][1]},{&l_431[2][0][0],&l_431[1][0][1]},{&l_431[3][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[6][0][0]},{&l_431[4][0][1],(void*)0},{&l_431[0][0][1],&l_431[0][0][1]},{&l_431[6][0][1],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]}},{{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[0][0][0],&l_431[2][0][0]},{&l_431[0][0][0],&l_431[0][0][0]},{&l_431[6][0][1],&l_431[0][0][1]},{&l_431[0][0][1],(void*)0},{&l_431[0][0][0],&l_431[0][0][0]}}};
    int16_t *l_460 = (void*)0;
    const int32_t *l_466 = &l_321;
    int64_t l_467 = 5L;
    uint32_t *l_472 = (void*)0;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_391[i] = &l_392;
    for (g_143 = 0; (g_143 <= 8); g_143 += 1)
    { /* block id: 143 */
        int64_t l_317 = (-1L);
        uint32_t *l_322 = &g_175;
        uint8_t *l_323 = &l_320;
        int8_t *l_324 = &g_147[0];
        int8_t *l_325 = &g_326;
        struct S0 **l_348 = (void*)0;
        uint32_t l_350 = 0xC5D97952L;
        int32_t l_375 = 0xA5320807L;
        int16_t l_389 = 0x9569L;
        int32_t l_390 = 0x68A8FD14L;
        int32_t l_394 = 6L;
        int8_t l_538 = 1L;
        uint8_t *l_546 = &l_320;
        int32_t **l_555 = &g_118[9][2];
        for (g_62 = 6; (g_62 >= 2); g_62 -= 1)
        { /* block id: 146 */
            int i;
            g_274[g_143] = (*g_298);
            if ((*p_21))
                break;
            return g_274[g_143];
        }
        if ((((safe_add_func_uint64_t_u_u_unsafe_macro/*192*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_u_unsafe_macro/*193*//* ___SAFE__OP */(((*l_325) = ((*l_324) &= (safe_add_func_int64_t_s_s_unsafe_macro/*194*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u((safe_div_func_int32_t_s_s_unsafe_macro/*196*//* ___SAFE__OP */((((g_106[1][0] , (g_286[5] != (((*l_323) = ((safe_mul_func_int16_t_s_s_unsafe_macro/*197*//* ___SAFE__OP */(0x2AE0L, (((*l_322) = ((~(((safe_div_func_int64_t_s_s_unsafe_macro/*198*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*199*//* ___SAFE__OP */(((l_321 = ((p_20 , (0x230FD66C7585B619LL ^ (l_317 > (g_318[2] != (g_176 , (l_320 , (void*)0)))))) < 0UL)) && 0x71AAL), l_320)), 6UL)) || l_317) , l_320)) == p_20)) || l_317))) < 2L)) | l_317))) ^ p_19) , l_317), 0xB5FAAD63L)), g_51)), 0x6D76849D5BDE55AFLL)))), p_20)), g_104.f7)) || g_281) , (*p_21)))
        { /* block id: 156 */
            const int32_t *l_327 = &g_299[0];
            const int32_t *l_328 = &l_321;
            int32_t l_351 = 1L;
            int i;
            for (g_60 = 0; (g_60 <= 8); g_60 += 1)
            { /* block id: 159 */
                l_328 = l_327;
            }
            l_352 &= (l_351 |= (safe_div_func_uint64_t_u_u_unsafe_macro/*200*//* ___SAFE__OP */(((((safe_mul_func_uint32_t_u_u_unsafe_macro/*201*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u_unsafe_macro/*202*//* ___SAFE__OP */(((*l_325) |= (safe_div_func_uint8_t_u_u_unsafe_macro/*203*//* ___SAFE__OP */((l_321 , ((safe_div_func_uint16_t_u_u((safe_unary_minus_func_int8_t_s_unsafe_macro/*205*//* ___SAFE__OP */((l_320 & ((-7L) && ((((p_19 | ((safe_mod_func_int64_t_s_s_unsafe_macro/*206*//* ___SAFE__OP */(0x02055A8E9C823D7ELL, g_248.f1)) <= ((((~(g_343 , ((*l_324) |= (safe_lshift_func_int32_t_s_s(l_317, 1))))) && (safe_lshift_func_int32_t_s_u_unsafe_macro/*208*//* ___SAFE__OP */(((*p_21) = l_317), g_279))) , l_348) == l_349))) | 1L) | 247UL) >= p_19))))), g_143)) <= l_350)), l_350))), p_20)), 1UL)) == l_350) && g_292[5][4][3]) >= g_248.f0), 0x4B9194847A4CA32ELL)));
        }
        else
        { /* block id: 167 */
            uint8_t *l_380 = &l_320;
            int64_t l_393 = 0x7084BD0766162521LL;
            for (g_51 = 0; (g_51 > (-1)); g_51 = safe_sub_func_int64_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */(g_51, 1))
            { /* block id: 170 */
                uint64_t *l_361 = &g_113;
                int64_t *l_362[8] = {&l_317,(void*)0,(void*)0,&l_317,(void*)0,(void*)0,&l_317,(void*)0};
                int32_t l_367 = 0L;
                int32_t *l_370[4][7][4] = {{{&g_119,(void*)0,&g_119,&g_119},{&g_62,&g_62,(void*)0,&g_62},{(void*)0,&g_62,&g_62,&g_119},{&g_119,&g_62,&g_62,&g_62},{(void*)0,&g_62,(void*)0,&g_119},{&g_62,&g_62,&g_62,&g_62},{&g_62,&g_62,&g_62,&g_119}},{{&g_62,(void*)0,&g_62,&g_62},{&g_119,&g_62,&g_62,&g_62},{&g_119,(void*)0,&g_62,&g_119},{&g_62,&g_62,&g_62,&g_62},{&g_62,&g_119,&g_62,&g_119},{&g_62,&g_119,(void*)0,&g_119},{(void*)0,&g_62,&g_62,&g_119}},{{&g_119,&g_119,&g_62,&g_119},{(void*)0,&g_119,(void*)0,&g_62},{&g_62,&g_62,&g_119,&g_119},{&g_119,(void*)0,&g_119,&g_62},{&g_62,&g_62,&g_119,&g_62},{&g_119,(void*)0,&g_119,&g_119},{&g_62,&g_62,(void*)0,&g_62}},{{(void*)0,&g_62,&g_62,&g_119},{&g_119,&g_62,&g_62,&g_62},{(void*)0,&g_62,(void*)0,&g_119},{&g_62,&g_62,&g_62,&g_62},{&g_62,&g_62,&g_62,&g_119},{&g_62,(void*)0,&g_62,&g_62},{&g_119,&g_62,&g_62,&g_62}}};
                uint8_t **l_381 = &l_323;
                int i, j, k;
                l_371[3] &= (((g_104.f2 && (safe_mod_func_int32_t_s_s_unsafe_macro/*210*//* ___SAFE__OP */((l_367 = ((*g_298) &= ((l_320 , (safe_lshift_func_int64_t_s_u_unsafe_macro/*211*//* ___SAFE__OP */(g_272, (safe_mul_func_uint64_t_u_u_unsafe_macro/*212*//* ___SAFE__OP */(((*l_361) = 0xEC152A44410B750BLL), (l_321 = (p_19 || g_143))))))) | (0x0A25L ^ (safe_unary_minus_func_uint8_t_u_unsafe_macro/*213*//* ___SAFE__OP */((--g_364))))))), (safe_div_func_uint16_t_u_u_unsafe_macro/*214*//* ___SAFE__OP */(p_20, (((p_20 == 0xD47AEF6B9B6700EELL) != p_19) || 1UL)))))) == 0xC8L) , 1L);
                l_394 = (0x30L < (!(safe_rshift_func_int8_t_s_s_unsafe_macro/*215*//* ___SAFE__OP */(((*l_325) = g_282), (((0xA4L <= ((((((((l_375 = 0L) == ((safe_add_func_int32_t_s_s_unsafe_macro/*216*//* ___SAFE__OP */(l_350, (((safe_mul_func_int32_t_s_s_unsafe_macro/*217*//* ___SAFE__OP */(((*g_298) = ((l_382 = ((*l_381) = l_380)) != (l_383 = l_325))), ((safe_rshift_func_int16_t_s_s_unsafe_macro/*218*//* ___SAFE__OP */(((((l_390 = (((*l_380) = (((l_386 , (((+18446744073709551607UL) | l_388) <= l_389)) , 0x2F1FL) && p_20)) || 5L)) == l_317) , l_380) != (void*)0), l_388)) ^ l_317))) , g_106[1][0].f6) == 0x86BD966C9633A9F3LL))) , p_20)) , (void*)0) == l_391[0]) || l_393) || l_389) ^ 9UL) < p_19)) != p_20) < p_19)))));
            }
            for (l_375 = 0; (l_375 >= 0); l_375 -= 1)
            { /* block id: 189 */
                int i;
                l_371[(l_375 + 2)] = g_147[l_375];
            }
        }
        for (l_389 = 0; (l_389 <= 2); l_389 += 1)
        { /* block id: 195 */
            const int32_t *l_396[9][7] = {{&l_375,&l_394,&l_375,&l_394,&l_375,&l_394,&l_375},{&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)],&l_394,&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)]},{(void*)0,&l_394,(void*)0,&l_394,(void*)0,&l_394,(void*)0},{&l_394,&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)],&l_394,&l_394,&g_299[(l_389 + 2)]},{&l_375,&l_394,&l_375,&l_394,&l_375,&l_394,&l_375},{&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)],&l_394,&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)]},{(void*)0,&l_394,(void*)0,&l_394,(void*)0,&l_394,(void*)0},{&l_394,&l_394,&g_299[(l_389 + 2)],&g_299[(l_389 + 2)],&l_394,&l_394,&g_299[(l_389 + 2)]},{&l_375,&l_394,&l_375,&l_394,&l_375,&l_394,&l_375}};
            const int32_t **l_395 = &l_396[2][2];
            int32_t **l_398[1][6];
            const struct S0 *l_407 = &g_248;
            int64_t l_427 = (-1L);
            uint16_t l_432 = 65530UL;
            uint32_t l_465 = 6UL;
            int8_t *l_553 = &g_147[0];
            int8_t *l_554 = &l_386;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 6; j++)
                    l_398[i][j] = &g_118[0][5];
            }
            g_299[(l_389 + 2)] = l_350;
            for (l_317 = 2; (l_317 <= 8); l_317 += 1)
            { /* block id: 199 */
                const int32_t ***l_397 = &l_395;
                int32_t **l_399 = &g_117[1];
                uint16_t *l_400 = (void*)0;
                uint16_t *l_401 = &g_402;
                int32_t l_428[3][6] = {{0xF7CA3DB3L,2L,(-1L),(-1L),2L,0xB498175CL},{2L,0xB498175CL,0L,(-1L),0L,0xB498175CL},{0L,2L,0L,0x33229771L,0x33229771L,0L}};
                uint8_t *l_533 = &l_320;
                int i, j;
                if ((((*l_401) &= (((*l_397) = l_395) == (l_399 = l_398[0][0]))) > (safe_div_func_int64_t_s_s_unsafe_macro/*219*//* ___SAFE__OP */((l_371[l_389] <= ((g_326 ^= ((5UL == (safe_add_func_int8_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */(((g_105 = (void*)0) == l_407), (safe_rshift_func_int8_t_s_u_unsafe_macro/*221*//* ___SAFE__OP */(((*l_324) = g_274[g_143]), (safe_div_func_uint64_t_u_u_unsafe_macro/*222*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*223*//* ___SAFE__OP */((l_432 |= (((safe_mul_func_uint8_t_u_u_unsafe_macro/*224*//* ___SAFE__OP */((g_299[g_143] < ((((safe_rshift_func_int16_t_s_u((safe_sub_func_uint32_t_u_u_unsafe_macro/*226*//* ___SAFE__OP */(((safe_lshift_func_uint32_t_u_s_unsafe_macro/*227*//* ___SAFE__OP */(((safe_unary_minus_func_int8_t_s_unsafe_macro/*228*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*229*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*230*//* ___SAFE__OP */(p_20, 0xA05F37A506C2C957LL)), p_19)))) < 0xE1E8L), 23)) > (-8L)), 0xB9EE69BDL)), 15)) , p_19) ^ g_106[1][0].f6) , l_427)), l_428[0][2])) , g_429) == l_430[1][1][1])), g_104.f2)), g_104.f5))))))) >= 0x85A3C821BC8BA40DLL)) > p_19)), p_19))))
                { /* block id: 207 */
                    uint32_t * const l_439 = &g_175;
                    int32_t l_440[1];
                    int8_t l_462[8][3] = {{8L,(-3L),1L},{0L,(-3L),0L},{0L,8L,1L},{0L,0L,8L},{0L,8L,8L},{8L,(-3L),1L},{0L,(-3L),0L},{0L,8L,1L}};
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_440[i] = (-5L);
                    for (l_352 = 0; (l_352 <= 3); l_352 += 1)
                    { /* block id: 210 */
                        uint64_t l_447 = 1UL;
                        int32_t *l_463 = &g_62;
                        uint32_t **l_464 = &l_322;
                        int i, j;
                        (**l_397) = g_97[l_389][l_389];
                        g_274[(l_389 + 4)] = (safe_sub_func_uint16_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*232*//* ___SAFE__OP */((0x3414A22BL <= (safe_add_func_uint64_t_u_u_unsafe_macro/*233*//* ___SAFE__OP */((l_439 != (l_440[0] , ((*l_464) = &g_175))), p_19))), p_19)) != (*l_463)), p_19));
                        return l_465;
                    }
                    l_466 = ((**l_397) = p_21);
                    return l_467;
                }
                else
                { /* block id: 224 */
                    int32_t l_499 = 0x8AC4A8C4L;
                    uint8_t **l_536 = &l_382;
                    int64_t *l_537 = &g_224;
                    int16_t l_547 = (-10L);
                    int32_t l_548 = 1L;
                    int i;
                    if ((safe_mod_func_int8_t_s_s_unsafe_macro/*234*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*235*//* ___SAFE__OP */(0xC7D9B5DFC6C013B9LL, (g_62 , ((((p_21 == l_472) || ((((safe_mul_func_uint32_t_u_u_unsafe_macro/*236*//* ___SAFE__OP */((g_173.f2 = (safe_rshift_func_int64_t_s_s_unsafe_macro/*237*//* ___SAFE__OP */(g_248.f0, ((*p_21) <= (*p_21))))), (((safe_div_func_uint32_t_u_u_unsafe_macro/*238*//* ___SAFE__OP */(((safe_div_func_uint64_t_u_u_unsafe_macro/*239*//* ___SAFE__OP */(((((0x08L && ((((safe_div_func_int16_t_s_s_unsafe_macro/*240*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*241*//* ___SAFE__OP */(((l_371[l_389] = (((0UL & (*l_466)) >= g_104.f2) == (-9L))) == (*p_21)), 1)), g_101.f6)) , p_20) && g_273) , 0UL)) == 0xB9B2L) && 0xBDA1A9B85F00FC0ALL) | g_299[l_317]), 1UL)) && 0L), 0x71669387L)) || g_319.f6) <= 0x8A2CL))) != g_402) , &l_460) != g_429)) & g_106[1][0].f2) || 0x73F0B1D4L)))), l_317)))
                    { /* block id: 227 */
                        const int16_t l_493 = 0xEF6AL;
                        int32_t *l_494 = &g_176;
                        (*p_21) = (((safe_mod_func_int8_t_s_s_unsafe_macro/*242*//* ___SAFE__OP */(((g_147[0] &= 0x6BL) | (safe_add_func_uint64_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */(((*p_21) , (((*l_494) ^= (safe_add_func_int16_t_s_s_unsafe_macro/*244*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*245*//* ___SAFE__OP */((*p_21), l_493)), (-1L)))) , (l_375 , (safe_sub_func_uint8_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*247*//* ___SAFE__OP */((6L < (((*l_325) = (p_19 <= (g_271 < p_20))) < g_173.f1)), g_22)), g_104.f4))))), l_493))), g_224)) , g_101.f4) <= 0x7FL);
                        g_500++;
                        (*p_21) &= 0x2E3FEF56L;
                    }
                    else
                    { /* block id: 234 */
                        int8_t l_518 = (-6L);
                        l_371[l_389] &= ((l_394 &= p_20) , (safe_mul_func_int16_t_s_s_unsafe_macro/*248*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*249*//* ___SAFE__OP */((((safe_unary_minus_func_int32_t_s_unsafe_macro/*250*//* ___SAFE__OP */((g_319.f3 <= ((((g_364 , (safe_add_func_uint32_t_u_u_unsafe_macro/*251*//* ___SAFE__OP */(((((safe_add_func_uint64_t_u_u_unsafe_macro/*252*//* ___SAFE__OP */(((((*l_322) = (g_104.f2 &= ((void*)0 != &p_21))) > l_390) , (~(safe_mul_func_int8_t_s_s_unsafe_macro/*253*//* ___SAFE__OP */(((*l_325) = p_20), (safe_mod_func_int8_t_s_s_unsafe_macro/*254*//* ___SAFE__OP */(((((+0x8BL) , p_20) | p_20) , g_62), l_499)))))), 7L)) , g_299[l_317]) != l_317) && l_350), (*p_21)))) >= l_518) | (-2L)) ^ 0x6231L)))) < 0xCAL) || (*l_466)), g_248.f0)), l_350)));
                    }
                    l_375 = ((*g_298) = (safe_add_func_uint8_t_u_u_unsafe_macro/*255*//* ___SAFE__OP */((g_299[l_317] ^ p_19), (safe_sub_func_int32_t_s_s((*p_21), (((g_402 = (safe_mul_func_int16_t_s_s_unsafe_macro/*257*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s_unsafe_macro/*258*//* ___SAFE__OP */(((*l_537) = ((4UL ^ (((*l_324) = (-2L)) <= g_343.f0)) <= (safe_sub_func_uint64_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */(p_20, ((((((*l_325) = ((+(safe_unary_minus_func_uint8_t_u_unsafe_macro/*260*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*261*//* ___SAFE__OP */(((l_533 == ((*l_536) = (g_534 = g_534))) != g_22), g_248.f2))))) , p_20)) >= g_248.f1) , 0x7C5FL) ^ l_375) > p_19))))), l_538)) && g_299[l_317]), 0xF073L))) | 65528UL) , 0xD1435DD5L))))));
                    for (g_176 = 3; (g_176 >= 0); g_176 -= 1)
                    { /* block id: 251 */
                        l_548 = (safe_mul_func_int32_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */((((&g_534 == &g_534) || (safe_lshift_func_uint8_t_u_u_unsafe_macro/*263*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*264*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*265*//* ___SAFE__OP */(p_19, (p_20 | 18446744073709551615UL))))), 7))) ^ (-8L)), ((g_299[l_317] = 0L) != ((g_147[0] = ((&l_320 != (p_20 , l_546)) == (-1L))) | l_547))));
                        return (*p_21);
                    }
                    return l_499;
                }
            }
            p_21 = func_24(g_97[l_389][l_389], (safe_mul_func_int16_t_s_s_unsafe_macro/*266*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_s_unsafe_macro/*267*//* ___SAFE__OP */((((l_553 != l_554) , (l_555 = &p_21)) == (g_271 , &p_21)), (safe_lshift_func_int32_t_s_u_unsafe_macro/*268*//* ___SAFE__OP */(0xF5B720F0L, 9)))), (safe_rshift_func_int32_t_s_u_unsafe_macro/*269*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*270*//* ___SAFE__OP */((((*l_323) |= 0UL) || ((g_51 = ((((safe_div_func_int16_t_s_s_unsafe_macro/*271*//* ___SAFE__OP */((l_538 , g_173.f4), p_20)) > g_101.f1) , &g_22) == (void*)0)) <= 1L)), 0x3AF9F30EL)), l_389)))), p_20);
            (*l_395) = p_21;
            for (g_364 = 0; (g_364 <= 3); g_364 += 1)
            { /* block id: 267 */
                int32_t l_582 = 0x9F96D5C7L;
                int32_t l_583 = (-6L);
                (*p_21) ^= 9L;
                if (g_564)
                    break;
                l_583 ^= (l_582 = (safe_mod_func_int8_t_s_s_unsafe_macro/*272*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u_unsafe_macro/*273*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*274*//* ___SAFE__OP */((*g_534), (safe_sub_func_uint8_t_u_u_unsafe_macro/*275*//* ___SAFE__OP */((*g_534), ((*p_21) == ((*g_298) = (safe_div_func_int16_t_s_s_unsafe_macro/*276*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*277*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*278*//* ___SAFE__OP */((((p_20 ^ g_23.f0) > (**l_555)) >= (+0xC242L)), (*p_21))), (safe_mul_func_int16_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */((((p_20 , (*g_298)) >= p_19) | g_101.f6), 65527UL)))), 0xFB89L)))))))), 11)) > 1L), l_582)));
            }
        }
    }
    return (*p_21);
}


/* ------------------------------------------ */
/* 
 * reads : g_176
 * writes: g_67 g_147 g_176 g_119 g_60 g_299
 */
static int32_t * func_24(int32_t * p_25, uint32_t  p_26, int64_t  p_27)
{ /* block id: 130 */
    uint64_t l_265[4][3][6] = {{{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL}},{{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL}},{{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL}},{{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL},{0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL,0x1D988B7A090017A1LL,0x152F9C7390741066LL,0x152F9C7390741066LL}}};
    int i, j, k;
    for (g_67 = 0; g_67 < 1; g_67 += 1)
    {
        g_147[g_67] = 0L;
    }
    for (g_176 = 0; (g_176 != (-7)); g_176 = safe_sub_func_int8_t_s_s_unsafe_macro/*280*//* ___SAFE__OP */(g_176, 1))
    { /* block id: 134 */
        (*p_25) = 0xF7E4CA83L;
        if (l_265[1][0][4])
            break;
    }
    return &g_119;
}


/* ------------------------------------------ */
/* 
 * reads : g_119 g_62
 * writes: g_119 g_118 g_62
 */
static int32_t * func_28(int32_t * p_29, int32_t * p_30, int8_t  p_31, int32_t * p_32)
{ /* block id: 116 */
    uint32_t l_249 = 0x95B74949L;
    int32_t *l_261 = &g_119;
    l_249--;
    for (g_119 = 0; (g_119 == (-12)); g_119 = safe_sub_func_uint64_t_u_u_unsafe_macro/*281*//* ___SAFE__OP */(g_119, 8))
    { /* block id: 120 */
        int32_t **l_254 = (void*)0;
        int32_t **l_255 = &g_118[6][0];
        (*l_255) = (void*)0;
        (*p_29) ^= (((safe_lshift_func_uint16_t_u_u_unsafe_macro/*282*//* ___SAFE__OP */(0xAB6FL, (safe_unary_minus_func_uint32_t_u_unsafe_macro/*283*//* ___SAFE__OP */(p_31)))) , p_30) != (void*)0);
    }
    for (g_62 = 25; (g_62 == 28); ++g_62)
    { /* block id: 126 */
        p_29 = p_29;
    }
    return l_261;
}


/* ------------------------------------------ */
/* 
 * reads : g_51 g_106.f6 g_22 g_104 g_147 g_101.f6 g_143 g_101.f5 g_119 g_248
 * writes: g_61 g_51 g_143 g_147 g_119 g_113 g_97
 */
static struct S0  func_33(int32_t  p_34)
{ /* block id: 31 */
    int32_t **l_120 = &g_61;
    uint64_t *l_127 = &g_113;
    struct S0 **l_144[10][7] = {{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,(void*)0,&g_105,&g_105,(void*)0,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,(void*)0,&g_105,(void*)0,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105}};
    int32_t l_149 = 0L;
    int32_t l_177 = 0x2E41012EL;
    int32_t l_179 = 0L;
    uint32_t *l_186[8][7] = {{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175},{&g_175,(void*)0,&g_175,(void*)0,&g_175,(void*)0,&g_175},{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175},{&g_175,(void*)0,&g_175,(void*)0,&g_175,(void*)0,&g_175},{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175},{&g_175,(void*)0,&g_175,(void*)0,&g_175,(void*)0,&g_175},{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175},{&g_175,(void*)0,&g_175,(void*)0,&g_175,(void*)0,&g_175}};
    int16_t l_195 = 0x91FDL;
    uint64_t l_200[1][7][6] = {{{0xBACBC80529FFD0D4LL,8UL,18446744073709551607UL,0xBACBC80529FFD0D4LL,0xBDECE06B3608916ALL,0xBDECE06B3608916ALL},{0x3C9A6C5E243C7E61LL,8UL,8UL,0x3C9A6C5E243C7E61LL,0xBDECE06B3608916ALL,18446744073709551607UL},{0UL,8UL,0xBDECE06B3608916ALL,0UL,0xBDECE06B3608916ALL,8UL},{0xBACBC80529FFD0D4LL,8UL,18446744073709551607UL,0xBACBC80529FFD0D4LL,0xBDECE06B3608916ALL,0xBDECE06B3608916ALL},{0x3C9A6C5E243C7E61LL,8UL,8UL,0x3C9A6C5E243C7E61LL,0xBDECE06B3608916ALL,18446744073709551607UL},{0UL,8UL,0xBDECE06B3608916ALL,0UL,0xBDECE06B3608916ALL,8UL},{0xBACBC80529FFD0D4LL,8UL,18446744073709551607UL,0xBACBC80529FFD0D4LL,0xBDECE06B3608916ALL,0xBDECE06B3608916ALL}}};
    int32_t **l_240 = &g_118[7][3];
    int i, j, k;
    (*l_120) = (void*)0;
    for (g_51 = 0; (g_51 <= (-17)); g_51--)
    { /* block id: 35 */
        uint16_t l_137 = 0x7DEDL;
        int8_t *l_142 = &g_143;
        struct S0 **l_145 = &g_105;
        int8_t *l_146[9] = {&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0]};
        int32_t l_148 = (-1L);
        int32_t l_178[2];
        int32_t l_198 = (-6L);
        uint64_t *l_225 = (void*)0;
        int i;
        for (i = 0; i < 2; i++)
            l_178[i] = 0x57621A52L;
        l_149 = ((safe_lshift_func_int64_t_s_u_unsafe_macro/*284*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*285*//* ___SAFE__OP */((l_127 != (void*)0), (p_34 & ((safe_add_func_int8_t_s_s_unsafe_macro/*286*//* ___SAFE__OP */(((((l_148 = (4294967292UL >= ((safe_mul_func_uint16_t_u_u_unsafe_macro/*287*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_s_unsafe_macro/*288*//* ___SAFE__OP */(0xB3153F037E6CEEB8LL, 31)) >= (~(safe_mod_func_uint8_t_u_u_unsafe_macro/*289*//* ___SAFE__OP */(l_137, (((safe_lshift_func_int32_t_s_u_unsafe_macro/*290*//* ___SAFE__OP */((g_106[1][0].f6 != ((((((safe_sub_func_uint16_t_u_u_unsafe_macro/*291*//* ___SAFE__OP */(((g_147[0] ^= ((g_22 || ((((*l_142) = ((((g_104 , (void*)0) == l_127) & 5L) && 0x7FFC2CB1L)) , l_144[7][4]) == l_145)) >= 0xAFL)) & 5UL), 0xBA81L)) | p_34) ^ p_34) < 8UL) != g_101.f6) == l_137)), p_34)) && g_143) & g_22))))), p_34)) , 1UL))) <= l_137) > 0x33A7L) == p_34), g_104.f1)) , g_101.f5)))), 0)) & 0xCDL);
        for (g_119 = 7; (g_119 >= 2); g_119 -= 1)
        { /* block id: 42 */
            uint32_t *l_174[6][1][10] = {{{&g_175,(void*)0,&g_175,&g_175,&g_175,(void*)0,&g_175,(void*)0,&g_175,&g_175}},{{&g_175,&g_175,&g_175,(void*)0,&g_175,(void*)0,&g_175,&g_175,&g_175,(void*)0}},{{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175}},{{&g_175,(void*)0,&g_175,&g_175,&g_175,(void*)0,&g_175,(void*)0,&g_175,&g_175}},{{&g_175,&g_175,&g_175,(void*)0,&g_175,(void*)0,&g_175,&g_175,&g_175,(void*)0}},{{&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175,&g_175}}};
            int16_t *l_182 = &g_51;
            int32_t l_196[10] = {7L,7L,7L,7L,7L,7L,7L,7L,7L,7L};
            int32_t l_199[2][4][10] = {{{(-1L),0x28B2817EL,6L,6L,0x28B2817EL,(-1L),7L,0x28B2817EL,7L,(-1L)},{0x3A2AA5A5L,0x28B2817EL,(-1L),0x28B2817EL,0x3A2AA5A5L,(-1L),(-3L),(-3L),(-1L),0x3A2AA5A5L},{0x3A2AA5A5L,7L,7L,0x3A2AA5A5L,6L,(-1L),7L,0x9B31E182L,0x7CC31644L,7L},{0x9B31E182L,7L,0x9B31E182L,0x7CC31644L,7L,(-1L),(-1L),7L,0x7CC31644L,0x9B31E182L}},{{(-1L),(-1L),(-3L),7L,6L,(-3L),6L,7L,(-3L),(-1L)},{6L,(-1L),0x9B31E182L,6L,0x7CC31644L,0x7CC31644L,6L,0x9B31E182L,(-1L),6L},{0x9B31E182L,(-1L),(-1L),0x7CC31644L,(-1L),0x7CC31644L,(-1L),(-1L),0x9B31E182L,0x9B31E182L},{6L,7L,(-3L),(-1L),(-1L),(-3L),7L,6L,(-3L),6L}}};
            int8_t l_222 = (-1L);
            int i, j, k;
            for (g_143 = 3; (g_143 <= 8); g_143 += 1)
            { /* block id: 45 */
                uint8_t l_150 = 0x0FL;
                for (l_148 = 0; l_148 < 3; l_148 += 1)
                {
                    for (g_113 = 0; g_113 < 3; g_113 += 1)
                    {
                        g_97[l_148][g_113] = &g_60;
                    }
                }
                if (l_150)
                    continue;
            }
        }
    }
    return g_248;
}


/* ------------------------------------------ */
/* 
 * reads : g_23.f1 g_61 g_62 g_101.f2 g_299
 * writes: g_61 g_97 g_62 g_105 g_113 g_115
 */
static int32_t * func_38(int16_t  p_39, int32_t  p_40, uint64_t  p_41, uint32_t  p_42, int32_t * p_43)
{ /* block id: 8 */
    uint32_t l_74 = 0UL;
    int32_t *l_87 = &g_62;
    for (p_41 = (-12); (p_41 < 38); p_41 = safe_add_func_uint32_t_u_u_unsafe_macro/*292*//* ___SAFE__OP */(p_41, 6))
    { /* block id: 11 */
        struct S0 *l_103 = &g_104;
        int32_t l_111 = 0xD4330F15L;
        uint64_t *l_112 = &g_113;
        l_74 = (0x85F6474AL || 1L);
        for (p_42 = 0; (p_42 > 27); ++p_42)
        { /* block id: 15 */
            int32_t **l_88 = (void*)0;
            struct S0 *l_100 = &g_101;
            struct S0 **l_102[1][3];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_102[i][j] = &l_100;
            }
            l_87 = func_77(&g_51, (safe_mul_func_uint64_t_u_u_unsafe_macro/*293*//* ___SAFE__OP */(1UL, ((g_61 = ((0x05L < (&p_39 == &g_51)) , l_87)) == &g_62))), &p_42, (*p_43), p_40);
            l_103 = l_100;
        }
        g_105 = l_103;
        (*l_87) = (safe_add_func_int32_t_s_s_unsafe_macro/*294*//* ___SAFE__OP */((*p_43), ((((safe_mul_func_uint32_t_u_u_unsafe_macro/*295*//* ___SAFE__OP */(4294967295UL, (*l_87))) <= 0x6CL) || (l_111 && (((*l_112) = g_101.f2) && (~(((g_115 = &p_43) != (void*)0) | (*l_87)))))) >= p_41)));
    }
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_62 g_68 g_23.f1
 * writes: g_68
 */
static int16_t  func_44(int16_t  p_45, uint32_t  p_46, const uint64_t  p_47, int32_t * p_48)
{ /* block id: 4 */
    int32_t l_63 = 0x8A77F2A5L;
    int32_t *l_64 = (void*)0;
    int32_t *l_65[2][9][8] = {{{&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62},{(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62,&g_62},{(void*)0,(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,&g_62,&g_62},{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62},{(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62,&g_62},{(void*)0,(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,&g_62,&g_62}},{{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62},{(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62,&g_62},{(void*)0,(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,&g_62,&g_62},{&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62,(void*)0,&g_62},{&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,(void*)0,&g_62},{(void*)0,&g_62,&g_62,&g_62,(void*)0,(void*)0,&g_62,&g_62},{&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,&g_62,&g_62}}};
    int32_t l_66 = 0x13EC5CB5L;
    int i, j, k;
    l_63 |= (*p_48);
    ++g_68;
    return g_23.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_23.f1 g_61 g_62
 * writes: g_97 g_62
 */
static int32_t * func_77(int16_t * p_78, uint64_t  p_79, uint32_t * p_80, int32_t  p_81, const int8_t  p_82)
{ /* block id: 17 */
    uint32_t *l_96 = &g_60;
    int32_t **l_98 = (void*)0;
    int32_t l_99 = 9L;
    (*g_61) ^= (safe_mul_func_int64_t_s_s_unsafe_macro/*296*//* ___SAFE__OP */((((!(-10L)) , p_78) != (((safe_sub_func_uint8_t_u_u_unsafe_macro/*297*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*298*//* ___SAFE__OP */(1L, ((((l_96 != (g_97[0][0] = &g_60)) , l_98) == l_98) , (g_23.f1 | ((void*)0 == &g_62))))), p_79)) , l_99) , (void*)0)), p_81));
    return &g_62;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_23.f0, "g_23.f0", print_hash_value);
    transparent_crc(g_23.f1, "g_23.f1", print_hash_value);
    transparent_crc(g_23.f2, "g_23.f2", print_hash_value);
    transparent_crc(g_23.f3, "g_23.f3", print_hash_value);
    transparent_crc(g_23.f4, "g_23.f4", print_hash_value);
    transparent_crc(g_23.f5, "g_23.f5", print_hash_value);
    transparent_crc(g_23.f6, "g_23.f6", print_hash_value);
    transparent_crc(g_23.f7, "g_23.f7", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_101.f0, "g_101.f0", print_hash_value);
    transparent_crc(g_101.f1, "g_101.f1", print_hash_value);
    transparent_crc(g_101.f2, "g_101.f2", print_hash_value);
    transparent_crc(g_101.f3, "g_101.f3", print_hash_value);
    transparent_crc(g_101.f4, "g_101.f4", print_hash_value);
    transparent_crc(g_101.f5, "g_101.f5", print_hash_value);
    transparent_crc(g_101.f6, "g_101.f6", print_hash_value);
    transparent_crc(g_101.f7, "g_101.f7", print_hash_value);
    transparent_crc(g_104.f0, "g_104.f0", print_hash_value);
    transparent_crc(g_104.f1, "g_104.f1", print_hash_value);
    transparent_crc(g_104.f2, "g_104.f2", print_hash_value);
    transparent_crc(g_104.f3, "g_104.f3", print_hash_value);
    transparent_crc(g_104.f4, "g_104.f4", print_hash_value);
    transparent_crc(g_104.f5, "g_104.f5", print_hash_value);
    transparent_crc(g_104.f6, "g_104.f6", print_hash_value);
    transparent_crc(g_104.f7, "g_104.f7", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_106[i][j].f0, "g_106[i][j].f0", print_hash_value);
            transparent_crc(g_106[i][j].f1, "g_106[i][j].f1", print_hash_value);
            transparent_crc(g_106[i][j].f2, "g_106[i][j].f2", print_hash_value);
            transparent_crc(g_106[i][j].f3, "g_106[i][j].f3", print_hash_value);
            transparent_crc(g_106[i][j].f4, "g_106[i][j].f4", print_hash_value);
            transparent_crc(g_106[i][j].f5, "g_106[i][j].f5", print_hash_value);
            transparent_crc(g_106[i][j].f6, "g_106[i][j].f6", print_hash_value);
            transparent_crc(g_106[i][j].f7, "g_106[i][j].f7", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_147[i], "g_147[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_173.f0, "g_173.f0", print_hash_value);
    transparent_crc(g_173.f1, "g_173.f1", print_hash_value);
    transparent_crc(g_173.f2, "g_173.f2", print_hash_value);
    transparent_crc(g_173.f3, "g_173.f3", print_hash_value);
    transparent_crc(g_173.f4, "g_173.f4", print_hash_value);
    transparent_crc(g_173.f5, "g_173.f5", print_hash_value);
    transparent_crc(g_173.f6, "g_173.f6", print_hash_value);
    transparent_crc(g_173.f7, "g_173.f7", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_197, "g_197", print_hash_value);
    transparent_crc(g_224, "g_224", print_hash_value);
    transparent_crc(g_248.f0, "g_248.f0", print_hash_value);
    transparent_crc(g_248.f1, "g_248.f1", print_hash_value);
    transparent_crc(g_248.f2, "g_248.f2", print_hash_value);
    transparent_crc(g_248.f3, "g_248.f3", print_hash_value);
    transparent_crc(g_248.f4, "g_248.f4", print_hash_value);
    transparent_crc(g_248.f5, "g_248.f5", print_hash_value);
    transparent_crc(g_248.f6, "g_248.f6", print_hash_value);
    transparent_crc(g_248.f7, "g_248.f7", print_hash_value);
    transparent_crc(g_267, "g_267", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_268[i], "g_268[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_269[i], "g_269[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_270, "g_270", print_hash_value);
    transparent_crc(g_271, "g_271", print_hash_value);
    transparent_crc(g_272, "g_272", print_hash_value);
    transparent_crc(g_273, "g_273", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_274[i], "g_274[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_275, "g_275", print_hash_value);
    transparent_crc(g_276, "g_276", print_hash_value);
    transparent_crc(g_277, "g_277", print_hash_value);
    transparent_crc(g_278, "g_278", print_hash_value);
    transparent_crc(g_279, "g_279", print_hash_value);
    transparent_crc(g_280, "g_280", print_hash_value);
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    transparent_crc(g_283, "g_283", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_284[i], "g_284[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_285, "g_285", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_286[i], "g_286[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_287, "g_287", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_288[i][j], "g_288[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_289, "g_289", print_hash_value);
    transparent_crc(g_290, "g_290", print_hash_value);
    transparent_crc(g_291, "g_291", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_292[i][j][k], "g_292[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_293, "g_293", print_hash_value);
    transparent_crc(g_294, "g_294", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    transparent_crc(g_296, "g_296", print_hash_value);
    transparent_crc(g_297, "g_297", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_299[i], "g_299[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_319.f0, "g_319.f0", print_hash_value);
    transparent_crc(g_319.f1, "g_319.f1", print_hash_value);
    transparent_crc(g_319.f2, "g_319.f2", print_hash_value);
    transparent_crc(g_319.f3, "g_319.f3", print_hash_value);
    transparent_crc(g_319.f4, "g_319.f4", print_hash_value);
    transparent_crc(g_319.f5, "g_319.f5", print_hash_value);
    transparent_crc(g_319.f6, "g_319.f6", print_hash_value);
    transparent_crc(g_319.f7, "g_319.f7", print_hash_value);
    transparent_crc(g_326, "g_326", print_hash_value);
    transparent_crc(g_343.f0, "g_343.f0", print_hash_value);
    transparent_crc(g_343.f1, "g_343.f1", print_hash_value);
    transparent_crc(g_343.f2, "g_343.f2", print_hash_value);
    transparent_crc(g_343.f3, "g_343.f3", print_hash_value);
    transparent_crc(g_343.f4, "g_343.f4", print_hash_value);
    transparent_crc(g_343.f5, "g_343.f5", print_hash_value);
    transparent_crc(g_343.f6, "g_343.f6", print_hash_value);
    transparent_crc(g_343.f7, "g_343.f7", print_hash_value);
    transparent_crc(g_364, "g_364", print_hash_value);
    transparent_crc(g_402, "g_402", print_hash_value);
    transparent_crc(g_461, "g_461", print_hash_value);
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_535, "g_535", print_hash_value);
    transparent_crc(g_564, "g_564", print_hash_value);
    transparent_crc(g_651, "g_651", print_hash_value);
    transparent_crc(g_735.f0, "g_735.f0", print_hash_value);
    transparent_crc(g_735.f1, "g_735.f1", print_hash_value);
    transparent_crc(g_735.f2, "g_735.f2", print_hash_value);
    transparent_crc(g_735.f3, "g_735.f3", print_hash_value);
    transparent_crc(g_735.f4, "g_735.f4", print_hash_value);
    transparent_crc(g_735.f5, "g_735.f5", print_hash_value);
    transparent_crc(g_735.f6, "g_735.f6", print_hash_value);
    transparent_crc(g_735.f7, "g_735.f7", print_hash_value);
    transparent_crc(g_774, "g_774", print_hash_value);
    transparent_crc(g_811, "g_811", print_hash_value);
    transparent_crc(g_867.f0, "g_867.f0", print_hash_value);
    transparent_crc(g_867.f1, "g_867.f1", print_hash_value);
    transparent_crc(g_867.f2, "g_867.f2", print_hash_value);
    transparent_crc(g_867.f3, "g_867.f3", print_hash_value);
    transparent_crc(g_867.f4, "g_867.f4", print_hash_value);
    transparent_crc(g_867.f5, "g_867.f5", print_hash_value);
    transparent_crc(g_867.f6, "g_867.f6", print_hash_value);
    transparent_crc(g_867.f7, "g_867.f7", print_hash_value);
    transparent_crc(g_912.f0, "g_912.f0", print_hash_value);
    transparent_crc(g_912.f1, "g_912.f1", print_hash_value);
    transparent_crc(g_912.f2, "g_912.f2", print_hash_value);
    transparent_crc(g_912.f3, "g_912.f3", print_hash_value);
    transparent_crc(g_912.f4, "g_912.f4", print_hash_value);
    transparent_crc(g_912.f5, "g_912.f5", print_hash_value);
    transparent_crc(g_912.f6, "g_912.f6", print_hash_value);
    transparent_crc(g_912.f7, "g_912.f7", print_hash_value);
    transparent_crc(g_996, "g_996", print_hash_value);
    transparent_crc(g_1047.f0, "g_1047.f0", print_hash_value);
    transparent_crc(g_1047.f1, "g_1047.f1", print_hash_value);
    transparent_crc(g_1047.f2, "g_1047.f2", print_hash_value);
    transparent_crc(g_1047.f3, "g_1047.f3", print_hash_value);
    transparent_crc(g_1047.f4, "g_1047.f4", print_hash_value);
    transparent_crc(g_1047.f5, "g_1047.f5", print_hash_value);
    transparent_crc(g_1047.f6, "g_1047.f6", print_hash_value);
    transparent_crc(g_1047.f7, "g_1047.f7", print_hash_value);
    transparent_crc(g_1084, "g_1084", print_hash_value);
    transparent_crc(g_1097.f0, "g_1097.f0", print_hash_value);
    transparent_crc(g_1097.f1, "g_1097.f1", print_hash_value);
    transparent_crc(g_1097.f2, "g_1097.f2", print_hash_value);
    transparent_crc(g_1097.f3, "g_1097.f3", print_hash_value);
    transparent_crc(g_1097.f4, "g_1097.f4", print_hash_value);
    transparent_crc(g_1097.f5, "g_1097.f5", print_hash_value);
    transparent_crc(g_1097.f6, "g_1097.f6", print_hash_value);
    transparent_crc(g_1097.f7, "g_1097.f7", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1139[i][j][k], "g_1139[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1141, "g_1141", print_hash_value);
    transparent_crc(g_1143, "g_1143", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1144[i], "g_1144[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1244.f0, "g_1244.f0", print_hash_value);
    transparent_crc(g_1244.f1, "g_1244.f1", print_hash_value);
    transparent_crc(g_1244.f2, "g_1244.f2", print_hash_value);
    transparent_crc(g_1244.f3, "g_1244.f3", print_hash_value);
    transparent_crc(g_1244.f4, "g_1244.f4", print_hash_value);
    transparent_crc(g_1244.f5, "g_1244.f5", print_hash_value);
    transparent_crc(g_1244.f6, "g_1244.f6", print_hash_value);
    transparent_crc(g_1244.f7, "g_1244.f7", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1317[i], "g_1317[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1339, "g_1339", print_hash_value);
    transparent_crc(g_1374, "g_1374", print_hash_value);
    transparent_crc(g_1380, "g_1380", print_hash_value);
    transparent_crc(g_1396.f0, "g_1396.f0", print_hash_value);
    transparent_crc(g_1396.f1, "g_1396.f1", print_hash_value);
    transparent_crc(g_1396.f2, "g_1396.f2", print_hash_value);
    transparent_crc(g_1396.f3, "g_1396.f3", print_hash_value);
    transparent_crc(g_1396.f4, "g_1396.f4", print_hash_value);
    transparent_crc(g_1396.f5, "g_1396.f5", print_hash_value);
    transparent_crc(g_1396.f6, "g_1396.f6", print_hash_value);
    transparent_crc(g_1396.f7, "g_1396.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 301
   depth: 1, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 9
XXX zero bitfields defined in structs: 1
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 26
breakdown:
   indirect level: 0, occurrence: 11
   indirect level: 1, occurrence: 11
   indirect level: 2, occurrence: 4
XXX full-bitfields structs in the program: 11
breakdown:
   indirect level: 0, occurrence: 11
XXX times a bitfields struct's address is taken: 14
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 19
XXX times a single bitfield on LHS: 6
XXX times a single bitfield on RHS: 129

XXX max expression depth: 57
breakdown:
   depth: 1, occurrence: 159
   depth: 2, occurrence: 49
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 2
   depth: 12, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 3
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 23, occurrence: 3
   depth: 24, occurrence: 4
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 27, occurrence: 2
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 4
   depth: 38, occurrence: 3
   depth: 39, occurrence: 1
   depth: 44, occurrence: 1
   depth: 52, occurrence: 1
   depth: 57, occurrence: 1

XXX total number of pointers: 290

XXX times a variable address is taken: 710
XXX times a pointer is dereferenced on RHS: 168
breakdown:
   depth: 1, occurrence: 149
   depth: 2, occurrence: 14
   depth: 3, occurrence: 5
XXX times a pointer is dereferenced on LHS: 163
breakdown:
   depth: 1, occurrence: 154
   depth: 2, occurrence: 8
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 18
XXX times a pointer is compared with address of another variable: 4
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 3292

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 720
   level: 2, occurrence: 92
   level: 3, occurrence: 52
   level: 4, occurrence: 10
   level: 5, occurrence: 18
XXX number of pointers point to pointers: 101
XXX number of pointers point to scalars: 178
XXX number of pointers point to structs: 11
XXX percent of pointers has null in alias set: 29.3
XXX average alias set size: 1.48

XXX times a non-volatile is read: 1108
XXX times a non-volatile is write: 542
XXX times a volatile is read: 61
XXX    times read thru a pointer: 2
XXX times a volatile is write: 8
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.26e+03
XXX percentage of non-volatile access: 96

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 174
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 28
   depth: 2, occurrence: 36
   depth: 3, occurrence: 30
   depth: 4, occurrence: 26
   depth: 5, occurrence: 24

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

