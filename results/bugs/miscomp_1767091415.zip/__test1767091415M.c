/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 1767091415 --bitfields --packed-struct
 * Seed:      1767091415
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   int32_t  f0;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static uint32_t g_16 = 0UL;
static struct S0 g_35 = {0x3FD52A42L};
static int32_t g_56 = 0x2CAC2457L;
static uint64_t g_59 = 0x58390A341A4633BELL;
static int32_t g_66[5] = {0x0F4B430FL,0x0F4B430FL,0x0F4B430FL,0x0F4B430FL,0x0F4B430FL};
static int32_t * volatile g_65 = &g_66[3];/* VOLATILE GLOBAL g_65 */
static int64_t g_86 = (-1L);
static uint8_t g_146 = 0x23L;
static uint32_t g_149 = 0x623687E8L;
static uint8_t * const *g_154 = (void*)0;
static uint8_t * const ** volatile g_153 = &g_154;/* VOLATILE GLOBAL g_153 */
static uint16_t g_186 = 8UL;
static uint8_t *g_191 = &g_146;
static uint8_t **g_190[4] = {&g_191,&g_191,&g_191,&g_191};
static uint8_t ****g_208 = (void*)0;
static uint8_t ***** volatile g_207 = &g_208;/* VOLATILE GLOBAL g_207 */
static int32_t g_210 = 0xC3C69C58L;
static int8_t g_211 = 0xFFL;
static int32_t g_212 = 0L;
static uint64_t g_238[5][7] = {{0x16281FC51678A96FLL,0UL,18446744073709551609UL,18446744073709551606UL,0xF96A7537CAC03C0FLL,18446744073709551606UL,18446744073709551609UL},{0xA0DCDEADA25E56E3LL,0xA0DCDEADA25E56E3LL,0x32ED61E018DE91D9LL,0xDD07A39AD0433462LL,0UL,0x140F5BE3012BAB1ELL,0x16281FC51678A96FLL},{0x16281FC51678A96FLL,18446744073709551606UL,0x32ED61E018DE91D9LL,0x32ED61E018DE91D9LL,18446744073709551606UL,0x16281FC51678A96FLL,0xF96A7537CAC03C0FLL},{0UL,0x32ED61E018DE91D9LL,18446744073709551609UL,0xF96A7537CAC03C0FLL,0UL,0UL,0xF96A7537CAC03C0FLL},{0xDD07A39AD0433462LL,0x6AD021763DC0B0FBLL,0xDD07A39AD0433462LL,0x140F5BE3012BAB1ELL,0xF96A7537CAC03C0FLL,0UL,0x16281FC51678A96FLL}};
static int64_t g_240[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static uint16_t g_243 = 0xC79DL;
static volatile uint8_t *g_286 = (void*)0;
static volatile uint8_t * volatile *g_285 = &g_286;
static int32_t * volatile g_291 = &g_66[3];/* VOLATILE GLOBAL g_291 */
static const int32_t *g_308 = &g_66[1];
static const int32_t ** volatile g_307 = &g_308;/* VOLATILE GLOBAL g_307 */
static const int32_t g_347 = 0x030A3B3EL;
static const int32_t *g_346[1][6][3] = {{{&g_347,&g_347,&g_347},{&g_347,&g_347,&g_347},{&g_347,&g_347,&g_347},{&g_347,&g_347,&g_347},{&g_347,&g_347,&g_347},{&g_347,&g_347,&g_347}}};
static struct S0 *g_349 = (void*)0;
static struct S0 ** volatile g_348 = &g_349;/* VOLATILE GLOBAL g_348 */
static struct S0 g_358[7][8] = {{{0x02F6A40CL},{0x02F6A40CL},{0x24059179L},{0xBA33D3BBL},{0xE90D8059L},{0x0BA1C739L},{0x1B6692F4L},{0x0BA1C739L}},{{0xDE94EE4FL},{0xBE214E3FL},{0xBA33D3BBL},{0xBE214E3FL},{0xDE94EE4FL},{-7L},{0x02F6A40CL},{0x0BA1C739L}},{{0xBE214E3FL},{0xE90D8059L},{0x1B6692F4L},{0xBA33D3BBL},{0xBA33D3BBL},{0x1B6692F4L},{0xE90D8059L},{0xBE214E3FL}},{{0x24059179L},{-7L},{0x1B6692F4L},{0L},{0x02F6A40CL},{0xDE94EE4FL},{0x02F6A40CL},{0L}},{{0xBA33D3BBL},{0x4712241EL},{0xBA33D3BBL},{0x0BA1C739L},{0L},{0xDE94EE4FL},{0x1B6692F4L},{0x1B6692F4L}},{{0x1B6692F4L},{-7L},{0x24059179L},{0x24059179L},{-7L},{0x1B6692F4L},{0L},{0x02F6A40CL}},{{0x1B6692F4L},{0xE90D8059L},{0xBE214E3FL},{-7L},{0L},{-7L},{0xBE214E3FL},{0xE90D8059L}}};
static struct S0 * volatile g_357 = &g_358[6][1];/* VOLATILE GLOBAL g_357 */
static const int64_t *g_393[7] = {&g_86,&g_86,&g_86,&g_86,&g_86,&g_86,&g_86};
static const int64_t ** volatile g_392 = &g_393[3];/* VOLATILE GLOBAL g_392 */
static int16_t g_398 = 0x153EL;
static uint32_t g_402 = 0x0E46D546L;
static struct S0 * volatile g_455[2] = {&g_358[6][1],&g_358[6][1]};
static struct S0 * const  volatile g_456 = (void*)0;/* VOLATILE GLOBAL g_456 */
static struct S0 * volatile g_457[3][8][3] = {{{(void*)0,&g_35,&g_35},{(void*)0,(void*)0,&g_35},{&g_35,&g_35,&g_35},{&g_35,&g_358[6][1],&g_35},{&g_35,&g_358[6][1],&g_358[6][1]},{(void*)0,&g_35,&g_35},{(void*)0,(void*)0,&g_35},{&g_35,&g_35,&g_35}},{{&g_35,&g_358[6][1],&g_35},{&g_35,&g_358[6][1],&g_358[6][1]},{(void*)0,&g_35,&g_35},{(void*)0,(void*)0,&g_35},{&g_35,&g_35,&g_35},{&g_35,&g_358[6][1],&g_35},{&g_35,&g_358[6][1],&g_358[6][1]},{(void*)0,&g_35,&g_35}},{{(void*)0,(void*)0,&g_35},{&g_35,&g_35,&g_35},{&g_35,&g_358[6][1],&g_35},{&g_35,&g_358[6][1],&g_358[6][1]},{(void*)0,&g_35,&g_35},{(void*)0,(void*)0,&g_35},{&g_35,&g_35,&g_35},{&g_35,&g_358[6][1],&g_35}}};
static struct S0 * volatile g_458 = &g_358[6][1];/* VOLATILE GLOBAL g_458 */
static const int32_t ** volatile g_462[5] = {&g_346[0][3][2],&g_346[0][3][2],&g_346[0][3][2],&g_346[0][3][2],&g_346[0][3][2]};
static uint32_t g_492 = 1UL;
static int32_t * volatile g_499 = (void*)0;/* VOLATILE GLOBAL g_499 */
static int32_t * volatile g_500[7] = {&g_66[1],&g_66[3],&g_66[1],&g_66[1],&g_66[3],&g_66[1],&g_66[1]};
static int32_t * volatile g_501 = (void*)0;/* VOLATILE GLOBAL g_501 */
static int32_t * volatile g_502 = &g_66[4];/* VOLATILE GLOBAL g_502 */
static volatile int32_t g_571 = 0xBC42612DL;/* VOLATILE GLOBAL g_571 */
static volatile int8_t g_578 = (-1L);/* VOLATILE GLOBAL g_578 */
static const volatile int8_t *g_577 = &g_578;
static const volatile int8_t ** volatile g_576[2][5][9] = {{{&g_577,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,(void*)0},{&g_577,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0}},{{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0,(void*)0,(void*)0,(void*)0,&g_577,&g_577,(void*)0}}};
static const volatile int8_t ** volatile * volatile g_579 = &g_576[1][0][2];/* VOLATILE GLOBAL g_579 */
static int16_t g_616 = 0xAE60L;
static int32_t *g_619 = &g_56;
static int32_t ** volatile g_618 = &g_619;/* VOLATILE GLOBAL g_618 */
static volatile int32_t g_653 = 2L;/* VOLATILE GLOBAL g_653 */
static uint8_t g_712 = 0UL;
static volatile int64_t g_726 = 0x1F23DB31B198D740LL;/* VOLATILE GLOBAL g_726 */
static const volatile int8_t ** volatile * volatile g_782[5][4][8] = {{{&g_576[1][3][8],&g_576[0][3][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][4][2],&g_576[1][2][4]},{&g_576[1][2][4],&g_576[1][3][3],(void*)0,(void*)0,&g_576[0][4][8],&g_576[1][0][2],&g_576[1][0][2],&g_576[0][4][8]},{&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2],(void*)0,&g_576[1][3][3],&g_576[1][0][8],&g_576[0][3][2]},{&g_576[1][0][2],&g_576[0][4][8],&g_576[1][0][2],&g_576[1][3][3],(void*)0,&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2]}},{{&g_576[1][0][2],&g_576[0][4][8],(void*)0,&g_576[1][4][2],&g_576[1][3][8],&g_576[1][3][3],&g_576[1][0][2],(void*)0},{&g_576[1][0][2],&g_576[1][0][2],(void*)0,&g_576[1][0][2],&g_576[1][0][8],&g_576[1][0][2],(void*)0,&g_576[1][0][2]},{&g_576[1][0][2],&g_576[1][3][3],&g_576[1][3][0],&g_576[1][0][8],(void*)0,&g_576[1][0][2],&g_576[1][4][0],&g_576[1][0][2]},{&g_576[1][0][2],&g_576[0][3][2],&g_576[1][3][3],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][4][2],&g_576[1][4][0],(void*)0}},{{&g_576[1][0][2],&g_576[1][0][2],&g_576[1][3][0],&g_576[1][0][2],&g_576[0][3][2],&g_576[1][2][1],(void*)0,(void*)0},{&g_576[0][3][2],&g_576[1][2][1],(void*)0,(void*)0,&g_576[1][2][1],&g_576[0][3][2],&g_576[1][0][2],&g_576[1][3][0]},{&g_576[1][0][2],(void*)0,(void*)0,&g_576[1][4][0],&g_576[1][4][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][3][3]},{(void*)0,&g_576[1][0][2],&g_576[1][0][2],&g_576[1][4][0],&g_576[1][0][2],(void*)0,&g_576[1][0][8],&g_576[1][3][0]}},{{&g_576[1][1][1],&g_576[1][0][2],&g_576[1][0][2],(void*)0,&g_576[1][0][2],&g_576[1][0][8],&g_576[1][0][2],(void*)0},{(void*)0,(void*)0,(void*)0,&g_576[1][0][2],&g_576[1][3][3],&g_576[1][3][8],&g_576[1][4][2],(void*)0},{(void*)0,(void*)0,&g_576[1][0][2],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][1][1],(void*)0,&g_576[0][4][8]},{&g_576[1][3][8],(void*)0,&g_576[1][2][4],&g_576[1][3][3],(void*)0,(void*)0,&g_576[0][4][8],&g_576[1][0][2]}},{{&g_576[1][0][2],&g_576[1][3][8],&g_576[1][3][0],(void*)0,(void*)0,&g_576[1][3][0],&g_576[1][3][8],&g_576[1][0][2]},{&g_576[1][0][2],(void*)0,&g_576[1][0][2],&g_576[1][0][8],&g_576[1][4][2],&g_576[1][0][2],&g_576[1][0][2],(void*)0},{&g_576[1][2][1],&g_576[1][0][2],&g_576[1][3][8],(void*)0,&g_576[1][0][8],&g_576[1][0][2],&g_576[1][0][2],&g_576[1][2][4]},{&g_576[1][0][2],(void*)0,&g_576[0][3][2],&g_576[0][4][8],&g_576[1][4][0],&g_576[1][3][0],&g_576[1][0][2],&g_576[1][3][0]}}};
static int32_t * const g_824 = &g_210;
static int32_t * const * volatile g_823[7][6] = {{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824},{&g_824,&g_824,&g_824,&g_824,&g_824,&g_824}};
static int32_t ** volatile g_876[10] = {&g_619,&g_619,&g_619,&g_619,&g_619,&g_619,&g_619,&g_619,&g_619,&g_619};
static int32_t ** const  volatile g_877 = &g_619;/* VOLATILE GLOBAL g_877 */
static int64_t g_909[3] = {0x0E1BBEC64AFA2D19LL,0x0E1BBEC64AFA2D19LL,0x0E1BBEC64AFA2D19LL};
static int32_t *g_922 = &g_56;
static int32_t ** volatile g_921[4][7] = {{&g_922,&g_922,(void*)0,&g_922,&g_922,&g_922,(void*)0},{&g_922,&g_922,&g_922,&g_922,(void*)0,&g_922,(void*)0},{&g_922,(void*)0,(void*)0,&g_922,&g_922,&g_922,&g_922},{&g_922,(void*)0,&g_922,&g_922,(void*)0,&g_922,(void*)0}};
static uint32_t g_951[6] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static struct S0 * volatile g_973 = &g_358[6][1];/* VOLATILE GLOBAL g_973 */
static int32_t ** volatile g_974 = &g_619;/* VOLATILE GLOBAL g_974 */
static int64_t *g_1006 = &g_909[0];
static int64_t **g_1005 = &g_1006;
static int64_t ***g_1004 = &g_1005;
static int64_t ****g_1003 = &g_1004;
static const struct S0 g_1021 = {0xD6A4260CL};
static uint8_t g_1034 = 249UL;
static struct S0 g_1052 = {0x0B1ED638L};
static volatile int16_t * volatile *g_1060 = (void*)0;
static int64_t g_1064 = 1L;
static uint64_t *g_1071 = (void*)0;
static uint64_t **g_1070 = &g_1071;
static int64_t * const *g_1121 = (void*)0;
static int64_t * const **g_1120[8] = {(void*)0,(void*)0,&g_1121,(void*)0,(void*)0,&g_1121,(void*)0,(void*)0};
static int64_t * const ***g_1119 = &g_1120[2];
static uint64_t ***g_1158 = &g_1070;
static uint64_t *** volatile *g_1157 = &g_1158;
static volatile uint32_t g_1190 = 4294967293UL;/* VOLATILE GLOBAL g_1190 */
static int32_t * volatile g_1193[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t * volatile g_1255 = &g_66[2];/* VOLATILE GLOBAL g_1255 */
static volatile int32_t * volatile * volatile * volatile *g_1257 = (void*)0;
static volatile int32_t * volatile * volatile * volatile ** volatile g_1258 = &g_1257;/* VOLATILE GLOBAL g_1258 */
static int16_t *g_1326 = &g_398;
static int16_t **g_1325 = &g_1326;
static int64_t g_1354 = 1L;
static int64_t * volatile g_1355[5][2][2] = {{{&g_1064,&g_240[8]},{&g_1064,&g_240[8]}},{{&g_1064,&g_240[8]},{&g_1064,&g_240[8]}},{{&g_1064,&g_240[8]},{&g_1064,&g_240[8]}},{{&g_1064,&g_240[8]},{&g_1064,&g_240[8]}},{{&g_1064,&g_240[8]},{&g_1064,&g_240[8]}}};
static const int8_t g_1471 = 5L;
static const int8_t *g_1470 = &g_1471;
static int32_t g_1482 = 0x755D3972L;
static volatile int8_t g_1496 = 0L;/* VOLATILE GLOBAL g_1496 */
static uint64_t **g_1526 = (void*)0;
static uint64_t *** const g_1525[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint64_t *** const *g_1524 = &g_1525[8];
static uint8_t ***g_1544[2] = {&g_190[3],&g_190[3]};
static uint8_t ****g_1543 = &g_1544[0];
static uint32_t g_1545 = 0xE9382D52L;
static const volatile int32_t g_1546[6] = {0xCBB510B6L,0xCBB510B6L,0xCBB510B6L,0xCBB510B6L,0xCBB510B6L,0xCBB510B6L};
static const uint16_t g_1616[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
static int32_t * const g_1645 = &g_66[2];
static struct S0 * volatile g_1649[1][4][2] = {{{&g_1052,&g_1052},{&g_1052,&g_1052},{&g_1052,&g_1052},{&g_1052,&g_1052}}};
static struct S0 * volatile g_1725 = &g_358[6][1];/* VOLATILE GLOBAL g_1725 */
static int32_t ** volatile g_1774 = &g_619;/* VOLATILE GLOBAL g_1774 */
static uint8_t ***g_1789 = &g_190[1];
static int32_t ** volatile g_1823 = &g_619;/* VOLATILE GLOBAL g_1823 */
static const int32_t *g_1856 = &g_1021.f0;
static const int32_t **g_1855 = &g_1856;
static const int32_t ***g_1854 = &g_1855;
static const int32_t ****g_1853 = &g_1854;
static const int32_t *****g_1852 = &g_1853;
static volatile uint16_t g_1880 = 0x7AC6L;/* VOLATILE GLOBAL g_1880 */
static int8_t *g_1965 = &g_211;
static int8_t **g_1964 = &g_1965;
static int8_t ***g_1963 = &g_1964;
static volatile uint8_t g_1980 = 0x61L;/* VOLATILE GLOBAL g_1980 */
static uint64_t *g_1993 = &g_238[4][0];
static uint64_t ** const g_1992 = &g_1993;
static uint64_t ** const *g_1991[2] = {&g_1992,&g_1992};
static uint64_t ** const **g_1990[1][1] = {{&g_1991[1]}};
static int16_t g_2040 = (-1L);
static uint16_t *g_2061 = &g_186;
static struct S0 * volatile g_2062 = &g_358[6][1];/* VOLATILE GLOBAL g_2062 */
static struct S0 * volatile g_2106[5] = {&g_35,&g_35,&g_35,&g_35,&g_35};
static struct S0 * volatile g_2151 = &g_358[5][3];/* VOLATILE GLOBAL g_2151 */
static uint8_t g_2185 = 0xF5L;
static uint32_t g_2186 = 0x3516FEB1L;
static int32_t * const ** volatile g_2204 = (void*)0;/* VOLATILE GLOBAL g_2204 */
static int32_t * const *g_2205 = &g_922;
static const int32_t ** volatile g_2221 = &g_346[0][3][2];/* VOLATILE GLOBAL g_2221 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_5(int8_t  p_6, struct S0  p_7, uint32_t  p_8, const uint32_t  p_9, int8_t  p_10);
static int32_t  func_13(int64_t  p_14, int64_t  p_15);
static uint64_t  func_19(struct S0  p_20, uint64_t  p_21, const int32_t  p_22, struct S0  p_23);
static struct S0  func_24(int32_t  p_25, int32_t  p_26, uint32_t  p_27, uint8_t  p_28, int8_t  p_29);
static uint8_t  func_32(struct S0  p_33, uint32_t  p_34);
static const int16_t  func_42(int16_t  p_43, const uint64_t  p_44);
static const int16_t  func_47(uint64_t  p_48, struct S0  p_49, int64_t  p_50, int32_t  p_51);
static int32_t * func_67(int16_t  p_68, int32_t * p_69, int32_t  p_70, const int32_t  p_71, struct S0  p_72);
static int32_t * func_79(int32_t * p_80, int8_t  p_81, int32_t * const  p_82, int32_t * p_83, int32_t * const  p_84);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_191 g_146 g_922 g_56 g_1543 g_1544 g_190 g_1326 g_398 g_307 g_308 g_66 g_1470 g_1471 g_1645 g_619 g_951 g_347 g_1325 g_1546 g_207 g_208 g_212 g_1004 g_1005 g_1006 g_909 g_616 g_2061 g_186 g_16 g_1774 g_2221
 * writes: g_16 g_56 g_211 g_66 g_398 g_212 g_616 g_1052 g_2205 g_346
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2 = 1UL;
    struct S0 l_1674 = {1L};
    uint64_t ****l_1717 = &g_1158;
    int16_t **l_1781 = &g_1326;
    uint8_t ***l_1790 = &g_190[2];
    int32_t l_1793[1][7] = {{(-4L),(-4L),(-3L),(-4L),(-4L),(-3L),(-4L)}};
    uint32_t l_1916 = 0xFD865306L;
    uint32_t l_1918 = 18446744073709551615UL;
    int32_t l_1932 = 0xBC81ABCBL;
    int32_t * const l_1934 = &g_66[3];
    const uint64_t l_1959 = 0x130C460D9154EF01LL;
    uint8_t ***l_1976 = (void*)0;
    int64_t *l_1979 = &g_1064;
    int8_t l_2019 = 3L;
    int32_t l_2034[3];
    uint8_t l_2069 = 0UL;
    struct S0 *l_2203 = &g_1052;
    int i, j;
    for (i = 0; i < 3; i++)
        l_2034[i] = 0xBF0D768FL;
    (*g_619) = (l_2 & (safe_rshift_func_int64_t_s_s(func_5(l_2, ((safe_mod_func_uint16_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */((func_13((g_16 = 1L), l_2) & ((((0x8A7EL == 1UL) == ((safe_mul_func_int32_t_s_s_unsafe_macro/*2*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u(0x0F76L, (((safe_add_func_int64_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */((-1L), l_2)) || l_2) , 65526UL))), g_951[3])) >= l_2)) , 0x2DCFA105L) != g_347)), 4L)) , l_1674), g_951[3], g_146, l_1674.f0), (***g_1004))));
    for (g_616 = 0; (g_616 < (-2)); g_616 = safe_sub_func_int16_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */(g_616, 2))
    { /* block id: 803 */
        uint32_t l_1719[5][5][1] = {{{2UL},{4294967295UL},{0x0602816FL},{0x0602816FL},{4294967295UL}},{{2UL},{0x86E5744DL},{2UL},{4294967295UL},{0x0602816FL}},{{0x0602816FL},{4294967295UL},{2UL},{0x86E5744DL},{2UL}},{{4294967295UL},{0x0602816FL},{0x0602816FL},{4294967295UL},{2UL}},{{0x86E5744DL},{2UL},{4294967295UL},{0x0602816FL},{0x0602816FL}}};
        int64_t l_1753[9][4] = {{0xDD4B4AA40D5723E3LL,0L,0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL},{0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL,0xDD4B4AA40D5723E3LL,0L},{0xDD4B4AA40D5723E3LL,0L,0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL},{0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL,0xDD4B4AA40D5723E3LL,0L},{0xDD4B4AA40D5723E3LL,0L,0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL},{0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL,0xDD4B4AA40D5723E3LL,0L},{0xDD4B4AA40D5723E3LL,0L,0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL},{0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL,0xDD4B4AA40D5723E3LL,0L},{0xDD4B4AA40D5723E3LL,0L,0xDD4B4AA40D5723E3LL,0x8A9C47FB89FCE7B2LL}};
        int32_t l_1794 = 0xFD01B932L;
        int64_t l_1819[5][8];
        int32_t **l_1848 = &g_619;
        const int32_t *****l_1851 = (void*)0;
        uint64_t *l_1857 = (void*)0;
        uint64_t *l_1858 = (void*)0;
        uint64_t *l_1859 = &g_59;
        int32_t *l_1862[9] = {&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0,&g_35.f0};
        struct S0 l_1915 = {0x0392134EL};
        uint32_t l_1917 = 0x976B3526L;
        uint64_t ***l_2004[5][5] = {{&g_1526,&g_1526,&g_1070,(void*)0,(void*)0},{(void*)0,&g_1526,(void*)0,&g_1526,(void*)0},{&g_1070,&g_1526,&g_1526,(void*)0,(void*)0},{&g_1070,&g_1526,&g_1526,&g_1070,(void*)0},{&g_1070,&g_1070,&g_1526,(void*)0,&g_1526}};
        int32_t l_2027 = (-1L);
        int32_t l_2029 = 0xF04FCD86L;
        int32_t l_2030[8][1][1] = {{{(-1L)}},{{0x191896F6L}},{{(-1L)}},{{0x191896F6L}},{{(-1L)}},{{0x191896F6L}},{{(-1L)}},{{0x191896F6L}}};
        uint16_t *l_2046 = &g_243;
        int32_t l_2134 = 9L;
        int64_t l_2183 = (-4L);
        const int32_t l_2184 = 0L;
        int i, j, k;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 8; j++)
                l_1819[i][j] = 0x4D04A57DBB36F84FLL;
        }
    }
    if ((safe_add_func_int16_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */(((*l_1934) && (((*g_1325) != (((*l_2203) = ((((((((*l_1934) & (((*l_1934) || ((safe_sub_func_uint32_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s_unsafe_macro/*8*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*10*//* ___SAFE__OP */(((void*)0 != &l_2), (*l_1934))), (*l_1934))), ((*l_1934) || (-9L)))) && (*l_1934)), (*l_1934))) == (*g_2061))) <= (*l_1934))) , (*l_1934)) >= (*l_1934)) >= 1UL) , (*l_1934)) , (*l_1934)) , l_1674)) , (*l_1781))) >= (*l_1934))), (*l_1934))))
    { /* block id: 1033 */
        g_2205 = &l_1934;
        for (g_16 = (-13); (g_16 != 13); g_16 = safe_add_func_uint8_t_u_u_unsafe_macro/*11*//* ___SAFE__OP */(g_16, 1))
        { /* block id: 1037 */
            uint64_t ****l_2208 = &g_1158;
            uint64_t *****l_2209 = (void*)0;
            uint64_t *****l_2210 = (void*)0;
            uint64_t *****l_2211 = &l_2208;
            (*g_619) |= (l_1717 != ((*l_2211) = l_2208));
        }
    }
    else
    { /* block id: 1041 */
        (*g_1645) &= (*g_619);
        for (l_1932 = 0; (l_1932 <= 4); l_1932 += 1)
        { /* block id: 1045 */
            int32_t *l_2212 = &l_1793[0][0];
            int32_t l_2213 = 2L;
            int32_t *l_2214 = &l_1793[0][6];
            int32_t *l_2215 = (void*)0;
            int32_t *l_2216 = &g_56;
            int32_t *l_2217[2];
            uint16_t l_2218 = 0UL;
            int i;
            for (i = 0; i < 2; i++)
                l_2217[i] = &l_2213;
            l_2218--;
            (**g_1774) ^= g_66[l_1932];
        }
    }
    (*g_2221) = (*g_307);
    return (*l_1934);
}


/* ------------------------------------------ */
/* 
 * reads : g_1325 g_1326 g_1546 g_207 g_208 g_619 g_1645 g_66 g_212
 * writes: g_398 g_56 g_66 g_211 g_212
 */
static int64_t  func_5(int8_t  p_6, struct S0  p_7, uint32_t  p_8, const uint32_t  p_9, int8_t  p_10)
{ /* block id: 790 */
    const uint32_t l_1677 = 0x5DBEAC21L;
    uint8_t l_1690 = 253UL;
    int32_t l_1695 = 0x2431CFA3L;
    int8_t *l_1696 = &g_211;
    uint64_t l_1697 = 18446744073709551615UL;
    int32_t *l_1698 = &g_212;
    int32_t *l_1699 = &l_1695;
    int32_t *l_1700 = &g_66[1];
    int32_t *l_1701 = &g_212;
    int32_t *l_1702 = &g_56;
    int32_t *l_1703 = &g_212;
    int32_t *l_1704 = &g_66[3];
    int32_t *l_1705[5];
    uint32_t l_1706 = 0xA8E9C610L;
    int32_t l_1709 = 0xA792B969L;
    int i;
    for (i = 0; i < 5; i++)
        l_1705[i] = &l_1695;
    (*l_1698) ^= ((safe_lshift_func_int16_t_s_s(l_1677, 11)) < (p_9 != (safe_rshift_func_uint64_t_u_u((((safe_div_func_int8_t_s_s_unsafe_macro/*14*//* ___SAFE__OP */(((*l_1696) = (safe_add_func_int16_t_s_s_unsafe_macro/*15*//* ___SAFE__OP */((((safe_div_func_uint8_t_u_u_unsafe_macro/*16*//* ___SAFE__OP */((((*g_1645) &= ((((*g_619) = (safe_rshift_func_int64_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */((l_1677 || ((l_1677 <= (((**g_1325) = (l_1690 = 0x2E2FL)) | (p_7 , ((((l_1695 = ((safe_mul_func_int64_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */(p_8, (safe_div_func_uint8_t_u_u_unsafe_macro/*19*//* ___SAFE__OP */(p_7.f0, l_1677)))) , g_1546[4])) != l_1677) , (*g_207)) != (void*)0)))) & p_8)), 15))) > 0UL) > 0xC26EL)) != l_1677), p_7.f0)) || 8L) <= p_9), p_10))), 249UL)) ^ l_1697) < 5L), 56))));
    l_1706--;
    return l_1709;
}


/* ------------------------------------------ */
/* 
 * reads : g_191 g_146 g_922 g_56 g_1543 g_1544 g_190 g_1326 g_398 g_307 g_308 g_66 g_1470 g_1471 g_1645 g_619
 * writes: g_56 g_211 g_66
 */
static int32_t  func_13(int64_t  p_14, int64_t  p_15)
{ /* block id: 2 */
    struct S0 l_52[7] = {{0xF87662B0L},{0x94FE874DL},{0xF87662B0L},{0xF87662B0L},{0x94FE874DL},{0xF87662B0L},{0xF87662B0L}};
    uint64_t * const *l_1073[6][2] = {{&g_1071,&g_1071},{&g_1071,&g_1071},{&g_1071,&g_1071},{&g_1071,&g_1071},{&g_1071,&g_1071},{&g_1071,&g_1071}};
    int32_t l_1094 = (-6L);
    int32_t **l_1112 = &g_922;
    int16_t *l_1140 = &g_398;
    uint8_t *l_1143 = &g_146;
    uint8_t *l_1145 = &g_712;
    int32_t l_1165 = 0L;
    int32_t l_1177 = (-6L);
    int32_t l_1178 = 0xDB276EB4L;
    int32_t l_1179 = 0x35268C74L;
    int32_t l_1182 = (-10L);
    int32_t l_1183 = 0x3151C22BL;
    uint32_t l_1185[5][10] = {{4294967295UL,4294967295UL,0xF3AD4CABL,4294967288UL,0UL,0xF3AD4CABL,0UL,4294967288UL,0xF3AD4CABL,4294967295UL},{0UL,4294967287UL,1UL,0UL,0x22D0DA82L,0x22D0DA82L,0UL,1UL,4294967287UL,0UL},{1UL,4294967295UL,4294967287UL,0x22D0DA82L,4294967295UL,0x22D0DA82L,4294967287UL,4294967295UL,1UL,1UL},{0UL,4294967288UL,0xF3AD4CABL,4294967295UL,4294967295UL,0xF3AD4CABL,4294967288UL,0UL,0xF3AD4CABL,0UL},{4294967295UL,4294967287UL,0x22D0DA82L,1UL,4294967290UL,0xF3AD4CABL,1UL,0UL,0UL,1UL}};
    int64_t **l_1210 = &g_1006;
    const int8_t *l_1214 = &g_211;
    const int8_t ** const l_1213[1] = {&l_1214};
    uint64_t ****l_1283 = (void*)0;
    uint64_t ****l_1285 = &g_1158;
    uint16_t l_1305[10];
    int16_t **l_1327[7][3][6] = {{{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326}},{{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326}},{{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326}},{{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326}},{{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326}},{{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326}},{{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326},{&g_1326,&g_1326,&g_1326,&g_1326,&g_1326,&g_1326},{&l_1140,&g_1326,&l_1140,&g_1326,&l_1140,&g_1326}}};
    int64_t l_1391 = 0x5D3D549AEE81A66BLL;
    int32_t l_1392 = 0x20A4D504L;
    int32_t l_1393[2][1][8] = {{{0L,0L,0L,0x016847C1L,0x016847C1L,0L,0L,0L}},{{0x02CC9866L,0x016847C1L,(-9L),0x016847C1L,0x02CC9866L,0x02CC9866L,0x016847C1L,(-9L)}}};
    int32_t l_1395 = 0x711D76E3L;
    int16_t l_1396[9][7] = {{0x05AAL,0x43E7L,0x6028L,0xE3FEL,0xA9F8L,0xE3FEL,0x6028L},{0x05AAL,0x05AAL,1L,0x4148L,0x8A0FL,2L,0x34B4L},{2L,0xFD1EL,0xE90EL,1L,1L,0x6028L,0x8082L},{1L,0x9390L,0x75BEL,(-2L),0x8A0FL,0x8082L,0x05AAL},{2L,0x2BD6L,1L,(-8L),0xA9F8L,0xA9F8L,(-8L)},{0x663BL,0x2BD6L,0x663BL,0x05AAL,0x8082L,0x8A0FL,0xA9F8L},{1L,0x7011L,0x9390L,0x663BL,1L,0x857BL,0x714BL},{0x4148L,1L,0x8082L,0x43E7L,0x8A0FL,2L,0xFD1EL},{0x34B4L,(-2L),0xE3FEL,1L,0x4148L,0x8082L,0x4148L}};
    uint32_t *l_1406 = (void*)0;
    int32_t l_1455 = 0L;
    int16_t l_1574 = (-1L);
    int64_t **** const *l_1603 = (void*)0;
    uint8_t l_1635[2][3][5] = {{{0xDAL,5UL,5UL,0xDAL,0xA9L},{0xDAL,0xEAL,0x3BL,0xDAL,0x23L},{0x5CL,0xEAL,5UL,0x5CL,0x23L}},{{0xDAL,5UL,5UL,0xDAL,0xA9L},{0xDAL,0xEAL,0x3BL,0xDAL,0x23L},{0x5CL,0xEAL,5UL,0x5CL,0x23L}}};
    uint32_t l_1667 = 0x7C40CABBL;
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_1305[i] = 0xF97BL;
    if (p_14)
    { /* block id: 3 */
        uint32_t *l_730 = &g_149;
        int32_t l_975 = 0x279B0077L;
        uint8_t *l_1067 = &g_146;
        int16_t * const l_1088 = &g_398;
        int16_t * const *l_1087 = &l_1088;
        int32_t *l_1131 = (void*)0;
        int32_t **l_1130 = &l_1131;
        int64_t ***l_1142 = &g_1005;
        struct S0 l_1161[7] = {{6L},{6L},{6L},{6L},{6L},{6L},{6L}};
        int32_t l_1181[2];
        int64_t *** const *l_1205 = &l_1142;
        int64_t *** const **l_1204 = &l_1205;
        struct S0 l_1222[2] = {{0L},{0L}};
        uint32_t l_1259 = 1UL;
        uint16_t *l_1278 = &g_243;
        uint64_t *****l_1284 = &l_1283;
        int32_t l_1286[7] = {(-9L),0x56C64705L,0x56C64705L,(-9L),0x56C64705L,0x56C64705L,(-9L)};
        uint32_t l_1287 = 0x678D5102L;
        int32_t l_1303[7][9] = {{4L,1L,0xC1EF08FFL,0xC1EF08FFL,1L,4L,0x51D4CC28L,(-2L),(-5L)},{4L,0x9AC1365CL,0x08CE1243L,0xC1EF08FFL,0x9AC1365CL,0x24089835L,0x51D4CC28L,1L,9L},{4L,(-2L),0xDCF6BE26L,0xC1EF08FFL,(-2L),(-6L),0x51D4CC28L,0x9AC1365CL,0x51D4CC28L},{4L,1L,0xC1EF08FFL,0xC1EF08FFL,1L,4L,0x51D4CC28L,(-2L),(-5L)},{4L,0x9AC1365CL,0x08CE1243L,0xC1EF08FFL,0x9AC1365CL,0x24089835L,0x51D4CC28L,1L,9L},{4L,(-2L),0xDCF6BE26L,0xC1EF08FFL,(-2L),(-6L),0x51D4CC28L,0x9AC1365CL,0x51D4CC28L},{4L,1L,0xC1EF08FFL,0xC1EF08FFL,1L,4L,0x51D4CC28L,(-2L),(-5L)}};
        int64_t l_1397 = 0x5713DAF3446DC2FDLL;
        const int32_t *l_1427 = (void*)0;
        int i, j;
        for (i = 0; i < 2; i++)
            l_1181[i] = 0x3283F5F5L;
    }
    else
    { /* block id: 776 */
        struct S0 l_1648 = {0x9BB0B00FL};
        int64_t *****l_1664 = &g_1003;
        int8_t *l_1665 = (void*)0;
        int8_t *l_1666 = &g_211;
        l_1648 = l_1648;
        (*g_1645) = ((safe_lshift_func_int32_t_s_s_unsafe_macro/*20*//* ___SAFE__OP */(((safe_sub_func_uint8_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */((*g_191), (((((((1L != (safe_rshift_func_int64_t_s_u_unsafe_macro/*22*//* ___SAFE__OP */((((**l_1112) = p_14) , (((((safe_mod_func_uint8_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */(((**l_1112) | (safe_rshift_func_uint64_t_u_u_unsafe_macro/*24*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */(p_14, ((*l_1666) = (safe_rshift_func_uint64_t_u_u_unsafe_macro/*26*//* ___SAFE__OP */((((****g_1543) , (&g_1119 == (l_1664 = &g_1003))) && (**l_1112)), p_14))))) == 0x3543L), 38))), 0xFAL)) | 1UL) ^ (**l_1112)) != (*g_1326)) < 0xBAE9L)), l_1648.f0))) == p_15) , p_14) , p_14) , p_15) , 1L) , 0xF4L))) , (**g_307)), p_15)) <= (*g_1470));
        for (l_1178 = 4; (l_1178 >= 1); l_1178 -= 1)
        { /* block id: 784 */
            return l_1667;
        }
        (*g_619) = p_14;
    }
    return (*g_308);
}


/* ------------------------------------------ */
/* 
 * reads : g_712 g_392 g_393 g_86 g_186 g_619 g_56 g_877 g_243 g_240 g_191 g_146 g_824 g_211 g_577 g_578 g_308 g_66 g_922 g_59 g_1005 g_1006 g_909 g_210 g_1060 g_951 g_35.f0 g_16
 * writes: g_712 g_1003 g_398 g_56 g_243 g_149 g_210 g_211 g_1034 g_16 g_86 g_358 g_59 g_1064
 */
static uint64_t  func_19(struct S0  p_20, uint64_t  p_21, const int32_t  p_22, struct S0  p_23)
{ /* block id: 497 */
    int32_t *l_979[6];
    uint64_t l_980 = 0xA610295EE02EA992LL;
    int8_t *l_992 = &g_211;
    int8_t **l_991 = &l_992;
    uint16_t *l_1012 = &g_186;
    const struct S0 *l_1054[3][6][6] = {{{&g_1052,&g_1021,&g_358[6][1],&g_358[5][3],&g_35,&g_358[6][1]},{&g_1052,&g_1021,&g_35,&g_358[5][3],&g_35,&g_358[5][3]},{&g_1052,&g_1021,&g_1052,&g_358[5][3],&g_358[6][1],&g_358[0][3]},{&g_1052,&g_1021,&g_358[6][1],&g_358[5][3],&g_35,&g_358[6][1]},{&g_1052,&g_1021,&g_35,&g_358[5][3],&g_35,&g_358[5][3]},{&g_1052,&g_1021,&g_1052,&g_358[5][3],&g_358[6][1],&g_358[0][3]}},{{&g_1052,&g_1021,&g_358[6][1],&g_358[5][3],&g_35,&g_358[6][1]},{&g_1052,&g_1021,&g_35,&g_358[5][3],&g_35,&g_358[5][3]},{&g_1052,&g_1021,&g_1052,&g_358[5][3],&g_358[6][1],&g_358[0][3]},{&g_1052,&g_1021,&g_358[6][1],&g_358[5][3],&g_35,&g_358[6][1]},{&g_358[6][1],&g_358[6][1],&g_358[6][1],&g_35,&g_1052,&g_35},{&g_358[6][1],&g_358[0][3],&g_358[6][1],&g_35,&g_35,&g_1052}},{{&g_358[6][1],&g_358[5][3],&g_1021,&g_35,&g_358[6][1],&g_358[6][1]},{&g_358[6][1],&g_358[6][1],&g_358[6][1],&g_35,&g_1052,&g_35},{&g_358[6][1],&g_358[0][3],&g_358[6][1],&g_35,&g_35,&g_1052},{&g_358[6][1],&g_358[5][3],&g_1021,&g_35,&g_358[6][1],&g_358[6][1]},{&g_358[6][1],&g_358[6][1],&g_358[6][1],&g_35,&g_1052,&g_35},{&g_358[6][1],&g_358[0][3],&g_358[6][1],&g_35,&g_35,&g_1052}}};
    const struct S0 **l_1053 = &l_1054[1][2][1];
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_979[i] = (void*)0;
    l_980--;
    if (l_980)
        goto lbl_1013;
    for (g_712 = 0; (g_712 <= 4); g_712 += 1)
    { /* block id: 501 */
        int8_t ***l_993 = &l_991;
        int8_t **l_995 = &l_992;
        int8_t ***l_994 = &l_995;
        int32_t l_996 = 1L;
        int64_t ****l_1001 = (void*)0;
        int64_t *****l_1002 = &l_1001;
        int16_t *l_1009 = &g_398;
        int16_t *l_1010[4];
        int32_t l_1011 = 0xBA848146L;
        int i;
        for (i = 0; i < 4; i++)
            l_1010[i] = (void*)0;
        (*g_619) &= ((((safe_mod_func_int32_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */(((0x1E820C57CF916CC8LL <= ((!0x11ACL) , (safe_mod_func_int32_t_s_s_unsafe_macro/*28*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*29*//* ___SAFE__OP */(((+(((*l_993) = l_991) != ((*l_994) = &l_992))) & l_996), ((safe_mul_func_int16_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */(((**g_392) || ((g_1003 = ((*l_1002) = l_1001)) != (void*)0)), (l_1011 = ((*l_1009) = (safe_mul_func_uint64_t_u_u_unsafe_macro/*31*//* ___SAFE__OP */(g_186, p_20.f0)))))) & g_186))), 0x9CF10B80L)))) == 0xF9L), p_20.f0)) , l_1012) != &g_186) < 5UL);
    }
lbl_1013:
    (**g_877) = p_21;
    for (g_243 = 0; (g_243 >= 41); g_243 = safe_add_func_int16_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */(g_243, 8))
    { /* block id: 514 */
        struct S0 *l_1018 = &g_358[1][7];
        const struct S0 *l_1020 = &g_1021;
        const struct S0 **l_1019 = &l_1020;
        int32_t l_1022 = (-1L);
        uint32_t l_1023 = 6UL;
        int8_t *l_1024 = &g_211;
        uint32_t *l_1025 = &g_149;
        int32_t *l_1037 = &g_66[3];
        struct S0 * const **l_1048 = (void*)0;
        struct S0 * const l_1051 = &g_1052;
        struct S0 * const *l_1050[6][1][8] = {{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}},{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}},{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}},{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}},{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}},{{(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051,(void*)0,&l_1051}}};
        struct S0 * const **l_1049 = &l_1050[1][0][5];
        const struct S0 ***l_1055 = &l_1019;
        int16_t *l_1062 = &g_398;
        int16_t **l_1061 = &l_1062;
        uint32_t l_1063 = 0xE30527C5L;
        int32_t **l_1065 = &l_1037;
        int32_t *l_1066 = &g_212;
        int i, j, k;
        l_1022 &= (safe_sub_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */(g_56, ((g_240[8] <= 0xEBDDL) <= ((p_20 , l_1018) != ((*l_1019) = &p_23)))));
        (*l_1018) = func_24(l_1023, ((*g_824) = (p_21 ^ ((*l_1025) = ((*l_991) != ((*g_191) , l_1024))))), p_22, (safe_rshift_func_uint8_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */(((g_16 = (safe_add_func_uint32_t_u_u_unsafe_macro/*35*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */((p_21 < ((safe_div_func_int8_t_s_s_unsafe_macro/*37*//* ___SAFE__OP */((p_20.f0 , (g_1034 = ((**l_991) ^= 0x0CL))), (*g_577))) < p_20.f0)), 0xFFL)) < p_21), (*g_619)))) , 0UL), 0)), g_240[8]);
        for (g_59 = 0; (g_59 != 11); ++g_59)
        { /* block id: 525 */
            if (l_1022)
                break;
            return p_22;
        }
        l_1066 = ((*l_1065) = func_79(l_1037, (g_1064 = ((p_20 , ((*l_992) = (l_1024 == (*l_991)))) >= ((safe_add_func_uint64_t_u_u_unsafe_macro/*38*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*39*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*41*//* ___SAFE__OP */((((**g_1005) <= (-1L)) <= (((*l_1049) = &g_349) != ((*l_1055) = l_1053))), 13)), (safe_add_func_int32_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */((((((*l_1025) = (((safe_add_func_int8_t_s_s_unsafe_macro/*43*//* ___SAFE__OP */((*l_1037), (*l_1037))) != p_21) || 250UL)) > g_210) , g_1060) != l_1061), g_951[3])))), (*l_1037))), 18446744073709551615UL)) >= l_1063))), l_979[1], &l_1022, l_979[2]));
    }
    return g_578;
}


/* ------------------------------------------ */
/* 
 * reads : g_308 g_66 g_922 g_56 g_712 g_86
 * writes: g_56 g_712 g_86
 */
static struct S0  func_24(int32_t  p_25, int32_t  p_26, uint32_t  p_27, uint8_t  p_28, int8_t  p_29)
{ /* block id: 485 */
    struct S0 l_978 = {0x35B1FF20L};
    (*g_922) |= (*g_308);
    for (g_712 = 19; (g_712 >= 39); g_712 = safe_add_func_uint64_t_u_u_unsafe_macro/*44*//* ___SAFE__OP */(g_712, 2))
    { /* block id: 489 */
        for (g_86 = 0; (g_86 <= 8); g_86 += 1)
        { /* block id: 492 */
            return l_978;
        }
    }
    return l_978;
}


/* ------------------------------------------ */
/* 
 * reads : g_35.f0 g_191 g_146 g_238 g_619 g_56 g_579 g_576 g_211 g_243 g_398 g_86 g_212
 * writes: g_210 g_500 g_146 g_56 g_212 g_358 g_398 g_346 g_576 g_211 g_240 g_238 g_86 g_35.f0
 */
static uint8_t  func_32(struct S0  p_33, uint32_t  p_34)
{ /* block id: 345 */
    const uint32_t *l_731 = &g_149;
    uint64_t l_738 = 3UL;
    int64_t * const l_742 = &g_240[6];
    int32_t l_763 = 1L;
    int32_t l_766 = 0xFCC1C307L;
    int32_t l_767 = (-1L);
    int32_t l_768 = 0L;
    int16_t l_770[8] = {7L,0x9203L,7L,7L,0x9203L,7L,7L,0x9203L};
    int32_t l_772 = 0xD21FB5FEL;
    int32_t l_774 = 0x64F5C6AFL;
    int32_t l_776 = (-6L);
    uint32_t l_789 = 0x903F7149L;
    int32_t *l_925[4][3][4] = {{{&l_774,&l_776,&l_776,&l_774},{&l_776,&l_774,&g_66[3],&g_212},{&l_776,&g_66[3],&l_776,&l_772}},{{&l_774,&g_212,&l_772,&l_772},{&g_66[3],&g_66[3],&g_66[2],&g_212},{&g_212,&l_774,&g_66[2],&l_774}},{{&g_66[3],&l_776,&l_772,&g_66[2]},{&l_774,&l_776,&l_776,&l_774},{&l_776,&l_774,&g_66[3],&g_212}},{{&l_776,&g_66[3],&l_776,&l_772},{&l_774,&g_212,&l_772,&l_772},{&g_66[3],&g_66[3],&g_66[2],&g_212}}};
    struct S0 *l_939 = (void*)0;
    int32_t *l_965 = &l_768;
    int i, j, k;
lbl_781:
    for (g_210 = 0; g_210 < 7; g_210 += 1)
    {
        g_500[g_210] = &g_212;
    }
    for (g_146 = 0; (g_146 <= 4); g_146 += 1)
    { /* block id: 349 */
        int32_t *l_739 = &g_358[6][1].f0;
        int32_t **l_740 = &l_739;
        const int32_t l_741 = (-1L);
        int32_t l_765 = 0xEC751547L;
        int32_t l_773 = 1L;
        int32_t l_777 = 0x0D0FBCB2L;
        uint64_t l_778 = 18446744073709551615UL;
        struct S0 l_784[9] = {{0x6FA7C6B1L},{0x71D89CA1L},{0x71D89CA1L},{0x6FA7C6B1L},{0x71D89CA1L},{0x71D89CA1L},{0x6FA7C6B1L},{0x71D89CA1L},{0x71D89CA1L}};
        int32_t l_787[6] = {0xC477DF7CL,0x036A107FL,0x036A107FL,0xC477DF7CL,0x036A107FL,0x036A107FL};
        int32_t l_788[8] = {0xA9518522L,0x0197CC1FL,0x0197CC1FL,0xA9518522L,0x0197CC1FL,0x0197CC1FL,0xA9518522L,0x0197CC1FL};
        int64_t ***l_812 = (void*)0;
        int32_t l_815[8] = {0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL,0xFE3BB43CL};
        int64_t l_872 = 0x5F511C335A004EE0LL;
        int16_t l_914 = 0xEC32L;
        int32_t *l_924 = &l_777;
        int i;
        if ((l_731 != (((p_33 , (g_35.f0 , (safe_add_func_uint16_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */(0UL, ((((safe_mod_func_uint32_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */((((((safe_sub_func_uint32_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */(p_33.f0, (l_738 != (p_33.f0 >= (&g_210 == ((*l_740) = l_739)))))) , (-1L)) , p_33.f0) || 18446744073709551607UL) ^ l_738), l_741)) , l_742) == (void*)0) <= p_34))))) & (*g_191)) , (void*)0)))
        { /* block id: 351 */
            int16_t l_749 = 0L;
            int64_t *l_754[6][10][2] = {{{&g_240[8],&g_86},{&g_240[8],&g_240[8]},{&g_86,(void*)0},{&g_86,&g_240[8]},{(void*)0,&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]}},{{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86},{(void*)0,&g_240[8]},{&g_240[8],&g_240[8]},{(void*)0,(void*)0},{&g_240[8],&g_240[8]},{&g_86,&g_240[8]},{&g_240[8],(void*)0},{(void*)0,&g_240[8]}},{{&g_240[8],&g_240[8]},{(void*)0,&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]},{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86}},{{(void*)0,&g_240[8]},{&g_240[8],&g_240[8]},{(void*)0,(void*)0},{&g_240[8],&g_240[8]},{&g_86,&g_240[8]},{&g_240[8],(void*)0},{(void*)0,&g_240[8]},{&g_240[8],&g_240[8]},{(void*)0,&g_86},{&g_240[8],&g_86}},{{&g_240[8],&g_86},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]},{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86},{(void*)0,&g_240[8]},{&g_240[8],&g_240[8]},{(void*)0,(void*)0}},{{&g_240[8],&g_240[8]},{&g_86,&g_240[8]},{&g_240[8],(void*)0},{(void*)0,&g_240[8]},{&g_240[8],&g_240[8]},{(void*)0,&g_86},{&g_240[8],&g_86},{&g_240[8],&g_86},{&g_240[8],&g_240[8]},{&g_240[8],&g_240[8]}}};
            int64_t **l_753 = &l_754[3][8][1];
            int64_t ***l_752 = &l_753;
            int64_t ****l_751 = &l_752;
            int64_t *****l_755 = &l_751;
            int32_t l_764 = 0xEA05791AL;
            int32_t l_769 = 0x770CF13DL;
            int32_t l_771 = 0xF6B38829L;
            int32_t l_775 = 0xA31A75BAL;
            int i, j, k;
            if (p_33.f0)
            { /* block id: 352 */
                (*g_619) = (safe_rshift_func_uint32_t_u_s_unsafe_macro/*48*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*49*//* ___SAFE__OP */(p_33.f0, (safe_div_func_int32_t_s_s_unsafe_macro/*50*//* ___SAFE__OP */(l_749, g_238[3][5])))), 22));
            }
            else
            { /* block id: 354 */
                for (g_212 = 4; (g_212 >= 0); g_212 -= 1)
                { /* block id: 357 */
                    struct S0 *l_750 = &g_358[6][1];
                    int i, j;
                    (*l_750) = p_33;
                    (*g_619) = g_238[g_146][(g_146 + 2)];
                }
                (*g_619) ^= 0xE8D4F5EAL;
            }
            (*l_755) = l_751;
            for (g_212 = 4; (g_212 >= 0); g_212 -= 1)
            { /* block id: 366 */
                const int32_t **l_756 = &g_346[0][3][2];
                int32_t *l_757 = &g_66[2];
                int32_t *l_758 = &g_66[3];
                int32_t *l_759 = (void*)0;
                int32_t *l_760 = (void*)0;
                int32_t *l_761 = &g_66[2];
                int32_t *l_762[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_762[i] = &g_66[3];
                for (g_398 = 4; (g_398 >= 1); g_398 -= 1)
                { /* block id: 369 */
                    int i, j;
                    return g_238[g_146][g_146];
                }
                (*l_756) = l_731;
                --l_778;
                if (l_778)
                    goto lbl_781;
            }
        }
        else
        { /* block id: 376 */
            const volatile int8_t ** volatile *l_783 = &g_576[1][0][2];
            int32_t *l_785 = &l_767;
            int32_t *l_786[1][8] = {{&l_773,&l_773,&l_773,&l_773,&l_773,&l_773,&l_773,&l_773}};
            int i, j;
            (*l_783) = (*g_579);
            p_33 = l_784[3];
            --l_789;
        }
        for (g_211 = 3; (g_211 >= 0); g_211 -= 1)
        { /* block id: 383 */
            uint16_t l_799[5];
            int32_t l_834 = 0xE068A2EEL;
            int32_t *l_861 = &g_35.f0;
            int32_t l_911 = (-4L);
            int32_t l_916[3][6][5] = {{{0x0EC9436EL,0x3CBF475CL,5L,0x17D009DFL,0x0C46A0CCL},{0x0B0DC5A6L,0x2A7387EFL,0x72EB274DL,0x29F9B74BL,0x17D009DFL},{0x0C46A0CCL,0L,0x2B1D7C34L,0xD35E9B8CL,0x3CBF475CL},{0x72EB274DL,(-1L),0x4871251BL,0x4C056C86L,0x9A0C2109L},{0x72EB274DL,0x27948643L,0x07383ED6L,5L,0x07383ED6L},{0x0C46A0CCL,0x0C46A0CCL,(-1L),0xAD1304C7L,0x72EB274DL}},{{0x0B0DC5A6L,0xD16A7554L,0x4C056C86L,(-7L),0L},{0x0EC9436EL,1L,(-8L),0x0B0DC5A6L,(-8L)},{5L,0xD16A7554L,0xD35E9B8CL,0xBF689944L,0xF64344FAL},{0xBF689944L,0x0C46A0CCL,0L,0x2B1D7C34L,0xD35E9B8CL},{0x17D009DFL,0x27948643L,(-7L),0x3CBF475CL,0x80957413L},{0x2B1D7C34L,(-1L),(-7L),0x4871251BL,0x2A7387EFL}},{{1L,0L,0L,1L,0x16BDCC9CL},{0L,0x2A7387EFL,0xD35E9B8CL,0x40CA2E45L,0x0EC9436EL},{0x29F9B74BL,0x07383ED6L,0x0EC9436EL,0x3CBF475CL,5L},{0x72EB274DL,0x4C056C86L,5L,0x80957413L,(-1L)},{0x03598677L,(-7L),0xBF689944L,(-1L),0x3CBF475CL},{0L,0x4871251BL,0x17D009DFL,0x2B1D7C34L,0xF64344FAL}}};
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_799[i] = 0x7443L;
            (*g_619) &= (0x3FACBE40L ^ 0xD763ED04L);
            for (l_773 = 0; (l_773 <= 4); l_773 += 1)
            { /* block id: 387 */
                uint64_t *l_808 = (void*)0;
                uint64_t *l_809 = &l_778;
                const int32_t l_810 = 0x85B801AFL;
                int32_t l_811 = (-1L);
                int64_t ***l_813 = (void*)0;
                int32_t l_842 = 0xDC556499L;
                int32_t l_843[5][10] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
                uint16_t *l_898[7][5][5] = {{{(void*)0,(void*)0,&g_186,&g_186,&l_799[4]},{&g_243,(void*)0,&g_243,(void*)0,(void*)0},{&l_799[3],&l_799[3],&g_186,&g_243,&l_799[4]},{&g_186,(void*)0,&l_799[4],&l_799[1],&g_243},{&g_243,&l_799[3],&l_799[4],&g_243,&g_186}},{{&l_799[4],&l_799[4],&l_799[4],&l_799[4],&g_243},{&l_799[1],&l_799[4],&g_243,&g_186,(void*)0},{&g_186,&g_243,&l_799[0],&l_799[4],(void*)0},{&l_799[3],&g_186,&l_799[4],&g_186,&l_799[4]},{&l_799[4],&g_186,&l_799[4],&l_799[4],&l_799[4]}},{{&l_799[0],&g_243,&l_799[4],&g_243,(void*)0},{&l_799[0],&g_186,&g_186,&l_799[1],&l_799[4]},{&g_186,&g_186,&l_799[4],&g_243,(void*)0},{(void*)0,&g_186,&g_186,(void*)0,&g_186},{&g_186,&l_799[3],&g_186,&g_186,&l_799[4]}},{{(void*)0,&l_799[0],&l_799[1],&g_186,&l_799[3]},{(void*)0,&l_799[4],&l_799[3],&l_799[4],&l_799[4]},{&g_186,(void*)0,&g_186,&g_243,&l_799[4]},{(void*)0,&l_799[0],(void*)0,&l_799[3],&l_799[4]},{&g_186,&l_799[4],&l_799[4],&l_799[4],&g_243}},{{&l_799[0],&l_799[4],&g_243,&g_243,&g_243},{&l_799[0],&l_799[4],&l_799[0],&l_799[4],&l_799[2]},{&l_799[4],&g_243,&l_799[4],&g_186,(void*)0},{&l_799[3],(void*)0,(void*)0,&l_799[4],(void*)0},{(void*)0,&g_186,&g_243,&g_186,&g_186}},{{&g_243,&l_799[0],&g_186,(void*)0,&g_243},{&l_799[4],&g_186,(void*)0,(void*)0,&g_243},{(void*)0,&g_186,&l_799[0],&l_799[0],&g_243},{&l_799[3],&l_799[3],&g_186,&l_799[4],&l_799[1]},{&g_186,(void*)0,&g_243,&g_243,&l_799[0]}},{{&l_799[0],(void*)0,(void*)0,(void*)0,&l_799[4]},{(void*)0,&l_799[4],&g_243,&g_243,&l_799[4]},{(void*)0,&l_799[4],(void*)0,&l_799[2],&l_799[0]},{&g_243,&l_799[2],&l_799[0],&l_799[3],&l_799[1]},{&l_799[3],&l_799[0],&l_799[2],&l_799[1],&g_243}}};
                int32_t l_915 = 0x0E9EA555L;
                int64_t l_917 = 0x730A487ED32A41B4LL;
                int i, j, k;
                (*g_619) &= ((g_238[g_146][(g_146 + 2)] , ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */((l_811 = ((((~(safe_add_func_uint32_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */((l_799[4] != (((*l_809) ^= (g_238[l_773][(l_773 + 2)] = (g_238[g_146][(g_146 + 2)] || (safe_mul_func_int8_t_s_s_unsafe_macro/*53*//* ___SAFE__OP */(((g_238[g_146][(g_146 + 2)] , g_243) & (safe_div_func_int64_t_s_s_unsafe_macro/*54*//* ___SAFE__OP */((g_398 <= ((safe_add_func_int32_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */((((safe_mul_func_uint64_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */(p_33.f0, ((((*l_742) = l_741) & p_34) | l_799[4]))) || l_799[3]) != 2L), p_33.f0)) , 0x9E579EF00A8D37EALL)), g_35.f0))), 0xA6L))))) > p_34)), l_810))) , 0xDBD3C654L) != p_33.f0) , p_34)), l_799[4])) != 0x4BC67CD2BC1546F4LL)) , (-6L));
                for (l_763 = 8; (l_763 >= 3); l_763 -= 1)
                { /* block id: 395 */
                    uint32_t l_814 = 18446744073709551610UL;
                    l_813 = (g_146 , l_812);
                    for (g_86 = 6; (g_86 >= 0); g_86 -= 1)
                    { /* block id: 399 */
                        if (l_814)
                            break;
                    }
                }
                if (l_815[5])
                    break;
                for (g_35.f0 = 0; (g_35.f0 < (-3)); --g_35.f0)
                { /* block id: 406 */
                    uint32_t l_833 = 0xB70AF8A3L;
                    uint8_t ***l_836 = (void*)0;
                    uint8_t ****l_835 = &l_836;
                    int32_t l_841[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                    struct S0 l_847[8] = {{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL},{0x23ED48CAL}};
                    int32_t *l_908[6] = {(void*)0,&g_66[0],(void*)0,(void*)0,&g_66[0],(void*)0};
                    uint64_t l_918 = 1UL;
                    int i;
                }
            }
        }
    }
    for (l_738 = 0; (l_738 <= 7); l_738 += 1)
    { /* block id: 438 */
        int64_t *l_948 = &g_240[8];
        int32_t l_953[1][9][7] = {{{0x48DF74CDL,0x48DF74CDL,0xED59BAB2L,0xC64F4436L,0xE9348281L,0x3BAD5178L,(-7L)},{0L,(-1L),0xECDEEF8CL,0xE9348281L,0x48DF74CDL,1L,0L},{0x0BB5F4EFL,0x5A05D7B3L,0x60C1BAF3L,(-1L),0xE9348281L,0x345D40A0L,0x5A05D7B3L},{0xED59BAB2L,0L,0x4003A451L,0x4003A451L,0L,0xED59BAB2L,0x5A05D7B3L},{0x345D40A0L,0xE9348281L,(-1L),0x60C1BAF3L,0x5A05D7B3L,0x0BB5F4EFL,0L},{1L,0x48DF74CDL,0xE9348281L,0xECDEEF8CL,(-1L),0L,(-7L)},{0x3BAD5178L,0xE9348281L,0xC64F4436L,0xED59BAB2L,0x48DF74CDL,0x48DF74CDL,0xED59BAB2L},{0x60C1BAF3L,0L,0x60C1BAF3L,0xED59BAB2L,0L,(-5L),0L},{0xED59BAB2L,0x5A05D7B3L,0xC43E44A2L,0xECDEEF8CL,(-1L),0xED59BAB2L,0x6A1EB3FEL}}};
        int i, j, k;
    }
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_86
 * writes:
 */
static const int16_t  func_42(int16_t  p_43, const uint64_t  p_44)
{ /* block id: 92 */
    int8_t l_251 = 1L;
    int32_t l_298 = 1L;
    int32_t l_300 = 0x37431E9BL;
    int32_t l_302 = 1L;
    uint32_t l_303 = 0x4F3221E7L;
    int32_t l_313 = 0x1101BBE2L;
    int32_t l_314 = 0xF5313A40L;
    int32_t l_315 = 0xE5F27103L;
    int32_t l_317 = 7L;
    int8_t l_319 = (-9L);
    uint8_t ***l_339 = &g_190[3];
    int64_t l_370 = 0xA9F24DD085FCC17ELL;
    int16_t *l_397 = &g_398;
    int64_t **l_449 = (void*)0;
    int64_t l_476 = 0xCD116746D8829680LL;
    int32_t l_542 = (-9L);
    int32_t l_543 = 1L;
    int32_t l_544 = 0xAC78EAE6L;
    int32_t l_545 = 0xFDB4479AL;
    int32_t l_546[6] = {1L,9L,1L,1L,9L,1L};
    uint32_t l_634 = 4294967287UL;
    uint8_t ****l_651[4];
    struct S0 l_662 = {-5L};
    uint16_t l_727 = 2UL;
    int i;
    for (i = 0; i < 4; i++)
        l_651[i] = &l_339;
    for (p_43 = 0; (p_43 >= (-19)); p_43 = safe_sub_func_uint32_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */(p_43, 8))
    { /* block id: 95 */
        uint64_t *l_264 = (void*)0;
        uint64_t ** const l_263 = &l_264;
        int32_t l_267[6][8] = {{(-1L),1L,(-1L),5L,(-1L),(-1L),(-1L),0x57937E0FL},{0x78384601L,5L,0L,(-1L),0x78D5E2C2L,0x78D5E2C2L,(-1L),0L},{0x78384601L,0x78384601L,0x94BA823DL,0xF7C98B74L,(-1L),0x6CD7918DL,0x78384601L,(-1L)},{(-1L),(-1L),5L,(-1L),1L,(-1L),5L,(-1L)},{(-1L),(-1L),0L,0xF7C98B74L,(-1L),5L,1L,0L},{0x57937E0FL,1L,0L,(-1L),(-1L),0xF7C98B74L,0x78D5E2C2L,0L}};
        struct S0 l_270 = {-7L};
        uint32_t l_320 = 4294967288UL;
        int16_t l_341[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        int8_t *l_368 = (void*)0;
        const int32_t *l_464 = &g_56;
        int64_t l_529 = (-5L);
        uint8_t ****l_650[1];
        uint32_t l_663 = 4294967295UL;
        int64_t *l_695 = &l_529;
        int64_t ** const l_694 = &l_695;
        int i, j;
        for (i = 0; i < 1; i++)
            l_650[i] = &l_339;
    }
    return g_86;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_59 g_65 g_66 g_56 g_35.f0 g_35 g_86 g_149 g_153 g_186 g_190 g_207 g_212 g_210 g_240 g_243
 * writes: g_59 g_56 g_66 g_86 g_146 g_149 g_154 g_65 g_186 g_208 g_210 g_211 g_212 g_238 g_240 g_243
 */
static const int16_t  func_47(uint64_t  p_48, struct S0  p_49, int64_t  p_50, int32_t  p_51)
{ /* block id: 4 */
    int32_t l_53[2];
    int32_t *l_54 = (void*)0;
    int32_t *l_55 = &g_56;
    int32_t l_57[3];
    int32_t *l_58 = (void*)0;
    const int32_t *l_78 = (void*)0;
    const int32_t **l_77 = &l_78;
    int64_t *l_85 = &g_86;
    int i;
    for (i = 0; i < 2; i++)
        l_53[i] = 0x323E629BL;
    for (i = 0; i < 3; i++)
        l_57[i] = 0x53BDBB38L;
    for (p_51 = 1; (p_51 >= 0); p_51 -= 1)
    { /* block id: 7 */
        if (p_48)
            break;
        if (g_16)
            break;
    }
    g_59++;
    for (p_49.f0 = 7; (p_49.f0 < (-27)); p_49.f0 = safe_sub_func_uint16_t_u_u_unsafe_macro/*58*//* ___SAFE__OP */(p_49.f0, 9))
    { /* block id: 14 */
        int32_t *l_64 = (void*)0;
        (*g_65) |= ((*l_55) = p_50);
    }
    (*l_77) = func_67((*l_55), ((safe_div_func_int64_t_s_s_unsafe_macro/*59*//* ___SAFE__OP */(p_49.f0, (safe_rshift_func_int32_t_s_s_unsafe_macro/*60*//* ___SAFE__OP */(0x320AF47DL, (((*l_77) = &p_51) != (void*)0))))) , func_79((((p_50 , ((*l_85) = g_56)) , ((p_51 <= ((*l_85) = (safe_mul_func_uint32_t_u_u_unsafe_macro/*61*//* ___SAFE__OP */((!((p_51 , p_51) < (**l_77))), 0L)))) ^ 0UL)) , &g_56), (*l_55), &l_57[2], &l_57[2], &g_66[3])), (*l_55), g_66[1], g_35);
    return p_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_66 g_65 g_86 g_16 g_35.f0 g_149 g_59 g_153 g_186 g_190 g_207 g_212 g_210 g_240 g_243
 * writes: g_56 g_146 g_149 g_154 g_65 g_66 g_186 g_208 g_210 g_211 g_59 g_86 g_212 g_238 g_240 g_243
 */
static int32_t * func_67(int16_t  p_68, int32_t * p_69, int32_t  p_70, const int32_t  p_71, struct S0  p_72)
{ /* block id: 26 */
    int16_t l_112 = 0xF0BBL;
    uint64_t *l_157 = &g_59;
    int32_t l_171 = 0L;
    int32_t l_181 = 3L;
    int32_t l_182 = 0x7EF2E4F1L;
    int32_t l_183[9];
    int32_t *l_209 = &g_210;
    int32_t *l_214 = &l_171;
    int32_t **l_213 = &l_214;
    uint16_t *l_232 = (void*)0;
    uint8_t *****l_234 = &g_208;
    uint32_t l_246 = 0xD6D71039L;
    int i;
    for (i = 0; i < 9; i++)
        l_183[i] = (-1L);
    for (p_70 = 1; (p_70 <= (-18)); p_70--)
    { /* block id: 29 */
        uint32_t l_147 = 4294967289UL;
        uint8_t *l_163 = (void*)0;
        uint8_t **l_162 = &l_163;
        uint8_t ***l_161 = &l_162;
        int32_t l_172 = (-2L);
        int32_t l_174[5][5] = {{0xB7F14100L,1L,0xB7F14100L,1L,0xB7F14100L},{0x840180ABL,0x840180ABL,0x840180ABL,0x840180ABL,0x840180ABL},{0xB7F14100L,1L,0xB7F14100L,1L,0xB7F14100L},{0x840180ABL,0x840180ABL,0x840180ABL,0x840180ABL,0x840180ABL},{0xB7F14100L,1L,0xB7F14100L,1L,0xB7F14100L}};
        uint64_t *l_203 = &g_59;
        int i, j;
        if (l_112)
            break;
        for (p_72.f0 = 0; (p_72.f0 == (-27)); p_72.f0 = safe_sub_func_uint8_t_u_u_unsafe_macro/*62*//* ___SAFE__OP */(p_72.f0, 4))
        { /* block id: 33 */
            int8_t l_136 = 0x2CL;
            uint64_t *l_156 = (void*)0;
            int32_t l_184 = 3L;
            int32_t l_185 = 0xF527E66CL;
            uint8_t **l_189 = (void*)0;
            if ((6L == p_70))
            { /* block id: 34 */
                uint64_t l_125 = 0xE62ED8E9B07D9F9ALL;
                uint8_t * const l_152[5] = {&g_146,&g_146,&g_146,&g_146,&g_146};
                uint8_t * const *l_151 = &l_152[4];
                int i;
                for (g_56 = 4; (g_56 >= 0); g_56 -= 1)
                { /* block id: 37 */
                    int32_t *l_115 = (void*)0;
                    int32_t *l_116 = &g_66[0];
                    int32_t *l_117 = &g_66[3];
                    int32_t *l_118 = &g_66[0];
                    int32_t *l_119 = &g_66[g_56];
                    int32_t *l_120 = &g_66[3];
                    int32_t *l_121 = (void*)0;
                    int32_t *l_122 = &g_66[3];
                    int32_t l_123[1];
                    int32_t *l_124 = &l_123[0];
                    uint8_t *l_145 = &g_146;
                    uint32_t *l_148 = &g_149;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_123[i] = 0xC5BE0112L;
                    --l_125;
                    if ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*63*//* ___SAFE__OP */(((((0x7C62769AL != (g_66[g_56] , (*g_65))) && ((safe_mod_func_int8_t_s_s_unsafe_macro/*64*//* ___SAFE__OP */(l_125, ((safe_rshift_func_int32_t_s_u_unsafe_macro/*65*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*66*//* ___SAFE__OP */(((0x828161DDL <= (0x80AFD421L >= ((*l_148) &= (l_136 > ((safe_lshift_func_int32_t_s_s_unsafe_macro/*67*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */(p_72.f0, (safe_lshift_func_uint8_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */(((*l_145) = ((g_86 , 4294967295UL) || g_16)), 3)))), g_35.f0)), l_147)) ^ 0L))))) && p_71), p_72.f0)), 9)) , g_59))) && g_66[3])) & g_66[1]) & g_35.f0), l_136)))
                    { /* block id: 41 */
                        int32_t l_150 = (-4L);
                        if (l_150)
                            break;
                        (*g_153) = l_151;
                    }
                    else
                    { /* block id: 44 */
                        int32_t **l_155[9][8][3];
                        uint64_t **l_158 = &l_157;
                        int i, j, k;
                        for (i = 0; i < 9; i++)
                        {
                            for (j = 0; j < 8; j++)
                            {
                                for (k = 0; k < 3; k++)
                                    l_155[i][j][k] = &l_118;
                            }
                        }
                        g_65 = (void*)0;
                        l_115 = &g_66[g_56];
                        (*l_117) = (((((l_156 == ((*l_158) = l_157)) , (65535UL >= ((l_147 > 1L) < 0x4C435671L))) , l_161) != ((safe_mul_func_uint64_t_u_u_unsafe_macro/*71*//* ___SAFE__OP */(g_56, g_66[1])) , &g_154)) <= p_71);
                    }
                    return p_69;
                }
            }
            else
            { /* block id: 52 */
                int32_t *l_166 = &g_66[4];
                int32_t *l_167 = &g_56;
                int32_t *l_168 = (void*)0;
                int32_t *l_169 = &g_66[1];
                int32_t *l_170 = &g_66[3];
                int32_t *l_173 = &g_56;
                int32_t *l_175 = &l_174[2][0];
                int32_t *l_176 = (void*)0;
                int32_t *l_177 = &l_174[0][2];
                int32_t *l_178 = (void*)0;
                int32_t *l_179 = &g_56;
                int32_t *l_180[1];
                uint8_t *l_204 = (void*)0;
                uint8_t *l_205 = &g_146;
                int i;
                for (i = 0; i < 1; i++)
                    l_180[i] = (void*)0;
                g_186++;
                if (l_172)
                    continue;
                if (((*l_169) = (p_68 , (l_189 == ((*l_161) = g_190[3])))))
                { /* block id: 57 */
                    uint32_t l_192[5][6][2] = {{{0x9D31CE9DL,4294967294UL},{3UL,0xF7FF8115L},{4294967294UL,0x200A6F42L},{0xBCF3A28AL,0UL},{0x8DDB15D3L,0UL},{0xBCF3A28AL,0x200A6F42L}},{{4294967294UL,0xF7FF8115L},{3UL,4294967294UL},{0x9D31CE9DL,0x05F24046L},{0xF7FF8115L,0UL},{3UL,0x4D2E0C58L},{0UL,0x200A6F42L}},{{0xF009EE3FL,0xF009EE3FL},{0x8DDB15D3L,0xBCF3A28AL},{0UL,0x200A6F42L},{0xAF640DE0L,0x9D31CE9DL},{3UL,0xAF640DE0L},{0x4D2E0C58L,0x05F24046L}},{{0x4D2E0C58L,0xAF640DE0L},{3UL,0x9D31CE9DL},{0xAF640DE0L,0x200A6F42L},{0UL,0xBCF3A28AL},{0x8DDB15D3L,0xF009EE3FL},{0xF009EE3FL,0x200A6F42L}},{{0UL,0x4D2E0C58L},{3UL,0UL},{0xF7FF8115L,0x05F24046L},{0x9D31CE9DL,4294967294UL},{3UL,0xF7FF8115L},{4294967294UL,0x200A6F42L}}};
                    int i, j, k;
                    ++l_192[2][2][0];
                }
                else
                { /* block id: 59 */
                    uint64_t * const l_201 = (void*)0;
                    uint64_t *l_202 = &g_59;
                    uint16_t *l_206 = &g_186;
                    (*l_170) = ((((safe_mod_func_int32_t_s_s_unsafe_macro/*72*//* ___SAFE__OP */(0x8A6F2717L, (*p_69))) && (((safe_mul_func_uint32_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */(g_86, (l_171 == (safe_rshift_func_uint16_t_u_s_unsafe_macro/*74*//* ___SAFE__OP */(p_72.f0, 15))))) < ((((0L == (l_201 == (l_203 = l_202))) != ((*l_206) = ((l_204 = (void*)0) != l_205))) , 1L) , (-1L))) != 252UL)) & l_183[2]) == p_72.f0);
                }
            }
        }
        (*g_207) = &l_161;
    }
    (*l_213) = ((1UL & g_186) , func_79(&l_183[8], ((g_211 = ((*l_209) = (p_72.f0 | 3UL))) , g_212), &l_171, ((*l_213) = &l_182), p_69));
    if ((*p_69))
    { /* block id: 74 */
        (*l_214) &= (*g_65);
    }
    else
    { /* block id: 76 */
        int32_t *l_215 = &g_212;
        uint32_t l_216 = 4294967293UL;
        int64_t *l_226 = &g_86;
        uint64_t **l_227 = &l_157;
        int8_t l_233 = 0x13L;
        uint8_t *****l_235 = &g_208;
        uint64_t *l_236 = (void*)0;
        uint32_t l_237 = 4294967291UL;
        int16_t *l_239[5];
        const uint32_t l_241[5] = {0UL,0UL,0UL,0UL,0UL};
        uint16_t *l_242 = &g_243;
        uint16_t *l_244 = (void*)0;
        uint16_t *l_245[10][6] = {{&g_186,&g_186,(void*)0,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,(void*)0,(void*)0},{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,(void*)0,&g_186,(void*)0,&g_186},{&g_186,(void*)0,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,(void*)0,&g_186,&g_186,(void*)0,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,(void*)0,&g_186}};
        int i, j;
        for (i = 0; i < 5; i++)
            l_239[i] = &l_112;
        (*l_213) = func_79(l_215, g_86, l_215, ((*l_213) = (*l_213)), &g_66[1]);
        (*p_69) = ((l_246 = ((g_186 = ((*l_242) &= (l_216 & (((((g_240[8] ^= (((safe_div_func_int32_t_s_s_unsafe_macro/*75*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_u_unsafe_macro/*76*//* ___SAFE__OP */(((1UL >= (g_238[3][5] = (safe_mul_func_uint8_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */((((*l_226) = (~(*l_215))) , ((*l_215) = (((**l_227) = ((((l_227 != ((((**l_213) ^ ((void*)0 != &g_186)) , (safe_mul_func_int8_t_s_s_unsafe_macro/*79*//* ___SAFE__OP */(((((safe_div_func_uint64_t_u_u_unsafe_macro/*80*//* ___SAFE__OP */(((((((l_232 == l_232) | g_212) , g_16) || (**l_213)) && l_233) != 0x96L), g_186)) | (-6L)) >= 0x539F4849B7B0AB9FLL) | (*l_215)), 0x7FL))) , (void*)0)) >= 1L) , l_234) != l_235)) | 0xD4B51E4AA302B4F1LL))), l_237)), g_149)))) ^ 0xF50514DB471E7E6FLL), 7)), g_210)) != 0x4A86L) ^ g_149)) , l_241[4]) | p_72.f0) , (void*)0) != &g_186)))) <= p_72.f0)) || p_70);
    }
    return p_69;
}


/* ------------------------------------------ */
/* 
 * reads : g_66 g_35.f0 g_16 g_212
 * writes: g_59 g_212
 */
static int32_t * func_79(int32_t * p_80, int8_t  p_81, int32_t * const  p_82, int32_t * p_83, int32_t * const  p_84)
{ /* block id: 21 */
    int32_t *l_94 = &g_66[2];
    uint32_t l_101 = 1UL;
    int64_t *l_106 = &g_86;
    int64_t *l_108[10][1][4] = {{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}},{{&g_86,&g_86,&g_86,&g_86}}};
    int64_t **l_107 = &l_108[2][0][2];
    uint64_t *l_109[3];
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_109[i] = (void*)0;
    (*p_83) ^= ((safe_mul_func_uint32_t_u_u_unsafe_macro/*81*//* ___SAFE__OP */(((p_81 , (safe_mul_func_uint8_t_u_u_unsafe_macro/*82*//* ___SAFE__OP */(((void*)0 != l_94), 0x48L))) , ((safe_lshift_func_int8_t_s_s_unsafe_macro/*83*//* ___SAFE__OP */(g_66[3], (safe_rshift_func_int32_t_s_u_unsafe_macro/*84*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*85*//* ___SAFE__OP */((l_101 || (g_59 = ((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*86*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*87*//* ___SAFE__OP */(g_35.f0, (l_106 != ((*l_107) = l_106)))), 27)) || (*l_94)) || 1L) , 18446744073709551612UL))), (*l_94))), g_16)))) > 7L)), g_35.f0)) || 5L);
    return p_80;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_35.f0, "g_35.f0", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_66[i], "g_66[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_186, "g_186", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_211, "g_211", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_238[i][j], "g_238[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_240[i], "g_240[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_243, "g_243", print_hash_value);
    transparent_crc(g_347, "g_347", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_358[i][j].f0, "g_358[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_398, "g_398", print_hash_value);
    transparent_crc(g_402, "g_402", print_hash_value);
    transparent_crc(g_492, "g_492", print_hash_value);
    transparent_crc(g_571, "g_571", print_hash_value);
    transparent_crc(g_578, "g_578", print_hash_value);
    transparent_crc(g_616, "g_616", print_hash_value);
    transparent_crc(g_653, "g_653", print_hash_value);
    transparent_crc(g_712, "g_712", print_hash_value);
    transparent_crc(g_726, "g_726", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_909[i], "g_909[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_951[i], "g_951[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1021.f0, "g_1021.f0", print_hash_value);
    transparent_crc(g_1034, "g_1034", print_hash_value);
    transparent_crc(g_1052.f0, "g_1052.f0", print_hash_value);
    transparent_crc(g_1064, "g_1064", print_hash_value);
    transparent_crc(g_1190, "g_1190", print_hash_value);
    transparent_crc(g_1354, "g_1354", print_hash_value);
    transparent_crc(g_1471, "g_1471", print_hash_value);
    transparent_crc(g_1482, "g_1482", print_hash_value);
    transparent_crc(g_1496, "g_1496", print_hash_value);
    transparent_crc(g_1545, "g_1545", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1546[i], "g_1546[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1616[i], "g_1616[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1880, "g_1880", print_hash_value);
    transparent_crc(g_1980, "g_1980", print_hash_value);
    transparent_crc(g_2040, "g_2040", print_hash_value);
    transparent_crc(g_2185, "g_2185", print_hash_value);
    transparent_crc(g_2186, "g_2186", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 508
   depth: 1, occurrence: 28
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 107
   depth: 2, occurrence: 29
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 2
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 28, occurrence: 1
   depth: 30, occurrence: 2
   depth: 33, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 646

XXX times a variable address is taken: 1399
XXX times a pointer is dereferenced on RHS: 288
breakdown:
   depth: 1, occurrence: 203
   depth: 2, occurrence: 67
   depth: 3, occurrence: 9
   depth: 4, occurrence: 9
XXX times a pointer is dereferenced on LHS: 301
breakdown:
   depth: 1, occurrence: 279
   depth: 2, occurrence: 17
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 38
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 9
XXX times a pointer is qualified to be dereferenced: 7321

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1055
   level: 2, occurrence: 181
   level: 3, occurrence: 39
   level: 4, occurrence: 52
   level: 5, occurrence: 11
XXX number of pointers point to pointers: 225
XXX number of pointers point to scalars: 391
XXX number of pointers point to structs: 30
XXX percent of pointers has null in alias set: 30.3
XXX average alias set size: 1.5

XXX times a non-volatile is read: 1813
XXX times a non-volatile is write: 853
XXX times a volatile is read: 85
XXX    times read thru a pointer: 9
XXX times a volatile is write: 44
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 1.57e+03
XXX percentage of non-volatile access: 95.4

XXX forward jumps: 2
XXX backward jumps: 10

XXX stmts: 108
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 36
   depth: 1, occurrence: 25
   depth: 2, occurrence: 16
   depth: 3, occurrence: 15
   depth: 4, occurrence: 10
   depth: 5, occurrence: 6

XXX percentage a fresh-made variable is used: 16.9
XXX percentage an existing variable is used: 83.1
********************* end of statistics **********************/

