/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 195724100 --bitfields --packed-struct
 * Seed:      195724100
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int8_t  f0;
};

union U1 {
   volatile unsigned f0 : 29;
   uint32_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_2[10][1][7] = {{{0L,0xAD3380EE91B76E1ELL,0x6BA47C9D5FAC1226LL,1L,(-5L),1L,(-5L)}},{{0L,0x6BA47C9D5FAC1226LL,0x6BA47C9D5FAC1226LL,0L,0L,0x94DDBC3707822E6ELL,1L}},{{0x725D36729694D2B5LL,0x9523DD972C40A98CLL,1L,0x6BA47C9D5FAC1226LL,0x1D102278213AF72BLL,1L,0xEF9A8551B32E2659LL}},{{(-5L),0x2AEE5A9864BA8B35LL,0L,8L,0xAD3380EE91B76E1ELL,(-4L),1L}},{{0x932E3CA3691F6F49LL,0x94DDBC3707822E6ELL,9L,(-4L),0L,(-5L),(-5L)}},{{0x38EB16E2C9BF5E4DLL,(-4L),0xE3EDFA831EB2391CLL,(-4L),0x38EB16E2C9BF5E4DLL,0L,0x9523DD972C40A98CLL}},{{0x6BA47C9D5FAC1226LL,9L,0xEF9A8551B32E2659LL,8L,1L,0x90069F30CC2FDCBALL,0x2AEE5A9864BA8B35LL}},{{0x1D102278213AF72BLL,0x932E3CA3691F6F49LL,0L,(-5L),0xF737A9A971867B8FLL,0xB821342F3D47941CLL,1L}},{{(-5L),0xEF9A8551B32E2659LL,0x38EB16E2C9BF5E4DLL,0L,8L,0x04EE7D214C405B40LL,0xDADE0980DB959C45LL}},{{0x932E3CA3691F6F49LL,8L,0L,0L,8L,0x932E3CA3691F6F49LL,0xB821342F3D47941CLL}}};
static int32_t g_3 = 0x940C9BA5L;
static uint16_t g_61 = 5UL;
static uint32_t g_120 = 4294967289UL;
static int32_t g_130 = 1L;
static int32_t *g_129[3] = {&g_130,&g_130,&g_130};
static int32_t *g_154 = &g_130;
static int32_t **g_153 = &g_154;
static const int64_t g_156 = 0x8D7F9BA6DCB14003LL;
static uint32_t g_158 = 4294967295UL;
static uint64_t g_161 = 18446744073709551614UL;
static uint8_t g_164 = 0UL;
static int64_t g_195 = 9L;
static int32_t g_203[9] = {0x843EB036L,0x122D0340L,0x843EB036L,0x122D0340L,0x843EB036L,0x122D0340L,0x843EB036L,0x122D0340L,0x843EB036L};
static int32_t g_251 = 0x43FE88F4L;
static union U0 g_265 = {0x67L};
static volatile int8_t g_363 = 0x18L;/* VOLATILE GLOBAL g_363 */
static volatile int8_t * const g_362 = &g_363;
static volatile int16_t g_385[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
static volatile int16_t *g_384[1][2] = {{&g_385[2],&g_385[2]}};
static int32_t g_399 = 1L;
static uint16_t g_404 = 2UL;
static union U0 * volatile g_422 = &g_265;/* VOLATILE GLOBAL g_422 */
static union U0 *g_423 = (void*)0;
static union U0 * volatile *g_421[6] = {(void*)0,&g_423,&g_423,(void*)0,&g_423,&g_423};
static union U0 * volatile ** const g_420[4] = {&g_421[1],&g_421[1],&g_421[1],&g_421[1]};
static union U0 g_448 = {-8L};
static union U1 g_479 = {0x11E6578CL};/* VOLATILE GLOBAL g_479 */
static int32_t g_498 = 6L;
static int16_t g_502 = 0x79A6L;
static int16_t *g_501 = &g_502;
static union U1 g_511 = {0UL};/* VOLATILE GLOBAL g_511 */
static union U1 g_512 = {1UL};/* VOLATILE GLOBAL g_512 */
static union U1 g_513 = {0x63BE5066L};/* VOLATILE GLOBAL g_513 */
static union U1 g_514 = {0xD7C3677EL};/* VOLATILE GLOBAL g_514 */
static const int32_t g_517 = 0xC7CB8A28L;
static volatile union U0 * volatile * volatile * volatile * volatile g_543 = (void*)0;/* VOLATILE GLOBAL g_543 */
static volatile union U0 * volatile * volatile * volatile * volatile *g_542 = &g_543;
static int32_t * volatile *g_559 = &g_129[1];
static int32_t * volatile **g_558 = &g_559;
static int32_t * volatile ***g_557 = &g_558;
static int32_t * volatile ****g_556[6][10] = {{&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557},{&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557},{&g_557,&g_557,&g_557,(void*)0,(void*)0,&g_557,&g_557,&g_557,&g_557,&g_557},{&g_557,&g_557,(void*)0,&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,(void*)0},{&g_557,&g_557,(void*)0,&g_557,&g_557,&g_557,(void*)0,&g_557,&g_557,(void*)0},{&g_557,&g_557,&g_557,&g_557,&g_557,&g_557,(void*)0,&g_557,&g_557,&g_557}};
static union U1 g_564 = {4294967293UL};/* VOLATILE GLOBAL g_564 */
static union U1 *g_563 = &g_564;
static union U1 g_567 = {4294967288UL};/* VOLATILE GLOBAL g_567 */
static int32_t ***g_642 = &g_153;
static int32_t ****g_641 = &g_642;
static int32_t *****g_640 = &g_641;
static int32_t *****g_643 = &g_641;
static int32_t *****g_645 = &g_641;
static union U1 g_705 = {0xB88CF2C4L};/* VOLATILE GLOBAL g_705 */
static int16_t g_737 = 0x630FL;
static union U0 **g_746[1][4] = {{&g_423,&g_423,&g_423,&g_423}};
static const uint8_t g_766[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static const uint8_t *g_767 = (void*)0;
static volatile int8_t g_786 = 0xD5L;/* VOLATILE GLOBAL g_786 */
static volatile int8_t *g_785 = &g_786;
static const int8_t g_789 = 1L;
static union U0 ** const ***g_821 = (void*)0;
static uint64_t g_854 = 0x1C6B28B1B04EC839LL;
static uint32_t g_906 = 0UL;
static int64_t g_913 = 1L;
static const uint16_t g_976 = 0x13B2L;
static int8_t g_977[2][7][5] = {{{0x83L,0x26L,0x83L,(-1L),0xC8L},{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0xC8L},{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0xC8L},{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0xC8L}},{{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0xC8L},{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0xC8L},{(-1L),0x5DL,(-1L),(-7L),(-7L)},{0x83L,0x26L,0x83L,(-1L),0x83L},{(-6L),0L,(-6L),(-1L),(-1L)}}};
static int64_t g_1018[2][5][6] = {{{0x5926266087109125LL,0x6DD38303340972A4LL,0x5926266087109125LL,0x847F7EB556E30C1BLL,0x49FEA099B33864E6LL,0x5926266087109125LL},{(-1L),0x8E58CA41C7FE25ABLL,0x847F7EB556E30C1BLL,0L,0x49FEA099B33864E6LL,(-1L)},{0x847F7EB556E30C1BLL,0x6DD38303340972A4LL,0L,0L,0x6DD38303340972A4LL,0x847F7EB556E30C1BLL},{(-1L),0x49FEA099B33864E6LL,0L,0x847F7EB556E30C1BLL,0x8E58CA41C7FE25ABLL,(-1L)},{0x5926266087109125LL,0x49FEA099B33864E6LL,0x847F7EB556E30C1BLL,0x5926266087109125LL,0x6DD38303340972A4LL,0x5926266087109125LL}},{{0x5926266087109125LL,0x6DD38303340972A4LL,0x5926266087109125LL,0x847F7EB556E30C1BLL,0x49FEA099B33864E6LL,0x5926266087109125LL},{(-1L),0x8E58CA41C7FE25ABLL,0x847F7EB556E30C1BLL,0L,0x49FEA099B33864E6LL,(-1L)},{0x847F7EB556E30C1BLL,0x6DD38303340972A4LL,0L,0L,0x6DD38303340972A4LL,0x847F7EB556E30C1BLL},{(-1L),0x49FEA099B33864E6LL,0L,0x847F7EB556E30C1BLL,0x8E58CA41C7FE25ABLL,(-1L)},{0x5926266087109125LL,0x49FEA099B33864E6LL,0x847F7EB556E30C1BLL,0x5926266087109125LL,0x6DD38303340972A4LL,0x5926266087109125LL}}};
static union U0 ***g_1082 = (void*)0;
static union U0 ****g_1081 = &g_1082;
static union U0 *****g_1080 = &g_1081;
static int16_t **g_1122 = &g_501;
static int16_t ***g_1121 = &g_1122;
static int32_t **g_1135 = &g_129[0];
static volatile int64_t g_1197[8] = {0xE6D37725F716043FLL,0x750247497906C6EALL,0xE6D37725F716043FLL,0xE6D37725F716043FLL,0x750247497906C6EALL,0xE6D37725F716043FLL,0xE6D37725F716043FLL,0x750247497906C6EALL};
static volatile int64_t * const  volatile g_1196 = &g_1197[3];/* VOLATILE GLOBAL g_1196 */
static volatile int64_t * const  volatile *g_1195 = &g_1196;
static uint64_t *g_1267 = &g_161;
static uint64_t ** const g_1266 = &g_1267;
static uint64_t ** const *g_1265 = &g_1266;
static uint64_t ** const **g_1264 = &g_1265;
static uint8_t g_1396 = 0UL;
static uint32_t *g_1441[2] = {&g_567.f1,&g_567.f1};
static uint32_t **g_1440 = &g_1441[1];
static uint8_t g_1536[5] = {0x82L,0x82L,0x82L,0x82L,0x82L};
static uint32_t * volatile *g_1639 = (void*)0;
static uint32_t * volatile **g_1638 = &g_1639;
static uint16_t g_1718 = 0xFD2EL;
static const uint8_t g_1726[8][1][1] = {{{255UL}},{{255UL}},{{255UL}},{{255UL}},{{255UL}},{{255UL}},{{255UL}},{{255UL}}};
static const int32_t ****g_1734 = (void*)0;
static const int32_t *****g_1733 = &g_1734;
static int32_t g_1745[7] = {0x173BB2C0L,0x173BB2C0L,0x173BB2C0L,0x173BB2C0L,0x173BB2C0L,0x173BB2C0L,0x173BB2C0L};
static const int16_t * const **g_1754 = (void*)0;
static volatile union U1 g_1767[4][5] = {{{4294967290UL},{0xF288292CL},{4294967290UL},{0UL},{0UL}},{{4294967290UL},{0xF288292CL},{4294967290UL},{0UL},{0UL}},{{4294967290UL},{0xF288292CL},{4294967290UL},{0UL},{0UL}},{{4294967290UL},{0xF288292CL},{4294967290UL},{0UL},{0UL}}};
static volatile union U1 *g_1766 = &g_1767[1][2];
static volatile union U1 **g_1765 = &g_1766;
static volatile union U1 *** volatile g_1764 = &g_1765;/* VOLATILE GLOBAL g_1764 */
static volatile union U1 *** volatile *g_1763 = &g_1764;
static volatile union U1 *** volatile * volatile *g_1762[2] = {&g_1763,&g_1763};
static union U1 g_1775 = {4294967295UL};/* VOLATILE GLOBAL g_1775 */
static union U1 g_1862 = {4294967295UL};/* VOLATILE GLOBAL g_1862 */
static const int16_t * const ***g_1969 = &g_1754;
static union U1 g_2012 = {0xC261EDC3L};/* VOLATILE GLOBAL g_2012 */
static union U1 g_2014 = {4294967286UL};/* VOLATILE GLOBAL g_2014 */
static uint16_t g_2081 = 65529UL;
static uint16_t g_2120 = 0x56E4L;
static int16_t g_2170 = 0L;
static int8_t g_2179 = 0x58L;
static int8_t g_2205 = 0x43L;
static int8_t *g_2221 = &g_977[1][2][1];
static int8_t **g_2220 = &g_2221;
static int16_t g_2272 = 0xB058L;
static uint32_t g_2275 = 0xBF87F316L;
static union U1 ***g_2286 = (void*)0;
static int16_t ** const *g_2323[10][1][3] = {{{&g_1122,&g_1122,&g_1122}},{{(void*)0,(void*)0,&g_1122}},{{&g_1122,&g_1122,&g_1122}},{{(void*)0,(void*)0,&g_1122}},{{&g_1122,&g_1122,&g_1122}},{{(void*)0,(void*)0,&g_1122}},{{&g_1122,&g_1122,&g_1122}},{{(void*)0,(void*)0,&g_1122}},{{&g_1122,&g_1122,&g_1122}},{{(void*)0,(void*)0,&g_1122}}};
static int16_t ** const **g_2322 = &g_2323[0][0][0];
static int16_t ** const ***g_2321 = &g_2322;
static uint32_t g_2353[6] = {4294967292UL,4294967292UL,4294967292UL,4294967292UL,4294967292UL,4294967292UL};
static uint32_t * const g_2352 = &g_2353[1];
static uint32_t * const *g_2351 = &g_2352;
static const int32_t *g_2361 = &g_130;
static union U1 g_2543 = {0UL};/* VOLATILE GLOBAL g_2543 */
static int64_t g_2558[9] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
static uint64_t *g_2650[1][5][8] = {{{&g_854,(void*)0,&g_854,&g_854,(void*)0,&g_854,(void*)0,&g_854},{&g_854,(void*)0,&g_854,&g_854,&g_854,&g_854,(void*)0,&g_854},{&g_854,&g_854,&g_854,&g_854,&g_854,&g_854,&g_854,&g_854},{&g_854,&g_854,&g_854,(void*)0,&g_854,&g_854,&g_854,&g_854},{&g_854,&g_854,&g_854,&g_854,&g_854,&g_854,&g_854,&g_854}}};
static uint64_t g_2768 = 1UL;
static int8_t g_2836 = 0x96L;
static int64_t *g_2878 = &g_913;
static int64_t **g_2877 = &g_2878;
static int64_t * const *g_2906 = &g_2878;
static int64_t * const **g_2905 = &g_2906;
static const int32_t **** const *g_2948 = &g_1734;
static const volatile uint16_t * volatile * volatile g_3028 = (void*)0;/* VOLATILE GLOBAL g_3028 */
static const volatile uint16_t * volatile * volatile * volatile g_3027 = &g_3028;/* VOLATILE GLOBAL g_3027 */
static uint16_t ***g_3033 = (void*)0;
static uint16_t *g_3036 = &g_61;
static uint16_t **g_3035 = &g_3036;
static uint16_t ***g_3034 = &g_3035;
static const int32_t ** volatile g_3122 = &g_2361;/* VOLATILE GLOBAL g_3122 */
static uint64_t g_3145 = 0x6B45798C1AEC895CLL;
static union U1 g_3190 = {0x258639A1L};/* VOLATILE GLOBAL g_3190 */
static int32_t * volatile g_3206 = &g_3;/* VOLATILE GLOBAL g_3206 */
static union U1 g_3252 = {7UL};/* VOLATILE GLOBAL g_3252 */
static int32_t g_3253 = 1L;
static uint8_t *g_3315 = &g_1536[2];
static uint8_t ** volatile g_3314 = &g_3315;/* VOLATILE GLOBAL g_3314 */
static uint8_t ** const  volatile * volatile g_3313[1][6] = {{&g_3314,&g_3314,&g_3314,&g_3314,&g_3314,&g_3314}};
static uint8_t ** const  volatile * volatile * volatile g_3316[3][3] = {{(void*)0,&g_3313[0][0],&g_3313[0][0]},{(void*)0,&g_3313[0][0],&g_3313[0][0]},{(void*)0,&g_3313[0][0],&g_3313[0][0]}};
static volatile union U1 g_3396 = {0x598F0131L};/* VOLATILE GLOBAL g_3396 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const union U1  func_6(uint32_t  p_7, uint16_t  p_8, uint64_t  p_9, uint16_t  p_10);
static uint16_t  func_23(int32_t  p_24, int32_t  p_25);
static int32_t  func_26(uint8_t  p_27, uint8_t  p_28, uint32_t  p_29, int64_t  p_30, int64_t  p_31);
static const int32_t * func_34(int32_t * p_35, int32_t * p_36);
static int32_t * func_37(int16_t  p_38, int32_t * p_39, int32_t * p_40);
static uint32_t  func_57(uint8_t  p_58, int32_t  p_59, int32_t * p_60);
static uint8_t  func_67(int32_t * p_68, uint32_t  p_69, int32_t * p_70, int8_t  p_71);
static int32_t * func_72(int32_t * p_73, int32_t * p_74, int32_t * const  p_75, uint32_t  p_76, int32_t * p_77);
static int32_t * func_78(int8_t  p_79, int32_t * p_80, uint16_t  p_81, int8_t  p_82);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_640 g_641 g_642 g_153 g_154 g_130 g_737 g_766 g_1638 g_1639 g_2906 g_2878 g_913 g_2351 g_2352 g_1763 g_1764 g_1765 g_1766 g_1767 g_2220 g_2221 g_558 g_559 g_129 g_3027 g_3035 g_3036 g_1266 g_1267 g_161 g_501 g_502 g_977 g_2179 g_643 g_2877 g_1264 g_1265 g_1121 g_1122 g_61 g_1396 g_362 g_363 g_2768 g_1767.f0 g_3122 g_1195 g_1196 g_1197 g_2353 g_557 g_785 g_786 g_265.f0 g_2361 g_3145 g_3190 g_2170 g_3206 g_906 g_2275 g_542 g_543 g_1080 g_1081 g_2081 g_3252.f1 g_2905 g_251 g_3396 g_3315 g_1536 g_3314
 * writes: g_3 g_130 g_737 g_1440 g_913 g_2353 g_977 g_3033 g_3034 g_61 g_161 g_2220 g_164 g_1396 g_2768 g_2361 g_502 g_3145 g_906 g_2275 g_2081 g_3252.f1 g_448 g_2179 g_251
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    const int8_t l_22 = (-9L);
    int8_t l_2989 = 4L;
    const int32_t *l_3121 = &g_130;
    int8_t l_3181[8][1][5] = {{{(-3L),1L,(-6L),1L,0xB4L}},{{0x95L,0xE6L,0L,0L,0xE6L}},{{(-3L),1L,(-6L),1L,0xB4L}},{{0x95L,0xE6L,0L,0L,0xE6L}},{{(-3L),1L,(-6L),1L,0xB4L}},{{0x95L,0xE6L,0L,0L,0xE6L}},{{(-3L),1L,(-6L),1L,0xB4L}},{{0x95L,0xE6L,0L,0L,0xE6L}}};
    int32_t l_3211[9][9] = {{0x420DD1E7L,0xFDF89ADAL,0x420DD1E7L,5L,0xBFDC1C50L,8L,1L,1L,0x7BB2B6BCL},{0x0E50CEFAL,4L,0L,9L,0L,0x78E75F86L,0L,9L,0L},{0x7BB2B6BCL,0x7BB2B6BCL,0xFDF89ADAL,5L,0x65439E56L,0x420DD1E7L,0x97647FF4L,0x60C3B524L,0x346983D7L},{9L,0x5F12CB3CL,0x78E75F86L,0x02CE8861L,1L,1L,0x02CE8861L,0x78E75F86L,0x5F12CB3CL},{0xBBEF1D1FL,0xB45802D7L,0xFDF89ADAL,0L,(-1L),5L,0x7BB2B6BCL,0x97647FF4L,0xBFDC1C50L},{9L,9L,0L,0x5F12CB3CL,0x717AFB3BL,0x5F12CB3CL,0L,9L,9L},{(-1L),0xB45802D7L,0x420DD1E7L,0x6EC9577FL,0x7BB2B6BCL,1L,0x346983D7L,0xFDF89ADAL,8L},{0xFFE7A711L,0x5F12CB3CL,6L,0x78E75F86L,0x78E75F86L,6L,0x5F12CB3CL,0xFFE7A711L,0xDEB9AA0EL},{(-1L),0x7BB2B6BCL,0x346983D7L,0x65439E56L,1L,0xBBEF1D1FL,0xBFDC1C50L,0x6EC9577FL,0x6EC9577FL}};
    uint32_t l_3212 = 9UL;
    uint32_t l_3230 = 0x93434A13L;
    uint32_t l_3233 = 1UL;
    uint64_t l_3275 = 0x8F0D535DBB90586CLL;
    union U0 l_3300[5] = {{0xFCL},{0xFCL},{0xFCL},{0xFCL},{0xFCL}};
    int32_t l_3354 = 0xEE298CFFL;
    uint64_t **l_3358 = &g_2650[0][1][7];
    uint64_t l_3373 = 0x84B16994BC63FB67LL;
    uint32_t l_3393 = 18446744073709551612UL;
    uint32_t l_3411 = 0x93F2A7B8L;
    int i, j, k;
    if (g_2[8][0][2])
    { /* block id: 1 */
        uint16_t l_32[7] = {65528UL,0xACDDL,0xACDDL,65528UL,0xACDDL,0xACDDL,65528UL};
        const int64_t l_33 = 0xFF7828E972CE3C48LL;
        uint32_t l_3008[8];
        int i;
        for (i = 0; i < 8; i++)
            l_3008[i] = 0x9C34BD3CL;
        for (g_3 = (-22); (g_3 == (-30)); g_3 = safe_sub_func_uint32_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */(g_3, 8))
        { /* block id: 4 */
            int64_t l_17[5] = {0x9405DBD55ADB51FDLL,0x9405DBD55ADB51FDLL,0x9405DBD55ADB51FDLL,0x9405DBD55ADB51FDLL,0x9405DBD55ADB51FDLL};
            uint16_t l_2987 = 0xA8F7L;
            int64_t l_2988 = 0x3D8D093351DB4E3FLL;
            uint32_t l_3007 = 4294967295UL;
            int i;
            (*g_154) = (func_6((safe_lshift_func_int64_t_s_u_unsafe_macro/*1*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(g_2[8][0][2], (safe_div_func_int64_t_s_s_unsafe_macro/*3*//* ___SAFE__OP */((l_17[4] == (safe_sub_func_uint8_t_u_u_unsafe_macro/*4*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */(9UL, ((((l_22 , (1UL == (func_23(func_26(l_32[3], (((l_32[3] == g_3) != l_33) , 0xF1L), g_3, l_33, l_32[3]), l_17[4]) , l_22))) != l_22) >= l_2987) >= 0UL))), 255UL))), l_2988)))), l_2989)), l_22, l_22, g_766[6]) , l_3007);
        }
        l_3008[7]++;
    }
    else
    { /* block id: 1325 */
        uint16_t *l_3031[9] = {&g_404,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404};
        uint16_t **l_3030 = &l_3031[6];
        uint16_t ***l_3029[9] = {&l_3030,&l_3030,&l_3030,&l_3030,&l_3030,&l_3030,&l_3030,&l_3030,&l_3030};
        uint16_t ****l_3032[9][7] = {{(void*)0,&l_3029[6],&l_3029[7],&l_3029[2],&l_3029[8],&l_3029[7],&l_3029[8]},{&l_3029[6],&l_3029[7],&l_3029[7],&l_3029[6],&l_3029[7],&l_3029[4],(void*)0},{&l_3029[0],&l_3029[8],&l_3029[4],(void*)0,&l_3029[1],&l_3029[7],(void*)0},{(void*)0,&l_3029[7],&l_3029[7],&l_3029[7],(void*)0,&l_3029[7],(void*)0},{&l_3029[7],&l_3029[7],&l_3029[7],&l_3029[7],&l_3029[7],&l_3029[8],(void*)0},{(void*)0,&l_3029[4],&l_3029[7],&l_3029[2],&l_3029[7],&l_3029[4],(void*)0},{(void*)0,&l_3029[7],&l_3029[7],&l_3029[6],(void*)0,&l_3029[2],&l_3029[7]},{&l_3029[7],&l_3029[7],&l_3029[7],(void*)0,&l_3029[1],&l_3029[7],&l_3029[2]},{&l_3029[7],(void*)0,&l_3029[7],&l_3029[7],&l_3029[7],(void*)0,&l_3029[4]}};
        int32_t l_3037 = 0L;
        uint64_t l_3065 = 18446744073709551615UL;
        uint64_t l_3067 = 18446744073709551611UL;
        int64_t *l_3070[7][2][4] = {{{&g_1018[0][2][0],&g_1018[0][1][0],&g_1018[0][1][0],&g_1018[0][2][0]},{&g_1018[0][2][0],&g_2558[6],&g_1018[1][0][4],(void*)0}},{{&g_913,&g_1018[0][2][0],&g_1018[1][4][5],&g_2558[8]},{&g_195,(void*)0,&g_195,&g_2558[8]}},{{&g_1018[1][4][5],&g_1018[0][2][0],&g_913,(void*)0},{&g_1018[1][0][4],&g_2558[6],&g_1018[0][2][0],&g_1018[0][2][0]}},{{&g_1018[0][1][0],&g_1018[0][1][0],&g_1018[0][2][0],&g_195},{&g_1018[1][0][4],&g_913,&g_913,&g_2558[6]}},{{&g_1018[1][4][5],&g_913,&g_195,&g_913},{&g_195,&g_913,&g_1018[1][4][5],&g_2558[6]}},{{&g_913,&g_913,&g_1018[1][0][4],&g_195},{&g_1018[0][2][0],&g_1018[0][1][0],&g_1018[0][1][0],&g_1018[0][2][0]}},{{&g_1018[0][2][0],&g_2558[6],&g_1018[1][0][4],(void*)0},{&g_913,&g_1018[0][2][0],&g_1018[1][4][5],&g_2558[8]}}};
        const int8_t **l_3071 = (void*)0;
        int8_t **l_3074 = &g_2221;
        int16_t l_3118 = (-1L);
        uint64_t **l_3139 = &g_2650[0][0][3];
        uint64_t *** const l_3138 = &l_3139;
        uint32_t **l_3147 = &g_1441[1];
        union U1 *l_3149 = &g_1862;
        uint16_t l_3166 = 0UL;
        int16_t ****l_3183 = &g_1121;
        int16_t *****l_3182[8][8][3] = {{{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183}},{{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,(void*)0},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183},{&l_3183,&l_3183,&l_3183}}};
        uint32_t l_3204 = 0xBBF61F44L;
        int32_t l_3210 = 0x61987B6EL;
        uint16_t l_3299[1];
        union U0 *l_3378 = &g_448;
        int8_t *l_3389 = &g_2179;
        int32_t *l_3390 = &l_3211[0][6];
        int32_t *l_3410[2];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_3299[i] = 0xA11EL;
        for (i = 0; i < 2; i++)
            l_3410[i] = &l_3037;
        if ((safe_rshift_func_int8_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */((((((**g_2220) = 0x75L) < (!(***g_558))) == (safe_add_func_uint32_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*8*//* ___SAFE__OP */(l_2989, l_2989)), ((**g_2351) = 0xB0AB7AFCL)))) , (safe_add_func_uint16_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */(((**g_3035) = (safe_div_func_int32_t_s_s_unsafe_macro/*10*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*11*//* ___SAFE__OP */(((!(((*****g_640) = (g_3027 != (g_3034 = (g_3033 = l_3029[7])))) && l_22)) > l_3037), 28)), l_2989))), l_22))), l_2989)))
        { /* block id: 1332 */
            uint8_t l_3040 = 255UL;
            union U1 ** const l_3046 = &g_563;
            int8_t ***l_3063 = (void*)0;
            uint32_t l_3064[2];
            int32_t l_3066[4][6] = {{0xDA212C7FL,1L,1L,0xDA212C7FL,0x17BE4C0CL,0xDA212C7FL},{0xDA212C7FL,0x17BE4C0CL,0xDA212C7FL,1L,1L,0xDA212C7FL},{0xE6EFE7C0L,0xE6EFE7C0L,1L,0x444FF723L,1L,0xE6EFE7C0L},{1L,0x17BE4C0CL,0x444FF723L,0x444FF723L,0x17BE4C0CL,1L}};
            const int8_t ***l_3072 = &l_3071;
            int8_t ***l_3073[9][4] = {{(void*)0,&g_2220,(void*)0,&g_2220},{&g_2220,&g_2220,&g_2220,&g_2220},{&g_2220,&g_2220,&g_2220,&g_2220},{&g_2220,&g_2220,&g_2220,&g_2220},{&g_2220,(void*)0,&g_2220,&g_2220},{&g_2220,(void*)0,(void*)0,&g_2220},{(void*)0,&g_2220,&g_2220,&g_2220},{(void*)0,&g_2220,(void*)0,&g_2220},{&g_2220,&g_2220,&g_2220,&g_2220}};
            uint8_t *l_3089 = (void*)0;
            uint8_t *l_3090 = &g_1396;
            uint8_t *l_3091 = &g_164;
            uint32_t l_3092 = 0x0526E408L;
            int8_t l_3093 = 1L;
            int32_t l_3114 = (-1L);
            union U0 *l_3123 = &g_265;
            uint64_t ** const *l_3140 = &l_3139;
            int32_t *l_3207 = &l_3114;
            int32_t *l_3208 = &l_3114;
            int32_t *l_3209[4];
            int i, j;
            for (i = 0; i < 2; i++)
                l_3064[i] = 0x65D23323L;
            for (i = 0; i < 4; i++)
                l_3209[i] = &g_130;
lbl_3096:
            l_3067 = (((((safe_add_func_int8_t_s_s_unsafe_macro/*12*//* ___SAFE__OP */(l_22, (l_3040 > (safe_unary_minus_func_int8_t_s_unsafe_macro/*13*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u_unsafe_macro/*14*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*15*//* ___SAFE__OP */(((**g_1266) ^= ((void*)0 != l_3046)), (safe_mod_func_int32_t_s_s_unsafe_macro/*16*//* ___SAFE__OP */((!(safe_mod_func_int8_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */((0x44F7A022L <= (((g_164 = (safe_sub_func_int8_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */(((*g_501) != ((safe_add_func_int32_t_s_s_unsafe_macro/*20*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */((((safe_mod_func_int8_t_s_s_unsafe_macro/*22*//* ___SAFE__OP */(l_3037, ((*g_2221) |= (+(((g_2220 = (void*)0) != &g_2221) , l_3037))))) >= l_3064[0]) > l_3065), l_2989)), l_3064[0])) | l_3064[0])), 0xD9L))) <= g_2179) <= (*****g_640))), 10)), l_2989))), l_3037)))), l_22)) | l_22)))))) && (*****g_643)) || l_2989) || l_3064[0]) > l_3066[2][5]);
            (*****g_640) = (safe_mod_func_int32_t_s_s_unsafe_macro/*23*//* ___SAFE__OP */((l_3070[4][0][0] == (*g_2877)), ((((((((*l_3072) = l_3071) == (l_3074 = &g_2221)) || ((*g_2221) = ((((((((!(safe_rshift_func_int8_t_s_u_unsafe_macro/*24*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */(l_2989, ((((safe_lshift_func_int16_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */(((***g_558) | (!((*l_3091) = ((*l_3090) ^= ((****g_1264) , (((safe_sub_func_uint8_t_u_u_unsafe_macro/*27*//* ___SAFE__OP */((((safe_div_func_int16_t_s_s_unsafe_macro/*28*//* ___SAFE__OP */((l_3037 < (safe_rshift_func_int8_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */(1L, 5))), l_2989)) >= (***g_1121)) , 255UL), g_61)) && l_3040) < 0xBF70L)))))), l_3066[2][5])) ^ l_2989) >= 0x95D4L) & l_3066[3][5]))), l_3092))) , (*g_2221)) >= (*g_362)) != l_3093) >= 0L) , (*g_3036)) == (***g_1121)) , (-1L)))) && l_2989) , l_2989) , l_22) & l_3040)));
            for (g_161 = 0; (g_161 >= 41); g_161++)
            { /* block id: 1346 */
                int64_t l_3097[4][6] = {{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)},{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)},{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)},{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)}};
                const union U0 l_3106 = {-1L};
                uint64_t *l_3115 = &g_2768;
                int8_t * const **l_3130 = (void*)0;
                int i, j;
                if (g_1396)
                    goto lbl_3096;
                if ((l_3097[1][3] , (l_3067 == ((safe_lshift_func_int32_t_s_u_unsafe_macro/*30*//* ___SAFE__OP */(((safe_div_func_uint8_t_u_u_unsafe_macro/*31*//* ___SAFE__OP */(((safe_mod_func_int32_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */(l_3065, (l_3114 &= (safe_div_func_uint32_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((l_3067 , (l_3106 , ((safe_mul_func_int16_t_s_s_unsafe_macro/*34*//* ___SAFE__OP */(((safe_unary_minus_func_uint32_t_u_unsafe_macro/*35*//* ___SAFE__OP */(((*g_2352) = ((((safe_lshift_func_int64_t_s_u_unsafe_macro/*36*//* ___SAFE__OP */((((safe_lshift_func_uint8_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */(((--(*l_3115)) && ((**g_2906) = (l_3106.f0 , (l_3118 = 1L)))), (l_3067 && ((safe_rshift_func_int16_t_s_u_unsafe_macro/*38*//* ___SAFE__OP */((***g_1121), l_3097[2][1])) | 1UL)))) != l_3065) != (-1L)), (***g_1265))) || g_1767[1][2].f0) && (*g_2221)) & l_3040)))) ^ 1UL), (*g_3036))) | l_3067))), (*****g_643)))))) , 0xFBL), l_3065)) < 0xA90DL), 2)) , l_3037))))
                { /* block id: 1353 */
                    const int16_t l_3144[10][9] = {{3L,3L,1L,3L,3L,1L,3L,3L,1L},{(-9L),0L,(-1L),0L,(-9L),5L,(-9L),0L,(-1L)},{3L,3L,1L,3L,3L,1L,3L,3L,1L},{(-9L),0L,(-1L),0L,(-9L),5L,(-9L),0L,(-1L)},{3L,3L,1L,3L,3L,1L,3L,3L,1L},{(-9L),0L,(-1L),0L,(-9L),5L,(-9L),0L,(-1L)},{3L,3L,1L,3L,3L,1L,3L,3L,1L},{(-9L),0L,(-1L),0L,(-9L),5L,(-9L),0L,(-1L)},{3L,3L,1L,3L,3L,1L,3L,3L,1L},{(-9L),0L,(-1L),0L,(-9L),5L,(-9L),0L,(-1L)}};
                    int32_t l_3150 = 1L;
                    int i, j;
                    (*g_3122) = l_3121;
                    if (((void*)0 != l_3123))
                    { /* block id: 1355 */
                        int8_t ***l_3131 = (void*)0;
                        int32_t l_3141 = 0L;
                        int32_t l_3142 = 1L;
                        int32_t l_3143 = 0xCF272A2AL;
                        int32_t *l_3146 = &g_3;
                        union U1 *l_3148 = &g_512;
                        (*l_3146) |= (safe_rshift_func_int32_t_s_u_unsafe_macro/*39*//* ___SAFE__OP */(((g_3145 = ((((safe_mod_func_uint16_t_u_u_unsafe_macro/*40*//* ___SAFE__OP */(((safe_lshift_func_int8_t_s_s_unsafe_macro/*41*//* ___SAFE__OP */((((*g_3036) || (l_3143 |= (((l_3130 != l_3131) , ((((**g_1122) = (*g_501)) < (-8L)) > (safe_sub_func_uint64_t_u_u_unsafe_macro/*42*//* ___SAFE__OP */(((((((((*g_3036) = 0UL) >= (((safe_lshift_func_uint64_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((*l_3121), (safe_sub_func_uint32_t_u_u_unsafe_macro/*44*//* ___SAFE__OP */(((l_3118 , (l_3138 == l_3140)) & (**g_1195)), 0xED9287F1L)))) & (**g_2877)) <= l_3037)) || (**g_1266)) && l_3067) , l_3141) | (*g_154)) , l_3142), (**g_2906))))) ^ g_977[1][6][1]))) == g_2353[4]), l_3118)) >= l_3144[3][6]), (*l_3121))) != l_3142) , l_3106.f0) ^ l_3097[2][1])) == 0x01L), l_3144[3][6]));
                        l_3149 = (((*g_1638) != l_3147) , l_3148);
                        if (l_3066[2][5])
                            break;
                    }
                    else
                    { /* block id: 1363 */
                        l_3150 ^= (****g_557);
                        if (g_2768)
                            goto lbl_3096;
                    }
                    l_3150 ^= ((((safe_unary_minus_func_uint64_t_u_unsafe_macro/*45*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */(l_3097[1][0], (&g_2351 == (void*)0))), (-1L))))) < l_3097[3][3]) < (6UL ^ ((safe_mul_func_uint32_t_u_u_unsafe_macro/*48*//* ___SAFE__OP */(0xA14DFC62L, (safe_lshift_func_uint16_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */(((!(safe_unary_minus_func_uint8_t_u_unsafe_macro/*50*//* ___SAFE__OP */((l_3037 <= ((((*g_3036) = (((***g_558) = ((((safe_add_func_uint8_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */(l_3144[3][6], 0x3BL)), (*g_785))) && l_3166) , 0x67L) && l_3064[0])) < 0x77D1E07CL)) < l_3114) , 0L))))) >= 0x15C56291151A5E2CLL), 9)))) != g_265.f0))) & 18446744073709551615UL);
                }
                else
                { /* block id: 1370 */
                    int16_t l_3178 = (-9L);
                    (****g_641) = (*g_2361);
                    for (g_3145 = 0; (g_3145 <= 0); g_3145 += 1)
                    { /* block id: 1374 */
                        int8_t l_3177 = 0L;
                        int32_t *l_3184 = &g_3;
                    }
                    if (l_3178)
                    { /* block id: 1378 */
                        (****g_641) ^= 0x2F37D2A0L;
                    }
                    else
                    { /* block id: 1380 */
                        union U0 l_3189 = {0xAAL};
                        int32_t l_3205 = 0x11945622L;
                        if (l_3178)
                            break;
                        (*g_3206) = (l_3205 = (safe_sub_func_int8_t_s_s_unsafe_macro/*53*//* ___SAFE__OP */((((safe_lshift_func_int64_t_s_s_unsafe_macro/*54*//* ___SAFE__OP */((l_3189 , (g_3190 , (safe_rshift_func_uint32_t_u_u_unsafe_macro/*55*//* ___SAFE__OP */(l_3106.f0, 24)))), (l_3065 <= ((l_3204 = ((((**g_153) |= ((safe_mul_func_int32_t_s_s_unsafe_macro/*56*//* ___SAFE__OP */(0x43BC9C02L, (safe_add_func_uint16_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*58*//* ___SAFE__OP */(((*g_3036) &= (!(safe_rshift_func_int8_t_s_s_unsafe_macro/*59*//* ___SAFE__OP */(0xF5L, 1)))), 0xED82L)), ((*g_2352) ^ (*g_2352)))))) == l_3178)) <= l_3097[3][1]) != (*g_1267))) != g_2170)))) , l_3189.f0) & l_3114), 9L)));
                        if ((*****g_643))
                            continue;
                    }
                }
                return g_1197[1];
            }
            l_3212--;
        }
        else
        { /* block id: 1393 */
            int32_t l_3219 = (-3L);
            uint32_t *l_3234 = &g_906;
            int32_t l_3235 = 0x963F5C65L;
            int16_t l_3286 = 0x4F07L;
            uint32_t l_3290 = 1UL;
            int64_t ***l_3295 = &g_2877;
            uint32_t l_3303 = 0UL;
            int32_t l_3353 = 0xAEBA97C5L;
            int32_t l_3355 = 0x61638B75L;
            int32_t *l_3372[2][3] = {{&l_3235,&l_3235,&l_3235},{&l_3211[0][6],&l_3211[0][6],&l_3211[0][6]}};
            int i, j;
            l_3235 ^= (((safe_lshift_func_uint64_t_u_s_unsafe_macro/*60*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_s_unsafe_macro/*61*//* ___SAFE__OP */((l_3219 & ((safe_sub_func_int16_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */((&l_3149 == (*g_1764)), (((*l_3234) &= ((safe_rshift_func_int64_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u_unsafe_macro/*64*//* ___SAFE__OP */(l_3037, (safe_mul_func_int32_t_s_s_unsafe_macro/*65*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*66*//* ___SAFE__OP */(l_3230, ((safe_sub_func_int16_t_s_s_unsafe_macro/*67*//* ___SAFE__OP */(l_3166, (*g_3036))) , (**g_3035)))), 0x96ACAB21L)))) <= (**g_559)) | l_3219), (*l_3121))) , l_3233)) , (-1L)))) , 0UL)), (**g_1122))) != l_3219), (**g_2906))) | 8L) == (*g_2352));
            for (g_2275 = 0; (g_2275 <= 0); g_2275 += 1)
            { /* block id: 1398 */
                union U0 l_3247 = {0x2FL};
                int64_t *l_3285 = &g_1018[0][3][5];
                int32_t ****l_3287[6][9][3] = {{{&g_642,&g_642,&g_642},{&g_642,&g_642,(void*)0},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,(void*)0,&g_642},{&g_642,&g_642,&g_642}},{{&g_642,&g_642,(void*)0},{&g_642,&g_642,&g_642},{(void*)0,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{(void*)0,(void*)0,&g_642},{&g_642,&g_642,(void*)0},{&g_642,&g_642,&g_642}},{{&g_642,&g_642,&g_642},{(void*)0,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,(void*)0},{&g_642,&g_642,&g_642},{(void*)0,(void*)0,(void*)0},{&g_642,&g_642,&g_642},{&g_642,(void*)0,&g_642},{&g_642,&g_642,&g_642}},{{&g_642,&g_642,&g_642},{&g_642,&g_642,(void*)0},{&g_642,(void*)0,&g_642},{&g_642,&g_642,&g_642},{&g_642,(void*)0,(void*)0},{&g_642,(void*)0,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642}},{{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{(void*)0,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642}},{{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{(void*)0,&g_642,(void*)0},{&g_642,&g_642,&g_642},{(void*)0,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{&g_642,&g_642,&g_642},{(void*)0,&g_642,&g_642}}};
                int8_t l_3311 = 0x0CL;
                int32_t l_3337 = 0x510BFCCAL;
                int i, j, k;
                for (l_3219 = 0; (l_3219 <= 0); l_3219 += 1)
                { /* block id: 1401 */
                    const uint32_t l_3236 = 4294967295UL;
                    int32_t l_3282 = 0xBE7D7530L;
                    uint8_t *l_3298 = &g_1536[2];
                    uint8_t ** const  volatile * volatile l_3319[2][5][2] = {{{&g_3314,(void*)0},{&g_3314,(void*)0},{&g_3314,(void*)0},{(void*)0,&g_3314},{(void*)0,&g_3314}},{{(void*)0,&g_3314},{(void*)0,(void*)0},{&g_3314,(void*)0},{&g_3314,(void*)0},{&g_3314,(void*)0}}};
                    int i, j, k;
                }
                for (g_2081 = 0; (g_2081 <= 0); g_2081 += 1)
                { /* block id: 1447 */
                    uint8_t l_3352 = 0xEEL;
                    int8_t ***l_3356 = (void*)0;
                    int8_t ***l_3357 = &l_3074;
                    uint64_t l_3368[5];
                    uint64_t l_3369 = 1UL;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_3368[i] = 0x1B5886AAA1F966AELL;
                    (**g_153) = (((safe_lshift_func_int8_t_s_s_unsafe_macro/*68*//* ___SAFE__OP */(l_3118, 5)) | 0x39E8L) == (safe_mod_func_int32_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*70*//* ___SAFE__OP */((***g_1121), l_3235)), (safe_lshift_func_int64_t_s_u_unsafe_macro/*71*//* ___SAFE__OP */((((*l_3357) = (((l_3355 = (l_3354 = (((((***g_1121) | (safe_lshift_func_uint64_t_u_s_unsafe_macro/*72*//* ___SAFE__OP */((**g_1266), (safe_div_func_uint16_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*74*//* ___SAFE__OP */(l_3352, (((***l_3295) ^= (((l_3211[1][8] = (l_3210 = ((*g_2352) , (l_3353 &= l_3299[0])))) , (**g_2220)) < (*l_3121))) || 0x0B71DD49C8D0DBC3LL))) && (*g_2352)), (**g_3035)))))) == (*l_3121)) < l_3299[0]) <= (***g_1121)))) >= (*g_2361)) , &g_2221)) == (void*)0), 42)))));
                    (*l_3138) = l_3358;
                    for (g_3252.f1 = 0; (g_3252.f1 <= 0); g_3252.f1 += 1)
                    { /* block id: 1459 */
                        int16_t * const * const l_3370[4] = {&g_501,&g_501,&g_501,&g_501};
                        int32_t l_3371 = (-1L);
                        int i, j, k;
                        (****g_641) = (func_6((safe_mod_func_int16_t_s_s_unsafe_macro/*75*//* ___SAFE__OP */(((~(+((*g_1196) && ((((((safe_unary_minus_func_uint32_t_u_unsafe_macro/*76*//* ___SAFE__OP */(l_3352)) , (*g_542)) == (*g_1080)) == (*g_2221)) , (-10L)) || (((safe_mul_func_uint16_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*78*//* ___SAFE__OP */(((*g_2221) = (l_3368[2] > l_3369)), ((l_3370[3] == (void*)0) >= l_3299[0]))), (**g_1122))) <= (-1L)) >= l_3371))))) || (-1L)), l_3371)), (**g_3035), l_3235, l_3303) , (*l_3121));
                    }
                }
            }
            ++l_3373;
        }
        (*l_3390) &= (((void*)0 != &l_3230) ^ (safe_add_func_int8_t_s_s_unsafe_macro/*79*//* ___SAFE__OP */(((*g_1764) == &l_3149), ((*l_3389) = ((*g_2221) = ((((*l_3378) = l_3300[0]) , ((((**g_1122) = (safe_div_func_int16_t_s_s_unsafe_macro/*80*//* ___SAFE__OP */((((safe_add_func_int32_t_s_s_unsafe_macro/*81*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*82*//* ___SAFE__OP */((***g_2905), (safe_rshift_func_int64_t_s_s_unsafe_macro/*83*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*84*//* ___SAFE__OP */((-3L), 0x60L)), 57)))), (*l_3121))) , 1UL) < l_3118), (*l_3121)))) ^ (*l_3121)) | 0x3C9E438DL)) <= (****g_1264)))))));
        for (g_251 = 0; (g_251 == 12); g_251 = safe_add_func_int16_t_s_s_unsafe_macro/*85*//* ___SAFE__OP */(g_251, 1))
        { /* block id: 1474 */
            const uint32_t l_3409 = 9UL;
            l_3037 |= (l_3393 >= ((safe_mod_func_uint64_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(((((g_3396 , (((safe_lshift_func_int16_t_s_u_unsafe_macro/*87*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*88*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*89*//* ___SAFE__OP */((l_3210 &= ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*90*//* ___SAFE__OP */((*l_3121), (safe_mod_func_int32_t_s_s_unsafe_macro/*91*//* ___SAFE__OP */((*l_3121), ((**g_1765) , 0x4EB5FA3DL))))) >= ((safe_mul_func_uint8_t_u_u_unsafe_macro/*92*//* ___SAFE__OP */((*g_3315), (((((*g_3036) , (****g_1264)) , l_3409) , (*l_3390)) ^ l_3409))) == 0x0B1CL))), (***g_1121))), (*g_1267))), (*l_3121))) != (*l_3390)) < 6UL)) , (***g_1265)) ^ (-7L)) && (*l_3121)), (****g_1264))) , (*l_3390)));
        }
        l_3411++;
    }
    return (**g_3314);
}


/* ------------------------------------------ */
/* 
 * reads : g_1638 g_1639 g_2906 g_2878 g_913 g_2351 g_2352 g_641 g_642 g_153 g_154 g_130 g_1763 g_1764 g_1765 g_1766 g_1767
 * writes: g_1440 g_913 g_2353 g_130
 */
static const union U1  func_6(uint32_t  p_7, uint16_t  p_8, uint64_t  p_9, uint16_t  p_10)
{ /* block id: 1314 */
    uint32_t ***l_2996 = &g_1440;
    union U0 l_2997 = {-6L};
    uint32_t l_3004 = 1UL;
    int16_t ****l_3006[9] = {&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121};
    int16_t *****l_3005 = &l_3006[0];
    int i;
    (****g_641) &= (safe_lshift_func_uint16_t_u_s_unsafe_macro/*93*//* ___SAFE__OP */((((((((**g_2351) = ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*94*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */((((p_9 & (((((((*l_2996) = &g_1441[0]) == (*g_1638)) == (((**g_2906) &= (-1L)) || ((p_10 = 0xD285L) , 0UL))) | 0x3DD7L) && (l_2997 , (safe_add_func_uint16_t_u_u_unsafe_macro/*96*//* ___SAFE__OP */((p_10 = (safe_add_func_int16_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(2L, 255UL)), l_3004))), (-10L))))) >= l_2997.f0)) , &l_2996) == &g_1638), p_8)), l_3004)) < l_3004)) & 0x9D025F4AL) , &g_1969) == l_3005) , (void*)0) == (void*)0), p_7));
    return (****g_1763);
}


/* ------------------------------------------ */
/* 
 * reads : g_640 g_641 g_642 g_153 g_154 g_130 g_737
 * writes: g_130 g_737
 */
static uint16_t  func_23(int32_t  p_24, int32_t  p_25)
{ /* block id: 1164 */
    const uint64_t l_2632 = 0xC16551BBD46DA708LL;
    int32_t l_2658 = 0xF12FD122L;
    int16_t l_2712 = (-1L);
    int32_t l_2760 = 0x3ADB481DL;
    int32_t l_2761 = 0L;
    int32_t l_2763[8] = {5L,2L,5L,2L,5L,2L,5L,2L};
    union U1 * const *l_2781 = &g_563;
    union U1 * const **l_2780 = &l_2781;
    union U1 * const ***l_2779 = &l_2780;
    union U0 l_2868[6][9] = {{{1L},{-1L},{1L},{1L},{-1L},{1L},{1L},{-1L},{1L}},{{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L}},{{1L},{-1L},{1L},{1L},{-1L},{1L},{1L},{-1L},{1L}},{{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L}},{{1L},{-1L},{1L},{1L},{-1L},{1L},{1L},{-1L},{1L}},{{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L},{0x22L},{-1L},{0x22L}}};
    uint64_t l_2938 = 0x4052FC45906B6DA3LL;
    int i, j;
    (*****g_640) ^= (l_2632 || p_24);
    for (g_737 = (-13); (g_737 < (-18)); g_737 = safe_sub_func_int16_t_s_s_unsafe_macro/*99*//* ___SAFE__OP */(g_737, 1))
    { /* block id: 1168 */
        int32_t l_2642 = 0xD832C665L;
        int32_t l_2653[6] = {0x643829F9L,1L,0x643829F9L,0x643829F9L,1L,0x643829F9L};
        uint16_t l_2771 = 8UL;
        const union U0 *l_2789 = (void*)0;
        const union U0 **l_2788 = &l_2789;
        int32_t ** const *l_2812 = (void*)0;
        int16_t l_2870 = (-4L);
        int64_t l_2926 = 2L;
        const int32_t **** const *l_2947 = (void*)0;
        uint32_t *****l_2950 = (void*)0;
        uint32_t l_2966[6][4][1] = {{{5UL},{0x9545F96EL},{0UL},{4294967295UL}},{{0UL},{0x9545F96EL},{5UL},{0x9545F96EL}},{{0UL},{4294967295UL},{0UL},{0x9545F96EL}},{{5UL},{0x9545F96EL},{0UL},{4294967295UL}},{{5UL},{4294967295UL},{0xA73E5098L},{4294967295UL}},{{5UL},{4294967295UL},{5UL},{4294967295UL}}};
        int32_t l_2982 = (-1L);
        int64_t l_2983 = 0x6D8E25325D00F02FLL;
        int i, j, k;
    }
    return p_25;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_26(uint8_t  p_27, uint8_t  p_28, uint32_t  p_29, int64_t  p_30, int64_t  p_31)
{ /* block id: 5 */
    int32_t l_45 = (-1L);
    int32_t *l_56[2];
    int32_t *l_62 = (void*)0;
    const int32_t **l_2358 = (void*)0;
    const int32_t *l_2360[4][3] = {{&g_517,&g_3,&g_517},{&g_3,&g_517,&g_3},{&g_517,&g_3,&g_517},{&g_3,&g_517,&g_3}};
    const int32_t **l_2359[4];
    uint32_t l_2426 = 18446744073709551608UL;
    int32_t l_2479 = 1L;
    uint16_t l_2481[9][10][2] = {{{0xA898L,0xC56DL},{1UL,0x0788L},{1UL,2UL},{0xFBA0L,0x0788L},{1UL,0xC56DL},{0xF8DDL,0xC2B9L},{65533UL,0xC2B9L},{0xF8DDL,0xC56DL},{1UL,0x0788L},{0xFBA0L,2UL}},{{1UL,0x0788L},{1UL,0xC56DL},{0xA898L,0xC2B9L},{65535UL,0xC2B9L},{0xA898L,0xC56DL},{1UL,0x0788L},{1UL,2UL},{0xFBA0L,0x0788L},{1UL,0xC56DL},{0xF8DDL,0xC2B9L}},{{65533UL,0xC2B9L},{0xF8DDL,0xC56DL},{1UL,0x0788L},{0xFBA0L,2UL},{1UL,0x0788L},{1UL,0xC56DL},{0xA898L,0xC2B9L},{65535UL,0xC2B9L},{0xA898L,0xC56DL},{1UL,0x0788L}},{{1UL,2UL},{0xFBA0L,0x0788L},{1UL,0xC56DL},{0xF8DDL,0xC2B9L},{65533UL,0xC2B9L},{0xF8DDL,0xC56DL},{1UL,0x0788L},{0xFBA0L,2UL},{1UL,0x0788L},{1UL,0xC56DL}},{{0xA898L,0xC2B9L},{65535UL,0xC2B9L},{0xA898L,0xC56DL},{1UL,0x0788L},{1UL,2UL},{0xFBA0L,0x0788L},{1UL,0xC56DL},{0xF8DDL,0xC2B9L},{65533UL,0xC2B9L},{0xF8DDL,0xC56DL}},{{1UL,0x0788L},{0xFBA0L,2UL},{1UL,0x0788L},{1UL,0xC56DL},{0xA898L,0xC2B9L},{65535UL,0xC2B9L},{0xA898L,0xC56DL},{1UL,0x0788L},{1UL,2UL},{0xFBA0L,0x0788L}},{{1UL,0xC56DL},{0xF8DDL,0xC2B9L},{65533UL,0xC2B9L},{0xF8DDL,0xC56DL},{1UL,0x0788L},{0xFBA0L,2UL},{1UL,0x0788L},{1UL,0xC56DL},{0xA898L,0xC2B9L},{65535UL,0xC2B9L}},{{0xA898L,0xC56DL},{1UL,0x0788L},{1UL,2UL},{0xFBA0L,0x0788L},{1UL,0xC56DL},{0xF8DDL,0xC2B9L},{65533UL,0xC2B9L},{0xF8DDL,0xC56DL},{1UL,0x0788L},{0xFBA0L,2UL}},{{1UL,0x0788L},{1UL,0xC56DL},{0xA898L,0xC2B9L},{65535UL,0xC2B9L},{0xA898L,0xC56DL},{1UL,2UL},{0xA898L,65535UL},{0xF8DDL,2UL},{0x619BL,0x15D2L},{65535UL,0x0788L}}};
    uint32_t **** const *l_2510 = (void*)0;
    uint32_t ***l_2513 = &g_1440;
    uint32_t ****l_2512 = &l_2513;
    uint32_t **** const *l_2511 = &l_2512;
    uint64_t * const *l_2524 = (void*)0;
    uint64_t * const **l_2523 = &l_2524;
    uint64_t * const ***l_2522 = &l_2523;
    uint64_t * const *** const *l_2521[6];
    uint32_t l_2527 = 18446744073709551615UL;
    union U1 * const l_2542 = &g_2543;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_56[i] = (void*)0;
    for (i = 0; i < 4; i++)
        l_2359[i] = &l_2360[1][1];
    for (i = 0; i < 6; i++)
        l_2521[i] = &l_2522;
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_642 g_153 g_154
 * writes: g_154
 */
static const int32_t * func_34(int32_t * p_35, int32_t * p_36)
{ /* block id: 1040 */
    const int32_t *l_2357[5][10][1] = {{{&g_517},{&g_130},{&g_517},{&g_3},{&g_517},{&g_130},{&g_517},{&g_130},{&g_517},{&g_3}},{{&g_517},{&g_130},{&g_517},{&g_130},{&g_517},{&g_3},{&g_517},{&g_130},{&g_517},{&g_130}},{{&g_517},{&g_3},{&g_517},{&g_130},{&g_517},{&g_130},{&g_517},{&g_3},{&g_517},{&g_130}},{{&g_517},{&g_130},{&g_517},{&g_3},{&g_517},{&g_130},{&g_517},{&g_130},{&g_517},{&g_3}},{{&g_517},{&g_130},{&g_517},{&g_130},{&g_517},{&g_3},{&g_517},{&g_130},{&g_517},{&g_130}}};
    int i, j, k;
    (*g_153) = (**g_642);
    return l_2357[4][6][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_1267 g_643 g_641 g_642 g_153 g_154 g_130 g_1638 g_1639 g_640
 * writes: g_161 g_2351
 */
static int32_t * func_37(int16_t  p_38, int32_t * p_39, int32_t * p_40)
{ /* block id: 1035 */
    int16_t l_2348 = 1L;
    uint32_t * const *l_2349[6][6] = {{&g_1441[0],&g_1441[1],&g_1441[1],&g_1441[0],&g_1441[1],&g_1441[1]},{&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1]},{&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1]},{&g_1441[0],&g_1441[1],&g_1441[1],&g_1441[0],&g_1441[1],&g_1441[1]},{&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1]},{&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1],&g_1441[1]}};
    uint32_t * const **l_2350[5][10][5] = {{{&l_2349[2][5],&l_2349[1][2],&l_2349[2][1],&l_2349[1][2],&l_2349[0][2]},{&l_2349[5][4],&l_2349[1][2],&l_2349[0][2],&l_2349[2][5],&l_2349[4][2]},{&l_2349[2][1],&l_2349[1][2],&l_2349[1][2],&l_2349[0][2],&l_2349[0][2]},{&l_2349[5][4],&l_2349[4][1],&l_2349[0][2],&l_2349[5][4],&l_2349[0][2]},{&l_2349[2][5],&l_2349[0][2],&l_2349[0][2],&l_2349[1][2],&l_2349[1][2]},{(void*)0,&l_2349[0][2],(void*)0,&l_2349[0][2],&l_2349[5][4]},{&l_2349[1][2],&l_2349[4][1],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2]},{&l_2349[0][2],&l_2349[1][2],&l_2349[0][2],&l_2349[4][2],&l_2349[2][5]},{(void*)0,&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],&l_2349[1][2]},{&l_2349[1][2],&l_2349[1][2],(void*)0,&l_2349[3][2],&l_2349[0][2]}},{{&l_2349[0][2],&l_2349[3][2],&l_2349[0][2],&l_2349[3][2],&l_2349[0][2]},{&l_2349[2][1],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[1][5]},{&l_2349[4][2],&l_2349[4][1],&l_2349[1][2],&l_2349[4][2],&l_2349[0][2]},{&l_2349[3][2],&l_2349[5][4],&l_2349[0][2],&l_2349[0][2],&l_2349[1][5]},{(void*)0,&l_2349[4][2],&l_2349[2][1],&l_2349[0][2],&l_2349[0][2]},{&l_2349[1][5],&l_2349[4][1],&l_2349[0][2],&l_2349[1][2],&l_2349[0][2]},{&l_2349[1][5],&l_2349[1][5],&l_2349[0][2],&l_2349[5][4],&l_2349[1][2]},{(void*)0,&l_2349[2][5],&l_2349[0][2],&l_2349[0][2],&l_2349[2][5]},{&l_2349[3][2],&l_2349[1][2],&l_2349[0][2],&l_2349[2][5],&l_2349[0][2]},{&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[4][1]}},{{(void*)0,&l_2349[0][2],&l_2349[0][2],&l_2349[2][0],&l_2349[2][1]},{&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[4][5]},{&l_2349[0][2],&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],(void*)0},{&l_2349[1][4],&l_2349[4][1],(void*)0,&l_2349[4][5],&l_2349[1][2]},{(void*)0,&l_2349[0][2],&l_2349[0][1],&l_2349[0][2],&l_2349[2][0]},{&l_2349[2][1],(void*)0,&l_2349[1][2],&l_2349[0][2],&l_2349[0][2]},{&l_2349[1][4],&l_2349[0][2],&l_2349[2][0],&l_2349[2][0],&l_2349[0][2]},{&l_2349[0][2],&l_2349[0][2],(void*)0,&l_2349[0][2],&l_2349[2][0]},{&l_2349[4][1],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[1][2]},{(void*)0,&l_2349[2][1],&l_2349[0][2],&l_2349[2][0],(void*)0}},{{&l_2349[4][1],&l_2349[0][2],&l_2349[0][2],&l_2349[4][1],&l_2349[4][5]},{&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[2][1],&l_2349[2][1]},{&l_2349[1][4],&l_2349[0][2],&l_2349[1][4],&l_2349[4][5],&l_2349[4][1]},{&l_2349[2][1],&l_2349[0][2],&l_2349[4][5],(void*)0,&l_2349[2][0]},{(void*)0,&l_2349[2][1],&l_2349[1][2],&l_2349[1][2],&l_2349[0][2]},{&l_2349[1][4],&l_2349[0][2],&l_2349[4][5],&l_2349[2][0],&l_2349[0][2]},{&l_2349[0][2],&l_2349[0][2],&l_2349[1][4],&l_2349[0][2],&l_2349[2][0]},{&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2]},{(void*)0,(void*)0,&l_2349[0][2],&l_2349[2][0],&l_2349[0][2]},{&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],&l_2349[1][2],&l_2349[4][5]}},{{&l_2349[0][2],&l_2349[4][1],&l_2349[0][2],(void*)0,&l_2349[0][2]},{&l_2349[1][4],&l_2349[1][2],(void*)0,&l_2349[4][5],&l_2349[0][2]},{&l_2349[0][2],&l_2349[0][2],&l_2349[2][0],&l_2349[2][1],&l_2349[2][0]},{&l_2349[0][2],&l_2349[0][2],&l_2349[1][2],&l_2349[4][1],&l_2349[0][2]},{&l_2349[1][4],&l_2349[0][2],&l_2349[0][1],&l_2349[2][0],&l_2349[0][2]},{&l_2349[0][2],&l_2349[0][2],(void*)0,&l_2349[0][2],&l_2349[2][0]},{&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[4][1]},{(void*)0,&l_2349[0][2],&l_2349[0][2],&l_2349[2][0],&l_2349[2][1]},{&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[0][2],&l_2349[4][5]},{&l_2349[0][2],&l_2349[1][2],&l_2349[0][2],&l_2349[0][2],(void*)0}}};
    int32_t l_2355 = 0xD762BCF6L;
    int32_t *l_2356 = &l_2355;
    int i, j, k;
    l_2355 &= (safe_mul_func_int8_t_s_s_unsafe_macro/*100*//* ___SAFE__OP */((l_2348 != (((*g_1267) = 4UL) && ((g_2351 = l_2349[0][2]) == ((safe_unary_minus_func_int32_t_s_unsafe_macro/*101*//* ___SAFE__OP */((*****g_643))) , (*g_1638))))), l_2348));
    return (****g_640);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_57(uint8_t  p_58, int32_t  p_59, int32_t * p_60)
{ /* block id: 7 */
    uint8_t l_63[9][3][9] = {{{0xBCL,0x70L,0x3CL,255UL,0xAAL,2UL,247UL,0xBBL,0xE5L},{8UL,0x21L,247UL,255UL,255UL,251UL,0xB9L,0x76L,0xBBL},{0xEDL,255UL,0xBEL,0x0EL,0xBBL,8UL,255UL,0xBDL,0x13L}},{{251UL,0xBEL,0xEDL,0x0EL,0x3CL,0x21L,255UL,0x21L,0x3CL},{0x4AL,255UL,255UL,0x4AL,0x53L,0xAAL,0x70L,0x19L,0xAAL},{0xEDL,0xF0L,0xAAL,255UL,0x0EL,0xEDL,0x46L,0UL,1UL}},{{0xF5L,0UL,0xBCL,0x3CL,0x53L,0x19L,0x0DL,0x76L,0x70L},{0xBDL,255UL,255UL,251UL,8UL,0xEDL,0x3CL,0x46L,0UL},{3UL,0x21L,255UL,0x72L,247UL,0xEDL,0UL,0xBDL,0UL}},{{0x19L,251UL,0xF5L,0xF5L,251UL,0x19L,0x0EL,255UL,0xB9L},{0x53L,0xBCL,252UL,255UL,1UL,0xEDL,7UL,0x0EL,0x72L},{251UL,0x19L,0xD8L,255UL,0x76L,0xAAL,0x0EL,0x66L,0xEDL}},{{0UL,0x0EL,1UL,3UL,255UL,0xB9L,0UL,0x21L,252UL},{255UL,2UL,251UL,0xBEL,0xEDL,0x0EL,0x3CL,0x21L,255UL},{0x66L,0x0DL,0xBEL,0xF0L,0xF0L,0xBEL,0x0DL,0x66L,255UL}},{{0x70L,255UL,0x21L,3UL,255UL,0x72L,0x46L,0x0EL,0x53L},{0xAAL,0xF5L,1UL,0xB9L,0xF0L,0xE5L,0x70L,255UL,255UL},{1UL,0xAAL,3UL,0UL,0UL,0xBBL,0x53L,0xBDL,255UL}},{{0xEDL,0xA4L,7UL,0x53L,0xAAL,0x13L,251UL,0x46L,252UL},{0xEDL,0xEDL,0x76L,0x13L,0x3CL,0x3CL,0x13L,0x76L,0xEDL},{1UL,0xBDL,0xAAL,255UL,0xB9L,251UL,255UL,0UL,0x72L}},{{0xAAL,0xBBL,0xA4L,247UL,255UL,3UL,0x72L,0x19L,0xB9L},{0x70L,0xBDL,0UL,0x0EL,1UL,3UL,255UL,0xB9L,0UL},{0x66L,0xEDL,251UL,0xBCL,0xE5L,0xA4L,0xF0L,252UL,0UL}},{{255UL,0xA4L,251UL,0x70L,251UL,1UL,1UL,251UL,0x70L},{0UL,0xAAL,0xBDL,0xAAL,255UL,0xB9L,251UL,255UL,0UL},{0xAAL,0xF0L,0UL,0xF0L,0xBDL,0x72L,251UL,0xD8L,0x46L}}};
    union U0 l_85 = {-1L};
    uint32_t l_106 = 1UL;
    int8_t l_107 = 0x8DL;
    int32_t *l_574 = &g_3;
    union U1 ** const l_2124 = &g_563;
    int8_t l_2126[6][5] = {{4L,0L,(-1L),1L,(-1L)},{8L,8L,0L,0x58L,1L},{0L,4L,4L,0L,(-1L)},{0L,0x58L,0L,0L,0x58L},{(-1L),4L,0xA6L,(-6L),(-6L)},{0xFEL,8L,0xFEL,0L,0L}};
    const int8_t l_2129 = 0xC5L;
    int32_t l_2150 = 1L;
    int32_t l_2151[5];
    uint32_t ****l_2202 = (void*)0;
    int32_t l_2204 = 0x9B5DFDD7L;
    uint64_t l_2219 = 18446744073709551606UL;
    uint64_t l_2223 = 0UL;
    uint16_t l_2224 = 0x6688L;
    int32_t *l_2292 = &g_3;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_2151[i] = (-3L);
    for (p_58 = 0; (p_58 <= 2); p_58 += 1)
    { /* block id: 10 */
        int32_t l_66[6];
        int32_t *l_575 = &l_66[4];
        union U0 l_2105[3][8] = {{{0x69L},{1L},{0x69L},{0x69L},{1L},{0x69L},{0x69L},{1L}},{{1L},{0x69L},{0x69L},{1L},{0x69L},{0x69L},{1L},{0x69L}},{{1L},{1L},{0xF5L},{1L},{1L},{0xF5L},{1L},{1L}}};
        int32_t l_2141[4][3] = {{1L,(-7L),1L},{0x7FC389D9L,0x9EC7D1B4L,0x7FC389D9L},{1L,(-7L),1L},{0x7FC389D9L,0x9EC7D1B4L,0x7FC389D9L}};
        uint32_t l_2147[6];
        uint16_t l_2167 = 0xE2DCL;
        uint32_t l_2171 = 1UL;
        union U1 **l_2188 = &g_563;
        int8_t *l_2195 = (void*)0;
        int8_t *l_2196 = (void*)0;
        int8_t *l_2197 = &g_977[0][0][3];
        const uint8_t l_2198 = 0x30L;
        int8_t *l_2199 = &l_2105[1][0].f0;
        int8_t l_2200 = (-1L);
        uint16_t *l_2201 = &g_61;
        int32_t *l_2203 = &g_130;
        int64_t l_2312[8][2] = {{0x9CB312F1B771C4A6LL,0x9CB312F1B771C4A6LL},{0x9CB312F1B771C4A6LL,1L},{0x9CB312F1B771C4A6LL,0x9CB312F1B771C4A6LL},{0x9CB312F1B771C4A6LL,1L},{0x9CB312F1B771C4A6LL,0x9CB312F1B771C4A6LL},{0x9CB312F1B771C4A6LL,1L},{0x9CB312F1B771C4A6LL,0x9CB312F1B771C4A6LL},{0x9CB312F1B771C4A6LL,1L}};
        union U0 ****l_2318 = &g_1082;
        const uint64_t *l_2334 = (void*)0;
        int8_t l_2341 = 0x47L;
        int i, j;
        for (i = 0; i < 6; i++)
            l_66[i] = (-1L);
        for (i = 0; i < 6; i++)
            l_2147[i] = 0UL;
    }
    return p_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_195 g_501 g_265.f0 g_404 g_251 g_479.f1 g_164 g_158 g_154 g_61 g_156 g_203 g_502 g_130 g_161 g_906 g_789 g_120 g_854 g_1264 g_1265 g_1121 g_1122 g_1266 g_1267 g_1396 g_1135 g_977 g_1080 g_1081 g_1440 g_563 g_766 g_498 g_1441 g_399 g_1018 g_362 g_384 g_420 g_448 g_448.f0 g_542 g_556 g_517 g_1536 g_511.f1 g_567.f1 g_913 g_1638 g_1718 g_737 g_976 g_1733 g_1745 g_1762 g_514.f1 g_1726 g_2081 g_705.f1 g_512.f1
 * writes: g_567.f1 g_502 g_164 g_399 g_404 g_251 g_479.f1 g_161 g_640 g_643 g_645 g_154 g_61 g_511.f1 g_854 g_705.f1 g_514.f1 g_513.f1 g_563 g_737 g_265.f0 g_913 g_129 g_512.f1 g_130 g_977 g_1396 g_195 g_1018 g_120 g_153 g_158 g_203 g_423 g_1536 g_1718 g_767 g_1733 g_1754 g_641 g_1122 g_448.f0 g_1775.f1 g_1969 g_2081
 */
static uint8_t  func_67(int32_t * p_68, uint32_t  p_69, int32_t * p_70, int8_t  p_71)
{ /* block id: 203 */
    int32_t l_621 = (-1L);
    int32_t *l_648 = &l_621;
    int32_t l_651 = 0x46528C99L;
    int32_t *****l_656 = &g_641;
    uint64_t *l_685 = &g_161;
    uint64_t **l_684 = &l_685;
    int32_t l_801[4];
    uint16_t l_887 = 0xED68L;
    union U0 l_902 = {9L};
    int8_t l_1040 = 0xCBL;
    int16_t ***l_1126[5][4][3] = {{{(void*)0,&g_1122,&g_1122},{&g_1122,&g_1122,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_1122,(void*)0,(void*)0}},{{&g_1122,&g_1122,&g_1122},{&g_1122,(void*)0,&g_1122},{&g_1122,(void*)0,&g_1122},{&g_1122,&g_1122,&g_1122}},{{&g_1122,&g_1122,&g_1122},{&g_1122,&g_1122,&g_1122},{(void*)0,&g_1122,&g_1122},{&g_1122,&g_1122,(void*)0}},{{(void*)0,(void*)0,(void*)0},{&g_1122,(void*)0,(void*)0},{&g_1122,&g_1122,&g_1122},{&g_1122,(void*)0,&g_1122}},{{&g_1122,(void*)0,&g_1122},{&g_1122,&g_1122,&g_1122},{&g_1122,&g_1122,&g_1122},{&g_1122,&g_1122,&g_1122}}};
    union U1 ***l_1241 = (void*)0;
    uint32_t *l_1255[4][1] = {{&g_158},{&g_120},{&g_158},{&g_120}};
    uint32_t **l_1254 = &l_1255[1][0];
    union U1 ****l_1302 = (void*)0;
    union U1 *****l_1301 = &l_1302;
    union U1 ****l_1304 = &l_1241;
    union U1 *****l_1303 = &l_1304;
    uint64_t *l_1312 = &g_854;
    union U1 **l_1316 = (void*)0;
    union U1 ***l_1315 = &l_1316;
    int32_t l_1334[10][8][3] = {{{0xB8648F5CL,0x3D18C1D7L,0x37F46C4BL},{1L,0x99C613A0L,0x37F46C4BL},{0xD463C8D0L,0x559CB932L,0x330F42A9L},{0L,1L,0x0D6EF506L},{0xD463C8D0L,0x0D6EF506L,0x559CB932L},{1L,0x0D6EF506L,0x99E4B98BL},{0xB8648F5CL,1L,1L},{5L,0x559CB932L,0x99E4B98BL}},{{1L,0x99C613A0L,0x559CB932L},{1L,(-4L),0L},{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L},{1L,0x6D5012D8L,1L},{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L},{0x37F46C4BL,0L,(-1L)}},{{1L,0L,0x6D5C916AL},{1L,0x335E1033L,0x335E1033L},{0x3D18C1D7L,(-1L),0x6D5C916AL},{0x330F42A9L,0x6D5012D8L,(-1L)},{0x330F42A9L,(-4L),0L},{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L},{1L,0x6D5012D8L,1L}},{{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L},{0x37F46C4BL,0L,(-1L)},{1L,0L,0x6D5C916AL},{1L,0x335E1033L,0x335E1033L},{0x3D18C1D7L,(-1L),0x6D5C916AL},{0x330F42A9L,0x6D5012D8L,(-1L)},{0x330F42A9L,(-4L),0L}},{{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L},{1L,0x6D5012D8L,1L},{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L},{0x37F46C4BL,0L,(-1L)},{1L,0L,0x6D5C916AL},{1L,0x335E1033L,0x335E1033L}},{{0x3D18C1D7L,(-1L),0x6D5C916AL},{0x330F42A9L,0x6D5012D8L,(-1L)},{0x330F42A9L,(-4L),0L},{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L},{1L,0x6D5012D8L,1L},{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L}},{{0x37F46C4BL,0L,(-1L)},{1L,0L,0x6D5C916AL},{1L,0x335E1033L,0x335E1033L},{0x3D18C1D7L,(-1L),0x6D5C916AL},{0x330F42A9L,0x6D5012D8L,(-1L)},{0x330F42A9L,(-4L),0L},{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L}},{{1L,0x6D5012D8L,1L},{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L},{0x37F46C4BL,0L,(-1L)},{1L,0L,0x6D5C916AL},{1L,0x335E1033L,0x335E1033L},{0x3D18C1D7L,(-1L),0x6D5C916AL},{0x330F42A9L,0x6D5012D8L,(-1L)}},{{0x330F42A9L,(-4L),0L},{0x3D18C1D7L,0x366ED366L,0x5C5B201BL},{1L,(-4L),1L},{1L,0x6D5012D8L,1L},{0x37F46C4BL,(-1L),0x5C5B201BL},{0x7DA5E308L,0x335E1033L,0L},{0x37F46C4BL,0L,(-1L)},{1L,0L,0x6D5C916AL}},{{1L,0x335E1033L,0x335E1033L},{(-4L),0xBDE7BE0DL,5L},{0x5C5B201BL,1L,0xBDE7BE0DL},{0x5C5B201BL,0L,0x69A4237AL},{(-4L),0xE5480A8DL,0xB8648F5CL},{0x335E1033L,0L,1L},{0x366ED366L,1L,1L},{1L,0xBDE7BE0DL,0xB8648F5CL}}};
    union U0 ****l_1336[10][4][6] = {{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,(void*)0},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,(void*)0,(void*)0,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,(void*)0,&g_1082,&g_1082,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,(void*)0,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,&g_1082,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,&g_1082,&g_1082},{&g_1082,&g_1082,(void*)0,&g_1082,(void*)0,&g_1082}},{{&g_1082,&g_1082,(void*)0,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,&g_1082,(void*)0},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,(void*)0,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,(void*)0}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,(void*)0,(void*)0,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,(void*)0,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,(void*)0,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,(void*)0,&g_1082,&g_1082,&g_1082,(void*)0},{&g_1082,&g_1082,&g_1082,&g_1082,(void*)0,&g_1082}},{{&g_1082,&g_1082,&g_1082,&g_1082,(void*)0,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,(void*)0,&g_1082},{&g_1082,&g_1082,&g_1082,(void*)0,&g_1082,&g_1082},{&g_1082,(void*)0,&g_1082,&g_1082,&g_1082,&g_1082}},{{(void*)0,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082},{(void*)0,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082}}};
    union U0 *****l_1395[2];
    int64_t *l_1463[4];
    int64_t **l_1462[3][3] = {{&l_1463[2],&l_1463[2],&l_1463[2]},{&l_1463[2],&l_1463[2],&l_1463[2]},{&l_1463[2],&l_1463[2],&l_1463[2]}};
    uint64_t ***l_1492 = &l_684;
    uint64_t ****l_1491 = &l_1492;
    uint64_t *****l_1490 = &l_1491;
    uint64_t l_1505 = 1UL;
    int32_t l_1517[1][9] = {{0x7EE4DE90L,0xCD273241L,0x7EE4DE90L,0xCD273241L,0x7EE4DE90L,0xCD273241L,0x7EE4DE90L,0xCD273241L,0x7EE4DE90L}};
    uint32_t l_1518 = 0xC28B88EFL;
    int64_t l_1545[6] = {0x68EE7606AA25BC93LL,0x68EE7606AA25BC93LL,0x68EE7606AA25BC93LL,0x68EE7606AA25BC93LL,0x68EE7606AA25BC93LL,0x68EE7606AA25BC93LL};
    int32_t l_1547 = 0xFCE8C0D9L;
    int64_t l_1549 = 0L;
    uint32_t l_1552[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    const union U0 l_1559[4] = {{0x35L},{0x35L},{0x35L},{0x35L}};
    union U0 * const *l_1704 = &g_423;
    union U0 *l_1714[8][10] = {{&l_902,&l_902,&l_902,&l_902,&g_448,&l_902,&g_448,&g_265,&g_265,&g_265},{&l_902,(void*)0,&g_448,&g_265,&g_448,(void*)0,&l_902,&g_448,&g_265,&l_902},{&g_448,&l_902,&g_448,&l_902,&l_902,&l_902,&l_902,&g_448,&l_902,&g_448},{&l_902,&l_902,&g_265,&g_265,&g_265,&l_902,&l_902,&l_902,&g_265,&g_265},{&g_265,(void*)0,&g_265,&l_902,&g_265,(void*)0,&g_448,&g_448,&g_448,&g_448},{&g_265,&l_902,(void*)0,(void*)0,&l_902,&g_265,&l_902,&g_448,&l_902,&l_902},{(void*)0,&l_902,&g_265,&g_448,&g_448,&g_448,&g_265,&l_902,(void*)0,&g_265},{(void*)0,(void*)0,&g_265,&l_902,&g_448,&g_265,&g_265,&g_448,&l_902,&g_265}};
    uint8_t *l_1728[7][3][7];
    uint64_t l_1742 = 0UL;
    int64_t l_1792 = 0x72BD4E46154A169BLL;
    int16_t l_1976 = 0xA69DL;
    int32_t l_1983 = 2L;
    int16_t l_1994 = 0x677FL;
    uint16_t l_2003[7][4] = {{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL},{1UL,0xB797L,0xB797L,1UL}};
    uint8_t l_2006[8] = {0xA5L,0xA5L,0xA5L,0xA5L,0xA5L,0xA5L,0xA5L,0xA5L};
    int32_t * const l_2079 = &l_801[3];
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_801[i] = (-1L);
    for (i = 0; i < 2; i++)
        l_1395[i] = &l_1336[0][2][5];
    for (i = 0; i < 4; i++)
        l_1463[i] = &g_1018[0][0][2];
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
                l_1728[i][j][k] = &g_1536[2];
        }
    }
lbl_1749:
    for (g_567.f1 = 0; (g_567.f1 <= 5); g_567.f1 += 1)
    { /* block id: 206 */
        uint64_t l_618 = 0xC826A0881330DC23LL;
        int32_t *l_628 = &g_3;
        int32_t ** const l_627 = &l_628;
        int32_t ** const *l_626 = &l_627;
        int32_t l_630 = (-1L);
        int32_t ***l_639 = (void*)0;
        int32_t ****l_638[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t *****l_637[1][6][6] = {{{&l_638[2],&l_638[1],&l_638[1],&l_638[2],&l_638[2],&l_638[2]},{&l_638[2],&l_638[2],&l_638[1],&l_638[2],&l_638[2],&l_638[2]},{&l_638[2],&l_638[2],&l_638[2],&l_638[2],&l_638[2],&l_638[2]},{&l_638[1],&l_638[2],&l_638[2],&l_638[2],&l_638[2],&l_638[2]},{&l_638[2],&l_638[1],&l_638[2],&l_638[1],&l_638[1],&l_638[2]},{&l_638[2],&l_638[2],&l_638[1],&l_638[2],&l_638[2],&l_638[2]}}};
        int16_t **l_661 = &g_501;
        union U1 *l_704 = &g_705;
        int64_t l_795 = (-4L);
        uint16_t l_811 = 6UL;
        union U0 l_826 = {0x61L};
        const int32_t l_849 = 0xA360238BL;
        int8_t **l_860 = (void*)0;
        union U0 ***l_940 = &g_746[0][0];
        int64_t *l_975 = &g_195;
        int32_t l_996[6][3] = {{(-1L),0x144D705EL,(-1L)},{0x199604F2L,3L,(-4L)},{0x199604F2L,0x199604F2L,3L},{(-1L),3L,3L},{3L,0x144D705EL,(-4L)},{(-1L),0x144D705EL,(-1L)}};
        int16_t l_1025 = 3L;
        union U0 **l_1046[1];
        uint8_t l_1051 = 1UL;
        union U0 ****l_1079 = &l_940;
        union U0 *****l_1078 = &l_1079;
        uint32_t *l_1145 = &g_567.f1;
        uint32_t **l_1144 = &l_1145;
        int8_t *l_1176 = (void*)0;
        int8_t l_1204 = 0x46L;
        uint64_t **l_1228 = &l_685;
        uint32_t l_1231[2][10] = {{0xDF3CE4DFL,4294967295UL,4294967287UL,0UL,0UL,4294967287UL,4294967295UL,0xDF3CE4DFL,4294967287UL,0xDF3CE4DFL},{0UL,0x1140B935L,4294967291UL,0UL,4294967291UL,0x1140B935L,0UL,0xCF4B7A64L,0xCF4B7A64L,0UL}};
        int64_t l_1258[3];
        int64_t *l_1287 = &l_1258[1];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1046[i] = &g_423;
        for (i = 0; i < 3; i++)
            l_1258[i] = (-1L);
        if ((*p_70))
            break;
        if ((((safe_lshift_func_int32_t_s_u_unsafe_macro/*102*//* ___SAFE__OP */((((p_69 > (l_618 || (0x09L && g_195))) , ((0L ^ (g_164 = (((void*)0 != &g_557) != ((((*g_501) = l_618) != (safe_rshift_func_uint64_t_u_s_unsafe_macro/*103*//* ___SAFE__OP */(g_265.f0, p_71))) == l_618)))) || g_404)) >= 0x6D9F6BB26B52436CLL), 30)) , l_621) >= l_621))
        { /* block id: 210 */
            int32_t l_622[2][6][10] = {{{0x28480E20L,0xC66BD057L,0x28480E20L,(-1L),(-1L),(-1L),0x28480E20L,0xC66BD057L,0x28480E20L,(-1L)},{1L,0xC66BD057L,0x97917CFCL,0xC66BD057L,1L,0x96A11009L,1L,0xC66BD057L,0x97917CFCL,0xC66BD057L},{(-1L),(-1L),0x28480E20L,0xC66BD057L,0x28480E20L,(-1L),(-1L),(-1L),0x28480E20L,0xC66BD057L},{0L,0xC66BD057L,0L,(-1L),1L,(-1L),0L,0xC66BD057L,0L,(-1L)},{(-1L),0xC66BD057L,(-8L),0xC66BD057L,(-1L),0x96A11009L,(-1L),0xC66BD057L,(-8L),0xC66BD057L},{1L,(-1L),0L,0xC66BD057L,0L,(-1L),1L,(-1L),0L,0xC66BD057L}},{{0x28480E20L,0xC66BD057L,0x28480E20L,(-1L),(-1L),(-1L),0x28480E20L,0xC66BD057L,0x28480E20L,(-1L)},{1L,0xC66BD057L,0x97917CFCL,0xC66BD057L,1L,0x96A11009L,0L,(-1L),1L,(-1L)},{0x28480E20L,0x96A11009L,(-8L),(-1L),(-8L),0x96A11009L,0x28480E20L,0x96A11009L,(-8L),(-1L)},{0x97917CFCL,(-1L),0x97917CFCL,0x96A11009L,0L,0x96A11009L,0x97917CFCL,(-1L),0x97917CFCL,0x96A11009L},{0x28480E20L,(-1L),(-1L),(-1L),0x28480E20L,0xC66BD057L,0x28480E20L,(-1L),(-1L),(-1L)},{0L,0x96A11009L,0x97917CFCL,(-1L),0x97917CFCL,0x96A11009L,0L,0x96A11009L,0x97917CFCL,(-1L)}}};
            int32_t ***l_625 = &g_153;
            int16_t ***l_662 = (void*)0;
            int16_t ***l_663 = &l_661;
            uint64_t *l_664 = (void*)0;
            uint64_t *l_665[1];
            uint16_t *l_672 = &g_61;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_665[i] = &g_161;
            for (g_399 = 5; (g_399 >= 0); g_399 -= 1)
            { /* block id: 213 */
                return l_622[1][0][1];
            }
            for (g_404 = 0; (g_404 <= 5); g_404 += 1)
            { /* block id: 218 */
                int32_t *l_629[2][7] = {{&l_622[0][1][6],&l_622[0][1][6],&l_622[0][1][6],&l_622[0][1][6],&l_622[0][1][6],&l_622[0][1][6],&l_622[0][1][6]},{&l_621,&l_621,&l_621,&l_621,&l_621,&l_621,&l_621}};
                int i, j;
                l_630 = (+(((+1UL) , l_625) == (l_626 = &g_153)));
                for (g_251 = 0; (g_251 <= 1); g_251 += 1)
                { /* block id: 223 */
                    int32_t l_633[1][6][6] = {{{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L},{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L},{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L},{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L},{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L},{0x6FA7869CL,0x7D4281A2L,0x7D4281A2L,0x6FA7869CL,0x7D4281A2L,0x7D4281A2L}}};
                    int32_t l_636 = 0x6D1FAFE0L;
                    int32_t *****l_644 = &l_638[2];
                    uint64_t *l_649 = &l_618;
                    const int32_t l_650 = (-1L);
                    int i, j, k;
                    for (g_479.f1 = 1; (g_479.f1 <= 5); g_479.f1 += 1)
                    { /* block id: 226 */
                        uint8_t l_631[1][7] = {{0xF9L,0x35L,0x35L,0xF9L,0x35L,0x35L,0xF9L}};
                        uint64_t *l_632 = &g_161;
                        int i, j, k;
                        l_622[g_251][g_404][(g_251 + 8)] = l_631[0][0];
                        l_622[g_251][(g_251 + 2)][(g_479.f1 + 3)] |= ((*p_68) < (((*l_632) = (&g_420[0] == &g_420[2])) > 0xD690913C06DF6198LL));
                    }
                    if (l_633[0][0][1])
                        continue;
                    l_651 ^= (safe_rshift_func_int8_t_s_u_unsafe_macro/*104*//* ___SAFE__OP */(((((*g_501) = (*l_628)) | ((p_69 > (l_636 = l_633[0][0][1])) | ((((((1L || ((g_643 = (g_640 = l_637[0][0][1])) == (g_645 = l_644))) , ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*105*//* ___SAFE__OP */(((*l_649) = ((l_648 = func_72(func_72(p_68, func_72(p_68, p_70, p_70, g_164, p_68), p_68, g_203[1], p_68), p_68, p_70, p_69, p_68)) != &l_622[1][0][1])), l_621)) , (void*)0)) != (void*)0) , 18446744073709551615UL) && g_156) > l_650))) || (*g_501)), 6));
                    for (g_502 = 1; (g_502 <= 5); g_502 += 1)
                    { /* block id: 242 */
                        if ((*p_68))
                            break;
                        return g_195;
                    }
                }
            }
            l_651 = (((safe_lshift_func_uint32_t_u_u_unsafe_macro/*106*//* ___SAFE__OP */(g_130, 17)) & (g_404 >= ((*l_672) = (safe_lshift_func_int16_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */(((void*)0 == l_656), ((*g_501) = ((((safe_sub_func_int8_t_s_s_unsafe_macro/*108*//* ___SAFE__OP */(g_203[1], ((((safe_mod_func_int8_t_s_s_unsafe_macro/*109*//* ___SAFE__OP */((((l_622[1][2][9] = (&g_384[0][0] != ((*l_663) = l_661))) , (safe_add_func_uint64_t_u_u_unsafe_macro/*110*//* ___SAFE__OP */(p_71, (safe_mod_func_int64_t_s_s_unsafe_macro/*111*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*112*//* ___SAFE__OP */((2UL != p_69), g_251)), (-6L)))))) > 0xBF8CCC5480A15F8ALL), 0x5EL)) , 0x808C9F69L) == (*p_70)) & 0xD195L))) <= (*p_70)) || g_161) == (*l_628)))))))) != p_69);
        }
        else
        { /* block id: 253 */
            uint64_t **l_695[8] = {&l_685,&l_685,&l_685,&l_685,&l_685,&l_685,&l_685,&l_685};
            int32_t l_707 = 0L;
            uint8_t *l_768 = &g_164;
            int16_t l_794 = (-1L);
            int32_t l_806 = 0xF04E037FL;
            int32_t l_810 = 0x599C2850L;
            union U0 ** const *l_820 = &g_746[0][0];
            union U0 ** const **l_819[1];
            union U0 ** const ***l_818 = &l_819[0];
            int8_t *l_859 = &g_265.f0;
            int8_t ** const l_858 = &l_859;
            int32_t l_907 = (-1L);
            int i;
            for (i = 0; i < 1; i++)
                l_819[i] = &l_820;
            for (g_404 = 0; (g_404 <= 0); g_404 += 1)
            { /* block id: 256 */
                return g_158;
            }
            for (g_511.f1 = 0; (g_511.f1 <= 0); g_511.f1 += 1)
            { /* block id: 261 */
                int8_t *l_677[5][6] = {{&g_265.f0,&g_265.f0,&g_265.f0,&g_265.f0,(void*)0,(void*)0},{(void*)0,&g_265.f0,&g_448.f0,&g_265.f0,(void*)0,&g_448.f0},{&g_265.f0,(void*)0,&g_448.f0,&g_448.f0,(void*)0,&g_265.f0},{&g_265.f0,&g_265.f0,(void*)0,(void*)0,(void*)0,&g_265.f0},{(void*)0,&g_265.f0,&g_448.f0,&g_448.f0,&g_448.f0,&g_448.f0}};
                uint64_t ***l_692 = (void*)0;
                uint64_t **l_694 = &l_685;
                uint64_t ***l_693 = &l_694;
                int32_t l_696 = (-1L);
                int32_t * const l_703 = &g_130;
                int32_t *l_761 = (void*)0;
                int32_t l_803 = 0L;
                int32_t l_804 = 0xB1684AE9L;
                int32_t l_807 = 0x64A34CA2L;
                int32_t l_808 = 0L;
                union U0 l_825 = {9L};
                int64_t l_856 = 1L;
                uint32_t *l_868 = &g_511.f1;
                uint32_t **l_867 = &l_868;
                uint32_t *l_869 = &g_705.f1;
                uint32_t *l_870 = &g_564.f1;
                uint32_t *l_871 = &g_564.f1;
                uint32_t *l_872[9] = {&g_120,&g_705.f1,&g_705.f1,&g_120,&g_705.f1,&g_705.f1,&g_120,&g_705.f1,&g_705.f1};
                int64_t *l_875 = &l_856;
                int32_t l_923 = 0xE903BB93L;
                int i, j;
            }
            l_707 = ((l_940 == &g_746[0][3]) == p_69);
        }
    }
    if (((safe_div_func_uint64_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */(((p_69 , ((*l_1301) = &l_1241)) == ((*l_1303) = &l_1241)), (+((*l_1312) &= ((safe_mod_func_uint8_t_u_u_unsafe_macro/*114*//* ___SAFE__OP */((((safe_mul_func_int64_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */(g_161, ((&g_120 == (void*)0) < (safe_add_func_int32_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */((*p_70), ((g_906 && ((*g_501) >= p_71)) , (*p_68))))))) && p_69) < g_789), g_120)) == 0xE27CD292L))))) || 0x6F19L))
    { /* block id: 517 */
        union U1 **l_1314 = (void*)0;
        union U1 ***l_1313[3][2] = {{&l_1314,(void*)0},{&l_1314,&l_1314},{(void*)0,&l_1314}};
        uint16_t *l_1331 = (void*)0;
        uint16_t *l_1332 = (void*)0;
        uint16_t *l_1333[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t l_1335 = 0L;
        int32_t l_1423 = 0x81DF117FL;
        uint32_t l_1433 = 0xF0299048L;
        int32_t l_1456 = 0xFC35C559L;
        int32_t *l_1469[1];
        uint64_t ****l_1477 = (void*)0;
        union U0 l_1485 = {5L};
        uint8_t *l_1516 = &g_164;
        int i, j;
        for (i = 0; i < 1; i++)
            l_1469[i] = &l_621;
        if ((p_69 || ((l_1313[2][1] == ((*l_1304) = l_1315)) & (safe_sub_func_int16_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */(((void*)0 == &l_902), ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*119*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*120*//* ___SAFE__OP */(((-10L) > (safe_sub_func_uint16_t_u_u_unsafe_macro/*121*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*122*//* ___SAFE__OP */((l_1334[1][1][2] ^= (safe_rshift_func_int16_t_s_u_unsafe_macro/*123*//* ___SAFE__OP */(p_71, ((*g_1264) != (*g_1264))))), l_1335)), p_69))), 0xF3B1L)), l_1335)) , 0x2AA5A6BCL))) , (void*)0) == l_1336[1][1][0]), l_1335)))))
        { /* block id: 520 */
            int8_t l_1337 = 0L;
            uint32_t l_1344 = 0UL;
            int32_t l_1369 = 1L;
            l_1335 = l_1337;
            for (g_705.f1 = (-24); (g_705.f1 != 48); g_705.f1 = safe_add_func_int32_t_s_s_unsafe_macro/*124*//* ___SAFE__OP */(g_705.f1, 9))
            { /* block id: 524 */
                int16_t l_1345 = 0xC5C0L;
                int32_t l_1364 = 0x14AAFC73L;
                uint64_t ***l_1374 = &l_684;
                uint64_t ****l_1373 = &l_1374;
                int8_t *l_1397 = &g_265.f0;
                int32_t *l_1398[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_1398[i] = &l_1364;
                if (((((safe_mul_func_uint16_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */(p_69, (safe_add_func_uint32_t_u_u_unsafe_macro/*126*//* ___SAFE__OP */(((4L != (l_1344 || l_1345)) <= (-1L)), ((((**g_1121) != (g_195 , (**g_1121))) || l_1345) & g_203[4]))))) <= p_71) != l_1344) , 1L))
                { /* block id: 525 */
                    int8_t l_1362[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1362[i] = 0L;
                    for (l_1040 = 0; (l_1040 <= 0); l_1040 += 1)
                    { /* block id: 528 */
                        int32_t *l_1346 = &l_621;
                        (*l_1346) = (*p_70);
                        g_563 = (((safe_lshift_func_int16_t_s_u_unsafe_macro/*127*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u_unsafe_macro/*128*//* ___SAFE__OP */((l_1335 > (safe_div_func_int32_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */((*p_68), (*p_68)))), 31)) || (g_514.f1 = 0xEEBE187AL)), 11)) | ((p_71 || (!(((safe_div_func_int16_t_s_s_unsafe_macro/*130*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*131*//* ___SAFE__OP */(((***g_1265) , 0x77L), 5UL)), (safe_lshift_func_int32_t_s_s_unsafe_macro/*132*//* ___SAFE__OP */(((g_513.f1 = (safe_mul_func_uint64_t_u_u_unsafe_macro/*133*//* ___SAFE__OP */(l_1344, l_1362[0]))) ^ (*p_70)), 28)))) , 0x1CL) , (**g_1122)))) | l_1337)) , (void*)0);
                        if ((*l_1346))
                            break;
                    }
                    for (g_737 = 0; (g_737 >= 0); g_737 -= 1)
                    { /* block id: 537 */
                        uint32_t ***l_1363 = &l_1254;
                        int i, j;
                        (*l_1363) = &l_1255[(g_737 + 2)][g_737];
                    }
                }
                else
                { /* block id: 540 */
                    uint16_t l_1370 = 0xA5B9L;
                    for (g_854 = 0; (g_854 <= 8); g_854 += 1)
                    { /* block id: 543 */
                        int32_t *l_1365 = &l_621;
                        int32_t *l_1366 = (void*)0;
                        int32_t *l_1367 = &l_1364;
                        int32_t *l_1368[10][8][2] = {{{(void*)0,&l_1364},{&g_130,&l_651},{&g_3,&l_801[2]},{&l_621,(void*)0},{(void*)0,&l_621},{&l_651,(void*)0},{&l_1364,&l_621},{(void*)0,&l_1335}},{{&l_621,&l_801[2]},{&g_130,(void*)0},{&g_130,(void*)0},{&l_1364,(void*)0},{&l_1364,(void*)0},{&l_1364,(void*)0},{&g_130,(void*)0},{&g_130,&l_801[2]}},{{&l_621,&l_801[0]},{&l_1364,(void*)0},{&g_130,&l_621},{&l_1335,&l_621},{&l_1364,(void*)0},{&l_621,(void*)0},{&l_1364,&g_130},{&l_651,&l_1364}},{{&l_801[2],&l_1364},{(void*)0,(void*)0},{&l_1364,&l_1364},{&g_3,&l_1335},{&l_1364,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1335,&l_1364}},{{&l_1335,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1364,&l_1335},{&g_3,&l_1364},{&l_1364,(void*)0},{(void*)0,&l_1364},{&l_801[2],&l_1364}},{{&l_651,&g_130},{&l_1364,(void*)0},{&l_621,(void*)0},{&l_1364,&l_621},{&l_1335,&l_621},{&g_130,(void*)0},{&l_1364,&l_801[0]},{(void*)0,(void*)0}},{{(void*)0,&l_1335},{&l_651,&l_801[2]},{&l_1364,&l_1364},{&l_801[0],&l_1364},{&l_1364,&l_801[2]},{&l_651,&l_1335},{(void*)0,(void*)0},{(void*)0,&l_801[0]}},{{&l_1364,(void*)0},{&g_130,&l_621},{&l_1335,&l_621},{&l_1364,(void*)0},{&l_621,(void*)0},{&l_1364,&g_130},{&l_651,&l_1364},{&l_801[2],&l_1364}},{{(void*)0,(void*)0},{&l_1364,&l_1364},{&g_3,&l_1335},{&l_1364,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1335,&l_1364},{&l_1335,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1364,&l_1335},{&g_3,&l_1364},{&l_1364,(void*)0},{(void*)0,&l_1364},{&l_801[2],&l_1364},{&l_651,&g_130}}};
                        int i, j, k;
                        l_1364 = g_203[g_854];
                        ++l_1370;
                    }
                }
                l_1335 &= ((l_1373 == (void*)0) & (((*l_1397) = ((safe_mul_func_uint64_t_u_u_unsafe_macro/*134*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*135*//* ___SAFE__OP */(p_69, (safe_div_func_uint16_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*137*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*139*//* ___SAFE__OP */(65535UL, (safe_mod_func_int32_t_s_s_unsafe_macro/*140*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u_unsafe_macro/*141*//* ___SAFE__OP */(255UL, p_69)) , ((((safe_mul_func_int32_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */((l_1369 = ((safe_mul_func_int32_t_s_s_unsafe_macro/*143*//* ___SAFE__OP */((*p_68), ((l_1395[0] = &g_1081) != (void*)0))) | 0x173658B6688924C0LL)), p_69)) | l_1344) ^ l_1345) <= (-1L))), 0x61B8DD6FL)))), l_1337)) > 0xCBL), g_1396)), 4L)))), p_71)) <= 0xD9C70245L)) | g_854));
                for (g_511.f1 = (-28); (g_511.f1 > 55); g_511.f1 = safe_add_func_uint32_t_u_u_unsafe_macro/*144*//* ___SAFE__OP */(g_511.f1, 1))
                { /* block id: 554 */
                    const int32_t **l_1401 = (void*)0;
                    const int32_t *l_1403 = &g_517;
                    const int32_t **l_1402 = &l_1403;
                    const int32_t **l_1404 = (void*)0;
                    const int32_t *l_1406 = (void*)0;
                    const int32_t **l_1405 = &l_1406;
                    (*l_1405) = ((*l_1402) = (void*)0);
                    if ((*p_68))
                        break;
                }
            }
        }
        else
        { /* block id: 560 */
            int32_t * const l_1409 = &g_3;
            int32_t *l_1410 = (void*)0;
            int32_t l_1422 = 0x17132028L;
            int32_t l_1427 = 8L;
            uint16_t l_1454 = 8UL;
            uint32_t l_1493 = 8UL;
            for (g_913 = (-18); (g_913 > 24); ++g_913)
            { /* block id: 563 */
                int32_t * const l_1411 = &g_130;
                union U1 * const *l_1418 = &g_563;
                union U1 * const **l_1417 = &l_1418;
                int32_t l_1421 = 0x9F89450CL;
                int32_t l_1430 = (-1L);
                int64_t l_1431 = 0x8E6EB660A16D5B40LL;
                (*g_1135) = func_72(func_72(&l_1335, ((*g_1135) = p_70), l_1409, g_977[1][1][0], p_68), &l_1335, &l_1335, g_906, l_1410);
                for (g_164 = 0; (g_164 <= 3); g_164 += 1)
                { /* block id: 568 */
                    uint16_t l_1412 = 0xC127L;
                    int32_t l_1419 = 0L;
                    int32_t l_1420 = (-1L);
                    int32_t l_1428 = 0x0901D22FL;
                    int32_t l_1432 = 0x6F2B99E2L;
                    --l_1412;
                    for (g_512.f1 = 0; (g_512.f1 <= 0); g_512.f1 += 1)
                    { /* block id: 572 */
                        int32_t *l_1424 = &l_1423;
                        int32_t *l_1425 = (void*)0;
                        int32_t *l_1426[7];
                        int32_t l_1429[3];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_1426[i] = (void*)0;
                        for (i = 0; i < 3; i++)
                            l_1429[i] = 0xD29B744AL;
                        (*g_154) |= (0x7EB5E2F9L | (l_1417 == &l_1418));
                        --l_1433;
                    }
                }
                (*l_1411) = (safe_lshift_func_int64_t_s_u_unsafe_macro/*145*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*146*//* ___SAFE__OP */(((void*)0 != (*g_1080)), ((((((void*)0 == g_1440) || (g_164 > (1UL < (safe_add_func_int64_t_s_s_unsafe_macro/*147*//* ___SAFE__OP */((((void*)0 != g_563) || p_69), 2UL))))) != (*l_1411)) & (*l_1409)) < 0x17L))) ^ p_69), p_71));
            }
            for (g_913 = 19; (g_913 > 19); g_913 = safe_add_func_uint16_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */(g_913, 4))
            { /* block id: 581 */
                uint8_t l_1453 = 5UL;
                uint8_t *l_1468 = &g_1396;
                int32_t **l_1470 = &g_154;
                int8_t *l_1471 = &g_265.f0;
                int8_t *l_1472 = &g_977[1][2][4];
                l_1456 &= (safe_sub_func_int16_t_s_s_unsafe_macro/*149*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*150*//* ___SAFE__OP */((p_69 ^ (safe_mul_func_int32_t_s_s_unsafe_macro/*151*//* ___SAFE__OP */((l_1453 = ((l_1335 >= (+l_1423)) || p_71)), l_1454))), 0xCE0448BEL)), ((**g_1122) = ((((~0UL) && (18446744073709551615UL < 0xD7B69E098E9D499FLL)) ^ 0x96E78DC1L) ^ (*p_68)))));
                l_1422 &= ((*l_648) <= (((((*l_1468) &= ((g_737 = ((***g_1121) = (~(l_1453 <= (((((((**g_1440) = ((((safe_lshift_func_int8_t_s_u_unsafe_macro/*152*//* ___SAFE__OP */(((*l_1472) = ((((**g_1266) , (safe_sub_func_int16_t_s_s_unsafe_macro/*153*//* ___SAFE__OP */((((*l_1471) = ((g_766[6] , (((void*)0 != l_1462[1][2]) , &l_1427)) == ((*l_1470) = &l_621))) == p_69), 0x25DBL))) & 1UL) != p_69)), 6)) && g_498) < 0x42D4FEFAC5796381LL) ^ p_69)) ^ (*p_68)) >= p_69) , 0x6023CBE6787A6FC4LL) || g_3) & (*p_68)))))) , p_69)) == p_69) || (*l_648)) || (-1L)));
                if (((l_651 = (safe_mul_func_uint16_t_u_u_unsafe_macro/*154*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */((l_1477 != &g_1265), (*g_1267))), (((safe_sub_func_uint64_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */((*g_1267), (safe_sub_func_int16_t_s_s_unsafe_macro/*157*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */((l_1493 = ((*l_1312) = (~(((l_1485 , ((*l_1472) = p_69)) > (safe_div_func_uint8_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */(p_71, (safe_lshift_func_uint64_t_u_s_unsafe_macro/*160*//* ___SAFE__OP */(1UL, ((**l_1470) ^= (g_195 = (((&l_1477 == l_1490) , (void*)0) == &l_1456)))))))) || p_71)))), (****g_1264))), p_69)))) <= 5UL) != g_399)))) | (-1L)))
                { /* block id: 600 */
                    g_563 = g_563;
                    if ((*p_70))
                        break;
                    return g_1018[0][3][5];
                }
                else
                { /* block id: 604 */
                    int32_t *l_1494 = &l_801[2];
                    int32_t **l_1497[8][8][4] = {{{&g_129[0],&l_1494,&g_154,&l_1469[0]},{&l_1469[0],&l_1410,&l_648,(void*)0},{&g_129[1],&l_1494,&l_1469[0],&l_648},{(void*)0,&l_1410,&l_1410,&g_129[1]},{(void*)0,&l_1494,(void*)0,&g_129[2]},{&l_1469[0],&l_1494,&l_648,(void*)0},{&g_154,&l_1469[0],&l_1469[0],&g_129[1]},{(void*)0,(void*)0,&l_1494,&l_1469[0]}},{{&l_1469[0],&l_1494,&g_154,(void*)0},{&g_154,&l_1410,(void*)0,&l_1410},{&l_1410,&l_1469[0],(void*)0,(void*)0},{&g_154,&g_154,&l_1469[0],(void*)0},{&l_1494,(void*)0,(void*)0,&l_1410},{&g_129[0],&l_1494,&l_1410,&l_1469[0]},{&l_1410,&g_154,&g_154,&l_1469[0]},{&l_1469[0],&l_1410,&l_1469[0],(void*)0}},{{&l_1494,&l_1469[0],&g_154,&l_1494},{&g_154,&l_1494,&g_154,(void*)0},{(void*)0,&l_1494,&l_1469[0],(void*)0},{&l_1469[0],&g_129[0],&l_1410,&l_1494},{(void*)0,&l_1469[0],&l_1410,&l_1494},{&l_1469[0],&l_1494,&l_1469[0],&l_1410},{(void*)0,(void*)0,&g_154,&l_1494},{&g_154,&l_1494,&g_154,(void*)0}},{{&l_1494,&l_1469[0],&l_1410,&l_1469[0]},{&l_1410,&l_1469[0],&l_648,&l_1410},{&l_1469[0],&l_1410,&g_129[0],&l_648},{(void*)0,(void*)0,(void*)0,&l_1469[0]},{&l_1469[0],&l_1494,&l_1469[0],&g_154},{&l_1494,&g_154,&l_648,&l_1494},{(void*)0,&l_1410,&l_1494,&l_1494},{&g_129[2],(void*)0,&g_129[1],&l_1494}},{{&l_1469[0],&l_1469[0],&g_129[2],(void*)0},{(void*)0,&l_1494,&l_1469[0],&l_1469[0]},{&l_1494,&l_1469[0],(void*)0,&g_129[2]},{(void*)0,&g_154,&l_1494,&l_1469[0]},{&l_1410,&l_1410,&g_129[0],(void*)0},{(void*)0,&l_1410,&g_154,&l_1469[0]},{&l_1469[0],&g_129[0],(void*)0,(void*)0},{&l_1494,&l_1469[0],&l_1469[0],&g_129[2]}},{{&l_1494,&l_1494,&l_1469[0],(void*)0},{&g_129[0],&l_1469[0],&l_1469[0],&l_1410},{&l_648,&l_1469[0],(void*)0,&l_1494},{&g_154,&l_1469[0],(void*)0,&l_1469[0]},{&l_1469[0],(void*)0,&l_1410,&l_1494},{&l_1469[0],(void*)0,&l_1469[0],&l_1469[0]},{&g_129[0],&g_129[0],&g_154,&l_1494},{(void*)0,(void*)0,&g_154,&l_1469[0]}},{{&l_1469[0],(void*)0,&l_1469[0],&g_154},{&l_1469[0],(void*)0,&g_154,&l_1469[0]},{(void*)0,(void*)0,&l_1494,&l_1494},{&l_648,&g_129[0],&l_1469[0],&l_1469[0]},{&l_648,(void*)0,&l_648,&l_1494},{(void*)0,(void*)0,&g_129[0],&l_1469[0]},{&g_129[2],&l_1469[0],&l_1494,&l_1494},{&l_1469[0],&l_1469[0],&l_1494,&l_1410}},{{&l_1494,&l_1469[0],&l_1469[0],(void*)0},{&l_648,&l_1494,&l_1469[0],&g_129[2]},{&l_1469[0],&l_1469[0],&l_1494,(void*)0},{&l_1410,&g_129[0],&g_154,&l_1469[0]},{&l_1494,&l_1410,&l_648,(void*)0},{&l_1410,&l_1410,(void*)0,&l_1469[0]},{(void*)0,&g_154,&g_129[2],&g_129[2]},{&g_154,&l_1469[0],&g_129[0],&l_1410}}};
                    int32_t **l_1498 = &l_1469[0];
                    int i, j, k;
                    (*g_1135) = func_72(p_68, p_68, ((*l_1498) = func_72(func_78(p_71, l_1494, ((g_1018[0][3][5] ^= ((0x33L || (*l_1494)) != (safe_sub_func_int64_t_s_s_unsafe_macro/*161*//* ___SAFE__OP */((*l_1494), (l_1485 , (**l_1470)))))) , 65532UL), g_789), p_70, p_70, p_69, &l_801[2])), (*l_1409), p_68);
                }
            }
        }
        l_651 ^= (safe_mod_func_uint16_t_u_u_unsafe_macro/*162*//* ___SAFE__OP */((l_801[2] = (safe_sub_func_uint32_t_u_u_unsafe_macro/*163*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*164*//* ___SAFE__OP */(((***g_1121) , l_1505), (safe_lshift_func_int16_t_s_u_unsafe_macro/*165*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*166*//* ___SAFE__OP */((p_69 ^ (l_1517[0][2] = (safe_lshift_func_uint16_t_u_u_unsafe_macro/*167*//* ___SAFE__OP */((1L <= ((*l_1516) = (safe_sub_func_uint16_t_u_u_unsafe_macro/*168*//* ___SAFE__OP */(((*l_648) > p_71), (safe_mul_func_uint16_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */(((&p_70 != &p_70) == p_69), p_71)))))), (*l_648))))), 0xC9L)), 4)))), p_69))), (*l_648)));
        l_1518 ^= (*l_648);
    }
    else
    { /* block id: 616 */
        uint32_t l_1523 = 1UL;
        int32_t l_1529 = 0x6DBF4F4CL;
        union U1 * const l_1530 = (void*)0;
        uint16_t *l_1533 = (void*)0;
        int32_t *l_1534 = (void*)0;
        union U1 *l_1535 = (void*)0;
        int32_t l_1537 = 0x784AB530L;
        int32_t l_1546 = 1L;
        int32_t l_1548 = (-7L);
        int32_t l_1550[6] = {(-1L),0xE0ED072BL,0xE0ED072BL,(-1L),0xE0ED072BL,0xE0ED072BL};
        int64_t l_1551 = 0x0BCA5C26A63909FCLL;
        uint32_t l_1595 = 0x313E7E27L;
        int8_t l_1620 = 4L;
        int32_t l_1646 = 0x750B32C2L;
        uint8_t l_1671[7][1][6] = {{{1UL,252UL,1UL,1UL,1UL,252UL}},{{252UL,252UL,0UL,252UL,252UL,252UL}},{{1UL,1UL,1UL,252UL,1UL,1UL}},{{252UL,1UL,0UL,1UL,252UL,1UL}},{{1UL,252UL,1UL,1UL,1UL,252UL}},{{252UL,252UL,0UL,252UL,252UL,252UL}},{{1UL,1UL,1UL,252UL,1UL,1UL}}};
        union U0 **l_1705 = (void*)0;
        uint32_t l_1708[10] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
        int8_t l_1709 = 0xCAL;
        union U1 **l_1732 = &g_563;
        int16_t **l_1735 = &g_501;
        const int16_t * const *l_1751 = (void*)0;
        const int16_t * const **l_1750 = &l_1751;
        int32_t ****l_1785 = &g_642;
        const union U0 l_1811[3] = {{0L},{0L},{0L}};
        int32_t l_1863 = 0x1604779CL;
        int32_t *l_1886 = &g_130;
        union U1 *****l_1892 = &l_1302;
        const int32_t l_1927 = 1L;
        int32_t l_1929 = 1L;
        int16_t **l_1959[3][8];
        int32_t l_1963 = 0xBC968ED3L;
        uint8_t l_1984 = 6UL;
        union U0 l_2028 = {0xD9L};
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 8; j++)
                l_1959[i][j] = &g_501;
        }
lbl_1890:
        l_1537 = ((safe_add_func_uint16_t_u_u_unsafe_macro/*170*//* ___SAFE__OP */(0UL, ((safe_div_func_uint64_t_u_u_unsafe_macro/*171*//* ___SAFE__OP */((l_1523 && (((0L != (((safe_add_func_uint64_t_u_u_unsafe_macro/*172*//* ___SAFE__OP */((~((~(l_1529 = (+65535UL))) && 65527UL)), (l_1530 == ((((((*l_1254) = p_68) == p_68) || p_69) , 0xFE47L) , l_1535)))) ^ (*p_70)) && 0x8CADL)) , (-2L)) == 255UL)), g_1536[2])) == (*l_648)))) | g_399);
        for (l_1518 = 0; (l_1518 <= 1); l_1518 += 1)
        { /* block id: 622 */
            int64_t l_1538[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
            int32_t l_1539 = (-1L);
            int32_t *l_1540 = &l_621;
            int32_t *l_1541 = &l_1537;
            int32_t *l_1542 = &l_621;
            int32_t *l_1543 = &l_801[0];
            int32_t *l_1544[10][5] = {{&g_130,&g_130,&l_1537,&g_130,&l_621},{&l_651,&g_130,(void*)0,&g_130,&l_651},{&l_1537,(void*)0,&g_130,&l_621,(void*)0},{&l_651,&g_130,&g_130,&l_651,&l_621},{&g_130,&l_651,(void*)0,(void*)0,(void*)0},{&l_1537,&l_651,&l_1537,&l_621,&l_651},{(void*)0,&g_130,&l_621,(void*)0,&l_621},{(void*)0,(void*)0,(void*)0,&l_651,&g_130},{&l_1537,&g_130,&l_621,&l_621,&g_130},{&g_130,&g_130,&l_1537,&g_130,&l_621}};
            uint32_t l_1555 = 0xC5515E6CL;
            int8_t l_1594 = 0x1BL;
            uint32_t ***l_1640[8];
            int i, j;
            for (i = 0; i < 8; i++)
                l_1640[i] = &g_1440;
            l_1552[2]--;
            l_1555++;
            for (g_511.f1 = 0; (g_511.f1 <= 1); g_511.f1 += 1)
            { /* block id: 627 */
                int16_t *l_1569 = &g_502;
                int32_t l_1596[7] = {6L,6L,6L,6L,6L,6L,6L};
                int8_t l_1641 = 0xF6L;
                int i;
                p_68 = p_70;
                (*g_1135) = (void*)0;
                for (g_399 = 5; (g_399 >= 1); g_399 -= 1)
                { /* block id: 632 */
                    int32_t *l_1562 = &l_1539;
                    uint8_t *l_1597[9][7] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1396,(void*)0,(void*)0,&g_1396,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1396,(void*)0,(void*)0,&g_1396,(void*)0},{&g_1396,(void*)0,(void*)0,&g_1396,(void*)0,(void*)0,&g_1396},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1396,&g_1396,(void*)0,&g_1396,&g_1396,(void*)0,&g_1396},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1396,(void*)0,(void*)0,&g_1396,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1396,(void*)0,(void*)0,&g_1396,(void*)0}};
                    int i, j;
                    for (l_1505 = 0; (l_1505 <= 5); l_1505 += 1)
                    { /* block id: 635 */
                        union U0 **l_1558 = &g_423;
                        uint8_t *l_1570 = (void*)0;
                        uint8_t *l_1571 = &g_164;
                        int i, j, k;
                        l_1550[l_1505] = (g_1018[l_1518][(g_511.f1 + 2)][l_1505] < ((((void*)0 == l_1558) <= (p_69 , 0xC03FC17EL)) <= ((l_1559[1] , ((safe_add_func_uint8_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */((((void*)0 != l_1562) == (safe_mul_func_int16_t_s_s_unsafe_macro/*174*//* ___SAFE__OP */(((safe_lshift_func_int8_t_s_s_unsafe_macro/*175*//* ___SAFE__OP */((((*l_1571) &= (safe_div_func_uint64_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */((l_1533 != l_1569), 18446744073709551608UL))) && 0x6AL), g_1018[0][3][5])) != p_69), g_251))), p_69)) <= p_69)) < p_71)));
                        (*l_1562) ^= 0L;
                        return p_71;
                    }
                    l_1562 = func_72((((*l_1543) |= ((*l_1562) = ((p_69 >= (((((safe_rshift_func_uint32_t_u_u_unsafe_macro/*177*//* ___SAFE__OP */((((*l_685) = ((g_1536[4] = (0x08L & (+((safe_sub_func_int32_t_s_s_unsafe_macro/*178*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*179*//* ___SAFE__OP */((((((safe_div_func_int16_t_s_s_unsafe_macro/*180*//* ___SAFE__OP */(((((safe_lshift_func_int32_t_s_s_unsafe_macro/*181*//* ___SAFE__OP */((*p_68), 28)) && ((safe_lshift_func_int16_t_s_u_unsafe_macro/*182*//* ___SAFE__OP */(((((safe_sub_func_int64_t_s_s_unsafe_macro/*183*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*184*//* ___SAFE__OP */(((p_69 < ((safe_add_func_int32_t_s_s_unsafe_macro/*185*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u_unsafe_macro/*186*//* ___SAFE__OP */((~((p_69 || 0xB28D594C191AB688LL) > (18446744073709551614UL ^ (((p_71 >= p_69) ^ 0x7791CA7EL) != 5UL)))), 3)), (*p_68))) , (*g_501))) || l_1594), p_69)), p_71)) == g_789) < g_766[1]) < 3UL), 3)) , g_399)) >= l_1595) ^ p_69), (*l_1542))) & 0UL) > (**g_1440)) > (*p_68)) <= 18446744073709551608UL), 9UL)), l_1596[1])) > p_71)))) ^ p_69)) == p_69), (*l_1541))) | 0xB6L) | l_1596[1]) > (*l_1541)) ^ 0xD7852E22L)) >= p_71))) , &l_1546), p_68, p_70, p_69, p_70);
                }
                for (g_913 = 0; (g_913 <= 1); g_913 += 1)
                { /* block id: 649 */
                    int32_t *l_1598 = &l_1539;
                    uint8_t *l_1619 = &g_164;
                    uint64_t *** const *l_1625 = &l_1492;
                    int i, j, k;
                    l_1598 = ((*g_1135) = (void*)0);
                    l_1620 &= ((safe_mul_func_uint64_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */(0xD103D82681777D4BLL, (safe_lshift_func_uint8_t_u_s_unsafe_macro/*188*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*189*//* ___SAFE__OP */(18446744073709551613UL, (safe_rshift_func_int16_t_s_u_unsafe_macro/*190*//* ___SAFE__OP */((g_1018[l_1518][(g_913 + 3)][g_913] >= (((((safe_mod_func_uint64_t_u_u_unsafe_macro/*191*//* ___SAFE__OP */(((0xF7L != g_1018[g_913][(g_913 + 2)][(g_511.f1 + 4)]) ^ ((safe_add_func_uint8_t_u_u_unsafe_macro/*192*//* ___SAFE__OP */(0UL, (g_203[0] == (((*l_1619) = (safe_mul_func_uint8_t_u_u_unsafe_macro/*193*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s_unsafe_macro/*194*//* ___SAFE__OP */(((safe_rshift_func_int16_t_s_u_unsafe_macro/*195*//* ___SAFE__OP */((p_71 | (((*l_1542) = (p_70 != (void*)0)) || p_69)), g_156)) | (*l_1543)), p_71)) || 0x582D1029911C83E7LL), l_1596[1]))) != l_1596[1])))) & p_69)), 0xA8E97D72C7A37075LL)) , &g_785) != (void*)0) && (*p_70)) == g_3)), 3)))), 2)))) & g_251);
                    if (l_1596[2])
                        continue;
                    for (l_1594 = 0; (l_1594 <= 6); l_1594 += 1)
                    { /* block id: 658 */
                        int8_t *l_1626 = &l_902.f0;
                        int i;
                        (*l_1541) ^= ((safe_div_func_int32_t_s_s_unsafe_macro/*196*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*197*//* ___SAFE__OP */((g_61 = ((l_1596[l_1518] <= (0UL > ((((*l_1626) |= (g_977[1][0][4] &= (l_1625 == &g_1265))) && (l_1596[(g_511.f1 + 5)] >= ((--(****g_1264)) || (((*l_1543) &= (*p_70)) < (((safe_add_func_uint16_t_u_u_unsafe_macro/*198*//* ___SAFE__OP */(65529UL, 0L)) > ((safe_mod_func_int32_t_s_s_unsafe_macro/*199*//* ___SAFE__OP */(((safe_unary_minus_func_uint32_t_u_unsafe_macro/*200*//* ___SAFE__OP */((((((safe_rshift_func_uint16_t_u_s_unsafe_macro/*201*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*202*//* ___SAFE__OP */((g_251 , 0x386E8B30L), p_69)), p_71)) , g_1638) != l_1640[2]) | (***g_1121)) >= (-1L)))) > 5UL), l_1641)) >= p_69)) , l_1596[(g_511.f1 + 5)]))))) ^ l_1596[(g_511.f1 + 5)]))) & p_69)), (***g_1121))), p_69)) <= 0x34L);
                    }
                }
            }
        }
        if ((*p_70))
        { /* block id: 669 */
            uint16_t *l_1649 = &l_887;
            uint16_t *l_1650 = (void*)0;
            uint16_t *l_1651 = &g_61;
            int32_t l_1662 = 0x333717C5L;
            int32_t l_1663 = 0x5109944DL;
            int32_t *l_1664 = &l_1546;
            union U0 l_1710 = {0x92L};
            int32_t l_1715 = 0x2806FB3AL;
            int32_t l_1716[9];
            int8_t l_1717 = 0x5CL;
            const uint8_t *l_1725 = &g_1726[6][0][0];
            int i;
            for (i = 0; i < 9; i++)
                l_1716[i] = 0xE71C685FL;
            if (((l_1646 >= (0x2A8DL > (safe_mul_func_uint32_t_u_u_unsafe_macro/*203*//* ___SAFE__OP */(p_71, ((*l_1664) ^= (((*l_1651) = ((*l_1649) = 0x2B1EL)) != ((((g_502 < ((((0xD98D9FC9L == (l_1662 &= (safe_div_func_uint64_t_u_u_unsafe_macro/*204*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*205*//* ___SAFE__OP */(0x2D71L, (safe_mod_func_uint64_t_u_u_unsafe_macro/*206*//* ___SAFE__OP */((++(****g_1264)), (safe_mod_func_int64_t_s_s_unsafe_macro/*207*//* ___SAFE__OP */(p_71, 0x1F2EAE85E898EA43LL)))))), 0x349DE8EFA3E7DA37LL)))) != p_71) < g_448.f0) != p_69)) | l_1663) == 8UL) & l_1663))))))) < 0UL))
            { /* block id: 675 */
                int64_t l_1665 = 6L;
                int32_t *l_1666 = &l_1537;
                int32_t *l_1667 = &l_801[2];
                int32_t *l_1668 = &l_1646;
                int32_t *l_1669 = &l_1537;
                int32_t *l_1670[1];
                uint64_t *l_1701[8] = {&g_854,&g_161,&g_161,&g_161,&g_854,&g_854,&g_161,&g_854};
                union U0 *l_1713 = (void*)0;
                int i;
                for (i = 0; i < 1; i++)
                    l_1670[i] = &l_1550[0];
                l_1671[3][0][3]++;
                l_621 |= (((***g_1121) |= (*l_1664)) != (!(safe_div_func_uint32_t_u_u_unsafe_macro/*208*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*209*//* ___SAFE__OP */(g_766[6], (0x32D8EEC0F0BABC0DLL != ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*210*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*211*//* ___SAFE__OP */((((*l_1667) = (g_913 = (safe_mod_func_uint64_t_u_u_unsafe_macro/*212*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*213*//* ___SAFE__OP */(((((safe_add_func_int8_t_s_s_unsafe_macro/*214*//* ___SAFE__OP */(g_1536[4], (safe_rshift_func_int64_t_s_s_unsafe_macro/*215*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*216*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*217*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*218*//* ___SAFE__OP */((((safe_div_func_uint32_t_u_u_unsafe_macro/*219*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */((l_1701[1] != (void*)0), ((safe_mul_func_uint16_t_u_u_unsafe_macro/*221*//* ___SAFE__OP */((l_1704 != l_1705), ((*l_1649)++))) ^ p_69))), l_1671[0][0][4])) > (*l_1668)) , p_69), p_69)), l_1708[6])), l_1709)) ^ p_71), 45)))) | 65535UL) > p_69) > p_69), (*p_70))), 0x38DF4FDEC0AAD7FCLL)))) == g_3), g_130)), 5)) && p_69)))), p_71))));
                for (g_854 = 1; (g_854 <= 5); g_854 += 1)
                { /* block id: 684 */
                    int i;
                    l_1550[g_854] |= (l_1710 , (-9L));
                    for (g_479.f1 = 28; (g_479.f1 >= 38); ++g_479.f1)
                    { /* block id: 688 */
                        (*l_1668) |= (*l_1664);
                        if ((*p_70))
                            continue;
                        l_1714[5][6] = l_1713;
                    }
                    return p_71;
                }
                g_1718--;
            }
            else
            { /* block id: 696 */
                const uint8_t **l_1727 = &g_767;
                uint8_t *l_1729 = &l_1671[3][0][3];
                (*l_1664) |= (*p_68);
                for (g_161 = 0; (g_161 <= 5); g_161 += 1)
                { /* block id: 700 */
                    int i;
                    return l_1545[g_161];
                }
                (*l_1664) = (0x65DCL || (safe_div_func_uint32_t_u_u_unsafe_macro/*222*//* ___SAFE__OP */(p_69, (safe_mul_func_int64_t_s_s_unsafe_macro/*223*//* ___SAFE__OP */(((g_737 ^= ((***g_1121) = (*g_501))) > 0x495CL), ((0x4475C7E279BBFB6DLL == (((*l_1727) = (l_1725 = &g_164)) == (((*g_1266) == (void*)0) , (l_1729 = l_1728[5][0][5])))) , g_203[1]))))));
            }
        }
        else
        { /* block id: 710 */
            int16_t **l_1736 = &g_501;
            int32_t * const *l_1740 = (void*)0;
            int32_t * const **l_1739[9][5] = {{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740,&l_1740}};
            int32_t * const ***l_1738 = &l_1739[1][3];
            int32_t * const ****l_1737[9] = {&l_1738,&l_1738,&l_1738,&l_1738,&l_1738,&l_1738,&l_1738,&l_1738,&l_1738};
            int16_t ****l_1741 = &l_1126[0][2][2];
            int i, j;
            l_1537 = (safe_div_func_int16_t_s_s_unsafe_macro/*224*//* ___SAFE__OP */((g_976 | (((((&g_563 == ((*l_1315) = l_1732)) >= (((g_1733 = g_1733) == ((p_71 ^ (l_1735 != l_1736)) , l_1737[5])) & (((*l_1741) = &l_1736) != &g_1122))) >= 0x3A4FEFD4L) <= g_1536[3]) & 1UL)), 0x554DL));
            ++l_1742;
            return g_1745[0];
        }
        for (l_1548 = 0; (l_1548 <= 0); l_1548 += 1)
        { /* block id: 720 */
            uint8_t l_1788 = 0xF2L;
            int16_t **l_1790 = &g_501;
            int32_t l_1791 = 0xAF8B2882L;
            int64_t *l_1812 = &g_195;
            uint64_t ****l_1823 = &l_1492;
            int32_t l_1856 = 0x142C8E91L;
            int32_t l_1857[6][10] = {{(-2L),0x494FB22EL,0xF1F63E4AL,0x494FB22EL,(-2L),0x494FB22EL,0xF1F63E4AL,0x494FB22EL,(-2L),0x494FB22EL},{1L,0x494FB22EL,1L,3L,1L,0x494FB22EL,1L,3L,1L,0x494FB22EL},{(-2L),3L,0xF1F63E4AL,3L,(-2L),3L,0xF1F63E4AL,3L,(-2L),3L},{1L,3L,1L,0x494FB22EL,1L,3L,1L,0x494FB22EL,1L,3L},{(-2L),0x494FB22EL,0xF1F63E4AL,0x494FB22EL,(-2L),0x494FB22EL,0xF1F63E4AL,0x494FB22EL,(-2L),0x494FB22EL},{1L,0x494FB22EL,1L,3L,1L,0x494FB22EL,1L,3L,1L,0x494FB22EL}};
            union U1 *l_1861 = &g_1862;
            int32_t l_1889 = 9L;
            union U0 l_1920 = {0L};
            uint32_t **l_1939 = &l_1255[2][0];
            int32_t **l_1970 = &l_1886;
            uint8_t l_1977 = 0xD8L;
            union U0 l_2009 = {0x94L};
            int32_t *l_2078[8] = {&l_1889,&l_1889,&l_1889,&l_1889,&l_1889,&l_1889,&l_1889,&l_1889};
            int i, j;
            for (g_514.f1 = 0; (g_514.f1 <= 2); g_514.f1 += 1)
            { /* block id: 723 */
                int64_t l_1758 = 0x43B6F9B113DDD5BALL;
                int i;
                for (l_1523 = 0; (l_1523 <= 2); l_1523 += 1)
                { /* block id: 726 */
                    union U1 *l_1774[3];
                    union U1 ** const l_1773 = &l_1774[0];
                    union U1 ** const *l_1772 = &l_1773;
                    union U1 ** const **l_1771 = &l_1772;
                    union U1 ** const ***l_1770 = &l_1771;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1774[i] = &g_1775;
                    for (l_1546 = 0; (l_1546 <= 2); l_1546 += 1)
                    { /* block id: 729 */
                        int32_t *l_1748 = &l_651;
                        const int16_t * const ***l_1752 = (void*)0;
                        const int16_t * const ***l_1753[7][4] = {{&l_1750,&l_1750,(void*)0,(void*)0},{&l_1750,&l_1750,&l_1750,&l_1750},{&l_1750,&l_1750,(void*)0,&l_1750},{(void*)0,&l_1750,&l_1750,&l_1750},{&l_1750,&l_1750,&l_1750,(void*)0},{(void*)0,&l_1750,&l_1750,(void*)0},{(void*)0,&l_1750,&l_1750,&l_1750}};
                        int i, j;
                        (*l_1748) = (safe_lshift_func_uint64_t_u_s_unsafe_macro/*225*//* ___SAFE__OP */(g_203[(l_1523 + 5)], g_203[(l_1523 + 5)]));
                        g_129[(l_1548 + 2)] = l_1255[(l_1523 + 1)][l_1548];
                        if (l_1546)
                            goto lbl_1749;
                        l_1758 = ((18446744073709551615UL && ((((g_1754 = l_1750) != (void*)0) >= (+p_69)) != (safe_lshift_func_int16_t_s_s_unsafe_macro/*226*//* ___SAFE__OP */((***g_1121), 9)))) || 0L);
                    }
                    for (l_902.f0 = 0; (l_902.f0 <= 2); l_902.f0 += 1)
                    { /* block id: 738 */
                        union U1 ** const **l_1769 = (void*)0;
                        union U1 ** const ***l_1768 = &l_1769;
                        uint32_t l_1776 = 0x46C6D6BDL;
                        l_1776 = (safe_unary_minus_func_uint64_t_u_unsafe_macro/*227*//* ___SAFE__OP */((((**g_1440)--) || (g_1762[0] == (l_1770 = l_1768)))));
                    }
                }
                if ((safe_lshift_func_int64_t_s_s_unsafe_macro/*228*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*229*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*230*//* ___SAFE__OP */(0x99503F9FL, (safe_lshift_func_uint16_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */((g_203[(l_1548 + 3)] > p_71), p_69)))))), 8)))
                { /* block id: 744 */
                    for (l_1620 = 2; (l_1620 >= 0); l_1620 -= 1)
                    { /* block id: 747 */
                        int i;
                        return g_1536[(g_514.f1 + 2)];
                    }
                }
                else
                { /* block id: 750 */
                    int32_t *l_1784 = &l_1550[0];
                    uint8_t l_1786[7][3] = {{0xBFL,247UL,0xF0L},{0x48L,0x50L,0x48L},{0xCEL,0xBFL,0xF0L},{0x5FL,0x5FL,0x80L},{0xADL,0xBFL,0xBFL},{0x80L,0x50L,8UL},{0xADL,247UL,0xADL}};
                    int i, j;
                    (*l_1784) = (((*l_1491) = (void*)0) != (void*)0);
                    (*l_656) = l_1785;
                    if (l_1786[4][2])
                        break;
                    if (l_1758)
                        break;
                }
                for (l_1529 = 2; (l_1529 >= 0); l_1529 -= 1)
                { /* block id: 759 */
                    int8_t *l_1787 = &g_265.f0;
                    l_1788 |= ((0x8A81L == (p_71 | ((*l_1787) ^= g_203[7]))) <= (*l_648));
                    for (g_158 = 0; (g_158 <= 9); g_158 += 1)
                    { /* block id: 764 */
                        int16_t **l_1789 = &g_501;
                        l_1791 &= (l_1789 != (l_1790 = ((*g_1121) = (*g_1121))));
                    }
                    return p_69;
                }
            }
            for (g_567.f1 = 0; (g_567.f1 <= 2); g_567.f1 += 1)
            { /* block id: 774 */
                uint32_t l_1806[6][3];
                int32_t l_1813 = 0xFBE90C73L;
                int32_t l_1821 = 0x5C814091L;
                int32_t *l_1884[4][2] = {{&l_651,&l_651},{&l_651,&l_651},{&l_651,&l_651},{&l_651,&l_651}};
                uint8_t l_1885[5][10];
                union U0 ****l_1900[10] = {&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082,&g_1082};
                int64_t l_1912 = (-1L);
                int i, j;
                for (i = 0; i < 6; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_1806[i][j] = 18446744073709551610UL;
                }
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 10; j++)
                        l_1885[i][j] = 1UL;
                }
                for (l_1546 = 0; (l_1546 <= 0); l_1546 += 1)
                { /* block id: 777 */
                    int64_t l_1798 = 0x5DA0230C81688E26LL;
                    int32_t l_1803 = 0x6AFED48BL;
                    int32_t l_1804 = (-5L);
                    int32_t l_1805 = (-1L);
                    if (l_1792)
                    { /* block id: 778 */
                        int32_t l_1793 = 0xC8236AD0L;
                        int32_t *l_1794 = &l_1537;
                        int32_t *l_1795 = &l_621;
                        int32_t *l_1796 = (void*)0;
                        int32_t *l_1797 = &l_801[1];
                        int32_t *l_1799 = &l_801[2];
                        int32_t *l_1800 = &l_801[2];
                        int32_t *l_1801 = &l_1550[4];
                        int32_t *l_1802[5][3] = {{&l_1791,&l_1791,&l_1791},{(void*)0,&g_130,(void*)0},{&l_1791,&l_1791,&l_1791},{(void*)0,&g_130,(void*)0},{&l_1791,&l_1791,&l_1791}};
                        int i, j;
                        ++l_1806[3][2];
                        if ((*p_70))
                            break;
                    }
                    else
                    { /* block id: 781 */
                        return p_71;
                    }
                    for (l_902.f0 = 0; (l_902.f0 >= 0); l_902.f0 -= 1)
                    { /* block id: 786 */
                        int32_t *l_1814 = &l_1550[3];
                        int32_t *l_1822 = &l_1646;
                        (*l_1822) |= (safe_div_func_uint64_t_u_u_unsafe_macro/*232*//* ___SAFE__OP */((p_69 ^ l_1788), (p_71 || (((*l_1814) = (l_1813 = ((l_1811[1] , l_1812) != (void*)0))) == (l_1803 = (safe_mul_func_uint8_t_u_u_unsafe_macro/*233*//* ___SAFE__OP */((l_1821 = (safe_add_func_int8_t_s_s_unsafe_macro/*234*//* ___SAFE__OP */((((((((safe_mod_func_int8_t_s_s_unsafe_macro/*235*//* ___SAFE__OP */((((***g_1265) < (*g_1267)) > (((***g_1265) < 0L) , p_69)), 0x03L)) | 0x88L) <= 0xB694L) >= g_1396) != 0L) , g_1745[3]) , g_789), p_71))), 0x54L)))))));
                    }
                }
                if ((*p_68))
                { /* block id: 794 */
                    uint8_t l_1826[1][7] = {{255UL,255UL,255UL,255UL,255UL,255UL,255UL}};
                    int32_t *l_1877 = &l_621;
                    int8_t l_1882 = 0x72L;
                    int i, j;
                    if ((((void*)0 != l_1823) , (safe_add_func_int8_t_s_s_unsafe_macro/*236*//* ___SAFE__OP */(l_1826[0][3], p_69))))
                    { /* block id: 795 */
                        const int32_t l_1852[2] = {(-8L),(-8L)};
                        uint32_t ***l_1869 = (void*)0;
                        uint32_t ****l_1868 = &l_1869;
                        uint32_t l_1883 = 4294967292UL;
                        int32_t *l_1887 = &l_801[2];
                        int32_t **l_1888[4][2] = {{&g_129[2],&g_129[2]},{&g_129[2],&g_129[2]},{&g_129[2],&g_129[2]},{&g_129[2],&g_129[2]}};
                        int i, j;
                        l_1857[5][2] = (safe_div_func_uint16_t_u_u_unsafe_macro/*237*//* ___SAFE__OP */((((((((((l_1788 , (safe_sub_func_int64_t_s_s_unsafe_macro/*238*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*239*//* ___SAFE__OP */((l_1856 ^= (safe_mod_func_int64_t_s_s_unsafe_macro/*240*//* ___SAFE__OP */((g_404 & 1L), ((*l_1812) = (((((safe_mod_func_uint32_t_u_u_unsafe_macro/*241*//* ___SAFE__OP */(((+(***g_1121)) & (safe_add_func_int32_t_s_s_unsafe_macro/*242*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */(((safe_mul_func_uint16_t_u_u_unsafe_macro/*244*//* ___SAFE__OP */(((safe_sub_func_int16_t_s_s_unsafe_macro/*245*//* ___SAFE__OP */((!(safe_sub_func_uint64_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */((((g_161 ^ ((~l_1852[0]) > ((p_69 , (~(((l_1813 |= (l_1791 = (safe_mul_func_uint32_t_u_u_unsafe_macro/*247*//* ___SAFE__OP */(p_71, (p_69 && 0L))))) == 0x53B69877L) ^ g_203[1]))) , p_71))) != p_69) != 0L), p_69))), 65535UL)) , g_158), 0x2036L)) , l_1826[0][3]), (*p_68))), p_71))), (*p_68))) | l_1788) >= g_399) ^ p_69) ^ l_1852[1]))))), 0x230397FF3DFEDB72LL)), 1UL))) , l_1826[0][4]) || l_1852[0]) >= l_1806[3][2]) , 0x0D0FL) ^ (-1L)) < l_1788) < 6UL) || (**g_1440)), l_1852[0]));
                        l_1821 = (0UL < (safe_rshift_func_int8_t_s_s_unsafe_macro/*248*//* ___SAFE__OP */(((~(6L ^ (l_1861 == (g_563 = g_563)))) | (l_1863 | (safe_sub_func_uint8_t_u_u_unsafe_macro/*249*//* ___SAFE__OP */(((g_448.f0 = (safe_mul_func_uint8_t_u_u_unsafe_macro/*250*//* ___SAFE__OP */(p_71, (((*l_1868) = (void*)0) == ((safe_div_func_int64_t_s_s_unsafe_macro/*251*//* ___SAFE__OP */((+(safe_div_func_uint32_t_u_u_unsafe_macro/*252*//* ___SAFE__OP */(p_69, ((l_1791 &= (safe_mul_func_uint16_t_u_u_unsafe_macro/*253*//* ___SAFE__OP */((p_69 && (**g_1266)), 5UL))) , (*p_70))))), 1UL)) , (void*)0))))) & p_69), l_1826[0][1])))), p_69)));
                        l_1889 ^= (((p_68 = (l_1887 = func_72(func_72(l_1886, l_1877, p_68, g_502, p_70), &l_1813, p_70, p_69, l_1255[(g_567.f1 + 1)][l_1548]))) != (void*)0) && (*l_648));
                    }
                    else
                    { /* block id: 811 */
                        return p_71;
                    }
                    return p_71;
                }
                else
                { /* block id: 815 */
                    if (l_1646)
                        goto lbl_1890;
                }
                for (l_1620 = 2; (l_1620 >= 0); l_1620 -= 1)
                { /* block id: 820 */
                    uint32_t *l_1891 = &l_1806[0][0];
                    union U1 *****l_1893 = &l_1304;
                    int32_t l_1910 = 0xD3BBF10FL;
                    if ((g_130 > (((*l_1891) = 6UL) , p_69)))
                    { /* block id: 822 */
                        l_1893 = l_1892;
                    }
                    else
                    { /* block id: 824 */
                        uint32_t l_1911 = 4294967293UL;
                        (*l_1886) = (safe_sub_func_uint16_t_u_u_unsafe_macro/*254*//* ___SAFE__OP */(((void*)0 != &g_1536[3]), (p_71 <= ((safe_add_func_uint8_t_u_u_unsafe_macro/*255*//* ___SAFE__OP */(((((((safe_rshift_func_uint64_t_u_u_unsafe_macro/*256*//* ___SAFE__OP */((l_1900[4] != (void*)0), 7)) >= ((safe_mod_func_int64_t_s_s_unsafe_macro/*257*//* ___SAFE__OP */((0x783F7979230F31A5LL && (~(safe_add_func_int32_t_s_s_unsafe_macro/*258*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*260*//* ___SAFE__OP */((p_71 || ((**g_1122) > 0x5665L)), 28)), l_1889)), l_1857[3][6])))), 6UL)) >= l_1910)) && g_203[1]) <= 0x50L) , l_1911) == l_1912), 1L)) < 0x043DB37AL))));
                    }
                }
                for (g_737 = 2; (g_737 >= 0); g_737 -= 1)
                { /* block id: 830 */
                    uint8_t **l_1919[5][1][2] = {{{&l_1728[5][0][5],&l_1728[5][0][5]}},{{&l_1728[5][0][5],&l_1728[5][0][5]}},{{&l_1728[5][0][5],&l_1728[5][0][5]}},{{&l_1728[5][0][5],&l_1728[5][0][5]}},{{&l_1728[5][0][5],&l_1728[5][0][5]}}};
                    int32_t l_1928[9] = {0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L,0x36E3B488L};
                    int i, j, k;
                    l_1550[4] = ((*l_1886) = 0xBAF558EBL);
                    l_1928[7] = ((safe_div_func_uint32_t_u_u_unsafe_macro/*261*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */(g_1536[4], 2)) , (((((*l_1886) ^= ((safe_mul_func_uint32_t_u_u_unsafe_macro/*263*//* ___SAFE__OP */(4294967287UL, (&l_1885[4][0] == (l_1728[5][0][5] = (void*)0)))) ^ (l_1920 , p_71))) | ((safe_sub_func_int8_t_s_s_unsafe_macro/*264*//* ___SAFE__OP */((*l_648), ((safe_sub_func_uint8_t_u_u_unsafe_macro/*265*//* ___SAFE__OP */(0x66L, (safe_add_func_uint8_t_u_u_unsafe_macro/*266*//* ___SAFE__OP */(0xCCL, (-1L))))) > l_1927))) , (*p_68))) , (*l_1886)) != g_251)), (*p_68))) ^ 0x4FL);
                }
            }
            if (l_1929)
                break;
            if ((l_1857[5][2] , (safe_add_func_uint16_t_u_u_unsafe_macro/*267*//* ___SAFE__OP */(0UL, (((safe_add_func_int16_t_s_s_unsafe_macro/*268*//* ___SAFE__OP */(0x3E9EL, ((***g_1121) = (safe_lshift_func_uint8_t_u_s_unsafe_macro/*269*//* ___SAFE__OP */(p_69, ((((((*l_648) == (safe_div_func_uint64_t_u_u_unsafe_macro/*270*//* ___SAFE__OP */(4UL, ((*l_1812) &= 0xA56CBEAF9F829681LL)))) != 7UL) != (~(1UL || p_69))) , p_69) >= p_71)))))) , 0xB5041B16L) || p_69)))))
            { /* block id: 841 */
                union U0 *l_1942[8][3] = {{&l_902,&l_1920,&g_265},{&g_265,&g_265,&g_265},{(void*)0,&l_902,&g_265},{&g_448,&g_448,&g_448},{&l_1920,&l_902,&l_902},{&g_448,&g_265,&g_448},{&l_1920,&l_1920,&l_1920},{&g_448,&g_448,&g_448}};
                uint32_t ***l_1956 = &l_1254;
                uint32_t ****l_1955[2];
                int32_t l_1962[4][2][6] = {{{(-6L),0xDC41A471L,1L,(-1L),1L,0xDC41A471L},{1L,(-5L),0x847D10C6L,(-1L),0x940DC031L,0x76A5C49FL}},{{(-6L),0x76A5C49FL,0x847D10C6L,0x76A5C49FL,(-6L),0xDC41A471L},{1L,0x76A5C49FL,1L,(-5L),0x940DC031L,(-5L)}},{{1L,(-5L),1L,0x76A5C49FL,1L,(-5L)},{(-6L),0xDC41A471L,1L,(-1L),1L,0xDC41A471L}},{{1L,(-5L),0x847D10C6L,(-1L),0x940DC031L,0x76A5C49FL},{(-6L),0x76A5C49FL,0x847D10C6L,0x76A5C49FL,(-6L),0xDC41A471L}}};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_1955[i] = &l_1956;
                for (l_1929 = 2; (l_1929 >= 0); l_1929 -= 1)
                { /* block id: 844 */
                    const union U0 *l_1943 = &l_1811[1];
                    const union U0 **l_1944 = (void*)0;
                    const union U0 **l_1945 = &l_1943;
                    int8_t *l_1960 = &l_1620;
                    int32_t *l_1961 = &l_1889;
                    (*l_1886) = ((void*)0 != l_1939);
                    (*l_1961) &= (((0x05L ^ ((safe_add_func_int64_t_s_s_unsafe_macro/*271*//* ___SAFE__OP */((l_1942[5][2] == ((*l_1945) = l_1943)), ((((*l_1960) = (safe_lshift_func_int16_t_s_s_unsafe_macro/*272*//* ___SAFE__OP */((~(safe_sub_func_int16_t_s_s_unsafe_macro/*273*//* ___SAFE__OP */((0x92620240L == ((safe_mul_func_int8_t_s_s_unsafe_macro/*274*//* ___SAFE__OP */((((safe_mod_func_int16_t_s_s_unsafe_macro/*275*//* ___SAFE__OP */((((l_1955[1] != &l_1956) < p_71) <= ((**g_1122) , (((safe_add_func_int16_t_s_s_unsafe_macro/*276*//* ___SAFE__OP */((l_1959[0][6] == (void*)0), (*g_501))) ^ l_1791) & p_69))), p_69)) , (-6L)) <= (*l_1886)), g_404)) != l_1857[2][6])), (***g_1121)))), (**g_1122)))) , 8UL) ^ 0x4504E4F7L))) == p_71)) , p_69) <= g_502);
                    for (g_1775.f1 = 0; (g_1775.f1 <= 2); g_1775.f1 += 1)
                    { /* block id: 851 */
                        uint32_t l_1964[7][10][3] = {{{6UL,0xD8CF8F81L,1UL},{0xDC9C3644L,0x3AE91B5CL,18446744073709551610UL},{0xDC9C3644L,1UL,8UL},{6UL,4UL,1UL},{8UL,0x2DE35403L,4UL},{1UL,0xED805D0CL,18446744073709551615UL},{0x4FC31042L,0UL,18446744073709551609UL},{7UL,3UL,5UL},{1UL,0UL,18446744073709551614UL},{18446744073709551614UL,0x0C55F854L,18446744073709551615UL}},{{1UL,18446744073709551615UL,0xAADB0766L},{0UL,0xC4DDC069L,0xC4DDC069L},{0xA90B4253L,0x8518ADA8L,0xBCED0A29L},{0x7C169FDFL,0x3A1ADFABL,1UL},{3UL,0x9D67028CL,1UL},{18446744073709551615UL,0xE71BA1FDL,8UL},{0x648C867CL,0x9D67028CL,18446744073709551612UL},{0xBCED0A29L,0x3A1ADFABL,18446744073709551608UL},{0xAC9279D8L,0x8518ADA8L,0x451EB194L},{18446744073709551615UL,0xC4DDC069L,0UL}},{{0x9D67028CL,18446744073709551615UL,0x1A5DF379L},{0x4679E9F1L,0x8518ADA8L,2UL},{0xAADB0766L,0x34AD13EDL,1UL},{0x4FC31042L,0UL,18446744073709551615UL},{18446744073709551612UL,0UL,0x648C867CL},{0xA90B4253L,0x1638DFF8L,1UL},{6UL,0x4FC31042L,7UL},{1UL,18446744073709551615UL,0xED805D0CL},{18446744073709551610UL,0xD8CF8F81L,3UL},{0x00D68743L,1UL,3UL}},{{0xACCDB0D4L,18446744073709551612UL,0xED805D0CL},{0x3A1ADFABL,1UL,7UL},{3UL,18446744073709551615UL,1UL},{18446744073709551609UL,18446744073709551615UL,0x648C867CL},{1UL,18446744073709551610UL,18446744073709551615UL},{18446744073709551615UL,0xDEDCECA3L,1UL},{0xE0A4EAD3L,0x8A251C19L,2UL},{0x4188E75AL,6UL,0x3A1ADFABL},{18446744073709551610UL,0x3A1ADFABL,0x34AD13EDL},{6UL,18446744073709551610UL,6UL}},{{0x648C867CL,0xED805D0CL,3UL},{0x3AE91B5CL,18446744073709551611UL,0x4A0327C1L},{1UL,0x2DE35403L,0x1A5DF379L},{0xB7344B7DL,0UL,0xD8CF8F81L},{1UL,0x6EC9A6D1L,5UL},{0x3AE91B5CL,18446744073709551609UL,0x2DE35403L},{0x648C867CL,7UL,0xB583DE69L},{6UL,0x9D67028CL,18446744073709551615UL},{18446744073709551610UL,6UL,1UL},{0x4188E75AL,18446744073709551609UL,18446744073709551613UL}},{{0xE0A4EAD3L,0x0C55F854L,0x4188E75AL},{18446744073709551615UL,1UL,0x7602EAFDL},{1UL,0xAC9279D8L,0x451EB194L},{18446744073709551609UL,5UL,18446744073709551615UL},{3UL,0xE71BA1FDL,0x9D67028CL},{0x3A1ADFABL,0x73604548L,18446744073709551613UL},{0xACCDB0D4L,0x77995B69L,1UL},{0x00D68743L,0x77995B69L,8UL},{18446744073709551610UL,0x73604548L,18446744073709551612UL},{1UL,0xE71BA1FDL,18446744073709551612UL}},{{6UL,5UL,0x4FC31042L},{0xA90B4253L,0xAC9279D8L,0xE0A4EAD3L},{18446744073709551612UL,1UL,8UL},{0x4FC31042L,0x0C55F854L,18446744073709551609UL},{0xAADB0766L,18446744073709551609UL,0x3AE91B5CL},{0xC839F3A8L,6UL,0xBC50F042L},{1UL,0x9D67028CL,0UL},{7UL,7UL,1UL},{0xA8014BCBL,18446744073709551609UL,0UL},{0x2DE35403L,0x6EC9A6D1L,1UL}}};
                        int i, j, k;
                        --l_1964[2][6][2];
                    }
                }
            }
            else
            { /* block id: 855 */
                const int16_t * const ***l_1968 = &l_1750;
                const int16_t * const ****l_1967[10][10] = {{&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968},{&l_1968,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968},{&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968},{(void*)0,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,(void*)0,&l_1968},{&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968},{&l_1968,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968},{&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968},{(void*)0,&l_1968,&l_1968,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,(void*)0,&l_1968},{&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968},{&l_1968,&l_1968,&l_1968,&l_1968,(void*)0,&l_1968,(void*)0,&l_1968,&l_1968,&l_1968}};
                int32_t *l_1971 = &g_130;
                int32_t *l_1972 = &g_130;
                int32_t *l_1973 = (void*)0;
                int32_t *l_1974 = &l_621;
                int32_t *l_1975[9] = {(void*)0,&l_1546,&l_1546,(void*)0,&l_1546,&l_1546,(void*)0,&l_1546,&l_1546};
                int i, j;
                g_1969 = &l_1750;
                (*l_1886) &= ((void*)0 == l_1970);
                ++l_1977;
            }
            for (g_161 = 0; (g_161 <= 2); g_161 += 1)
            { /* block id: 862 */
                int32_t *l_1980 = &l_1646;
                int32_t *l_1981 = &l_1550[0];
                int32_t *l_1982[3];
                int32_t *** const *l_1989[7] = {&g_642,&g_642,&g_642,&g_642,&g_642,&g_642,&g_642};
                union U0 l_2027 = {1L};
                int i;
                for (i = 0; i < 3; i++)
                    l_1982[i] = (void*)0;
                --l_1984;
                for (p_71 = 0; (p_71 <= 2); p_71 += 1)
                { /* block id: 866 */
                    int64_t l_1999 = (-10L);
                    int32_t l_2000 = 4L;
                    int32_t l_2001 = 0x62CD1535L;
                    int32_t l_2002 = (-1L);
                    union U0 l_2026 = {0x9FL};
                    uint32_t ***l_2031 = &l_1939;
                    uint32_t ****l_2030 = &l_2031;
                    uint32_t *****l_2029 = &l_2030;
                    (*l_1980) = (safe_sub_func_uint8_t_u_u_unsafe_macro/*277*//* ___SAFE__OP */(p_71, ((void*)0 != l_1989[3])));
                    if ((l_1546 = ((safe_sub_func_uint32_t_u_u_unsafe_macro/*278*//* ___SAFE__OP */((**g_1440), ((*l_1886) = (safe_add_func_int16_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */((g_203[1] , ((l_1994 , p_69) <= ((*l_1980) |= ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*280*//* ___SAFE__OP */(p_69, (safe_add_func_uint32_t_u_u_unsafe_macro/*281*//* ___SAFE__OP */((l_2003[1][0]++), l_2000)))) <= 0x936EL)))), ((((*p_70) || ((4294967289UL >= (*p_68)) , l_2006[5])) < 255UL) != (***g_1265))))))) > (-1L))))
                    { /* block id: 872 */
                        return p_71;
                    }
                    else
                    { /* block id: 874 */
                        union U1 *l_2011 = &g_2012;
                        union U1 *l_2013 = &g_2014;
                        const int32_t l_2017 = 1L;
                        int i, j, k;
                        (*l_1886) = (((((safe_div_func_uint8_t_u_u_unsafe_macro/*282*//* ___SAFE__OP */(((l_2009 , (safe_unary_minus_func_int16_t_s_unsafe_macro/*283*//* ___SAFE__OP */(((*l_1981) = ((l_2013 = (l_2011 = (void*)0)) == (void*)0))))) | ((l_2028 = (l_2027 = ((safe_mod_func_int32_t_s_s_unsafe_macro/*284*//* ___SAFE__OP */(((((l_2009 , (*l_1886)) , p_71) , l_2017) <= 4294967295UL), (((((safe_mul_func_uint64_t_u_u_unsafe_macro/*285*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*286*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*287*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*288*//* ___SAFE__OP */(l_2001, l_2017)), 7UL)), l_2000)), (**g_1266))) | g_1018[0][3][5]) != g_203[1]) , 0x774F262AL) & (-8L)))) , l_2026))) , (**l_1970))), 3L)) | 0xC0L) <= 1L) & p_71) & p_69);
                    }
                    (*l_2029) = (void*)0;
                }
                for (l_1977 = 0; (l_1977 <= 2); l_1977 += 1)
                { /* block id: 886 */
                    uint32_t l_2049[7][8][2] = {{{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L}},{{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL}},{{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL}},{{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L}},{{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL}},{{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL}},{{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L},{0xCC264C71L,18446744073709551611UL},{0x3091F159L,18446744073709551611UL},{0xCC264C71L,0x070AC1F7L}}};
                    int32_t l_2056 = 0x968A129BL;
                    int32_t l_2073 = 0xE0C23C9EL;
                    int32_t l_2074[2][10];
                    int32_t l_2080 = (-3L);
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_2074[i][j] = 0x85233F3BL;
                    }
                    for (l_1994 = 2; (l_1994 >= 0); l_1994 -= 1)
                    { /* block id: 889 */
                        union U0 *** const *l_2048 = &g_1082;
                        int i, j, k;
                        (*l_1981) = (*p_70);
                        (*l_1980) = (safe_lshift_func_int32_t_s_s_unsafe_macro/*289*//* ___SAFE__OP */((0x12L | (safe_rshift_func_int64_t_s_s_unsafe_macro/*290*//* ___SAFE__OP */(0L, (((safe_mod_func_int16_t_s_s_unsafe_macro/*291*//* ___SAFE__OP */((p_70 != (((((((*l_1981) > ((safe_mul_func_int64_t_s_s_unsafe_macro/*292*//* ___SAFE__OP */(((((safe_sub_func_int8_t_s_s_unsafe_macro/*293*//* ___SAFE__OP */(((*l_1981) | ((**l_1970) = (safe_mul_func_uint16_t_u_u_unsafe_macro/*294*//* ___SAFE__OP */(p_71, (safe_mod_func_uint32_t_u_u_unsafe_macro/*295*//* ___SAFE__OP */((((l_1920 , ((void*)0 != l_2048)) | p_69) || p_71), (*p_70))))))), g_906)) | 1UL) <= (**g_1266)) & p_71), g_1745[3])) , l_2049[3][4][1])) > p_71) > 0UL) & p_69) | p_69) , (void*)0)), (***g_1121))) , l_2049[3][4][1]) ^ (*l_648))))), 18));
                    }
                    for (g_737 = 5; (g_737 >= 0); g_737 -= 1)
                    { /* block id: 896 */
                        int32_t l_2077 = 1L;
                        int i;
                        l_2074[1][4] &= ((safe_lshift_func_uint8_t_u_u_unsafe_macro/*296*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_u_unsafe_macro/*297*//* ___SAFE__OP */((l_2056 = 0x69977BE3758DDC8BLL), (**g_1266))), (((safe_lshift_func_int16_t_s_u_unsafe_macro/*298*//* ___SAFE__OP */(((((g_1396 = ((((void*)0 == &l_1823) ^ l_2049[3][4][1]) <= g_448.f0)) || g_1726[2][0][0]) || (safe_div_func_uint64_t_u_u_unsafe_macro/*299*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*300*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*301*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*302*//* ___SAFE__OP */((((safe_lshift_func_int32_t_s_u_unsafe_macro/*303*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*304*//* ___SAFE__OP */((l_2049[6][2][1] <= ((safe_add_func_int16_t_s_s_unsafe_macro/*305*//* ___SAFE__OP */((-1L), 0x34C3L)) | p_69)), p_71)), p_71)) < (*l_648)) <= g_61), p_71)), (-3L))), l_2049[3][4][1])), (*l_648)))) , 0x6819L), 1)) | p_71) <= l_2073))) || 0UL);
                    }
                    g_2081++;
                }
                for (l_1518 = 0; (l_1518 <= 2); l_1518 += 1)
                { /* block id: 909 */
                    int64_t l_2084 = (-7L);
                    return l_2084;
                }
            }
        }
    }
    for (g_511.f1 = 0; (g_511.f1 <= 18); g_511.f1 = safe_add_func_uint16_t_u_u_unsafe_macro/*306*//* ___SAFE__OP */(g_511.f1, 9))
    { /* block id: 917 */
        return g_976;
    }
    if (l_1505)
        goto lbl_1749;
    return g_195;
}


/* ------------------------------------------ */
/* 
 * reads : g_164 g_158 g_154 g_3 g_61 g_156 l_66
 * writes: g_154 g_164 g_61
 */
static int32_t * func_72(int32_t * p_73, int32_t * p_74, int32_t * const  p_75, uint32_t  p_76, int32_t * p_77)
{ /* block id: 196 */
    int32_t **l_576[2][8][5] = {{{&g_129[0],&g_129[1],&g_129[1],&g_154,&g_129[0]},{&g_129[0],&g_129[0],&g_129[2],&g_129[0],&g_129[0]},{&g_129[0],&g_129[2],&g_129[2],&g_129[0],&g_129[2]},{&g_129[1],&g_129[0],&g_129[2],&g_154,&g_129[1]},{&g_154,&g_154,&g_154,&g_129[0],&g_129[2]},{&g_154,&g_129[1],&g_154,&g_154,&g_129[1]},{(void*)0,&g_129[0],(void*)0,&g_129[0],&g_129[1]},{&g_154,&g_129[0],&g_129[0],&g_129[0],&g_129[2]}},{{&g_129[0],&g_129[0],&g_129[0],&g_129[1],&g_129[1]},{&g_154,(void*)0,&g_154,&g_129[0],&g_129[2]},{(void*)0,(void*)0,&g_129[0],&g_129[0],&g_129[0]},{&g_154,&g_129[0],&g_129[1],&g_129[0],(void*)0},{&g_154,&g_129[0],&g_129[0],&g_129[0],&g_154},{&g_129[1],&g_129[0],&g_154,&g_129[0],&g_129[0]},{&g_129[0],&g_129[1],&g_129[0],&g_129[0],&g_154},{&g_129[0],&g_154,&g_129[0],&g_129[0],&g_129[0]}}};
    int32_t *l_577[9][7][4] = {{{&g_130,&g_130,&g_130,&g_130},{&g_130,&g_130,&g_3,&g_3},{&g_3,&g_130,&g_3,&g_3},{(void*)0,&g_3,(void*)0,&g_130},{(void*)0,&g_130,&g_130,&g_3},{&g_3,&g_3,&g_3,&g_130},{&g_130,&g_130,&g_3,&g_130}},{{&g_3,&g_3,&g_130,&g_130},{(void*)0,&g_3,(void*)0,&g_3},{(void*)0,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,&g_3},{&g_130,&g_3,&g_130,&g_130},{&g_130,&g_130,(void*)0,&g_3},{&g_3,&g_130,&g_130,&g_3}},{{&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_130,&g_3,&g_130},{&g_130,(void*)0,(void*)0,&g_130},{&g_3,&g_130,(void*)0,(void*)0},{(void*)0,&g_3,&g_130,&g_3},{&g_130,&g_130,(void*)0,&g_3},{&g_3,&g_130,&g_3,&g_130}},{{&g_3,&g_3,(void*)0,&g_3},{&g_130,(void*)0,&g_130,&g_3},{&g_130,&g_3,&g_130,&g_3},{&g_130,&g_3,&g_3,&g_130},{&g_130,&g_3,&g_3,&g_130},{(void*)0,&g_130,&g_3,&g_130},{(void*)0,&g_3,&g_3,&g_3}},{{&g_130,&g_130,&g_3,&g_130},{&g_130,&g_3,(void*)0,&g_130},{&g_130,(void*)0,&g_130,(void*)0},{&g_130,&g_130,(void*)0,&g_130},{&g_130,(void*)0,&g_3,&g_130},{&g_130,&g_3,&g_3,&g_3},{&g_130,&g_130,&g_3,&g_3}},{{&g_3,&g_3,&g_130,&g_3},{&g_130,&g_130,(void*)0,&g_130},{&g_3,&g_130,&g_3,&g_3},{&g_130,&g_3,&g_3,&g_3},{&g_3,&g_130,&g_3,&g_3},{&g_3,&g_3,&g_130,&g_130},{&g_3,(void*)0,&g_3,&g_130}},{{&g_3,&g_130,&g_3,(void*)0},{&g_3,(void*)0,&g_130,&g_130},{&g_3,(void*)0,&g_3,&g_130},{&g_130,&g_3,&g_130,&g_3},{&g_3,(void*)0,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_130},{&g_3,&g_3,&g_130,&g_3}},{{&g_130,&g_130,&g_3,&g_3},{&g_3,&g_3,&g_130,&g_3},{&g_3,&g_130,&g_3,&g_130},{&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_130,(void*)0},{&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_130}},{{&g_130,&g_130,&g_3,&g_130},{&g_3,&g_3,(void*)0,&g_130},{&g_130,&g_130,&g_130,&g_130},{&g_3,&g_3,&g_3,&g_3},{&g_130,&g_3,&g_3,(void*)0},{&g_130,&g_3,&g_3,(void*)0},{&g_130,&g_3,(void*)0,&g_130}}};
    int32_t *** const l_599[4][1] = {{&l_576[0][6][3]},{&l_576[1][3][3]},{&l_576[0][6][3]},{&l_576[1][3][3]}};
    int32_t *** const *l_598 = &l_599[1][0];
    int32_t *** const **l_597 = &l_598;
    uint8_t *l_600 = &g_164;
    uint64_t *l_611 = &g_161;
    uint16_t *l_612 = (void*)0;
    uint16_t *l_613 = (void*)0;
    uint16_t *l_614 = &g_61;
    int32_t l_615 = 1L;
    int i, j, k;
    g_154 = (l_577[6][5][0] = p_74);
    l_615 |= (safe_add_func_uint8_t_u_u_unsafe_macro/*307*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s_unsafe_macro/*308*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*309*//* ___SAFE__OP */(0x5AB7L, ((*l_614) ^= ((safe_div_func_uint16_t_u_u_unsafe_macro/*310*//* ___SAFE__OP */((safe_unary_minus_func_uint16_t_u_unsafe_macro/*311*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*312*//* ___SAFE__OP */(p_76, ((safe_rshift_func_int8_t_s_s_unsafe_macro/*313*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*314*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*315*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u_unsafe_macro/*316*//* ___SAFE__OP */((l_597 != &g_557), 13)) != (++(*l_600))), g_158)), (safe_lshift_func_int8_t_s_u_unsafe_macro/*317*//* ___SAFE__OP */((1L && (safe_div_func_uint8_t_u_u_unsafe_macro/*318*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*319*//* ___SAFE__OP */(((safe_sub_func_uint32_t_u_u_unsafe_macro/*320*//* ___SAFE__OP */(((void*)0 != l_611), (*g_154))) , 0L), (*p_74))), p_76))), 6)))), p_76)) | g_158))))), 0x562EL)) | p_76)))) | p_76), p_76)) & g_156), 250UL));
    return p_77;
}


/* ------------------------------------------ */
/* 
 * reads : g_120 g_156 g_158 g_3 g_130 g_161 g_164 g_154 g_61 g_203 g_195 g_265.f0 g_362 g_384 g_251 g_399 g_404 g_420 g_448 g_498 g_501 g_448.f0 g_542 g_502 g_556 g_517 g_563
 * writes: g_120 g_129 g_153 g_158 g_161 g_164 g_130 g_195 g_203 g_251 g_265.f0 g_399 g_423 g_61 g_404 g_154 g_512.f1
 */
static int32_t * func_78(int8_t  p_79, int32_t * p_80, uint16_t  p_81, int8_t  p_82)
{ /* block id: 11 */
    int32_t l_108 = 0x2CCD07D1L;
    int32_t *l_109 = &l_108;
    int32_t *l_110 = &l_108;
    int32_t *l_111 = (void*)0;
    int32_t *l_112 = &l_108;
    int32_t *l_113 = &l_108;
    int32_t *l_114 = &l_108;
    int32_t *l_115 = &l_108;
    int32_t *l_116 = &l_108;
    int32_t *l_117 = &l_108;
    int32_t *l_118[7][1] = {{&l_108},{&l_108},{&l_108},{&l_108},{&l_108},{&l_108},{&l_108}};
    int8_t l_119 = 1L;
    uint16_t l_159 = 0UL;
    const union U0 l_197 = {0L};
    int32_t l_227 = 7L;
    union U0 *l_264[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    union U0 **l_263 = &l_264[0];
    union U0 ***l_262[10][9] = {{&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,(void*)0},{&l_263,(void*)0,&l_263,(void*)0,&l_263,&l_263,(void*)0,&l_263,(void*)0},{&l_263,&l_263,&l_263,&l_263,&l_263,(void*)0,&l_263,&l_263,(void*)0},{&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,(void*)0,&l_263,(void*)0},{(void*)0,&l_263,&l_263,(void*)0,&l_263,(void*)0,&l_263,&l_263,&l_263},{(void*)0,&l_263,&l_263,&l_263,&l_263,&l_263,(void*)0,&l_263,&l_263},{&l_263,(void*)0,(void*)0,&l_263,(void*)0,&l_263,&l_263,&l_263,&l_263},{(void*)0,&l_263,(void*)0,&l_263,&l_263,(void*)0,&l_263,(void*)0,&l_263},{&l_263,&l_263,&l_263,(void*)0,(void*)0,&l_263,&l_263,(void*)0,(void*)0},{&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,&l_263,&l_263}};
    uint8_t *l_305 = (void*)0;
    uint8_t *l_306 = &g_164;
    uint32_t *l_400 = &g_158;
    uint32_t l_499[7][4] = {{1UL,0x44963142L,0x44963142L,1UL},{0x244D8428L,0x44963142L,1UL,0x44963142L},{0x44963142L,18446744073709551609UL,1UL,1UL},{0x244D8428L,0x244D8428L,0x44963142L,1UL},{1UL,18446744073709551609UL,1UL,0x44963142L},{1UL,0x44963142L,0x44963142L,1UL},{0x244D8428L,0x44963142L,1UL,0x44963142L}};
    int32_t **** const l_524 = (void*)0;
    const int32_t l_531 = 0L;
    int64_t *l_534 = &g_195;
    int32_t l_560[7] = {6L,6L,6L,6L,6L,6L,6L};
    union U1 *l_566 = &g_567;
    int i, j;
    g_120++;
    if ((p_82 , ((&l_108 == &l_108) && (*l_109))))
    { /* block id: 13 */
        int32_t **l_127 = &l_109;
        int32_t **l_128[5][10][1] = {{{&l_111},{&l_111},{&l_118[6][0]},{&l_113},{&l_118[6][0]},{&l_111},{&l_111},{&l_111},{&l_111},{&l_118[6][0]}},{{&l_113},{&l_118[6][0]},{&l_111},{&l_111},{&l_111},{&l_111},{&l_118[6][0]},{&l_113},{&l_118[6][0]},{&l_111}},{{&l_111},{&l_111},{&l_111},{&l_118[6][0]},{&l_113},{&l_118[6][0]},{&l_111},{&l_111},{&l_111},{&l_111}},{{&l_118[6][0]},{&l_113},{&l_118[6][0]},{&l_111},{&l_111},{&l_111},{&l_111},{&l_118[6][0]},{&l_113},{&l_118[6][0]}},{{&l_111},{&l_111},{&l_111},{&l_111},{&l_118[6][0]},{&l_113},{&l_118[6][0]},{&l_111},{&l_111},{&l_111}}};
        int32_t ***l_152[3];
        int32_t **l_155 = (void*)0;
        uint32_t *l_157 = &g_158;
        uint64_t *l_160 = &g_161;
        uint8_t *l_162 = (void*)0;
        uint8_t *l_163[6];
        int16_t l_165 = 0x3380L;
        union U0 *l_447 = &g_448;
        union U1 *l_478 = &g_479;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_152[i] = &l_128[2][7][0];
        for (i = 0; i < 6; i++)
            l_163[i] = &g_164;
        (*g_154) = ((safe_sub_func_uint8_t_u_u_unsafe_macro/*321*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*322*//* ___SAFE__OP */(7L, (g_164 |= (((*l_113) = (((*l_160) ^= ((((*l_127) = p_80) != (g_129[0] = &l_108)) != (safe_lshift_func_int16_t_s_u_unsafe_macro/*323*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*324*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*325*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*326*//* ___SAFE__OP */((*l_114), 31)), (safe_mod_func_int16_t_s_s_unsafe_macro/*327*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_u_unsafe_macro/*328*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*329*//* ___SAFE__OP */(g_120, 250UL)), (((safe_add_func_uint32_t_u_u_unsafe_macro/*330*//* ___SAFE__OP */(((safe_div_func_uint8_t_u_u_unsafe_macro/*331*//* ___SAFE__OP */((!0x58FFL), (((((((*l_157) ^= (safe_lshift_func_uint8_t_u_u_unsafe_macro/*332*//* ___SAFE__OP */(((g_153 = (void*)0) != l_155), g_156))) | l_159) , p_82) ^ 0xD5L) & p_82) ^ (*l_113)))) , g_3), (*l_116))) ^ (*l_115)) , g_120))), g_130)))), p_82)), (*l_112))))) , (*l_115))) , 0xF1L)))), 0x3AL)) , l_165);
        for (g_120 = (-21); (g_120 < 38); ++g_120)
        { /* block id: 24 */
            int8_t *l_174[5] = {&l_119,&l_119,&l_119,&l_119,&l_119};
            int32_t l_201 = (-5L);
            uint32_t l_202 = 0x4ADEF71BL;
            int32_t l_214 = 1L;
            uint8_t l_228 = 254UL;
            int32_t l_231 = (-1L);
            int32_t l_236 = 0L;
            int32_t l_237 = 0x07284809L;
            union U0 ***l_266 = &l_263;
            uint64_t **l_294 = &l_160;
            int32_t *l_298 = &l_227;
            int16_t l_351 = 0x4DCDL;
            uint16_t *l_401 = &g_61;
            uint64_t l_405 = 1UL;
            uint16_t l_438[6][1] = {{65527UL},{6UL},{65527UL},{65527UL},{6UL},{65527UL}};
            int64_t l_466[8][7][4] = {{{5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L},{0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL},{5L,5L,0x898DAF1AD423761DLL,5L},{5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L},{0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL},{5L,5L,0x898DAF1AD423761DLL,5L},{5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L}},{{0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL},{5L,5L,0x898DAF1AD423761DLL,5L},{5L,0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL}},{{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL}},{{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL}},{{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL}},{{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL}},{{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL}},{{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL},{0x97663FD43EE1FDABLL,0x97663FD43EE1FDABLL,5L,0x97663FD43EE1FDABLL},{0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL},{0x898DAF1AD423761DLL,0x97663FD43EE1FDABLL,0x898DAF1AD423761DLL,0x898DAF1AD423761DLL}}};
            int32_t l_471[8][7][4] = {{{0xB4E5E8EEL,0x22E72E4BL,0xB4E5E8EEL,0L},{0x81A60374L,0L,0xFC8E7367L,0L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,5L},{0xB4E5E8EEL,0L,0x9BE886D3L,5L},{(-1L),0x2FCAD346L,0x059BF69FL,0L},{0xFC8E7367L,0x4874BAACL,0x059BF69FL,0x4874BAACL},{(-1L),0L,0x9BE886D3L,0x22E72E4BL},{0xB4E5E8EEL,0L,0xFCF1142FL,0x4874BAACL},{0xFCF1142FL,0x4874BAACL,(-1L),0L}},{{0xFCF1142FL,0x2FCAD346L,0xFCF1142FL,0x22E72E4BL},{0xFCF1142FL,5L,0x059BF69FL,0x22E72E4BL},{0x81A60374L,1L,(-1L),5L},{0x9BE886D3L,0L,(-1L),0L},{0x81A60374L,0L,0x059BF69FL,0x2FCAD346L},{0xFCF1142FL,0L,0xFC8E7367L,0L},{0xFC8E7367L,0L,0x81A60374L,5L}}};
            union U1 *l_510[9] = {&g_514,&g_512,&g_514,&g_512,&g_514,&g_512,&g_514,&g_512,&g_514};
            int i, j, k;
            if ((((*g_154) < ((g_164 | (safe_lshift_func_int16_t_s_u_unsafe_macro/*333*//* ___SAFE__OP */((*l_110), 10))) > (((*l_157) &= (safe_add_func_int8_t_s_s_unsafe_macro/*334*//* ___SAFE__OP */((p_82 = (((0xE4526E093E1FD80DLL > (safe_rshift_func_int8_t_s_u_unsafe_macro/*335*//* ___SAFE__OP */(g_3, 2))) < p_79) <= (((void*)0 == &g_164) || p_79))), 0x93L))) <= (-1L)))) , 0L))
            { /* block id: 27 */
                int64_t *l_194[10][1] = {{&g_195},{&g_195},{&g_195},{&g_195},{&g_195},{&g_195},{&g_195},{&g_195},{&g_195},{&g_195}};
                int32_t l_196 = 0L;
                int32_t ***l_200 = &l_155;
                int32_t l_204 = 1L;
                int i, j;
                l_204 |= ((*g_154) = (safe_sub_func_int8_t_s_s_unsafe_macro/*336*//* ___SAFE__OP */((g_203[1] &= (p_79 = (safe_lshift_func_uint8_t_u_u_unsafe_macro/*337*//* ___SAFE__OP */((((g_195 = (safe_mod_func_uint8_t_u_u_unsafe_macro/*338*//* ___SAFE__OP */(g_61, (safe_unary_minus_func_int16_t_s_unsafe_macro/*339*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*340*//* ___SAFE__OP */((((*l_117) = (((safe_add_func_int8_t_s_s_unsafe_macro/*341*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*342*//* ___SAFE__OP */(g_158, (safe_sub_func_uint64_t_u_u_unsafe_macro/*343*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*344*//* ___SAFE__OP */((p_82 = ((safe_rshift_func_int64_t_s_u_unsafe_macro/*345*//* ___SAFE__OP */((l_110 == (void*)0), 15)) != (((l_196 = (-10L)) || (l_197 , ((*l_160) |= (safe_div_func_int32_t_s_s_unsafe_macro/*346*//* ___SAFE__OP */((((((void*)0 != l_200) < 0xAB1F273FL) == 0UL) | (*l_114)), l_201))))) || l_202))), p_79)), p_81)))), g_158)) & g_158) | p_81)) && (*l_115)), 4))))))) != g_164) , p_79), p_79)))), 0xFCL)));
            }
            else
            { /* block id: 37 */
                uint8_t l_215[2];
                int64_t *l_223 = (void*)0;
                int32_t l_224 = (-1L);
                int32_t l_233 = (-5L);
                int32_t l_234[7][2];
                const union U0 *l_245 = &l_197;
                const union U0 * const *l_244 = &l_245;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_215[i] = 6UL;
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_234[i][j] = 0xB37FBF51L;
                }
                for (p_81 = 0; (p_81 <= 0); p_81 += 1)
                { /* block id: 40 */
                    union U0 l_208 = {0x13L};
                    union U0 *l_209 = &l_208;
                    int32_t l_222 = 0xB20BFAB2L;
                    uint16_t *l_225 = (void*)0;
                    uint16_t *l_226 = &l_159;
                    int32_t l_229 = 0x4DADB69EL;
                    int32_t l_232[1][8] = {{1L,1L,1L,1L,1L,1L,1L,1L}};
                    const union U0 * const **l_246 = (void*)0;
                    const union U0 * const **l_247 = &l_244;
                    int i, j;
                    if (((safe_lshift_func_uint8_t_u_u_unsafe_macro/*347*//* ___SAFE__OP */(((!(((((*l_209) = l_208) , (safe_add_func_uint64_t_u_u_unsafe_macro/*348*//* ___SAFE__OP */(18446744073709551610UL, (p_79 || (safe_add_func_uint8_t_u_u_unsafe_macro/*349*//* ___SAFE__OP */((g_61 & (l_215[1]--)), p_81)))))) <= ((((safe_lshift_func_uint16_t_u_u_unsafe_macro/*350*//* ___SAFE__OP */(((*l_226) |= (((((4294967293UL >= (((*l_157) = ((safe_mul_func_uint64_t_u_u_unsafe_macro/*351*//* ___SAFE__OP */((&g_156 != ((l_222 > ((*l_117) |= (p_79 , 0x2A3D4019L))) , l_223)), g_164)) <= l_224)) , (*p_80))) , (*p_80)) != (-7L)) >= g_161) >= 18446744073709551609UL)), p_82)) == l_224) > l_227) != (**l_127))) , l_228)) , g_156), l_229)) == l_224))
                    { /* block id: 46 */
                        int32_t l_230 = 0L;
                        int32_t l_235[3];
                        uint8_t l_238 = 1UL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_235[i] = 0x958433A3L;
                        (*l_116) = (1L | p_82);
                        if ((*g_154))
                            break;
                        if (l_214)
                            continue;
                        --l_238;
                    }
                    else
                    { /* block id: 51 */
                        uint32_t l_241[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_241[i] = 0UL;
                        l_241[0]--;
                        if (l_229)
                            continue;
                        (*l_117) = 2L;
                        (*l_116) = (0x990CL > 3UL);
                    }
                    (*l_247) = l_244;
                    for (l_228 = 0; (l_228 <= 0); l_228 += 1)
                    { /* block id: 60 */
                        int64_t *l_250 = &g_195;
                        int32_t l_278[1][7][9] = {{{0x72E7577DL,8L,1L,7L,0xE0DAC7CBL,4L,4L,0xE0DAC7CBL,7L},{(-1L),0xB5C4C33CL,(-1L),0xF9871668L,(-1L),8L,1L,0xE0DAC7CBL,0L},{0xB5C4C33CL,1L,0x86A70711L,0L,1L,(-8L),7L,(-8L),1L},{0xF9871668L,7L,7L,0xF9871668L,1L,3L,(-8L),5L,1L},{5L,(-1L),(-8L),7L,4L,0L,(-1L),(-1L),0L},{1L,(-3L),0xF9871668L,(-3L),1L,5L,(-1L),(-8L),7L},{1L,3L,(-8L),5L,1L,(-1L),0xE0DAC7CBL,8L,0xE0DAC7CBL}}};
                        const uint32_t *l_281 = (void*)0;
                        uint64_t ***l_295 = &l_294;
                        int i, j, k;
                        l_278[0][6][1] = ((*l_117) = ((safe_lshift_func_int32_t_s_u_unsafe_macro/*352*//* ___SAFE__OP */((((g_251 = ((*l_250) &= p_81)) > ((safe_add_func_uint16_t_u_u_unsafe_macro/*353*//* ___SAFE__OP */((p_82 < ((safe_add_func_uint16_t_u_u_unsafe_macro/*354*//* ___SAFE__OP */(65528UL, (safe_add_func_uint32_t_u_u_unsafe_macro/*355*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*356*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*357*//* ___SAFE__OP */((l_262[4][3] != (g_164 , l_266)), ((safe_sub_func_int16_t_s_s_unsafe_macro/*358*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*359*//* ___SAFE__OP */((+((g_265.f0 = (safe_div_func_uint32_t_u_u_unsafe_macro/*360*//* ___SAFE__OP */(4294967293UL, (safe_mul_func_int16_t_s_s_unsafe_macro/*361*//* ___SAFE__OP */((((((((safe_sub_func_uint64_t_u_u_unsafe_macro/*362*//* ___SAFE__OP */(6UL, p_82)) , (void*)0) != (void*)0) > 0x31L) , 1UL) <= 0x35L) , l_202), p_82))))) | 0x19L)), g_156)), l_278[0][3][5])) != 0x8365L))), p_82)) || l_222), (-1L))))) == l_234[3][0])), p_79)) && g_120)) >= g_161), 18)) != p_82));
                        (*l_117) = ((((g_161 &= (safe_sub_func_uint16_t_u_u_unsafe_macro/*363*//* ___SAFE__OP */((p_81 | (((void*)0 != l_281) > (safe_lshift_func_int64_t_s_s_unsafe_macro/*364*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*365*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*366*//* ___SAFE__OP */((((safe_add_func_int64_t_s_s_unsafe_macro/*367*//* ___SAFE__OP */(g_158, (safe_div_func_uint8_t_u_u_unsafe_macro/*368*//* ___SAFE__OP */(0UL, (g_164 = 0x75L))))) == (safe_sub_func_uint64_t_u_u_unsafe_macro/*369*//* ___SAFE__OP */(0UL, (-1L)))) | ((p_82 || 0x70L) > p_82)), l_278[0][3][5])), 0x9D5E12A2L)), g_61)))), 0xA388L))) > g_61) , p_81) <= 1UL);
                        (*l_295) = l_294;
                        l_214 = (safe_mod_func_uint16_t_u_u_unsafe_macro/*370*//* ___SAFE__OP */((p_79 && (&g_158 == (void*)0)), l_224));
                    }
                }
            }
            if ((*p_80))
            { /* block id: 74 */
                union U0 ****l_299[2][7];
                union U0 *****l_300 = &l_299[0][4];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 7; j++)
                        l_299[i][j] = &l_262[4][3];
                }
                g_129[0] = (l_298 = (void*)0);
                if ((*g_154))
                    break;
                (*l_300) = l_299[0][4];
            }
            else
            { /* block id: 79 */
                for (l_236 = 5; (l_236 >= 2); l_236 -= 1)
                { /* block id: 82 */
                    union U0 *l_303 = &g_265;
                    int32_t l_304 = 0L;
                    (*g_154) &= (safe_mul_func_int32_t_s_s_unsafe_macro/*371*//* ___SAFE__OP */((*l_117), (l_303 != (l_304 , &g_265))));
                }
            }
            if (((&g_164 != (l_306 = l_305)) , ((safe_mul_func_int8_t_s_s_unsafe_macro/*372*//* ___SAFE__OP */(p_81, (l_202 ^ (((-2L) < (p_79 ^ p_82)) && 0UL)))) | (((+((void*)0 != &l_128[0][7][0])) | 0x6571B35FL) , (*l_114)))))
            { /* block id: 87 */
                uint8_t l_324 = 0xABL;
                int32_t l_326[2][4];
                int16_t *l_403 = &l_351;
                union U0 l_413 = {0xAAL};
                uint64_t ***l_457 = &l_294;
                union U0 *l_477 = (void*)0;
                uint8_t l_500[1];
                int16_t *l_504 = &g_502;
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 4; j++)
                        l_326[i][j] = (-5L);
                }
                for (i = 0; i < 1; i++)
                    l_500[i] = 0xD0L;
                for (g_265.f0 = 0; (g_265.f0 >= 0); g_265.f0 -= 1)
                { /* block id: 90 */
                    uint32_t l_368 = 0x3E9F7859L;
                    int32_t *l_398 = &g_399;
                    const uint16_t *l_402 = &l_159;
                    int32_t l_462 = 0xDE155A03L;
                    int32_t l_463 = 0x57EF1B18L;
                    int32_t l_464 = 0x3D795D6EL;
                    int32_t l_465 = 0xDEB3A4BCL;
                    int32_t l_469 = 0xC542693FL;
                    int32_t l_470 = (-6L);
                    int32_t l_472 = 0xC293D29CL;
                    int32_t l_473 = 0xE37C265CL;
                    uint8_t l_474 = 0x4EL;
                    if ((safe_div_func_uint16_t_u_u_unsafe_macro/*373*//* ___SAFE__OP */(0UL, g_164)))
                    { /* block id: 91 */
                        int32_t l_325 = 0L;
                        if ((*g_154))
                            break;
                        (*l_113) &= ((*p_80) | (((*l_157) = ((((((!g_120) == p_81) | (0L <= ((((safe_add_func_int16_t_s_s_unsafe_macro/*374*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*375*//* ___SAFE__OP */(0x4ED48955634FACB7LL, (g_120 < ((+(--(*l_160))) && l_324)))) != (0x96L > (l_326[1][3] ^= (l_324 <= l_325)))), p_82)) > p_81) , g_195) < 9L))) == g_265.f0) , g_130) & l_324)) ^ (*g_154)));
                    }
                    else
                    { /* block id: 97 */
                        const union U0 l_337 = {0xD1L};
                        int64_t *l_348 = &g_195;
                        uint16_t *l_349 = &l_159;
                        int16_t *l_350 = &l_165;
                        int i;
                        (*l_110) = (*p_80);
                        l_326[1][3] = (safe_mul_func_int8_t_s_s_unsafe_macro/*376*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*377*//* ___SAFE__OP */(((safe_sub_func_int16_t_s_s_unsafe_macro/*378*//* ___SAFE__OP */(((*l_350) = ((*g_154) != (g_120 && ((p_82 = ((safe_lshift_func_uint16_t_u_s_unsafe_macro/*379*//* ___SAFE__OP */((((*l_113) = (p_82 >= (safe_add_func_uint8_t_u_u_unsafe_macro/*380*//* ___SAFE__OP */((((*l_349) = (l_337 , ((safe_rshift_func_int32_t_s_u_unsafe_macro/*381*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*382*//* ___SAFE__OP */(7UL, (safe_add_func_uint64_t_u_u_unsafe_macro/*383*//* ___SAFE__OP */((&l_294 != ((safe_mul_func_uint32_t_u_u_unsafe_macro/*384*//* ___SAFE__OP */(l_337.f0, (((*l_348) = ((g_156 ^ (safe_sub_func_int8_t_s_s_unsafe_macro/*385*//* ___SAFE__OP */((p_79 = (l_337.f0 & 2L)), p_81))) & 0UL)) != (*l_117)))) , (void*)0)), p_81)))), g_203[2])) , g_203[1]))) ^ (**l_127)), l_337.f0)))) & g_164), l_337.f0)) & 0L)) <= p_81)))), 0UL)) , (*p_80)), 18)), l_351));
                        (*l_116) |= (safe_rshift_func_uint8_t_u_s_unsafe_macro/*386*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*387*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*388*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*389*//* ___SAFE__OP */(p_81, (safe_mod_func_int64_t_s_s_unsafe_macro/*390*//* ___SAFE__OP */((g_362 == &p_79), g_130)))), (((*l_348) = (safe_sub_func_uint16_t_u_u_unsafe_macro/*391*//* ___SAFE__OP */(p_81, (safe_sub_func_int8_t_s_s_unsafe_macro/*392*//* ___SAFE__OP */(g_156, l_368))))) , (((((((p_79 >= (!((safe_sub_func_uint64_t_u_u_unsafe_macro/*393*//* ___SAFE__OP */(p_79, 18446744073709551615UL)) == (-1L)))) == g_3) , 0x2A3EE8A6A471C4FFLL) || p_79) | 0UL) < l_236) || 0xF1FDF211L)))), 0xB6EFACE8F519CF44LL)), 5));
                    }
                    if ((safe_div_func_uint32_t_u_u_unsafe_macro/*394*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*395*//* ___SAFE__OP */((p_81 ^ (safe_div_func_int64_t_s_s_unsafe_macro/*396*//* ___SAFE__OP */(g_203[8], (safe_mul_func_int32_t_s_s_unsafe_macro/*397*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*398*//* ___SAFE__OP */(((*l_115) ^= (safe_mul_func_uint8_t_u_u_unsafe_macro/*399*//* ___SAFE__OP */(p_82, (g_384[0][0] == (((*l_157) = (safe_div_func_int16_t_s_s_unsafe_macro/*400*//* ___SAFE__OP */((((l_401 = ((safe_div_func_int16_t_s_s_unsafe_macro/*401*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*402*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_u_unsafe_macro/*403*//* ___SAFE__OP */(p_79, 8)) < ((((*l_398) ^= (g_251 & (l_326[1][3] < (((((((safe_rshift_func_int64_t_s_s_unsafe_macro/*404*//* ___SAFE__OP */(p_82, (safe_mod_func_uint32_t_u_u_unsafe_macro/*405*//* ___SAFE__OP */((0xB3L > l_368), p_81)))) , l_368) == l_324) == 0xC2FE3EEE26554883LL) == (*l_109)) < l_324) > (-3L))))) , l_400) != (void*)0)), p_79)), g_195)) , &g_61)) == l_402) == g_158), p_79))) , l_403))))), 0x392CDDA0L)), p_81))))), 1UL)), g_404)))
                    { /* block id: 113 */
                        int64_t *l_410 = (void*)0;
                        int64_t *l_411 = (void*)0;
                        int64_t *l_412 = &g_195;
                        uint64_t ***l_418 = &l_294;
                        const union U0 * const **l_419 = (void*)0;
                        int32_t l_434[2];
                        union U0 *l_449 = &g_448;
                        uint16_t *l_458[8];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_434[i] = 0x0D7859EAL;
                        for (i = 0; i < 8; i++)
                            l_458[i] = &l_438[0][0];
                        (*g_154) = (0x95L | (p_82 ^ ((l_405 <= ((safe_rshift_func_int32_t_s_s_unsafe_macro/*406*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*407*//* ___SAFE__OP */((p_80 != &g_399), ((*l_412) = (0xB26CBD6CL >= g_120)))) > ((((l_413 , (safe_rshift_func_int32_t_s_s_unsafe_macro/*408*//* ___SAFE__OP */(((((safe_sub_func_int64_t_s_s_unsafe_macro/*409*//* ___SAFE__OP */(((((*l_418) = &l_160) != &l_160) ^ l_413.f0), 0x07B2179A88729649LL)) , l_419) != g_420[0]) < g_404), 21))) == g_164) && 0x3AL) , 0xB6AEAC0E24B2507CLL)), (*g_154))) <= g_3)) , l_326[0][3])));
                        (*g_154) = (safe_sub_func_uint64_t_u_u_unsafe_macro/*410*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*411*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*412*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*413*//* ___SAFE__OP */(g_158, (safe_sub_func_uint8_t_u_u_unsafe_macro/*414*//* ___SAFE__OP */((g_203[1] & (((l_434[0] | g_3) , (void*)0) != (void*)0)), ((p_82 >= (safe_rshift_func_int8_t_s_u_unsafe_macro/*415*//* ___SAFE__OP */((~((*l_112) = ((g_399 >= l_438[1][0]) && 0xDBL))), g_404))) ^ p_82))))), 5)), 0x16L)), 1UL));
                        (*l_110) = (0x856EL < (safe_rshift_func_int16_t_s_u_unsafe_macro/*416*//* ___SAFE__OP */(((p_81 <= (((((safe_mul_func_int16_t_s_s_unsafe_macro/*417*//* ___SAFE__OP */((p_81 != (safe_add_func_int8_t_s_s_unsafe_macro/*418*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*419*//* ___SAFE__OP */(((l_447 = (*l_263)) != (g_423 = l_449)), ((safe_rshift_func_int16_t_s_s_unsafe_macro/*420*//* ___SAFE__OP */(((*l_403) &= ((!(g_404 = (safe_mul_func_int32_t_s_s_unsafe_macro/*421*//* ___SAFE__OP */(0x5A9F6234L, (((*l_401) = (safe_add_func_int8_t_s_s_unsafe_macro/*422*//* ___SAFE__OP */((((((*l_449) , l_457) != (void*)0) == g_195) && l_434[0]), p_81))) ^ g_156))))) >= p_79)), 9)) != p_82))) || 0x4A0EL), 0x8FL))), 0xA3A6L)) > 0x8CL) ^ 0x856BD9A5L) != g_195) & l_368)) > g_3), g_265.f0)));
                    }
                    else
                    { /* block id: 125 */
                        int32_t l_459 = 0xA893BCF0L;
                        int32_t l_460 = (-6L);
                        int32_t l_461 = 2L;
                        int32_t l_467 = 0x8A3B0C54L;
                        int32_t l_468[7][3] = {{0x61CFDD80L,(-9L),0x61CFDD80L},{0L,0L,(-5L)},{1L,(-9L),1L},{0L,(-5L),(-5L)},{0x61CFDD80L,(-9L),0x61CFDD80L},{0L,0L,(-5L)},{1L,(-9L),1L}};
                        int i, j;
                        l_474++;
                        g_154 = (g_129[0] = ((*l_127) = p_80));
                        return &g_3;
                    }
                    l_477 = &g_265;
                    for (l_165 = 0; (l_165 >= 0); l_165 -= 1)
                    { /* block id: 135 */
                        union U1 **l_480 = &l_478;
                        int i, j, k;
                        l_326[l_165][(g_265.f0 + 3)] = (*p_80);
                        (*l_480) = l_478;
                    }
                    for (g_251 = 0; (g_251 <= 0); g_251 += 1)
                    { /* block id: 141 */
                        int16_t **l_503[8] = {&g_501,&g_501,&g_501,&g_501,&g_501,&g_501,&g_501,&g_501};
                        int i, j, k;
                        (*l_127) = p_80;
                        (*l_114) = (safe_sub_func_uint16_t_u_u_unsafe_macro/*423*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*424*//* ___SAFE__OP */(p_81, (safe_add_func_int16_t_s_s_unsafe_macro/*425*//* ___SAFE__OP */(((((safe_mul_func_int64_t_s_s_unsafe_macro/*426*//* ___SAFE__OP */(((0x2A736D7CL || (((((p_79 > (safe_sub_func_int16_t_s_s_unsafe_macro/*427*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*428*//* ___SAFE__OP */((((safe_add_func_int32_t_s_s_unsafe_macro/*429*//* ___SAFE__OP */((&l_447 == &l_477), (*l_109))) , (!p_79)) || ((safe_lshift_func_int8_t_s_s_unsafe_macro/*430*//* ___SAFE__OP */((p_82 >= g_164), 4)) , g_399)), 0xD7182D5CL)), g_164))) , p_82) == p_79) > g_156) || g_498)) != 0x0EF6L), l_499[5][1])) , p_79) , g_195) ^ 7L), 0x5061L)))) >= g_203[1]), l_500[0]));
                        (*l_115) = (p_79 ^ (((l_504 = g_501) != l_402) >= g_130));
                    }
                }
            }
            else
            { /* block id: 148 */
                union U0 * volatile **l_508 = (void*)0;
                union U0 * volatile ***l_507 = &l_508;
                union U1 *l_509 = (void*)0;
                for (l_227 = (-10); (l_227 < (-9)); l_227++)
                { /* block id: 151 */
                    for (l_202 = 0; l_202 < 9; l_202 += 1)
                    {
                        g_203[l_202] = 6L;
                    }
                }
                (*l_127) = p_80;
                (*l_507) = &g_421[1];
                for (g_265.f0 = 0; (g_265.f0 <= 0); g_265.f0 += 1)
                { /* block id: 158 */
                    l_510[6] = l_509;
                    for (g_512.f1 = 0; (g_512.f1 <= 0); g_512.f1 += 1)
                    { /* block id: 162 */
                        const int32_t *l_516[5][1][2] = {{{&g_517,&g_517}},{{&g_517,&g_517}},{{&g_517,&g_517}},{{&g_517,&g_517}},{{&g_517,&g_517}}};
                        const int32_t **l_515 = &l_516[4][0][0];
                        const int32_t *l_519 = (void*)0;
                        const int32_t **l_518 = &l_519;
                        int i, j, k;
                        (*l_518) = ((*l_515) = &l_108);
                    }
                }
            }
            if ((g_156 == 0xBEA5A88354F028AALL))
            { /* block id: 168 */
                for (g_61 = 0; (g_61 < 12); g_61++)
                { /* block id: 171 */
                    for (g_404 = 17; (g_404 != 33); g_404 = safe_add_func_int16_t_s_s_unsafe_macro/*431*//* ___SAFE__OP */(g_404, 8))
                    { /* block id: 174 */
                        int32_t ****l_526 = &l_152[0];
                        int32_t *****l_525 = &l_526;
                        (*l_525) = l_524;
                    }
                }
            }
            else
            { /* block id: 178 */
                (*l_127) = p_80;
            }
        }
    }
    else
    { /* block id: 182 */
        int64_t *l_533 = (void*)0;
        int64_t **l_532 = &l_533;
        int32_t l_539[1];
        int8_t *l_541[7];
        int i;
        for (i = 0; i < 1; i++)
            l_539[i] = 0x9B57CE6AL;
        for (i = 0; i < 7; i++)
            l_541[i] = &l_119;
        if ((p_79 < (safe_add_func_uint32_t_u_u_unsafe_macro/*432*//* ___SAFE__OP */((((*p_80) ^ (safe_lshift_func_uint64_t_u_u_unsafe_macro/*433*//* ___SAFE__OP */(g_448.f0, ((*l_112) | (l_531 && (((*l_532) = &g_195) != l_534)))))) == (safe_mod_func_uint64_t_u_u_unsafe_macro/*434*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*435*//* ___SAFE__OP */(l_539[0], (~((l_541[3] == g_362) || g_130)))), 0x65C86B15C5185B2FLL))), (*p_80)))))
        { /* block id: 184 */
            (*l_116) |= ((void*)0 != g_542);
        }
        else
        { /* block id: 186 */
            uint64_t l_555 = 0xF45E9A4CF3531FD2LL;
            int16_t l_561 = 0xE300L;
            int16_t l_562 = 0xEF3BL;
            union U0 l_565[1] = {{0x98L}};
            union U1 **l_568 = &l_566;
            int i;
            l_562 = (safe_add_func_uint8_t_u_u_unsafe_macro/*436*//* ___SAFE__OP */(((~((safe_mod_func_uint16_t_u_u_unsafe_macro/*437*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*438*//* ___SAFE__OP */(g_399, (((safe_sub_func_int64_t_s_s_unsafe_macro/*439*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*440*//* ___SAFE__OP */((l_555 <= ((*g_501) == (((g_556[2][4] != &g_557) < ((*l_117) = ((*l_110) , g_517))) <= (254UL ^ (-1L))))), l_539[0])), 0xAE6E5FC060F4EA0DLL)) <= l_560[3]) > g_161))), g_203[3])) < l_561)) , g_164), l_555));
            if (p_79)
                goto lbl_573;
lbl_573:
            (*l_117) = ((p_81 <= ((p_81 , (g_563 == ((*l_568) = (l_565[0] , l_566)))) , ((safe_mod_func_int32_t_s_s_unsafe_macro/*441*//* ___SAFE__OP */((l_565[0] , (*p_80)), (safe_add_func_int64_t_s_s_unsafe_macro/*442*//* ___SAFE__OP */(g_61, g_502)))) || p_79))) & (*l_110));
            (*l_568) = (l_565[0].f0 , g_563);
        }
    }
    return p_80;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_203[i], "g_203[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_251, "g_251", print_hash_value);
    transparent_crc(g_265.f0, "g_265.f0", print_hash_value);
    transparent_crc(g_363, "g_363", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_385[i], "g_385[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_399, "g_399", print_hash_value);
    transparent_crc(g_404, "g_404", print_hash_value);
    transparent_crc(g_448.f0, "g_448.f0", print_hash_value);
    transparent_crc(g_479.f0, "g_479.f0", print_hash_value);
    transparent_crc(g_498, "g_498", print_hash_value);
    transparent_crc(g_502, "g_502", print_hash_value);
    transparent_crc(g_511.f0, "g_511.f0", print_hash_value);
    transparent_crc(g_512.f0, "g_512.f0", print_hash_value);
    transparent_crc(g_513.f0, "g_513.f0", print_hash_value);
    transparent_crc(g_514.f0, "g_514.f0", print_hash_value);
    transparent_crc(g_517, "g_517", print_hash_value);
    transparent_crc(g_564.f0, "g_564.f0", print_hash_value);
    transparent_crc(g_567.f0, "g_567.f0", print_hash_value);
    transparent_crc(g_705.f0, "g_705.f0", print_hash_value);
    transparent_crc(g_737, "g_737", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_766[i], "g_766[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_786, "g_786", print_hash_value);
    transparent_crc(g_789, "g_789", print_hash_value);
    transparent_crc(g_854, "g_854", print_hash_value);
    transparent_crc(g_906, "g_906", print_hash_value);
    transparent_crc(g_913, "g_913", print_hash_value);
    transparent_crc(g_976, "g_976", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_977[i][j][k], "g_977[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1018[i][j][k], "g_1018[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1197[i], "g_1197[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1396, "g_1396", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1536[i], "g_1536[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1718, "g_1718", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1726[i][j][k], "g_1726[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1745[i], "g_1745[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1767[i][j].f0, "g_1767[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1775.f0, "g_1775.f0", print_hash_value);
    transparent_crc(g_1862.f0, "g_1862.f0", print_hash_value);
    transparent_crc(g_2012.f0, "g_2012.f0", print_hash_value);
    transparent_crc(g_2014.f0, "g_2014.f0", print_hash_value);
    transparent_crc(g_2081, "g_2081", print_hash_value);
    transparent_crc(g_2120, "g_2120", print_hash_value);
    transparent_crc(g_2170, "g_2170", print_hash_value);
    transparent_crc(g_2179, "g_2179", print_hash_value);
    transparent_crc(g_2205, "g_2205", print_hash_value);
    transparent_crc(g_2272, "g_2272", print_hash_value);
    transparent_crc(g_2275, "g_2275", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2353[i], "g_2353[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2543.f0, "g_2543.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2558[i], "g_2558[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2768, "g_2768", print_hash_value);
    transparent_crc(g_2836, "g_2836", print_hash_value);
    transparent_crc(g_3145, "g_3145", print_hash_value);
    transparent_crc(g_3190.f0, "g_3190.f0", print_hash_value);
    transparent_crc(g_3253, "g_3253", print_hash_value);
    transparent_crc(g_3396.f0, "g_3396.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 887
XXX total union variables: 37

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 38
breakdown:
   indirect level: 0, occurrence: 3
   indirect level: 1, occurrence: 15
   indirect level: 2, occurrence: 5
   indirect level: 3, occurrence: 8
   indirect level: 4, occurrence: 2
   indirect level: 5, occurrence: 5
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 16
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 3
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 1

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 266
   depth: 2, occurrence: 88
   depth: 3, occurrence: 6
   depth: 4, occurrence: 7
   depth: 5, occurrence: 5
   depth: 8, occurrence: 2
   depth: 12, occurrence: 2
   depth: 13, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 3
   depth: 19, occurrence: 6
   depth: 20, occurrence: 5
   depth: 21, occurrence: 3
   depth: 22, occurrence: 4
   depth: 23, occurrence: 2
   depth: 24, occurrence: 4
   depth: 25, occurrence: 3
   depth: 26, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 3
   depth: 29, occurrence: 3
   depth: 30, occurrence: 1
   depth: 31, occurrence: 2
   depth: 32, occurrence: 4
   depth: 33, occurrence: 3
   depth: 34, occurrence: 2
   depth: 35, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 42, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 703

XXX times a variable address is taken: 1582
XXX times a pointer is dereferenced on RHS: 493
breakdown:
   depth: 1, occurrence: 348
   depth: 2, occurrence: 76
   depth: 3, occurrence: 44
   depth: 4, occurrence: 19
   depth: 5, occurrence: 6
XXX times a pointer is dereferenced on LHS: 382
breakdown:
   depth: 1, occurrence: 300
   depth: 2, occurrence: 49
   depth: 3, occurrence: 14
   depth: 4, occurrence: 16
   depth: 5, occurrence: 3
XXX times a pointer is compared with null: 69
XXX times a pointer is compared with address of another variable: 23
XXX times a pointer is compared with another pointer: 19
XXX times a pointer is qualified to be dereferenced: 12145

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 3437
   level: 2, occurrence: 605
   level: 3, occurrence: 445
   level: 4, occurrence: 345
   level: 5, occurrence: 260
XXX number of pointers point to pointers: 341
XXX number of pointers point to scalars: 326
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 33
XXX average alias set size: 1.54

XXX times a non-volatile is read: 3113
XXX times a non-volatile is write: 1361
XXX times a volatile is read: 35
XXX    times read thru a pointer: 23
XXX times a volatile is write: 12
XXX    times written thru a pointer: 9
XXX times a volatile is available for access: 484
XXX percentage of non-volatile access: 99

XXX forward jumps: 2
XXX backward jumps: 11

XXX stmts: 298
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 19
   depth: 2, occurrence: 40
   depth: 3, occurrence: 57
   depth: 4, occurrence: 75
   depth: 5, occurrence: 82

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

