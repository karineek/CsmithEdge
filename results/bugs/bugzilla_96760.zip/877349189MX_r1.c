#include "csmith.h"
union a {
  int32_t b;
};
int8_t c, f;
uint16_t d = 209;
uint64_t e;
int32_t *g;
int16_t h[][1];
static int8_t i(union a, int32_t, int16_t, int8_t *);
static uint32_t j() {
  union a am = {1};
  int16_t an = 0;
  i(am, 0, an, &c);
}
int8_t i(union a ao, int32_t ap, int16_t aq, int8_t *ar) {
  for (;;) {
    uint64_t *as = &e;
    for (c = 20; c < 22; c++) {
      uint16_t *at = &d;
      if (safe_div_func_int16_t_s_s_unsafe_macro(ao.b, *at))
        continue;
      printf("HERE IS the Bug %lu %d\n", e, f);
      return 1;
    }
    h[4][0] = ((*as)++, *g);
  }
}
int main() { j(); }
