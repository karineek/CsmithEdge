#include "csmith.h" 
int8_t c=0;
uint16_t d = 209;
unsigned long e=0;
int32_t *g=(void*)0;
int16_t h[5][1]={{1,2,3,4,5},{1,2,3,4,5}};

int main() { 
  for (;;) {
    unsigned long *as = &e;
    for (c = 0; c < 2; c++) {
      if (1 / d)
        continue;
      printf("HERE IS the Bug %lu \n", e);
      return 1;
    }
    h[4][0] = ((*as)++, *g);
  }
}