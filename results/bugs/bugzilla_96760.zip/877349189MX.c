#include <stdio.h>

char a = 0, f = 0, c = 5;
unsigned long d = 0;
int g = 0;
int *e = &g;
int main() {
  char  b = 0;
  for (;;) {
    for (a = 20; a; a++) {
      if (c) {
        // printf("a=%d, b=%d, d=%lu, e=%p, f=%d, g=%d\n", a, b, d, e, f, g);
        printf("HERE IS the Bug %lu %d\n", d, b);
        return 0; 
      }
    }

    f = (d++, *e);
  }

}
