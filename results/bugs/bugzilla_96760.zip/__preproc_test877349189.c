# 0 "__test877349189.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "__test877349189.c"
# 10 "__test877349189.c"
# 1 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h" 1
# 40 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h"
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 424 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 427 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 428 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 429 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 425 "/usr/include/features.h" 2 3 4
# 448 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 449 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 1 3 4
# 209 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 3 4

# 209 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 34 "/usr/include/string.h" 2 3 4
# 42 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 90 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 121 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



# 1 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 153 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 225 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 252 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 272 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 302 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 329 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 384 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 409 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)));
# 427 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));



# 432 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 498 "/usr/include/string.h" 3 4

# 41 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h" 2
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/float.h" 1 3 4
# 42 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h" 2
# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 28 "/usr/include/math.h" 2 3 4









# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;







typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 130 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 131 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 38 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 2 3 4
# 41 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 120 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 121 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 44 "/usr/include/math.h" 2 3 4
# 138 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 139 "/usr/include/math.h" 2 3 4
# 149 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 190 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-logb.h" 1 3 4
# 191 "/usr/include/math.h" 2 3 4
# 233 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-fast.h" 1 3 4
# 234 "/usr/include/math.h" 2 3 4
# 289 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinf (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __isnan (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __iseqsig (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignaling (double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 290 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double acos (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __acos (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double asin (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __asin (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double atan (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atan (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern double cos (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cos (double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern double sin (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sin (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double tan (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __tan (double __x) __attribute__ ((__nothrow__ , __leaf__));




extern double cosh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cosh (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double sinh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sinh (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double tanh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __tanh (double __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double acosh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __acosh (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double asinh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __asinh (double __x) __attribute__ ((__nothrow__ , __leaf__));

extern double atanh (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __atanh (double __x) __attribute__ ((__nothrow__ , __leaf__));





 extern double exp (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __exp (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern double log (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double log10 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log10 (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double expm1 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __expm1 (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double log1p (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log1p (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double logb (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __logb (double __x) __attribute__ ((__nothrow__ , __leaf__));




extern double exp2 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __exp2 (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double log2 (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __log2 (double __x) __attribute__ ((__nothrow__ , __leaf__));






 extern double pow (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));


extern double sqrt (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __sqrt (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern double hypot (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));




extern double cbrt (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __cbrt (double __x) __attribute__ ((__nothrow__ , __leaf__));






extern double ceil (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __ceil (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fabs (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __floor (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinf (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern int finite (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double drem (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __drem (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));



extern double significand (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __significand (double __x) __attribute__ ((__nothrow__ , __leaf__));






extern double copysign (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __copysign (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern double nan (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __nan (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 211 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnan (double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern double j0 (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __j0 (double) __attribute__ ((__nothrow__ , __leaf__));
extern double j1 (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __j1 (double) __attribute__ ((__nothrow__ , __leaf__));
extern double jn (int, double) __attribute__ ((__nothrow__ , __leaf__)); extern double __jn (int, double) __attribute__ ((__nothrow__ , __leaf__));
extern double y0 (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __y0 (double) __attribute__ ((__nothrow__ , __leaf__));
extern double y1 (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __y1 (double) __attribute__ ((__nothrow__ , __leaf__));
extern double yn (int, double) __attribute__ ((__nothrow__ , __leaf__)); extern double __yn (int, double) __attribute__ ((__nothrow__ , __leaf__));





extern double erf (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __erf (double) __attribute__ ((__nothrow__ , __leaf__));
extern double erfc (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __erfc (double) __attribute__ ((__nothrow__ , __leaf__));
extern double lgamma (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __lgamma (double) __attribute__ ((__nothrow__ , __leaf__));




extern double tgamma (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __tgamma (double) __attribute__ ((__nothrow__ , __leaf__));





extern double gamma (double) __attribute__ ((__nothrow__ , __leaf__)); extern double __gamma (double) __attribute__ ((__nothrow__ , __leaf__));







extern double lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__)); extern double __lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__));






extern double rint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __rint (double __x) __attribute__ ((__nothrow__ , __leaf__));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 272 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogb (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogb (double __x) __attribute__ ((__nothrow__ , __leaf__));
# 290 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern double nearbyint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern double __nearbyint (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern double round (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __round (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __trunc (double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrint (double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrint (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrint (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lround (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lround (double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llround (double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llround (double __x) __attribute__ ((__nothrow__ , __leaf__));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__));


extern double fmax (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fmax (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern double __fmin (double __x, double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ , __leaf__)); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ , __leaf__));
# 396 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalb (double __x, double __n) __attribute__ ((__nothrow__ , __leaf__)); extern double __scalb (double __x, double __n) __attribute__ ((__nothrow__ , __leaf__));
# 291 "/usr/include/math.h" 2 3 4
# 306 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinff (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __isnanf (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __iseqsigf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignalingf (float __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 307 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float acosf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __acosf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float asinf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __asinf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float atanf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atanf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__ , __leaf__));


 extern float cosf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __cosf (float __x) __attribute__ ((__nothrow__ , __leaf__));

 extern float sinf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sinf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float tanf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __tanf (float __x) __attribute__ ((__nothrow__ , __leaf__));




extern float coshf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __coshf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float sinhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sinhf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float tanhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __tanhf (float __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float acoshf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __acoshf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float asinhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __asinhf (float __x) __attribute__ ((__nothrow__ , __leaf__));

extern float atanhf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __atanhf (float __x) __attribute__ ((__nothrow__ , __leaf__));





 extern float expf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __expf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern float logf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __logf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float log10f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log10f (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float expm1f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __expm1f (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float log1pf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log1pf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float logbf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __logbf (float __x) __attribute__ ((__nothrow__ , __leaf__));




extern float exp2f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __exp2f (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float log2f (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __log2f (float __x) __attribute__ ((__nothrow__ , __leaf__));






 extern float powf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));


extern float sqrtf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __sqrtf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));




extern float cbrtf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __cbrtf (float __x) __attribute__ ((__nothrow__ , __leaf__));






extern float ceilf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __ceilf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fabsf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __floorf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinff (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern int finitef (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float dremf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __dremf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));



extern float significandf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __significandf (float __x) __attribute__ ((__nothrow__ , __leaf__));






extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __copysignf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern float nanf (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __nanf (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 211 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnanf (float __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern float j0f (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __j0f (float) __attribute__ ((__nothrow__ , __leaf__));
extern float j1f (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __j1f (float) __attribute__ ((__nothrow__ , __leaf__));
extern float jnf (int, float) __attribute__ ((__nothrow__ , __leaf__)); extern float __jnf (int, float) __attribute__ ((__nothrow__ , __leaf__));
extern float y0f (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __y0f (float) __attribute__ ((__nothrow__ , __leaf__));
extern float y1f (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __y1f (float) __attribute__ ((__nothrow__ , __leaf__));
extern float ynf (int, float) __attribute__ ((__nothrow__ , __leaf__)); extern float __ynf (int, float) __attribute__ ((__nothrow__ , __leaf__));





extern float erff (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __erff (float) __attribute__ ((__nothrow__ , __leaf__));
extern float erfcf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __erfcf (float) __attribute__ ((__nothrow__ , __leaf__));
extern float lgammaf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __lgammaf (float) __attribute__ ((__nothrow__ , __leaf__));




extern float tgammaf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __tgammaf (float) __attribute__ ((__nothrow__ , __leaf__));





extern float gammaf (float) __attribute__ ((__nothrow__ , __leaf__)); extern float __gammaf (float) __attribute__ ((__nothrow__ , __leaf__));







extern float lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__)); extern float __lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__));






extern float rintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __rintf (float __x) __attribute__ ((__nothrow__ , __leaf__));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 272 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogbf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogbf (float __x) __attribute__ ((__nothrow__ , __leaf__));
# 290 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern float roundf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __roundf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __truncf (float __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrintf (float __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrintf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lroundf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lroundf (float __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llroundf (float __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__ , __leaf__));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__));


extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fmaxf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern float __fminf (float __x, float __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ , __leaf__)); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ , __leaf__));
# 396 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalbf (float __x, float __n) __attribute__ ((__nothrow__ , __leaf__)); extern float __scalbf (float __x, float __n) __attribute__ ((__nothrow__ , __leaf__));
# 308 "/usr/include/math.h" 2 3 4
# 349 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinfl (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __isnanl (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __iseqsigl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignalingl (long double __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 350 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double acosl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __acosl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double asinl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __asinl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double atanl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atanl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ , __leaf__));


 extern long double cosl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __cosl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

 extern long double sinl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sinl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double tanl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tanl (long double __x) __attribute__ ((__nothrow__ , __leaf__));




extern long double coshl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __coshl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double sinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double tanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double acoshl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double asinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));

extern long double atanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__ , __leaf__));





 extern long double expl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __expl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__)); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ , __leaf__));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__)); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ , __leaf__));


 extern long double logl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __logl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double log10l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log10l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ , __leaf__)); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double expm1l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double log1pl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double logbl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __logbl (long double __x) __attribute__ ((__nothrow__ , __leaf__));




extern long double exp2l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double log2l (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __log2l (long double __x) __attribute__ ((__nothrow__ , __leaf__));






 extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));




extern long double cbrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__ , __leaf__));






extern long double ceill (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __ceill (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fabsl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __floorl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinfl (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern int finitel (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double dreml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __dreml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));



extern long double significandl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __significandl (long double __x) __attribute__ ((__nothrow__ , __leaf__));






extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern long double nanl (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __nanl (const char *__tagb) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 211 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnanl (long double __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern long double j0l (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __j0l (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double j1l (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __j1l (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double jnl (int, long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __jnl (int, long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double y0l (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __y0l (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double y1l (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __y1l (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double ynl (int, long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __ynl (int, long double) __attribute__ ((__nothrow__ , __leaf__));





extern long double erfl (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __erfl (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double erfcl (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __erfcl (long double) __attribute__ ((__nothrow__ , __leaf__));
extern long double lgammal (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __lgammal (long double) __attribute__ ((__nothrow__ , __leaf__));




extern long double tgammal (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __tgammal (long double) __attribute__ ((__nothrow__ , __leaf__));





extern long double gammal (long double) __attribute__ ((__nothrow__ , __leaf__)); extern long double __gammal (long double) __attribute__ ((__nothrow__ , __leaf__));







extern long double lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__)); extern long double __lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__ , __leaf__));






extern long double rintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __rintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));
# 272 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ , __leaf__)); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ , __leaf__));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
# 290 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__)); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ , __leaf__));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long double roundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __roundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __truncl (long double __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__)); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ , __leaf__));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__));
__extension__
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__)); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__ , __leaf__));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__));


extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)); extern long double __fminl (long double __x, long double __y) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ , __leaf__)); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ , __leaf__));
# 396 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalbl (long double __x, long double __n) __attribute__ ((__nothrow__ , __leaf__)); extern long double __scalbl (long double __x, long double __n) __attribute__ ((__nothrow__ , __leaf__));
# 351 "/usr/include/math.h" 2 3 4
# 420 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));


extern int __signbitf128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));



extern int __isinff128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __finitef128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __isnanf128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern int __iseqsigf128 (_Float128 __x, _Float128 __y) __attribute__ ((__nothrow__ , __leaf__));


extern int __issignalingf128 (_Float128 __value) __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__const__));
# 421 "/usr/include/math.h" 2 3 4
# 489 "/usr/include/math.h" 3 4
extern int signgam;
# 569 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 1263 "/usr/include/math.h" 3 4

# 43 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h" 2


# 1 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 1
# 51 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h"
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 1 3 4
# 34 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 3 4
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/syslimits.h" 1 3 4






# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 1 3 4
# 203 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 183 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 160 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 161 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 184 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 188 "/usr/include/limits.h" 2 3 4
# 204 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 2 3 4
# 8 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/syslimits.h" 2 3 4
# 35 "/home/user42/gcc-csmith-0/gcc-build/gcc/include-fixed/limits.h" 2 3 4
# 52 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2



# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stdint.h" 1 3 4
# 9 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4





typedef signed char int_least8_t;
typedef short int int_least16_t;
typedef int int_least32_t;

typedef long int int_least64_t;






typedef unsigned char uint_least8_t;
typedef unsigned short int uint_least16_t;
typedef unsigned int uint_least32_t;

typedef unsigned long int uint_least64_t;
# 68 "/usr/include/stdint.h" 3 4
typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 81 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 97 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 111 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stdint.h" 2 3 4
# 56 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2



# 1 "/usr/include/assert.h" 1 3 4
# 66 "/usr/include/assert.h" 3 4



extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));


extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



# 60 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2
# 89 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h"
# 1 "/home/user42/git/MinCond/csmith_runtime_orig/platform_generic.h" 1
# 39 "/home/user42/git/MinCond/csmith_runtime_orig/platform_generic.h"
# 1 "/usr/include/stdio.h" 1 3 4
# 27 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 28 "/usr/include/stdio.h" 2 3 4





# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 1 3 4
# 34 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 37 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 38 "/usr/include/stdio.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/libio.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/_G_config.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/_G_config.h" 3 4
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stddef.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/_G_config.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 22 "/usr/include/x86_64-linux-gnu/bits/_G_config.h" 2 3 4




typedef struct
{
  __off_t __pos;
  __mbstate_t __state;
} _G_fpos_t;
typedef struct
{
  __off64_t __pos;
  __mbstate_t __state;
} _G_fpos64_t;
# 36 "/usr/include/x86_64-linux-gnu/bits/libio.h" 2 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
# 1 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stdarg.h" 1 3 4
# 40 "/home/user42/gcc-csmith-0/gcc-build/gcc/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 54 "/usr/include/x86_64-linux-gnu/bits/libio.h" 2 3 4
# 149 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
struct _IO_jump_t; struct _IO_FILE;




typedef void _IO_lock_t;





struct _IO_marker {
  struct _IO_marker *_next;
  struct _IO_FILE *_sbuf;



  int _pos;
# 177 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
};


enum __codecvt_result
{
  __codecvt_ok,
  __codecvt_partial,
  __codecvt_error,
  __codecvt_noconv
};
# 245 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
struct _IO_FILE {
  int _flags;




  char* _IO_read_ptr;
  char* _IO_read_end;
  char* _IO_read_base;
  char* _IO_write_base;
  char* _IO_write_ptr;
  char* _IO_write_end;
  char* _IO_buf_base;
  char* _IO_buf_end;

  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;



  int _flags2;

  __off_t _old_offset;



  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];



  _IO_lock_t *_lock;
# 293 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
  __off64_t _offset;







  void *__pad1;
  void *__pad2;
  void *__pad3;
  void *__pad4;

  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];

};


typedef struct _IO_FILE _IO_FILE;


struct _IO_FILE_plus;

extern struct _IO_FILE_plus _IO_2_1_stdin_;
extern struct _IO_FILE_plus _IO_2_1_stdout_;
extern struct _IO_FILE_plus _IO_2_1_stderr_;
# 337 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
typedef __ssize_t __io_read_fn (void *__cookie, char *__buf, size_t __nbytes);







typedef __ssize_t __io_write_fn (void *__cookie, const char *__buf,
     size_t __n);







typedef int __io_seek_fn (void *__cookie, __off64_t *__pos, int __w);


typedef int __io_close_fn (void *__cookie);
# 389 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
extern int __underflow (_IO_FILE *);
extern int __uflow (_IO_FILE *);
extern int __overflow (_IO_FILE *, int);
# 433 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
extern int _IO_getc (_IO_FILE *__fp);
extern int _IO_putc (int __c, _IO_FILE *__fp);
extern int _IO_feof (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ferror (_IO_FILE *__fp) __attribute__ ((__nothrow__ , __leaf__));

extern int _IO_peekc_locked (_IO_FILE *__fp);





extern void _IO_flockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern void _IO_funlockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
extern int _IO_ftrylockfile (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
# 462 "/usr/include/x86_64-linux-gnu/bits/libio.h" 3 4
extern int _IO_vfscanf (_IO_FILE * __restrict, const char * __restrict,
   __gnuc_va_list, int *__restrict);
extern int _IO_vfprintf (_IO_FILE *__restrict, const char *__restrict,
    __gnuc_va_list);
extern __ssize_t _IO_padn (_IO_FILE *, int, __ssize_t);
extern size_t _IO_sgetn (_IO_FILE *, void *, size_t);

extern __off64_t _IO_seekoff (_IO_FILE *, __off64_t, int, int);
extern __off64_t _IO_seekpos (_IO_FILE *, __off64_t, int);

extern void _IO_free_backup_area (_IO_FILE *) __attribute__ ((__nothrow__ , __leaf__));
# 42 "/usr/include/stdio.h" 2 3 4




typedef __gnuc_va_list va_list;
# 57 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;
# 71 "/usr/include/stdio.h" 3 4
typedef __ssize_t ssize_t;






typedef _G_fpos_t fpos_t;
# 131 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 132 "/usr/include/stdio.h" 2 3 4



extern struct _IO_FILE *stdin;
extern struct _IO_FILE *stdout;
extern struct _IO_FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));







extern FILE *tmpfile (void) ;
# 173 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;




extern char *tmpnam_r (char *__s) __attribute__ ((__nothrow__ , __leaf__)) ;
# 190 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) ;







extern int fclose (FILE *__stream);




extern int fflush (FILE *__stream);
# 213 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 232 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) ;
# 265 "/usr/include/stdio.h" 3 4
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__)) ;
# 278 "/usr/include/stdio.h" 3 4
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__)) ;





extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...);




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg);




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 365 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) ;




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));
# 395 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                               ;
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 420 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) ;





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 443 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) ;
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 477 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream);
extern int getc (FILE *__stream);





extern int getchar (void);
# 495 "/usr/include/stdio.h" 3 4
extern int getc_unlocked (FILE *__stream);
extern int getchar_unlocked (void);
# 506 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream);
# 517 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream);
extern int putc (int __c, FILE *__stream);





extern int putchar (int __c);
# 537 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream);







extern int putc_unlocked (int __c, FILE *__stream);
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream);


extern int putw (int __w, FILE *__stream);







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     ;
# 603 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
          size_t *__restrict __n, int __delimiter,
          FILE *__restrict __stream) ;
extern __ssize_t getdelim (char **__restrict __lineptr,
        size_t *__restrict __n, int __delimiter,
        FILE *__restrict __stream) ;







extern __ssize_t getline (char **__restrict __lineptr,
       size_t *__restrict __n,
       FILE *__restrict __stream) ;







extern int fputs (const char *__restrict __s, FILE *__restrict __stream);





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream);






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) ;




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s);
# 673 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) ;
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream);







extern int fseek (FILE *__stream, long int __off, int __whence);




extern long int ftell (FILE *__stream) ;




extern void rewind (FILE *__stream);
# 707 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence);




extern __off_t ftello (FILE *__stream) ;
# 731 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos);




extern int fsetpos (FILE *__stream, const fpos_t *__pos);
# 757 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;







extern void perror (const char *__s);





# 1 "/usr/include/x86_64-linux-gnu/bits/sys_errlist.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/sys_errlist.h" 3 4
extern int sys_nerr;
extern const char *const sys_errlist[];
# 782 "/usr/include/stdio.h" 2 3 4




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
# 800 "/usr/include/stdio.h" 3 4
extern FILE *popen (const char *__command, const char *__modes) ;





extern int pclose (FILE *__stream);





extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__));
# 840 "/usr/include/stdio.h" 3 4
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
# 868 "/usr/include/stdio.h" 3 4

# 40 "/home/user42/git/MinCond/csmith_runtime_orig/platform_generic.h" 2



# 42 "/home/user42/git/MinCond/csmith_runtime_orig/platform_generic.h"
static void
platform_main_begin(void)
{

}

static void
platform_main_end(uint32_t crc, int flag)
{





 printf ("checksum = %X\n", crc);
# 120 "/home/user42/git/MinCond/csmith_runtime_orig/platform_generic.h"
}
# 90 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2
# 102 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h"
# 1 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 1
# 13 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
static int8_t
(safe_unary_minus_func_int8_t_s)(int8_t si )
{
 
  return






    -si;
}

static int8_t
(safe_add_func_int8_t_s_s)(int8_t si1, int8_t si2 )
{
 
  return






    (si1 + si2);
}

static int8_t
(safe_sub_func_int8_t_s_s)(int8_t si1, int8_t si2 )
{
 
  return






    (si1 - si2);
}

static int8_t
(safe_mul_func_int8_t_s_s)(int8_t si1, int8_t si2 )
{
 
  return






    si1 * si2;
}

static int8_t
(safe_mod_func_int8_t_s_s)(int8_t si1, int8_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 75 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-128)
# 75 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                   ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 % si2);
}

static int8_t
(safe_div_func_int8_t_s_s)(int8_t si1, int8_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 87 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-128)
# 87 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                   ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 / si2);
}

static int8_t
(safe_lshift_func_int8_t_s_s)(int8_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32) || (left > (
# 99 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                         (127) 
# 99 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                  >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static int8_t
(safe_lshift_func_int8_t_s_u)(int8_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32) || (left > (
# 111 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                            (127) 
# 111 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                     >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static int8_t
(safe_rshift_func_int8_t_s_s)(int8_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32))?
    ((left)) :

    (left >> ((int)right));
}

static int8_t
(safe_rshift_func_int8_t_s_u)(int8_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32)) ?
    ((left)) :

    (left >> ((unsigned int)right));
}



static int16_t
(safe_unary_minus_func_int16_t_s)(int16_t si )
{
 
  return






    -si;
}

static int16_t
(safe_add_func_int16_t_s_s)(int16_t si1, int16_t si2 )
{
 
  return






    (si1 + si2);
}

static int16_t
(safe_sub_func_int16_t_s_s)(int16_t si1, int16_t si2 )
{
 
  return






    (si1 - si2);
}

static int16_t
(safe_mul_func_int16_t_s_s)(int16_t si1, int16_t si2 )
{
 
  return






    si1 * si2;
}

static int16_t
(safe_mod_func_int16_t_s_s)(int16_t si1, int16_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 205 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-32767-1)
# 205 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 % si2);
}

static int16_t
(safe_div_func_int16_t_s_s)(int16_t si1, int16_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 217 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-32767-1)
# 217 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 / si2);
}

static int16_t
(safe_lshift_func_int16_t_s_s)(int16_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32) || (left > (
# 229 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                         (32767) 
# 229 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                   >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static int16_t
(safe_lshift_func_int16_t_s_u)(int16_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32) || (left > (
# 241 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                            (32767) 
# 241 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static int16_t
(safe_rshift_func_int16_t_s_s)(int16_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32))?
    ((left)) :

    (left >> ((int)right));
}

static int16_t
(safe_rshift_func_int16_t_s_u)(int16_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32)) ?
    ((left)) :

    (left >> ((unsigned int)right));
}



static int32_t
(safe_unary_minus_func_int32_t_s)(int32_t si )
{
 
  return


    (si==
# 280 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
        (-2147483647-1)
# 280 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                 ) ?
    ((si)) :


    -si;
}

static int32_t
(safe_add_func_int32_t_s_s)(int32_t si1, int32_t si2 )
{
 
  return


    (((si1>0) && (si2>0) && (si1 > (
# 294 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                   (2147483647)
# 294 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                            -si2))) || ((si1<0) && (si2<0) && (si1 < (
# 294 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                      (-2147483647-1)
# 294 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                               -si2)))) ?
    ((si1)) :


    (si1 + si2);
}

static int32_t
(safe_sub_func_int32_t_s_s)(int32_t si1, int32_t si2 )
{
 
  return


    (((si1^si2) & (((si1 ^ ((si1^si2) & (~
# 308 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                         (2147483647)
# 308 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                  )))-si2)^si2)) < 0) ?
    ((si1)) :


    (si1 - si2);
}

static int32_t
(safe_mul_func_int32_t_s_s)(int32_t si1, int32_t si2 )
{
 
  return


    (((si1 > 0) && (si2 > 0) && (si1 > (
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                       (2147483647) 
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                 / si2))) || ((si1 > 0) && (si2 <= 0) && (si2 < (
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                 (-2147483647-1) 
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                           / si1))) || ((si1 <= 0) && (si2 > 0) && (si1 < (
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                                                                           (-2147483647-1) 
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                                                                                     / si2))) || ((si1 <= 0) && (si2 <= 0) && (si1 != 0) && (si2 < (
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                                                                                                                                                    (2147483647) 
# 322 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                                                                                                                                                              / si1)))) ?
    ((si1)) :


    si1 * si2;
}

static int32_t
(safe_mod_func_int32_t_s_s)(int32_t si1, int32_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 335 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-2147483647-1)
# 335 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 % si2);
}

static int32_t
(safe_div_func_int32_t_s_s)(int32_t si1, int32_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 347 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-2147483647-1)
# 347 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 / si2);
}

static int32_t
(safe_lshift_func_int32_t_s_s)(int32_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32) || (left > (
# 359 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                         (2147483647) 
# 359 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                   >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static int32_t
(safe_lshift_func_int32_t_s_u)(int32_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32) || (left > (
# 371 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                            (2147483647) 
# 371 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static int32_t
(safe_rshift_func_int32_t_s_s)(int32_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32))?
    ((left)) :

    (left >> ((int)right));
}

static int32_t
(safe_rshift_func_int32_t_s_u)(int32_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32)) ?
    ((left)) :

    (left >> ((unsigned int)right));
}




static int64_t
(safe_unary_minus_func_int64_t_s)(int64_t si )
{
 
  return


    (si==
# 411 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
        (-9223372036854775807L -1)
# 411 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                 ) ?
    ((si)) :


    -si;
}

static int64_t
(safe_add_func_int64_t_s_s)(int64_t si1, int64_t si2 )
{
 
  return


    (((si1>0) && (si2>0) && (si1 > (
# 425 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                   (9223372036854775807L)
# 425 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                            -si2))) || ((si1<0) && (si2<0) && (si1 < (
# 425 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                      (-9223372036854775807L -1)
# 425 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                               -si2)))) ?
    ((si1)) :


    (si1 + si2);
}

static int64_t
(safe_sub_func_int64_t_s_s)(int64_t si1, int64_t si2 )
{
 
  return


    (((si1^si2) & (((si1 ^ ((si1^si2) & (~
# 439 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                         (9223372036854775807L)
# 439 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                  )))-si2)^si2)) < 0) ?
    ((si1)) :


    (si1 - si2);
}

static int64_t
(safe_mul_func_int64_t_s_s)(int64_t si1, int64_t si2 )
{
 
  return


    (((si1 > 0) && (si2 > 0) && (si1 > (
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                       (9223372036854775807L) 
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                 / si2))) || ((si1 > 0) && (si2 <= 0) && (si2 < (
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                 (-9223372036854775807L -1) 
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                           / si1))) || ((si1 <= 0) && (si2 > 0) && (si1 < (
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                                                                           (-9223372036854775807L -1) 
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                                                                                     / si2))) || ((si1 <= 0) && (si2 <= 0) && (si1 != 0) && (si2 < (
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                                                                                                                                                                                    (9223372036854775807L) 
# 453 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                                                                                                                                                                              / si1)))) ?
    ((si1)) :


    si1 * si2;
}

static int64_t
(safe_mod_func_int64_t_s_s)(int64_t si1, int64_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 466 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-9223372036854775807L -1)
# 466 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 % si2);
}

static int64_t
(safe_div_func_int64_t_s_s)(int64_t si1, int64_t si2 )
{
 
  return

    ((si2 == 0) || ((si1 == 
# 478 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                           (-9223372036854775807L -1)
# 478 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                    ) && (si2 == (-1)))) ?
    ((si1)) :

    (si1 / si2);
}

static int64_t
(safe_lshift_func_int64_t_s_s)(int64_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32) || (left > (
# 490 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                                         (9223372036854775807L) 
# 490 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                                   >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static int64_t
(safe_lshift_func_int64_t_s_u)(int64_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32) || (left > (
# 502 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                            (9223372036854775807L) 
# 502 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static int64_t
(safe_rshift_func_int64_t_s_s)(int64_t left, int right )
{
 
  return

    ((left < 0) || (((int)right) < 0) || (((int)right) >= 32))?
    ((left)) :

    (left >> ((int)right));
}

static int64_t
(safe_rshift_func_int64_t_s_u)(int64_t left, unsigned int right )
{
 
  return

    ((left < 0) || (((unsigned int)right) >= 32)) ?
    ((left)) :

    (left >> ((unsigned int)right));
}







static uint8_t
(safe_unary_minus_func_uint8_t_u)(uint8_t ui )
{
 
  return -ui;
}

static uint8_t
(safe_add_func_uint8_t_u_u)(uint8_t ui1, uint8_t ui2 )
{
 
  return ui1 + ui2;
}

static uint8_t
(safe_sub_func_uint8_t_u_u)(uint8_t ui1, uint8_t ui2 )
{
 
  return ui1 - ui2;
}

static uint8_t
(safe_mul_func_uint8_t_u_u)(uint8_t ui1, uint8_t ui2 )
{
 
  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static uint8_t
(safe_mod_func_uint8_t_u_u)(uint8_t ui1, uint8_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 % ui2);
}

static uint8_t
(safe_div_func_uint8_t_u_u)(uint8_t ui1, uint8_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 / ui2);
}

static uint8_t
(safe_lshift_func_uint8_t_u_s)(uint8_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32) || (left > (
# 596 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                           (255) 
# 596 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                     >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static uint8_t
(safe_lshift_func_uint8_t_u_u)(uint8_t left, unsigned int right )
{
 
  return

    ((((unsigned int)right) >= 32) || (left > (
# 608 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                              (255) 
# 608 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                        >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static uint8_t
(safe_rshift_func_uint8_t_u_s)(uint8_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32)) ?
    ((left)) :

    (left >> ((int)right));
}

static uint8_t
(safe_rshift_func_uint8_t_u_u)(uint8_t left, unsigned int right )
{
 
  return

    (((unsigned int)right) >= 32) ?
    ((left)) :

    (left >> ((unsigned int)right));
}



static uint16_t
(safe_unary_minus_func_uint16_t_u)(uint16_t ui )
{
 
  return -ui;
}

static uint16_t
(safe_add_func_uint16_t_u_u)(uint16_t ui1, uint16_t ui2 )
{
 
  return ui1 + ui2;
}

static uint16_t
(safe_sub_func_uint16_t_u_u)(uint16_t ui1, uint16_t ui2 )
{
 
  return ui1 - ui2;
}

static uint16_t
(safe_mul_func_uint16_t_u_u)(uint16_t ui1, uint16_t ui2 )
{
 
  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static uint16_t
(safe_mod_func_uint16_t_u_u)(uint16_t ui1, uint16_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 % ui2);
}

static uint16_t
(safe_div_func_uint16_t_u_u)(uint16_t ui1, uint16_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 / ui2);
}

static uint16_t
(safe_lshift_func_uint16_t_u_s)(uint16_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32) || (left > (
# 698 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                           (65535) 
# 698 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static uint16_t
(safe_lshift_func_uint16_t_u_u)(uint16_t left, unsigned int right )
{
 
  return

    ((((unsigned int)right) >= 32) || (left > (
# 710 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                              (65535) 
# 710 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                         >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static uint16_t
(safe_rshift_func_uint16_t_u_s)(uint16_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32)) ?
    ((left)) :

    (left >> ((int)right));
}

static uint16_t
(safe_rshift_func_uint16_t_u_u)(uint16_t left, unsigned int right )
{
 
  return

    (((unsigned int)right) >= 32) ?
    ((left)) :

    (left >> ((unsigned int)right));
}



static uint32_t
(safe_unary_minus_func_uint32_t_u)(uint32_t ui )
{
 
  return -ui;
}

static uint32_t
(safe_add_func_uint32_t_u_u)(uint32_t ui1, uint32_t ui2 )
{
 
  return ui1 + ui2;
}

static uint32_t
(safe_sub_func_uint32_t_u_u)(uint32_t ui1, uint32_t ui2 )
{
 
  return ui1 - ui2;
}

static uint32_t
(safe_mul_func_uint32_t_u_u)(uint32_t ui1, uint32_t ui2 )
{
 
  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static uint32_t
(safe_mod_func_uint32_t_u_u)(uint32_t ui1, uint32_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 % ui2);
}

static uint32_t
(safe_div_func_uint32_t_u_u)(uint32_t ui1, uint32_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 / ui2);
}

static uint32_t
(safe_lshift_func_uint32_t_u_s)(uint32_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32) || (left > (
# 800 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                           (4294967295U) 
# 800 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static uint32_t
(safe_lshift_func_uint32_t_u_u)(uint32_t left, unsigned int right )
{
 
  return

    ((((unsigned int)right) >= 32) || (left > (
# 812 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                              (4294967295U) 
# 812 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                         >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static uint32_t
(safe_rshift_func_uint32_t_u_s)(uint32_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32)) ?
    ((left)) :

    (left >> ((int)right));
}

static uint32_t
(safe_rshift_func_uint32_t_u_u)(uint32_t left, unsigned int right )
{
 
  return

    (((unsigned int)right) >= 32) ?
    ((left)) :

    (left >> ((unsigned int)right));
}




static uint64_t
(safe_unary_minus_func_uint64_t_u)(uint64_t ui )
{
 
  return -ui;
}

static uint64_t
(safe_add_func_uint64_t_u_u)(uint64_t ui1, uint64_t ui2 )
{
 
  return ui1 + ui2;
}

static uint64_t
(safe_sub_func_uint64_t_u_u)(uint64_t ui1, uint64_t ui2 )
{
 
  return ui1 - ui2;
}

static uint64_t
(safe_mul_func_uint64_t_u_u)(uint64_t ui1, uint64_t ui2 )
{
 
  return ((unsigned long long)ui1) * ((unsigned long long)ui2);
}

static uint64_t
(safe_mod_func_uint64_t_u_u)(uint64_t ui1, uint64_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 % ui2);
}

static uint64_t
(safe_div_func_uint64_t_u_u)(uint64_t ui1, uint64_t ui2 )
{
 
  return

    (ui2 == 0) ?
    ((ui1)) :

    (ui1 / ui2);
}

static uint64_t
(safe_lshift_func_uint64_t_u_s)(uint64_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32) || (left > (
# 903 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                                           (18446744073709551615UL) 
# 903 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                                      >> ((int)right)))) ?
    ((left)) :

    (left << ((int)right));
}

static uint64_t
(safe_lshift_func_uint64_t_u_u)(uint64_t left, unsigned int right )
{
 
  return

    ((((unsigned int)right) >= 32) || (left > (
# 915 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                              (18446744073709551615UL) 
# 915 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                                         >> ((unsigned int)right)))) ?
    ((left)) :

    (left << ((unsigned int)right));
}

static uint64_t
(safe_rshift_func_uint64_t_u_s)(uint64_t left, int right )
{
 
  return

    ((((int)right) < 0) || (((int)right) >= 32)) ?
    ((left)) :

    (left >> ((int)right));
}

static uint64_t
(safe_rshift_func_uint64_t_u_u)(uint64_t left, unsigned int right )
{
 
  return

    (((unsigned int)right) >= 32) ?
    ((left)) :

    (left >> ((unsigned int)right));
}
# 953 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
static float
(safe_add_func_float_f_f)(float sf1, float sf2 )
{
 
  return

    (fabsf((0.5f * sf1) + (0.5f * sf2)) > (0.5f * 3.40282346638528859811704183484516925e+38F)) ?
    (sf1) :

    (sf1 + sf2);
}

static float
(safe_sub_func_float_f_f)(float sf1, float sf2 )
{
 
  return

    (fabsf((0.5f * sf1) - (0.5f * sf2)) > (0.5f * 3.40282346638528859811704183484516925e+38F)) ?
    (sf1) :

    (sf1 - sf2);
}

static float
(safe_mul_func_float_f_f)(float sf1, float sf2 )
{
 
  return


    (fabsf((0x1.0p-100f * sf1) * (0x1.0p-28f * sf2)) > (0x1.0p-100f * (0x1.0p-28f * 3.40282346638528859811704183484516925e+38F))) ?



    (sf1) :

    (sf1 * sf2);
}

static float
(safe_div_func_float_f_f)(float sf1, float sf2 )
{
 
  return


    ((fabsf(sf2) < 1.0f) && (((sf2 == 0.0f) || (fabsf((0x1.0p-49f * sf1) / (0x1.0p100f * sf2))) > (0x1.0p-100f * (0x1.0p-49f * 3.40282346638528859811704183484516925e+38F))))) ?



    (sf1) :

    (sf1 / sf2);
}




static double
(safe_add_func_double_f_f)(double sf1, double sf2 )
{
 
  return

    (fabs((0.5 * sf1) + (0.5 * sf2)) > (0.5 * ((double)1.79769313486231570814527423731704357e+308L))) ?
    (sf1) :

    (sf1 + sf2);
}

static double
(safe_sub_func_double_f_f)(double sf1, double sf2 )
{
 
  return

    (fabs((0.5 * sf1) - (0.5 * sf2)) > (0.5 * ((double)1.79769313486231570814527423731704357e+308L))) ?
    (sf1) :

    (sf1 - sf2);
}

static double
(safe_mul_func_double_f_f)(double sf1, double sf2 )
{
 
  return


    (fabs((0x1.0p-100 * sf1) * (0x1.0p-924 * sf2)) > (0x1.0p-100 * (0x1.0p-924 * ((double)1.79769313486231570814527423731704357e+308L)))) ?



    (sf1) :

    (sf1 * sf2);
}

static double
(safe_div_func_double_f_f)(double sf1, double sf2 )
{
 
  return


    ((fabs(sf2) < 1.0) && (((sf2 == 0.0) || (fabs((0x1.0p-974 * sf1) / (0x1.0p100 * sf2))) > (0x1.0p-100 * (0x1.0p-974 * ((double)1.79769313486231570814527423731704357e+308L)))))) ?



    (sf1) :

    (sf1 / sf2);
}
# 1193 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
static int32_t
(safe_convert_func_float_to_int32_t)(float sf1 )
{
 
  return

    ((sf1 <= 
# 1199 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
            (-2147483647-1)
# 1199 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                     ) || (sf1 >= 
# 1199 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
                                  (2147483647)
# 1199 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
                                           )) ?
    (
# 1200 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h" 3 4
   (2147483647)
# 1200 "/home/user42/git/MinCond/csmith_runtime_orig_build/safe_math.h"
   ) :

    ((int32_t)(sf1));
}
# 103 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2
# 1 "/home/user42/git/MinCond/csmith_runtime_orig_build/unsafe_math.h" 1
# 13 "/home/user42/git/MinCond/csmith_runtime_orig_build/unsafe_math.h"
static signed char
safe_unary_minus_func_int8_t_s_unsafe_macro(signed char si )
{

  return






    -si;
}

static signed char
safe_add_func_int8_t_s_s_unsafe_macro(signed char si1, signed char si2 )
{

  return






    (si1 + si2);
}

static signed char
safe_sub_func_int8_t_s_s_unsafe_macro(signed char si1, signed char si2 )
{

  return






    (si1 - si2);
}

static signed char
safe_mul_func_int8_t_s_s_unsafe_macro(signed char si1, signed char si2 )
{

  return






    si1 * si2;
}

static signed char
safe_mod_func_int8_t_s_s_unsafe_macro(signed char si1, signed char si2 )
{

  return




    (si1 % si2);
}

static signed char
safe_div_func_int8_t_s_s_unsafe_macro(signed char si1, signed char si2 )
{

  return




    (si1 / si2);
}

static signed char
safe_lshift_func_int8_t_s_s_unsafe_macro(signed char left, int right )
{

  return




    (left << ((int)right));
}

static signed char
safe_lshift_func_int8_t_s_u_unsafe_macro(signed char left, unsigned int right )
{

  return




    (left << ((unsigned int)right));
}

static signed char
safe_rshift_func_int8_t_s_s_unsafe_macro(signed char left, int right )
{

  return




    (left >> ((int)right));
}

static signed char
safe_rshift_func_int8_t_s_u_unsafe_macro(signed char left, unsigned int right )
{

  return




    (left >> ((unsigned int)right));
}



static short
safe_unary_minus_func_int16_t_s_unsafe_macro(short si )
{

  return






    -si;
}

static short
safe_add_func_int16_t_s_s_unsafe_macro(short si1, short si2 )
{

  return






    (si1 + si2);
}

static short
safe_sub_func_int16_t_s_s_unsafe_macro(short si1, short si2 )
{

  return






    (si1 - si2);
}

static short
safe_mul_func_int16_t_s_s_unsafe_macro(short si1, short si2 )
{

  return






    si1 * si2;
}

static short
safe_mod_func_int16_t_s_s_unsafe_macro(short si1, short si2 )
{

  return




    (si1 % si2);
}

static short
safe_div_func_int16_t_s_s_unsafe_macro(short si1, short si2 )
{

  return




    (si1 / si2);
}

static short
safe_lshift_func_int16_t_s_s_unsafe_macro(short left, int right )
{

  return




    (left << ((int)right));
}

static short
safe_lshift_func_int16_t_s_u_unsafe_macro(short left, unsigned int right )
{

  return




    (left << ((unsigned int)right));
}

static short
safe_rshift_func_int16_t_s_s_unsafe_macro(short left, int right )
{

  return




    (left >> ((int)right));
}

static short
safe_rshift_func_int16_t_s_u_unsafe_macro(short left, unsigned int right )
{

  return




    (left >> ((unsigned int)right));
}



static int
safe_unary_minus_func_int32_t_s_unsafe_macro(int si )
{

  return






    -si;
}

static int
safe_add_func_int32_t_s_s_unsafe_macro(int si1, int si2 )
{

  return






    (si1 + si2);
}

static int
safe_sub_func_int32_t_s_s_unsafe_macro(int si1, int si2 )
{

  return
    (si1 - si2);
}

static int
safe_mul_func_int32_t_s_s_unsafe_macro(int si1, int si2 )
{

  return
    si1 * si2;
}

static int
safe_mod_func_int32_t_s_s_unsafe_macro(int si1, int si2 )
{

  return
    (si1 % si2);
}

static int
safe_div_func_int32_t_s_s_unsafe_macro(int si1, int si2 )
{

  return
    (si1 / si2);
}

static int
safe_lshift_func_int32_t_s_s_unsafe_macro(int left, int right )
{

  return
    (left << ((int)right));
}

static int
safe_lshift_func_int32_t_s_u_unsafe_macro(int left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static int
safe_rshift_func_int32_t_s_s_unsafe_macro(int left, int right )
{

  return
    (left >> ((int)right));
}

static int
safe_rshift_func_int32_t_s_u_unsafe_macro(int left, unsigned int right )
{

  return
    (left >> ((unsigned int)right));
}




static long long
safe_unary_minus_func_int64_t_s_unsafe_macro(long long si )
{

  return
    -si;
}

static long long
safe_add_func_int64_t_s_s_unsafe_macro(long long si1, long long si2 )
{

  return
    (si1 + si2);
}

static long long
safe_sub_func_int64_t_s_s_unsafe_macro(long long si1, long long si2 )
{

  return
    (si1 - si2);
}

static long long
safe_mul_func_int64_t_s_s_unsafe_macro(long long si1, long long si2 )
{

  return
    si1 * si2;
}

static long long
safe_mod_func_int64_t_s_s_unsafe_macro(long long si1, long long si2 )
{

  return
    (si1 % si2);
}

static long long
safe_div_func_int64_t_s_s_unsafe_macro(long long si1, long long si2 )
{

  return
    (si1 / si2);
}

static long long
safe_lshift_func_int64_t_s_s_unsafe_macro(long long left, int right )
{

  return
    (left << ((int)right));
}

static long long
safe_lshift_func_int64_t_s_u_unsafe_macro(long long left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static long long
safe_rshift_func_int64_t_s_s_unsafe_macro(long long left, int right )
{

  return
    (left >> ((int)right));
}

static long long
safe_rshift_func_int64_t_s_u_unsafe_macro(long long left, unsigned int right )
{

  return
    (left >> ((unsigned int)right));
}







static unsigned char
safe_unary_minus_func_uint8_t_u_unsafe_macro(unsigned char ui )
{

  return -ui;
}

static unsigned char
safe_add_func_uint8_t_u_u_unsafe_macro(unsigned char ui1, unsigned char ui2 )
{

  return ui1 + ui2;
}

static unsigned char
safe_sub_func_uint8_t_u_u_unsafe_macro(unsigned char ui1, unsigned char ui2 )
{

  return ui1 - ui2;
}

static unsigned char
safe_mul_func_uint8_t_u_u_unsafe_macro(unsigned char ui1, unsigned char ui2 )
{

  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static unsigned char
safe_mod_func_uint8_t_u_u_unsafe_macro(unsigned char ui1, unsigned char ui2 )
{

  return
    (ui1 % ui2);
}

static unsigned char
safe_div_func_uint8_t_u_u_unsafe_macro(unsigned char ui1, unsigned char ui2 )
{

  return
    (ui1 / ui2);
}

static unsigned char
safe_lshift_func_uint8_t_u_s_unsafe_macro(unsigned char left, int right )
{

  return
    (left << ((int)right));
}

static unsigned char
safe_lshift_func_uint8_t_u_u_unsafe_macro(unsigned char left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static unsigned char
safe_rshift_func_uint8_t_u_s_unsafe_macro(unsigned char left, int right )
{

  return
    (left >> ((int)right));
}

static unsigned char
safe_rshift_func_uint8_t_u_u_unsafe_macro(unsigned char left, unsigned int right )
{

  return
    (left >> ((unsigned int)right));
}



static unsigned short
safe_unary_minus_func_uint16_t_u_unsafe_macro(unsigned short ui )
{

  return -ui;
}

static unsigned short
safe_add_func_uint16_t_u_u_unsafe_macro(unsigned short ui1, unsigned short ui2 )
{

  return ui1 + ui2;
}

static unsigned short
safe_sub_func_uint16_t_u_u_unsafe_macro(unsigned short ui1, unsigned short ui2 )
{

  return ui1 - ui2;
}

static unsigned short
safe_mul_func_uint16_t_u_u_unsafe_macro(unsigned short ui1, unsigned short ui2 )
{

  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static unsigned short
safe_mod_func_uint16_t_u_u_unsafe_macro(unsigned short ui1, unsigned short ui2 )
{

  return
    (ui1 % ui2);
}

static unsigned short
safe_div_func_uint16_t_u_u_unsafe_macro(unsigned short ui1, unsigned short ui2 )
{

  return
    (ui1 / ui2);
}

static unsigned short
safe_lshift_func_uint16_t_u_s_unsafe_macro(unsigned short left, int right )
{

  return
    (left << ((int)right));
}

static unsigned short
safe_lshift_func_uint16_t_u_u_unsafe_macro(unsigned short left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static unsigned short
safe_rshift_func_uint16_t_u_s_unsafe_macro(unsigned short left, int right )
{

  return
    (left >> ((int)right));
}

static unsigned short
safe_rshift_func_uint16_t_u_u_unsafe_macro(unsigned short left, unsigned int right )
{

  return
    (left >> ((unsigned int)right));
}



static unsigned
safe_unary_minus_func_uint32_t_u_unsafe_macro(unsigned ui )
{

  return -ui;
}

static unsigned
safe_add_func_uint32_t_u_u_unsafe_macro(unsigned ui1, unsigned ui2 )
{

  return ui1 + ui2;
}

static unsigned
safe_sub_func_uint32_t_u_u_unsafe_macro(unsigned ui1, unsigned ui2 )
{

  return ui1 - ui2;
}

static unsigned
safe_mul_func_uint32_t_u_u_unsafe_macro(unsigned ui1, unsigned ui2 )
{

  return ((unsigned int)ui1) * ((unsigned int)ui2);
}

static unsigned
safe_mod_func_uint32_t_u_u_unsafe_macro(unsigned ui1, unsigned ui2 )
{

  return
    (ui1 % ui2);
}

static unsigned
safe_div_func_uint32_t_u_u_unsafe_macro(unsigned ui1, unsigned ui2 )
{

  return
    (ui1 / ui2);
}

static unsigned
safe_lshift_func_uint32_t_u_s_unsafe_macro(unsigned left, int right )
{

  return
    (left << ((int)right));
}

static unsigned
safe_lshift_func_uint32_t_u_u_unsafe_macro(unsigned left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static unsigned
safe_rshift_func_uint32_t_u_s_unsafe_macro(unsigned left, int right )
{

  return
    (left >> ((int)right));
}

static unsigned
safe_rshift_func_uint32_t_u_u_unsafe_macro(unsigned left, unsigned int right )
{
  return
    (left >> ((unsigned int)right));
}




static unsigned long long
safe_unary_minus_func_uint64_t_u_unsafe_macro(unsigned long long ui )
{
  return -ui;
}

static unsigned long long
safe_add_func_uint64_t_u_u_unsafe_macro(unsigned long long ui1, unsigned long long ui2 )
{
  return ui1 + ui2;
}

static unsigned long long
safe_sub_func_uint64_t_u_u_unsafe_macro(unsigned long long ui1, unsigned long long ui2 )
{
  return ui1 - ui2;
}

static unsigned long long
safe_mul_func_uint64_t_u_u_unsafe_macro(unsigned long long ui1, unsigned long long ui2 )
{
  return ((unsigned long long)ui1) * ((unsigned long long)ui2);
}

static unsigned long long
safe_mod_func_uint64_t_u_u_unsafe_macro(unsigned long long ui1, unsigned long long ui2 )
{

  return
    (ui1 % ui2);
}

static unsigned long long
safe_div_func_uint64_t_u_u_unsafe_macro(unsigned long long ui1, unsigned long long ui2 )
{

  return
    (ui1 / ui2);
}

static unsigned long long
safe_lshift_func_uint64_t_u_s_unsafe_macro(unsigned long long left, int right )
{

  return
    (left << ((int)right));
}

static unsigned long long
safe_lshift_func_uint64_t_u_u_unsafe_macro(unsigned long long left, unsigned int right )
{

  return
    (left << ((unsigned int)right));
}

static unsigned long long
safe_rshift_func_uint64_t_u_s_unsafe_macro(unsigned long long left, int right )
{

  return
    (left >> ((int)right));
}

static unsigned long long
safe_rshift_func_uint64_t_u_u_unsafe_macro(unsigned long long left, unsigned int right )
{

  return
    (left >> ((unsigned int)right));
}



static float
safe_add_func_float_f_f_unsafe_macro(float sf1, float sf2 )
{

  return
    (sf1 + sf2);
}

static float
safe_sub_func_float_f_f_unsafe_macro(float sf1, float sf2 )
{

  return
    (sf1 - sf2);
}

static float
safe_mul_func_float_f_f_unsafe_macro(float sf1, float sf2 )
{

  return
    (sf1 * sf2);
}

static float
safe_div_func_float_f_f_unsafe_macro(float sf1, float sf2 )
{

  return
    (sf1 / sf2);
}




static double
safe_add_func_double_f_f_unsafe_macro(double sf1, double sf2 )
{

  return
    (sf1 + sf2);
}

static double
safe_sub_func_double_f_f_unsafe_macro(double sf1, double sf2 )
{

  return
    (sf1 - sf2);
}

static double
safe_mul_func_double_f_f_unsafe_macro(double sf1, double sf2 )
{

  return
    (sf1 * sf2);
}

static double
safe_div_func_double_f_f_unsafe_macro(double sf1, double sf2 )
{

  return
    (sf1 / sf2);
}

static int
safe_convert_func_float_to_int32_t_unsafe_macro(float sf1 )
{

  return
    ((int)(sf1));
}
# 104 "/home/user42/git/MinCond/csmith_runtime_orig/random_inc.h" 2
# 46 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h" 2

static uint32_t crc32_tab[256];
static uint32_t crc32_context = 0xFFFFFFFFUL;

static void
crc32_gentab (void)
{
 uint32_t crc;
 const uint32_t poly = 0xEDB88320UL;
 int i, j;

 for (i = 0; i < 256; i++) {
  crc = i;
  for (j = 8; j > 0; j--) {
   if (crc & 1) {
    crc = (crc >> 1) ^ poly;
   } else {
    crc >>= 1;
   }
  }
  crc32_tab[i] = crc;
 }
}

static void
crc32_byte (uint8_t b) {
 crc32_context =
  ((crc32_context >> 8) & 0x00FFFFFF) ^
  crc32_tab[(crc32_context ^ b) & 0xFF];
}
# 96 "/home/user42/git/MinCond/csmith_runtime_orig/csmith.h"
static void
crc32_8bytes (uint64_t val)
{
 crc32_byte ((val>>0) & 0xff);
 crc32_byte ((val>>8) & 0xff);
 crc32_byte ((val>>16) & 0xff);
 crc32_byte ((val>>24) & 0xff);
 crc32_byte ((val>>32) & 0xff);
 crc32_byte ((val>>40) & 0xff);
 crc32_byte ((val>>48) & 0xff);
 crc32_byte ((val>>56) & 0xff);
}

static void
transparent_crc (uint64_t val, char* vname, int flag)
{
 crc32_8bytes(val);
 if (flag) {
    printf("...checksum after hashing %s : %lX\n", vname, crc32_context ^ 0xFFFFFFFFUL);
 }
}



static void
transparent_crc_bytes (char *ptr, int nbytes, char* vname, int flag)
{
    int i;
    for (i=0; i<nbytes; i++) {
        crc32_byte(ptr[i]);
    }
 if (flag) {
    printf("...checksum after hashing %s : %lX\n", vname, crc32_context ^ 0xFFFFFFFFUL);
 }
}
# 11 "__test877349189.c" 2


static long __undefined;


union U0 {
   int32_t f0;
   const volatile int8_t * f1;
   int8_t f2;
   const int64_t f3;
   const int16_t f4;
};


static int16_t g_16 = 1L;
static int8_t g_21 = 0xF1L;
static int8_t *g_20[8][8] = {{&g_21,(void*)0,&g_21,(void*)0,&g_21,&g_21,&g_21,&g_21},{(void*)0,&g_21,(void*)0,(void*)0,(void*)0,&g_21,&g_21,&g_21},{&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21},{&g_21,&g_21,(void*)0,&g_21,&g_21,&g_21,&g_21,&g_21},{&g_21,&g_21,(void*)0,&g_21,&g_21,(void*)0,&g_21,&g_21},{&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,(void*)0,&g_21},{&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21},{(void*)0,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,(void*)0}};
static int32_t g_103 = (-5L);
static int32_t g_113 = (-5L);
static int32_t g_118 = 0xB510C19EL;
static int16_t g_120 = 0x4FD4L;
static volatile uint32_t g_121 = 0xF5641E62L;
static int64_t g_131[5] = {1L,1L,1L,1L,1L};
static int64_t g_132 = 0xE07F6A708938AD39LL;
static uint16_t g_134 = 0xDBD1L;
static uint64_t g_140 = 0xBB5922496703B863LL;
static uint8_t g_146 = 1UL;
static volatile union U0 g_152[1] = {{-1L}};
static int8_t g_155[6] = {0xFFL,0xFFL,0xFFL,0xFFL,0xFFL,0xFFL};
static int32_t *g_156 = &g_113;
static uint8_t g_182 = 0x23L;
static int16_t g_183[7][5] = {{(-9L),0xAD43L,0x8F31L,1L,(-1L)},{0L,0x3B9AL,0x3B9AL,0L,1L},{(-9L),0x3877L,0L,3L,1L},{0x3B9AL,(-9L),(-1L),(-1L),(-1L)},{(-1L),(-1L),1L,3L,0L},{0x97A4L,0xC2ECL,1L,0L,0x3B9AL},{0x8F31L,1L,(-1L),1L,0x8F31L}};
static uint8_t **g_210 = (void*)0;
static int64_t *g_215[8] = {&g_132,&g_132,&g_132,&g_132,&g_132,&g_132,&g_132,&g_132};
static int64_t g_225 = 0x11529398376B8D06LL;
static const uint64_t *g_234 = (void*)0;
static uint32_t g_236 = 0UL;
static uint16_t g_292 = 0x2025L;
static int32_t g_309 = 0x51A493D7L;
static int32_t g_311 = 0x78ED7A29L;
static uint64_t g_312 = 0x75E5E3340633E0AALL;
static volatile uint8_t g_337 = 254UL;
static int32_t g_388 = 3L;
static volatile uint16_t g_457 = 0UL;
static uint16_t g_501 = 0xFA2BL;
static volatile int8_t g_537 = (-1L);
static volatile int32_t g_538 = 0xCD2B59D1L;
static int32_t g_539 = 0xC29A58C5L;
static volatile uint32_t g_540 = 1UL;
static uint64_t g_544 = 18446744073709551612UL;
static uint8_t *g_561 = &g_182;
static uint8_t **g_560 = &g_561;
static uint8_t *** volatile g_559 = &g_560;
static const int32_t *g_603 = &g_118;
static volatile uint32_t g_612 = 0x835ACE7CL;
static volatile uint32_t g_658 = 1UL;
static uint32_t g_700 = 4294967293UL;
static int16_t g_730 = 6L;
static int32_t * volatile g_745 = (void*)0;
static int32_t * volatile g_746[6][4] = {{&g_118,&g_388,&g_309,&g_118},{&g_309,&g_118,(void*)0,(void*)0},{&g_113,&g_113,&g_113,&g_113},{&g_113,&g_388,(void*)0,&g_113},{&g_309,&g_113,&g_309,(void*)0},{&g_118,&g_113,&g_113,&g_113}};
static int32_t * volatile g_747 = &g_118;
static uint16_t g_778 = 0x5169L;
static int32_t ** volatile g_814 = &g_156;
static int8_t g_848[1][6][3] = {{{0xCBL,0L,0L},{1L,0L,0L},{0xCBL,0L,0L},{1L,0L,0L},{0xCBL,0L,0L},{1L,0L,0L}}};
static int32_t ** volatile g_964[5] = {&g_156,&g_156,&g_156,&g_156,&g_156};
static int32_t ** volatile g_965 = &g_156;
static int32_t ** volatile g_999 = &g_156;
static int32_t ** volatile g_1036 = &g_156;
static uint32_t g_1073[2] = {18446744073709551607UL,18446744073709551607UL};
static uint32_t * const g_1137 = &g_700;
static uint32_t * const *g_1136 = &g_1137;
static int32_t ** volatile g_1138 = &g_156;
static union U0 g_1153[10] = {{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}};
static int32_t ** volatile g_1166 = &g_156;
static int32_t g_1201 = 0x6377CDC4L;
static int32_t g_1203 = (-1L);
static volatile uint32_t g_1210 = 0x54927182L;
static uint8_t ***g_1243 = &g_560;
static uint64_t g_1276 = 8UL;
static volatile int32_t g_1279 = 0x5AD0CFC2L;
static uint16_t g_1284 = 3UL;
static const int32_t ** volatile g_1288[8] = {&g_603,&g_603,&g_603,&g_603,&g_603,&g_603,&g_603,&g_603};
static uint16_t g_1310 = 65527UL;



static uint32_t func_1(void);
static union U0 func_8(uint16_t p_9, int8_t * p_10);
static uint16_t func_11(uint8_t p_12, const int16_t p_13, const int16_t p_14, int8_t * p_15);
static uint8_t func_17(int16_t p_18, int8_t * p_19);
static int64_t func_36(uint64_t p_37, int8_t * p_38, uint32_t p_39, uint8_t p_40, int8_t * p_41);
static uint8_t func_44(int8_t * p_45, int16_t p_46, int8_t p_47, uint32_t p_48);
static int8_t * func_49(int8_t * p_50, int8_t * p_51, const int32_t p_52, int8_t * p_53);
static uint64_t func_54(int8_t * p_55);
static int32_t func_58(int16_t p_59, uint64_t p_60, int16_t p_61);
static int8_t func_63(union U0 p_64, int32_t p_65, int16_t p_66, int8_t * p_67);
# 115 "__test877349189.c"
static uint32_t func_1(void)
{
    int8_t l_5[1];
    uint16_t *l_1198 = &g_292;
    int32_t l_1199 = 0x60174AF5L;
    int32_t *l_1200 = &g_1201;
    int32_t l_1204 = (-1L);
    int32_t l_1209[4][4][9] = {{{0x299A1684L,0xD34CB6B7L,3L,0L,0x566DB9DDL,0x6768F2FEL,0xA09F1987L,4L,0L},{0xA09F1987L,0xBA19D24AL,0x174A3F89L,0xB409EB73L,1L,0xDB779B89L,(-2L),0xBE05CB8DL,0x174A3F89L},{0x174A3F89L,0xD34CB6B7L,0xF2D71FADL,0L,0x6999FFD1L,0x3F7F32DEL,(-2L),1L,0x299A1684L},{0L,0x4F518CB9L,1L,3L,5L,0xA09F1987L,0xA09F1987L,5L,3L}},{{0xF2D71FADL,0xE0130BC9L,0xF2D71FADL,0x6768F2FEL,4L,0x86B67D71L,0x409C449AL,5L,0x305B5310L},{0x3F7F32DEL,0x4E79C1C0L,0x174A3F89L,0x305B5310L,0xBA19D24AL,1L,0x6701A302L,0x3F7F32DEL,0xC2DC7D51L},{0x48213F8AL,0x174A3F89L,0x6701A302L,0x48213F8AL,0L,0xC1728CD5L,0x58D6A1DAL,(-2L),0xC2DC7D51L},{(-1L),0x299A1684L,0xCD1CDD17L,0x6701A302L,(-9L),8L,0xA721DB9BL,0x409C449AL,8L}},{{0x8C7C6CFCL,3L,0x48213F8AL,6L,0L,(-1L),0x7BB305ACL,0L,0x6701A302L},{0x8C7C6CFCL,0x305B5310L,0x58D6A1DAL,(-1L),1L,0x7BB305ACL,(-2L),0xB409EB73L,(-2L)},{(-1L),0x409C449AL,0x21CD77EEL,0x21CD77EEL,0x409C449AL,(-1L),0L,0L,0x330BA0BEL},{0x48213F8AL,0x409C449AL,0x671A67EEL,0xC2DC7D51L,(-8L),8L,0x21CD77EEL,3L,6L}},{{0L,0x305B5310L,8L,0xCD1CDD17L,1L,0xC1728CD5L,0L,0x6768F2FEL,0x671A67EEL},{0x7BB305ACL,3L,8L,0L,0L,0x58D6A1DAL,(-2L),0x305B5310L,(-1L)},{0x21CD77EEL,0x299A1684L,0x671A67EEL,0xC1728CD5L,0x305B5310L,0x671A67EEL,0x7BB305ACL,0x6768F2FEL,0L},{0x330BA0BEL,0x174A3F89L,0x21CD77EEL,0xC1728CD5L,0xF2D71FADL,0L,0xA721DB9BL,3L,0x58D6A1DAL}}};
    union U0 l_1229 = {-1L};
    uint8_t ***l_1242[8][10] = {{&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_560,&g_210,&g_210},{&g_210,&g_560,&g_210,&g_210,&g_210,&g_210,&g_560,&g_210,(void*)0,&g_560},{&g_210,&g_210,&g_210,&g_560,&g_210,&g_210,&g_560,&g_210,&g_210,&g_210},{&g_210,&g_560,&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_210},{&g_210,&g_210,&g_210,&g_560,&g_210,(void*)0,&g_560,&g_560,(void*)0,&g_210},{&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_560,&g_210,&g_210,&g_560},{&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_210,&g_560,&g_210,&g_210},{&g_210,&g_560,&g_210,&g_210,&g_210,&g_210,&g_560,&g_210,(void*)0,&g_560}};
    int64_t *l_1258 = (void*)0;
    int32_t **l_1290[8][4][7] = {{{&l_1200,(void*)0,&l_1200,&l_1200,&l_1200,&g_156,(void*)0},{&g_156,&l_1200,(void*)0,&g_156,&l_1200,&g_156,&l_1200},{(void*)0,&g_156,(void*)0,&l_1200,(void*)0,&l_1200,&l_1200},{&l_1200,&g_156,&g_156,&l_1200,&g_156,&g_156,&g_156}},{{&l_1200,&l_1200,&l_1200,&g_156,(void*)0,&l_1200,&g_156},{&g_156,&l_1200,&l_1200,&l_1200,&g_156,&g_156,(void*)0},{(void*)0,&g_156,&l_1200,(void*)0,&g_156,&l_1200,&g_156},{&l_1200,&l_1200,&l_1200,&l_1200,(void*)0,&g_156,&l_1200}},{{&l_1200,&g_156,&l_1200,&l_1200,&g_156,&l_1200,&g_156},{(void*)0,&g_156,&l_1200,&l_1200,&l_1200,&l_1200,(void*)0},{&g_156,&l_1200,&g_156,&l_1200,&g_156,&g_156,&g_156},{(void*)0,&g_156,&g_156,(void*)0,&g_156,(void*)0,&g_156}},{{&l_1200,&g_156,&l_1200,&l_1200,&l_1200,&g_156,&l_1200},{&l_1200,&g_156,&g_156,&g_156,&g_156,&g_156,&g_156},{(void*)0,&l_1200,&g_156,&l_1200,(void*)0,(void*)0,(void*)0},{&g_156,&g_156,&g_156,&l_1200,&g_156,&g_156,(void*)0}},{{&l_1200,&g_156,&l_1200,&g_156,&g_156,&l_1200,&g_156},{&l_1200,&l_1200,&g_156,&l_1200,(void*)0,&l_1200,&l_1200},{&l_1200,&g_156,&g_156,&l_1200,&g_156,&g_156,&g_156},{&l_1200,&l_1200,&l_1200,&g_156,(void*)0,&l_1200,&g_156}},{{&g_156,&l_1200,&l_1200,&l_1200,&g_156,&g_156,(void*)0},{(void*)0,&g_156,&l_1200,(void*)0,&g_156,&l_1200,&g_156},{&l_1200,&l_1200,&l_1200,&l_1200,(void*)0,&g_156,&l_1200},{&l_1200,&g_156,&l_1200,&l_1200,&g_156,&l_1200,&g_156}},{{(void*)0,&g_156,&l_1200,&l_1200,&l_1200,&l_1200,(void*)0},{&g_156,&l_1200,&g_156,&l_1200,&g_156,&g_156,&g_156},{(void*)0,&g_156,&g_156,(void*)0,&g_156,(void*)0,&g_156},{&l_1200,&g_156,&l_1200,&l_1200,&l_1200,&g_156,&l_1200}},{{&l_1200,&g_156,&g_156,&g_156,&g_156,&g_156,&g_156},{(void*)0,&l_1200,&g_156,&l_1200,(void*)0,(void*)0,&g_156},{&g_156,&l_1200,&g_156,&g_156,&l_1200,&l_1200,&g_156},{&l_1200,&l_1200,&l_1200,&l_1200,(void*)0,&g_156,&g_156}}};
    int32_t *l_1291 = (void*)0;
    uint32_t *l_1303 = (void*)0;
    uint32_t **l_1302 = &l_1303;
    uint64_t *l_1308 = &g_1276;
    uint8_t l_1309 = 255UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_5[i] = 0xADL;
    (*l_1200) ^= (!(l_1199 = ((safe_mul_func_uint16_t_u_u (((*l_1198) = (l_5[0] < ((((func_8(func_11(g_16, (g_16 & func_17(l_5[0], g_20[5][6])), (~((l_5[0] != (safe_rshift_func_uint64_t_u_u (g_848[0][5][2], ((l_5[0] || g_730) ^ g_730)))) ^ g_1153[0].f0)), &l_5[0]), &g_848[0][5][2]) , l_5[0]) >= 0x68BB33FB1BC2721ELL) && l_5[0]) == 0UL))), 0L)) && l_5[0])));
    for (g_236 = 1; (g_236 <= 4); g_236 += 1)
    {
        int16_t l_1205 = 0xBF1BL;
        int32_t l_1206 = 0xAD45BE41L;
        int32_t l_1207 = 1L;
        int32_t l_1208 = 2L;
        int64_t **l_1226 = (void*)0;
        int64_t ***l_1227 = (void*)0;
        int64_t ***l_1228 = &l_1226;
        uint64_t *l_1232 = &g_140;
        uint64_t *l_1233 = &g_312;
        union U0 l_1251 = {0x8F1DCFECL};
        int32_t l_1259 = 1L;
        for (g_225 = 4; (g_225 >= 0); g_225 -= 1)
        {
            int32_t *l_1202[1][1];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1202[i][j] = &g_309;
            }
            if (g_183[(g_225 + 2)][g_236])
                break;
            --g_1210;
            (*l_1200) = (safe_div_func_uint16_t_u_u (((*l_1198)--), (safe_div_func_uint16_t_u_u (0x8827L, (g_134 = g_225)))));
        }
        if (((+((safe_sub_func_uint8_t_u_u (((*g_561) = (safe_unary_minus_func_int32_t_s (9L))), (-7L))) , (((1UL & (~(((*l_1233) = ((((safe_div_func_int8_t_s_s (((-1L) || ((((((*l_1228) = l_1226) == (void*)0) && ((((l_1229 , ((*l_1232) = (l_1206 < ((safe_mul_func_int32_t_s_s (l_1205, l_1205)) >= 0x6E873D50L)))) >= (*l_1200)) != g_1203) , (*l_1200))) > (*l_1200)) | g_183[4][0])), 5L)) || g_658) ^ 0x0D6EDBFCL) || (*l_1200))) , 0x0402C08E76E0538ALL))) != 0x6564L) & (-4L)))) & (*l_1200)))
        {
            uint16_t l_1234 = 65535UL;
            return l_1234;
        }
        else
        {
            int32_t l_1260[8][7] = {{0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L},{0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL},{0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L},{0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL},{0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L},{0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL},{0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L,0xFED7BB22L},{0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL,0x4D92A83BL}};
            int64_t *l_1261 = (void*)0;
            int64_t *l_1262 = &g_131[1];
            uint32_t l_1263 = 0UL;
            int16_t *l_1269 = &g_183[4][0];
            int32_t *l_1277 = &g_1203;
            int32_t l_1280 = 0x32DA78CDL;
            int32_t l_1282 = 0x0D7AC49CL;
            int32_t l_1283 = 1L;
            int i, j;
            (*l_1200) = (+(safe_sub_func_int32_t_s_s ((-9L), (safe_add_func_int32_t_s_s ((((*l_1262) |= (safe_rshift_func_int16_t_s_u (((((g_1243 = l_1242[1][6]) != &g_560) > ((safe_rshift_func_int32_t_s_s ((safe_sub_func_uint16_t_u_u (((1UL | ((~(l_1251 , (g_113 <= (((((*g_561)++) >= ((safe_lshift_func_int32_t_s_s (((**g_999) = 0xB8CAB3C2L), 9)) , (0x839E42A1L || ((void*)0 == l_1258)))) | l_1251.f0) >= l_1205)))) != l_1259)) < l_1260[5][1]), l_1260[5][1])), 11)) , (*l_1200))) && l_1206), 8))) <= l_1260[5][1]), l_1263)))));
            (*l_1277) ^= (safe_unary_minus_func_int64_t_s ((safe_mul_func_int64_t_s_s (((((safe_mul_func_uint16_t_u_u (((((*l_1269) = 0x86C8L) ^ (((**g_1136) | (**g_1036)) != ((safe_lshift_func_int16_t_s_s (0xE2B0L, 13)) >= ((safe_sub_func_int64_t_s_s ((0xEAF66A10L != (((safe_lshift_func_int32_t_s_s (((l_1261 == (g_215[5] = &g_132)) & ((((*l_1233) = 0x34E1B746AF7C06F7LL) && 0x5FD2E34A1D3150D5LL) != (*l_1200))), (*g_156))) , &g_1243) == &g_1243)), g_120)) , g_113)))) < 65531UL), g_848[0][2][1])) && (*l_1200)) >= g_1276) >= g_118), l_1263))));
            for (l_1208 = 4; (l_1208 >= 1); l_1208 -= 1)
            {
                int32_t *l_1278[9];
                int64_t l_1281 = 0xC2648294D501621DLL;
                int i;
                for (i = 0; i < 9; i++)
                    l_1278[i] = &l_1207;
                --g_1284;
            }
        }
        if ((*l_1200))
            continue;
        for (g_103 = 0; (g_103 <= 4); g_103 += 1)
        {
            const int32_t *l_1287 = &g_1201;
            const int32_t **l_1289 = &g_603;
            int i, j;
            (*l_1289) = l_1287;
            if (g_183[(g_103 + 1)][g_103])
                break;
        }
    }
    l_1291 = &l_1204;
    (*l_1200) = ((*g_156) = ((g_16 = (((safe_mod_func_uint64_t_u_u ((safe_mod_func_int8_t_s_s (((0xD4FF606A857AE524LL < (safe_lshift_func_uint32_t_u_s (((*l_1291) = (safe_add_func_int16_t_s_s (((void*)0 == (*g_559)), (((safe_sub_func_uint16_t_u_u (g_1284, ((((((((*l_1302) = (void*)0) == (void*)0) , ((*l_1291) || (safe_mul_func_uint8_t_u_u ((((*l_1291) | ((safe_mod_func_uint64_t_u_u (((*l_1308) = (*l_1200)), 0x06800F9DA342B02ALL)) ^ l_1309)) , (*l_1291)), (*l_1200))))) & (*l_1291)) , (*l_1291)) <= 0xD31623A3B42A5C73LL) & (*l_1200)))) , g_1276) , (*l_1200))))), 25))) != g_1201), (*l_1200))), g_225)) < 0xD72B565237794C44LL) <= g_1310)) < g_1153[0].f0));
    return g_312;
}







static union U0 func_8(uint16_t p_9, int8_t * p_10)
{
    int32_t *l_1195[9] = {&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118};
    int32_t **l_1196 = &g_156;
    union U0 l_1197[8][9][3] = {{{{0L},{-9L},{-9L}},{{0L},{-1L},{0x693EC3ECL}},{{-1L},{-2L},{0x538A7561L}},{{0x693EC3ECL},{1L},{0x273CDA8AL}},{{0L},{0xA1D0572BL},{0xE7D7E59CL}},{{-9L},{1L},{8L}},{{0x273CDA8AL},{-2L},{0L}},{{0x46A8E33DL},{-1L},{0x1463B4B4L}},{{0x1463B4B4L},{-9L},{0x1463B4B4L}}},{{{0x079BBF5EL},{0x693EC3ECL},{0L}},{{-9L},{0x538A7561L},{8L}},{{0L},{0x273CDA8AL},{0xE7D7E59CL}},{{0x538A7561L},{0xE7D7E59CL},{0x273CDA8AL}},{{0L},{8L},{0x538A7561L}},{{-9L},{0L},{0x693EC3ECL}},{{0x079BBF5EL},{0x1463B4B4L},{-9L}},{{0x1463B4B4L},{0x1463B4B4L},{-1L}},{{0x46A8E33DL},{0L},{-2L}}},{{{0x273CDA8AL},{8L},{1L}},{{-9L},{0xE7D7E59CL},{0xA1D0572BL}},{{0L},{0x273CDA8AL},{1L}},{{0x693EC3ECL},{0x538A7561L},{-2L}},{{-1L},{0x693EC3ECL},{-1L}},{{0L},{-9L},{-9L}},{{0L},{-1L},{0x693EC3ECL}},{{-1L},{-2L},{0x538A7561L}},{{0x693EC3ECL},{1L},{0x273CDA8AL}}},{{{0L},{0xA1D0572BL},{0xE7D7E59CL}},{{-9L},{1L},{8L}},{{0x273CDA8AL},{-2L},{0L}},{{0x46A8E33DL},{-1L},{0x1463B4B4L}},{{0x1463B4B4L},{-9L},{0x1463B4B4L}},{{0x079BBF5EL},{0x693EC3ECL},{0L}},{{-9L},{0x538A7561L},{8L}},{{0L},{0x273CDA8AL},{0xE7D7E59CL}},{{0x538A7561L},{0xE7D7E59CL},{0x273CDA8AL}}},{{{0L},{8L},{-2L}},{{0L},{0x079BBF5EL},{-9L}},{{0x538A7561L},{0xA1B4EADFL},{0x6F5FDB87L}},{{0xA1B4EADFL},{0xA1B4EADFL},{0xA1D0572BL}},{{0x1463B4B4L},{0x079BBF5EL},{0xE7D7E59CL}},{{-9L},{0x273CDA8AL},{0x46A8E33DL}},{{0x6F5FDB87L},{-1L},{0L}},{{0x079BBF5EL},{-9L},{0x46A8E33DL}},{{-9L},{-2L},{0xE7D7E59CL}}},{{{8L},{-9L},{0xA1D0572BL}},{{0L},{0x6F5FDB87L},{0x6F5FDB87L}},{{0L},{0xA1D0572BL},{-9L}},{{8L},{0xE7D7E59CL},{-2L}},{{-9L},{0x46A8E33DL},{-9L}},{{0x079BBF5EL},{0L},{-1L}},{{0x6F5FDB87L},{0x46A8E33DL},{0x273CDA8AL}},{{-9L},{0xE7D7E59CL},{0x079BBF5EL}},{{0x1463B4B4L},{0xA1D0572BL},{0xA1B4EADFL}}},{{{0xA1B4EADFL},{0x6F5FDB87L},{0xA1B4EADFL}},{{0x538A7561L},{-9L},{0x079BBF5EL}},{{0L},{-2L},{0x273CDA8AL}},{{1L},{-9L},{-1L}},{{-2L},{-1L},{-9L}},{{1L},{0x273CDA8AL},{-2L}},{{0L},{0x079BBF5EL},{-9L}},{{0x538A7561L},{0xA1B4EADFL},{0x6F5FDB87L}},{{0xA1B4EADFL},{0xA1B4EADFL},{0xA1D0572BL}}},{{{0x1463B4B4L},{0x079BBF5EL},{0xE7D7E59CL}},{{-9L},{0x273CDA8AL},{0x46A8E33DL}},{{0x6F5FDB87L},{-1L},{0L}},{{0x079BBF5EL},{-9L},{0x46A8E33DL}},{{-9L},{-2L},{0xE7D7E59CL}},{{8L},{-9L},{0xA1D0572BL}},{{0L},{0x6F5FDB87L},{0x6F5FDB87L}},{{0L},{0xA1D0572BL},{-9L}},{{8L},{0xE7D7E59CL},{-2L}}}};
    int i, j, k;
    (*l_1196) = l_1195[0];
    return l_1197[5][6][1];
}







static uint16_t func_11(uint8_t p_12, const int16_t p_13, const int16_t p_14, int8_t * p_15)
{
    int32_t *l_1165 = &g_309;
    int64_t * const l_1184 = &g_131[2];
    int16_t l_1194[2];
    int i;
    for (i = 0; i < 2; i++)
        l_1194[i] = (-2L);
    (*g_1166) = l_1165;
    for (g_539 = 22; (g_539 <= (-28)); --g_539)
    {
        int32_t **l_1169 = (void*)0;
        int32_t **l_1170 = &g_156;
        (*l_1170) = (*g_814);
        for (g_388 = 0; (g_388 >= (-17)); g_388 = safe_sub_func_int64_t_s_s (g_388, 3))
        {
            int64_t *l_1183 = &g_131[1];
            (*l_1165) = (((p_14 , (((safe_div_func_int32_t_s_s ((**g_965), ((safe_mod_func_int64_t_s_s (((safe_div_func_int8_t_s_s ((g_309 < ((safe_rshift_func_int64_t_s_u (((*l_1184) = (safe_rshift_func_uint16_t_u_s ((((l_1183 = l_1183) != l_1184) > ((**g_1136) , (safe_rshift_func_uint16_t_u_s ((g_778 ^= (~(((safe_lshift_func_uint16_t_u_s ((safe_div_func_uint32_t_u_u ((p_13 | (&p_13 != &p_13)), 0x920B55D6L)), (**l_1170))) , 0xCAA2L) == p_12))), g_309)))), p_12))), 60)) ^ 0xA1DAL)), (*l_1165))) , (**l_1170)), p_14)) , p_13))) | (*p_15)) ^ 0x03L)) ^ 0x143D3F45L) , 0xE05001F3L);
            return p_12;
        }
        return (*l_1165);
    }
    return l_1194[1];
}







static uint8_t func_17(int16_t p_18, int8_t * p_19)
{
    const int8_t *l_25 = &g_21;
    int32_t l_28 = 2L;
    int32_t l_29 = 0xD52A2848L;
    uint16_t *l_798 = (void*)0;
    int8_t *l_847 = &g_848[0][5][2];
    int32_t *l_1157 = &g_309;
    int32_t *l_1158[4][10][6] = {{{&g_309,&l_28,&l_28,&g_309,(void*)0,&g_388},{&g_103,&g_388,&l_29,&g_118,&g_309,&g_309},{&g_388,&g_118,&g_118,&g_118,&g_388,(void*)0},{&g_118,&g_388,&g_113,&l_28,&g_118,&g_388},{&g_118,(void*)0,(void*)0,&g_388,&g_118,&g_388},{&g_113,&g_103,&g_113,&g_309,&g_388,(void*)0},{&g_118,&g_113,&g_118,&l_28,(void*)0,&g_309},{&g_388,&l_28,&l_29,&l_29,&l_28,&g_388},{&g_118,(void*)0,&l_28,&l_28,&g_103,&g_118},{&g_309,&g_309,(void*)0,&g_118,&g_118,&g_388}},{{&g_309,&g_118,&g_118,&l_28,&l_28,(void*)0},{&g_118,&g_103,&g_388,&l_29,&g_118,&g_309},{&g_388,&g_309,(void*)0,&l_28,(void*)0,&g_309},{&g_118,&g_309,&g_103,&g_309,&g_388,&l_28},{&g_113,&l_28,(void*)0,&g_118,&g_103,&g_309},{&l_28,&l_28,&g_309,&g_103,&g_118,&g_103},{&g_309,&g_388,&g_113,&l_28,&g_118,&g_309},{&g_118,&g_309,&g_118,(void*)0,(void*)0,&g_118},{&l_28,&l_28,&g_103,&g_388,&g_118,&g_118},{&l_28,&g_118,&g_113,&g_118,&l_28,&g_103}},{{&g_103,&l_28,&g_113,&g_118,&l_28,&g_118},{(void*)0,&g_118,&g_103,&g_388,&l_29,&g_118},{&g_388,&l_29,&g_118,&g_309,&g_309,&g_309},{&g_113,(void*)0,&g_113,(void*)0,&l_28,&g_103},{&l_28,&g_309,&g_309,&l_28,(void*)0,&g_309},{&l_29,&g_113,(void*)0,&l_28,&g_103,(void*)0},{&l_28,&g_118,&g_309,(void*)0,&g_118,&g_309},{&g_113,&l_28,&g_118,&g_309,&g_118,&g_118},{&g_388,&g_118,&g_118,&g_388,&g_113,&g_103},{(void*)0,(void*)0,(void*)0,&g_118,&g_388,&l_28}},{{&g_103,&g_118,&g_388,&g_118,&g_388,(void*)0},{&l_28,(void*)0,&l_29,&g_388,&g_113,&g_118},{&l_28,&g_118,(void*)0,(void*)0,&g_118,&g_388},{&g_118,&l_28,&g_309,&l_28,&g_118,&g_113},{&g_309,&g_118,(void*)0,&g_103,&g_103,&g_118},{&l_28,&g_113,&g_309,&g_118,(void*)0,&g_118},{&l_28,&g_309,(void*)0,&l_28,&l_28,&g_113},{(void*)0,(void*)0,&g_309,&g_118,&g_309,&g_388},{&g_118,&l_29,(void*)0,(void*)0,&l_29,&g_118},{&g_103,&g_118,&l_29,&g_388,&l_28,(void*)0}}};
    uint8_t l_1159[9][6] = {{1UL,1UL,0xDFL,0xEDL,0x29L,0xEDL},{0xDFL,1UL,0xDFL,0x10L,0xA4L,4UL},{3UL,0x10L,0xEDL,0x70L,0xD8L,0xD8L},{0x70L,0xD8L,0xD8L,0x70L,0xEDL,0x10L},{3UL,4UL,0xA4L,0x10L,0xDFL,1UL},{0xDFL,0xEDL,0x29L,0xEDL,0xDFL,255UL},{255UL,0xD8L,0x29L,0x10L,1UL,0xEDL},{0xEDL,0x70L,0xD8L,0xD8L,0x70L,0xEDL},{0x10L,1UL,0x29L,4UL,0xEDL,255UL}};
    int i, j, k;
    l_29 ^= (safe_mul_func_uint64_t_u_u (18446744073709551611UL, (safe_unary_minus_func_int32_t_s (((l_25 != p_19) < (safe_rshift_func_uint8_t_u_s (p_18, l_28)))))));
    l_28 = (g_16 <= (safe_rshift_func_int64_t_s_u ((safe_mod_func_uint8_t_u_u ((safe_mod_func_int64_t_s_s (func_36((safe_lshift_func_int8_t_s_u (p_18, func_44(func_49(&g_21, &g_21, (func_54(((safe_lshift_func_uint64_t_u_s (p_18, 33)) , (void*)0)) & ((void*)0 != l_798)), g_20[3][3]), l_28, l_28, g_16))), p_19, g_730, l_28, l_847), p_18)), 0x72L)), l_28)));
    ++l_1159[3][3];
    return (*g_561);
}







static int64_t func_36(uint64_t p_37, int8_t * p_38, uint32_t p_39, uint8_t p_40, int8_t * p_41)
{
    int32_t **l_849 = &g_156;
    uint64_t *l_858[8][4] = {{&g_312,&g_140,&g_312,&g_312},{&g_140,&g_140,&g_312,&g_140},{&g_140,&g_312,&g_312,&g_140},{&g_312,&g_140,&g_312,&g_312},{&g_140,&g_140,&g_312,&g_140},{&g_140,&g_312,&g_312,&g_140},{&g_312,&g_140,&g_312,&g_312},{&g_140,&g_140,&g_312,&g_140}};
    int32_t l_861 = 1L;
    union U0 l_864 = {-3L};
    int64_t *l_865 = &g_131[3];
    uint8_t ***l_899 = &g_560;
    int32_t l_935[1];
    uint64_t l_939 = 18446744073709551609UL;
    uint8_t l_961[8] = {0x2EL,0x0BL,0x0BL,0x2EL,0x0BL,0x0BL,0x2EL,0x0BL};
    int16_t *l_1012 = &g_183[1][0];
    uint32_t l_1130 = 0xAC78EC41L;
    uint32_t * const l_1134 = &l_1130;
    uint32_t * const *l_1133[9][8];
    int32_t *l_1156 = (void*)0;
    int i, j;
    for (i = 0; i < 1; i++)
        l_935[i] = (-3L);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
            l_1133[i][j] = &l_1134;
    }
    (*l_849) = (void*)0;
    if ((safe_sub_func_int8_t_s_s (((safe_rshift_func_uint32_t_u_u ((safe_mod_func_uint8_t_u_u ((*g_561), ((safe_lshift_func_uint64_t_u_u ((--p_37), 47)) || l_861))), 16)) && (safe_add_func_int8_t_s_s (((void*)0 == &p_37), ((l_864 , (((*l_865) &= p_39) <= (&l_858[5][3] != &g_234))) || (~(safe_mod_func_int32_t_s_s ((safe_add_func_int16_t_s_s (p_40, p_39)), p_39))))))), p_40)))
    {
        int32_t l_873 = 0xB7E6D164L;
        for (g_134 = (-12); (g_134 <= 8); g_134 = safe_add_func_uint8_t_u_u (g_134, 8))
        {
            (*l_849) = (l_873 , (*g_814));
            return p_39;
        }
    }
    else
    {
        int8_t l_874 = 1L;
        int32_t l_886 = 0xF4521DC0L;
        uint32_t l_887 = 0x64ED70FDL;
        uint8_t ***l_901 = (void*)0;
        int16_t l_906[9][2] = {{0x2CB6L,0L},{(-1L),(-5L)},{(-1L),0L},{0x2CB6L,0x2CB6L},{0L,(-1L)},{(-5L),(-1L)},{0L,0x2CB6L},{0x2CB6L,0L},{(-1L),(-5L)}};
        int32_t l_937[3];
        int32_t l_1112 = 0xE27A5B9BL;
        int i, j;
        for (i = 0; i < 3; i++)
            l_937[i] = 0xB88C9AF3L;
        if (l_874)
        {
            int8_t l_885 = 0x46L;
            (*g_747) = p_39;
            for (g_146 = 0; (g_146 >= 11); g_146 = safe_add_func_int64_t_s_s (g_146, 4))
            {
                int32_t *l_877 = &g_103;
                int32_t *l_878 = &g_113;
                int32_t *l_879 = (void*)0;
                int32_t *l_880 = &l_861;
                int32_t *l_881 = &g_113;
                int32_t l_882 = 0xA9EED730L;
                int32_t *l_883 = &g_103;
                int32_t *l_884[9] = {&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113};
                int i;
                l_887++;
            }
        }
        else
        {
            union U0 l_890[4] = {{-7L},{-7L},{-7L},{-7L}};
            uint8_t ****l_900 = &l_899;
            int32_t l_924 = (-1L);
            int32_t l_934 = 0x42C8B423L;
            int32_t l_936[3];
            int8_t l_938 = 1L;
            int i;
            for (i = 0; i < 3; i++)
                l_936[i] = 0x04E90A43L;
            if ((((((&g_746[5][3] != (void*)0) ^ p_40) || ((1L | (((*l_865) &= (l_890[3] , (safe_mod_func_uint8_t_u_u ((safe_mod_func_uint16_t_u_u (((safe_lshift_func_int32_t_s_s ((p_39 <= ((l_886 = (((((*l_900) = l_899) == l_901) <= (safe_lshift_func_int8_t_s_u ((safe_lshift_func_uint64_t_u_s (((0xD205L || p_39) , l_886), 43)), l_886))) != p_37)) , 0L)), p_37)) == l_890[3].f0), p_39)), (-7L))))) < p_37)) >= l_906[8][1])) , l_890[3].f0) == (*g_561)))
            {
                uint8_t l_925[1];
                int32_t *l_928 = &g_388;
                int32_t *l_929 = &l_924;
                int32_t *l_930 = &g_388;
                int32_t *l_931 = (void*)0;
                int32_t *l_932 = &l_861;
                int32_t *l_933[5][2] = {{&g_388,&g_309},{&g_113,&g_388},{&g_309,&g_309},{&g_309,&g_388},{&g_113,&g_309}};
                int i, j;
                for (i = 0; i < 1; i++)
                    l_925[i] = 0xA1L;
                for (g_21 = 2; (g_21 >= (-30)); g_21--)
                {
                    uint8_t **l_914 = &g_561;
                    int32_t l_917 = 1L;
                    int32_t *l_918 = &g_118;
                    int32_t *l_919 = &l_917;
                    int32_t *l_920 = &l_886;
                    int32_t *l_921 = &l_917;
                    int32_t *l_922 = &g_113;
                    int32_t *l_923[5][3][6] = {{{&l_886,&l_886,&g_388,&l_861,&g_388,&l_861},{(void*)0,&l_886,(void*)0,&g_388,&g_388,&g_388},{&l_917,(void*)0,(void*)0,&l_917,&l_886,&l_861}},{{&l_861,&l_917,&g_388,&l_917,&l_861,&g_388},{&l_917,&l_861,&g_388,&g_388,&l_861,&l_917},{(void*)0,&l_917,&l_886,&l_861,&l_886,&l_917}},{{&l_886,(void*)0,&g_388,&g_388,&g_388,&g_388},{&l_886,&l_886,&g_388,&l_861,&g_388,&l_861},{(void*)0,&l_886,(void*)0,&g_388,&g_388,&g_388}},{{&l_917,(void*)0,(void*)0,&l_917,&l_886,&l_861},{&l_861,&l_917,&g_388,&l_917,&l_861,&g_388},{&l_917,&l_861,&g_388,&g_388,&l_861,&l_917}},{{(void*)0,&l_917,&l_886,&l_861,&l_886,&l_917},{&l_886,(void*)0,&g_388,&g_388,&g_388,&g_388},{&l_886,&l_886,&g_388,&l_861,&g_388,&l_861}}};
                    int i, j, k;
                    (*l_918) &= (p_37 || (&p_40 == ((l_890[3].f0 < (safe_add_func_int8_t_s_s (((~((safe_rshift_func_uint64_t_u_u ((((p_37 & ((l_914 != (*g_559)) == ((((safe_sub_func_int8_t_s_s (((void*)0 != &g_848[0][2][1]), ((((p_37 & 1UL) , 18446744073709551615UL) == (-7L)) && (*g_561)))) & 0xB986L) , 9L) || l_890[3].f0))) , l_886) >= 1UL), 61)) , p_37)) < l_917), (-1L)))) , (void*)0)));
                    l_925[0]--;
                }
                ++l_939;
                return p_40;
            }
            else
            {
                int32_t ***l_942 = (void*)0;
                int32_t ***l_943 = &l_849;
                (*l_943) = (void*)0;
            }
            for (g_132 = 0; g_132 < 3; g_132 += 1)
            {
                l_936[g_132] = 0x7ED2326FL;
            }
        }
    }
    (*g_1138) = (*g_999);
    l_935[0] |= (((safe_lshift_func_int8_t_s_u ((safe_lshift_func_int8_t_s_u ((safe_sub_func_uint64_t_u_u ((safe_lshift_func_uint16_t_u_u (p_40, 13)), (safe_mul_func_uint64_t_u_u ((((*g_747) ^= p_37) > (*g_1137)), (safe_div_func_int8_t_s_s ((safe_mul_func_uint8_t_u_u (p_37, (((1UL ^ (g_1153[0] , p_40)) && ((g_544--) <= (-10L))) == ((0x425FF1AFL != p_37) <= p_39)))), 7UL)))))), p_39)), (*g_561))) || p_40) , 1L);
    return p_39;
}







static uint8_t func_44(int8_t * p_45, int16_t p_46, int8_t p_47, uint32_t p_48)
{
    uint8_t *l_822 = &g_182;
    int32_t l_823 = 0x65638D19L;
    uint16_t *l_831 = (void*)0;
    uint16_t *l_832 = &g_501;
    int16_t *l_833 = (void*)0;
    int16_t *l_834 = (void*)0;
    int16_t *l_835[1][2];
    int32_t l_836 = 9L;
    int32_t *l_837 = (void*)0;
    int32_t *l_838 = (void*)0;
    int32_t *l_839 = (void*)0;
    int32_t *l_840 = &g_388;
    int32_t *l_841 = &g_309;
    uint64_t l_842 = 2UL;
    int8_t l_843 = 0xADL;
    uint16_t *l_844 = &g_134;
    uint16_t *l_845 = &g_292;
    int32_t l_846[1][3];
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_835[i][j] = &g_183[3][3];
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_846[i][j] = (-1L);
    }
    l_846[0][2] &= (((*l_845) |= (safe_add_func_int32_t_s_s (((safe_rshift_func_uint16_t_u_u ((safe_div_func_uint8_t_u_u ((safe_unary_minus_func_int16_t_s (((((void*)0 == l_822) , p_46) ^ l_823))), l_823)), 11)) || (safe_mod_func_int32_t_s_s ((safe_div_func_uint16_t_u_u (((*l_844) &= (safe_rshift_func_uint8_t_u_u ((((!(l_823 = ((*l_832) = g_539))) != ((p_46 != (0xF9526474L && ((*l_841) = ((*l_840) = ((l_836 = p_46) == p_46))))) | l_842)) <= 0x171BL), l_843))), p_48)), p_48))), p_47))) && 2L);
    return (*g_561);
}







static int8_t * func_49(int8_t * p_50, int8_t * p_51, const int32_t p_52, int8_t * p_53)
{
    const int64_t l_800[9][10][2] = {{{(-7L),(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)}},{{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL}},{{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)}},{{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)}},{{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL}},{{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)}},{{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)}},{{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL}},{{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)},{0x59FCDFB5200B3072LL,(-7L)},{(-7L),0x59FCDFB5200B3072LL},{(-7L),(-7L)}}};
    const int16_t l_811 = 0x54AEL;
    int32_t l_812 = 0x12ACB60BL;
    int32_t l_813 = 0x455D2B0EL;
    int i, j, k;
    l_813 &= (+(((g_309 , l_800[5][2][0]) | (l_812 = (safe_mul_func_uint64_t_u_u (l_800[5][2][0], ((&p_52 == &p_52) | ((l_800[4][1][1] > p_52) < (safe_div_func_uint32_t_u_u (((safe_rshift_func_uint16_t_u_s ((((safe_add_func_int16_t_s_s ((l_800[4][0][1] , ((l_800[5][2][0] < l_800[5][2][0]) , p_52)), 0x8610L)) , l_811) > 0UL), 7)) , 0xB844C222L), p_52)))))))) && g_700));
    (*g_814) = &l_813;
    return &g_21;
}







static uint64_t func_54(int8_t * p_55)
{
    int64_t l_62 = 0L;
    union U0 l_68 = {-1L};
    int32_t l_95 = 0x8991CD3CL;
    uint16_t l_96 = 0x1799L;
    int16_t l_97 = (-7L);
    uint8_t *l_98[4][1];
    int32_t l_99 = 0xF7C4FBB7L;
    int8_t *l_562 = &g_155[4];
    int32_t *l_597 = &g_118;
    uint64_t *l_679 = &g_140;
    int i, j;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
            l_98[i][j] = (void*)0;
    }
    if (func_58(g_16, g_16, (((l_62 = g_16) , ((*l_562) = func_63(l_68, ((safe_lshift_func_uint64_t_u_u (l_62, 56)) & (safe_mul_func_int8_t_s_s ((safe_rshift_func_uint64_t_u_s (l_68.f0, ((safe_lshift_func_int64_t_s_u (((l_99 = ((safe_rshift_func_int8_t_s_s ((((safe_lshift_func_int64_t_s_s ((safe_mul_func_int8_t_s_s (((safe_add_func_int32_t_s_s (((((safe_sub_func_uint8_t_u_u ((safe_rshift_func_uint8_t_u_u (g_21, (safe_add_func_int32_t_s_s (((safe_lshift_func_uint64_t_u_u ((l_95 &= ((safe_mod_func_int64_t_s_s ((((p_55 == (l_62 , (void*)0)) ^ g_16) , 0x79F1A7DFAE38EDFCLL), l_68.f0)) ^ 0x398C3D34E0BB6923LL)), l_68.f0)) , g_21), 0UL)))), l_68.f0)) | 7UL) > l_62) , g_21), l_96)) > g_16), 0x19L)), 57)) > l_62) < g_21), l_97)) > g_16)) == 0xD5L), 29)) > l_62))), l_68.f0))), l_97, &g_21))) , g_183[4][0])))
    {
        return l_99;
    }
    else
    {
        int32_t l_591 = (-1L);
        int64_t *l_619[6] = {&g_131[4],&g_131[4],&g_131[4],&g_131[4],&g_131[4],&g_131[4]};
        int32_t l_657 = 0x9381AE92L;
        uint16_t l_731 = 0xEA51L;
        int8_t *l_764[8][5] = {{&g_155[2],&g_21,&g_21,(void*)0,&g_155[1]},{&g_21,&g_155[1],(void*)0,&g_21,&g_21},{&g_21,&g_155[3],&g_155[3],&g_21,&g_21},{(void*)0,&g_155[2],(void*)0,&g_21,&g_21},{&g_155[3],(void*)0,&g_21,&g_155[0],&g_21},{&g_155[0],&g_155[0],&g_21,&g_21,(void*)0},{(void*)0,&g_21,&g_21,&g_21,&g_155[3]},{(void*)0,&g_21,&g_21,&g_21,(void*)0}};
        int i, j;
        if ((safe_sub_func_int8_t_s_s (((((l_591 , ((((l_68.f0 != (&g_457 != (void*)0)) , ((safe_add_func_uint64_t_u_u (l_68.f0, l_68.f0)) > (safe_mod_func_int16_t_s_s (((l_591 , (*g_559)) == (void*)0), l_95)))) , 0xBE52L) != 0xF1C1L)) , l_97) <= 0x3A14BEE3F9FCAC31LL) ^ 8L), l_591)))
        {
            int32_t *l_596 = (void*)0;
            int32_t l_601[2][7][5] = {{{1L,1L,1L,(-1L),(-1L)},{0x36424F15L,2L,0x36424F15L,0xE36695FFL,0L},{(-1L),0x6CE15A02L,(-1L),0x6CE15A02L,(-1L)},{0x36424F15L,1L,2L,0x40408EBDL,2L},{1L,1L,(-1L),(-1L),(-1L)},{1L,0x36424F15L,0x36424F15L,1L,2L},{0x6CE15A02L,(-1L),1L,1L,(-1L)}},{{2L,0x36424F15L,0xE36695FFL,0L,0L},{1L,1L,1L,1L,(-1L)},{0x40408EBDL,1L,0L,1L,0x40408EBDL},{1L,0x6CE15A02L,1L,(-1L),1L},{2L,2L,0L,0x40408EBDL,1L},{0x6CE15A02L,1L,1L,0x6CE15A02L,1L},{1L,0x40408EBDL,0xE36695FFL,0xE36695FFL,0x40408EBDL}}};
            int64_t *l_620 = &g_225;
            union U0 l_643[3][4] = {{{4L},{0x6D93444DL},{0x6D93444DL},{4L}},{{0x6D93444DL},{4L},{0x6D93444DL},{0x6D93444DL}},{{4L},{4L},{0xF7C6C453L},{4L}}};
            int32_t l_656 = 0xBFD0EA1DL;
            uint8_t **l_663 = &l_98[3][0];
            int16_t l_681 = 6L;
            int8_t l_790[10][8] = {{0xCEL,0x2EL,0xFCL,4L,(-1L),0x37L,(-9L),0L},{0L,0x23L,0x5FL,0x37L,4L,0x37L,0x5FL,0x23L},{1L,0x2EL,0L,1L,0xCEL,0x1DL,(-1L),0x5FL},{0x23L,0x37L,0L,(-1L),1L,1L,(-1L),0L},{(-1L),(-1L),0L,0x1DL,9L,0xFCL,0x5FL,0L},{9L,0xFCL,0x5FL,0L,(-9L),0L,(-9L),0L},{0xFCL,0L,0xFCL,0x1DL,5L,0x23L,0x37L,0L},{1L,0xCEL,0x1DL,(-1L),0x5FL,5L,5L,0x5FL},{1L,(-9L),(-9L),1L,5L,(-1L),0L,0x23L},{0xFCL,4L,0L,0x23L,0x5FL,0x37L,4L,0x37L}};
            int16_t l_796 = 6L;
            int i, j, k;
lbl_774:
            l_597 = l_596;
            l_591 ^= (safe_unary_minus_func_uint64_t_u ((safe_add_func_uint8_t_u_u ((g_544 , (*g_561)), l_601[1][5][0]))));
            for (g_544 = 1; (g_544 <= 4); g_544 += 1)
            {
                const int32_t *l_602 = &g_388;
                int32_t l_606 = (-1L);
                int32_t l_610 = 0x90A7F492L;
                uint32_t *l_696[5];
                uint32_t *l_697 = &g_236;
                uint32_t *l_698 = (void*)0;
                uint32_t *l_699 = &g_700;
                uint16_t l_742 = 0x0160L;
                int i;
                for (i = 0; i < 5; i++)
                    l_696[i] = &g_236;
                if (g_131[g_544])
                {
                    int8_t l_604 = 0x98L;
                    g_603 = l_602;
                    return l_604;
                }
                else
                {
                    g_156 = &g_103;
                }
                for (l_96 = 0; (l_96 <= 0); l_96 += 1)
                {
                    int32_t l_624[10][9] = {{0xC916FF94L,1L,0x8B8EF223L,(-10L),0x8B8EF223L,1L,0xC916FF94L,0xC932F31CL,0x0B258863L},{(-1L),(-1L),0x422053B2L,0x8CD43B90L,0L,0xC510C92EL,0L,0x8CD43B90L,0x422053B2L},{(-10L),(-10L),0x1EAEC2CFL,0x36216C4AL,0x0B258863L,0x521E7C35L,1L,0xC932F31CL,1L},{0x422053B2L,0xC1E255D0L,(-1L),(-1L),0xC1E255D0L,0x422053B2L,8L,0L,0xE5D2B0CCL},{0xC932F31CL,0xC818A4E6L,0x1EAEC2CFL,8L,0xC916FF94L,0xC916FF94L,8L,0x1EAEC2CFL,0xC818A4E6L},{0xC1E255D0L,0x48BC7B54L,0x422053B2L,0L,0xDB3445CEL,0x8CD43B90L,8L,8L,0x8CD43B90L},{0x0B603B3AL,0x1EAEC2CFL,0x8B8EF223L,0x1EAEC2CFL,0x0B603B3AL,(-1L),1L,(-10L),8L},{0xC510C92EL,0x48BC7B54L,0L,2L,0L,2L,0L,0x48BC7B54L,0xC510C92EL},{0x36216C4AL,0xC818A4E6L,0x0B258863L,0x0B603B3AL,(-10L),(-1L),0xC916FF94L,(-1L),(-10L)},{0xE5D2B0CCL,0xC1E255D0L,0xC1E255D0L,0xE5D2B0CCL,2L,0x8CD43B90L,(-1L),0x422053B2L,0xDB3445CEL}};
                    int64_t l_645 = 0L;
                    int i, j;
                    for (g_309 = 1; (g_309 >= 0); g_309 -= 1)
                    {
                        int32_t *l_605 = &l_601[0][0][3];
                        int32_t *l_607 = &l_591;
                        int32_t *l_608 = &l_601[g_309][(l_96 + 3)][(g_309 + 2)];
                        int32_t *l_609 = &l_95;
                        int32_t *l_611[7][8] = {{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103}};
                        int64_t **l_621 = &l_620;
                        int16_t *l_642 = &g_183[4][0];
                        int16_t *l_644 = &g_120;
                        int i, j, k;
                        --g_612;
                        (*g_156) = ((((((safe_lshift_func_int8_t_s_s (((0xC817D05A90D62E5FLL >= (l_68 , 0x736EBB5A25F942B6LL)) > (safe_rshift_func_uint64_t_u_s (((l_619[5] == ((*l_621) = l_620)) , (safe_div_func_uint8_t_u_u (0xD5L, l_601[l_96][(g_544 + 1)][g_544]))), 54))), 1)) == (0xFD9226A7L > (l_601[l_96][l_96][(l_96 + 4)] | (*l_602)))) , l_624[5][6]) , 0x21FFL) ^ g_537) ^ l_591);
                        (*g_156) = (((safe_mul_func_uint32_t_u_u ((safe_add_func_uint8_t_u_u ((+g_312), ((0x3A96EBED0AA08895LL & ((((1UL >= (~g_183[4][0])) || (~(((safe_mod_func_int16_t_s_s ((safe_rshift_func_int16_t_s_u ((*l_605), (safe_add_func_int16_t_s_s ((((safe_sub_func_int8_t_s_s ((((*l_642) ^= (0x27L == 0x70L)) >= (((*l_644) = (((l_643[1][3] , (((l_624[3][2] < 0x5C0EL) | (*l_602)) , (*l_605))) & 0x0EE69D5CD04E3F19LL) || (*l_608))) >= 0x1D66L)), l_591)) , 1L) & 0xCCL), (*l_602))))), 0x8556L)) & l_591) > l_591))) == l_645) && 0UL)) > g_121))), 1UL)) , g_103) > l_591);
                    }
                    if (((*g_156) &= (+(~0xB0506BF2L))))
                    {
                        volatile int32_t *l_651[1];
                        volatile int32_t **l_650 = &l_651[0];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_651[i] = &g_538;
                        (*g_156) &= ((safe_rshift_func_int64_t_s_s (l_624[5][6], 59)) , (-3L));
                        g_603 = (void*)0;
                        (*l_650) = &g_538;
                    }
                    else
                    {
                        int32_t *l_652 = &g_118;
                        int32_t *l_653 = &l_95;
                        int32_t *l_654 = &l_601[1][5][0];
                        int32_t *l_655[3][3][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}}};
                        uint64_t *l_670 = &g_312;
                        uint64_t **l_680 = &l_670;
                        int i, j, k;
                        g_658--;
                        (*l_654) = (((safe_mod_func_int16_t_s_s (l_624[2][4], ((((l_663 == ((((safe_div_func_uint8_t_u_u (((*g_561) ^= (safe_div_func_uint32_t_u_u ((safe_rshift_func_uint8_t_u_s ((((((*l_670) ^= l_624[3][8]) | l_96) , ((g_501 != (g_309 , (safe_add_func_uint8_t_u_u (l_624[5][6], (safe_lshift_func_uint32_t_u_u ((safe_lshift_func_uint64_t_u_u ((safe_mul_func_int8_t_s_s ((g_152[0] , ((((((*l_680) = l_679) != &g_140) == (*l_602)) < (*g_156)) ^ l_624[9][6])), 246UL)), 34)), g_544)))))) ^ g_21)) > (*l_602)), l_681)), l_624[1][8]))), l_601[1][6][2])) >= 255UL) < l_645) , (*g_559))) <= l_657) , l_643[1][3]) , 65535UL))) > (*l_652)) != g_113);
                    }
                }
                if ((safe_add_func_int32_t_s_s (((g_182 && ((safe_div_func_uint64_t_u_u (((*l_679) = (safe_mul_func_uint32_t_u_u (((*l_699) = ((*l_697) = (&g_540 != (l_696[2] = ((safe_add_func_int16_t_s_s ((((((0x8AL && ((255UL != (((*l_602) , (0x98464631L == (safe_mul_func_uint8_t_u_u (l_657, 0xB9L)))) < (safe_add_func_int8_t_s_s ((((((safe_sub_func_int64_t_s_s (l_657, l_591)) , (*l_602)) & 0x1AL) <= l_681) <= (*l_602)), l_591)))) == g_537)) , (*l_602)) || (*g_156)) , 0L) != 0L), g_146)) , &g_236))))), (*l_602)))), (*l_602))) <= 1UL)) || 3UL), l_96)))
                {
                    uint64_t l_709 = 0x8692F0243F0681AALL;
                    int32_t *l_733 = &l_95;
                    int32_t *l_734 = &l_656;
                    int32_t *l_735 = &g_118;
                    int32_t *l_736 = (void*)0;
                    int32_t *l_737 = &g_309;
                    int32_t *l_738 = &g_388;
                    int32_t *l_739 = &l_657;
                    int32_t *l_740 = &l_657;
                    int32_t *l_741[3][1][6] = {{{&l_656,(void*)0,(void*)0,&l_656,&l_656,(void*)0}},{{&l_656,&l_656,(void*)0,(void*)0,&l_656,&l_656}},{{&l_656,(void*)0,(void*)0,&l_656,&l_656,(void*)0}}};
                    int i, j, k;
                    for (l_62 = 1; (l_62 <= 4); l_62 += 1)
                    {
                        uint64_t l_704[1][2][1];
                        int32_t l_729 = 0x67A1B6B4L;
                        uint16_t *l_732 = &g_292;
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_704[i][j][k] = 0x15F7C07A493AD338LL;
                            }
                        }
                        (*g_156) = (l_591 = (~((*l_732) &= (safe_add_func_int8_t_s_s ((l_704[0][0][0] & ((safe_div_func_int16_t_s_s ((safe_sub_func_int8_t_s_s ((l_709 | l_657), ((*l_562) = ((safe_rshift_func_uint16_t_u_u (0UL, 7)) > (safe_div_func_int64_t_s_s (((safe_mod_func_uint16_t_u_u ((0x24EDL < ((safe_sub_func_int8_t_s_s ((safe_mod_func_uint8_t_u_u (((safe_mod_func_int16_t_s_s (g_388, (safe_div_func_int32_t_s_s ((safe_add_func_uint8_t_u_u (8UL, (((*l_697) = l_657) <= (safe_rshift_func_int8_t_s_u ((l_729 = (safe_unary_minus_func_int64_t_s (((-8L) >= 1L)))), l_709))))), l_709)))) & l_704[0][1][0]), l_709)), 0xC1L)) , l_709)), g_539)) != l_704[0][0][0]), l_709)))))), g_730)) && l_731)), (*l_602))))));
                    }
                    l_742--;
                }
                else
                {
                    uint8_t l_748 = 0xE6L;
                    uint8_t l_763 = 0UL;
                    int32_t **l_770 = &l_596;
                    int32_t ***l_769 = &l_770;
                    uint16_t *l_773 = &l_96;
                    (*g_747) |= (*g_156);
                    for (g_225 = 0; (g_225 >= 0); g_225 -= 1)
                    {
                        --l_748;
                    }
                    g_118 ^= (safe_sub_func_int32_t_s_s (((((((safe_mod_func_uint16_t_u_u (((*l_773) &= (((l_610 = ((!((safe_lshift_func_int64_t_s_s ((((*l_679) = (safe_mul_func_int32_t_s_s (1L, ((~((safe_sub_func_int16_t_s_s (((l_763 , p_55) == l_764[1][3]), ((safe_mod_func_uint32_t_u_u ((((*l_602) , 0xF9L) < ((*g_561) = ((((*l_769) = &g_156) != &l_596) < (safe_rshift_func_uint16_t_u_s (l_731, 5))))), (*l_602))) && (-1L)))) == g_121)) == (*l_602))))) <= (*l_602)), 18)) ^ 0x790F030724D32B82LL)) & 0xB37EF48A28669056LL)) | l_62) > l_591)), 65533UL)) | (*g_156)) ^ (*l_602)) | l_591) && (***l_769)) && 0xACF0FA0EL), (*g_156)));
                }
                for (l_95 = 0; (l_95 <= 4); l_95 += 1)
                {
                    uint8_t l_777[2][2][5] = {{{0xB8L,255UL,0xB8L,6UL,0xB8L},{1UL,0x10L,0x10L,1UL,0x10L}},{{0xB8L,0xB8L,255UL,0xB8L,0xB8L},{0x10L,1UL,0x10L,0x10L,1UL}}};
                    int i, j, k;
                    for (g_21 = 0; (g_21 <= 4); g_21 += 1)
                    {
                        int16_t l_789 = 0xE41AL;
                        uint32_t l_791 = 4294967295UL;
                        int32_t *l_797 = &l_656;
                        (*g_156) ^= ((*l_602) >= 4294967295UL);
                        if (g_544)
                            goto lbl_774;
                        l_591 |= (safe_rshift_func_uint32_t_u_s (((l_777[0][0][4] , ((*g_156) &= g_778)) , g_658), 15));
                        (*l_797) &= ((g_152[0] , ((*g_156) = (safe_mul_func_uint64_t_u_u ((safe_rshift_func_uint32_t_u_u ((l_610 = (safe_mul_func_int16_t_s_s ((g_103 , (((safe_sub_func_int64_t_s_s ((safe_add_func_int32_t_s_s ((l_789 > ((l_789 & 0xB686L) == ((l_790[0][7] ^ l_791) ^ (safe_add_func_int32_t_s_s ((*g_747), (safe_add_func_uint64_t_u_u (1UL, (*l_602)))))))), g_140)), 0x00B1DA753BFC7770LL)) | l_791) == (*l_602))), 0x100FL))), l_777[1][0][2])), 0x87D2E8BBD93E7F5ELL)))) | l_796);
                    }
                    if ((*l_602))
                        break;
                }
            }
        }
        else
        {
            return (*l_597);
        }
    }
    return l_99;
}







static int32_t func_58(int16_t p_59, uint64_t p_60, int16_t p_61)
{
    int32_t *l_563 = &g_309;
    int8_t *l_569[10][2] = {{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]},{&g_155[3],&g_155[3]}};
    uint32_t *l_570 = &g_236;
    int64_t *l_579 = &g_225;
    uint8_t *l_582[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t l_586 = 0x51E1EF24L;
    int i, j;
    (*l_563) = 0xAE80621EL;
    (*l_563) = ((((safe_mod_func_int32_t_s_s (0x7A55F609L, (safe_lshift_func_int64_t_s_s ((*l_563), 8)))) , (((*l_579) = ((!((((*l_570) ^= ((&g_155[2] == l_569[5][1]) || 0xAC86L)) == ((*l_563) ^ (safe_add_func_uint16_t_u_u (((safe_mod_func_int32_t_s_s (0x8FB2D6D6L, (*l_563))) , (safe_mul_func_uint32_t_u_u ((safe_mul_func_int8_t_s_s ((*l_563), (*l_563))), 0xD742D97CL))), g_103)))) == p_60)) >= 1L)) , &g_236)) != &g_540) && g_292);
    for (g_544 = 4; (g_544 == 53); g_544 = safe_add_func_int32_t_s_s (g_544, 9))
    {
        (*l_563) |= ((void*)0 == l_582[5]);
        for (g_539 = 21; (g_539 <= (-18)); g_539--)
        {
            int64_t *l_585 = &g_131[0];
            (*l_563) = (l_585 != l_579);
        }
    }
    --l_586;
    return (*l_563);
}







static int8_t func_63(union U0 p_64, int32_t p_65, int16_t p_66, int8_t * p_67)
{
    int32_t *l_102 = &g_103;
    int32_t l_117[2];
    uint32_t l_216[7] = {0x3E5249ECL,0x3E5249ECL,0x3E5249ECL,0x3E5249ECL,0x3E5249ECL,0x3E5249ECL,0x3E5249ECL};
    int64_t *l_223 = (void*)0;
    int16_t *l_243 = &g_183[4][0];
    uint8_t *l_250 = &g_146;
    int8_t l_341 = 0xF6L;
    uint32_t l_342[3][3] = {{0x8C37194EL,0x8C37194EL,0x8C37194EL},{0UL,0UL,0UL},{0x8C37194EL,0x8C37194EL,0x8C37194EL}};
    const union U0 l_366 = {0xCC406B18L};
    int32_t l_449 = 0x75AD1371L;
    int64_t l_476 = 0x3EEDDB6DF4DFEFB0LL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_117[i] = 0xCF258FD7L;
    if (p_64.f0)
    {
        int32_t *l_104 = &g_103;
        uint8_t *l_147 = &g_146;
        uint8_t l_179 = 0x94L;
        int64_t *l_213[7][9][4] = {{{&g_131[2],(void*)0,&g_131[2],&g_132},{&g_131[2],&g_132,&g_132,(void*)0},{(void*)0,(void*)0,&g_132,&g_131[2]},{&g_131[2],&g_131[4],&g_131[2],&g_131[3]},{&g_131[2],&g_131[2],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_131[1]},{&g_131[2],&g_131[0],&g_131[2],&g_132},{&g_132,(void*)0,&g_131[0],&g_131[2]},{&g_131[2],&g_131[2],&g_132,&g_131[3]}},{{(void*)0,&g_132,&g_132,&g_131[1]},{&g_131[0],&g_132,&g_131[1],(void*)0},{&g_131[3],&g_132,&g_131[2],&g_132},{(void*)0,&g_132,&g_131[0],&g_132},{&g_131[2],&g_132,&g_132,&g_131[2]},{&g_132,&g_131[4],&g_131[0],&g_132},{&g_131[2],&g_132,(void*)0,(void*)0},{&g_131[3],&g_132,(void*)0,&g_131[2]},{&g_132,&g_132,&g_131[2],&g_131[2]}},{{&g_131[2],&g_132,&g_131[2],&g_131[2]},{(void*)0,(void*)0,(void*)0,&g_131[1]},{&g_131[2],&g_131[2],&g_131[2],&g_131[2]},{&g_132,(void*)0,(void*)0,(void*)0},{&g_132,(void*)0,&g_131[2],&g_131[4]},{&g_131[2],&g_131[3],&g_132,&g_131[4]},{&g_132,(void*)0,&g_131[2],(void*)0},{&g_131[2],(void*)0,&g_132,&g_131[2]},{&g_131[2],&g_131[2],&g_131[2],&g_131[1]}},{{&g_131[0],(void*)0,&g_131[2],&g_131[2]},{&g_131[3],&g_132,&g_132,&g_131[2]},{(void*)0,&g_132,&g_131[1],&g_131[2]},{&g_131[2],&g_132,&g_132,(void*)0},{&g_131[2],&g_132,&g_131[2],&g_132},{&g_132,&g_131[4],&g_131[2],&g_131[2]},{&g_131[1],&g_132,&g_132,&g_131[4]},{&g_131[2],&g_131[2],&g_131[2],(void*)0},{&g_132,&g_132,&g_131[2],&g_131[0]}},{{&g_131[2],&g_131[0],&g_131[4],&g_132},{&g_131[2],(void*)0,(void*)0,&g_132},{&g_131[2],&g_131[2],&g_132,&g_132},{&g_131[2],&g_131[2],&g_131[0],&g_131[0]},{&g_131[2],&g_131[0],&g_131[3],&g_131[2]},{&g_132,(void*)0,&g_131[2],(void*)0},{(void*)0,&g_131[2],(void*)0,&g_132},{&g_132,&g_132,(void*)0,&g_131[4]},{&g_131[2],&g_131[3],&g_131[2],&g_131[2]}},{{&g_131[2],&g_132,(void*)0,(void*)0},{&g_132,&g_131[2],(void*)0,&g_131[2]},{(void*)0,&g_132,&g_131[2],&g_131[2]},{&g_132,&g_131[1],&g_131[3],&g_131[2]},{&g_131[2],&g_132,&g_131[0],&g_131[2]},{&g_131[2],&g_131[1],&g_132,&g_132},{&g_131[2],&g_131[2],(void*)0,(void*)0},{&g_131[2],&g_131[4],&g_131[4],&g_132},{&g_131[2],&g_131[0],&g_131[2],&g_131[4]}},{{&g_132,(void*)0,&g_131[2],&g_131[2]},{&g_131[2],&g_131[2],&g_132,&g_131[2]},{&g_131[1],(void*)0,&g_132,&g_131[0]},{(void*)0,(void*)0,&g_131[1],&g_131[2]},{&g_132,(void*)0,(void*)0,&g_132},{&g_132,&g_131[2],&g_131[4],&g_131[2]},{&g_131[0],&g_131[0],(void*)0,&g_131[2]},{(void*)0,&g_131[0],&g_131[4],&g_131[2]},{&g_131[0],&g_131[4],&g_131[4],&g_131[4]}}};
        int32_t l_219[3][7][6] = {{{0x7D7E8CB1L,8L,(-1L),0x691E9A43L,0x6E787A2BL,(-1L)},{0x7D7E8CB1L,0L,0x6E787A2BL,(-2L),1L,0x2F6452D9L},{4L,0L,8L,0L,0x6E787A2BL,0x6E787A2BL},{1L,8L,8L,1L,0L,0x2F6452D9L},{(-2L),(-2L),0x6E787A2BL,1L,0x2F6452D9L,(-1L)},{1L,0x2F6452D9L,(-1L),0L,0x2F6452D9L,(-2L)},{4L,(-2L),0L,(-2L),0L,(-2L)}},{{0x7D7E8CB1L,8L,(-1L),0x691E9A43L,0x6E787A2BL,(-1L)},{0x7D7E8CB1L,0L,0x6E787A2BL,(-2L),1L,0x2F6452D9L},{4L,0L,8L,0L,0x6E787A2BL,0x6E787A2BL},{1L,8L,8L,1L,0L,0x2F6452D9L},{(-2L),(-2L),0x6E787A2BL,1L,(-1L),0x2025CEF9L},{8L,(-1L),0x2025CEF9L,0x6E787A2BL,(-1L),0xE73B9E9AL},{0x2F6452D9L,0xE73B9E9AL,0xDCD383C1L,(-1L),0xDCD383C1L,0xE73B9E9AL}},{{1L,0xBD7DA9C4L,0x2025CEF9L,0L,5L,0x2025CEF9L},{1L,0xDCD383C1L,5L,(-1L),(-9L),(-1L)},{0x2F6452D9L,0xDCD383C1L,0xBD7DA9C4L,0x6E787A2BL,5L,5L},{8L,0xBD7DA9C4L,0xBD7DA9C4L,8L,0xDCD383C1L,(-1L)},{(-1L),0xE73B9E9AL,5L,8L,(-1L),0x2025CEF9L},{8L,(-1L),0x2025CEF9L,0x6E787A2BL,(-1L),0xE73B9E9AL},{0x2F6452D9L,0xE73B9E9AL,0xDCD383C1L,(-1L),0xDCD383C1L,0xE73B9E9AL}}};
        int i, j, k;
        for (p_65 = 28; (p_65 >= (-12)); p_65 = safe_sub_func_uint8_t_u_u (p_65, 3))
        {
            int16_t l_116 = 0xAC69L;
            int32_t l_119 = 0x611CF5FCL;
            int32_t l_141 = (-1L);
            int32_t l_150 = 0L;
            uint8_t **l_211 = (void*)0;
            int64_t *l_212 = &g_131[2];
            int64_t **l_214[1][10][9] = {{{&l_212,&l_212,&l_212,&l_212,&l_212,&l_212,&l_212,&l_212,&l_212},{&l_213[6][3][0],&l_213[6][8][0],&l_213[2][8][3],(void*)0,&l_213[2][8][3],&l_213[6][8][0],&l_213[6][3][0],(void*)0,&l_213[5][7][1]},{(void*)0,&l_212,(void*)0,&l_212,&l_212,(void*)0,&l_212,(void*)0,&l_212},{&l_213[3][1][3],(void*)0,&l_213[2][8][3],(void*)0,&l_212,(void*)0,&l_213[2][8][3],(void*)0,&l_213[3][1][3]},{(void*)0,&l_212,&l_212,&l_212,(void*)0,(void*)0,&l_212,&l_212,&l_212},{&l_213[2][8][3],&l_213[0][3][1],&l_213[5][7][1],(void*)0,&l_212,(void*)0,&l_212,(void*)0,&l_213[5][7][1]},{(void*)0,(void*)0,&l_212,&l_212,&l_212,(void*)0,(void*)0,&l_212,&l_212},{&l_213[3][1][3],&l_213[0][3][1],&l_213[3][1][3],(void*)0,&l_213[2][8][3],(void*)0,&l_212,(void*)0,&l_213[2][8][3]},{(void*)0,&l_212,&l_212,(void*)0,&l_212,(void*)0,&l_212,&l_212,(void*)0},{&l_213[6][3][0],(void*)0,&l_213[5][7][1],(void*)0,&l_213[6][3][0],&l_213[6][8][0],&l_213[2][8][3],(void*)0,&l_213[2][8][3]}}};
            int32_t l_217 = 0x5645DE02L;
            int32_t *l_218[7] = {&l_150,&l_141,&l_141,&l_150,&l_141,&l_141,&l_150};
            int i, j, k;
            l_104 = l_102;
            for (p_66 = 0; (p_66 > (-7)); p_66 = safe_sub_func_int64_t_s_s (p_66, 4))
            {
                int32_t *l_107 = &g_103;
                uint64_t *l_166 = &g_140;
                uint8_t *l_180 = (void*)0;
                uint8_t *l_181 = &g_182;
                l_102 = l_107;
                for (g_21 = 20; (g_21 < 22); g_21++)
                {
                    for (g_103 = 22; (g_103 > (-2)); g_103 = safe_sub_func_uint16_t_u_u (g_103, 5))
                    {
                        int32_t *l_112 = &g_113;
                        int32_t *l_114 = &g_113;
                        int32_t *l_115[6][7] = {{&g_103,&g_113,&g_103,&g_113,&g_103,&g_113,&g_103},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{&g_103,&g_113,&g_103,&g_113,&g_103,&g_113,&g_103},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{&g_103,&g_113,&g_103,&g_113,&g_103,&g_113,&g_103},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113}};
                        int i, j;
                        if ((*l_102))
                            break;
                        --g_121;
                    }
                }
                for (l_119 = 7; (l_119 >= 1); l_119 -= 1)
                {
                    int64_t *l_130[7][7] = {{&g_131[1],&g_131[2],&g_131[1],&g_131[1],&g_131[2],(void*)0,(void*)0},{&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2]},{&g_131[2],(void*)0,&g_131[1],&g_131[2],&g_131[1],(void*)0,&g_131[2]},{&g_131[1],&g_131[2],(void*)0,&g_131[1],&g_131[2],&g_131[1],(void*)0},{&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2],&g_131[2]},{&g_131[2],(void*)0,(void*)0,&g_131[2],&g_131[1],&g_131[1],&g_131[2]},{&g_131[1],&g_131[2],&g_131[1],&g_131[1],&g_131[2],&g_131[1],(void*)0}};
                    uint16_t *l_133 = &g_134;
                    int32_t l_148 = 9L;
                    int32_t l_157[10][9][2] = {{{6L,0xCDBDFE5EL},{(-8L),0x03787015L},{0x1DEC27F6L,(-1L)},{0xA38B5D02L,6L},{6L,0x67245343L},{(-1L),(-4L)},{(-8L),0L},{0xEB764D41L,0xC78F562DL},{0xD756E631L,6L}},{{0x39686C71L,(-10L)},{1L,0xE5BA6927L},{(-8L),0xE5BA6927L},{1L,(-10L)},{0x39686C71L,6L},{0xD756E631L,0xC78F562DL},{0xEB764D41L,0L},{(-8L),(-4L)},{(-1L),0x67245343L}},{{6L,6L},{0xA38B5D02L,(-1L)},{0x1DEC27F6L,0x03787015L},{(-8L),0xCDBDFE5EL},{6L,(-8L)},{0x5BC1B5E4L,6L},{0x5BC1B5E4L,(-8L)},{6L,0xCDBDFE5EL},{(-8L),0x03787015L}},{{0x1DEC27F6L,(-1L)},{0xA38B5D02L,6L},{6L,0x67245343L},{(-1L),(-4L)},{(-8L),0L},{0xEB764D41L,0xC78F562DL},{0xD756E631L,6L},{0x39686C71L,(-10L)},{1L,0xE5BA6927L}},{{(-8L),0xE5BA6927L},{1L,(-10L)},{0x39686C71L,6L},{0xD756E631L,0xC78F562DL},{0xEB764D41L,0L},{(-8L),(-4L)},{(-1L),0x67245343L},{6L,6L},{0xA38B5D02L,(-1L)}},{{0x1DEC27F6L,0x03787015L},{(-8L),0xCDBDFE5EL},{6L,(-8L)},{0x5BC1B5E4L,6L},{0x5BC1B5E4L,(-8L)},{6L,0xCDBDFE5EL},{(-8L),0x03787015L},{0x1DEC27F6L,(-1L)},{0xA38B5D02L,6L}},{{6L,0x67245343L},{(-1L),(-4L)},{(-8L),0L},{0xEB764D41L,0xC78F562DL},{0xD756E631L,6L},{0x39686C71L,(-10L)},{1L,0xE5BA6927L},{(-8L),0xE5BA6927L},{1L,(-10L)}},{{0x39686C71L,6L},{0xD756E631L,0xC78F562DL},{0xEB764D41L,0L},{(-8L),(-4L)},{(-1L),0x67245343L},{6L,6L},{(-1L),0xEB764D41L},{0xC0895B47L,0xD756E631L},{1L,0x39686C71L}},{{0x5A61D411L,1L},{(-10L),(-8L)},{(-10L),1L},{0x5A61D411L,0x39686C71L},{1L,0xD756E631L},{0xC0895B47L,0xEB764D41L},{(-1L),(-8L)},{(-8L),(-1L)},{(-1L),6L}},{{1L,0xA38B5D02L},{5L,0x1DEC27F6L},{0x67245343L,(-8L)},{0xC78F562DL,6L},{(-2L),0x5BC1B5E4L},{1L,0x5BC1B5E4L},{(-2L),6L},{0xC78F562DL,(-8L)},{0x67245343L,0x1DEC27F6L}}};
                    int i, j, k;
                    if (((*l_102) = (safe_div_func_int16_t_s_s ((safe_sub_func_int16_t_s_s ((safe_lshift_func_uint64_t_u_u (0UL, ((g_131[0] = l_119) | g_118))), p_64.f0)), (++(*l_133))))))
                    {
                        uint64_t *l_139[10][3] = {{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140},{&g_140,&g_140,&g_140}};
                        int32_t l_142 = (-8L);
                        uint8_t **l_143 = (void*)0;
                        uint8_t *l_145[6] = {(void*)0,(void*)0,&g_146,(void*)0,(void*)0,&g_146};
                        uint8_t **l_144 = &l_145[0];
                        int32_t *l_149[8][4][8] = {{{(void*)0,(void*)0,(void*)0,&l_117[0],(void*)0,(void*)0,(void*)0,(void*)0},{&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0},{(void*)0,(void*)0,&l_117[0],&l_117[0],(void*)0,(void*)0,(void*)0,&l_117[0]},{&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148}},{{(void*)0,(void*)0,&l_117[0],(void*)0,(void*)0,(void*)0,(void*)0,&l_117[0]},{(void*)0,(void*)0,(void*)0,&l_117[0],(void*)0,(void*)0,(void*)0,(void*)0},{&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0},{(void*)0,(void*)0,&l_117[0],&l_117[0],(void*)0,(void*)0,(void*)0,&l_117[0]}},{{&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148},{(void*)0,(void*)0,&l_117[0],(void*)0,(void*)0,(void*)0,(void*)0,&l_117[0]},{(void*)0,(void*)0,(void*)0,&l_117[0],(void*)0,(void*)0,(void*)0,(void*)0},{&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_117[0],&l_117[0],(void*)0,(void*)0,(void*)0,&l_117[0]},{&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0,&l_148},{(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0},{(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148}},{{&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0],&l_148,&l_148},{&l_148,(void*)0,(void*)0,(void*)0,(void*)0,&l_148,(void*)0,(void*)0},{&l_117[0],(void*)0,&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0]},{(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0}},{{(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148},{&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0],&l_148,&l_148},{&l_148,(void*)0,(void*)0,(void*)0,(void*)0,&l_148,(void*)0,(void*)0},{&l_117[0],(void*)0,&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0]}},{{(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0},{(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148},{&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0],&l_148,&l_148},{&l_148,(void*)0,(void*)0,(void*)0,(void*)0,&l_148,(void*)0,(void*)0}},{{&l_117[0],(void*)0,&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0]},{(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148,(void*)0},{(void*)0,(void*)0,&l_148,(void*)0,&l_148,(void*)0,(void*)0,&l_148},{&l_117[0],&l_148,&l_148,&l_117[0],(void*)0,&l_117[0],&l_148,&l_148}}};
                        int i, j, k;
                        l_150 |= (((*p_67) != (((((((safe_add_func_uint64_t_u_u ((l_141 = 18446744073709551615UL), ((((*l_104) = p_65) <= l_142) | (((void*)0 == &g_140) & (l_142 != (p_66 < ((((((((*l_144) = p_67) == l_147) > g_113) <= l_119) != l_148) >= p_64.f0) <= 7UL))))))) , g_103) , l_148) > 0L) , &g_21) == p_67) == g_113)) < 0x955FA402L);
                        if (g_131[2])
                            continue;
                        l_102 = &g_113;
                        (*l_104) &= (g_131[2] && ((+(g_152[0] , 0x4BFD8C34L)) , (p_65 , ((safe_unary_minus_func_uint64_t_u (g_134)) ^ g_21))));
                    }
                    else
                    {
                        int8_t *l_154 = &g_155[3];
                        (*l_104) |= ((*p_67) & ((*l_154) &= (*p_67)));
                        g_156 = &l_117[0];
                    }
                    return l_157[9][0][1];
                }
                g_183[4][0] ^= (((safe_div_func_int32_t_s_s ((safe_add_func_uint8_t_u_u (((*l_147)--), ((*l_181) ^= (safe_mul_func_uint32_t_u_u ((((*p_67) = (((((*l_166) |= g_120) , ((safe_add_func_int8_t_s_s (((safe_add_func_int32_t_s_s ((safe_add_func_uint64_t_u_u ((safe_mod_func_int32_t_s_s (((((((*l_166)++) , (g_21 < ((*p_67) > (safe_add_func_int8_t_s_s (0x63L, l_179))))) && (g_155[4] == (((*g_156) < (*g_156)) & (g_152[0].f0 == 1L)))) ^ p_65) | 0xB907L), g_21)), g_131[2])), g_16)) && (*l_102)), 0xF8L)) & 0xCD3DL)) <= 0x307A3C17D6ECED94LL) , (*p_67))) <= (-10L)), (*g_156)))))), (*l_104))) >= (-3L)) < g_113);
            }
            l_219[1][1][4] &= (((safe_mod_func_uint8_t_u_u (p_64.f0, ((((*g_156) = p_65) > ((safe_mod_func_int32_t_s_s (((safe_mod_func_uint32_t_u_u (((((safe_mul_func_uint64_t_u_u ((safe_add_func_int8_t_s_s ((p_65 & (safe_add_func_int16_t_s_s (((safe_rshift_func_int64_t_s_s ((g_132 = (((65528UL || ((safe_add_func_uint32_t_u_u (((g_152[0] , ((g_215[5] = (((*l_102) < ((safe_mod_func_uint64_t_u_u ((l_150 == ((safe_lshift_func_int16_t_s_u (((((*l_212) &= ((safe_div_func_int8_t_s_s ((*p_67), (safe_lshift_func_int32_t_s_u ((safe_add_func_uint8_t_u_u (((l_211 = g_210) != (void*)0), l_116)), p_64.f0)))) , p_64.f0)) < (*l_104)) || (*l_102)), (*l_102))) >= (*l_102))), p_64.f0)) != 0xA6L)) , l_213[2][8][3])) == (void*)0)) , 4294967295UL), p_66)) > 255UL)) , l_216[0]) <= 0L)), g_155[3])) , p_66), (*l_102)))), p_65)), (*l_104))) , (*l_102)) < g_183[4][0]) != g_21), p_65)) <= 0xE5EF4969E89804B6LL), l_217)) ^ l_116)) ^ (*l_104)))) , p_64) , (*g_156));
        }
    }
    else
    {
        int8_t *l_221[4][1] = {{&g_155[3]},{(void*)0},{&g_155[3]},{(void*)0}};
        uint8_t l_222 = 255UL;
        uint64_t *l_233 = &g_140;
        uint64_t **l_232 = &l_233;
        uint32_t *l_235 = &g_236;
        int32_t l_237 = 0x6722DAFDL;
        uint8_t *l_238 = (void*)0;
        uint8_t *l_239 = &g_146;
        int i, j;
        (*l_102) = (safe_unary_minus_func_int64_t_s ((((0x84CAL > ((((l_222 ^= (*p_67)) , l_223) != &g_132) != (((safe_unary_minus_func_uint16_t_u (g_225)) < (p_66 , (safe_add_func_uint8_t_u_u (((*l_239) = (safe_sub_func_int32_t_s_s (((safe_mul_func_int64_t_s_s (((((*l_232) = l_223) != (g_234 = &g_140)) == (((*l_235) ^= (p_66 | 7UL)) , p_66)), l_237)) , (*g_156)), l_237))), (*l_102))))) & 1UL))) == 0x8F9857E4L) , p_64.f0)));
    }
    if (((((+(*l_102)) < (((((*l_243) = 0xA347L) | p_64.f0) , 0x40L) > (p_66 , (((safe_rshift_func_int32_t_s_s ((((g_134 |= (safe_sub_func_int8_t_s_s ((((&g_134 == l_243) < 0x2437CD80L) == (((safe_add_func_int16_t_s_s ((((*l_250)--) < (l_102 == (void*)0)), g_121)) != p_64.f0) > (*l_102))), 0xF1L))) < 0xBD34L) != p_64.f0), (*g_156))) && g_155[3]) >= p_66)))) , p_66) != (-1L)))
    {
        uint64_t l_253 = 18446744073709551608UL;
        return l_253;
    }
    else
    {
        uint64_t l_256 = 1UL;
        int32_t *l_259 = &l_117[0];
        int32_t l_308 = 0x86E1A8FBL;
        int32_t l_310[2];
        uint64_t *l_320 = &l_256;
        uint64_t l_331 = 3UL;
        int64_t l_336 = 0x6940AC3FDCEB1211LL;
        uint8_t **l_378 = &l_250;
        uint16_t *l_428 = (void*)0;
        uint32_t *l_447 = &g_236;
        int32_t *l_448[9][4][7] = {{{&g_118,(void*)0,&l_310[1],&l_308,&g_103,&l_308,&g_309},{&g_113,&l_308,&g_388,(void*)0,(void*)0,&g_103,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_118,&g_103,(void*)0},{(void*)0,&g_388,&l_308,&g_113,(void*)0,&l_308,&g_118}},{{&l_308,&l_310[1],(void*)0,&g_118,&g_388,&g_388,(void*)0},{&g_118,&g_309,&g_388,&g_388,&g_309,&g_118,(void*)0},{&g_118,(void*)0,&g_309,(void*)0,(void*)0,(void*)0,&g_309},{(void*)0,&g_113,&g_309,&g_118,&l_308,&l_308,(void*)0}},{{&l_308,(void*)0,&g_103,&g_388,&g_388,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,&l_308,&g_103,&g_388,&g_309},{&g_118,(void*)0,&g_309,&l_308,&g_118,&l_310[1],&g_118},{&g_103,&l_308,&g_309,&l_308,&g_309,&g_309,&l_308}},{{&g_309,&g_118,&g_309,&g_388,&g_309,&l_308,(void*)0},{(void*)0,&l_310[1],&g_118,&g_118,&g_118,(void*)0,(void*)0},{&g_118,&g_118,&l_310[1],(void*)0,&g_103,&l_308,&l_308},{&g_388,&g_309,&g_118,&g_309,&g_388,&g_309,&l_308}},{{&l_308,&g_309,&l_308,&g_103,&l_308,&l_310[1],(void*)0},{&l_308,&g_309,(void*)0,&g_118,(void*)0,&g_388,(void*)0},{&l_308,&g_103,(void*)0,(void*)0,(void*)0,&g_103,&l_308},{&g_388,&g_103,(void*)0,&l_308,&g_309,&l_308,&g_118}},{{&g_118,&g_309,&g_113,(void*)0,(void*)0,(void*)0,&g_309},{(void*)0,&g_309,(void*)0,&g_388,&g_103,&g_388,(void*)0},{&g_309,&g_309,(void*)0,&g_388,&g_118,&l_308,(void*)0},{&g_103,&g_118,(void*)0,(void*)0,&g_118,&g_309,&g_309}},{{&g_118,&l_310[1],&l_308,&l_308,&g_118,&g_118,&g_118},{(void*)0,&g_118,&g_118,(void*)0,&g_103,&g_118,&g_113},{&l_308,&l_308,&l_310[1],&g_118,(void*)0,&g_309,&g_388},{(void*)0,(void*)0,&g_118,&g_103,&g_309,&l_308,&g_113}},{{&g_388,(void*)0,&g_309,&g_309,(void*)0,&g_388,&g_118},{&g_388,(void*)0,&g_309,(void*)0,(void*)0,(void*)0,&g_309},{(void*)0,&g_113,&g_309,&g_118,&l_308,&l_308,(void*)0},{&l_308,(void*)0,&g_103,&g_388,&g_388,&g_103,(void*)0}},{{(void*)0,(void*)0,&g_103,&l_308,&g_103,&g_388,&g_309},{&g_118,(void*)0,&g_309,&g_309,&g_103,(void*)0,(void*)0},{&g_118,&g_309,&g_309,&l_310[1],(void*)0,(void*)0,&l_310[1]},{&g_103,(void*)0,&g_103,&l_308,(void*)0,(void*)0,(void*)0}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_310[i] = (-1L);
        for (g_132 = 0; (g_132 >= 22); ++g_132)
        {
            uint32_t l_287 = 0x9283E141L;
            int32_t l_301 = 0x31E086E9L;
            int32_t *l_306 = &l_301;
            int32_t *l_307[3];
            int i;
            for (i = 0; i < 3; i++)
                l_307[i] = &g_103;
            for (g_120 = 0; (g_120 <= 4); g_120 += 1)
            {
                int32_t *l_261[8][8][4] = {{{&g_118,(void*)0,&l_117[1],(void*)0},{(void*)0,&l_117[1],(void*)0,&g_103},{&l_117[0],&g_103,&l_117[0],&l_117[0]},{&g_118,(void*)0,&g_118,&g_103},{&l_117[0],&g_103,&g_113,&g_103},{&g_118,&g_113,&g_103,&g_113},{&g_113,(void*)0,&g_113,&g_113},{(void*)0,&g_103,&g_103,&l_117[0]}},{{&g_118,&g_113,&g_118,(void*)0},{&g_118,(void*)0,(void*)0,&g_118},{&l_117[0],(void*)0,&g_103,(void*)0},{(void*)0,&l_117[0],&l_117[1],(void*)0},{&g_103,&g_118,&g_113,&g_103},{&g_118,&g_113,&g_118,&g_103},{&g_118,(void*)0,&g_113,&g_118},{&g_103,&g_103,&l_117[1],&g_113}},{{(void*)0,&g_103,&g_103,&g_113},{&l_117[0],&l_117[0],(void*)0,&g_113},{&g_118,(void*)0,&g_118,&g_103},{&g_118,&l_117[0],&g_103,(void*)0},{(void*)0,(void*)0,&g_113,(void*)0},{&g_113,&l_117[0],&g_103,&g_113},{&g_118,&g_103,&g_113,(void*)0},{&l_117[0],&l_117[1],&g_118,(void*)0}},{{&g_118,&l_117[0],&l_117[0],&g_118},{&l_117[0],(void*)0,(void*)0,&g_103},{(void*)0,(void*)0,&l_117[1],&g_113},{&g_118,&l_117[0],(void*)0,&g_113},{&g_118,(void*)0,&l_117[0],&g_103},{&g_118,(void*)0,&g_103,&g_118},{&g_103,&l_117[0],&l_117[0],(void*)0},{&g_113,&l_117[1],&g_113,(void*)0}},{{&l_117[0],&g_103,(void*)0,&g_113},{(void*)0,&l_117[0],&g_118,(void*)0},{&l_117[0],(void*)0,&g_113,(void*)0},{&l_117[0],&l_117[0],&l_117[0],&g_103},{&g_103,(void*)0,(void*)0,&g_113},{&g_103,&l_117[0],&g_113,&g_113},{(void*)0,&g_103,(void*)0,&g_113},{&g_118,&g_103,(void*)0,&g_118}},{{(void*)0,(void*)0,&l_117[0],&g_103},{&l_117[0],&g_113,&l_117[0],&g_103},{(void*)0,&g_118,(void*)0,(void*)0},{&g_118,&l_117[0],(void*)0,&g_118},{(void*)0,&g_118,&g_118,&l_117[0]},{&g_113,&g_118,&l_117[0],&g_118},{&g_118,&l_117[0],(void*)0,&g_113},{&l_117[0],&g_103,(void*)0,&l_117[1]}},{{&l_117[0],&g_103,(void*)0,&l_117[0]},{(void*)0,&g_118,&g_118,&g_113},{&g_113,&g_118,&g_103,&l_117[1]},{(void*)0,&l_117[0],&g_113,&g_113},{&g_113,&g_113,&g_118,(void*)0},{&g_103,&l_117[0],&l_117[0],&g_118},{(void*)0,&g_118,&g_118,&l_117[0]},{(void*)0,&g_118,&l_117[0],&g_118}},{{&g_118,&l_117[0],&l_117[0],(void*)0},{&l_117[0],&g_113,&g_103,&g_113},{&l_117[0],&l_117[0],&g_103,&l_117[1]},{&l_117[0],&g_118,&g_118,&g_113},{(void*)0,&g_118,(void*)0,&l_117[0]},{&g_118,&g_103,&g_103,&l_117[1]},{(void*)0,&g_103,&g_118,&g_113},{&g_113,&l_117[0],&l_117[0],&g_118}}};
                uint8_t l_299 = 0xC1L;
                int i, j, k;
                --l_256;
                for (g_134 = 0; (g_134 <= 4); g_134 += 1)
                {
                    int32_t **l_260 = &g_156;
                    uint64_t l_296 = 1UL;
                    uint32_t l_298 = 18446744073709551615UL;
                    (*l_260) = l_259;
                    for (g_146 = 1; (g_146 <= 5); g_146 += 1)
                    {
                        int i;
                        if (g_131[g_120])
                            break;
                        return g_131[g_120];
                    }
                    for (g_21 = 1; (g_21 <= 5); g_21 += 1)
                    {
                        int32_t **l_276 = (void*)0;
                        uint16_t *l_291 = &g_292;
                        uint64_t *l_295 = &l_256;
                        uint32_t *l_297 = &g_236;
                        const uint8_t l_300 = 0xDAL;
                        int32_t *l_302 = &g_118;
                        int i, j;
                        g_156 = l_261[0][4][1];
                        l_301 |= (((safe_sub_func_uint32_t_u_u (((((safe_mod_func_uint16_t_u_u (((safe_lshift_func_uint16_t_u_u ((safe_div_func_uint32_t_u_u ((*l_102), (safe_rshift_func_uint16_t_u_u ((safe_add_func_int16_t_s_s (((safe_lshift_func_uint64_t_u_u ((l_276 == &g_156), (safe_mod_func_int16_t_s_s ((safe_mul_func_int64_t_s_s ((((((*l_297) = ((safe_sub_func_int8_t_s_s ((safe_mod_func_int32_t_s_s ((g_118 &= (p_65 , ((safe_add_func_int32_t_s_s (((*l_259) || l_287), ((+(!(((+(--(*l_291))) , l_295) == l_223))) , (((((p_65 | 0x8A35905E24F52A20LL) < (-2L)) || g_236) < l_296) < 0x244AL)))) > g_103))), g_155[5])), (*p_67))) , 1UL)) <= l_296) > g_21) || 1L), l_298)), l_287)))) < 18446744073709551615UL), (-1L))), l_287)))), 9)) < l_299), p_64.f0)) <= p_66) , 0UL) <= l_300), g_131[2])) , l_287) , 0x6F9C49DCL);
                        (*l_102) = 0x5B255EBFL;
                        l_302 = (*l_260);
                    }
                    for (l_301 = 0; (l_301 <= 5); l_301 += 1)
                    {
                        uint16_t l_303 = 0xC6AEL;
                        l_303--;
                    }
                }
            }
            --g_312;
        }
        for (g_134 = 15; (g_134 == 35); g_134 = safe_add_func_int8_t_s_s (g_134, 6))
        {
            (*l_259) = p_65;
        }
        if ((((!g_131[2]) & ((g_236 >= ((*l_243) |= (p_65 || (++(*l_320))))) , (((0xD300L ^ ((safe_add_func_uint64_t_u_u (g_152[0].f0, ((safe_add_func_uint8_t_u_u ((((p_64.f0 ^ (*l_102)) <= (safe_mod_func_uint32_t_u_u ((safe_mul_func_int32_t_s_s (g_155[3], l_331)), p_64.f0))) > (*l_259)), 246UL)) , 7L))) < (*l_259))) && 0x5DA1L) <= p_66))) , (-1L)))
        {
            int32_t *l_332 = &g_309;
            int32_t l_333 = 0xE4AC5E38L;
            int32_t *l_334 = &g_113;
            int32_t *l_335[10] = {&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309};
            int32_t **l_340 = &l_334;
            int i;
            --g_337;
            (*l_340) = &l_117[1];
            l_342[1][1]++;
        }
        else
        {
            int16_t l_355 = 0x41ECL;
            uint32_t *l_367 = &l_342[1][1];
            if (((((safe_lshift_func_uint8_t_u_s (p_66, (safe_add_func_uint32_t_u_u ((((safe_rshift_func_int32_t_s_u (1L, p_65)) & (((0x75L ^ (l_355 <= (safe_mul_func_int32_t_s_s ((safe_rshift_func_int8_t_s_u ((*p_67), 6)), ((safe_mod_func_uint32_t_u_u (((((safe_mod_func_uint8_t_u_u (((-1L) != ((*l_367) = ((((l_366 , ((*p_67) < (*p_67))) && 246UL) ^ p_66) || 0L))), (*l_259))) , &g_183[3][2]) == &p_66) < 0x4B1AL), p_66)) == (-4L)))))) < (*l_259)) != p_66)) & 0UL), p_65)))) <= p_66) , p_65) , p_65))
            {
                int32_t *l_368 = (void*)0;
                for (g_312 = 0; (g_312 <= 5); g_312 += 1)
                {
                    for (l_256 = 1; (l_256 <= 5); l_256 += 1)
                    {
                        int i;
                        g_156 = (l_368 = &l_117[0]);
                        if (g_155[g_312])
                            continue;
                    }
                }
                for (g_182 = 0; (g_182 <= 1); g_182 += 1)
                {
                    const int64_t l_389[6] = {0xFB2059F015E47498LL,0xF5619777422D29C8LL,0xF5619777422D29C8LL,0xFB2059F015E47498LL,0xF5619777422D29C8LL,0xF5619777422D29C8LL};
                    uint16_t *l_427 = &g_134;
                    int32_t l_429 = 0x28CE12BBL;
                    int i;
                    for (g_311 = 0; (g_311 <= 1); g_311 += 1)
                    {
                        uint8_t ***l_377 = &g_210;
                        int16_t *l_390 = (void*)0;
                        int16_t *l_391 = &l_355;
                        int32_t *l_392 = &g_103;
                        uint16_t *l_403[5] = {&g_134,&g_134,&g_134,&g_134,&g_134};
                        int i;
                        g_118 &= ((l_117[g_182] | (safe_rshift_func_int16_t_s_u (((*l_391) = ((*l_243) = (((*l_320) = (safe_mod_func_uint8_t_u_u ((((safe_div_func_int8_t_s_s (((*p_67) = 0x33L), (safe_mod_func_uint16_t_u_u (g_309, p_66)))) , (((*l_250) = (l_366 , ((((((((((*l_377) = (void*)0) != l_378) > l_355) && (safe_lshift_func_int64_t_s_u ((((safe_sub_func_int32_t_s_s ((+(safe_sub_func_uint32_t_u_u ((safe_lshift_func_int32_t_s_s ((p_64.f0 == g_388), p_66)), g_337))), l_389[5])) < g_21) < p_65), 18))) , (void*)0) != &g_155[0]) | (*p_67)) <= l_389[5]) | p_64.f0))) , 0x93F1L)) >= 65535UL), 1UL))) || 0xD74562F7644E7E3FLL))), 14))) & (*l_102));
                        l_392 = (void*)0;
                        (*l_259) = ((0x476B1021L > (safe_sub_func_uint8_t_u_u ((255UL >= ((safe_div_func_uint16_t_u_u (((safe_mod_func_int32_t_s_s (((*l_102) = (safe_mod_func_int32_t_s_s (((safe_lshift_func_uint16_t_u_s ((++g_134), ((((safe_div_func_uint64_t_u_u ((safe_lshift_func_int32_t_s_u (p_64.f0, 0)), 0x2FB072385D3454CCLL)) > 0xDFB1L) == ((((*p_67) = (*p_67)) ^ (*l_102)) && ((((void*)0 == &g_140) , (void*)0) == l_392))) , g_132))) <= p_65), (*l_259)))), 5L)) | 0xD49853B6L), 0xB4DFL)) && l_389[0])), p_65))) , l_389[5]);
                    }
                    if (((*l_102) = ((((**l_378) = ((0L | ((safe_unary_minus_func_int64_t_s (p_65)) == ((l_429 = ((safe_mul_func_int32_t_s_s (((-2L) > ((((((p_65 , l_389[4]) && l_355) ^ ((*l_427) = (safe_sub_func_int64_t_s_s ((safe_mod_func_uint32_t_u_u ((safe_mod_func_int64_t_s_s (l_389[5], (safe_mul_func_int16_t_s_s ((-6L), ((safe_div_func_uint16_t_u_u ((safe_sub_func_uint32_t_u_u (4294967286UL, p_64.f0)), 6UL)) < p_64.f0))))), l_389[5])), p_65)))) , (void*)0) != l_428) < (*l_102))), 4294967295UL)) > g_309)) != l_389[5]))) < 0x6E64F549L)) != l_389[0]) , (*l_102))))
                    {
                        return (*p_67);
                    }
                    else
                    {
                        return (*p_67);
                    }
                }
            }
            else
            {
                return (*p_67);
            }
        }
        l_449 &= (safe_mod_func_int64_t_s_s (((safe_lshift_func_int64_t_s_u ((5L == (*l_102)), 16)) >= ((g_152[0] , (g_225 == ((((*l_259) |= (safe_div_func_int32_t_s_s (p_65, (safe_lshift_func_uint8_t_u_u ((1L || p_66), 1))))) >= (safe_sub_func_int64_t_s_s (((((safe_lshift_func_uint64_t_u_s ((safe_sub_func_uint32_t_u_u ((safe_unary_minus_func_int64_t_s ((safe_div_func_uint32_t_u_u (((*l_447) = ((*l_102) < 0xA4L)), 0xDB61C8ACL)))), 0xFAF5C5A5L)), 55)) , l_223) != (void*)0) == g_309), (*l_102)))) >= (*l_102)))) , g_120)), (*l_102)));
    }
    for (g_134 = 24; (g_134 >= 57); ++g_134)
    {
        int64_t l_452[1];
        int32_t *l_453 = (void*)0;
        int32_t *l_454 = &g_309;
        int32_t *l_455 = (void*)0;
        int32_t *l_456[4][2][5] = {{{&l_117[0],&g_103,&g_118,(void*)0,&g_118},{(void*)0,&l_117[0],(void*)0,&l_117[1],(void*)0}},{{&l_117[1],&l_117[1],&g_118,(void*)0,&g_118},{(void*)0,(void*)0,&g_118,&g_103,(void*)0}},{{(void*)0,&g_118,(void*)0,&g_118,(void*)0},{(void*)0,(void*)0,&g_118,(void*)0,&l_117[1]}},{{(void*)0,&l_117[1],(void*)0,&g_103,&g_103},{(void*)0,&l_117[0],(void*)0,(void*)0,&l_117[1]}}};
        uint32_t *l_479[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        const int32_t l_504 = 0x7931BB25L;
        int64_t l_530 = 0xA73B1F44EBC241BFLL;
        int32_t l_536[6] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
        int32_t l_557 = (-3L);
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_452[i] = (-9L);
        (*l_102) &= 0x92D6179AL;
        g_457--;
        if ((((0x21L <= (0x43FA86A4C04676BFLL <= ((safe_lshift_func_int8_t_s_s ((!((((safe_mul_func_uint64_t_u_u (((g_152[0] , (g_312 = (((*l_102) = ((*l_102) & ((--(*l_250)) || ((*l_250) = (safe_mod_func_uint16_t_u_u ((safe_add_func_uint8_t_u_u ((safe_mod_func_int16_t_s_s ((safe_lshift_func_uint32_t_u_u ((g_21 <= (+(((((*l_454) = (((l_476 <= g_337) != 0xA39AEACBL) == (((safe_mul_func_int32_t_s_s ((p_64.f0 , p_65), 1UL)) , &g_236) == (void*)0))) ^ 1UL) == p_66) != (*l_102)))), 5)), g_140)), 0x34L)), g_183[0][1])))))) < (-1L)))) == l_341), p_66)) , (*l_102)) >= 0xDDC4F7654F77BF78LL) , 0x5C71L)), 5)) != 0x8C21F315237DCF14LL))) , &g_312) != (void*)0))
        {
            int32_t l_492 = 0xC9260910L;
            uint16_t *l_498 = (void*)0;
            uint16_t *l_499 = &g_292;
            uint16_t *l_500 = &g_501;
            int32_t l_505[3];
            int32_t *l_548[10] = {&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1],&l_505[1]};
            uint8_t ***l_558 = &g_210;
            int i;
            for (i = 0; i < 3; i++)
                l_505[i] = (-5L);
            if (((safe_rshift_func_uint16_t_u_s (((l_505[1] = (safe_rshift_func_uint8_t_u_u ((l_243 != ((safe_add_func_int32_t_s_s (((((safe_lshift_func_int16_t_s_s (((safe_sub_func_uint16_t_u_u ((((safe_lshift_func_int8_t_s_u ((*p_67), 0)) , (++(*l_250))) ^ (p_66 != (((*l_500) = ((*l_499) = (safe_sub_func_uint8_t_u_u (0x1CL, (&g_134 != ((safe_unary_minus_func_uint64_t_u (0UL)) , &g_134)))))) , (safe_mod_func_uint8_t_u_u (((p_64.f0 | 0UL) != p_64.f0), (-9L)))))), 1L)) | (-5L)), g_155[3])) && g_155[3]) > l_504) ^ (*l_102)), l_492)) , l_243)), (*l_102)))) == (-1L)), g_225)) || 7L))
            {
                (*l_102) |= ((*l_454) |= (-4L));
            }
            else
            {
                int32_t * const *l_507 = &l_456[3][0][1];
                int32_t * const **l_506 = &l_507;
                int32_t l_535[1];
                int64_t **l_555[6] = {&g_215[5],&g_215[5],&g_215[5],&g_215[5],&g_215[5],&g_215[5]};
                int64_t l_556[7][4] = {{0x4E06555FDD7AFA0DLL,0xC9403019182367B8LL,0x4E06555FDD7AFA0DLL,(-1L)},{0x611F490C95C6C4CDLL,0xC9403019182367B8LL,1L,0x851076CB71BED1CCLL},{0xC9403019182367B8LL,0x2B5FDA639FB57FBELL,0x2B5FDA639FB57FBELL,0xC9403019182367B8LL},{0x4E06555FDD7AFA0DLL,0x851076CB71BED1CCLL,0x2B5FDA639FB57FBELL,(-2L)},{0x2B5FDA639FB57FBELL,(-1L),0x851076CB71BED1CCLL,(-1L)},{(-1L),1L,0x9E5E4C15ED0017CBLL,(-1L)},{0x9E5E4C15ED0017CBLL,(-1L),(-2L),(-2L)}};
                int i, j;
                for (i = 0; i < 1; i++)
                    l_535[i] = 1L;
                (*l_454) = p_65;
                (*l_506) = (void*)0;
                for (g_118 = 28; (g_118 == 10); g_118--)
                {
                    int32_t l_513 = (-1L);
                    int32_t l_514 = 0x74C16D5EL;
                    uint16_t *l_529 = &g_292;
                    if ((safe_mul_func_int8_t_s_s (l_505[1], (((((~(((l_513 = p_66) | (((*l_250) = l_514) , ((safe_mod_func_uint32_t_u_u ((safe_sub_func_uint64_t_u_u ((safe_add_func_int16_t_s_s ((safe_lshift_func_uint16_t_u_u (((-1L) != (safe_rshift_func_int8_t_s_s ((0xBCC2L != ((((safe_rshift_func_int64_t_s_s ((&l_342[1][1] == &l_342[1][1]), (*l_102))) && (safe_add_func_uint8_t_u_u ((l_529 == l_500), (*p_67)))) > 0x83E4L) ^ (*p_67))), (*p_67)))), 14)), g_236)), g_131[3])), 0x378E1BF9L)) || p_65))) < l_530)) > 0xF317EFE483CA4B45LL) , l_514) & (-2L)) & (-5L)))))
                    {
                        int8_t *l_533 = &l_341;
                        int32_t l_534 = 8L;
                        l_534 ^= (safe_rshift_func_int8_t_s_u (((*l_533) = ((*p_67) = 1L)), g_501));
                    }
                    else
                    {
                        int64_t l_543 = 0xA01C9C23427BEF75LL;
                        int32_t **l_547 = &g_156;
                        --g_540;
                        g_544--;
                        l_548[8] = ((*l_547) = l_456[3][0][1]);
                    }
                    (*l_454) &= (safe_add_func_int8_t_s_s (((safe_add_func_int32_t_s_s ((((l_514 < g_337) | ((safe_mul_func_uint16_t_u_u (((l_243 == (void*)0) | (((((g_155[3] && 0x6AF7FF28L) == (*l_102)) >= ((l_449 = ((void*)0 != l_555[3])) , 4L)) > l_556[5][2]) ^ (*p_67))), 1L)) & 0x5FA5L)) < p_65), g_120)) != l_557), (*p_67)));
                    if ((*l_102))
                        break;
                }
            }
            if (p_64.f0)
                continue;
            (*g_559) = ((*l_558) = g_210);
        }
        else
        {
            return (*p_67);
        }
    }
    return (*l_102);
}





int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_131[i], "g_131[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_152[i].f0, "g_152[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_155[i], "g_155[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_182, "g_182", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_183[i][j], "g_183[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_236, "g_236", print_hash_value);
    transparent_crc(g_292, "g_292", print_hash_value);
    transparent_crc(g_309, "g_309", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    transparent_crc(g_312, "g_312", print_hash_value);
    transparent_crc(g_337, "g_337", print_hash_value);
    transparent_crc(g_388, "g_388", print_hash_value);
    transparent_crc(g_457, "g_457", print_hash_value);
    transparent_crc(g_501, "g_501", print_hash_value);
    transparent_crc(g_537, "g_537", print_hash_value);
    transparent_crc(g_538, "g_538", print_hash_value);
    transparent_crc(g_539, "g_539", print_hash_value);
    transparent_crc(g_540, "g_540", print_hash_value);
    transparent_crc(g_544, "g_544", print_hash_value);
    transparent_crc(g_612, "g_612", print_hash_value);
    transparent_crc(g_658, "g_658", print_hash_value);
    transparent_crc(g_700, "g_700", print_hash_value);
    transparent_crc(g_730, "g_730", print_hash_value);
    transparent_crc(g_778, "g_778", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_848[i][j][k], "g_848[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1073[i], "g_1073[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1153[i].f0, "g_1153[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1201, "g_1201", print_hash_value);
    transparent_crc(g_1203, "g_1203", print_hash_value);
    transparent_crc(g_1210, "g_1210", print_hash_value);
    transparent_crc(g_1276, "g_1276", print_hash_value);
    transparent_crc(g_1279, "g_1279", print_hash_value);
    transparent_crc(g_1284, "g_1284", print_hash_value);
    transparent_crc(g_1310, "g_1310", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}
