/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 3343092425 --bitfields --packed-struct
 * Seed:      3343092425
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const unsigned f0 : 3;
   volatile signed f1 : 14;
};

union U1 {
   volatile int8_t  f0;
   volatile signed f1 : 17;
};

union U2 {
   const int32_t  f0;
   volatile signed f1 : 12;
   uint32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x7A00F47AL;
static volatile int32_t g_5[3] = {0x4AA0D722L,0x4AA0D722L,0x4AA0D722L};
static volatile int32_t g_6 = 0xFA516694L;/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7[4] = {(-1L),(-1L),(-1L),(-1L)};
static volatile int32_t g_8 = 1L;/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = 0L;
static int32_t g_14 = 0x0DDD9CD4L;
static int64_t g_31 = 0x9E68FC786C7A88FFLL;
static int32_t *g_72[4] = {&g_2,&g_2,&g_2,&g_2};
static int32_t **g_71 = &g_72[3];
static int64_t g_78 = (-1L);
static uint64_t g_100 = 0x763FF6366113C509LL;
static uint16_t g_103 = 0x0F42L;
static int8_t g_105 = 1L;
static uint64_t *g_114 = &g_100;
static int32_t g_123 = 1L;
static uint16_t g_182 = 0xD098L;
static int16_t g_195 = 4L;
static uint32_t g_202 = 0x36ECFF39L;
static uint32_t g_235[1] = {2UL};
static int32_t g_253 = (-8L);
static int8_t g_259 = 0xF3L;
static int64_t * volatile *g_329 = (void*)0;
static int64_t *g_402 = &g_31;
static int64_t **g_401 = &g_402;
static int64_t ***g_400[6] = {&g_401,&g_401,&g_401,&g_401,&g_401,&g_401};
static int8_t * const  volatile *g_448 = (void*)0;
static uint8_t g_482 = 0x39L;
static uint64_t g_485[7][5][2] = {{{0x52B8AA18D6F5A9EBLL,18446744073709551614UL},{0xA232C95722CF2F56LL,0xA232C95722CF2F56LL},{1UL,0x72BD41F7F0EC4DC2LL},{0xE3C8741FD667C65CLL,0xAA39FBE9D128CC32LL},{0x80C4C9A8CFA8B300LL,0xD622D70BE8D03F3BLL}},{{0xD5A8C7BBF130A4CDLL,0x80C4C9A8CFA8B300LL},{0xB65D10E4F95A40A0LL,0x233707791824622ALL},{0xB65D10E4F95A40A0LL,0x80C4C9A8CFA8B300LL},{0xD5A8C7BBF130A4CDLL,0xD622D70BE8D03F3BLL},{0x80C4C9A8CFA8B300LL,0xAA39FBE9D128CC32LL}},{{0xE3C8741FD667C65CLL,0x72BD41F7F0EC4DC2LL},{1UL,0xA232C95722CF2F56LL},{0xA232C95722CF2F56LL,18446744073709551614UL},{0x52B8AA18D6F5A9EBLL,1UL},{0xD622D70BE8D03F3BLL,0x233707791824622ALL}},{{0x52B8AA18D6F5A9EBLL,0x233707791824622ALL},{0xD622D70BE8D03F3BLL,18446744073709551614UL},{0xE3C8741FD667C65CLL,0x88ED53F475382431LL},{0xB65D10E4F95A40A0LL,0xB65D10E4F95A40A0LL},{18446744073709551614UL,0x52B8AA18D6F5A9EBLL}},{{0x6793AD307729216DLL,0xF136E3B21C554344LL},{0x7F90F1E63D561E1ELL,0xA232C95722CF2F56LL},{0x80C4C9A8CFA8B300LL,0x7F90F1E63D561E1ELL},{0x72BD41F7F0EC4DC2LL,0xD622D70BE8D03F3BLL},{0x72BD41F7F0EC4DC2LL,0x7F90F1E63D561E1ELL}},{{0x80C4C9A8CFA8B300LL,0xA232C95722CF2F56LL},{0x7F90F1E63D561E1ELL,0xF136E3B21C554344LL},{0x6793AD307729216DLL,0x52B8AA18D6F5A9EBLL},{18446744073709551614UL,0xB65D10E4F95A40A0LL},{0xB65D10E4F95A40A0LL,0x88ED53F475382431LL}},{{0xE3C8741FD667C65CLL,18446744073709551614UL},{0xD622D70BE8D03F3BLL,0x233707791824622ALL},{0x52B8AA18D6F5A9EBLL,0x233707791824622ALL},{0xD622D70BE8D03F3BLL,18446744073709551614UL},{0xE3C8741FD667C65CLL,0x88ED53F475382431LL}}};
static int64_t g_529 = 9L;
static int16_t g_611 = 0x9A17L;
static int16_t g_613[10] = {0x9256L,0x9256L,0x9256L,0x9256L,0x9256L,0x9256L,0x9256L,0x9256L,0x9256L,0x9256L};
static int32_t g_714 = 0x71E59802L;
static const uint32_t g_749 = 4294967295UL;
static union U2 g_843 = {0x886AAC7AL};/* VOLATILE GLOBAL g_843 */
static union U2 *g_842 = &g_843;
static union U2 g_847 = {0L};/* VOLATILE GLOBAL g_847 */
static int64_t g_883[2][5][9] = {{{0xF2E59CD9E56701C0LL,0x657C4283B491D64ELL,(-1L),(-8L),0xB408B80943EF9E04LL,(-1L),(-4L),(-1L),0xFE9414444B5E5590LL},{0xC78761D1F028E87BLL,0xF2E59CD9E56701C0LL,(-2L),(-4L),0L,0x3B46D0CAA3179875LL,0xC52B43A4559D8656LL,0xFE9414444B5E5590LL,0xFE9414444B5E5590LL},{(-8L),0x086DBC37E1D09D54LL,0xD3C3007DFF26EC4ALL,0xC78761D1F028E87BLL,0xD3C3007DFF26EC4ALL,0x086DBC37E1D09D54LL,(-8L),0x3896D444F27946B7LL,0xF2A90DBB102F0C0FLL},{1L,(-2L),0x443C4C48AB7A5B28LL,0x1016C0D60D0A6A7FLL,0xA18930AC1F40841DLL,0x5BB8422B5D50A17FLL,0xE965D29AA21A80EBLL,7L,0x26A785E600585F92LL},{0x97D1E14FEC97F605LL,0xF2A90DBB102F0C0FLL,7L,0L,3L,0xAA9B14E9440F5050LL,0x2FA382185053B047LL,0x3896D444F27946B7LL,0xC78761D1F028E87BLL}},{{0x657C4283B491D64ELL,(-1L),(-8L),0xB408B80943EF9E04LL,(-1L),(-4L),(-1L),0xFE9414444B5E5590LL,0x443C4C48AB7A5B28LL},{0xAEDF6F1F34B36572LL,(-9L),0x3896D444F27946B7LL,0x0516BB0CBA295674LL,0L,0xA18930AC1F40841DLL,(-1L),(-1L),0xA18930AC1F40841DLL},{0x02D6CB0F7B09517CLL,0xE84D40EB13140C48LL,0L,0xE84D40EB13140C48LL,0x02D6CB0F7B09517CLL,0x49CE877969579296LL,0x2FA382185053B047LL,0xC78761D1F028E87BLL,0xAA9B14E9440F5050LL},{0xD3C3007DFF26EC4ALL,(-4L),0x26A785E600585F92LL,0xF2A90DBB102F0C0FLL,0x406A37689DA3B9C8LL,0x0516BB0CBA295674LL,0xE965D29AA21A80EBLL,0L,0xE84D40EB13140C48LL},{0L,3L,(-4L),(-9L),0x086DBC37E1D09D54LL,0x49CE877969579296LL,(-8L),0x3B46D0CAA3179875LL,0x02D6CB0F7B09517CLL}}};
static uint8_t *g_912 = (void*)0;
static uint32_t *g_918[2][4][6] = {{{&g_235[0],(void*)0,&g_235[0],&g_235[0],(void*)0,&g_235[0]},{&g_235[0],(void*)0,&g_235[0],(void*)0,(void*)0,&g_235[0]},{&g_235[0],&g_235[0],&g_235[0],&g_235[0],&g_235[0],(void*)0},{&g_235[0],&g_235[0],&g_235[0],(void*)0,&g_235[0],&g_235[0]}},{{&g_235[0],(void*)0,(void*)0,&g_235[0],&g_235[0],&g_235[0]},{&g_235[0],&g_235[0],&g_235[0],(void*)0,(void*)0,(void*)0},{&g_235[0],&g_235[0],&g_235[0],&g_235[0],(void*)0,&g_235[0]},{&g_235[0],&g_235[0],&g_235[0],&g_235[0],&g_235[0],&g_235[0]}}};
static uint32_t **g_917 = &g_918[0][2][5];
static const uint16_t g_971[5][5] = {{0x57FEL,0x1AF0L,0x71BCL,0x71BCL,0x1AF0L},{7UL,0UL,0x71BCL,65535UL,65535UL},{0UL,7UL,0UL,0x71BCL,65535UL},{0x1AF0L,65535UL,65535UL,65535UL,0x1AF0L},{0UL,65535UL,7UL,0x1AF0L,7UL}};
static const uint16_t *g_970[10][6][4] = {{{&g_971[1][3],&g_971[1][3],&g_971[1][2],&g_971[1][3]},{&g_971[4][3],&g_971[1][3],&g_971[3][4],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],(void*)0},{&g_971[0][1],&g_971[2][1],&g_971[1][2],&g_971[1][3]},{(void*)0,&g_971[0][0],&g_971[1][3],&g_971[0][0]},{(void*)0,&g_971[1][2],&g_971[1][3],&g_971[1][3]}},{{&g_971[1][2],&g_971[2][1],&g_971[0][1],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[4][1],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[0][1],&g_971[1][3]},{&g_971[1][2],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{(void*)0,&g_971[0][1],&g_971[1][3],&g_971[0][4]},{(void*)0,&g_971[1][3],&g_971[1][2],&g_971[1][3]}},{{&g_971[0][1],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[3][4],(void*)0},{&g_971[4][3],(void*)0,&g_971[1][2],&g_971[1][3]},{&g_971[1][3],&g_971[0][0],&g_971[1][3],&g_971[1][2]},{(void*)0,&g_971[0][0],&g_971[1][3],&g_971[1][3]},{&g_971[0][0],(void*)0,&g_971[0][1],(void*)0}},{{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[2][2],&g_971[1][3]},{&g_971[0][0],&g_971[1][3],&g_971[1][3],&g_971[0][4]},{&g_971[1][3],&g_971[0][1],&g_971[1][3],&g_971[1][3]},{(void*)0,&g_971[1][3],(void*)0,&g_971[1][3]},{&g_971[4][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]}},{{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{&g_971[4][3],&g_971[2][1],(void*)0,&g_971[1][3]},{(void*)0,&g_971[1][2],&g_971[1][3],&g_971[0][0]},{&g_971[1][3],&g_971[0][0],&g_971[1][3],&g_971[1][3]},{&g_971[0][0],&g_971[2][1],&g_971[2][2],(void*)0},{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]}},{{&g_971[1][3],&g_971[1][3],&g_971[0][1],&g_971[1][3]},{&g_971[0][0],&g_971[1][3],&g_971[1][3],&g_971[0][4]},{(void*)0,&g_971[1][3],&g_971[1][3],&g_971[0][4]},{&g_971[1][3],&g_971[1][3],&g_971[1][2],&g_971[1][3]},{&g_971[4][3],&g_971[1][3],&g_971[3][4],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],(void*)0}},{{&g_971[0][1],&g_971[2][1],&g_971[1][2],&g_971[1][3]},{(void*)0,&g_971[0][0],&g_971[1][3],&g_971[0][0]},{(void*)0,&g_971[1][2],&g_971[1][3],&g_971[1][3]},{&g_971[1][2],&g_971[2][1],&g_971[0][1],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[4][1],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],(void*)0}},{{&g_971[1][3],&g_971[1][3],&g_971[2][2],(void*)0},{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][2]},{&g_971[0][1],&g_971[4][1],&g_971[1][3],(void*)0},{&g_971[1][3],&g_971[1][3],&g_971[4][1],&g_971[4][1]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]}},{{&g_971[2][2],&g_971[1][3],&g_971[4][2],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[4][3],&g_971[1][3]},{&g_971[1][3],&g_971[1][3],&g_971[1][3],&g_971[1][3]},{&g_971[4][1],&g_971[1][3],(void*)0,&g_971[4][1]},{&g_971[1][3],&g_971[1][3],(void*)0,(void*)0},{&g_971[1][3],&g_971[4][1],&g_971[2][2],&g_971[1][2]}},{{&g_971[4][2],&g_971[1][3],&g_971[4][2],(void*)0},{&g_971[0][1],&g_971[1][3],&g_971[0][1],(void*)0},{&g_971[1][3],&g_971[3][4],&g_971[4][1],&g_971[1][3]},{(void*)0,&g_971[1][3],&g_971[4][1],&g_971[4][2]},{&g_971[1][3],&g_971[1][3],&g_971[0][1],&g_971[1][3]},{&g_971[0][1],&g_971[1][3],&g_971[4][2],&g_971[1][3]}}};
static union U2 g_992[5] = {{0L},{0L},{0L},{0L},{0L}};
static const union U2 g_1008 = {0xB4863EF9L};/* VOLATILE GLOBAL g_1008 */
static struct S0 g_1019[6] = {{0,16},{0,16},{0,16},{0,16},{0,16},{0,16}};
static const volatile union U2 *g_1043 = (void*)0;
static volatile int64_t g_1051 = 0xC5193666E6AE94BBLL;/* VOLATILE GLOBAL g_1051 */
static volatile int8_t g_1052[2] = {0L,0L};
static union U1 g_1076 = {0x29L};/* VOLATILE GLOBAL g_1076 */
static union U1 *g_1078 = &g_1076;
static union U1 ** volatile g_1077 = &g_1078;/* VOLATILE GLOBAL g_1077 */
static uint64_t ****g_1105 = (void*)0;
static uint64_t *****g_1104 = &g_1105;
static volatile uint8_t g_1114 = 0xD9L;/* VOLATILE GLOBAL g_1114 */
static struct S0 g_1151 = {0,25};/* VOLATILE GLOBAL g_1151 */
static const uint16_t **g_1154 = (void*)0;
static uint64_t * volatile ** volatile g_1195[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint64_t * volatile ** volatile *g_1194 = &g_1195[7];
static volatile struct S0 g_1196 = {0,105};/* VOLATILE GLOBAL g_1196 */
static union U2 **g_1217 = (void*)0;
static uint8_t g_1226[1][2] = {{255UL,255UL}};
static uint32_t g_1234 = 0x3D071C01L;
static uint32_t *g_1240[1] = {&g_1234};
static uint32_t * volatile *g_1239 = &g_1240[0];
static struct S0 g_1248 = {0,5};/* VOLATILE GLOBAL g_1248 */
static struct S0 g_1257 = {0,-43};/* VOLATILE GLOBAL g_1257 */
static struct S0 g_1315 = {1,57};/* VOLATILE GLOBAL g_1315 */
static volatile union U1 g_1386 = {-1L};/* VOLATILE GLOBAL g_1386 */
static volatile int32_t *g_1394 = &g_7[3];
static volatile int32_t **g_1393 = &g_1394;
static volatile int32_t ***g_1392 = &g_1393;
static volatile int32_t *** volatile * volatile g_1391 = &g_1392;/* VOLATILE GLOBAL g_1391 */
static const int32_t ****g_1395[2] = {(void*)0,(void*)0};
static uint32_t ***g_1443[7][9][4] = {{{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,(void*)0,&g_917},{&g_917,&g_917,&g_917,(void*)0}},{{&g_917,(void*)0,&g_917,&g_917},{&g_917,&g_917,(void*)0,&g_917},{&g_917,(void*)0,(void*)0,&g_917},{&g_917,&g_917,&g_917,(void*)0},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{(void*)0,&g_917,&g_917,(void*)0},{&g_917,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917}},{{(void*)0,&g_917,&g_917,&g_917},{(void*)0,(void*)0,&g_917,(void*)0},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,(void*)0},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,(void*)0,&g_917},{&g_917,&g_917,&g_917,&g_917},{(void*)0,&g_917,&g_917,&g_917}},{{(void*)0,&g_917,&g_917,&g_917},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,(void*)0},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917}},{{(void*)0,&g_917,&g_917,(void*)0},{(void*)0,&g_917,&g_917,&g_917},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,(void*)0,&g_917},{&g_917,(void*)0,&g_917,&g_917},{(void*)0,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,(void*)0},{&g_917,&g_917,&g_917,(void*)0},{(void*)0,(void*)0,&g_917,(void*)0}},{{(void*)0,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917},{&g_917,&g_917,(void*)0,&g_917},{(void*)0,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917}},{{&g_917,&g_917,&g_917,(void*)0},{(void*)0,(void*)0,&g_917,(void*)0},{(void*)0,&g_917,&g_917,(void*)0},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,(void*)0,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,&g_917,&g_917},{&g_917,&g_917,(void*)0,(void*)0}}};
static struct S0 g_1533 = {1,97};/* VOLATILE GLOBAL g_1533 */
static uint32_t ****g_1567 = &g_1443[1][4][2];
static volatile union U2 g_1591 = {0xA745991BL};/* VOLATILE GLOBAL g_1591 */
static volatile union U1 g_1609 = {0L};/* VOLATILE GLOBAL g_1609 */
static const volatile union U1 g_1627 = {-1L};/* VOLATILE GLOBAL g_1627 */
static struct S0 *g_1632 = &g_1257;
static struct S0 ** volatile g_1631 = &g_1632;/* VOLATILE GLOBAL g_1631 */
static const volatile union U2 g_1635 = {-9L};/* VOLATILE GLOBAL g_1635 */
static volatile union U1 g_1656[6][5][8] = {{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}},{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}},{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}},{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}},{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}},{{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}},{{2L},{2L},{2L},{2L},{2L},{2L},{2L},{2L}}}};
static int8_t * const *g_1683 = (void*)0;
static int8_t * const ** volatile g_1682 = &g_1683;/* VOLATILE GLOBAL g_1682 */
static const union U2 g_1707 = {0xF6789BBBL};/* VOLATILE GLOBAL g_1707 */
static int16_t *g_1763 = &g_195;
static int16_t * volatile *g_1762 = &g_1763;
static union U1 g_1767 = {0x3CL};/* VOLATILE GLOBAL g_1767 */
static struct S0 g_1773 = {0,-27};/* VOLATILE GLOBAL g_1773 */
static int64_t **** volatile g_1794[10] = {&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0],&g_400[0]};
static const union U2 g_1823 = {1L};/* VOLATILE GLOBAL g_1823 */
static const union U2 *g_1822[10] = {&g_1707,&g_1707,&g_1707,&g_1707,&g_1707,&g_1707,&g_1707,&g_1707,&g_1707,&g_1707};
static int8_t *g_1849 = &g_259;
static int8_t **g_1848 = &g_1849;
static int16_t g_1861 = 0x8772L;
static volatile struct S0 g_1878 = {1,-11};/* VOLATILE GLOBAL g_1878 */
static volatile union U1 g_1882 = {0x6BL};/* VOLATILE GLOBAL g_1882 */
static volatile uint32_t g_1903 = 0x89D47143L;/* VOLATILE GLOBAL g_1903 */
static const union U1 g_1931 = {0x4BL};/* VOLATILE GLOBAL g_1931 */
static volatile union U1 g_1999[3] = {{6L},{6L},{6L}};
static uint8_t **g_2023[6] = {(void*)0,&g_912,(void*)0,(void*)0,&g_912,(void*)0};
static volatile union U2 g_2045[9] = {{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}};
static union U2 g_2110 = {-1L};/* VOLATILE GLOBAL g_2110 */
static const uint32_t *g_2187 = (void*)0;
static const uint32_t **g_2186 = &g_2187;
static struct S0 ***g_2205 = (void*)0;
static struct S0 **g_2209 = &g_1632;
static struct S0 ***g_2208[8] = {&g_2209,&g_2209,&g_2209,&g_2209,&g_2209,&g_2209,&g_2209,&g_2209};
static struct S0 *** const * volatile g_2207 = &g_2208[3];/* VOLATILE GLOBAL g_2207 */
static union U1 g_2249 = {0x3DL};/* VOLATILE GLOBAL g_2249 */
static volatile union U1 g_2337 = {0x9FL};/* VOLATILE GLOBAL g_2337 */
static int32_t g_2346 = 0x3DEB19EFL;
static struct S0 ** const *g_2368[6][10][4] = {{{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209}},{{(void*)0,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209}},{{(void*)0,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,&g_2209,&g_2209,&g_2209}},{{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,(void*)0,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,(void*)0,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209}},{{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,(void*)0,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,(void*)0,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209}},{{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{(void*)0,(void*)0,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,(void*)0,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209},{&g_2209,&g_2209,&g_2209,&g_2209}}};
static struct S0 ** const **g_2367 = &g_2368[3][6][0];
static const volatile struct S0 g_2375 = {1,21};/* VOLATILE GLOBAL g_2375 */
static union U2 g_2402 = {-8L};/* VOLATILE GLOBAL g_2402 */
static volatile uint8_t *****g_2406 = (void*)0;
static uint64_t * const **g_2415 = (void*)0;
static uint64_t * const ***g_2414[1][4] = {{&g_2415,&g_2415,&g_2415,&g_2415}};
static uint64_t * const ****g_2413 = &g_2414[0][2];
static volatile int8_t g_2474 = 4L;/* VOLATILE GLOBAL g_2474 */
static volatile uint64_t g_2475 = 1UL;/* VOLATILE GLOBAL g_2475 */
static int8_t ***g_2493 = &g_1848;
static int8_t ****g_2492 = &g_2493;
static union U1 ***g_2522 = (void*)0;
static int16_t **g_2552 = &g_1763;
static int16_t *** volatile g_2551[5] = {&g_2552,&g_2552,&g_2552,&g_2552,&g_2552};
static union U1 **g_2585 = &g_1078;
static uint32_t ** const *g_2632 = (void*)0;
static uint32_t ** const **g_2631 = &g_2632;
static union U2 g_2658 = {-8L};/* VOLATILE GLOBAL g_2658 */
static union U2 g_2761 = {0x50B9F201L};/* VOLATILE GLOBAL g_2761 */
static union U1 g_2770 = {1L};/* VOLATILE GLOBAL g_2770 */
static int32_t ** volatile g_2782[2][5] = {{&g_72[2],&g_72[2],&g_72[2],&g_72[2],&g_72[2]},{&g_72[2],&g_72[2],&g_72[2],&g_72[2],&g_72[2]}};
static struct S0 g_2808 = {0,-125};/* VOLATILE GLOBAL g_2808 */
static volatile union U1 g_2825 = {0xE7L};/* VOLATILE GLOBAL g_2825 */
static union U2 g_2852 = {0x8E9E2964L};/* VOLATILE GLOBAL g_2852 */
static union U1 * const *g_2868[10] = {&g_1078,&g_1078,&g_1078,&g_1078,&g_1078,&g_1078,&g_1078,&g_1078,&g_1078,&g_1078};
static union U1 * const **g_2867 = &g_2868[4];
static union U1 * const ***g_2866 = &g_2867;
static union U1 * const ****g_2865 = &g_2866;
static struct S0 g_2894 = {0,112};/* VOLATILE GLOBAL g_2894 */
static union U1 g_2907 = {0L};/* VOLATILE GLOBAL g_2907 */
static volatile union U2 g_2919 = {0xBEE1DC8DL};/* VOLATILE GLOBAL g_2919 */
static struct S0 g_2920 = {1,-86};/* VOLATILE GLOBAL g_2920 */
static union U2 g_2933[1] = {{0xB3DAA8B2L}};
static union U1 g_2955 = {0xC8L};/* VOLATILE GLOBAL g_2955 */
static union U2 g_2963 = {0xDDE0E265L};/* VOLATILE GLOBAL g_2963 */
static int32_t *g_2967 = &g_123;
static int32_t *g_2972 = &g_253;
static int32_t ** volatile g_2973 = (void*)0;/* VOLATILE GLOBAL g_2973 */
static struct S0 g_3016 = {1,-126};/* VOLATILE GLOBAL g_3016 */
static struct S0 g_3050[6][2][8] = {{{{1,16},{1,7},{1,7},{1,16},{0,-103},{0,59},{0,18},{1,-122}},{{1,-122},{1,15},{1,-23},{1,76},{0,-45},{1,-122},{0,66},{0,99}}},{{{1,-59},{1,15},{1,16},{0,18},{1,22},{0,59},{1,15},{0,59}},{{0,-31},{1,7},{1,-112},{1,7},{0,-31},{1,-19},{1,22},{1,-112}}},{{{0,-103},{0,-31},{0,15},{1,-23},{1,-122},{0,-115},{1,-19},{1,7}},{{1,-105},{0,18},{0,15},{1,16},{0,-103},{1,-23},{1,-94},{1,-94}}},{{{1,-105},{0,-31},{1,118},{1,118},{0,-31},{1,-105},{1,-47},{0,66}},{{1,-23},{0,-103},{1,76},{0,59},{1,-59},{1,14},{0,-103},{0,99}}},{{{0,18},{1,-105},{0,66},{0,59},{1,-122},{1,7},{1,-59},{0,66}},{{0,15},{1,-122},{1,16},{1,118},{1,16},{1,-122},{0,15},{1,-94}}},{{{0,99},{1,-94},{1,-59},{1,76},{1,-47},{1,-112},{0,59},{1,16}},{{1,-105},{0,-115},{0,-103},{0,66},{1,-47},{1,-105},{0,-31},{1,118}}}};
static union U1 g_3067 = {-5L};/* VOLATILE GLOBAL g_3067 */
static volatile struct S0 g_3073[3] = {{0,-69},{0,-69},{0,-69}};
static volatile union U1 g_3083[1] = {{-8L}};
static int32_t g_3108 = 0xFC7928ECL;
static int32_t ***g_3121 = &g_71;
static int32_t ****g_3120 = &g_3121;
static volatile uint32_t g_3127 = 0xCEBC87A9L;/* VOLATILE GLOBAL g_3127 */
static volatile uint32_t *g_3126 = &g_3127;
static volatile uint32_t **g_3125[5][3][5] = {{{&g_3126,&g_3126,(void*)0,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126}},{{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126}},{{&g_3126,&g_3126,&g_3126,&g_3126,(void*)0},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126}},{{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,(void*)0,&g_3126}},{{(void*)0,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126},{&g_3126,&g_3126,&g_3126,&g_3126,&g_3126}}};
static volatile union U2 g_3128 = {-5L};/* VOLATILE GLOBAL g_3128 */
static volatile struct S0 g_3145 = {1,-11};/* VOLATILE GLOBAL g_3145 */
static uint64_t g_3172 = 0xFD65E8FFD8C74264LL;
static volatile int32_t * volatile g_3192 = &g_5[2];/* VOLATILE GLOBAL g_3192 */
static volatile int32_t * volatile * volatile g_3193 = &g_3192;/* VOLATILE GLOBAL g_3193 */
static volatile union U1 g_3236[4][2][1] = {{{{0L}},{{0xAAL}}},{{{0L}},{{0xAAL}}},{{{0L}},{{0xAAL}}},{{{0L}},{{0xAAL}}}};
static struct S0 ****g_3241 = (void*)0;
static struct S0 *****g_3240 = &g_3241;
static union U1 g_3260 = {0xFFL};/* VOLATILE GLOBAL g_3260 */
static struct S0 g_3261 = {0,107};/* VOLATILE GLOBAL g_3261 */
static volatile int32_t g_3308 = 0xFE11B0ADL;/* VOLATILE GLOBAL g_3308 */
static volatile int32_t *g_3307 = &g_3308;
static volatile int32_t ** volatile g_3306 = &g_3307;/* VOLATILE GLOBAL g_3306 */
static int32_t **g_3309 = (void*)0;
static const struct S0 g_3324[5] = {{1,-86},{1,-86},{1,-86},{1,-86},{1,-86}};
static const volatile uint32_t g_3328 = 0x86C0D614L;/* VOLATILE GLOBAL g_3328 */
static const volatile union U2 g_3333 = {0xFCFA24D8L};/* VOLATILE GLOBAL g_3333 */
static struct S0 g_3354 = {1,56};/* VOLATILE GLOBAL g_3354 */
static volatile union U2 g_3403 = {0L};/* VOLATILE GLOBAL g_3403 */
static int8_t g_3459 = 0x29L;
static uint64_t **g_3499[4][2] = {{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114}};
static uint64_t ***g_3498 = &g_3499[3][0];
static uint32_t **g_3520[5] = {&g_1240[0],&g_1240[0],&g_1240[0],&g_1240[0],&g_1240[0]};
static uint32_t ***g_3519 = &g_3520[1];
static int64_t g_3586 = 0L;
static union U2 g_3601 = {0xF6681B9DL};/* VOLATILE GLOBAL g_3601 */
static int16_t * const *g_3608 = &g_1763;
static int16_t * const ** volatile g_3607 = &g_3608;/* VOLATILE GLOBAL g_3607 */
static volatile union U2 g_3623[1][7] = {{{-4L},{-4L},{-4L},{-4L},{-4L},{-4L},{-4L}}};
static const uint16_t g_3641 = 0x8FCEL;
static int32_t ****g_3646 = &g_3121;
static union U2 g_3651[1][8][8] = {{{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}},{{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L},{0x3609BCC7L},{0x23CB4769L},{0x3609BCC7L},{0x35A4AAA3L}}}};
static volatile int32_t g_3654[5][8][6] = {{{0xF74E64F5L,0x82C30124L,0L,0x2D5E6DD1L,0L,0x3CC0E5F9L},{1L,(-1L),7L,0x2D5E6DD1L,0x7FFDB35AL,1L},{0xF74E64F5L,3L,0x189D82A3L,3L,0xF74E64F5L,0x3CC0E5F9L},{0x61CBB18CL,3L,7L,(-1L),0x7FFDB35AL,1L},{0x714ABE46L,(-1L),0xAA1D7486L,3L,0L,1L},{1L,0x82C30124L,7L,0x2D5E6DD1L,1L,0x3CC0E5F9L},{0L,(-1L),0x189D82A3L,0x2D5E6DD1L,0x11F01C52L,1L},{1L,3L,7L,3L,1L,0x3CC0E5F9L}},{{0x714ABE46L,3L,0L,(-1L),0x11F01C52L,1L},{0x61CBB18CL,(-1L),0L,3L,1L,1L},{0xF74E64F5L,0x82C30124L,0L,0x2D5E6DD1L,0L,0x3CC0E5F9L},{1L,(-1L),7L,0x2D5E6DD1L,0x7FFDB35AL,1L},{0xF74E64F5L,3L,0x189D82A3L,3L,0xF74E64F5L,0x3CC0E5F9L},{0x61CBB18CL,3L,7L,(-1L),0x7FFDB35AL,1L},{0x714ABE46L,(-1L),0xAA1D7486L,3L,0L,1L},{1L,0x82C30124L,7L,0x2D5E6DD1L,1L,0x3CC0E5F9L}},{{0L,(-1L),0x189D82A3L,0x2D5E6DD1L,0x11F01C52L,1L},{1L,3L,7L,3L,1L,0x3CC0E5F9L},{0x714ABE46L,3L,0L,(-1L),0x11F01C52L,1L},{0x61CBB18CL,(-1L),0L,3L,1L,1L},{0xF74E64F5L,0x82C30124L,0L,0x2D5E6DD1L,0L,0x3CC0E5F9L},{1L,(-1L),7L,0x2D5E6DD1L,0x7FFDB35AL,1L},{0xF74E64F5L,3L,0x189D82A3L,3L,0xF74E64F5L,0x3CC0E5F9L},{0x61CBB18CL,3L,7L,(-1L),0x7FFDB35AL,1L}},{{0x714ABE46L,(-1L),0xAA1D7486L,3L,0L,1L},{1L,0x82C30124L,7L,2L,0L,3L},{0xA7E70AACL,0xC7D2D446L,0x11F01C52L,2L,(-1L),(-1L)},{0x26BDAD8BL,0x26C879A5L,0x7FFDB35AL,0x26C879A5L,0x26BDAD8BL,3L},{0x269E1AE4L,0x26C879A5L,0x714ABE46L,0xB4804E69L,(-1L),0x2D5E6DD1L},{0x4D3BCA9CL,0xC7D2D446L,0L,0x26C879A5L,0L,0x2D5E6DD1L},{0xB277BFEEL,0xA33A4F2DL,0x714ABE46L,2L,0xA7E70AACL,3L},{0L,0xC7D2D446L,0x7FFDB35AL,2L,0x59BA7FDAL,(-1L)}},{{0xB277BFEEL,0x26C879A5L,0x11F01C52L,0x26C879A5L,0xB277BFEEL,3L},{0x4D3BCA9CL,0x26C879A5L,0x61CBB18CL,0xB4804E69L,0x59BA7FDAL,0x2D5E6DD1L},{0x269E1AE4L,0xC7D2D446L,9L,0x26C879A5L,0xA7E70AACL,0x2D5E6DD1L},{0x26BDAD8BL,0xA33A4F2DL,0x61CBB18CL,2L,0L,3L},{0xA7E70AACL,0xC7D2D446L,0x11F01C52L,2L,(-1L),(-1L)},{0x26BDAD8BL,0x26C879A5L,0x7FFDB35AL,0x26C879A5L,0x26BDAD8BL,3L},{0x269E1AE4L,0x26C879A5L,0x714ABE46L,0xB4804E69L,(-1L),0x2D5E6DD1L},{0x4D3BCA9CL,0xC7D2D446L,0L,0x26C879A5L,0L,0x2D5E6DD1L}}};
static volatile struct S0 g_3671 = {0,120};/* VOLATILE GLOBAL g_3671 */
static volatile union U1 g_3677 = {0x59L};/* VOLATILE GLOBAL g_3677 */
static int32_t g_3712 = (-9L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t * func_15(uint8_t  p_16, uint64_t  p_17, const int64_t  p_18, uint32_t  p_19, int32_t * p_20);
static int64_t  func_25(int32_t  p_26, int32_t * p_27);
static int32_t * func_40(const int64_t  p_41);
static uint16_t  func_42(const int64_t * p_43, int8_t  p_44, int32_t * p_45);
static int64_t * func_46(uint32_t  p_47, uint16_t  p_48, int64_t  p_49);
static int64_t  func_50(int64_t * p_51, const int32_t * p_52);
static uint32_t  func_57(uint16_t  p_58);
static int32_t * func_62(int32_t * p_63);
static int8_t  func_69(int32_t * p_70);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_9 g_1849 g_259 g_3128 g_3712 g_3519 g_3520 g_1240 g_1234 g_1762 g_1763 g_401 g_402 g_71 g_72 g_195 g_253 g_2967 g_2972
 * writes: g_2 g_9 g_6 g_482 g_195 g_71 g_259 g_78 g_182 g_253 g_2967
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_22 = 0xFBF26171L;
    const int16_t l_3708[9] = {0x257CL,0x257CL,0x257CL,0x257CL,0x257CL,0x257CL,0x257CL,0x257CL,0x257CL};
    uint32_t l_3709 = 0x0DE34288L;
    uint8_t *l_3710 = &g_482;
    int32_t l_3711 = 7L;
    union U1 *l_3713 = &g_3067;
    int64_t *l_3714 = &g_3586;
    int32_t l_3715[4] = {0x9F7BEFD4L,0x9F7BEFD4L,0x9F7BEFD4L,0x9F7BEFD4L};
    int32_t **l_3716 = &g_2967;
    int i;
    for (g_2 = (-29); (g_2 < (-28)); g_2 = safe_add_func_int32_t_s_s_unsafe_macro/*0*//* ___SAFE__OP */(g_2, 9))
    { /* block id: 3 */
        int64_t l_12 = 0x49B76EEA53061ECELL;
        int16_t l_21 = 0xC352L;
        int32_t *l_28 = &l_22;
        for (g_9 = 0; (g_9 != (-26)); g_9--)
        { /* block id: 6 */
            int32_t *l_13[6][6][2] = {{{&g_9,(void*)0},{&g_9,&g_9},{&g_14,&g_2},{&g_9,&g_14},{&g_2,&g_14},{&g_9,&g_2}},{{&g_9,&g_14},{&g_9,&g_2},{&g_9,&g_14},{&g_2,&g_14},{&g_9,&g_2},{&g_14,&g_9}},{{&g_9,(void*)0},{&g_9,&g_14},{(void*)0,&g_14},{&g_9,(void*)0},{&g_9,&g_9},{&g_14,&g_2}},{{&g_9,&g_14},{&g_2,&g_14},{&g_9,&g_2},{&g_9,&g_14},{&g_9,&g_2},{&g_9,&g_14}},{{&g_2,&g_14},{&g_9,&g_2},{&g_14,&g_9},{&g_9,(void*)0},{&g_9,&g_14},{(void*)0,&g_14}},{{&g_9,(void*)0},{&g_9,&g_9},{&g_14,&g_2},{&g_9,&g_14},{&g_2,&g_14},{&g_9,&g_2}}};
            int64_t *l_30 = &g_31;
            int32_t **l_3665 = &g_2972;
            int8_t l_3668[8][8] = {{(-7L),1L,(-1L),0xC7L,(-1L),(-1L),0xC7L,(-1L)},{1L,1L,7L,0xC7L,0xFBL,(-1L),1L,(-1L)},{(-7L),1L,(-1L),0xC7L,(-1L),(-1L),0xC7L,(-1L)},{1L,1L,7L,0xC7L,0xFBL,(-1L),1L,(-1L)},{(-7L),1L,(-1L),0xC7L,(-1L),(-1L),0xC7L,(-1L)},{1L,1L,7L,0xC7L,0xFBL,(-1L),1L,(-1L)},{(-7L),1L,(-1L),0xC7L,(-1L),(-1L),0xC7L,(-1L)},{1L,1L,7L,0xC7L,0xFBL,(-1L),1L,(-1L)}};
            int8_t ** const * const l_3674 = &g_1848;
            int8_t ** const * const *l_3673 = &l_3674;
            int8_t ** const * const **l_3672 = &l_3673;
            int i, j, k;
            g_6 = l_12;
        }
    }
    (*l_3716) = func_62(((safe_add_func_uint16_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(((((((safe_unary_minus_func_int8_t_s_unsafe_macro/*3*//* ___SAFE__OP */((l_22 & l_22))) | ((l_22 , ((((safe_div_func_uint64_t_u_u_unsafe_macro/*4*//* ___SAFE__OP */(18446744073709551615UL, l_22)) < (safe_mul_func_int16_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */(((((**g_1762) = (safe_div_func_int32_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u(((((safe_mod_func_uint16_t_u_u_unsafe_macro/*8*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u((safe_add_func_uint8_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s_unsafe_macro/*11*//* ___SAFE__OP */(0xAAL)), (*g_1849))), 10)) || ((safe_sub_func_uint32_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */(((((g_3128 , (safe_sub_func_uint8_t_u_u_unsafe_macro/*13*//* ___SAFE__OP */(((*l_3710) = ((safe_div_func_int16_t_s_s_unsafe_macro/*14*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s_unsafe_macro/*15*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*16*//* ___SAFE__OP */(l_3708[5], l_3709)), l_3709)) || 0x20A2L), l_3708[5])) < l_3708[5])), l_3709))) || (-1L)) != l_3708[8]) >= 246UL), l_3708[5])) >= 0xF0635B85L)) , 0UL), 0x3CCFL)) <= l_3711) >= l_3708[5]) , g_3712), l_3711)) || l_3711), (***g_3519)))) , l_3713) != l_3713), 0x33A5L))) , l_3714) == (*g_401))) , (**g_71))) <= l_3709) != l_3715[2]) >= l_3708[5]) & l_3708[4]), 0xE45F49CEL)), 65529UL)) , &l_3715[2]));
    (*g_2972) = (**l_3716);
    return (***g_3519);
}


/* ------------------------------------------ */
/* 
 * reads : g_2552 g_1763 g_100 g_2972 g_71 g_195 g_253 g_202 g_9 g_401 g_402 g_31 g_2 g_114 g_1393 g_1394 g_7 g_843.f2 g_1392 g_3016 g_1762 g_2967 g_123 g_1315 g_1849 g_259 g_1239 g_1240 g_3050 g_2865 g_2866 g_2867 g_2868 g_3067 g_883 g_917 g_3073 g_3083 g_72 g_14 g_1848 g_3108 g_3125 g_3128 g_1226 g_2375 g_105 g_3145 g_3172 g_1196 g_3192 g_3193 g_2413 g_2414 g_3121 g_2963.f2 g_3236 g_2492 g_2493 g_1234 g_3240 g_3260 g_3261 g_182 g_1631 g_1632 g_2209 g_2110.f2 g_3519 g_918 g_3601 g_3607 g_3623 g_714 g_5 g_3651 g_3646
 * writes: g_195 g_100 g_72 g_71 g_259 g_78 g_182 g_253 g_202 g_31 g_103 g_7 g_843.f2 g_1234 g_123 g_105 g_883 g_918 g_3108 g_3120 g_1226 g_1822 g_3192 g_2346 g_2963.f2 g_1632 g_2110.f2 g_3498 g_3608 g_714 g_3646
 */
static int32_t * func_15(uint8_t  p_16, uint64_t  p_17, const int64_t  p_18, uint32_t  p_19, int32_t * p_20)
{ /* block id: 12 */
    int64_t *l_53[6][3][2] = {{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}}};
    const int32_t *l_54 = &g_9;
    int8_t *****l_2968 = (void*)0;
    int8_t *****l_2969 = &g_2492;
    union U1 ****l_2993 = (void*)0;
    uint64_t l_3035 = 0UL;
    const struct S0 **l_3038 = (void*)0;
    const struct S0 ***l_3037 = &l_3038;
    const struct S0 ****l_3036 = &l_3037;
    struct S0 ****l_3039[4] = {&g_2205,&g_2205,&g_2205,&g_2205};
    int64_t l_3040 = 0x7EA6120495EFF861LL;
    uint64_t **l_3051 = &g_114;
    int32_t l_3103 = 0L;
    uint32_t l_3152 = 0x4A3EEB8CL;
    int32_t l_3182 = 1L;
    int32_t l_3186 = 3L;
    int32_t l_3187 = 0x073E104DL;
    int32_t l_3188[2];
    uint32_t ***l_3311 = &g_917;
    int32_t ** const *l_3315 = &g_71;
    int32_t ** const **l_3314 = &l_3315;
    int32_t l_3321[6][1] = {{0x42EC53BEL},{(-1L)},{0x42EC53BEL},{(-1L)},{0x42EC53BEL},{(-1L)}};
    const struct S0 *l_3323 = &g_3324[2];
    const struct S0 ** const l_3322[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint8_t ***l_3340[3];
    uint8_t *** const *l_3339[6][3] = {{&l_3340[1],&l_3340[1],&l_3340[1]},{&l_3340[1],(void*)0,(void*)0},{&l_3340[1],&l_3340[1],&l_3340[1]},{&l_3340[1],&l_3340[1],(void*)0},{&l_3340[1],&l_3340[1],&l_3340[1]},{&l_3340[1],(void*)0,(void*)0}};
    uint8_t *** const **l_3338 = &l_3339[2][2];
    uint32_t *** const *l_3356 = (void*)0;
    uint32_t *** const **l_3355 = &l_3356;
    uint32_t * const *l_3364[2][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    uint32_t * const **l_3363 = &l_3364[1][2];
    uint32_t * const ***l_3362 = &l_3363;
    uint32_t * const ****l_3361 = &l_3362;
    int8_t l_3395 = 0xB3L;
    uint32_t *l_3424 = &g_1234;
    int16_t **l_3449 = (void*)0;
    int32_t l_3458 = 0xE6D1A9F6L;
    union U2 **l_3481 = &g_842;
    uint32_t ***l_3521 = &g_3520[4];
    int32_t ***l_3523[10] = {&g_3309,&g_3309,&g_3309,&g_3309,&g_3309,&g_3309,&g_3309,&g_3309,&g_3309,&g_3309};
    int64_t l_3524 = 1L;
    int8_t l_3577[3][1];
    int8_t l_3624 = 0xC7L;
    const uint16_t *l_3640 = &g_3641;
    int32_t l_3663 = 0xEDA84D2EL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3188[i] = 0xADEC8EA7L;
    for (i = 0; i < 3; i++)
        l_3340[i] = &g_2023[2];
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_3577[i][j] = 0xF1L;
    }
    for (p_17 = 0; (p_17 <= 2); p_17 += 1)
    { /* block id: 15 */
        uint64_t l_37 = 0xA84ADE726F2C0E84LL;
        uint64_t ***l_988 = (void*)0;
    }
    if ((((**g_2552) = 1L) == ((l_2968 = l_2968) == l_2969)))
    { /* block id: 1464 */
        int32_t l_2985 = 0x2895C3E3L;
        uint64_t l_2998 = 1UL;
        int16_t l_2999 = (-9L);
        int32_t * const ****l_3002 = (void*)0;
        for (g_100 = 28; (g_100 == 51); g_100 = safe_add_func_int64_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */(g_100, 4))
        { /* block id: 1467 */
            int32_t **l_2974 = (void*)0;
            int32_t **l_2975 = &g_72[3];
            (*l_2975) = func_62(((*g_71) = g_2972));
        }
        for (g_202 = 0; (g_202 >= 40); g_202 = safe_add_func_uint32_t_u_u_unsafe_macro/*18*//* ___SAFE__OP */(g_202, 4))
        { /* block id: 1473 */
            uint64_t **l_2980 = &g_114;
            uint64_t ***l_2979 = &l_2980;
            int32_t l_2996 = (-1L);
            int32_t l_2997 = 0L;
            int32_t *l_3000 = (void*)0;
            int32_t *l_3001 = &l_2985;
            uint16_t *l_3003 = &g_103;
            (**g_1393) &= ((((*l_3003) = ((((0x4AL || (p_18 & (!(l_2979 == &l_2980)))) ^ 1UL) <= (safe_div_func_uint64_t_u_u_unsafe_macro/*19*//* ___SAFE__OP */(((*g_114) = (((((*l_3001) = ((((((((safe_rshift_func_uint64_t_u_s_unsafe_macro/*20*//* ___SAFE__OP */((p_17 = (l_2985 != (safe_div_func_uint64_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */(p_16, (safe_unary_minus_func_uint8_t_u_unsafe_macro/*22*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*23*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*24*//* ___SAFE__OP */((((l_2993 != ((((**g_401) |= (safe_div_func_int8_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */(((l_2996 = 0L) | (-6L)), (*l_54)))) >= 18446744073709551615UL) , (void*)0)) & p_18) ^ (*p_20)), l_2997)), l_2998)) <= 0x3DL))))))), l_2999)) || l_2996) >= l_2997) , l_2998) , 1L) || (*l_54)) ^ 0xAB33098FDB073563LL) | 0x45CAL)) , (void*)0) != l_3002) == p_19)), p_19))) != (*l_54))) && l_2997) , l_2996);
        }
        for (g_843.f2 = 23; (g_843.f2 < 36); g_843.f2 = safe_add_func_uint32_t_u_u_unsafe_macro/*26*//* ___SAFE__OP */(g_843.f2, 3))
        { /* block id: 1484 */
            if ((*l_54))
                break;
        }
        (***g_1392) ^= (((*l_54) && (*l_54)) | (safe_rshift_func_int32_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*28*//* ___SAFE__OP */((p_19 || 0x8ADCDF39A110A992LL), ((**g_401) ^= 0x44D201F9612A399ALL))), 20)));
    }
    else
    { /* block id: 1489 */
        uint16_t l_3021 = 0UL;
        uint8_t l_3024 = 0UL;
        int32_t l_3041 = (-1L);
        int64_t *l_3113[7];
        int32_t ***l_3119[6][4][2] = {{{(void*)0,&g_71},{&g_71,&g_71},{&g_71,&g_71},{&g_71,&g_71}},{{(void*)0,&g_71},{(void*)0,&g_71},{&g_71,&g_71},{&g_71,&g_71}},{{&g_71,&g_71},{(void*)0,&g_71},{(void*)0,&g_71},{&g_71,&g_71}},{{&g_71,&g_71},{&g_71,&g_71},{(void*)0,&g_71},{(void*)0,&g_71}},{{&g_71,&g_71},{&g_71,&g_71},{&g_71,&g_71},{(void*)0,&g_71}},{{(void*)0,&g_71},{&g_71,&g_71},{&g_71,&g_71},{&g_71,&g_71}}};
        int32_t ****l_3118 = &l_3119[3][0][0];
        uint64_t l_3189 = 0x4750A2F01ED9B726LL;
        uint32_t ***l_3233 = &g_917;
        union U1 **l_3237 = (void*)0;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_3113[i] = &g_78;
        if ((safe_rshift_func_int32_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_s_unsafe_macro/*30*//* ___SAFE__OP */((*l_54), (safe_rshift_func_uint64_t_u_u_unsafe_macro/*31*//* ___SAFE__OP */((((((g_3016 , ((((*l_54) , (safe_mod_func_int64_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */(((safe_mul_func_uint16_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */(((*l_54) ^ 0x7318CC7B28027099LL), (p_16 != l_3021))) <= (*l_54)), (safe_div_func_uint8_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */(p_17, 255UL))))) <= (*p_20)) >= p_18)) != l_3021) > 0xF6L) > (**g_1762)) != l_3024), p_17)))), (*g_2967))))
        { /* block id: 1490 */
            int32_t l_3045 = (-9L);
            l_3041 |= (g_1315 , (safe_mod_func_uint64_t_u_u_unsafe_macro/*35*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*36*//* ___SAFE__OP */(((**g_1762) = (safe_mod_func_int8_t_s_s_unsafe_macro/*37*//* ___SAFE__OP */((((((safe_rshift_func_int64_t_s_s_unsafe_macro/*38*//* ___SAFE__OP */(p_19, 16)) == (p_17 , (*g_1849))) < l_3035) , (l_3036 != l_3039[0])) <= ((**g_1239) = (p_16 == l_3040))), (*l_54)))), l_3024)), p_16)));
            (*g_2972) ^= (+(safe_rshift_func_int16_t_s_u_unsafe_macro/*39*//* ___SAFE__OP */(((void*)0 != &l_53[1][2][0]), (l_3041 ^= ((*l_54) < ((l_3045 | ((safe_mul_func_int32_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */(0L, ((safe_sub_func_uint64_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */((((**g_1239) = (*l_54)) != 0UL), (((((((*g_2967) = (-1L)) , g_3050[2][1][5]) , p_17) <= 0x406714E4DD1A58E8LL) , l_3051) == (void*)0))) && 0x360B5C76L))) && p_19)) >= 1L))))));
            for (g_105 = 0; g_105 < 4; g_105 += 1)
            {
                g_72[g_105] = (void*)0;
            }
        }
        else
        { /* block id: 1499 */
            uint64_t l_3060 = 0x6F7239149683DA83LL;
            int64_t *l_3068[1];
            int64_t *l_3069[9][3][2] = {{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}},{{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]},{&g_883[0][2][0],&g_883[0][2][0]}}};
            int64_t *l_3070 = &g_883[0][4][4];
            uint32_t *l_3071 = &g_235[0];
            uint64_t l_3072 = 0x4D1E2C3268AFCD21LL;
            union U1 **l_3076 = &g_1078;
            uint8_t l_3106 = 1UL;
            int32_t l_3144 = 0x62C51134L;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_3068[i] = (void*)0;
lbl_3181:
            (*g_2967) = ((((*g_2972) = (***g_1392)) , (safe_div_func_uint16_t_u_u_unsafe_macro/*42*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*43*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_s_unsafe_macro/*44*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*45*//* ___SAFE__OP */(((((((l_3060 >= (safe_mul_func_uint8_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */(0x95L, (((((safe_rshift_func_uint8_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*48*//* ___SAFE__OP */(((p_19 >= (((((((((***g_2865) == (((((*g_917) = func_40(((*l_3070) &= (g_3067 , 4L)))) == l_3071) , (-1L)) , (*g_2867))) | (*l_54)) , 0xFA9BL) > p_18) > p_19) || 0UL) < p_17) ^ p_18)) <= 0L), (*g_114))), p_17)) , l_3060) < p_16) | l_3072) <= 65529UL)))) <= p_16) , (*l_54)) , g_3073[1]) , p_19) > (*l_54)), 59)), (*p_20))) > 0xBBDF2EB71521687ELL), l_3072)) ^ 7L), (*l_54)))) == p_16);
            if (l_3060)
            { /* block id: 1504 */
                uint64_t *l_3084 = &l_3035;
                uint32_t * const *l_3085 = &g_918[1][3][5];
                int32_t l_3102 = 0L;
                int64_t l_3104[8][7] = {{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL},{0x8ED0D4E1A4EDEDC3LL,0x8ED0D4E1A4EDEDC3LL,0xF86B20CB53024424LL,(-1L),3L,(-1L),0xF86B20CB53024424LL}};
                int32_t ****l_3124[7] = {&l_3119[0][1][0],&g_3121,&g_3121,&l_3119[0][1][0],&g_3121,&g_3121,&l_3119[0][1][0]};
                union U2 *l_3180 = &g_2658;
                int i, j;
                for (g_78 = (-23); (g_78 == 23); ++g_78)
                { /* block id: 1507 */
                    int8_t l_3105 = 0xEEL;
                    int64_t *l_3114[5];
                    union U1 *****l_3117 = &l_2993;
                    int8_t *** const *l_3163 = &g_2493;
                    int8_t *** const **l_3162 = &l_3163;
                    int32_t l_3179 = 1L;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_3114[i] = &l_3040;
                    (*g_2967) = (p_17 ^ (l_3076 != (void*)0));
                    if ((*p_20))
                    { /* block id: 1509 */
                        int32_t l_3101 = 9L;
                        int32_t *l_3107 = &g_3108;
                        int32_t ****l_3122[1];
                        int32_t *****l_3123[8][10] = {{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]},{&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0],&l_3122[0]}};
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_3122[i] = &l_3119[2][1][0];
                        (*l_3107) ^= (safe_rshift_func_int16_t_s_u_unsafe_macro/*49*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*50*//* ___SAFE__OP */((((((*g_2967) == (safe_sub_func_uint16_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */((g_3083[0] , (((*g_2972) = ((void*)0 != l_3084)) >= (l_3085 != &l_3071))), (safe_mod_func_uint16_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */(((safe_mod_func_int64_t_s_s_unsafe_macro/*53*//* ___SAFE__OP */((l_3103 = ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*54*//* ___SAFE__OP */((((*l_54) || ((**g_71) , (safe_div_func_int8_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */((!(safe_sub_func_int32_t_s_s_unsafe_macro/*56*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */((((safe_rshift_func_int64_t_s_s_unsafe_macro/*58*//* ___SAFE__OP */((l_3101 = ((**g_401) = 8L)), 2)) , 0xE6ABF784E542D626LL) && p_18), l_3102)), 1L))), 1UL)))) , p_18), 1)) < p_17)), l_3104[0][3])) != l_3041), p_17))))) | l_3105) == p_19) >= (**g_1848)), p_18)), l_3106));
                        if ((*p_20))
                            break;
                        (*g_71) = (*g_71);
                        (*g_2967) ^= ((*g_2972) &= (((l_3041 != (l_3072 > (safe_div_func_int32_t_s_s_unsafe_macro/*59*//* ___SAFE__OP */((l_3113[3] != (p_16 , l_3114[2])), (safe_mul_func_int16_t_s_s_unsafe_macro/*60*//* ___SAFE__OP */(((void*)0 == l_3117), ((g_3120 = l_3118) == (l_3124[6] = l_3122[0])))))))) , g_3125[2][2][3]) == (void*)0));
                    }
                    else
                    { /* block id: 1521 */
                        int32_t *l_3132[2];
                        int32_t **l_3133 = (void*)0;
                        int32_t **l_3134 = &l_3132[1];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_3132[i] = &g_714;
                        (*g_1394) = ((g_3128 , (safe_sub_func_int8_t_s_s_unsafe_macro/*61*//* ___SAFE__OP */(p_17, (((+p_19) , p_20) == ((*l_3134) = l_3132[0]))))) & 1L);
                        if ((***g_1392))
                            break;
                    }
                    if ((0x2097D8BAL >= (*p_20)))
                    { /* block id: 1526 */
                        uint8_t *l_3135 = &g_1226[0][1];
                        int32_t l_3155 = (-1L);
                        (*g_2967) |= (((++(*l_3135)) <= ((safe_mod_func_int8_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */((*g_1849), (g_105 &= ((((g_2375 , ((*g_402) >= 0xAFE217662CF3E26DLL)) == (0x1E809817L < (((p_17 <= 1UL) && ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*64*//* ___SAFE__OP */(p_18, 15)) || ((l_3144 = p_16) , 250UL))) != 0x84F8DFDCL))) <= l_3106) > 8L)))), p_17)) ^ 0xCB6DL)) || p_19);
                        (*g_2972) |= (g_3145 , (safe_rshift_func_uint32_t_u_s_unsafe_macro/*65*//* ___SAFE__OP */(l_3144, (0xC1L == (safe_rshift_func_int16_t_s_s_unsafe_macro/*66*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s_unsafe_macro/*67*//* ___SAFE__OP */(l_3144, 6)), (l_3152 < (safe_mul_func_int32_t_s_s_unsafe_macro/*68*//* ___SAFE__OP */((p_19 != l_3155), (safe_rshift_func_int8_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */((l_3162 == &g_2492), 0xC8F13BF33537776DLL)), 49)) >= 18446744073709551615UL), l_3155)))))))))));
                    }
                    else
                    { /* block id: 1532 */
                        if ((*g_2967))
                            break;
                        (*g_2972) |= ((safe_mul_func_int8_t_s_s_unsafe_macro/*72*//* ___SAFE__OP */((-9L), (safe_sub_func_uint64_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*74*//* ___SAFE__OP */(0xBBA8D5F499A8F726LL, (l_3179 ^= ((((*g_2967) = (safe_sub_func_uint64_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */(((*l_3084) ^= g_3172), p_19))) ^ ((safe_div_func_int64_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */(((*l_3070) = (((safe_mul_func_int8_t_s_s_unsafe_macro/*77*//* ___SAFE__OP */((g_1196 , ((((safe_rshift_func_int32_t_s_u_unsafe_macro/*78*//* ___SAFE__OP */((p_16 | (p_16 || ((**g_401) > p_19))), p_17)) ^ 0x3BF8L) , p_17) || p_18)), p_18)) && (*l_54)) <= p_19)), (*l_54))) == (*l_54))) , p_18)))), (*g_402))))) , (*p_20));
                        g_1822[8] = l_3180;
                        (*g_2972) = 0x9134FC2BL;
                    }
                    if (g_3016.f0)
                        goto lbl_3181;
                }
            }
            else
            { /* block id: 1544 */
                uint16_t l_3183[6][2][5] = {{{65535UL,0UL,0UL,65535UL,0UL},{0x52EBL,0x52EBL,3UL,0x52EBL,0x52EBL}},{{0UL,65535UL,0UL,0UL,65535UL},{0x52EBL,1UL,1UL,0x52EBL,1UL}},{{65535UL,65535UL,0UL,65535UL,65535UL},{1UL,0x52EBL,1UL,1UL,0x52EBL}},{{65535UL,0UL,0UL,65535UL,0UL},{0x52EBL,0x52EBL,3UL,0x52EBL,0x52EBL}},{{0UL,65535UL,0UL,0UL,65535UL},{0x52EBL,1UL,1UL,0x52EBL,1UL}},{{65535UL,65535UL,0UL,65535UL,65535UL},{1UL,0x52EBL,1UL,1UL,0x52EBL}}};
                int i, j, k;
                --l_3183[1][0][3];
            }
            (*g_2972) = 0x220AB812L;
        }
        ++l_3189;
lbl_3297:
        (*g_3193) = g_3192;
        for (l_3035 = (-29); (l_3035 <= 44); ++l_3035)
        { /* block id: 1553 */
            uint8_t l_3219[5][7][7] = {{{0xA6L,0x3AL,0xC3L,7UL,0x8BL,0UL,255UL},{0x3AL,0UL,0xADL,7UL,0xACL,0x80L,255UL},{0UL,0xA6L,253UL,255UL,0x3FL,255UL,253UL},{0UL,0UL,0x98L,255UL,0x23L,250UL,253UL},{0x71L,0x3AL,0x68L,0xB9L,0x9FL,0x48L,255UL},{0xFEL,0xB4L,0xE5L,0x53L,0x23L,0xB9L,255UL},{2UL,0UL,0xE5L,0x62L,0x3FL,0x57L,0x4BL}},{{255UL,0x51L,0x68L,0x57L,0xACL,255UL,253UL},{2UL,255UL,0x98L,0x17L,0x8BL,255UL,251UL},{0xFEL,0UL,253UL,1UL,0xBDL,0x57L,0xADL},{0x71L,0xA2L,0xADL,0x17L,1UL,0xB9L,0xE5L},{0UL,0xA2L,0xC3L,0x57L,0UL,0x48L,0x26L},{0UL,0UL,251UL,0x62L,0x6BL,250UL,0xE5L},{0x3AL,255UL,248UL,0x53L,0x6BL,255UL,0xADL}},{{0xA6L,0x51L,252UL,0xB9L,0UL,0x80L,251UL},{0UL,0UL,248UL,255UL,1UL,0UL,253UL},{0UL,0xB4L,251UL,255UL,0xBDL,255UL,0x4BL},{0xA6L,0x3AL,0xC3L,7UL,0x8BL,0UL,255UL},{0x3AL,0UL,0xADL,9UL,0x8AL,0x04L,0UL},{0x4AL,0x3FL,0x16L,0x27L,0UL,0x27L,0x16L},{0x5CL,0x5CL,0x51L,255UL,0x86L,1UL,0x16L}},{{0UL,0xBDL,0x3AL,0x5AL,4UL,1UL,0UL},{0x10L,0x6BL,255UL,0xA5L,0x86L,0x5AL,2UL},{0xB7L,0UL,255UL,255UL,0UL,0x59L,0xB4L},{255UL,0x29L,0x3AL,0x59L,0x8AL,255UL,0xA6L},{0xB7L,255UL,0x51L,0x1AL,0x99L,255UL,0UL},{0x10L,1UL,0x16L,255UL,0xE2L,0x59L,5UL},{0UL,0x9FL,5UL,0x1AL,0x43L,0x5AL,255UL}},{{0x5CL,0x9FL,0UL,0x59L,9UL,1UL,0UL},{0x4AL,1UL,0UL,255UL,255UL,1UL,255UL},{0xBDL,255UL,0x14L,0xA5L,255UL,0x27L,5UL},{0x3FL,0x29L,0xFEL,0x5AL,9UL,0x04L,0UL},{1UL,0UL,0x14L,255UL,0x43L,255UL,0xA6L},{1UL,0x6BL,0UL,0x27L,0xE2L,7UL,0xB4L},{0x3FL,0xBDL,0UL,9UL,0x99L,255UL,2UL}}};
            union U2 **l_3250 = &g_842;
            int i, j, k;
            for (g_78 = 0; (g_78 <= 25); g_78 = safe_add_func_uint64_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */(g_78, 8))
            { /* block id: 1556 */
                int32_t l_3198 = 0xDFA77666L;
                int32_t l_3218 = 0L;
                int32_t *** const *l_3228 = &l_3119[3][0][0];
                union U1 **l_3238 = &g_1078;
                struct S0 *****l_3242 = &l_3039[0];
                int8_t ***l_3276 = &g_1848;
                if (l_3198)
                { /* block id: 1557 */
                    const int8_t l_3212 = 0x19L;
                    int16_t *l_3217[10] = {&g_1861,&g_613[6],&g_613[6],&g_613[6],&g_1861,&g_1861,&g_613[6],&g_613[6],&g_613[6],&g_1861};
                    int i;
                    (*g_2967) &= (safe_sub_func_int16_t_s_s_unsafe_macro/*80*//* ___SAFE__OP */((l_3218 = (((safe_mul_func_int64_t_s_s_unsafe_macro/*81*//* ___SAFE__OP */(((l_3187 = (((**g_2552) ^= (safe_mod_func_int32_t_s_s_unsafe_macro/*82*//* ___SAFE__OP */((((((safe_rshift_func_uint8_t_u_s_unsafe_macro/*83*//* ___SAFE__OP */((*l_54), (((9L != (0x4D1932BEL ^ (*p_20))) <= p_18) > ((safe_lshift_func_int8_t_s_s_unsafe_macro/*84*//* ___SAFE__OP */((~(safe_lshift_func_int16_t_s_s_unsafe_macro/*85*//* ___SAFE__OP */(l_3212, (safe_add_func_uint8_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(((p_17 |= l_3212) || (safe_sub_func_uint64_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */(((void*)0 != (*g_2413)), p_19))), 247UL))))), 1)) | l_3212)))) ^ (*l_54)) , 0x7687A4B6L) != p_19) < 65527UL), p_19))) | p_19)) & 0x2C784E2CL), 0xF89A1C2AE0D2EA34LL)) <= p_18) ^ l_3198)), p_18));
                }
                else
                { /* block id: 1563 */
                    l_3219[2][1][4]++;
                }
                for (g_182 = 5; (g_182 == 20); g_182++)
                { /* block id: 1568 */
                    (**g_3121) = p_20;
                }
                for (l_3186 = (-2); (l_3186 < (-20)); l_3186 = safe_sub_func_uint8_t_u_u_unsafe_macro/*88*//* ___SAFE__OP */(l_3186, 7))
                { /* block id: 1573 */
                    (**g_3121) = p_20;
                }
                for (g_2346 = (-29); (g_2346 == (-6)); g_2346 = safe_add_func_uint16_t_u_u_unsafe_macro/*89*//* ___SAFE__OP */(g_2346, 3))
                { /* block id: 1578 */
                    int8_t l_3231 = 0x1AL;
                    struct S0 *****l_3243 = &l_3039[0];
                    uint8_t *l_3262 = &g_1226[0][0];
                    uint16_t *l_3263 = &g_182;
                    int32_t l_3293[7] = {0x3DEE7C88L,0x3DEE7C88L,0x3DEE7C88L,0x3DEE7C88L,0x3DEE7C88L,0x3DEE7C88L,0x3DEE7C88L};
                    int i;
                    for (g_2963.f2 = 0; (g_2963.f2 <= 4); g_2963.f2 += 1)
                    { /* block id: 1581 */
                        int16_t l_3239 = 5L;
                        int i, j, k;
                        p_20 = ((((*g_2967) = (((void*)0 != l_3228) | ((**g_1762) = ((safe_mul_func_uint16_t_u_u_unsafe_macro/*90*//* ___SAFE__OP */(l_3231, (((+(l_3219[g_2963.f2][(g_2963.f2 + 1)][(g_2963.f2 + 1)] = (((void*)0 == l_3233) & (*l_54)))) | 0xAC80L) && ((((safe_mul_func_uint8_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */(((((((g_3236[1][1][0] , (((*p_20) , (*l_54)) & p_19)) != 2UL) & 2UL) != p_17) , l_3237) == l_3238), (****g_2492))) || (-1L)) | 0xF00FAAE3B320062ELL) < l_3239)))) > p_17)))) <= (**g_1239)) , p_20);
                    }
                    if ((((l_3242 = g_3240) != (l_3243 = &g_3241)) > (safe_sub_func_uint8_t_u_u_unsafe_macro/*92*//* ___SAFE__OP */((p_17 == (safe_mod_func_int8_t_s_s_unsafe_macro/*93*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u_unsafe_macro/*94*//* ___SAFE__OP */(((void*)0 != l_3250), ((((*l_3263) |= ((safe_mod_func_uint32_t_u_u_unsafe_macro/*95*//* ___SAFE__OP */((((safe_unary_minus_func_int32_t_s_unsafe_macro/*96*//* ___SAFE__OP */(((*g_2967) = (*p_20)))) < ((p_19 < (safe_sub_func_int32_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((((*l_3262) = ((safe_add_func_int8_t_s_s_unsafe_macro/*99*//* ___SAFE__OP */(((g_3260 , g_3261) , p_17), (***g_2493))) , p_18)) | 0x3DL) < 9L), p_16)), (*p_20)))) && p_19)) > p_18), p_19)) , (*l_54))) < p_16) ^ 0x9DL))) <= l_3218) ^ 0x1EA1EAD1L), 5L))), 0xB6L))))
                    { /* block id: 1592 */
                        int16_t l_3291[2][1];
                        uint16_t l_3292 = 0x9C6BL;
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_3291[i][j] = 0L;
                        }
                        (*g_2972) = (safe_add_func_int8_t_s_s_unsafe_macro/*100*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*101*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*102*//* ___SAFE__OP */(((((safe_lshift_func_uint32_t_u_u_unsafe_macro/*103*//* ___SAFE__OP */(l_3231, 26)) & 0xFA90L) || 0x8FF62104L) != ((safe_mul_func_int8_t_s_s_unsafe_macro/*104*//* ___SAFE__OP */(l_3231, (((-5L) > ((safe_sub_func_int32_t_s_s_unsafe_macro/*105*//* ___SAFE__OP */(((void*)0 != l_3276), ((safe_add_func_int8_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_u_unsafe_macro/*107*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u_unsafe_macro/*108*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*109*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*110*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*111*//* ___SAFE__OP */(((g_182 = (safe_mod_func_int16_t_s_s_unsafe_macro/*112*//* ___SAFE__OP */((*l_54), (**g_1762)))) || p_19), p_16)), 12)), 8)), p_17)), 3)) >= l_3291[1][0]), p_19)) ^ (*p_20)))) , 18446744073709551615UL)) > p_17))) < 1UL)), l_3292)), 1UL)), p_18));
                    }
                    else
                    { /* block id: 1595 */
                        uint64_t l_3294[4][8][3] = {{{18446744073709551615UL,18446744073709551612UL,0xB6C7DAEFEA59AE95LL},{6UL,4UL,18446744073709551615UL},{18446744073709551615UL,0xF4A6BD6E9C900EBALL,0x32E4188ECE8C1CD4LL},{18446744073709551615UL,18446744073709551615UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xF4A6BD6E9C900EBALL},{6UL,0UL,18446744073709551608UL},{18446744073709551615UL,0UL,0UL},{18446744073709551611UL,6UL,18446744073709551608UL}},{{0xB6C7DAEFEA59AE95LL,18446744073709551615UL,0xF4A6BD6E9C900EBALL},{18446744073709551615UL,0xB96DEA500D595EF7LL,0UL},{0x32E4188ECE8C1CD4LL,2UL,0x32E4188ECE8C1CD4LL},{0UL,0xB96DEA500D595EF7LL,18446744073709551615UL},{0xF4A6BD6E9C900EBALL,18446744073709551615UL,0xB6C7DAEFEA59AE95LL},{18446744073709551608UL,6UL,18446744073709551611UL},{0UL,0UL,18446744073709551615UL},{18446744073709551608UL,0UL,6UL}},{{0xF4A6BD6E9C900EBALL,18446744073709551615UL,18446744073709551615UL},{0UL,18446744073709551615UL,18446744073709551615UL},{0x32E4188ECE8C1CD4LL,0xF4A6BD6E9C900EBALL,18446744073709551615UL},{18446744073709551615UL,18446744073709551608UL,0x65BA074C65677AABLL},{0x32E4188ECE8C1CD4LL,18446744073709551615UL,0UL},{0xB96DEA500D595EF7LL,18446744073709551614UL,0xB96DEA500D595EF7LL},{0UL,18446744073709551615UL,0x32E4188ECE8C1CD4LL},{0x65BA074C65677AABLL,18446744073709551608UL,18446744073709551611UL}},{{0xB6C7DAEFEA59AE95LL,2UL,18446744073709551612UL},{1UL,1UL,18446744073709551615UL},{0xB6C7DAEFEA59AE95LL,0UL,2UL},{0x65BA074C65677AABLL,18446744073709551615UL,18446744073709551615UL},{0UL,1UL,1UL},{0xB96DEA500D595EF7LL,0x65BA074C65677AABLL,18446744073709551615UL},{0x32E4188ECE8C1CD4LL,18446744073709551615UL,2UL},{18446744073709551611UL,0UL,18446744073709551615UL}}};
                        int i, j, k;
                        (*g_2209) = (*g_1631);
                        --l_3294[2][0][0];
                        (**g_1393) &= (*p_20);
                        if (g_1315.f0)
                            goto lbl_3297;
                    }
                }
            }
        }
    }
    for (g_2963.f2 = 0; (g_2963.f2 <= 0); g_2963.f2 += 1)
    { /* block id: 1607 */
        int32_t ***l_3310 = &g_3309;
        const uint8_t l_3318 = 0UL;
        int8_t ***l_3319 = &g_1848;
        uint64_t l_3320 = 18446744073709551610UL;
        struct S0 **l_3325 = &g_1632;
        int32_t l_3326 = 0xB42BD46EL;
        uint64_t l_3327 = 0x670BA73956D39DA5LL;
        int8_t *l_3329 = &g_105;
        uint8_t *****l_3337 = (void*)0;
        const int16_t l_3366[6] = {7L,0x697EL,7L,7L,0x697EL,7L};
        uint16_t l_3367 = 65535UL;
        int32_t l_3397[5];
        uint32_t *****l_3452 = &g_1567;
        uint8_t l_3460 = 255UL;
        int32_t *l_3463 = &l_3188[0];
        int i;
        for (i = 0; i < 5; i++)
            l_3397[i] = 0x00195352L;
    }
    if ((p_17 == ((((safe_rshift_func_uint32_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_s_unsafe_macro/*114*//* ___SAFE__OP */((!(((p_16 = (65535UL > ((((((*g_2972) = ((*l_54) != (safe_rshift_func_int8_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */((((void*)0 == (*g_2493)) , (*l_54)), ((((safe_mod_func_uint32_t_u_u_unsafe_macro/*116*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */(((void*)0 != &g_1682), (safe_sub_func_int64_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */(((safe_mul_func_uint32_t_u_u_unsafe_macro/*119*//* ___SAFE__OP */(((((safe_mul_func_uint8_t_u_u_unsafe_macro/*120*//* ___SAFE__OP */((&g_1822[8] != l_3481), 0xA6L)) & (*g_2972)) <= p_17) , p_16), p_19)) , 0xC234797E33815CD7LL), p_18)))), (*l_54))) , 0xFD48L) && p_17) , (*l_54)))))) != (*p_20)) == (*l_54)) < (****g_2492)) , p_16))) && 1L) != p_19)), 10)), p_19)) , (*g_114)) != p_18) != p_19)))
    { /* block id: 1697 */
        int16_t * const *l_3485 = &g_1763;
        int16_t * const **l_3484 = &l_3485;
        union U1 *l_3504 = &g_2770;
        int32_t l_3508 = (-1L);
        int64_t *l_3510 = &g_883[0][2][0];
        uint32_t l_3522[5];
        int i;
        for (i = 0; i < 5; i++)
            l_3522[i] = 0xBD44FF18L;
        for (p_19 = 0; (p_19 <= 24); ++p_19)
        { /* block id: 1700 */
            return p_20;
        }
        (**g_1393) |= ((void*)0 != l_3484);
        for (g_2110.f2 = 10; (g_2110.f2 == 5); g_2110.f2--)
        { /* block id: 1706 */
            uint16_t l_3494 = 0x983AL;
            (***g_1392) |= (safe_lshift_func_int16_t_s_s_unsafe_macro/*121*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s_unsafe_macro/*122*//* ___SAFE__OP */(((p_16 &= 0xACL) != ((**g_1848) = p_17)), 5)), 4));
            for (p_17 = 0; (p_17 != 57); p_17 = safe_add_func_uint8_t_u_u_unsafe_macro/*123*//* ___SAFE__OP */(p_17, 1))
            { /* block id: 1712 */
                --l_3494;
                (***g_1392) ^= (*p_20);
                if ((*p_20))
                    break;
                if ((*p_20))
                    break;
            }
        }
        (***g_1392) = (safe_unary_minus_func_uint16_t_u_unsafe_macro/*124*//* ___SAFE__OP */((((g_3498 = &l_3051) != ((safe_rshift_func_int64_t_s_s_unsafe_macro/*125*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*126*//* ___SAFE__OP */((l_3504 != l_3504), (safe_add_func_uint32_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */(((((!l_3508) != (safe_unary_minus_func_uint8_t_u_unsafe_macro/*128*//* ___SAFE__OP */(p_16))) , ((l_3510 != (void*)0) & ((safe_mul_func_int8_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*130*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */((&g_3309 == ((safe_rshift_func_int32_t_s_u_unsafe_macro/*132*//* ___SAFE__OP */((((l_3521 = g_3519) != (void*)0) != l_3522[2]), 9)) , l_3523[7])), (*l_54))), p_16)), l_3524)) <= 1L))) , p_19), p_17)))), l_3522[3])) , (void*)0)) , p_19)));
    }
    else
    { /* block id: 1722 */
        int32_t l_3531 = 0L;
        uint16_t l_3549 = 65535UL;
        int32_t l_3563[6][7][5] = {{{9L,0x2080AB7CL,1L,0x25EEC830L,0xDEA90276L},{1L,0xED60615FL,0x1C3DD6ECL,0xEB257F82L,0xEB257F82L},{0xDEA90276L,0xFFB521DEL,0xDEA90276L,0xD3CF8471L,0xD4EE2E58L},{7L,(-4L),1L,0x1C3DD6ECL,1L},{0xFFB521DEL,0xD4EE2E58L,1L,9L,0x2FC97BDEL},{0x209CC1D3L,1L,1L,1L,(-1L)},{6L,1L,0xDEA90276L,0xDEA90276L,1L}},{{0x3BB1A165L,0xE8DBD94DL,0x1C3DD6ECL,7L,(-3L)},{0x2080AB7CL,0L,1L,0xFFB521DEL,0xDCB00FF4L},{1L,0xD56CD776L,0x5FDA6124L,0x209CC1D3L,0L},{0x2080AB7CL,0x727FD2B9L,9L,6L,0x25EEC830L},{0x3BB1A165L,(-1L),(-1L),0x3BB1A165L,0x1C3DD6ECL},{6L,9L,0x727FD2B9L,0x2080AB7CL,9L},{0x209CC1D3L,0x5FDA6124L,0xD56CD776L,1L,(-1L)}},{{0xFFB521DEL,1L,0L,0x2080AB7CL,0x07A379ACL},{7L,0x1C3DD6ECL,0xE8DBD94DL,0x3BB1A165L,0xE8DBD94DL},{0xDEA90276L,0xDEA90276L,1L,6L,1L},{1L,1L,1L,0x209CC1D3L,0x3BB1A165L},{9L,1L,0xD4EE2E58L,0xFFB521DEL,0xC6E27140L},{0x1C3DD6ECL,1L,(-4L),7L,0xD56CD776L},{0xD3CF8471L,0xDEA90276L,0xFFB521DEL,0xDEA90276L,0xD3CF8471L}},{{0xEB257F82L,0x1C3DD6ECL,0xED60615FL,1L,0xDBB45860L},{0x25EEC830L,1L,0x2080AB7CL,9L,0xFFB521DEL},{0xED60615FL,0x5FDA6124L,(-1L),0x1C3DD6ECL,0xDBB45860L},{0xC6E27140L,9L,0x25EEC830L,0xD3CF8471L,0xD3CF8471L},{0xDBB45860L,(-1L),0xDBB45860L,0xEB257F82L,0xD56CD776L},{0x6F13A0CBL,0x727FD2B9L,0x49C71A79L,0x25EEC830L,0xC6E27140L},{(-1L),0xD56CD776L,(-1L),0xED60615FL,0x3BB1A165L}},{{(-2L),0L,0x49C71A79L,0xC6E27140L,1L},{(-10L),0xE8DBD94DL,(-3L),(-3L),(-1L)},{0xDC00C763L,1L,0xFFB521DEL,0L,0xDCB00FF4L},{1L,0x5FDA6124L,(-10L),0xC5F5BD8DL,0x1C3DD6ECL},{0x727FD2B9L,1L,0xC6E27140L,9L,0x2FC97BDEL},{1L,0xD56CD776L,0xEB257F82L,0xDBB45860L,(-1L)},{0xDC00C763L,9L,9L,0xDC00C763L,0xFFB521DEL}},{{0xDBB45860L,0xEB257F82L,0xD56CD776L,1L,0x3BB1A165L},{9L,0xC6E27140L,1L,0x727FD2B9L,0x25EEC830L},{0xC5F5BD8DL,(-10L),0x5FDA6124L,1L,(-1L)},{0L,0xFFB521DEL,1L,0xDC00C763L,1L},{(-3L),(-3L),(-1L),0xDBB45860L,(-10L)},{9L,0x727FD2B9L,0x2080AB7CL,9L,0xDC00C763L},{0xEB257F82L,0x209CC1D3L,0xE8DBD94DL,0xC5F5BD8DL,0xED60615FL}}};
        uint64_t l_3590 = 0xAE657F32E6B83E7CLL;
        int16_t l_3593[7][6][5] = {{{(-1L),8L,0L,0x082FL,0xE3A7L},{(-1L),0xB507L,0L,0xB507L,(-1L)},{3L,0x1EEAL,(-4L),0xB507L,0x082FL},{0x1AFDL,3L,0xCD48L,0x082FL,(-6L)},{0L,(-4L),0x082FL,0x1EEAL,0x082FL},{0x082FL,0x082FL,(-1L),0xCD48L,(-1L)}},{{0x082FL,0L,(-1L),0L,0xE3A7L},{0L,(-1L),(-6L),8L,0xB507L},{0x1AFDL,0L,0L,0x1AFDL,1L},{3L,0x082FL,0L,(-1L),0L},{(-1L),(-4L),(-6L),0L,0L},{(-1L),3L,(-1L),(-1L),3L}},{{0xE3A7L,0x1EEAL,(-1L),0x1AFDL,3L},{(-4L),0xB507L,0x082FL,8L,0L},{0x1EEAL,8L,0xCD48L,0L,0L},{(-4L),(-1L),(-4L),0xCD48L,1L},{0xE3A7L,(-1L),0L,0x1EEAL,0xB507L},{(-1L),8L,0L,0x082FL,0xE3A7L}},{{(-1L),0xB507L,0L,0xB507L,(-1L)},{3L,0x1EEAL,(-4L),0xB507L,0x082FL},{0x1AFDL,3L,0xCD48L,0x082FL,(-6L)},{0L,(-4L),0x082FL,0x1EEAL,0x082FL},{0x082FL,0x082FL,(-1L),0xCD48L,(-1L)},{0x082FL,0L,(-1L),0L,0xE3A7L}},{{0L,(-1L),(-6L),8L,0xB507L},{0x1AFDL,0L,(-6L),0xE3A7L,(-1L)},{0L,0L,(-6L),(-4L),(-1L)},{(-4L),1L,0L,0x1EEAL,(-6L)},{0xB507L,0L,(-4L),(-4L),0L},{0xCD48L,0x1AFDL,8L,0xE3A7L,0L}},{{1L,0x082FL,0L,(-1L),(-6L)},{0x1AFDL,(-1L),3L,(-1L),(-1L)},{1L,8L,1L,3L,(-1L)},{0xCD48L,8L,0x1EEAL,0x1AFDL,0x082FL},{0xB507L,(-1L),(-1L),0L,0xCD48L},{(-4L),0x082FL,0x1EEAL,0x082FL,(-4L)}},{{0L,0x1AFDL,1L,0x082FL,0L},{0xE3A7L,0L,3L,0L,0L},{0x1EEAL,1L,0L,0x1AFDL,0L},{0L,0L,8L,3L,(-4L)},{0L,(-6L),(-4L),(-1L),0xCD48L},{0x1EEAL,0xB507L,0L,(-1L),0x082FL}}};
        int32_t *l_3605 = &l_3187;
        int32_t l_3625 = 0xE5AA3335L;
        int i, j, k;
        for (g_2963.f2 = (-30); (g_2963.f2 != 27); g_2963.f2 = safe_add_func_uint8_t_u_u_unsafe_macro/*133*//* ___SAFE__OP */(g_2963.f2, 1))
        { /* block id: 1725 */
            uint16_t l_3534 = 0x557EL;
            int32_t *l_3545 = &g_3108;
            uint32_t ****l_3561 = &g_1443[4][2][1];
            int32_t l_3575 = 0xD9A2C768L;
            int32_t l_3576 = 0x1FACFD92L;
            int32_t l_3579 = 0xA5092FEBL;
            int32_t l_3581 = (-8L);
            int32_t l_3584[3][6] = {{1L,0xECE839E7L,1L,0L,0xECE839E7L,0L},{1L,4L,1L,0L,4L,1L},{1L,1L,0L,0L,1L,1L}};
            uint8_t l_3594 = 254UL;
            uint32_t l_3626 = 0x948F9C4AL;
            int32_t ****l_3644 = &g_3121;
            uint32_t l_3658 = 4294967295UL;
            int i, j;
            (*l_3545) = (safe_rshift_func_int32_t_s_u_unsafe_macro/*134*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*135*//* ___SAFE__OP */(((**l_3051) ^= (((**g_401) = l_3531) > p_16)), (safe_mul_func_uint32_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */((l_3534 >= ((safe_div_func_uint16_t_u_u_unsafe_macro/*137*//* ___SAFE__OP */((0xDB0C840A4CE2C2ABLL & (safe_mul_func_int8_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */(l_3531, ((p_18 < ((0x87BF7EAC1E851BAALL | (safe_sub_func_int16_t_s_s_unsafe_macro/*139*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*140*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*141*//* ___SAFE__OP */((0L > ((p_20 != l_3545) , (**g_2552))), l_3531)) && 18446744073709551610UL), 0x09D0AEE27F9CF727LL)), (*l_3545)))) == 0x8C501719689BC366LL)) == p_17)))), p_17)) , 0x75L)), 4294967291UL)))), l_3531));
            for (g_2346 = 0; (g_2346 <= 1); g_2346 += 1)
            { /* block id: 1731 */
                uint32_t l_3546[8] = {0x267EF7A0L,0x267EF7A0L,0x267EF7A0L,0x267EF7A0L,0x267EF7A0L,0x267EF7A0L,0x267EF7A0L,0x267EF7A0L};
                int32_t l_3565 = 0x053823B0L;
                int32_t l_3567 = 2L;
                int32_t l_3568 = 0xD305880FL;
                int32_t l_3578 = (-1L);
                int32_t l_3580 = 0x33C99747L;
                int32_t l_3582 = 0x8A08B5F2L;
                int32_t l_3583 = 0x697D2F29L;
                int32_t l_3585 = 0x70FF977AL;
                int32_t l_3588 = (-1L);
                int32_t l_3589[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                int16_t * const *l_3606[6] = {&g_1763,&g_1763,(void*)0,&g_1763,&g_1763,(void*)0};
                int64_t ***l_3627 = &g_401;
                int i;
                l_3546[5]--;
                for (p_16 = 0; (p_16 <= 1); p_16 += 1)
                { /* block id: 1735 */
                    uint32_t *l_3560 = &g_235[0];
                    uint16_t *l_3562 = (void*)0;
                    int32_t l_3566[7][1] = {{1L},{1L},{0x506D5122L},{1L},{1L},{0x506D5122L},{1L}};
                    uint16_t l_3620 = 1UL;
                    int i, j, k;
                    for (g_31 = 1; (g_31 >= 0); g_31 -= 1)
                    { /* block id: 1738 */
                        if ((*p_20))
                            break;
                        --l_3549;
                    }
                    if (((((g_182 ^= (((p_17 || p_19) <= ((p_18 & (safe_rshift_func_int32_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */((((((safe_mod_func_int32_t_s_s_unsafe_macro/*143*//* ___SAFE__OP */((((**g_401) = (**g_401)) , 1L), (safe_mod_func_int16_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */((p_18 <= (safe_div_func_int16_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */((((*g_917) = (*g_917)) == l_3560), (-1L)))), (*g_1763))))) & (*p_20)) ^ p_18) , &g_1443[5][2][1]) == l_3561), (***g_1392)))) <= 0x09L)) , l_3546[1])) & p_19) , p_16) , (*g_2972)))
                    { /* block id: 1745 */
                        int16_t l_3564 = 0x1D8DL;
                        int32_t *l_3569 = &l_3187;
                        int32_t *l_3570 = &l_3103;
                        int32_t *l_3571 = &l_3563[3][6][2];
                        int32_t *l_3572 = &l_3567;
                        int32_t *l_3573 = &l_3321[1][0];
                        int32_t *l_3574[1];
                        int16_t l_3587 = 1L;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_3574[i] = &l_3563[2][3][1];
                        --l_3590;
                        (*g_71) = (**g_3121);
                        l_3594--;
                    }
                    else
                    { /* block id: 1749 */
                        uint16_t *l_3599[8][10] = {{(void*)0,&g_103,&l_3534,(void*)0,&g_182,(void*)0,&g_103,&l_3549,&g_103,&l_3549},{&l_3534,&l_3549,(void*)0,&g_103,&g_182,&g_103,(void*)0,&l_3549,&l_3534,(void*)0},{&g_182,&g_103,&l_3549,&l_3549,&l_3534,&l_3534,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3549,&g_182,&l_3549,&l_3549,&l_3549,&l_3549,&g_182,&l_3549,&l_3534,&l_3534},{&g_182,(void*)0,(void*)0,&g_103,(void*)0,(void*)0,(void*)0,&l_3549,&g_103,&l_3549},{&g_103,&l_3549,(void*)0,(void*)0,(void*)0,&l_3549,&g_103,&l_3549,&l_3549,&l_3549},{&l_3534,&l_3534,&g_103,(void*)0,&l_3549,&l_3549,&l_3534,&g_103,&g_103,&l_3534},{(void*)0,&l_3534,&l_3534,&l_3534,&l_3534,(void*)0,&l_3549,(void*)0,&l_3534,&l_3549}};
                        int32_t l_3600 = 1L;
                        int32_t **l_3604 = (void*)0;
                        int i, j;
                        l_3605 = func_40((safe_sub_func_uint16_t_u_u_unsafe_macro/*146*//* ___SAFE__OP */((l_3600 = (((**l_3051) &= 0UL) <= 9L)), (g_3601 , (safe_lshift_func_uint8_t_u_s_unsafe_macro/*147*//* ___SAFE__OP */(p_18, 5))))));
                        (*g_3607) = l_3606[2];
                    }
                    (*g_1394) = (safe_rshift_func_uint16_t_u_s_unsafe_macro/*148*//* ___SAFE__OP */((((safe_mul_func_uint32_t_u_u_unsafe_macro/*149*//* ___SAFE__OP */((((safe_rshift_func_uint16_t_u_s_unsafe_macro/*150*//* ___SAFE__OP */(0x46EEL, (l_3565 = (l_3626 = ((safe_add_func_int64_t_s_s_unsafe_macro/*151*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u_unsafe_macro/*152*//* ___SAFE__OP */(((((~0xC5E5C9B25D8A2BA3LL) & ((**g_1762) = (((((p_18 ^ l_3620) || ((safe_mul_func_int32_t_s_s_unsafe_macro/*153*//* ___SAFE__OP */((((4294967295UL == ((((*p_20) && (0xBB5C3A4BD47E387CLL > (((l_3566[5][0] = 253UL) <= ((g_3623[0][2] , l_3562) != &l_3593[0][3][2])) || p_16))) , (*l_3545)) , 1L)) != l_3624) , (*p_20)), l_3565)) & 0x6231EE7DL)) && l_3625) && 0x6075EF8DE69B2117LL) < p_18))) == (***g_2493)) || (-1L)), 0xC63AL)) > p_19), 0xFD1DA5A95B42043CLL)) & 255UL))))) | l_3546[5]) | 1UL), 0x4AB1F7F0L)) , l_3627) == &g_329), l_3583));
                }
            }
            for (g_714 = 0; (g_714 == 0); g_714 = safe_add_func_int64_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */(g_714, 7))
            { /* block id: 1764 */
                uint16_t *l_3638 = (void*)0;
                int32_t l_3652 = 0L;
                int32_t l_3655 = (-9L);
                int16_t l_3656 = (-1L);
                int32_t l_3657 = 0xAF65B911L;
                for (l_3103 = 0; (l_3103 >= 0); l_3103 -= 1)
                { /* block id: 1767 */
                    int32_t * const ***l_3649 = (void*)0;
                    int32_t *l_3653[4][4] = {{&l_3188[0],&l_3188[0],&l_3652,&l_3188[0]},{&l_3188[0],&l_3188[0],&l_3188[0],&l_3188[0]},{&l_3188[0],&l_3188[0],&l_3188[0],&l_3188[0]},{&l_3188[0],&l_3188[0],&l_3652,&l_3188[0]}};
                    int i, j;
                    for (g_259 = 3; (g_259 >= 0); g_259 -= 1)
                    { /* block id: 1770 */
                        int i, j;
                        if (g_1226[l_3103][l_3103])
                            break;
                        return g_72[g_259];
                    }
                    for (p_16 = 0; (p_16 <= 0); p_16 += 1)
                    { /* block id: 1776 */
                        const uint16_t **l_3639[5][6] = {{(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1]},{(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1]},{(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1]},{(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1]},{(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1],(void*)0,&g_970[9][2][1]}};
                        int32_t *****l_3645[7][10][3] = {{{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120}},{{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120}},{{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0}},{{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0}},{{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120}},{{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120}},{{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,(void*)0},{&l_3644,&l_3644,&l_3644},{&l_3644,&g_3120,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&l_3644,&g_3120},{&l_3644,&g_3120,&l_3644},{&l_3644,&g_3120,(void*)0}}};
                        uint16_t l_3650 = 65535UL;
                        int i, j, k;
                        (*g_2972) = (safe_mod_func_int16_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*157*//* ___SAFE__OP */((((0xB26CL || p_19) != (p_16 && (1L < p_19))) || (((safe_mod_func_int16_t_s_s_unsafe_macro/*158*//* ___SAFE__OP */(((*g_1763) = ((l_3638 != (l_3640 = (void*)0)) || (safe_sub_func_uint8_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */(((g_3646 = l_3644) != ((safe_div_func_uint32_t_u_u_unsafe_macro/*160*//* ___SAFE__OP */(0UL, (**g_3193))) , l_3649)), (*g_1849))))), l_3650)) , g_3651[0][3][4]) , (***g_2493))), p_18)), l_3652)) == (*p_20)), p_16));
                        (***g_1392) ^= 0x9D644265L;
                        if ((**g_3193))
                            continue;
                        return (*g_71);
                    }
                    ++l_3658;
                    (*g_2967) = (safe_lshift_func_int64_t_s_s_unsafe_macro/*161*//* ___SAFE__OP */(p_17, ((l_3663 = p_19) , ((**g_401) = (+(*g_1763))))));
                }
                return (***g_3646);
            }
        }
    }
    return (***l_3314);
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_14
 * writes: g_14
 */
static int64_t  func_25(int32_t  p_26, int32_t * p_27)
{ /* block id: 8 */
    int32_t *l_29 = &g_14;
    (*l_29) |= g_9;
    return g_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_195 g_253
 * writes: g_72 g_71 g_259 g_78 g_182 g_253
 */
static int32_t * func_40(const int64_t  p_41)
{ /* block id: 1449 */
    int32_t *l_2964 = &g_14;
    int32_t **l_2965 = &l_2964;
    int32_t *l_2966 = (void*)0;
    (*l_2965) = func_62(((*l_2965) = ((*g_71) = l_2964)));
    return l_2966;
}


/* ------------------------------------------ */
/* 
 * reads : g_100 g_71 g_14 g_253 g_123 g_1393 g_1394 g_7 g_1878 g_2492 g_2493 g_1848 g_1849 g_259 g_72 g_195 g_2761 g_402 g_31 g_2770 g_401 g_2552 g_1763 g_1392 g_1077 g_1078 g_2808 g_2825 g_2852 g_1226 g_114 g_2865 g_2585 g_2894 g_1239 g_1240 g_482 g_1773 g_2907 g_105 g_2919 g_2920 g_2209 g_1632 g_2933 g_182 g_2955 g_2963
 * writes: g_100 g_72 g_14 g_7 g_482 g_103 g_71 g_259 g_78 g_182 g_253 g_847.f2 g_123 g_105 g_2402.f2 g_1226 g_1078 g_2658.f2 g_1861 g_1234 g_195
 */
static uint16_t  func_42(const int64_t * p_43, int8_t  p_44, int32_t * p_45)
{ /* block id: 1320 */
    uint32_t l_2745 = 2UL;
    int32_t l_2748 = 0xA14B471DL;
    int32_t l_2749[1][8][7] = {{{(-1L),0xCBB53669L,(-1L),(-1L),0xCBB53669L,(-1L),(-1L)},{0L,0x8CADEE23L,(-1L),1L,6L,7L,0xCBB53669L},{7L,1L,0L,(-1L),0x5B9EDE06L,0xCBB53669L,0x5B9EDE06L},{6L,0x8CADEE23L,0x8CADEE23L,6L,0xCF07C610L,1L,(-1L)},{6L,0xCBB53669L,0x5FBEFFCCL,1L,3L,(-9L),(-1L)},{7L,0xCF07C610L,(-1L),(-1L),0L,(-1L),(-1L)},{0L,0L,6L,0L,(-9L),(-1L),0x5B9EDE06L},{(-1L),6L,0x5B9EDE06L,0x8CADEE23L,7L,(-9L),0xCBB53669L}}};
    uint8_t l_2753 = 255UL;
    int32_t *l_2756[5][7] = {{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714},{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714},{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714},{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714},{&g_714,&g_714,&g_714,&g_714,&g_714,&g_714,&g_714}};
    int64_t ****l_2832 = (void*)0;
    union U1 ****l_2875 = (void*)0;
    union U1 *****l_2874 = &l_2875;
    union U2 *l_2893 = &g_847;
    uint16_t l_2897 = 0x7B81L;
    int8_t **l_2902[8] = {&g_1849,&g_1849,&g_1849,&g_1849,&g_1849,&g_1849,&g_1849,&g_1849};
    uint64_t *l_2910 = &g_485[4][3][1];
    uint64_t **l_2913[10];
    uint64_t ***l_2912 = &l_2913[2];
    uint64_t ****l_2911 = &l_2912;
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_2913[i] = &l_2910;
    for (g_100 = (-29); (g_100 != 28); g_100++)
    { /* block id: 1323 */
        (*g_71) = p_45;
    }
    for (g_14 = 0; (g_14 <= 3); g_14 += 1)
    { /* block id: 1328 */
        int32_t *l_2750 = &g_123;
        int32_t *l_2751 = (void*)0;
        int32_t *l_2752[5];
        uint32_t l_2773 = 0xDB4D506AL;
        uint64_t **l_2778 = &g_114;
        uint32_t * const *l_2794[2][1][4] = {{{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0}}};
        uint32_t * const **l_2793 = &l_2794[0][0][2];
        struct S0 ****l_2871 = &g_2205;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_2752[i] = (void*)0;
        l_2745++;
        (**g_1393) &= (*p_45);
        ++l_2753;
        for (g_482 = 0; (g_482 <= 3); g_482 += 1)
        { /* block id: 1334 */
            int8_t l_2767 = 0L;
            int32_t l_2811 = (-1L);
            uint16_t l_2820[2];
            union U1 *l_2844 = &g_2249;
            int i;
            for (i = 0; i < 2; i++)
                l_2820[i] = 0x1ACEL;
            for (g_103 = 0; (g_103 <= 3); g_103 += 1)
            { /* block id: 1337 */
                int32_t l_2766[5][8][5] = {{{0x98261DEFL,0x98261DEFL,0xE401DE5AL,0L,2L},{0x5FCAA440L,0L,0x882CCFBAL,0x5FCAA440L,0x98261DEFL},{(-5L),(-7L),0x9348C973L,0L,(-7L)},{0x98261DEFL,0L,0xFB70CEABL,9L,9L},{0x882CCFBAL,0x98261DEFL,0x882CCFBAL,0x9348C973L,9L},{0L,0x5FCAA440L,7L,(-5L),(-7L)},{0L,(-5L),0L,0L,0x98261DEFL},{0L,0x98261DEFL,7L,(-7L),2L}},{{(-5L),0x882CCFBAL,0x882CCFBAL,(-5L),0L},{(-5L),0L,0xFB70CEABL,0L,0L},{0L,0L,0x9348C973L,7L,9L},{0L,0L,0x882CCFBAL,0L,7L},{0L,(-5L),0xE401DE5AL,(-5L),0L},{0x882CCFBAL,(-5L),0L,(-7L),0x98261DEFL},{0x98261DEFL,0L,7L,0L,0x65639527L},{(-5L),0L,0xB397F761L,(-5L),0x98261DEFL}},{{0x5FCAA440L,0L,0x9348C973L,0x9348C973L,0L},{0x98261DEFL,0x882CCFBAL,0x9348C973L,9L,7L},{0L,0x98261DEFL,0xB397F761L,0L,9L},{(-7L),(-5L),7L,0x5FCAA440L,0L},{0L,0x5FCAA440L,0L,0L,0L},{0x98261DEFL,0x98261DEFL,0xE401DE5AL,0L,2L},{0x5FCAA440L,0L,0x882CCFBAL,0x5FCAA440L,0x98261DEFL},{(-5L),(-7L),0x9348C973L,0L,(-7L)}},{{0x98261DEFL,0L,0xFB70CEABL,9L,9L},{0x882CCFBAL,0x98261DEFL,0x882CCFBAL,0x9348C973L,9L},{0L,0x5FCAA440L,7L,(-5L),(-7L)},{0L,(-5L),0L,0L,0x98261DEFL},{0L,0x98261DEFL,7L,(-7L),2L},{(-5L),0x882CCFBAL,0x882CCFBAL,(-5L),0L},{(-5L),0L,0xFB70CEABL,0L,0L},{0L,0L,0x9348C973L,7L,9L}},{{0L,0L,0x882CCFBAL,0L,7L},{0L,(-5L),0xE401DE5AL,(-5L),0L},{0x882CCFBAL,(-5L),0L,(-7L),0x98261DEFL},{0x98261DEFL,0L,7L,0L,0x65639527L},{(-5L),0L,0xB397F761L,(-5L),0x98261DEFL},{0x5FCAA440L,0L,0x9348C973L,0x9348C973L,0L},{0x65639527L,(-1L),0xE401DE5AL,0L,0L},{(-7L),0x65639527L,0L,7L,0L}}};
                uint32_t *****l_2809 = &g_1567;
                union U1 * const ****l_2869 = (void*)0;
                int i, j, k;
                if (((g_1878 , ((****g_2492) , func_62((*g_71)))) != l_2756[2][3]))
                { /* block id: 1338 */
                    int32_t l_2781 = 0x809ED593L;
                    uint32_t **l_2792 = &g_1240[0];
                    uint32_t ***l_2791[1];
                    int64_t *l_2810[2][5];
                    int8_t *l_2812 = &g_105;
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_2791[i] = &l_2792;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 5; j++)
                            l_2810[i][j] = &g_883[0][2][0];
                    }
                    if ((*p_45))
                        break;
                    for (g_847.f2 = 0; (g_847.f2 <= 3); g_847.f2 += 1)
                    { /* block id: 1342 */
                        uint64_t l_2758 = 0UL;
                        uint64_t **l_2774 = &g_114;
                        uint64_t ***l_2775 = &l_2774;
                        uint64_t **l_2777 = &g_114;
                        uint64_t ***l_2776 = &l_2777;
                        int32_t **l_2783[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        (*p_45) = (((p_44 = (+(l_2758 , (0xF97FL < (((safe_mod_func_int8_t_s_s_unsafe_macro/*162*//* ___SAFE__OP */((g_2761 , (safe_div_func_int8_t_s_s_unsafe_macro/*163*//* ___SAFE__OP */(((**g_1848) &= ((((p_44 >= 2UL) , (*l_2750)) > ((safe_add_func_int64_t_s_s_unsafe_macro/*164*//* ___SAFE__OP */(0x574E1E28C4015BA1LL, 18446744073709551606UL)) <= l_2766[2][5][1])) < 0x48L)), p_44))), 0x07L)) , (*g_402)) < (*g_402)))))) & l_2766[4][7][0]) < l_2767);
                        (***g_1392) = ((safe_div_func_int8_t_s_s_unsafe_macro/*165*//* ___SAFE__OP */((p_44 , ((((g_2770 , ((safe_mul_func_int64_t_s_s_unsafe_macro/*166*//* ___SAFE__OP */((**g_401), ((**g_2552) <= l_2773))) , (((*l_2776) = ((*l_2775) = l_2774)) == l_2778))) , (safe_lshift_func_int64_t_s_u_unsafe_macro/*167*//* ___SAFE__OP */((**g_401), p_44))) && p_44) && p_44)), l_2781)) > (***g_2493));
                        p_45 = func_62((((void*)0 == (*g_1077)) , p_45));
                        (**g_1393) = (safe_unary_minus_func_int32_t_s_unsafe_macro/*168*//* ___SAFE__OP */(3L));
                    }
                    (*l_2750) = ((safe_div_func_uint32_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*170*//* ___SAFE__OP */(1UL, (((safe_rshift_func_int32_t_s_u_unsafe_macro/*171*//* ___SAFE__OP */((l_2791[0] != l_2793), ((safe_mul_func_int32_t_s_s_unsafe_macro/*172*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */(0UL, 12)), 0x725F4968L)) || l_2767))) >= ((*l_2812) = ((!((l_2811 = ((safe_lshift_func_uint32_t_u_s_unsafe_macro/*174*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*175*//* ___SAFE__OP */(p_44, 1)), (***g_1392))) , ((l_2748 = ((safe_div_func_uint8_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*177*//* ___SAFE__OP */(((***g_2493) = ((g_2808 , (void*)0) == l_2809)), 5UL)) ^ p_44), p_44)) & p_44)) && 1L))) , l_2781)) != l_2781))) < (-3L)))), l_2781)) < p_44);
                    for (g_2402.f2 = 0; (g_2402.f2 <= 3); g_2402.f2 += 1)
                    { /* block id: 1359 */
                        uint16_t l_2813 = 0x7862L;
                        return l_2813;
                    }
                }
                else
                { /* block id: 1362 */
                    uint32_t l_2816 = 0xA83FFA3AL;
                    int32_t l_2819 = 0xF4BE6B77L;
                    int64_t ****l_2831 = &g_400[2];
                    int8_t l_2833 = 0x71L;
                    union U1 *l_2845 = &g_1767;
                    int32_t l_2855 = 0x2A215304L;
                    for (l_2745 = 1; (l_2745 <= 4); l_2745 += 1)
                    { /* block id: 1365 */
                        int32_t l_2814 = 0x3E05643EL;
                        int32_t l_2815 = 0x0B7463CEL;
                        int32_t l_2828[8][3] = {{0xB5370A10L,1L,0xB5370A10L},{0xA239B743L,(-1L),0xA239B743L},{0xB5370A10L,1L,0xB5370A10L},{0xA239B743L,(-1L),0xA239B743L},{0xB5370A10L,1L,0xB5370A10L},{0xA239B743L,(-1L),0xA239B743L},{0xB5370A10L,1L,0xB5370A10L},{0xA239B743L,(-1L),0xA239B743L}};
                        int64_t ****l_2830 = &g_400[0];
                        int64_t *****l_2829[8][10] = {{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830},{&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830,&l_2830}};
                        int i, j, k;
                        l_2816++;
                        ++l_2820[0];
                        (**g_1393) = (l_2766[4][0][1] != ((((g_2825 , (*g_1849)) > 255UL) >= l_2816) & ((*l_2750) = ((p_44 , ((p_44 > ((l_2828[3][2] && (((l_2831 = &g_400[0]) != l_2832) || l_2833)) < l_2749[0][4][5])) <= p_44)) < p_44))));
                    }
                    for (g_847.f2 = 0; (g_847.f2 <= 3); g_847.f2 += 1)
                    { /* block id: 1374 */
                        const uint32_t l_2853 = 0x81D23981L;
                        uint8_t *l_2854 = &g_1226[0][0];
                        (**g_1393) &= 0x494314B7L;
                        l_2855 &= (safe_div_func_int8_t_s_s_unsafe_macro/*178*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*179*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*180*//* ___SAFE__OP */((l_2816 <= (safe_unary_minus_func_int32_t_s_unsafe_macro/*181*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u_unsafe_macro/*182*//* ___SAFE__OP */(((((safe_unary_minus_func_int16_t_s_unsafe_macro/*183*//* ___SAFE__OP */(0x31B9L)) && ((*l_2750) = (((p_44 , l_2844) != l_2845) , ((safe_sub_func_int8_t_s_s_unsafe_macro/*184*//* ___SAFE__OP */(p_44, ((*l_2854) |= ((safe_sub_func_uint16_t_u_u_unsafe_macro/*185*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*186*//* ___SAFE__OP */((g_2852 , p_44), l_2766[4][6][0])), l_2853)) > p_44)))) || l_2853)))) , l_2819) >= 1UL), (*g_114))) , 0x46984841L)))), 2)), l_2753)), l_2853));
                    }
                }
                for (g_259 = 0; (g_259 <= 3); g_259 += 1)
                { /* block id: 1383 */
                    union U1 *l_2862 = &g_2249;
                    union U1 * const ****l_2870 = &g_2866;
                    struct S0 ****l_2873[7][9] = {{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]},{&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3],&g_2205,&g_2208[3],&g_2208[3]}};
                    struct S0 *****l_2872 = &l_2873[1][3];
                    uint8_t *l_2882 = &l_2753;
                    int32_t *l_2883 = &g_253;
                    int i, j;
                    if ((***g_1392))
                        break;
                    (*p_45) = (safe_add_func_int8_t_s_s_unsafe_macro/*187*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*188*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*189*//* ___SAFE__OP */((l_2862 == ((*g_2585) = ((safe_mod_func_uint16_t_u_u_unsafe_macro/*190*//* ___SAFE__OP */((p_44 , ((((**l_2778) = ((l_2870 = (l_2869 = g_2865)) == ((l_2871 == ((*l_2872) = l_2871)) , l_2874))) , ((*l_2882) = (safe_sub_func_uint64_t_u_u_unsafe_macro/*191*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*192*//* ___SAFE__OP */(l_2748, (safe_add_func_int32_t_s_s_unsafe_macro/*193*//* ___SAFE__OP */((**g_1393), p_44)))), 0x06CE59ED69AE7DD6LL)))) | (*g_1849))), l_2766[2][2][2])) , (void*)0))), 9L)), (-8L))), (***g_2493)));
                    p_45 = l_2883;
                }
                (**g_1393) = 0xF20A3502L;
            }
            for (g_2658.f2 = 0; (g_2658.f2 <= 3); g_2658.f2 += 1)
            { /* block id: 1398 */
                if ((l_2745 ^ (*p_45)))
                { /* block id: 1399 */
                    for (g_1861 = 3; (g_1861 >= 0); g_1861 -= 1)
                    { /* block id: 1402 */
                        (*g_71) = p_45;
                    }
                }
                else
                { /* block id: 1405 */
                    l_2844 = (*g_2585);
                }
                if (l_2820[1])
                    break;
            }
        }
    }
    if ((safe_lshift_func_int64_t_s_s_unsafe_macro/*194*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*195*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*196*//* ___SAFE__OP */(((**g_1239) = (safe_unary_minus_func_int16_t_s_unsafe_macro/*197*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*198*//* ___SAFE__OP */(((7L >= (((0UL || (****g_2492)) < ((((l_2893 == l_2893) | (*p_45)) <= (*p_45)) & 0x82573443F7A0CA9FLL)) , (g_2894 , l_2749[0][4][5]))) >= (-1L)), 3))))), l_2745)), (**g_1848))), (*g_402))))
    { /* block id: 1413 */
        uint16_t *l_2914 = &g_103;
        const int64_t l_2918 = 1L;
        for (g_482 = (-30); (g_482 <= 49); g_482 = safe_add_func_uint32_t_u_u_unsafe_macro/*199*//* ___SAFE__OP */(g_482, 4))
        { /* block id: 1416 */
            uint16_t l_2915 = 6UL;
            const uint8_t l_2916 = 0x7DL;
            int32_t l_2917[8] = {0xDA0D3863L,0xDA0D3863L,0xDA0D3863L,0xDA0D3863L,0xDA0D3863L,0xDA0D3863L,0xDA0D3863L,0xDA0D3863L};
            int i;
            --l_2897;
            l_2917[2] ^= ((((safe_add_func_int8_t_s_s_unsafe_macro/*200*//* ___SAFE__OP */(((**g_1848) = ((g_1773 , (((((**g_2492) != l_2902[6]) , (safe_rshift_func_uint16_t_u_u_unsafe_macro/*201*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_u_unsafe_macro/*202*//* ___SAFE__OP */((((((g_2907 , (((l_2910 == p_43) | ((**g_1239) = 4294967295UL)) && ((void*)0 == l_2911))) , &g_103) == l_2914) , l_2753) <= 8L), 1)) >= p_44), 7))) , 1L) | l_2915)) && l_2915)), p_44)) ^ 0xECE89F4D29C9FA64LL) & l_2915) , l_2916);
        }
        for (g_105 = 0; (g_105 <= 0); g_105 += 1)
        { /* block id: 1424 */
            const int64_t l_2921[7][5] = {{(-4L),(-4L),0xC002E0443B91729DLL,7L,0x20A72E9624121A99LL},{0x7666D58938826B9CLL,0x20A72E9624121A99LL,0xDC538013F8B86618LL,0xDC538013F8B86618LL,0x20A72E9624121A99LL},{0x20A72E9624121A99LL,1L,0x7666D58938826B9CLL,0x20A72E9624121A99LL,0xDC538013F8B86618LL},{7L,0x20A72E9624121A99LL,0xC002E0443B91729DLL,0x20A72E9624121A99LL,7L},{0x7666D58938826B9CLL,(-4L),1L,0xDC538013F8B86618LL,(-4L)},{7L,1L,1L,7L,0xDC538013F8B86618LL},{0x20A72E9624121A99LL,7L,0xC002E0443B91729DLL,(-4L),(-4L)}};
            int i, j;
            (*p_45) ^= ((l_2918 , (p_44 != (0xE1E2L >= 0x3E93L))) == ((g_2919 , g_2920) , 253UL));
            if (l_2921[0][4])
                continue;
        }
    }
    else
    { /* block id: 1428 */
        int32_t l_2938 = 6L;
        int32_t l_2947 = 0x3B86B390L;
        int32_t l_2949[10] = {0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L,0x8A94F055L};
        int i;
        (*g_1394) ^= (*p_45);
        (**g_1393) = 0L;
        for (p_44 = 0; (p_44 == (-5)); p_44--)
        { /* block id: 1433 */
            int16_t * const *l_2928 = &g_1763;
            int16_t * const **l_2927 = &l_2928;
            uint8_t *l_2943 = (void*)0;
            uint8_t *l_2944 = &g_1226[0][0];
            uint16_t *l_2945 = &g_182;
            uint16_t *l_2946[9] = {&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103};
            int32_t l_2948[5];
            struct S0 *l_2950[6][5][5] = {{{&g_2808,&g_1533,&g_2894,&g_1533,&g_2808},{&g_1248,&g_1533,&g_1315,&g_2894,&g_1533},{&g_1773,&g_2920,&g_1151,&g_1533,(void*)0},{&g_1151,&g_1773,&g_1248,&g_1533,&g_1533},{&g_1533,&g_1533,&g_2808,&g_1019[5],&g_2808}},{{&g_1533,&g_1533,&g_1248,&g_1151,&g_1019[4]},{&g_1533,&g_1019[5],&g_1773,&g_1019[2],&g_2894},{&g_1151,&g_1257,&g_1151,&g_1151,&g_2894},{&g_1773,&g_1019[5],&g_1533,&g_2920,(void*)0},{&g_1248,&g_1533,&g_1533,&g_1248,&g_1151}},{{&g_2808,&g_1533,&g_1533,&g_1257,&g_2894},{&g_1248,&g_1773,&g_1151,&g_1773,&g_1248},{&g_1151,&g_2920,&g_1773,&g_1257,&g_1257},{&g_1315,&g_1533,&g_1248,&g_1248,&g_1533},{&g_2894,&g_1533,&g_2808,&g_2920,&g_1257}},{{&g_1773,&g_1248,&g_1248,&g_1151,&g_1248},{&g_1257,&g_1019[5],&g_1151,&g_1019[2],&g_2894},{&g_1773,&g_1019[4],&g_1315,&g_1151,&g_1151},{&g_2894,(void*)0,&g_2894,&g_1019[5],(void*)0},{&g_1315,&g_1019[4],&g_1773,&g_1533,&g_2894}},{{&g_1151,&g_1019[5],&g_1257,&g_1533,&g_2894},{&g_1248,&g_1248,&g_1773,&g_2894,&g_1019[4]},{&g_2808,&g_1533,&g_2894,&g_1533,&g_2808},{&g_1248,&g_1533,&g_1315,&g_2894,&g_1533},{&g_1773,&g_2920,&g_1151,&g_1533,(void*)0}},{{&g_1151,&g_1773,&g_1248,&g_1533,&g_1533},{&g_1533,&g_1533,&g_2808,&g_1019[5],&g_2808},{&g_1533,&g_1151,&g_1533,&g_1533,&g_1248},{&g_2894,(void*)0,&g_2894,&g_2920,(void*)0},{&g_1533,&g_2894,&g_1533,&g_1773,&g_1019[4]}}};
            uint16_t l_2951 = 0x0892L;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_2948[i] = 1L;
            (*p_45) ^= (~(((safe_sub_func_int16_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(((**l_2928) = (l_2927 != &g_1762)), ((*g_2209) == ((safe_rshift_func_int16_t_s_u_unsafe_macro/*204*//* ___SAFE__OP */(((l_2949[3] = (safe_mul_func_uint64_t_u_u_unsafe_macro/*205*//* ___SAFE__OP */(((l_2947 ^= (((*l_2945) &= (g_2933[0] , (((safe_rshift_func_uint16_t_u_s_unsafe_macro/*206*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u_unsafe_macro/*207*//* ___SAFE__OP */(0xA44016085072C2FDLL, (l_2938 = 0x1D65A9AD75EF1D50LL))) , p_44), (p_44 | ((*l_2944) = (safe_mod_func_int16_t_s_s_unsafe_macro/*208*//* ___SAFE__OP */(((--(*g_114)) | 0x27FA608D3AD817F4LL), p_44)))))) > 0xA7B6D3B13FEF8F7BLL) & 0x7CEFL))) == p_44)) & l_2748), l_2948[2]))) > l_2748), p_44)) , l_2950[3][4][3])))) , (void*)0) != (void*)0));
            (**g_1393) = l_2951;
        }
    }
    (*g_1394) = (((safe_add_func_int16_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */((~l_2748), 65534UL)) >= (g_2955 , (((l_2749[0][6][5] = ((((*p_45) = 8L) || 0xA2DE4951L) != ((safe_mul_func_int64_t_s_s_unsafe_macro/*210*//* ___SAFE__OP */(l_2749[0][1][4], (0x826AL < (safe_sub_func_int64_t_s_s_unsafe_macro/*211*//* ___SAFE__OP */((((+(safe_mod_func_uint8_t_u_u_unsafe_macro/*212*//* ___SAFE__OP */((g_2963 , (l_2749[0][3][1] < p_44)), l_2745))) , 1UL) >= p_44), l_2897))))) | l_2897))) || (-1L)) && l_2897))) < l_2753);
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int64_t * func_46(uint32_t  p_47, uint16_t  p_48, int64_t  p_49)
{ /* block id: 399 */
    const union U2 *l_996 = &g_843;
    const union U2 **l_995[8][2] = {{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996},{&l_996,&l_996}};
    int32_t l_997 = 0x24D01115L;
    int32_t **l_1003[10] = {&g_72[2],&g_72[3],&g_72[3],&g_72[3],&g_72[2],&g_72[2],&g_72[3],&g_72[3],&g_72[3],&g_72[2]};
    const int32_t l_1058 = 1L;
    int32_t l_1061 = 1L;
    uint64_t l_1074 = 18446744073709551615UL;
    uint16_t * const l_1140 = &g_103;
    union U2 **l_1216 = (void*)0;
    uint32_t *l_1233 = &g_1234;
    int8_t *l_1250 = &g_259;
    uint32_t *l_1311[1];
    int64_t ***l_1362 = &g_401;
    uint32_t l_1366 = 0xA37DACABL;
    int64_t *** const l_1383 = &g_401;
    int16_t l_1416 = 0x4A1BL;
    int16_t l_1420 = 0x6BA7L;
    uint64_t l_1425 = 18446744073709551615UL;
    uint32_t ***l_1441 = &g_917;
    const int16_t l_1581 = 9L;
    uint64_t **l_1602[1][5][10] = {{{&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114},{&g_114,&g_114,(void*)0,&g_114,&g_114,(void*)0,&g_114,&g_114,(void*)0,&g_114},{&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114},{&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114,&g_114},{&g_114,&g_114,(void*)0,&g_114,&g_114,(void*)0,&g_114,&g_114,(void*)0,&g_114}}};
    uint8_t l_1628 = 0UL;
    int64_t *l_1655 = &g_529;
    uint64_t *l_1666[9] = {&l_1074,&l_1074,&l_1074,&l_1074,&l_1074,&l_1074,&l_1074,&l_1074,&l_1074};
    int64_t l_1670 = 0xCEA06C1EBFD98634LL;
    union U1 **l_1680 = &g_1078;
    int64_t l_1747[8][5][6] = {{{0xC269A7126B0B1B26LL,0x78E05DF999D7F6D4LL,(-1L),0L,0x3AAB2152DB41488ALL,(-4L)},{0x44B6314165AC3C73LL,(-1L),0x08FACD8629838DBCLL,7L,0xD8E8DA42A474E983LL,0L},{0x44B6314165AC3C73LL,0L,7L,0L,0x44B6314165AC3C73LL,0x3AAB2152DB41488ALL},{0xC269A7126B0B1B26LL,0x3AAB2152DB41488ALL,0xD8E8DA42A474E983LL,0x44B6314165AC3C73LL,0L,0x2DB77712609DDFB4LL},{0L,(-4L),0L,0x3AAB2152DB41488ALL,0x2DB77712609DDFB4LL,0x2DB77712609DDFB4LL}},{{0x917B7EEAA475FF4ALL,0xD8E8DA42A474E983LL,0xD8E8DA42A474E983LL,0x917B7EEAA475FF4ALL,0xA7D48A2793046846LL,0x3AAB2152DB41488ALL},{0x2DB77712609DDFB4LL,0L,7L,0x78E05DF999D7F6D4LL,0L,0L},{7L,0L,0x08FACD8629838DBCLL,(-4L),0L,(-4L)},{(-1L),0L,(-1L),0x765B9B8990FC0CA9LL,0xA7D48A2793046846LL,0L},{0x3AAB2152DB41488ALL,0xD8E8DA42A474E983LL,0x44B6314165AC3C73LL,0L,0x2DB77712609DDFB4LL,0xA7D48A2793046846LL}},{{0x78E05DF999D7F6D4LL,(-4L),0x765B9B8990FC0CA9LL,0L,0L,0x765B9B8990FC0CA9LL},{0x3AAB2152DB41488ALL,0x3AAB2152DB41488ALL,0L,0x765B9B8990FC0CA9LL,0x44B6314165AC3C73LL,(-1L)},{(-1L),0L,0x3AAB2152DB41488ALL,(-4L),0xD8E8DA42A474E983LL,0L},{7L,(-1L),0x3AAB2152DB41488ALL,0x78E05DF999D7F6D4LL,0x3AAB2152DB41488ALL,(-1L)},{0x2DB77712609DDFB4LL,0x78E05DF999D7F6D4LL,0L,0x917B7EEAA475FF4ALL,0xC269A7126B0B1B26LL,0x765B9B8990FC0CA9LL}},{{0x917B7EEAA475FF4ALL,0xC269A7126B0B1B26LL,0xC269A7126B0B1B26LL,7L,0L,0L},{0L,0xD8E8DA42A474E983LL,(-1L),(-1L),0xD8E8DA42A474E983LL,0L},{0xD8E8DA42A474E983LL,0x917B7EEAA475FF4ALL,0xA7D48A2793046846LL,0x3AAB2152DB41488ALL,7L,0L},{(-1L),0xA7D48A2793046846LL,0L,0x78E05DF999D7F6D4LL,0x08FACD8629838DBCLL,0x44B6314165AC3C73LL},{(-1L),0x3AAB2152DB41488ALL,0x78E05DF999D7F6D4LL,0x3AAB2152DB41488ALL,(-1L),7L}},{{0xD8E8DA42A474E983LL,7L,0x08FACD8629838DBCLL,(-1L),0x44B6314165AC3C73LL,0x765B9B8990FC0CA9LL},{0L,0L,0x44B6314165AC3C73LL,7L,0x765B9B8990FC0CA9LL,0x765B9B8990FC0CA9LL},{0x2DB77712609DDFB4LL,0x08FACD8629838DBCLL,0x08FACD8629838DBCLL,0x2DB77712609DDFB4LL,0L,7L},{0x765B9B8990FC0CA9LL,(-4L),0x78E05DF999D7F6D4LL,0x917B7EEAA475FF4ALL,0x3AAB2152DB41488ALL,0x44B6314165AC3C73LL},{0x78E05DF999D7F6D4LL,0L,0L,0L,0x3AAB2152DB41488ALL,0L}},{{0xA7D48A2793046846LL,(-4L),0xA7D48A2793046846LL,0xC269A7126B0B1B26LL,0L,0L},{7L,0x08FACD8629838DBCLL,(-1L),0x44B6314165AC3C73LL,0x765B9B8990FC0CA9LL,0L},{0x917B7EEAA475FF4ALL,0L,0xC269A7126B0B1B26LL,0x44B6314165AC3C73LL,0x44B6314165AC3C73LL,0xC269A7126B0B1B26LL},{7L,7L,(-4L),0xC269A7126B0B1B26LL,(-1L),0xA7D48A2793046846LL},{0xA7D48A2793046846LL,0x3AAB2152DB41488ALL,7L,0L,0x08FACD8629838DBCLL,(-4L)}},{{0x78E05DF999D7F6D4LL,0xA7D48A2793046846LL,7L,0x917B7EEAA475FF4ALL,7L,0xA7D48A2793046846LL},{0x765B9B8990FC0CA9LL,0x917B7EEAA475FF4ALL,(-4L),0x2DB77712609DDFB4LL,0xD8E8DA42A474E983LL,0xC269A7126B0B1B26LL},{0x2DB77712609DDFB4LL,0xD8E8DA42A474E983LL,0xC269A7126B0B1B26LL,7L,0L,0L},{0L,0xD8E8DA42A474E983LL,(-1L),(-1L),0xD8E8DA42A474E983LL,0L},{0xD8E8DA42A474E983LL,0x917B7EEAA475FF4ALL,0xA7D48A2793046846LL,0x3AAB2152DB41488ALL,7L,0L}},{{(-1L),0xA7D48A2793046846LL,0L,0x78E05DF999D7F6D4LL,0x08FACD8629838DBCLL,0x44B6314165AC3C73LL},{(-1L),0x3AAB2152DB41488ALL,0x78E05DF999D7F6D4LL,0x3AAB2152DB41488ALL,(-1L),7L},{0xD8E8DA42A474E983LL,7L,0x08FACD8629838DBCLL,(-1L),0x44B6314165AC3C73LL,0x765B9B8990FC0CA9LL},{0L,0L,0x44B6314165AC3C73LL,7L,0x765B9B8990FC0CA9LL,0x765B9B8990FC0CA9LL},{0x2DB77712609DDFB4LL,0x08FACD8629838DBCLL,0x08FACD8629838DBCLL,0x2DB77712609DDFB4LL,0L,7L}}};
    int8_t ***l_1826 = (void*)0;
    int8_t ****l_1825 = &l_1826;
    uint32_t l_1887 = 18446744073709551615UL;
    int32_t *l_1940 = &g_9;
    const int8_t l_1969 = (-3L);
    uint32_t l_1985 = 1UL;
    int32_t l_2026[1];
    int32_t l_2037 = 0L;
    volatile int32_t *l_2077 = &g_5[2];
    int32_t ***l_2087[8] = {&l_1003[2],&l_1003[2],&l_1003[2],&l_1003[2],&l_1003[2],&l_1003[2],&l_1003[2],&l_1003[2]};
    int32_t ****l_2086 = &l_2087[1];
    int32_t *****l_2085 = &l_2086;
    int32_t ***l_2091 = &l_1003[6];
    int32_t **** const l_2090 = &l_2091;
    int32_t **** const *l_2089[4];
    uint64_t *** const l_2099[5][6] = {{&l_1602[0][4][3],&l_1602[0][1][4],&l_1602[0][2][2],&l_1602[0][4][3],&l_1602[0][4][3],&l_1602[0][2][2]},{&l_1602[0][1][4],&l_1602[0][1][4],(void*)0,&l_1602[0][4][3],&l_1602[0][4][3],&l_1602[0][4][3]},{(void*)0,&l_1602[0][4][3],&l_1602[0][2][9],(void*)0,&l_1602[0][2][5],(void*)0},{&l_1602[0][2][9],(void*)0,&l_1602[0][2][9],&l_1602[0][0][3],&l_1602[0][1][4],&l_1602[0][4][3]},{(void*)0,&l_1602[0][0][3],(void*)0,&l_1602[0][0][8],&l_1602[0][2][2],&l_1602[0][2][2]}};
    uint64_t *** const *l_2098 = &l_2099[2][5];
    uint64_t *** const **l_2097[5];
    uint32_t **l_2155 = &l_1233;
    const uint8_t *l_2226 = &l_1628;
    const uint8_t * const *l_2225 = &l_2226;
    const uint8_t * const **l_2224[7] = {&l_2225,&l_2225,(void*)0,&l_2225,&l_2225,&l_2225,&l_2225};
    uint16_t l_2321 = 0xDC25L;
    uint64_t l_2423 = 5UL;
    struct S0 *l_2431 = &g_1151;
    struct S0 ****l_2439[10] = {&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3],&g_2208[3]};
    struct S0 *****l_2438 = &l_2439[1];
    uint8_t l_2453 = 0x4FL;
    int8_t l_2496 = 1L;
    int32_t l_2538 = 0L;
    int64_t * const l_2583 = &g_78;
    uint64_t l_2586[3];
    uint32_t ** const **l_2633 = &g_2632;
    int16_t l_2668 = 0xAA31L;
    int32_t *l_2741 = (void*)0;
    int64_t *l_2742 = &g_883[0][2][0];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1311[i] = &g_843.f2;
    for (i = 0; i < 1; i++)
        l_2026[i] = 0x6476C85DL;
    for (i = 0; i < 4; i++)
        l_2089[i] = &l_2090;
    for (i = 0; i < 5; i++)
        l_2097[i] = &l_2098;
    for (i = 0; i < 3; i++)
        l_2586[i] = 9UL;
    return l_2742;
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_195 g_253 g_2 g_14 g_402 g_31
 * writes: g_71 g_259 g_78 g_182 g_253 g_14
 */
static int64_t  func_50(int64_t * p_51, const int32_t * p_52)
{ /* block id: 23 */
    int32_t l_59 = 1L;
    int32_t l_972 = 0x8CAB933AL;
    int32_t *l_973 = (void*)0;
    int32_t *l_974 = (void*)0;
    int32_t *l_975 = &g_14;
    (*l_975) &= (safe_mod_func_uint32_t_u_u_unsafe_macro/*213*//* ___SAFE__OP */(func_57(l_59), (l_972 , 0x91372F0CL)));
    return (*g_402);
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_195 g_253 g_2
 * writes: g_71 g_259 g_78 g_182 g_253
 */
static uint32_t  func_57(uint16_t  p_58)
{ /* block id: 24 */
    int32_t *l_459 = &g_253;
    uint16_t l_474 = 1UL;
    uint64_t *l_484 = &g_485[5][0][1];
    uint64_t *l_486 = &g_485[0][2][0];
    int32_t l_494 = 0x981EA442L;
    uint64_t l_562 = 0xAE3548EE6D15641DLL;
    int64_t l_595 = (-9L);
    int32_t l_676[8];
    uint16_t l_689 = 0x4101L;
    int8_t l_715 = 9L;
    int64_t l_790 = 0xE295700857704CF3LL;
    int16_t * const l_796 = &g_613[6];
    int64_t l_818 = 0x6E4A93C1F3A62F01LL;
    int32_t * const *l_822 = &l_459;
    int32_t * const **l_821[6] = {&l_822,&l_822,&l_822,&l_822,&l_822,&l_822};
    int32_t * const ***l_820 = &l_821[3];
    int32_t * const ****l_819 = &l_820;
    uint8_t l_884 = 255UL;
    uint8_t *l_911 = &l_884;
    int8_t *l_921[1][10][8] = {{{&g_259,&g_259,&g_259,&g_259,&l_715,&l_715,&l_715,&g_259},{&g_259,&l_715,&g_259,(void*)0,&g_105,&g_105,(void*)0,&g_259},{&l_715,&l_715,&g_105,&l_715,&g_259,&l_715,&g_105,&l_715},{&l_715,&g_259,(void*)0,&g_105,&g_105,(void*)0,&g_259,&l_715},{&g_259,&g_259,&l_715,&l_715,&l_715,&g_259,&g_259,&g_259},{&g_259,&l_715,(void*)0,(void*)0,&l_715,&g_259,&g_105,&g_259},{&l_715,&g_259,&g_105,&g_259,&l_715,(void*)0,(void*)0,&l_715},{&g_259,&g_259,&g_259,&g_259,&l_715,&l_715,&l_715,&g_259},{&g_259,&l_715,&g_259,(void*)0,&g_105,&g_105,(void*)0,&g_259},{&l_715,&l_715,&g_105,&l_715,&g_259,&l_715,&g_105,&l_715}}};
    int8_t **l_920 = &l_921[0][5][4];
    int8_t ***l_919 = &l_920;
    int64_t l_934 = 0x045A54291571DACALL;
    int8_t l_935 = 0x9EL;
    uint64_t l_956[10] = {0xA18A98144434257BLL,0x75CE9181B6B32E1ALL,0UL,0x75CE9181B6B32E1ALL,0xA18A98144434257BLL,0xA18A98144434257BLL,0x75CE9181B6B32E1ALL,0UL,0x75CE9181B6B32E1ALL,0xA18A98144434257BLL};
    int16_t l_965 = 0L;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_676[i] = 0xB618877AL;
    for (p_58 = 0; (p_58 <= 4); ++p_58)
    { /* block id: 27 */
        int32_t **l_458 = (void*)0;
        int8_t *l_460[6][3];
        int32_t l_475 = 0xF4230E89L;
        int32_t l_671[8][10] = {{0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L},{0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L},{0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L},{0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L},{0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L},{0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L},{0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L,0xDF891158L,0x69D6CD46L,0x69D6CD46L},{0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L,0xDF891158L,0xF07EED6FL,0xDF891158L}};
        const uint64_t l_713 = 1UL;
        uint64_t l_732 = 18446744073709551612UL;
        const uint32_t *l_748 = &g_749;
        int64_t **l_764 = (void*)0;
        int16_t *l_829 = &g_613[6];
        uint8_t l_908 = 0UL;
        int8_t ***l_941 = (void*)0;
        int16_t l_954 = 0xC3D2L;
        int i, j;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 3; j++)
                l_460[i][j] = &g_105;
        }
        l_459 = func_62(&g_2);
    }
    return (*****l_819);
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_195 g_253
 * writes: g_71 g_259 g_78 g_182 g_253
 */
static int32_t * func_62(int32_t * p_63)
{ /* block id: 28 */
    int8_t *l_453 = &g_259;
    int64_t *l_454 = &g_78;
    int32_t l_456[2][2][6] = {{{0x11193537L,0x021EF5A1L,(-7L),0x021EF5A1L,(-7L),(-7L)},{0x021EF5A1L,(-7L),(-7L),0x021EF5A1L,(-7L),(-7L)}},{{0x021EF5A1L,(-7L),(-7L),0x021EF5A1L,(-7L),(-7L)},{0x021EF5A1L,(-7L),(-7L),0x021EF5A1L,(-7L),(-7L)}}};
    int32_t *l_457 = &g_253;
    int i, j, k;
    (*l_457) ^= ((safe_mul_func_int16_t_s_s_unsafe_macro/*214*//* ___SAFE__OP */((((*l_454) = (safe_unary_minus_func_int8_t_s_unsafe_macro/*215*//* ___SAFE__OP */(((*l_453) = func_69(&g_2))))) > (+l_456[0][1][2])), (g_182 = l_456[0][1][4]))) ^ (l_456[0][1][2] != l_456[1][1][5]));
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_195
 * writes: g_71
 */
static int8_t  func_69(int32_t * p_70)
{ /* block id: 29 */
    int32_t ***l_73[4][7][7] = {{{(void*)0,(void*)0,&g_71,(void*)0,&g_71,(void*)0,(void*)0},{&g_71,(void*)0,(void*)0,(void*)0,&g_71,(void*)0,&g_71},{&g_71,(void*)0,(void*)0,(void*)0,&g_71,(void*)0,(void*)0},{&g_71,&g_71,&g_71,(void*)0,(void*)0,(void*)0,&g_71},{&g_71,(void*)0,&g_71,&g_71,(void*)0,&g_71,&g_71},{&g_71,&g_71,(void*)0,&g_71,(void*)0,(void*)0,&g_71},{(void*)0,&g_71,(void*)0,(void*)0,&g_71,&g_71,&g_71}},{{(void*)0,&g_71,&g_71,(void*)0,&g_71,&g_71,(void*)0},{&g_71,(void*)0,&g_71,&g_71,&g_71,&g_71,&g_71},{&g_71,&g_71,&g_71,&g_71,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_71,(void*)0,(void*)0,&g_71,(void*)0},{(void*)0,(void*)0,&g_71,(void*)0,&g_71,(void*)0,(void*)0},{&g_71,(void*)0,(void*)0,(void*)0,&g_71,(void*)0,&g_71},{&g_71,(void*)0,(void*)0,(void*)0,&g_71,(void*)0,(void*)0}},{{&g_71,&g_71,&g_71,(void*)0,(void*)0,(void*)0,&g_71},{&g_71,(void*)0,&g_71,&g_71,(void*)0,&g_71,&g_71},{&g_71,&g_71,(void*)0,&g_71,(void*)0,(void*)0,&g_71},{(void*)0,&g_71,(void*)0,(void*)0,&g_71,&g_71,&g_71},{(void*)0,&g_71,&g_71,(void*)0,&g_71,&g_71,(void*)0},{&g_71,(void*)0,&g_71,&g_71,&g_71,&g_71,&g_71},{&g_71,&g_71,&g_71,&g_71,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_71,(void*)0,(void*)0,&g_71,(void*)0},{(void*)0,(void*)0,&g_71,(void*)0,&g_71,(void*)0,(void*)0},{&g_71,(void*)0,(void*)0,(void*)0,&g_71,(void*)0,&g_71},{&g_71,&g_71,&g_71,&g_71,(void*)0,&g_71,&g_71},{(void*)0,(void*)0,&g_71,(void*)0,&g_71,(void*)0,(void*)0},{(void*)0,&g_71,&g_71,&g_71,&g_71,(void*)0,(void*)0},{&g_71,&g_71,&g_71,(void*)0,&g_71,&g_71,(void*)0}}};
    int32_t ****l_74 = (void*)0;
    int32_t ***l_76 = &g_71;
    int32_t ****l_75 = &l_76;
    int64_t *l_77 = &g_78;
    int32_t l_81 = 1L;
    const int32_t *l_97 = &g_2;
    const int32_t **l_96 = &l_97;
    uint64_t *l_98 = (void*)0;
    uint64_t *l_99 = &g_100;
    int32_t *l_101 = &g_14;
    uint16_t *l_102 = &g_103;
    int8_t *l_104 = &g_105;
    int32_t l_148 = (-1L);
    uint64_t l_191 = 0UL;
    int16_t l_203 = 5L;
    uint8_t l_272 = 255UL;
    int8_t l_364 = 0x45L;
    uint64_t l_366 = 6UL;
    uint16_t l_406 = 65535UL;
    uint8_t l_445[4];
    int8_t * const  volatile *l_449 = &l_104;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_445[i] = 0x6EL;
    g_71 = g_71;
    return g_195;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    transparent_crc(g_202, "g_202", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_235[i], "g_235[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_253, "g_253", print_hash_value);
    transparent_crc(g_259, "g_259", print_hash_value);
    transparent_crc(g_482, "g_482", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_485[i][j][k], "g_485[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_529, "g_529", print_hash_value);
    transparent_crc(g_611, "g_611", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_613[i], "g_613[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_714, "g_714", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    transparent_crc(g_843.f0, "g_843.f0", print_hash_value);
    transparent_crc(g_847.f0, "g_847.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_883[i][j][k], "g_883[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_971[i][j], "g_971[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_992[i].f0, "g_992[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1008.f0, "g_1008.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1019[i].f0, "g_1019[i].f0", print_hash_value);
        transparent_crc(g_1019[i].f1, "g_1019[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1051, "g_1051", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1052[i], "g_1052[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1076.f0, "g_1076.f0", print_hash_value);
    transparent_crc(g_1114, "g_1114", print_hash_value);
    transparent_crc(g_1151.f0, "g_1151.f0", print_hash_value);
    transparent_crc(g_1151.f1, "g_1151.f1", print_hash_value);
    transparent_crc(g_1196.f0, "g_1196.f0", print_hash_value);
    transparent_crc(g_1196.f1, "g_1196.f1", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1226[i][j], "g_1226[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1234, "g_1234", print_hash_value);
    transparent_crc(g_1248.f0, "g_1248.f0", print_hash_value);
    transparent_crc(g_1248.f1, "g_1248.f1", print_hash_value);
    transparent_crc(g_1257.f0, "g_1257.f0", print_hash_value);
    transparent_crc(g_1257.f1, "g_1257.f1", print_hash_value);
    transparent_crc(g_1315.f0, "g_1315.f0", print_hash_value);
    transparent_crc(g_1315.f1, "g_1315.f1", print_hash_value);
    transparent_crc(g_1386.f0, "g_1386.f0", print_hash_value);
    transparent_crc(g_1533.f0, "g_1533.f0", print_hash_value);
    transparent_crc(g_1533.f1, "g_1533.f1", print_hash_value);
    transparent_crc(g_1591.f0, "g_1591.f0", print_hash_value);
    transparent_crc(g_1609.f0, "g_1609.f0", print_hash_value);
    transparent_crc(g_1627.f0, "g_1627.f0", print_hash_value);
    transparent_crc(g_1635.f0, "g_1635.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_1656[i][j][k].f0, "g_1656[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1707.f0, "g_1707.f0", print_hash_value);
    transparent_crc(g_1767.f0, "g_1767.f0", print_hash_value);
    transparent_crc(g_1773.f0, "g_1773.f0", print_hash_value);
    transparent_crc(g_1773.f1, "g_1773.f1", print_hash_value);
    transparent_crc(g_1823.f0, "g_1823.f0", print_hash_value);
    transparent_crc(g_1861, "g_1861", print_hash_value);
    transparent_crc(g_1878.f0, "g_1878.f0", print_hash_value);
    transparent_crc(g_1878.f1, "g_1878.f1", print_hash_value);
    transparent_crc(g_1882.f0, "g_1882.f0", print_hash_value);
    transparent_crc(g_1903, "g_1903", print_hash_value);
    transparent_crc(g_1931.f0, "g_1931.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1999[i].f0, "g_1999[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2045[i].f0, "g_2045[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2110.f0, "g_2110.f0", print_hash_value);
    transparent_crc(g_2249.f0, "g_2249.f0", print_hash_value);
    transparent_crc(g_2337.f0, "g_2337.f0", print_hash_value);
    transparent_crc(g_2346, "g_2346", print_hash_value);
    transparent_crc(g_2375.f0, "g_2375.f0", print_hash_value);
    transparent_crc(g_2375.f1, "g_2375.f1", print_hash_value);
    transparent_crc(g_2402.f0, "g_2402.f0", print_hash_value);
    transparent_crc(g_2474, "g_2474", print_hash_value);
    transparent_crc(g_2475, "g_2475", print_hash_value);
    transparent_crc(g_2658.f0, "g_2658.f0", print_hash_value);
    transparent_crc(g_2761.f0, "g_2761.f0", print_hash_value);
    transparent_crc(g_2770.f0, "g_2770.f0", print_hash_value);
    transparent_crc(g_2808.f0, "g_2808.f0", print_hash_value);
    transparent_crc(g_2808.f1, "g_2808.f1", print_hash_value);
    transparent_crc(g_2825.f0, "g_2825.f0", print_hash_value);
    transparent_crc(g_2852.f0, "g_2852.f0", print_hash_value);
    transparent_crc(g_2894.f0, "g_2894.f0", print_hash_value);
    transparent_crc(g_2894.f1, "g_2894.f1", print_hash_value);
    transparent_crc(g_2907.f0, "g_2907.f0", print_hash_value);
    transparent_crc(g_2919.f0, "g_2919.f0", print_hash_value);
    transparent_crc(g_2920.f0, "g_2920.f0", print_hash_value);
    transparent_crc(g_2920.f1, "g_2920.f1", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2933[i].f0, "g_2933[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2955.f0, "g_2955.f0", print_hash_value);
    transparent_crc(g_2963.f0, "g_2963.f0", print_hash_value);
    transparent_crc(g_3016.f0, "g_3016.f0", print_hash_value);
    transparent_crc(g_3016.f1, "g_3016.f1", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_3050[i][j][k].f0, "g_3050[i][j][k].f0", print_hash_value);
                transparent_crc(g_3050[i][j][k].f1, "g_3050[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3067.f0, "g_3067.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3073[i].f0, "g_3073[i].f0", print_hash_value);
        transparent_crc(g_3073[i].f1, "g_3073[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_3083[i].f0, "g_3083[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3108, "g_3108", print_hash_value);
    transparent_crc(g_3127, "g_3127", print_hash_value);
    transparent_crc(g_3128.f0, "g_3128.f0", print_hash_value);
    transparent_crc(g_3145.f0, "g_3145.f0", print_hash_value);
    transparent_crc(g_3145.f1, "g_3145.f1", print_hash_value);
    transparent_crc(g_3172, "g_3172", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3236[i][j][k].f0, "g_3236[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3260.f0, "g_3260.f0", print_hash_value);
    transparent_crc(g_3261.f0, "g_3261.f0", print_hash_value);
    transparent_crc(g_3261.f1, "g_3261.f1", print_hash_value);
    transparent_crc(g_3308, "g_3308", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3324[i].f0, "g_3324[i].f0", print_hash_value);
        transparent_crc(g_3324[i].f1, "g_3324[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3328, "g_3328", print_hash_value);
    transparent_crc(g_3333.f0, "g_3333.f0", print_hash_value);
    transparent_crc(g_3354.f0, "g_3354.f0", print_hash_value);
    transparent_crc(g_3354.f1, "g_3354.f1", print_hash_value);
    transparent_crc(g_3403.f0, "g_3403.f0", print_hash_value);
    transparent_crc(g_3459, "g_3459", print_hash_value);
    transparent_crc(g_3586, "g_3586", print_hash_value);
    transparent_crc(g_3601.f0, "g_3601.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_3623[i][j].f0, "g_3623[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3641, "g_3641", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_3651[i][j][k].f0, "g_3651[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_3654[i][j][k], "g_3654[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3671.f0, "g_3671.f0", print_hash_value);
    transparent_crc(g_3671.f1, "g_3671.f1", print_hash_value);
    transparent_crc(g_3677.f0, "g_3677.f0", print_hash_value);
    transparent_crc(g_3712, "g_3712", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1067
   depth: 1, occurrence: 19
XXX total union variables: 39

XXX non-zero bitfields defined in structs: 4
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 3
XXX structs with bitfields in the program: 127
breakdown:
   indirect level: 0, occurrence: 58
   indirect level: 1, occurrence: 27
   indirect level: 2, occurrence: 18
   indirect level: 3, occurrence: 5
   indirect level: 4, occurrence: 9
   indirect level: 5, occurrence: 10
XXX full-bitfields structs in the program: 19
breakdown:
   indirect level: 0, occurrence: 19
XXX times a bitfields struct's address is taken: 75
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 80
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 4

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 160
   depth: 2, occurrence: 44
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 18, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 731

XXX times a variable address is taken: 1562
XXX times a pointer is dereferenced on RHS: 460
breakdown:
   depth: 1, occurrence: 303
   depth: 2, occurrence: 109
   depth: 3, occurrence: 30
   depth: 4, occurrence: 17
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 469
breakdown:
   depth: 1, occurrence: 355
   depth: 2, occurrence: 81
   depth: 3, occurrence: 31
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 61
XXX times a pointer is compared with address of another variable: 30
XXX times a pointer is compared with another pointer: 28
XXX times a pointer is qualified to be dereferenced: 12515

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1886
   level: 2, occurrence: 693
   level: 3, occurrence: 299
   level: 4, occurrence: 179
   level: 5, occurrence: 66
XXX number of pointers point to pointers: 403
XXX number of pointers point to scalars: 295
XXX number of pointers point to structs: 6
XXX percent of pointers has null in alias set: 29.7
XXX average alias set size: 1.47

XXX times a non-volatile is read: 3084
XXX times a non-volatile is write: 1523
XXX times a volatile is read: 123
XXX    times read thru a pointer: 65
XXX times a volatile is write: 108
XXX    times written thru a pointer: 96
XXX times a volatile is available for access: 6.13e+03
XXX percentage of non-volatile access: 95.2

XXX forward jumps: 1
XXX backward jumps: 14

XXX stmts: 166
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 27
   depth: 1, occurrence: 25
   depth: 2, occurrence: 25
   depth: 3, occurrence: 19
   depth: 4, occurrence: 28
   depth: 5, occurrence: 42

XXX percentage a fresh-made variable is used: 18.8
XXX percentage an existing variable is used: 81.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

