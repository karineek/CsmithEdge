#include <stdio.h>
#include <inttypes.h>

static int32_t a = 1L;
static int32_t b = 0;
static int64_t c = 0L;
static int64_t * volatile d = &c;

int main (int argc, char* argv[])
{
    for (b = 0; b >= 0; b--)
    {
        // Always true, so the loop is broken on its first iteration
        if (a) {
            printf("breaking\n");
            break;
        }
        // Unreachable, since the loop is already broken
        uint16_t A[1][2];
        int j;
        for (j = 0; j < 2; j++)
            A[0][j] = 0;
        // This access would be out of bounds, but it is unreachable
        A[13218][231] && *d;
    }
    printf("done\n");
    return 0;
}
