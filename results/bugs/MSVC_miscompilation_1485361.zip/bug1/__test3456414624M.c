/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 4ed4bbe
 * Options:   --no-paranoid --null-ptr-deref-prob 0.089 --dangling-ptr-deref-prob 0 --bitfields --packed-struct --annotated-arith-wrappers --relax-anlayses-conditions --relax-anlayses-prob /home/user42/git/RRS_EXPR/scripts/WA-v2-standalone/seedsProbs/probs_WeakenSafeAnalyse_test.txt --relax-anlayses-seed 3456414624 --bitfields --packed-struct --seed 3456414624
 * Seed:      3456414624
 */

#include "csmith.h"


static long __undefined;

/* Try to pick different op 0*/
/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   const uint64_t  f0;
   uint64_t  f1;
   unsigned f2 : 19;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S1 {
   const uint8_t  f0;
   int64_t  f1;
   volatile int32_t  f2;
   volatile uint32_t  f3;
   int64_t  f4;
   volatile int16_t  f5;
   const int32_t  f6;
   int16_t  f7;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S2 {
   const signed f0 : 31;
   unsigned f1 : 27;
   volatile unsigned f2 : 7;
   unsigned f3 : 2;
   signed f4 : 22;
   signed f5 : 20;
   signed f6 : 5;
   volatile signed f7 : 29;
   signed f8 : 9;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S3 {
   unsigned f0 : 6;
   signed f1 : 14;
   signed f2 : 3;
   const unsigned f3 : 20;
   signed f4 : 18;
   const signed f5 : 24;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 1L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4[1] = {0xA1245C81L};
static volatile int32_t g_5 = 0x7E4A9061L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6[8][6][5] = {{{(-1L),0xABEBF3B8L,0x1D2DAFFAL,(-9L),(-1L)},{0xF5452FA8L,(-1L),1L,0x440271DBL,1L},{(-9L),0xBD2F23D3L,0x813BF58AL,(-9L),4L},{1L,0x383C67EEL,0x8BBE58EDL,(-1L),(-1L)},{0L,(-9L),0L,2L,(-1L)},{1L,0xF5452FA8L,0x440271DBL,0x383C67EEL,0xF5452FA8L}},{{(-9L),0xABEBF3B8L,0x94D0F4F2L,0xABEBF3B8L,(-9L)},{0xF5452FA8L,0x383C67EEL,0x440271DBL,0xF5452FA8L,1L},{(-1L),2L,0L,(-9L),0L},{0xF5452FA8L,0xF5452FA8L,(-10L),0x440271DBL,0x98CBDB62L},{0x44D99649L,0xBD2F23D3L,0x94D0F4F2L,0xEA4C5706L,4L},{0x98CBDB62L,(-1L),0x8BBE58EDL,0xF5452FA8L,1L}},{{0L,0xBD2F23D3L,(-1L),2L,0L},{(-1L),0xF5452FA8L,(-1L),(-1L),0xF5452FA8L},{4L,1L,0x94D0F4F2L,2L,0x44D99649L},{0xF5452FA8L,0x440271DBL,0x383C67EEL,0xF5452FA8L,0x98CBDB62L},{0x1D2DAFFAL,2L,0x1D2DAFFAL,0xEA4C5706L,0L},{0xF5452FA8L,1L,0x8BBE58EDL,0x440271DBL,(-1L)}},{{4L,0xBD2F23D3L,0xD23C5AD0L,0xBD2F23D3L,4L},{(-1L),0x440271DBL,0x8BBE58EDL,1L,0xF5452FA8L},{0L,0xEA4C5706L,0x1D2DAFFAL,2L,0x1D2DAFFAL},{0x98CBDB62L,0xF5452FA8L,0x383C67EEL,0x440271DBL,0xF5452FA8L},{0x44D99649L,2L,0x94D0F4F2L,1L,4L},{0xF5452FA8L,(-1L),(-1L),0xF5452FA8L,(-1L)}},{{0L,2L,(-1L),0xBD2F23D3L,0L},{1L,0xF5452FA8L,0x8BBE58EDL,(-1L),0x98CBDB62L},{4L,0xEA4C5706L,0x94D0F4F2L,0xBD2F23D3L,0x44D99649L},{0x98CBDB62L,0x440271DBL,(-10L),0xF5452FA8L,0xF5452FA8L},{0x1D2DAFFAL,0xBD2F23D3L,0x1D2DAFFAL,1L,0L},{0x98CBDB62L,1L,(-1L),0x440271DBL,1L}},{{4L,2L,0xD23C5AD0L,2L,4L},{1L,0x440271DBL,(-1L),1L,0x98CBDB62L},{0L,1L,0x1D2DAFFAL,0xBD2F23D3L,0x1D2DAFFAL},{0xF5452FA8L,0xF5452FA8L,(-10L),0x440271DBL,0x98CBDB62L},{0x44D99649L,0xBD2F23D3L,0x94D0F4F2L,0xEA4C5706L,4L},{0x98CBDB62L,(-1L),0x8BBE58EDL,0xF5452FA8L,1L}},{{0L,0xBD2F23D3L,(-1L),2L,0L},{(-1L),0xF5452FA8L,(-1L),(-1L),0xF5452FA8L},{4L,1L,0x94D0F4F2L,2L,0x44D99649L},{0xF5452FA8L,0x440271DBL,0x383C67EEL,0xF5452FA8L,0x98CBDB62L},{0x1D2DAFFAL,2L,0x1D2DAFFAL,0xEA4C5706L,0L},{0xF5452FA8L,1L,0x8BBE58EDL,0x440271DBL,(-1L)}},{{4L,0xBD2F23D3L,0xD23C5AD0L,0xBD2F23D3L,4L},{(-1L),0x440271DBL,0x8BBE58EDL,1L,0xF5452FA8L},{0L,0xEA4C5706L,0x1D2DAFFAL,2L,0x1D2DAFFAL},{0x98CBDB62L,0xF5452FA8L,0x383C67EEL,0x440271DBL,0xF5452FA8L},{0x44D99649L,2L,0x94D0F4F2L,1L,4L},{0xF5452FA8L,0x383C67EEL,0x383C67EEL,1L,1L}}};
static volatile int32_t g_7 = 0x33B839BFL;/* VOLATILE GLOBAL g_7 */
static int32_t g_8 = 0x81606DC0L;
static int32_t g_15 = 0L;
static uint64_t g_25 = 0xF6B4AB19F88DD0BBLL;
static uint16_t g_36 = 0x0B54L;
static int16_t g_41[7] = {0xFB48L,0xFB48L,0L,0xFB48L,0xFB48L,0L,0xFB48L};
static int32_t g_44 = 0xFC39FA23L;
static int32_t g_46 = (-1L);
static int64_t g_64[4][5] = {{0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL},{(-6L),0xAE3B8AEA20016C6ALL,(-6L),0xAE3B8AEA20016C6ALL,(-6L)},{0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL,0x2417F16C3B14A51ELL},{(-6L),0xAE3B8AEA20016C6ALL,(-6L),0xAE3B8AEA20016C6ALL,(-6L)}};
static uint32_t g_65[8][7] = {{0x79270D6EL,0xDC3D349FL,0x1E4559F9L,2UL,0xD2487603L,7UL,4294967291UL},{4294967295UL,0x5F43E010L,7UL,0x1E4559F9L,7UL,0x5F43E010L,4294967295UL},{0xDEE2C543L,4294967295UL,3UL,0x1E4559F9L,4294967295UL,4294967291UL,2UL},{5UL,0x33A12938L,0x41A018BFL,2UL,0xDEE2C543L,0xD2487603L,0xD2487603L},{0x41A018BFL,0x4455642EL,3UL,0x4455642EL,0x41A018BFL,0x79270D6EL,0xDC3D349FL},{0xDC3D349FL,0x4455642EL,7UL,4294967295UL,0x1E4559F9L,0xB2EF76CAL,0xDEE2C543L},{0x4455642EL,0x33A12938L,0x1E4559F9L,0x0774A768L,3UL,3UL,0x0774A768L},{0xDC3D349FL,4294967295UL,0xDC3D349FL,3UL,4294967291UL,0x33A12938L,0x0774A768L}};
static int64_t g_97 = 0x157731B4BD6B4620LL;
static int32_t g_157 = 0xEADEB179L;
static int64_t g_158 = 0x1E180988709DC6ADLL;
static uint64_t g_159 = 0x23608D486CFEE316LL;
static int32_t g_172 = 0x104350C7L;
static uint16_t g_173 = 0xB7D1L;
static volatile int64_t g_204 = 9L;/* VOLATILE GLOBAL g_204 */
static volatile int64_t * volatile g_203 = &g_204;/* VOLATILE GLOBAL g_203 */
static volatile int64_t * const  volatile *g_202 = &g_203;
static volatile int32_t g_244 = 0x00657D72L;/* VOLATILE GLOBAL g_244 */
static volatile int32_t *g_243 = &g_244;
static volatile int32_t ** const g_242 = &g_243;
static int64_t ***g_255 = (void*)0;
static uint32_t *g_289[6] = {&g_65[5][3],&g_65[2][4],&g_65[5][3],&g_65[5][3],&g_65[2][4],&g_65[5][3]};
static struct S3 g_292 = {0,-101,1,588,-236,-3266};
static struct S3 g_297 = {1,-81,-0,832,-323,2215};
static struct S3 *g_296 = &g_297;
static uint32_t g_308 = 0x032CACBCL;
static int64_t g_341 = 0x5D16D59C3A3E59FFLL;
static uint8_t g_342 = 255UL;
static volatile uint8_t g_351 = 0x09L;/* VOLATILE GLOBAL g_351 */
static volatile uint8_t *g_350 = &g_351;
static int16_t g_354 = 6L;
static uint64_t g_356 = 0xE73530DF48D24F35LL;
static volatile uint16_t g_447 = 0UL;/* VOLATILE GLOBAL g_447 */
static volatile uint16_t *g_446 = &g_447;
static volatile uint16_t **g_445 = &g_446;
static int32_t g_453 = 1L;
static int64_t g_455[6] = {0x2476F20157C39720LL,0x2476F20157C39720LL,0x2476F20157C39720LL,0x2476F20157C39720LL,0x2476F20157C39720LL,0x2476F20157C39720LL};
static int8_t g_456 = 0xFFL;
static int32_t g_457 = 0x2CE0D3E0L;
static uint32_t g_460 = 4294967287UL;
static struct S0 g_464 = {0xF0EC19EDEA58A81ELL,0x9874BAE41FBABFE3LL,233};
static uint32_t g_489 = 0x8E457CF4L;
static int8_t g_500 = 0xDBL;
static const struct S1 g_555 = {0xD4L,0x7541984138294204LL,-10L,0x56E0336BL,-3L,0x520BL,0L,-1L};/* VOLATILE GLOBAL g_555 */
static const struct S1 *g_557 = (void*)0;
static int32_t *g_570[8][8] = {{&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0},{(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172},{(void*)0,(void*)0,&g_46,(void*)0,(void*)0,&g_46,(void*)0,(void*)0},{&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0},{(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172},{(void*)0,(void*)0,&g_46,(void*)0,(void*)0,&g_46,(void*)0,(void*)0},{&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0},{(void*)0,&g_172,&g_172,(void*)0,&g_172,&g_172,(void*)0,&g_172}};
static struct S1 g_599 = {1UL,1L,0x00E99619L,1UL,4L,-10L,-2L,0x1D20L};/* VOLATILE GLOBAL g_599 */
static uint32_t g_604 = 4UL;
static uint16_t g_630 = 0x8BEDL;
static int64_t g_631[8][5][6] = {{{1L,1L,(-1L),0L,0xBDD9A00CFA1DD413LL,0xBCDDBD754FCFA586LL},{1L,(-7L),(-1L),0x0DCA0CD34B697FD7LL,0x3844192F88AC64D9LL,0x57ED45CCB6C176A3LL},{(-8L),1L,0xBCDDBD754FCFA586LL,(-1L),1L,(-2L)},{(-1L),1L,(-2L),(-7L),(-7L),(-2L)},{1L,1L,0xBCDDBD754FCFA586LL,0x0D599FB7633464F2LL,0x7BE9A0DE9C7ACE04LL,(-7L)}},{{0x74A96FD5C8B92581LL,(-2L),0xBDD9A00CFA1DD413LL,0xB58EB3C0CCDA5011LL,0x732C7BF072493068LL,0xDFC5B847C9DF72A4LL},{0xD15548A5A95F6E19LL,0x74A96FD5C8B92581LL,0xBDD9A00CFA1DD413LL,0xB463BAD36AAE4366LL,0x2FC2EDE97DFF8641LL,(-7L)},{(-6L),0xB463BAD36AAE4366LL,0xDFC5B847C9DF72A4LL,0L,(-2L),0L},{0L,(-2L),0L,0x7BE9A0DE9C7ACE04LL,0x74A96FD5C8B92581LL,0L},{0xD15548A5A95F6E19LL,2L,0xDFC5B847C9DF72A4LL,0xAAB7B0FEFB643081LL,0xB463BAD36AAE4366LL,(-7L)}},{{0xB463BAD36AAE4366LL,0x11FBCB5F8A5F3DD5LL,0xBDD9A00CFA1DD413LL,0x0D599FB7633464F2LL,(-2L),0xDFC5B847C9DF72A4LL},{2L,0x7BE9A0DE9C7ACE04LL,0xBDD9A00CFA1DD413LL,0x7BE9A0DE9C7ACE04LL,2L,(-7L)},{3L,0x74A96FD5C8B92581LL,0xDFC5B847C9DF72A4LL,(-6L),0x11FBCB5F8A5F3DD5LL,0L},{(-6L),0x11FBCB5F8A5F3DD5LL,0L,0x74A96FD5C8B92581LL,0x7BE9A0DE9C7ACE04LL,0L},{2L,0xD15548A5A95F6E19LL,0xDFC5B847C9DF72A4LL,0xB58EB3C0CCDA5011LL,0x74A96FD5C8B92581LL,(-7L)}},{{0x7BE9A0DE9C7ACE04LL,0x732C7BF072493068LL,0xBDD9A00CFA1DD413LL,0xAAB7B0FEFB643081LL,0x11FBCB5F8A5F3DD5LL,0xDFC5B847C9DF72A4LL},{0x2FC2EDE97DFF8641LL,0xB463BAD36AAE4366LL,0xBDD9A00CFA1DD413LL,0x74A96FD5C8B92581LL,0xD15548A5A95F6E19LL,(-7L)},{0L,0x7BE9A0DE9C7ACE04LL,0xDFC5B847C9DF72A4LL,3L,0x732C7BF072493068LL,0L},{3L,0x732C7BF072493068LL,0L,0xB463BAD36AAE4366LL,0xB463BAD36AAE4366LL,0L},{0x2FC2EDE97DFF8641LL,0x2FC2EDE97DFF8641LL,0xDFC5B847C9DF72A4LL,0x0D599FB7633464F2LL,0x7BE9A0DE9C7ACE04LL,(-7L)}},{{0x74A96FD5C8B92581LL,(-2L),0xBDD9A00CFA1DD413LL,0xB58EB3C0CCDA5011LL,0x732C7BF072493068LL,0xDFC5B847C9DF72A4LL},{0xD15548A5A95F6E19LL,0x74A96FD5C8B92581LL,0xBDD9A00CFA1DD413LL,0xB463BAD36AAE4366LL,0x2FC2EDE97DFF8641LL,(-7L)},{(-6L),0xB463BAD36AAE4366LL,0xDFC5B847C9DF72A4LL,0L,(-2L),0L},{0L,(-2L),0L,0x7BE9A0DE9C7ACE04LL,0x74A96FD5C8B92581LL,0L},{0xD15548A5A95F6E19LL,2L,0xDFC5B847C9DF72A4LL,0xAAB7B0FEFB643081LL,0xB463BAD36AAE4366LL,(-7L)}},{{0xB463BAD36AAE4366LL,0x11FBCB5F8A5F3DD5LL,0xBDD9A00CFA1DD413LL,0x0D599FB7633464F2LL,(-2L),0xDFC5B847C9DF72A4LL},{2L,0x7BE9A0DE9C7ACE04LL,0xBDD9A00CFA1DD413LL,0x7BE9A0DE9C7ACE04LL,2L,(-7L)},{3L,0x74A96FD5C8B92581LL,0xDFC5B847C9DF72A4LL,(-6L),0x11FBCB5F8A5F3DD5LL,0L},{(-6L),0x11FBCB5F8A5F3DD5LL,0L,0x74A96FD5C8B92581LL,0x7BE9A0DE9C7ACE04LL,0L},{2L,0xD15548A5A95F6E19LL,0xDFC5B847C9DF72A4LL,0xB58EB3C0CCDA5011LL,0x74A96FD5C8B92581LL,(-7L)}},{{0x7BE9A0DE9C7ACE04LL,0x732C7BF072493068LL,0xBDD9A00CFA1DD413LL,0xAAB7B0FEFB643081LL,0x11FBCB5F8A5F3DD5LL,0xDFC5B847C9DF72A4LL},{0x2FC2EDE97DFF8641LL,0xB463BAD36AAE4366LL,0xBDD9A00CFA1DD413LL,0x74A96FD5C8B92581LL,0xD15548A5A95F6E19LL,(-7L)},{0L,0x7BE9A0DE9C7ACE04LL,0xDFC5B847C9DF72A4LL,3L,0x732C7BF072493068LL,0L},{3L,0x732C7BF072493068LL,0L,0xB463BAD36AAE4366LL,0xB463BAD36AAE4366LL,0L},{0x2FC2EDE97DFF8641LL,0x2FC2EDE97DFF8641LL,0xDFC5B847C9DF72A4LL,0x0D599FB7633464F2LL,0x7BE9A0DE9C7ACE04LL,(-7L)}},{{0x74A96FD5C8B92581LL,(-2L),0xBDD9A00CFA1DD413LL,0xB58EB3C0CCDA5011LL,0x732C7BF072493068LL,0xDFC5B847C9DF72A4LL},{0xD15548A5A95F6E19LL,0x74A96FD5C8B92581LL,0x11FBCB5F8A5F3DD5LL,0L,0x1DF8B2501E9A13F3LL,0xB463BAD36AAE4366LL},{0L,0L,(-6L),(-10L),(-1L),0xAAB7B0FEFB643081LL},{(-10L),(-1L),0xAAB7B0FEFB643081LL,0xFA972A1D78CFF22FLL,(-1L),0xAAB7B0FEFB643081LL},{0L,(-2L),(-6L),0L,0L,0xB463BAD36AAE4366LL}}};
static int16_t *g_638 = (void*)0;
static int16_t **g_637 = &g_638;
static int16_t g_678 = 1L;
static uint16_t *g_679 = &g_173;
static int8_t g_749 = 0x09L;
static uint8_t g_755[9][1][4] = {{{2UL,7UL,0x77L,7UL}},{{0x77L,7UL,2UL,4UL}},{{7UL,0x43L,1UL,0x77L}},{{0x41L,0UL,0UL,0x41L}},{{0x41L,4UL,1UL,0xB3L}},{{7UL,0x41L,2UL,0UL}},{{0x77L,0x39L,0x77L,0UL}},{{2UL,0x41L,7UL,0xB3L}},{{1UL,4UL,0x41L,0x41L}}};
static uint32_t g_778 = 4294967295UL;
static volatile uint16_t * volatile *g_784[6] = {&g_446,&g_446,&g_446,&g_446,&g_446,&g_446};
static volatile uint16_t * volatile **g_783 = &g_784[0];
static volatile uint16_t * volatile ** volatile *g_782[9][10] = {{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783},{&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783}};
static volatile uint16_t * volatile ** volatile **g_781 = &g_782[4][9];
static uint16_t ** const **g_792 = (void*)0;
static uint16_t g_977 = 0xE7A4L;
static uint32_t **g_983 = &g_289[1];
static uint32_t ***g_982[7][5][6] = {{{&g_983,&g_983,(void*)0,(void*)0,&g_983,&g_983},{&g_983,&g_983,(void*)0,&g_983,&g_983,(void*)0},{&g_983,&g_983,(void*)0,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,(void*)0,&g_983,&g_983,&g_983,(void*)0}},{{&g_983,(void*)0,&g_983,&g_983,&g_983,&g_983},{(void*)0,&g_983,(void*)0,&g_983,(void*)0,&g_983},{&g_983,(void*)0,(void*)0,&g_983,&g_983,(void*)0},{&g_983,&g_983,(void*)0,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983}},{{(void*)0,&g_983,(void*)0,&g_983,&g_983,(void*)0},{&g_983,&g_983,&g_983,&g_983,(void*)0,&g_983},{&g_983,(void*)0,&g_983,&g_983,&g_983,(void*)0},{&g_983,&g_983,&g_983,(void*)0,&g_983,&g_983},{&g_983,&g_983,(void*)0,(void*)0,&g_983,&g_983}},{{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,(void*)0,&g_983},{(void*)0,(void*)0,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983}},{{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,(void*)0,&g_983,&g_983,&g_983},{&g_983,&g_983,(void*)0,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,(void*)0,&g_983}},{{&g_983,&g_983,&g_983,(void*)0,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{(void*)0,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,(void*)0,(void*)0,(void*)0,&g_983,&g_983}},{{(void*)0,&g_983,&g_983,&g_983,&g_983,(void*)0},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983},{&g_983,&g_983,&g_983,&g_983,(void*)0,(void*)0},{&g_983,&g_983,(void*)0,&g_983,(void*)0,&g_983},{&g_983,&g_983,&g_983,&g_983,&g_983,&g_983}}};
static uint32_t ****g_981 = &g_982[2][1][3];
static int64_t *g_989 = &g_599.f1;
static struct S2 g_998 = {4425,7317,6,1,-1197,-562,2,-14676,19};/* VOLATILE GLOBAL g_998 */
static struct S2 g_999 = {3696,9682,1,1,-1057,361,-3,2308,0};/* VOLATILE GLOBAL g_999 */
static struct S2 g_1000[8][5] = {{{43185,5160,3,1,114,789,1,14117,21},{8521,6000,2,0,-1639,514,-3,-22267,15},{-38419,7332,7,1,-901,-1023,0,-15759,-2},{-24558,4653,5,1,1307,-1008,-4,-7665,11},{-40848,3688,7,0,-995,580,-4,1641,-14}},{{43185,5160,3,1,114,789,1,14117,21},{-40848,3688,7,0,-995,580,-4,1641,-14},{31093,2818,9,0,695,-762,1,-20443,-18},{9633,3861,5,0,1501,-618,0,-6190,9},{9633,3861,5,0,1501,-618,0,-6190,9}},{{-24558,4653,5,1,1307,-1008,-4,-7665,11},{-6991,1149,3,0,-706,179,2,-20336,-12},{-24558,4653,5,1,1307,-1008,-4,-7665,11},{8521,6000,2,0,-1639,514,-3,-22267,15},{-40848,3688,7,0,-995,580,-4,1641,-14}},{{17049,2168,10,1,1942,-205,-2,-5096,-10},{9633,3861,5,0,1501,-618,0,-6190,9},{-40848,3688,7,0,-995,580,-4,1641,-14},{-37045,3812,2,1,759,-179,-1,20968,-20},{9633,3861,5,0,1501,-618,0,-6190,9}},{{-21119,3958,8,1,-1538,-664,-2,-363,-5},{34284,3688,6,1,-1787,494,1,-21003,-8},{31093,2818,9,0,695,-762,1,-20443,-18},{31093,2818,9,0,695,-762,1,-20443,-18},{34284,3688,6,1,-1787,494,1,-21003,-8}},{{34284,3688,6,1,-1787,494,1,-21003,-8},{-38419,7332,7,1,-901,-1023,0,-15759,-2},{-21119,3958,8,1,-1538,-664,-2,-363,-5},{9633,3861,5,0,1501,-618,0,-6190,9},{-7282,9142,2,1,329,-27,-3,-13844,-6}},{{43185,5160,3,1,114,789,1,14117,21},{-38419,7332,7,1,-901,-1023,0,-15759,-2},{9633,3861,5,0,1501,-618,0,-6190,9},{-6991,1149,3,0,-706,179,2,-20336,-12},{17049,2168,10,1,1942,-205,-2,-5096,-10}},{{-40848,3688,7,0,-995,580,-4,1641,-14},{34284,3688,6,1,-1787,494,1,-21003,-8},{34284,3688,6,1,-1787,494,1,-21003,-8},{-40848,3688,7,0,-995,580,-4,1641,-14},{-6991,1149,3,0,-706,179,2,-20336,-12}}};
static struct S2 g_1001 = {-35314,6661,5,0,1128,564,4,2855,0};/* VOLATILE GLOBAL g_1001 */
static struct S2 g_1004 = {-3018,6515,8,0,1327,241,-1,15092,-2};/* VOLATILE GLOBAL g_1004 */
static struct S2 *g_1003 = &g_1004;
static uint16_t **g_1067 = &g_679;
static uint16_t ***g_1066 = &g_1067;
static uint16_t ****g_1065[3] = {&g_1066,&g_1066,&g_1066};
static uint16_t *****g_1064 = &g_1065[0];
static int16_t * volatile *g_1075 = (void*)0;
static int16_t * volatile **g_1074 = &g_1075;
static int16_t * volatile ** volatile * const g_1073[4][1] = {{&g_1074},{&g_1074},{&g_1074},{&g_1074}};
static struct S1 g_1083 = {4UL,0x64E942AB41C1C963LL,0L,0x1D6C7332L,0xBB2B2C193D3A5428LL,-4L,0xECED4747L,0xEF77L};/* VOLATILE GLOBAL g_1083 */
static struct S1 *g_1082 = &g_1083;
static struct S1 **g_1081 = &g_1082;
static struct S2 g_1180 = {-31876,10571,0,0,-498,-580,-2,3924,-7};/* VOLATILE GLOBAL g_1180 */
static volatile struct S2 g_1182 = {32526,2261,3,1,-979,-229,-3,-7057,-20};/* VOLATILE GLOBAL g_1182 */
static volatile struct S2 g_1183 = {40653,1574,5,1,-1596,-577,-3,-12452,-14};/* VOLATILE GLOBAL g_1183 */
static volatile struct S2 g_1184 = {-24169,2317,5,0,864,691,0,-14394,19};/* VOLATILE GLOBAL g_1184 */
static volatile struct S2 g_1185[6] = {{-11269,4828,9,0,-2026,180,2,-10406,7},{-11269,4828,9,0,-2026,180,2,-10406,7},{-11269,4828,9,0,-2026,180,2,-10406,7},{-11269,4828,9,0,-2026,180,2,-10406,7},{-11269,4828,9,0,-2026,180,2,-10406,7},{-11269,4828,9,0,-2026,180,2,-10406,7}};
static volatile struct S2 g_1186 = {30187,10547,10,0,-1002,101,-4,-19538,-17};/* VOLATILE GLOBAL g_1186 */
static volatile struct S2 g_1187 = {23533,8919,10,1,1037,911,0,8579,10};/* VOLATILE GLOBAL g_1187 */
static volatile struct S2 g_1188 = {-1804,2098,9,1,-259,663,1,13624,20};/* VOLATILE GLOBAL g_1188 */
static volatile struct S2 g_1189 = {-1506,9768,4,1,1780,962,-0,14018,9};/* VOLATILE GLOBAL g_1189 */
static volatile struct S2 *g_1181[10][8][3] = {{{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1184},{(void*)0,&g_1183,&g_1185[5]},{&g_1182,&g_1182,&g_1186},{&g_1187,&g_1183,&g_1183},{&g_1186,(void*)0,&g_1188},{&g_1187,&g_1189,&g_1187},{&g_1182,&g_1186,&g_1188}},{{(void*)0,(void*)0,&g_1183},{&g_1184,&g_1186,&g_1186},{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1184},{(void*)0,&g_1183,&g_1185[5]},{&g_1182,&g_1182,&g_1186},{&g_1187,&g_1183,&g_1183},{&g_1186,(void*)0,&g_1188}},{{&g_1187,&g_1189,&g_1187},{&g_1182,&g_1186,&g_1188},{(void*)0,(void*)0,&g_1183},{&g_1184,&g_1186,&g_1186},{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1184},{(void*)0,&g_1183,&g_1185[5]},{&g_1182,&g_1182,&g_1186}},{{&g_1187,&g_1183,&g_1183},{&g_1186,(void*)0,&g_1188},{&g_1187,&g_1189,&g_1187},{&g_1182,&g_1186,&g_1188},{(void*)0,(void*)0,&g_1183},{&g_1184,&g_1186,&g_1186},{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1184}},{{(void*)0,&g_1183,&g_1185[5]},{&g_1182,&g_1182,&g_1186},{&g_1187,&g_1183,&g_1183},{&g_1186,(void*)0,&g_1188},{&g_1187,&g_1189,&g_1187},{&g_1182,&g_1186,&g_1188},{(void*)0,(void*)0,&g_1183},{&g_1184,&g_1186,&g_1186}},{{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1184},{(void*)0,&g_1183,&g_1185[5]},{&g_1182,&g_1182,&g_1186},{&g_1187,&g_1183,&g_1183},{&g_1186,(void*)0,&g_1188},{&g_1187,&g_1189,&g_1187},{&g_1182,&g_1186,&g_1188}},{{(void*)0,(void*)0,&g_1183},{&g_1184,&g_1186,&g_1186},{&g_1183,&g_1189,&g_1185[5]},{&g_1184,(void*)0,&g_1188},{&g_1183,&g_1187,&g_1189},{&g_1186,&g_1186,&g_1184},{&g_1185[5],&g_1187,&g_1187},{&g_1184,&g_1182,(void*)0}},{{&g_1185[5],(void*)0,&g_1185[5]},{&g_1186,&g_1184,(void*)0},{&g_1183,&g_1183,&g_1187},{&g_1188,&g_1184,&g_1184},{&g_1187,(void*)0,&g_1189},{&g_1188,&g_1182,&g_1188},{&g_1183,&g_1187,&g_1189},{&g_1186,&g_1186,&g_1184}},{{&g_1185[5],&g_1187,&g_1187},{&g_1184,&g_1182,(void*)0},{&g_1185[5],(void*)0,&g_1185[5]},{&g_1186,&g_1184,(void*)0},{&g_1183,&g_1183,&g_1187},{&g_1188,&g_1184,&g_1184},{&g_1187,(void*)0,&g_1189},{&g_1188,&g_1182,&g_1188}},{{&g_1183,&g_1187,&g_1189},{&g_1186,&g_1186,&g_1184},{&g_1185[5],&g_1187,&g_1187},{&g_1184,&g_1182,(void*)0},{&g_1185[5],(void*)0,&g_1185[5]},{&g_1186,&g_1184,(void*)0},{&g_1183,&g_1183,&g_1187},{&g_1188,&g_1184,&g_1184}}};
static const int8_t g_1222 = 0x2AL;
static int64_t g_1256 = 0xF599140E9E710E96LL;
static uint8_t g_1257 = 254UL;
static int32_t g_1263 = 0L;
static int16_t **g_1293 = &g_638;
static uint64_t *g_1301 = &g_464.f1;
static uint64_t **g_1300 = &g_1301;
static struct S1 g_1374 = {0xEEL,-1L,0L,0x0DEAC901L,0x94519104CAF4382DLL,0L,0x9152C59AL,0x8D4DL};/* VOLATILE GLOBAL g_1374 */
static struct S1 g_1376[6] = {{0x33L,0x230F2998E9D32ED1LL,0x7FF1FF9AL,7UL,0xCADD407750D7571FLL,1L,0L,0x7B2BL},{8UL,-6L,-1L,1UL,0x2D5D50A8F61821ADLL,0x51CDL,0x3502116CL,0x9322L},{0x33L,0x230F2998E9D32ED1LL,0x7FF1FF9AL,7UL,0xCADD407750D7571FLL,1L,0L,0x7B2BL},{0x33L,0x230F2998E9D32ED1LL,0x7FF1FF9AL,7UL,0xCADD407750D7571FLL,1L,0L,0x7B2BL},{8UL,-6L,-1L,1UL,0x2D5D50A8F61821ADLL,0x51CDL,0x3502116CL,0x9322L},{0x33L,0x230F2998E9D32ED1LL,0x7FF1FF9AL,7UL,0xCADD407750D7571FLL,1L,0L,0x7B2BL}};
static int32_t **g_1443 = &g_570[0][0];
static int32_t ***g_1442 = &g_1443;
static int32_t ***g_1445 = &g_1443;
static volatile uint16_t g_1459 = 0UL;/* VOLATILE GLOBAL g_1459 */
static struct S0 g_1501 = {0x44236D15E1DC6819LL,0x6A1D5B86EEC634B9LL,620};
static struct S0 *g_1500 = &g_1501;
static volatile uint32_t g_1549 = 0xDC3EA06AL;/* VOLATILE GLOBAL g_1549 */
static volatile uint32_t *g_1548[8] = {&g_1549,&g_1549,&g_1549,&g_1549,&g_1549,&g_1549,&g_1549,&g_1549};
static struct S1 g_1574 = {6UL,0L,0xBB4F504AL,0x39534BFBL,0x1851196B51B3FDA5LL,1L,0x3A3689E3L,-1L};/* VOLATILE GLOBAL g_1574 */
static struct S3 ** volatile * volatile g_1592 = (void*)0;/* VOLATILE GLOBAL g_1592 */
static struct S3 ** volatile * volatile * volatile g_1591[4] = {&g_1592,&g_1592,&g_1592,&g_1592};
static const volatile struct S3 ** volatile g_1625 = (void*)0;/* VOLATILE GLOBAL g_1625 */
static const volatile struct S3 ** volatile *g_1624 = &g_1625;
static const volatile struct S3 ** volatile **g_1623 = &g_1624;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint64_t * func_47(int32_t * p_48, int64_t  p_49, uint64_t  p_50, uint16_t  p_51);
static struct S0  func_53(const uint64_t * const  p_54, uint64_t  p_55, uint32_t  p_56, int32_t * p_57);
static const int32_t  func_101(int32_t  p_102, uint8_t  p_103);
static int32_t  func_104(uint32_t * p_105);
static uint32_t * func_106(uint32_t  p_107, uint64_t  p_108, const struct S3  p_109, uint16_t * p_110);
static uint32_t  func_111(uint32_t  p_112, int8_t  p_113, int16_t * p_114);
static int32_t  func_117(int32_t  p_118, int16_t * p_119, uint16_t * p_120);
static uint8_t  func_121(int64_t * p_122, int8_t  p_123, const uint32_t * p_124, int32_t * p_125, int32_t * p_126);
static uint32_t * func_127(uint64_t  p_128, int8_t  p_129, uint64_t * p_130);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_3 g_7 g_4 g_15 g_203 g_204 g_989 g_292.f1 g_1623 g_1064 g_1065 g_1066 g_1067 g_679 g_173 g_489 g_354 g_1300 g_1301 g_464.f1 g_1574.f7 g_243 g_244
 * writes: g_8 g_15 g_599.f1 g_173 g_1574.f7
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_38 = 255UL;
    int32_t l_42 = 0x1471C2AAL;
    int32_t *l_52 = (void*)0;
    const uint64_t * const l_58 = &g_25;
    int32_t l_1456 = 0xA45ABBADL;
    int32_t l_1458 = (-6L);
    uint64_t l_1465 = 18446744073709551615UL;
    uint32_t l_1480 = 1UL;
    uint32_t l_1486 = 0xD55DCC09L;
    uint16_t l_1522 = 0x1FBCL;
    uint32_t l_1528 = 0xE1693D75L;
    uint64_t l_1557[1][10] = {{1UL,0UL,1UL,0UL,1UL,0UL,1UL,0UL,1UL,0UL}};
    int16_t ** const *l_1596 = &g_1293;
    int16_t ** const * const *l_1595 = &l_1596;
    int16_t ** const * const **l_1594 = &l_1595;
    const int32_t l_1630 = (-3L);
    int8_t l_1636 = 0x55L;
    int32_t l_1639 = 0x98BD0098L;
    int32_t l_1640 = 0L;
    int32_t l_1641[9][10] = {{8L,(-6L),0L,0L,0L,0L,(-6L),8L,0x7C2AEBC6L,0L},{8L,0x9F145461L,0x8F4B032CL,0L,0x18464E86L,0x8F4B032CL,(-6L),0x8F4B032CL,0x18464E86L,0L},{0x8F4B032CL,(-6L),0x8F4B032CL,0x18464E86L,0L,0x8F4B032CL,0x9F145461L,8L,0x18464E86L,0x18464E86L},{8L,(-6L),0L,0L,0L,0L,(-6L),8L,0x7C2AEBC6L,0L},{8L,0x9F145461L,0x8F4B032CL,0L,0x18464E86L,0x8F4B032CL,(-6L),0x8F4B032CL,0x18464E86L,0L},{0x8F4B032CL,(-6L),0x8F4B032CL,0x18464E86L,0L,0x8F4B032CL,0x9F145461L,8L,0x18464E86L,0x18464E86L},{8L,(-6L),0L,0L,0L,0L,(-6L),8L,0x7C2AEBC6L,0L},{8L,0x9F145461L,0x8F4B032CL,0L,0x18464E86L,0x8F4B032CL,(-6L),0x8F4B032CL,0L,0x8F4B032CL},{6L,0x3BD86078L,6L,0L,0x8F4B032CL,6L,(-4L),0xCFCF9EEAL,0L,0L}};
    int i, j;
    for (g_8 = 0; (g_8 >= (-30)); g_8 = safe_sub_func_uint64_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */(g_8, 7))
    { /* block id: 3 */
        uint64_t l_1462[9][7] = {{6UL,0xDCC08E12E016DDFELL,6UL,0x97B8FAEAB8BEDF79LL,0x97B8FAEAB8BEDF79LL,6UL,0xDCC08E12E016DDFELL},{0x97B8FAEAB8BEDF79LL,0xDCC08E12E016DDFELL,0UL,0UL,0xDCC08E12E016DDFELL,0x97B8FAEAB8BEDF79LL,0xDCC08E12E016DDFELL},{6UL,0x97B8FAEAB8BEDF79LL,0x97B8FAEAB8BEDF79LL,6UL,0xDCC08E12E016DDFELL,6UL,0x97B8FAEAB8BEDF79LL},{0xC7E49824EDC027CBLL,0xC7E49824EDC027CBLL,0x97B8FAEAB8BEDF79LL,0UL,0x97B8FAEAB8BEDF79LL,0xC7E49824EDC027CBLL,0xC7E49824EDC027CBLL},{0xC7E49824EDC027CBLL,0x97B8FAEAB8BEDF79LL,0UL,0x97B8FAEAB8BEDF79LL,0xC7E49824EDC027CBLL,0xC7E49824EDC027CBLL,0x97B8FAEAB8BEDF79LL},{6UL,0xDCC08E12E016DDFELL,6UL,0x97B8FAEAB8BEDF79LL,0x97B8FAEAB8BEDF79LL,6UL,0xDCC08E12E016DDFELL},{0x97B8FAEAB8BEDF79LL,0xDCC08E12E016DDFELL,0UL,0UL,0xDCC08E12E016DDFELL,0x97B8FAEAB8BEDF79LL,0xDCC08E12E016DDFELL},{6UL,0x97B8FAEAB8BEDF79LL,0x97B8FAEAB8BEDF79LL,6UL,0xDCC08E12E016DDFELL,6UL,0x97B8FAEAB8BEDF79LL},{0xC7E49824EDC027CBLL,0xC7E49824EDC027CBLL,0x97B8FAEAB8BEDF79LL,0UL,0x97B8FAEAB8BEDF79LL,0xC7E49824EDC027CBLL,0xC7E49824EDC027CBLL}};
        uint32_t l_1466 = 18446744073709551611UL;
        int32_t l_1484 = 0xF7DACD2EL;
        int32_t l_1515 = 0xDCB51B44L;
        uint16_t l_1520 = 1UL;
        int32_t l_1527 = 0x2CDA3340L;
        int32_t ** const l_1554 = &g_570[0][0];
        uint64_t l_1555 = 0x113357D7BFB48F88LL;
        int16_t l_1604 = 0xB13EL;
        int32_t l_1616 = (-1L);
        int32_t l_1627 = (-9L);
        int32_t l_1637 = 0xB2BEC578L;
        int32_t l_1638[4][5] = {{0xF9114E8DL,0xF9114E8DL,0xF9114E8DL,0xF9114E8DL,0xF9114E8DL},{(-9L),(-9L),(-9L),(-9L),(-9L)},{0xF9114E8DL,0xF9114E8DL,0xF9114E8DL,0xF9114E8DL,0xF9114E8DL},{(-9L),(-9L),(-9L),(-9L),(-9L)}};
        int i, j;
        if (g_3)
            break;
        if (g_7)
            break;
        if ((safe_div_func_int64_t_s_s_unsafe_macro/*1*//* ___SAFE__OP */(0xE905F4D0C653DDB2LL, (safe_mod_func_int64_t_s_s_unsafe_macro/*2*//* ___SAFE__OP */(g_4[0], g_8)))))
        { /* block id: 6 */
            uint16_t l_30 = 0xDFE9L;
            int32_t l_37[8][2];
            int32_t l_1479 = (-2L);
            uint32_t l_1551[9] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
            uint16_t l_1590[1][2];
            int16_t ** const * const **l_1597[3][8][1] = {{{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595}},{{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595}},{{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595},{&l_1595}}};
            uint8_t *l_1615[10][6] = {{&g_342,&g_342,(void*)0,&g_1257,(void*)0,&g_342},{(void*)0,&g_342,&l_38,&g_342,&g_342,&l_38},{(void*)0,(void*)0,&g_342,&g_1257,&g_342,&g_1257},{&g_342,(void*)0,&g_342,&l_38,&g_342,&g_342},{&g_342,&g_342,&g_342,&g_342,(void*)0,&g_1257},{&g_1257,&g_342,&g_342,&g_342,&g_1257,&l_38},{&g_342,&g_1257,&l_38,&l_38,&g_1257,&g_342},{&g_342,&g_342,(void*)0,&g_1257,(void*)0,&g_342},{(void*)0,&g_342,&l_38,&g_342,&g_342,&l_38},{(void*)0,(void*)0,&g_342,&g_1257,&g_342,&g_1257}};
            uint16_t l_1626 = 0x1CE3L;
            int32_t *l_1628[6][9][1] = {{{(void*)0},{&g_172},{(void*)0},{&g_15},{(void*)0},{&g_172},{&g_172},{&g_172},{(void*)0}},{{&g_15},{&l_1458},{&l_1527},{&l_1458},{&g_15},{(void*)0},{&g_172},{&g_172},{&g_172}},{{(void*)0},{&g_15},{&l_1458},{&l_1527},{&l_1458},{&g_15},{(void*)0},{&g_172},{&g_172}},{{&g_172},{(void*)0},{&g_15},{&l_1458},{&l_1527},{&l_1458},{&g_15},{(void*)0},{&g_172}},{{&g_172},{&g_172},{(void*)0},{&g_15},{&l_1458},{&l_1527},{&l_1458},{&g_15},{(void*)0}},{{&g_172},{&g_172},{&g_172},{(void*)0},{&g_15},{&l_1458},{&l_1527},{&l_1458},{&g_15}}};
            uint8_t l_1629 = 0x8DL;
            int64_t l_1634 = (-9L);
            uint16_t l_1642 = 3UL;
            int i, j, k;
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 2; j++)
                    l_37[i][j] = 0xC684CA67L;
            }
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1590[i][j] = 8UL;
            }
            for (g_15 = (-17); (g_15 == (-9)); g_15++)
            { /* block id: 9 */
                uint64_t *l_24 = &g_25;
                uint16_t *l_35[1];
                int16_t *l_39 = (void*)0;
                int16_t *l_40[5];
                int32_t *l_43 = &g_44;
                int32_t *l_45 = &g_46;
                int64_t l_1452 = 0x4B2A9003B9569BCDLL;
                const uint32_t l_1483[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
                struct S0 *l_1499 = &g_464;
                uint32_t l_1521 = 0x426FEE65L;
                int32_t l_1525 = (-1L);
                int32_t l_1526[2];
                int16_t l_1556[6][2] = {{0x8B28L,0x9A91L},{0x0AB2L,0L},{0x9A91L,0L},{0x0AB2L,0x9A91L},{0x8B28L,0x8B28L},{0x8B28L,0x9A91L}};
                uint64_t l_1562 = 18446744073709551610UL;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_35[i] = &g_36;
                for (i = 0; i < 5; i++)
                    l_40[i] = &g_41[2];
                for (i = 0; i < 2; i++)
                    l_1526[i] = 3L;
            }
            l_1597[28151][21003][1196] = l_1594;
            l_42 ^= (safe_lshift_func_uint32_t_u_u_unsafe_macro/*3*//* ___SAFE__OP */((((l_1629 = (safe_div_func_int64_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */((((l_1590[13218][231] && ((l_1604 , (((*g_989) = ((l_37[3833][0] = l_1479) , (*g_203))) | (safe_sub_func_int64_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */(((0xEB3CL <= 0x79F4L) && ((safe_lshift_func_int64_t_s_s_unsafe_macro/*7*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*8*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*9*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */((l_1616 = g_292.f1), (safe_sub_func_int8_t_s_s_unsafe_macro/*11*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */(((*****g_1064) ^= (safe_lshift_func_int32_t_s_u_unsafe_macro/*13*//* ___SAFE__OP */(((void*)0 == g_1623), l_1626))), l_30)) == g_489), l_1486)))) != g_354), l_1604)), (**g_1300))) && 248UL), 36)) ^ l_1590[15385][1799])), l_1551[11102])))) >= l_1479)) != l_1627) , 0xEEL), 4)), (*g_1301)))) > 0L) <= 18446744073709551615UL), l_1630));
            for (g_1574.f7 = 0; (g_1574.f7 >= (-26)); g_1574.f7 = safe_sub_func_uint64_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */(g_1574.f7, 7))
            { /* block id: 690 */
                int16_t l_1633[1][5][1] = {{{1L},{0xE583L},{1L},{0xE583L},{1L}}};
                int32_t l_1635[5][5] = {{0x27399A2BL,0x27399A2BL,0xE187D6CEL,0x27399A2BL,0x27399A2BL},{1L,(-4L),1L,0x36272083L,0x0C336E53L},{0x27399A2BL,(-10L),(-10L),0x27399A2BL,(-10L)},{0x0C336E53L,(-4L),0xDB2E45EEL,(-4L),0x0C336E53L},{(-10L),0x27399A2BL,(-10L),(-10L),0x27399A2BL}};
                int i, j, k;
                --l_1642;
            }
        }
        else
        { /* block id: 693 */
            uint32_t l_1645 = 0x51C03132L;
            return l_1645;
        }
    }
    return (*g_243);
}


/* ------------------------------------------ */
/* 
 * reads : g_65 g_41 g_15 g_25 g_8
 * writes: g_64 g_65 g_97 g_41
 */
static uint64_t * func_47(int32_t * p_48, int64_t  p_49, uint64_t  p_50, uint16_t  p_51)
{ /* block id: 20 */
    int32_t l_80 = 0L;
    int64_t *l_88 = (void*)0;
    uint32_t l_98 = 0xBD1F8265L;
    const struct S3 l_1264 = {3,-122,1,707,-28,934};
    uint16_t *l_1265 = &g_630;
    struct S1 *l_1375 = &g_1376[0];
    struct S2 **l_1396 = (void*)0;
    for (p_49 = 26; (p_49 != (-30)); --p_49)
    { /* block id: 23 */
        int64_t *l_81 = &g_64[0][4];
        int64_t **l_89 = &l_88;
        uint32_t *l_92 = &g_65[2][4];
        int32_t l_95 = 0xE9F9EEF7L;
        int64_t *l_96 = &g_97;
        int16_t *l_99 = &g_41[2];
        uint32_t l_100 = 0x1A8DCBC2L;
        uint8_t l_1335 = 0xC3L;
        int32_t l_1349 = 0x0C34AF19L;
        uint64_t ***l_1371 = &g_1300;
        struct S1 *l_1373 = &g_1374;
        int16_t ***l_1400 = &g_637;
        int16_t ****l_1399 = &l_1400;
        uint32_t l_1405 = 0xAD52B201L;
        const int32_t l_1435 = (-7L);
        l_100 = ((((safe_rshift_func_uint64_t_u_u_unsafe_macro/*15*//* ___SAFE__OP */(0x816E0766B1C03A75LL, 25)) , 9L) > ((*l_99) = (safe_sub_func_uint16_t_u_u_unsafe_macro/*16*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */(((*p_48) , (safe_div_func_int64_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */(((*l_81) = l_80), (safe_sub_func_uint16_t_u_u_unsafe_macro/*19*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*20*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*21*//* ___SAFE__OP */(((&p_49 == ((*l_89) = l_88)) && (((p_51 < (safe_lshift_func_int64_t_s_u_unsafe_macro/*22*//* ___SAFE__OP */(((*l_96) = (l_95 = (((*l_92) &= 4294967288UL) , (safe_rshift_func_uint32_t_u_s_unsafe_macro/*23*//* ___SAFE__OP */((l_95 != 0x637F256DL), g_41[2]))))), g_15))) >= g_25) || l_80)), l_98)), g_25)), g_8))))), 4294967295UL)), p_49)))) & 1L);
    }
    return l_88;
}


/* ------------------------------------------ */
/* 
 * reads : g_65
 * writes: g_65
 */
static struct S0  func_53(const uint64_t * const  p_54, uint64_t  p_55, uint32_t  p_56, int32_t * p_57)
{ /* block id: 16 */
    int32_t *l_60 = &g_44;
    int32_t *l_61 = &g_46;
    int32_t *l_62 = &g_44;
    int32_t *l_63[3][1][10] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_8,(void*)0,&g_8,(void*)0,&g_8,(void*)0,&g_8,(void*)0,&g_8,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
    struct S0 l_68[3][10] = {{{0xB99CB9CEB51834A9LL,18446744073709551615UL,65},{0x69E501E45A2DC96FLL,18446744073709551615UL,667},{1UL,0xA8BFC0225587BB5BLL,314},{0xB99CB9CEB51834A9LL,18446744073709551615UL,65},{0xF630FE8BAC2835E5LL,0xA12E219839B2FD4BLL,27},{0xF630FE8BAC2835E5LL,0xA12E219839B2FD4BLL,27},{0xB99CB9CEB51834A9LL,18446744073709551615UL,65},{1UL,0xA8BFC0225587BB5BLL,314},{0x69E501E45A2DC96FLL,18446744073709551615UL,667},{0xB99CB9CEB51834A9LL,18446744073709551615UL,65}},{{1UL,0xA8BFC0225587BB5BLL,314},{0x5EFCBABA1048D1DFLL,0x66F6C633F4C626C4LL,560},{0x69E501E45A2DC96FLL,18446744073709551615UL,667},{0xF630FE8BAC2835E5LL,0xA12E219839B2FD4BLL,27},{0x5EFCBABA1048D1DFLL,0x66F6C633F4C626C4LL,560},{0xF630FE8BAC2835E5LL,0xA12E219839B2FD4BLL,27},{0x69E501E45A2DC96FLL,18446744073709551615UL,667},{0x5EFCBABA1048D1DFLL,0x66F6C633F4C626C4LL,560},{1UL,0xA8BFC0225587BB5BLL,314},{1UL,0xA8BFC0225587BB5BLL,314}},{{0xB99CB9CEB51834A9LL,18446744073709551615UL,65},{0x4FBAEB33E7469BA6LL,1UL,224},{0x2A3EDB7DE593F29FLL,18446744073709551607UL,315},{0x5EFCBABA1048D1DFLL,0x66F6C633F4C626C4LL,560},{0x5EFCBABA1048D1DFLL,0x66F6C633F4C626C4LL,560},{0x2A3EDB7DE593F29FLL,18446744073709551607UL,315},{0x4FBAEB33E7469BA6LL,1UL,224},{0xB99CB9CEB51834A9LL,18446744073709551615UL,65},{0x2A3EDB7DE593F29FLL,18446744073709551607UL,315},{0xB99CB9CEB51834A9LL,18446744073709551615UL,65}}};
    int i, j, k;
    g_65[2][4]--;
    return l_68[1][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_242 g_243
 * writes: g_243
 */
static const int32_t  func_101(int32_t  p_102, uint8_t  p_103)
{ /* block id: 547 */
    int8_t l_1316 = 1L;
    int32_t *l_1317[7] = {&g_172,&g_46,&g_46,&g_172,&g_46,&g_46,&g_172};
    int i;
    p_102 = l_1316;
    (*g_242) = (*g_242);
    p_102 = 0xC881C24DL;
    return p_102;
}


/* ------------------------------------------ */
/* 
 * reads : g_242 g_243 g_1067 g_679 g_173 g_172
 * writes: g_173 g_172
 */
static int32_t  func_104(uint32_t * p_105)
{ /* block id: 543 */
    int32_t l_1308 = 0xD50F0F79L;
    uint32_t *l_1314 = &g_65[5][0];
    int32_t *l_1315 = &g_172;
    (*l_1315) = (safe_sub_func_int32_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */((l_1308 != l_1308), (safe_add_func_uint64_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */((((l_1308 < ((**g_1067) |= (l_1308 | ((void*)0 == (*g_242))))) , (+((((safe_rshift_func_int16_t_s_u_unsafe_macro/*26*//* ___SAFE__OP */(l_1308, 14)) & 7UL) , p_105) == l_1314))) != l_1308), l_1308))));
    return (*l_1315);
}


/* ------------------------------------------ */
/* 
 * reads : g_464.f2 g_8 g_1083.f6 g_1263 g_630 g_631 g_292.f2 g_159 g_989 g_599.f4 g_599.f1 g_1300 g_1064 g_1065 g_1066 g_1067 g_679 g_173
 * writes: g_456 g_1263 g_637 g_1293 g_599.f4 g_599.f1
 */
static uint32_t * func_106(uint32_t  p_107, uint64_t  p_108, const struct S3  p_109, uint16_t * p_110)
{ /* block id: 531 */
    int64_t l_1270[4][4][9] = {{{0x9ACCAF7DBEB50160LL,1L,0xB99C7864F4C19311LL,0x269C846404259776LL,0xB85699C41C30F9D2LL,0xCAF312EDAB1676F3LL,0xC8DF245179284816LL,(-10L),0xB7BE051F9D675046LL},{0L,(-8L),(-2L),0xB99C7864F4C19311LL,1L,0x56F2BE2CC63A7571LL,0xD61BB8FA55DB76C8LL,(-6L),0xAC297CB16A029007LL},{0x360D3057A7A43F9CLL,0x3F58B4D0F630F502LL,0xF36A94FF91BFAD97LL,0L,6L,(-10L),0x8A215273CF7B44D7LL,0x269C846404259776LL,1L},{0x9FFA9393E7C3642ELL,0xF43770AAB5BDAA42LL,0x360D3057A7A43F9CLL,2L,0xD61BB8FA55DB76C8LL,0L,0xF43770AAB5BDAA42LL,0xA571DEBAC8D80B0FLL,0x87ED8DED39BD53D0LL}},{{0xFC4B915D6207EA92LL,0xF36A94FF91BFAD97LL,0xB85699C41C30F9D2LL,0xA571DEBAC8D80B0FLL,0x9ACCAF7DBEB50160LL,0xCAF312EDAB1676F3LL,0xF43770AAB5BDAA42LL,3L,0xA571DEBAC8D80B0FLL},{0x2589D5E48A1FF8F2LL,0L,(-8L),1L,(-2L),0xF36A94FF91BFAD97LL,0x8A215273CF7B44D7LL,0xD9E9CB940F253024LL,0xD9E9CB940F253024LL},{0L,0xFC4B915D6207EA92LL,7L,0x14B7DE614CD314BDLL,7L,0xFC4B915D6207EA92LL,0L,1L,0xB85699C41C30F9D2LL},{0xB99C7864F4C19311LL,0xD61BB8FA55DB76C8LL,0x269C846404259776LL,0xF8593F743820CD38LL,0x2589D5E48A1FF8F2LL,(-1L),4L,(-10L),0xF43770AAB5BDAA42LL}},{{0x269C846404259776LL,0xF43770AAB5BDAA42LL,6L,0x9FFA9393E7C3642ELL,7L,2L,0L,1L,(-1L)},{0xCAF312EDAB1676F3LL,0x360D3057A7A43F9CLL,0x3F58B4D0F630F502LL,0xF36A94FF91BFAD97LL,0L,0xCAF312EDAB1676F3LL,0xA571DEBAC8D80B0FLL,0xD9E9CB940F253024LL,0x04F7ED3A4FD14077LL},{1L,0x56F2BE2CC63A7571LL,3L,1L,0x55757CA3F2951C6FLL,0x360D3057A7A43F9CLL,(-1L),3L,1L},{0L,(-2L),0xF43770AAB5BDAA42LL,(-8L),1L,(-6L),1L,0xA571DEBAC8D80B0FLL,1L}},{{0xF3AA496778B221D7LL,0xF755A8518D9A6AE4LL,0x87ED8DED39BD53D0LL,6L,0x2589D5E48A1FF8F2LL,0x06DA46FFFFFDB7D5LL,0L,0x269C846404259776LL,0x04F7ED3A4FD14077LL},{(-1L),0xB642958A916D2F25LL,0x2589D5E48A1FF8F2LL,0xB7BE051F9D675046LL,0x9EA1B1A00AACC597LL,0xB7BE051F9D675046LL,0x2589D5E48A1FF8F2LL,0xB642958A916D2F25LL,(-1L)},{1L,0xF8593F743820CD38LL,0xB85699C41C30F9D2LL,0x2589D5E48A1FF8F2LL,0xCAF312EDAB1676F3LL,(-2L),0x360D3057A7A43F9CLL,(-1L),0xF43770AAB5BDAA42LL},{0x04F7ED3A4FD14077LL,0x55757CA3F2951C6FLL,0xA9EFD31EDC556076LL,1L,0xF755A8518D9A6AE4LL,0xF8593F743820CD38LL,0x8A215273CF7B44D7LL,0x14B7DE614CD314BDLL,0xB85699C41C30F9D2LL}}};
    const int32_t *l_1279[6] = {&g_1083.f6,&g_1083.f6,&g_1083.f6,&g_1083.f6,&g_1083.f6,&g_1083.f6};
    const int32_t **l_1278 = &l_1279[14166];
    int32_t l_1280 = (-1L);
    int8_t *l_1281[5][1][1] = {{{&g_749}},{{&g_456}},{{&g_749}},{{&g_456}},{{&g_749}}};
    int32_t l_1282 = 1L;
    int32_t *l_1283 = &g_1263;
    int16_t **l_1291[4][6][7] = {{{&g_638,&g_638,(void*)0,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,(void*)0,(void*)0,(void*)0,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638}},{{&g_638,&g_638,(void*)0,&g_638,(void*)0,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,(void*)0,&g_638},{&g_638,&g_638,(void*)0,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638}},{{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,(void*)0,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{(void*)0,(void*)0,&g_638,&g_638,(void*)0,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638}},{{&g_638,&g_638,(void*)0,&g_638,(void*)0,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,(void*)0,&g_638,(void*)0,&g_638,&g_638},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638},{&g_638,&g_638,(void*)0,&g_638,&g_638,(void*)0,(void*)0},{&g_638,&g_638,&g_638,&g_638,&g_638,&g_638,&g_638}}};
    int16_t ***l_1292[10][4] = {{&g_637,&g_637,&g_637,&g_637},{&l_1291[0][20503][24430],&l_1291[0][20503][24430],(void*)0,&g_637},{&g_637,&g_637,(void*)0,&g_637},{&l_1291[0][20503][24430],&l_1291[29011][7349][23228],&g_637,(void*)0},{&g_637,&l_1291[29011][7349][23228],&l_1291[29011][7349][23228],&g_637},{&l_1291[29011][7349][23228],&g_637,&l_1291[0][20503][24430],&g_637},{&l_1291[29011][7349][23228],&l_1291[0][20503][24430],&l_1291[29011][7349][23228],&g_637},{&g_637,&g_637,&g_637,&g_637},{&l_1291[0][20503][24430],&l_1291[0][20503][24430],(void*)0,&g_637},{&g_637,&g_637,(void*)0,&g_637}};
    struct S3 l_1297 = {2,60,-0,252,-368,4044};
    uint64_t * const *l_1302 = (void*)0;
    uint64_t * const **l_1303 = &l_1302;
    int i, j, k;
    (*l_1283) ^= ((safe_mul_func_uint8_t_u_u_unsafe_macro/*27*//* ___SAFE__OP */(p_109.f3, g_464.f2)) , (l_1282 &= ((safe_div_func_int8_t_s_s_unsafe_macro/*28*//* ___SAFE__OP */(l_1270[19271][11826][21186], (safe_mul_func_int8_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */(((g_456 = ((safe_lshift_func_uint16_t_u_u_unsafe_macro/*30*//* ___SAFE__OP */((&g_570[3][3] == &g_243), l_1270[19271][11826][21186])) & ((+(safe_add_func_int16_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */(0xD89FL, (l_1278 != &l_1279[20289])))) | l_1280))) | 250UL), (**l_1278))))) , 0L)));
    (*l_1283) = (safe_mod_func_int64_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */(((*g_989) &= ((safe_div_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */(((*p_110) , g_631[0][0][2]), (safe_sub_func_int32_t_s_s_unsafe_macro/*34*//* ___SAFE__OP */(6L, ((safe_unary_minus_func_int64_t_s_unsafe_macro/*35*//* ___SAFE__OP */((g_292.f2 < (((g_637 = l_1291[29011][7349][23228]) != (g_1293 = (void*)0)) >= ((&l_1270[3][13923][2398] == (g_159 , (void*)0)) & (*l_1283)))))) && p_109.f0))))) >= 0x5736F445EB2F287ALL)), p_109.f3));
    (*l_1283) = (!(safe_mul_func_uint32_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */(((((l_1297 , p_109.f4) != (-7L)) < (safe_rshift_func_uint32_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */(((g_1300 == ((*l_1303) = l_1302)) == ((void*)0 == &g_308)), (0UL <= (((safe_mod_func_uint16_t_u_u_unsafe_macro/*38*//* ___SAFE__OP */(0xD629L, (*****g_1064))) , (**l_1278)) | p_109.f0))))) & (**l_1278)), (*l_1283))));
    (*l_1283) = 0x9B366C28L;
    return l_1283;
}


/* ------------------------------------------ */
/* 
 * reads : g_157 g_749 g_489 g_999.f4 g_570 g_679 g_173 g_1004.f1 g_456 g_159 g_599.f7 g_604 g_1064 g_1073 g_1004.f6 g_599.f4 g_36 g_464 g_1003 g_1081 g_342 g_1067 g_296 g_297 g_292 g_1000.f5 g_242 g_243 g_65 g_1257 g_1263
 * writes: g_157 g_989 g_1003 g_489 g_570 g_173 g_292.f4 g_159 g_599.f7 g_604 g_36 g_1081 g_342 g_500 g_755 g_65 g_1257
 */
static uint32_t  func_111(uint32_t  p_112, int8_t  p_113, int16_t * p_114)
{ /* block id: 413 */
    int64_t *l_986 = &g_599.f4;
    int32_t l_990 = 0xA279B955L;
    int32_t l_992 = 0x1B3EFD4FL;
    struct S0 l_993 = {18446744073709551612UL,18446744073709551610UL,329};
    struct S2 *l_997[1][2][7] = {{{(void*)0,&g_998,&g_1000[7][4],(void*)0,(void*)0,&g_1000[7][4],&g_998},{(void*)0,&g_998,&g_1000[7][4],(void*)0,(void*)0,&g_1000[7][4],&g_998}}};
    int32_t l_1077[4] = {0x85313A2AL,0x85313A2AL,0x85313A2AL,0x85313A2AL};
    uint8_t *l_1116[4][7] = {{&g_342,&g_342,&g_342,&g_342,&g_342,&g_755[7][0][0],&g_755[6][0][0]},{&g_755[7][0][0],&g_755[6][0][0],(void*)0,&g_755[6][0][0],&g_342,&g_755[6][0][0],&g_342},{(void*)0,&g_755[5][0][0],&g_755[5][0][0],(void*)0,&g_342,&g_755[6][0][0],&g_755[7][0][0]},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],(void*)0,(void*)0,(void*)0,(void*)0}};
    int32_t l_1129 = 0xF6BC2643L;
    int16_t ***l_1178 = &g_637;
    int8_t l_1245 = 0x83L;
    int32_t l_1253 = 0xAE3877F4L;
    int32_t l_1254[8][9][2] = {{{0L,0L},{0xB290ED75L,0L},{1L,(-3L)},{0L,0x9C68D528L},{0x88A3819AL,0L},{0L,0xB290ED75L},{0L,0L},{0x88A3819AL,0x9C68D528L},{0L,(-3L)}},{{1L,0L},{0xB290ED75L,0L},{0L,(-1L)},{1L,0x9C68D528L},{(-1L),0x9C68D528L},{1L,(-1L)},{0L,0L},{0xB290ED75L,0L},{1L,(-3L)}},{{0L,0x9C68D528L},{0x88A3819AL,0L},{0L,0xB290ED75L},{0L,0L},{0x88A3819AL,0x9C68D528L},{0L,(-3L)},{1L,0L},{0xB290ED75L,0L},{0L,(-1L)}},{{1L,0x9C68D528L},{(-1L),0x9C68D528L},{1L,(-1L)},{0L,0L},{0xB290ED75L,0L},{1L,(-3L)},{0L,0x9C68D528L},{0x88A3819AL,0L},{0L,0xB290ED75L}},{{0L,0L},{0x88A3819AL,0x9C68D528L},{0L,(-3L)},{1L,0L},{0xB290ED75L,0L},{0L,(-1L)},{1L,0x9C68D528L},{(-1L),0x9C68D528L},{1L,(-1L)}},{{0L,0L},{0xB290ED75L,0L},{1L,(-3L)},{0L,0x9C68D528L},{0x88A3819AL,0L},{0L,0xB290ED75L},{0L,0L},{0x88A3819AL,0x9C68D528L},{0L,(-3L)}},{{1L,0L},{0xB290ED75L,0L},{0L,(-1L)},{1L,0x9C68D528L},{(-1L),0x9C68D528L},{1L,(-1L)},{0L,0L},{0xB290ED75L,0L},{1L,(-3L)}},{{0L,0x9C68D528L},{0x88A3819AL,0L},{0L,0xB290ED75L},{0L,0L},{0x88A3819AL,0x9C68D528L},{0L,(-3L)},{1L,0L},{0xB290ED75L,0L},{0L,(-1L)}}};
    int32_t *l_1260 = (void*)0;
    int32_t *l_1261[6][3][10] = {{{(void*)0,&g_44,(void*)0,&g_172,&g_172,(void*)0,&g_44,(void*)0,(void*)0,&g_172},{(void*)0,(void*)0,&l_1077[19061],&g_172,&g_453,&l_1077[19061],&g_44,&l_1077[19061],&g_453,&g_172},{&l_1077[19061],&g_44,&l_1077[19061],&g_453,&g_172,&l_1077[19061],(void*)0,(void*)0,&g_453,&g_453}},{{(void*)0,&g_44,(void*)0,&g_172,&g_172,(void*)0,&g_44,(void*)0,(void*)0,&g_172},{(void*)0,&l_1254[18715][7363][13203],&l_1077[19061],&l_1077[19061],(void*)0,&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061]},{&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061],&l_1077[19061],&l_1254[18715][7363][13203],(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_453,&l_1077[30216],&l_1077[19061],&l_1077[19061],&l_1077[30216],&g_453,(void*)0,(void*)0,&l_1077[19061]},{(void*)0,&l_1254[18715][7363][13203],&l_1077[19061],&l_1077[19061],(void*)0,&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061]},{&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061],&l_1077[19061],&l_1254[18715][7363][13203],(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_453,&l_1077[30216],&l_1077[19061],&l_1077[19061],&l_1077[30216],&g_453,(void*)0,(void*)0,&l_1077[19061]},{(void*)0,&l_1254[18715][7363][13203],&l_1077[19061],&l_1077[19061],(void*)0,&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061]},{&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061],&l_1077[19061],&l_1254[18715][7363][13203],(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_453,&l_1077[30216],&l_1077[19061],&l_1077[19061],&l_1077[30216],&g_453,(void*)0,(void*)0,&l_1077[19061]},{(void*)0,&l_1254[18715][7363][13203],&l_1077[19061],&l_1077[19061],(void*)0,&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061]},{&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061],&l_1077[19061],&l_1254[18715][7363][13203],(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_453,&l_1077[30216],&l_1077[19061],&l_1077[19061],&l_1077[30216],&g_453,(void*)0,(void*)0,&l_1077[19061]},{(void*)0,&l_1254[18715][7363][13203],&l_1077[19061],&l_1077[19061],(void*)0,&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061]},{&l_1077[19061],&g_453,&l_1077[19061],(void*)0,&l_1077[19061],&l_1077[19061],&l_1254[18715][7363][13203],(void*)0,(void*)0,(void*)0}}};
    uint8_t l_1262 = 0xB1L;
    int i, j, k;
    for (g_157 = (-25); (g_157 <= (-1)); g_157++)
    { /* block id: 416 */
        int64_t *l_988 = &g_64[1][2];
        int64_t **l_987[2][9] = {{(void*)0,&l_986,&l_988,&l_986,(void*)0,&l_988,&l_988,&l_988,&l_988},{(void*)0,&l_986,&l_988,&l_986,(void*)0,&l_988,&l_988,&l_988,&l_988}};
        int32_t *l_991[9] = {&g_453,&g_453,&g_453,&g_453,&g_453,&g_453,&g_453,&g_453,&g_453};
        uint16_t l_1037[9] = {65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL,65527UL};
        struct S3 ** const l_1069[2][3] = {{&g_296,&g_296,&g_296},{(void*)0,(void*)0,(void*)0}};
        int32_t l_1099[4][9][7] = {{{1L,0xABE22E96L,0xEE045440L,0xABE22E96L,1L,0x714C82DAL,0xEE045440L},{0x5A736AFCL,6L,1L,0xED55FA8AL,0x74F47905L,0L,0x42E712CBL},{1L,0xFC2E069FL,(-6L),0x714C82DAL,(-6L),0xFC2E069FL,1L},{0x5A736AFCL,0xED55FA8AL,0x42E712CBL,0x74F47905L,6L,1L,1L},{1L,0xFC2E069FL,0x66DB45FCL,0xDCB44D46L,1L,0xDCB44D46L,0x66DB45FCL},{6L,6L,0x42E712CBL,1L,0x5A736AFCL,0L,0xED55FA8AL},{(-6L),0xABE22E96L,(-6L),0xDCB44D46L,1L,0xABE22E96L,1L},{0x74F47905L,1L,1L,0x74F47905L,0x5A736AFCL,0x42E712CBL,1L},{1L,0x714C82DAL,0xEE045440L,0x714C82DAL,1L,0xABE22E96L,0xEE045440L}},{{0L,6L,0xED55FA8AL,0xED55FA8AL,6L,0L,1L},{1L,0xDCB44D46L,(-6L),0xABE22E96L,(-6L),0xDCB44D46L,1L},{0L,0xED55FA8AL,1L,0x74F47905L,0x74F47905L,1L,0xED55FA8AL},{1L,0xDCB44D46L,0x66DB45FCL,0xFC2E069FL,1L,0xFC2E069FL,0x66DB45FCL},{0x74F47905L,6L,1L,1L,0L,0L,1L},{(-6L),0x714C82DAL,(-6L),0xFC2E069FL,1L,0x714C82DAL,1L},{6L,1L,0xED55FA8AL,0x74F47905L,0L,0x42E712CBL,0x42E712CBL},{1L,0xABE22E96L,0xEE045440L,0xABE22E96L,1L,0x714C82DAL,0xEE045440L},{0x5A736AFCL,6L,1L,0xED55FA8AL,0x74F47905L,0L,0x42E712CBL}},{{1L,0xFC2E069FL,(-6L),0x714C82DAL,(-6L),0xFC2E069FL,1L},{0x5A736AFCL,0xED55FA8AL,0x42E712CBL,0x74F47905L,6L,1L,1L},{1L,0xFC2E069FL,0x66DB45FCL,0xDCB44D46L,1L,0xDCB44D46L,0x66DB45FCL},{6L,6L,0x42E712CBL,1L,0x5A736AFCL,0L,0xED55FA8AL},{(-6L),0xABE22E96L,(-6L),0xDCB44D46L,1L,0xABE22E96L,1L},{0x74F47905L,1L,1L,0x74F47905L,0x5A736AFCL,0x42E712CBL,1L},{1L,0x714C82DAL,0xEE045440L,0x714C82DAL,1L,0xABE22E96L,0xEE045440L},{0L,6L,0xED55FA8AL,0xED55FA8AL,6L,0L,1L},{1L,0xDCB44D46L,(-6L),0xABE22E96L,(-6L),0xDCB44D46L,1L}},{{0L,0xED55FA8AL,1L,0x74F47905L,0x74F47905L,1L,0xED55FA8AL},{1L,0xDCB44D46L,0x66DB45FCL,0xFC2E069FL,1L,0xFC2E069FL,0x66DB45FCL},{0x74F47905L,6L,1L,1L,0L,0L,1L},{(-6L),0x714C82DAL,(-6L),0xFC2E069FL,1L,0x714C82DAL,1L},{6L,1L,0xED55FA8AL,0x74F47905L,0L,0x42E712CBL,0x42E712CBL},{1L,0xABE22E96L,0xEE045440L,0xABE22E96L,1L,0x714C82DAL,0xEE045440L},{0x5A736AFCL,6L,1L,0xED55FA8AL,0x74F47905L,0L,0x42E712CBL},{1L,0xFC2E069FL,(-6L),0x714C82DAL,(-6L),0xFC2E069FL,1L},{0x5A736AFCL,0xED55FA8AL,0x42E712CBL,0x74F47905L,6L,1L,1L}}};
        int32_t l_1101 = 5L;
        uint64_t l_1148 = 0xFCEA154F005BE82DLL;
        struct S2 *l_1179 = &g_1180;
        int16_t *** const l_1225 = &g_637;
        uint16_t l_1248[5][1][9] = {{{0x82BCL,0x82BCL,0xED62L,0x5ADFL,1UL,0xB2DFL,1UL,0x82BCL,0UL}},{{65535UL,0x4010L,0UL,0x5ADFL,0x82BCL,1UL,65535UL,65535UL,1UL}},{{0x5ADFL,0x4010L,0xED62L,0x4010L,0x5ADFL,0UL,65535UL,0x5ADFL,1UL}},{{65535UL,0x82BCL,0x26BFL,65535UL,1UL,0xED62L,65535UL,65535UL,0UL}},{{0x82BCL,65535UL,0UL,1UL,1UL,0UL,65535UL,0x82BCL,0x26BFL}}};
        uint16_t *l_1251[5] = {&g_977,&g_977,&g_977,&g_977,&g_977};
        int64_t l_1252[7][2] = {{0L,0xE454641EC3B6DBB9LL},{0xE454641EC3B6DBB9LL,0L},{0xE454641EC3B6DBB9LL,0xE454641EC3B6DBB9LL},{0L,0xE454641EC3B6DBB9LL},{0xE454641EC3B6DBB9LL,0L},{0xE454641EC3B6DBB9LL,0xE454641EC3B6DBB9LL},{0L,0xE454641EC3B6DBB9LL}};
        int32_t l_1255 = (-1L);
        int i, j, k;
        if ((l_992 &= (((l_986 != (g_989 = l_986)) ^ l_990) && p_113)))
        { /* block id: 419 */
            uint32_t * const *l_994 = &g_289[4];
            uint32_t * const **l_995 = (void*)0;
            uint32_t * const **l_996 = &l_994;
            struct S2 **l_1002[4][1];
            int32_t l_1009[10] = {1L,0xA350A670L,0x2FF7A079L,0xA350A670L,1L,1L,0xA350A670L,0x2FF7A079L,0xA350A670L,1L};
            int32_t l_1049 = 0L;
            uint16_t *****l_1068 = &g_1065[2];
            int16_t ***l_1071 = &g_637;
            int16_t ****l_1070 = &l_1071;
            int16_t *****l_1072 = &l_1070;
            int32_t l_1076[7][1] = {{(-10L)},{0xD576077FL},{(-10L)},{0xD576077FL},{(-10L)},{0xD576077FL},{(-10L)}};
            int i, j;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1002[i][j] = &l_997[5538][6910][13629];
            }
            (*l_996) = ((l_993 , g_749) , l_994);
            g_1003 = l_997[5538][6910][13629];
            if (l_993.f0)
            { /* block id: 422 */
                int32_t l_1019 = 1L;
                int32_t l_1028 = 0x52ADF0DEL;
                int32_t l_1032 = 3L;
                uint8_t l_1043 = 0xF6L;
                for (g_489 = 0; (g_489 <= 7); g_489 += 1)
                { /* block id: 425 */
                    uint32_t *l_1020 = (void*)0;
                    uint32_t *l_1021[9];
                    uint16_t **l_1025 = &g_679;
                    uint16_t ***l_1024 = &l_1025;
                    uint16_t ****l_1023 = &l_1024;
                    uint16_t *****l_1022 = &l_1023;
                    int32_t l_1026 = 0x7804FB39L;
                    int32_t l_1030 = 1L;
                    uint64_t l_1034 = 18446744073709551615UL;
                    int i, j;
                    for (i = 0; i < 9; i++)
                        l_1021[i] = (void*)0;
                    g_292.f4 = (l_990 = ((((0UL < ((!((g_999.f4 || (+(safe_rshift_func_uint16_t_u_s_unsafe_macro/*39*//* ___SAFE__OP */((4294967289UL ^ ((l_1009[8] , (void*)0) == (g_570[g_489][g_489] = g_570[g_489][g_489]))), 8)))) || (((l_1009[6164] = ((((((safe_mod_func_int16_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*41*//* ___SAFE__OP */(p_112, (safe_lshift_func_int32_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */((((*g_679) = (((safe_lshift_func_uint32_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((!(*g_679)), l_993.f2)) , (-1L)) || l_1019)) , l_990), p_112)))), l_1009[8])) <= 0xF581L) && l_1009[8]) | g_1004.f1) <= p_112) >= l_992)) && 4L) , 0xD1C0EBE3L))) || l_1019)) | g_456) , l_1022) == (void*)0));
                    for (g_159 = 0; (g_159 <= 7); g_159 += 1)
                    { /* block id: 433 */
                        l_1019 = l_1019;
                    }
                    for (g_599.f7 = 0; (g_599.f7 <= 7); g_599.f7 += 1)
                    { /* block id: 438 */
                        int32_t l_1027 = 0x57591B35L;
                        int32_t l_1029 = 0x9160C44FL;
                        int32_t l_1031 = 0x4CEBD676L;
                        int32_t l_1033 = 2L;
                        int i, j;
                        --l_1034;
                        l_1037[1]++;
                    }
                }
                for (g_604 = 10; (g_604 != 46); g_604 = safe_add_func_uint32_t_u_u_unsafe_macro/*44*//* ___SAFE__OP */(g_604, 4))
                { /* block id: 445 */
                    int64_t l_1042[9][1] = {{0x082002E0A437DADFLL},{0x082002E0A437DADFLL},{(-1L)},{0x082002E0A437DADFLL},{0x082002E0A437DADFLL},{(-1L)},{0x082002E0A437DADFLL},{0x082002E0A437DADFLL},{(-1L)}};
                    int i, j;
                    l_1043++;
                    return p_113;
                }
                if (l_993.f0)
                    continue;
            }
            else
            { /* block id: 450 */
                uint32_t l_1046 = 0x1D84D87CL;
                ++l_1046;
                return l_1049;
            }
            l_990 |= (l_1077[19061] = (((l_1076[1261][18029] |= (safe_lshift_func_uint16_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*46*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */(((+(safe_unary_minus_func_uint16_t_u_unsafe_macro/*48*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */((((p_113 != (safe_lshift_func_int64_t_s_s_unsafe_macro/*50*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*51*//* ___SAFE__OP */(0x7C1CB519L, ((l_1068 = g_1064) == (void*)0))), ((void*)0 == l_1069[1][16427])))) , ((*l_1072) = l_1070)) == (l_1009[5905] , g_1073[3][0])), (-1L)))))) && g_1004.f6), g_599.f4)), 0xA1L)), l_993.f2))) >= l_1009[13432]) || p_112));
        }
        else
        { /* block id: 459 */
            l_992 = p_113;
        }
        for (g_36 = 0; (g_36 != 30); g_36 = safe_add_func_int32_t_s_s_unsafe_macro/*52*//* ___SAFE__OP */(g_36, 1))
        { /* block id: 464 */
            struct S2 **l_1080 = &g_1003;
            uint8_t *l_1094[10][4][5] = {{{&g_755[6][0][0],&g_755[6][0][0],(void*)0,&g_755[6][0][0],(void*)0},{&g_755[6][0][0],&g_755[6][0][0],&g_342,&g_755[6][0][0],(void*)0},{&g_755[6][0][0],&g_342,&g_342,&g_755[6][0][0],&g_755[6][0][0]},{&g_755[6][0][0],&g_755[6][0][0],(void*)0,&g_755[6][0][0],(void*)0}},{{&g_755[6][0][0],&g_755[6][0][0],&g_342,&g_755[6][0][0],(void*)0},{&g_755[6][0][0],&g_342,&g_342,&g_755[6][0][0],&g_755[6][0][0]},{&g_755[6][0][0],&g_755[6][0][0],(void*)0,&g_755[6][0][0],(void*)0},{&g_755[6][0][0],&g_755[6][0][0],&g_342,&g_755[6][0][0],(void*)0}},{{&g_755[6][0][0],&g_342,&g_342,&g_755[6][0][0],&g_755[6][0][0]},{&g_755[6][0][0],&g_755[6][0][0],(void*)0,&g_755[6][0][0],(void*)0},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0}},{{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]}},{{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]}},{{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0}},{{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]}},{{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]}},{{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0}},{{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]},{&g_342,&g_755[6][0][0],&g_755[2][0][1],&g_342,&g_755[4][0][2]},{&g_755[7][0][0],&g_755[2][0][1],&g_755[2][0][1],&g_755[7][0][0],(void*)0},{&g_755[7][0][0],&g_755[6][0][0],&g_755[6][0][0],&g_755[7][0][0],&g_755[4][0][2]}}};
            int32_t l_1097[7][3][3] = {{{0L,0x758EA182L,0L},{4L,0L,0L},{0x0BEE6A62L,0x758EA182L,0x9D0C6115L}},{{0xA05DFF68L,4L,0L},{0L,2L,0L},{0xA05DFF68L,0L,1L}},{{0x0BEE6A62L,2L,0x9D0C6115L},{4L,4L,1L},{0L,0x758EA182L,0L}},{{4L,0L,0L},{0x0BEE6A62L,0x758EA182L,0x9D0C6115L},{0xA05DFF68L,4L,0L}},{{0L,2L,0L},{0xA05DFF68L,0L,1L},{0x0BEE6A62L,2L,0x9D0C6115L}},{{4L,4L,1L},{0L,0x758EA182L,0L},{4L,0L,0L}},{{0x0BEE6A62L,0x758EA182L,0x9D0C6115L},{0xA05DFF68L,4L,0L},{0L,2L,0L}}};
            int16_t *l_1098[9][9] = {{&g_41[5],&g_41[1],(void*)0,&g_1083.f7,&g_41[3],&g_41[0],&g_1083.f7,&g_354,(void*)0},{&g_599.f7,(void*)0,&g_41[1],(void*)0,(void*)0,&g_41[2],&g_41[5],&g_599.f7,&g_41[2]},{&g_41[5],&g_41[3],&g_1083.f7,&g_41[2],&g_41[2],&g_678,&g_41[1],(void*)0,(void*)0},{&g_41[2],&g_41[2],&g_599.f7,&g_41[2],&g_678,&g_678,&g_41[2],&g_599.f7,&g_41[2]},{(void*)0,&g_41[2],&g_41[0],&g_41[5],&g_1083.f7,&g_41[2],&g_41[1],&g_678,&g_41[2]},{(void*)0,&g_1083.f7,&g_354,(void*)0,&g_1083.f7,&g_41[0],&g_678,(void*)0,&g_41[2]},{(void*)0,&g_41[2],&g_678,(void*)0,&g_1083.f7,&g_1083.f7,(void*)0,&g_41[5],(void*)0},{&g_41[0],&g_41[2],&g_1083.f7,&g_678,(void*)0,&g_1083.f7,(void*)0,&g_678,&g_1083.f7},{&g_41[3],&g_41[3],&g_41[2],(void*)0,&g_41[0],&g_678,&g_678,(void*)0,&g_41[1]}};
            const uint64_t l_1100 = 0UL;
            int32_t l_1150 = 0x77132B1BL;
            int32_t **l_1155 = &l_991[684];
            uint32_t l_1159[7][1] = {{18446744073709551611UL},{0x2A56497CL},{18446744073709551611UL},{0x2A56497CL},{18446744073709551611UL},{0x2A56497CL},{18446744073709551611UL}};
            int32_t l_1228[6][2] = {{(-5L),(-5L)},{0x57EC37A9L,(-5L)},{(-5L),0x57EC37A9L},{(-5L),(-5L)},{0x57EC37A9L,(-5L)},{(-5L),0x57EC37A9L}};
            int i, j, k;
            if ((((g_464 , (((*l_1080) = g_1003) == (void*)0)) , (g_1081 = g_1081)) != ((safe_lshift_func_int8_t_s_u_unsafe_macro/*53*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*54*//* ___SAFE__OP */((((((((((((safe_lshift_func_int16_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */((((**g_1067) &= (safe_add_func_uint16_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */((++g_342), p_113)), (((l_1099[2][30974][29925] = l_1097[9565][2537][2]) != 0xF498L) , (l_1100 || l_1100))))) || 0xED5EL), 2)) , (*g_296)) , p_112) < 4294967295UL) < 0xF642E5179A0EBAF7LL) ^ l_992) , 4294967295UL) || 0x412C64CEL) | l_993.f0) && l_1101) > 0x3BL), p_113)), g_157)) , (void*)0)))
            { /* block id: 470 */
                uint32_t *l_1127[1];
                struct S2 **l_1128 = &l_997[5538][6910][13629];
                int32_t l_1130[3];
                int i;
                for (i = 0; i < 1; i++)
                    l_1127[i] = &g_460;
                for (i = 0; i < 3; i++)
                    l_1130[i] = (-10L);
                l_992 &= (l_1130[28545] = (safe_mul_func_int16_t_s_s_unsafe_macro/*58*//* ___SAFE__OP */((((void*)0 != &g_637) & (((safe_sub_func_int32_t_s_s_unsafe_macro/*59*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*60*//* ___SAFE__OP */((((((safe_add_func_uint32_t_u_u_unsafe_macro/*61*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */((p_112 || (l_1077[19061] = (p_113 < ((((l_1116[1445][1] == ((9UL | (safe_rshift_func_int8_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*64*//* ___SAFE__OP */(p_112, (safe_sub_func_int32_t_s_s_unsafe_macro/*65*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*66*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*67*//* ___SAFE__OP */(((&l_990 == (void*)0) || p_113), p_113)), 14)), p_112)))), 4))) , (void*)0)) | p_112) > g_1000[7][4].f5) , p_112)))), 1L)) && 0xB6974E3FL), p_113)) , &g_1003) == l_1128) || 0UL) ^ p_112), p_112)), l_993.f1)) >= (-1L)) > l_1129)), 65535UL)));
                return l_1130[22603];
            }
            else
            { /* block id: 475 */
                int32_t *l_1131 = &l_1097[27379][1][1];
                int32_t **l_1132 = &l_1131;
                int8_t *l_1139[1][9][8] = {{{&g_456,(void*)0,&g_749,&g_500,&g_456,&g_500,&g_749,&g_500},{&g_749,(void*)0,&g_500,&g_500,&g_500,(void*)0,&g_749,&g_456},{(void*)0,&g_500,&g_500,&g_500,&g_500,&g_456,(void*)0,&g_456},{&g_500,&g_500,&g_500,&g_500,&g_500,&g_500,&g_500,&g_500},{(void*)0,&g_500,(void*)0,&g_456,&g_500,&g_500,&g_500,(void*)0},{&g_749,&g_749,&g_749,&g_500,&g_456,&g_500,&g_749,&g_749},{&g_456,&g_500,(void*)0,(void*)0,(void*)0,&g_500,&g_500,&g_749},{&g_749,&g_500,&g_500,&g_500,&g_456,&g_456,&g_500,&g_500},{&g_500,&g_500,(void*)0,&g_500,(void*)0,(void*)0,&g_500,&g_500}}};
                int32_t l_1149 = 0x21D3E4FFL;
                int i, j, k;
                if (p_113)
                    break;
                (*l_1132) = l_1131;
                l_1150 |= (safe_mul_func_uint16_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */((l_1149 |= (safe_sub_func_uint16_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */((((((g_500 = (p_113 ^= (*l_1131))) & g_157) & ((**l_1132) > ((((*g_242) != (*l_1132)) , (((safe_rshift_func_int64_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */(0x922A68D72E53961FLL, 55)) < p_112) >= (safe_rshift_func_uint64_t_u_s_unsafe_macro/*72*//* ___SAFE__OP */(0UL, 40)))) , (l_1129 = (l_1148 = ((safe_add_func_uint8_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */((g_755[6][0][0] = (safe_mul_func_uint64_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */((&g_1003 != l_1080), 0xDF0CC1A85A818C9DLL))), p_112)) && l_1097[9565][2537][2])))))) | l_1097[9565][2537][2]) != 0xD293L), p_112))), l_1097[11769][19523][18226])), 0x0501L));
            }
            l_1097[13666][0][1357] |= (func_53(&l_1100, ((-1L) > (safe_mul_func_uint16_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */(1UL, (l_1077[19061] = 0xE938L)))), (p_112--), &g_172) , l_993.f0);
            (*l_1155) = &l_1097[5][28305][17756];
        }
        l_1077[19061] = ((((**g_1067) < (0xA04CL && ((safe_lshift_func_int8_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */((p_112 > (((g_342--) | (safe_sub_func_uint16_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */(l_990, (safe_unary_minus_func_int8_t_s_unsafe_macro/*80*//* ___SAFE__OP */(((safe_div_func_int16_t_s_s_unsafe_macro/*81*//* ___SAFE__OP */(((safe_add_func_uint8_t_u_u_unsafe_macro/*82*//* ___SAFE__OP */(l_1245, (((safe_sub_func_uint16_t_u_u_unsafe_macro/*83*//* ___SAFE__OP */((l_1248[5881][25840][3] >= (safe_lshift_func_uint16_t_u_u_unsafe_macro/*84*//* ___SAFE__OP */((g_1257--), p_113))), 0xE0F5L)) ^ g_999.f4) == l_993.f2))) , l_1245), p_112)) <= 2L))))), p_113))) & p_113)), 5)), p_113)) > 0x0E095AC7L))) > 18446744073709551612UL) | p_112);
    }
    l_1262 &= 0xFEB1912EL;
    return g_1263;
}


/* ------------------------------------------ */
/* 
 * reads : g_97 g_41 g_15 g_242 g_243 g_292.f0 g_342 g_172 g_350 g_296 g_297 g_292 g_356 g_65 g_341
 * writes: g_157 g_172 g_97 g_36 g_46 g_64 g_342 g_41 g_354 g_356 g_65 g_44
 */
static int32_t  func_117(int32_t  p_118, int16_t * p_119, uint16_t * p_120)
{ /* block id: 99 */
    uint32_t l_329 = 4294967287UL;
    int32_t l_338 = (-9L);
    int32_t l_340[1][10][10] = {{{0x7DD9766DL,0x0F4A7F7FL,0xFA70DFFAL,(-10L),(-2L),8L,1L,(-9L),0x41984293L,(-5L)},{0x7DD9766DL,0x2B7DBCEEL,0L,0x1075F8E6L,0xFA70DFFAL,0x3ACD351BL,(-5L),0x597CA0ADL,0x02920927L,0x597CA0ADL},{0x3ACD351BL,(-5L),0x597CA0ADL,0x02920927L,0x597CA0ADL,(-5L),0x3ACD351BL,0xFA70DFFAL,0x1075F8E6L,0L},{1L,0L,(-5L),0x41984293L,(-9L),1L,8L,(-2L),(-10L),0xFA70DFFAL},{0x41984293L,0L,0x9372773EL,0x7DD9766DL,1L,5L,0x3ACD351BL,0L,(-5L),(-5L)},{5L,(-5L),0x02920927L,0x0084BEE1L,0x0084BEE1L,0x02920927L,(-5L),5L,0x2B7DBCEEL,0L},{0x9372773EL,0x2B7DBCEEL,(-9L),0x597CA0ADL,0x1F99BF46L,1L,1L,0xED74E0BBL,0x3ACD351BL,0x0084BEE1L},{0x1075F8E6L,0x0F4A7F7FL,(-9L),0x1F99BF46L,0x02920927L,0xED74E0BBL,5L,5L,(-2L),1L},{0L,0L,0x02920927L,0L,(-5L),0L,0x02920927L,0L,0L,8L},{1L,0x3ACD351BL,0x9372773EL,8L,0x354D59C3L,5L,1L,(-2L),(-9L),0L}}};
    struct S3 *l_352 = &g_297;
    const uint64_t * const l_376 = &g_159;
    int16_t *l_381 = &g_354;
    int16_t **l_380 = &l_381;
    uint64_t *l_384 = &g_25;
    int32_t *l_387 = &g_15;
    int32_t **l_386 = &l_387;
    int32_t ***l_385 = &l_386;
    struct S3 l_391 = {2,76,1,713,199,-524};
    int32_t l_486 = 0x0EB32F37L;
    struct S0 l_543 = {0xD5EA108350CA4558LL,2UL,302};
    uint16_t *l_562 = (void*)0;
    uint16_t **l_561[6][3] = {{&l_562,&l_562,&l_562},{&l_562,&l_562,&l_562},{&l_562,&l_562,&l_562},{&l_562,&l_562,&l_562},{&l_562,&l_562,&l_562},{&l_562,&l_562,&l_562}};
    uint16_t ***l_560 = &l_561[14711][22270];
    struct S1 *l_598 = &g_599;
    uint8_t l_618 = 0x5EL;
    uint8_t l_633 = 0UL;
    int16_t l_750 = 0L;
    int32_t l_891 = (-1L);
    const int64_t l_960 = 0x0838F0236DD5CCDELL;
    uint32_t **l_980 = &g_289[3];
    uint32_t ***l_979 = &l_980;
    uint32_t ****l_978 = &l_979;
    int i, j, k;
    if (l_329)
    { /* block id: 100 */
        int32_t *l_332 = &g_15;
        int32_t l_339[7] = {0x367FBF12L,0x367FBF12L,0x367FBF12L,0x367FBF12L,0x367FBF12L,0x367FBF12L,0x367FBF12L};
        struct S3 *l_359 = (void*)0;
        int i;
        for (g_157 = 6; (g_157 >= 0); g_157 -= 1)
        { /* block id: 103 */
            int32_t *l_330 = (void*)0;
            int32_t *l_331 = &g_172;
            int32_t l_337[4][7][5] = {{{3L,(-3L),(-9L),(-8L),0x1078F472L},{(-1L),0xF441BDDDL,0xF441BDDDL,(-1L),(-8L)},{0x8291F714L,2L,1L,0x348B5250L,(-10L)},{0xF441BDDDL,0x8291F714L,0x4A67104AL,0x6FDB41F9L,0x1078F472L},{0x12492859L,0x6FDB41F9L,(-8L),0x348B5250L,1L},{0xA29DE70FL,0xA3D898C3L,(-1L),(-1L),0L},{(-9L),(-10L),0x4A67104AL,(-8L),0xCE309313L}},{{0x348B5250L,0x0A8E17AFL,1L,0xCE309313L,0x6FDB41F9L},{0x348B5250L,0x12492859L,0L,2L,2L},{(-9L),0x8291F714L,(-9L),0x0A8E17AFL,0x12492859L},{0xA29DE70FL,(-1L),0x6FDB41F9L,0xA3D898C3L,(-9L)},{0x12492859L,0L,(-6L),2L,0L},{0xF441BDDDL,(-3L),(-1L),(-6L),0x4A67104AL},{0xB460BE90L,1L,(-6L),3L,5L}},{{0x6FDB41F9L,0x1F4020B1L,(-1L),0x6FDB41F9L,3L},{(-1L),0xF441BDDDL,0L,(-8L),3L},{0x1F4020B1L,(-1L),5L,(-8L),5L},{(-8L),(-8L),0x8291F714L,0x0A8E17AFL,0x4A67104AL},{0x26F0E8B8L,0xC3ADBA4FL,0x2BFCDB38L,0x0BB737AEL,0x1F4020B1L},{(-1L),0x2BFCDB38L,5L,3L,(-6L)},{0x0A8E17AFL,0xC3ADBA4FL,0x1078F472L,(-1L),(-8L)}},{{(-8L),(-8L),0xF2732374L,0L,0xF441BDDDL},{(-1L),(-1L),(-6L),0xC3ADBA4FL,(-1L)},{(-9L),0xF441BDDDL,(-10L),0xC3ADBA4FL,(-1L)},{(-1L),0x1F4020B1L,0L,0L,0x1F4020B1L},{0x1F4020B1L,1L,(-1L),(-1L),0L},{0xB460BE90L,1L,2L,3L,(-2L)},{0x0BB737AEL,0x1F4020B1L,0xF2732374L,0x0BB737AEL,3L}}};
            int i, j, k;
            (*l_331) = 0x304C94EDL;
            for (g_97 = 1; (g_97 <= 5); g_97 += 1)
            { /* block id: 107 */
                int32_t *l_334 = &g_172;
                int32_t *l_335 = &g_44;
                int32_t *l_336[1];
                uint8_t *l_345 = &g_342;
                int16_t *l_353 = &g_354;
                int i;
                for (i = 0; i < 1; i++)
                    l_336[i] = &g_44;
                l_330 = l_332;
                for (l_329 = 0; (l_329 <= 5); l_329 += 1)
                { /* block id: 111 */
                    int i;
                    (*l_331) = (+((*p_120) = (g_41[(g_97 + 16849)] , ((*l_332) != ((p_118 , l_334) != (*g_242))))));
                    for (g_46 = 0; g_46 < 4; g_46 += 1)
                    {
                        for (p_118 = 0; p_118 < 5; p_118 += 1)
                        {
                            g_64[g_46][p_118] = 0x2AA58F5251EB5ED7LL;
                        }
                    }
                    if (g_292.f0)
                        continue;
                }
                g_342++;
                if ((((((*l_353) = ((*l_334) , ((*l_332) , ((((*l_345)++) > ((safe_mul_func_uint64_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((g_350 != (((g_41[(g_97 + 15120)] = ((void*)0 == l_352)) , (*g_296)) , (void*)0)), (*l_332))) | l_329)) & (*l_334))))) && 0xF688L) <= l_338) > p_118))
                { /* block id: 121 */
                    return p_118;
                }
                else
                { /* block id: 123 */
                    int16_t l_355[5] = {(-4L),(-4L),(-4L),(-4L),(-4L)};
                    int i;
                    --g_356;
                }
            }
        }
        l_352 = l_359;
    }
    else
    { /* block id: 129 */
        int64_t l_370[10][6][2] = {{{1L,2L},{0xA79A1D392CCF0B8BLL,0xA79A1D392CCF0B8BLL},{(-10L),0L},{0x1B4E32C60489F0D1LL,1L},{1L,1L},{(-10L),1L}},{{0x759DA75A76652DCBLL,0xA79A1D392CCF0B8BLL},{0x759DA75A76652DCBLL,1L},{(-10L),1L},{1L,1L},{0x1B4E32C60489F0D1LL,0L},{(-10L),0xA79A1D392CCF0B8BLL}},{{0xA79A1D392CCF0B8BLL,2L},{1L,0L},{1L,0xEE13FE9918F8D0A3LL},{(-1L),(-1L)},{(-1L),0xA79A1D392CCF0B8BLL},{1L,(-3L)}},{{(-5L),1L},{1L,1L},{(-5L),(-3L)},{1L,0xA79A1D392CCF0B8BLL},{(-1L),(-1L)},{(-1L),0xEE13FE9918F8D0A3LL}},{{1L,0L},{1L,2L},{0xA79A1D392CCF0B8BLL,0xA79A1D392CCF0B8BLL},{(-10L),0L},{0x1B4E32C60489F0D1LL,1L},{1L,1L}},{{(-10L),1L},{0x759DA75A76652DCBLL,0xA79A1D392CCF0B8BLL},{0x759DA75A76652DCBLL,1L},{(-10L),1L},{1L,1L},{0x1B4E32C60489F0D1LL,0L}},{{(-10L),0xA79A1D392CCF0B8BLL},{0xA79A1D392CCF0B8BLL,2L},{1L,0L},{1L,0xEE13FE9918F8D0A3LL},{(-1L),(-1L)},{(-1L),0xA79A1D392CCF0B8BLL}},{{1L,(-3L)},{(-5L),1L},{1L,1L},{(-5L),(-3L)},{1L,0xA79A1D392CCF0B8BLL},{(-1L),(-1L)}},{{(-1L),0xEE13FE9918F8D0A3LL},{1L,0L},{1L,2L},{0xA79A1D392CCF0B8BLL,0xA79A1D392CCF0B8BLL},{(-10L),0L},{0x1B4E32C60489F0D1LL,(-1L)}},{{(-5L),1L},{0x1CB5A17DCD40608DLL,(-5L)},{(-3L),1L},{(-3L),(-5L)},{0x1CB5A17DCD40608DLL,1L},{(-5L),(-1L)}}};
        struct S0 l_375[7][6] = {{{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x17655FDF3245BCAALL,0UL,395},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611}},{{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x17655FDF3245BCAALL,0UL,395},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611}},{{18446744073709551608UL,18446744073709551614UL,127},{18446744073709551608UL,18446744073709551614UL,127},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xE62D1187817E4CFDLL,0xE2F480426B1E962DLL,587},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{18446744073709551608UL,18446744073709551614UL,127}},{{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0x17655FDF3245BCAALL,0UL,395},{0xE62D1187817E4CFDLL,0xE2F480426B1E962DLL,587},{0xE62D1187817E4CFDLL,0xE2F480426B1E962DLL,587},{0x17655FDF3245BCAALL,0UL,395},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593}},{{18446744073709551608UL,18446744073709551614UL,127},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xE62D1187817E4CFDLL,0xE2F480426B1E962DLL,587},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{18446744073709551608UL,18446744073709551614UL,127},{18446744073709551608UL,18446744073709551614UL,127}},{{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x17655FDF3245BCAALL,0UL,395},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611}},{{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x17655FDF3245BCAALL,0UL,395},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0x998A925A2E80C138LL,0x6E898332D3BA066CLL,593},{0xED41E486DE831855LL,0xFB40BA595F55AF59LL,611}}};
        int32_t *l_377 = (void*)0;
        uint16_t l_378 = 0x4AB2L;
        int32_t *l_379 = &g_44;
        int i, j, k;
        (*l_379) = (safe_div_func_uint64_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */((((safe_lshift_func_int64_t_s_s_unsafe_macro/*87*//* ___SAFE__OP */((((safe_lshift_func_uint8_t_u_s_unsafe_macro/*88*//* ___SAFE__OP */(p_118, ((p_118 != (l_370[22215][27944][2950] != ((void*)0 == &g_242))) <= (((safe_div_func_uint16_t_u_u_unsafe_macro/*89*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s_unsafe_macro/*90*//* ___SAFE__OP */((((l_375[2][0] , (func_53(l_376, p_118, p_118, l_377) , g_292.f1)) != p_118) & p_118), p_118)) | p_118), 4L)) , l_378) < p_118)))) == p_118) > p_118), 20)) && l_340[17918][22909][32720]) != g_341), p_118));
    }
    return p_118;
}


/* ------------------------------------------ */
/* 
 * reads : g_97 g_202 g_44 g_15 g_65 g_172 g_242 g_46 g_243 g_36 g_159 g_173 g_64 g_41 g_158 g_308 g_157 g_297.f2 g_297.f5
 * writes: g_97 g_158 g_44 g_172 g_159 g_173 g_255 g_41 g_46 g_65 g_289 g_296 g_308
 */
static uint8_t  func_121(int64_t * p_122, int8_t  p_123, const uint32_t * p_124, int32_t * p_125, int32_t * p_126)
{ /* block id: 46 */
    int32_t l_179[6];
    uint32_t l_185 = 7UL;
    int32_t l_205 = 0x1DFB01F2L;
    int64_t *l_254 = &g_158;
    int64_t **l_253[3][1][8] = {{{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254,&l_254,&l_254}},{{(void*)0,&l_254,&l_254,(void*)0,(void*)0,(void*)0,&l_254,&l_254}},{{&l_254,(void*)0,&l_254,&l_254,(void*)0,&l_254,(void*)0,&l_254}}};
    int64_t ***l_252 = &l_253[10570][22494][7];
    const int32_t *l_271 = &g_46;
    const int32_t **l_270 = &l_271;
    uint32_t l_285 = 0xB656643BL;
    struct S3 *l_291 = &g_292;
    int32_t l_301 = (-7L);
    int32_t l_302 = 0x09DD38E6L;
    int32_t l_303 = 2L;
    int32_t l_304 = (-3L);
    int32_t l_305 = (-1L);
    int32_t l_306 = (-1L);
    int32_t l_307 = 0xFDD0078BL;
    uint32_t *l_321 = &l_285;
    int32_t *l_322 = &l_301;
    int32_t *l_323 = &l_303;
    int32_t *l_324 = &l_301;
    int32_t *l_325[3][4][6] = {{{&g_8,(void*)0,&g_46,(void*)0,(void*)0,&g_46},{&g_8,&g_8,(void*)0,(void*)0,&l_307,(void*)0},{(void*)0,&g_8,(void*)0,&g_46,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_8,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_46},{(void*)0,(void*)0,&g_46,&g_46,(void*)0,(void*)0},{(void*)0,(void*)0,&g_8,(void*)0,&g_8,(void*)0},{&g_8,(void*)0,&g_46,(void*)0,(void*)0,&g_46}},{{&g_8,&g_8,(void*)0,(void*)0,&l_307,(void*)0},{(void*)0,&g_8,(void*)0,&g_46,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_8,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_46}}};
    uint64_t l_326 = 2UL;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_179[i] = 1L;
    for (g_97 = 5; (g_97 <= (-13)); g_97 = safe_sub_func_uint8_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */(g_97, 4))
    { /* block id: 49 */
        int32_t *l_180 = &g_46;
        int32_t *l_181 = &g_172;
        int32_t *l_182 = &g_46;
        int32_t *l_183 = &g_44;
        int32_t *l_184[9][6][2] = {{{&g_44,(void*)0},{&g_44,&g_44},{&g_15,&g_44},{&g_15,&g_44},{&g_44,(void*)0},{&g_44,&g_46}},{{(void*)0,&g_44},{&g_44,&g_46},{&g_46,&g_44},{&g_44,&g_44},{&g_46,&g_46},{&g_44,&g_44}},{{(void*)0,&g_46},{&g_44,(void*)0},{&g_44,&g_44},{&g_15,&g_44},{&g_15,&g_44},{&g_44,(void*)0}},{{&g_44,&g_46},{(void*)0,&g_44},{&g_44,&g_44},{&g_44,&g_44},{&g_46,&g_44},{&g_44,&g_44}},{{&g_44,(void*)0},{&g_15,&g_44},{&g_44,&g_44},{&g_44,&g_44},{&g_46,&g_44},{&g_46,&g_44}},{{&g_44,&g_44},{&g_44,&g_44},{&g_15,(void*)0},{&g_44,&g_44},{&g_44,&g_44},{&g_46,&g_44}},{{&g_44,&g_44},{&g_44,(void*)0},{&g_15,&g_44},{&g_44,&g_44},{&g_44,&g_44},{&g_46,&g_44}},{{&g_46,&g_44},{&g_44,&g_44},{&g_44,&g_44},{&g_15,(void*)0},{&g_44,&g_44},{&g_44,&g_44}},{{&g_46,&g_44},{&g_44,&g_44},{&g_44,(void*)0},{&g_15,&g_44},{&g_44,&g_44},{&g_44,&g_44}}};
        int i, j, k;
        ++l_185;
    }
    if ((!l_185))
    { /* block id: 52 */
        int16_t l_193 = 0x7ABFL;
        uint64_t *l_248 = &g_159;
        struct S3 **l_293 = &l_291;
        struct S3 *l_295 = &g_292;
        struct S3 **l_294[8][1][3] = {{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}},{{&l_295,&l_295,&l_295}}};
        int i, j, k;
        if ((&g_65[2][4] != p_124))
        { /* block id: 53 */
lbl_286:
            g_44 |= (safe_sub_func_int8_t_s_s_unsafe_macro/*92*//* ___SAFE__OP */(0x10L, ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*93*//* ___SAFE__OP */(l_193, (safe_mul_func_int32_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */((*p_126), (safe_mod_func_uint8_t_u_u_unsafe_macro/*95*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*96*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*97*//* ___SAFE__OP */((((g_202 == (void*)0) ^ l_193) <= (l_205 = (g_158 = ((void*)0 == &g_65[2][4])))), (safe_div_func_int16_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */((0x7AL != 1UL), g_97)))), 15)), 1UL)))))) < l_193)));
        }
        else
        { /* block id: 57 */
            int32_t *l_220[1];
            uint32_t l_247 = 1UL;
            int64_t **l_283[4][10][6] = {{{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,(void*)0,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,(void*)0,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254}},{{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,(void*)0,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,(void*)0,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254}},{{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,(void*)0,(void*)0,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,(void*)0,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254}},{{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,(void*)0,(void*)0,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,&l_254,&l_254,&l_254},{&l_254,&l_254,&l_254,(void*)0,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254},{&l_254,&l_254,(void*)0,&l_254,&l_254,&l_254}}};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_220[i] = &g_172;
            l_205 ^= (safe_lshift_func_uint8_t_u_s_unsafe_macro/*99*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*100*//* ___SAFE__OP */(((l_185 != l_179[18654]) , (safe_sub_func_int64_t_s_s_unsafe_macro/*101*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_u_unsafe_macro/*102*//* ___SAFE__OP */(0x21L, 1)), (safe_add_func_int16_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*104*//* ___SAFE__OP */((&g_36 == &g_36), (*p_126))), ((p_123 & (l_193 == g_97)) >= g_15)))))), g_65[2][4])), 3));
            for (g_172 = 4; (g_172 >= 0); g_172 -= 1)
            { /* block id: 61 */
                int32_t **l_241 = &l_220[0];
                uint64_t *l_249[1][4][1] = {{{&g_159},{&g_25},{&g_159},{&g_25}}};
                int32_t *l_251[9][9] = {{&g_8,&g_172,&g_44,&g_8,&g_8,&g_44,&g_172,&g_8,&g_172},{&g_8,&g_44,&g_44,&g_44,&g_44,&g_8,&g_8,&g_8,&g_44},{&g_8,&g_172,&g_172,&g_8,&g_8,&g_44,&g_8,&g_8,&g_172},{&g_8,&g_8,&g_8,&g_44,&g_46,&g_44,&g_8,&g_8,&g_8},{&g_172,&g_8,&g_8,&g_44,&g_8,&g_8,&g_172,&g_172,&g_8},{&g_44,&g_172,&g_8,&g_172,&g_44,&g_8,&g_8,&g_44,&g_172},{&g_44,&g_46,&g_44,&g_8,&g_8,&g_8,&g_8,&g_44,&g_46},{&g_46,&g_44,&g_8,&g_8,&g_8,&g_8,&g_44,&g_46,&g_44},{&g_172,&g_44,&g_8,&g_8,&g_44,&g_172,&g_8,&g_172,&g_44}};
                int32_t **l_250 = &l_251[29117][10928];
                int i, j, k;
                (*l_250) = ((*l_241) = func_127((((safe_lshift_func_int8_t_s_u_unsafe_macro/*105*//* ___SAFE__OP */((l_179[(g_172 + 2376)] <= 0xC88E312AFD501939LL), (safe_sub_func_int16_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */(9L, (safe_lshift_func_int8_t_s_u_unsafe_macro/*107*//* ___SAFE__OP */(((safe_add_func_uint8_t_u_u_unsafe_macro/*108*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*109*//* ___SAFE__OP */((!l_179[(g_172 + 2376)]), ((safe_add_func_uint16_t_u_u_unsafe_macro/*110*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*111*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*112*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u_unsafe_macro/*113*//* ___SAFE__OP */((((safe_lshift_func_uint8_t_u_u_unsafe_macro/*114*//* ___SAFE__OP */((((&p_126 == l_241) , &p_126) == g_242), ((safe_div_func_uint8_t_u_u_unsafe_macro/*115*//* ___SAFE__OP */((g_46 , p_123), 1L)) , 255UL))) , (void*)0) != (*g_242)))), l_247)), 0x88E89D45L)), 0x2DA9L)) >= p_123))), 255UL)) == 18446744073709551615UL), 7)))))) , l_248) == l_249[0][0][31984]), g_36, p_122));
                g_255 = l_252;
                for (g_158 = 0; (g_158 <= 5); g_158 += 1)
                { /* block id: 67 */
                    int32_t ***l_265 = &l_250;
                    const int32_t ***l_272 = &l_270;
                    int16_t *l_273 = &g_41[2];
                    uint32_t *l_287 = &l_285;
                    g_46 |= ((*p_125) &= (safe_rshift_func_uint64_t_u_s_unsafe_macro/*116*//* ___SAFE__OP */(0xC17A10311EA467D7LL, (((safe_mod_func_uint32_t_u_u_unsafe_macro/*117*//* ___SAFE__OP */((((+((*l_273) ^= (safe_div_func_uint32_t_u_u_unsafe_macro/*118*//* ___SAFE__OP */(((18446744073709551615UL || 0xD71B0492FC4D6C54LL) || ((g_64[0][4] == (*p_124)) ^ 0x94EEF04CL)), (safe_mod_func_int8_t_s_s_unsafe_macro/*119*//* ___SAFE__OP */((((*l_265) = (void*)0) == &p_126), (safe_div_func_int32_t_s_s_unsafe_macro/*120*//* ___SAFE__OP */((((((((*l_272) = ((safe_mod_func_uint64_t_u_u_unsafe_macro/*121*//* ___SAFE__OP */(((-3L) ^ g_97), (**l_241))) , l_270)) == &p_126) , g_36) >= 0x1B20A924ABB9B91CLL) ^ 0x7C67L) > (-9L)), 4294967295UL)))))))) | p_123) & g_158), g_64[0][4])) || g_41[2]) ^ g_173))));
                    if (g_41[4])
                    { /* block id: 73 */
                        uint32_t *l_274 = &g_65[2][4];
                        int32_t l_284 = (-7L);
                        l_205 = (18446744073709551610UL && ((((*p_125) ^= ((((++(*l_274)) != (safe_mod_func_int16_t_s_s_unsafe_macro/*122*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*123*//* ___SAFE__OP */((((safe_div_func_uint64_t_u_u_unsafe_macro/*124*//* ___SAFE__OP */(18446744073709551615UL, ((l_193 || ((p_123 , (l_283[3][1][5048] != &p_122)) , (0xABL || (l_284 != ((g_97 , g_41[1]) == p_123))))) , g_173))) ^ g_46) < p_123), g_64[0][4])), 0x3B63L))) && l_285) || 0xE907L)) | 0xB1CB8AD0L) && g_172));
                        if (l_193)
                            goto lbl_286;
                    }
                    else
                    { /* block id: 78 */
                        uint32_t **l_288[4][10][6] = {{{&l_287,&l_287,&l_287,&l_287,(void*)0,&l_287},{&l_287,&l_287,(void*)0,&l_287,&l_287,&l_287},{(void*)0,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,(void*)0,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,(void*)0,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,(void*)0,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287}},{{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{(void*)0,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,(void*)0,(void*)0},{(void*)0,(void*)0,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,(void*)0,(void*)0,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{(void*)0,&l_287,(void*)0,&l_287,&l_287,&l_287},{&l_287,(void*)0,&l_287,&l_287,&l_287,&l_287}},{{&l_287,(void*)0,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,(void*)0,&l_287},{(void*)0,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,(void*)0,&l_287,(void*)0,&l_287,(void*)0},{&l_287,&l_287,(void*)0,&l_287,&l_287,&l_287},{(void*)0,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,(void*)0,&l_287,&l_287},{&l_287,(void*)0,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287}},{{&l_287,&l_287,(void*)0,(void*)0,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{(void*)0,(void*)0,&l_287,(void*)0,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,(void*)0,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,&l_287,&l_287,&l_287,&l_287,(void*)0},{&l_287,&l_287,&l_287,&l_287,&l_287,&l_287},{&l_287,(void*)0,(void*)0,&l_287,&l_287,(void*)0}}};
                        uint32_t ***l_290 = &l_288[14748][9][29152];
                        int i, j, k;
                        (*l_290) = ((l_251[29117][10928] == (g_289[3] = l_287)) , &g_289[3]);
                    }
                }
            }
        }
        g_296 = ((*l_293) = l_291);
    }
    else
    { /* block id: 87 */
        int32_t *l_298 = &l_205;
        int32_t *l_299 = &l_205;
        int32_t *l_300[8] = {&g_44,&g_172,&g_44,&g_172,&g_44,&g_172,&g_44,&g_172};
        int i;
lbl_313:
        --g_308;
        for (l_303 = (-26); (l_303 <= (-5)); ++l_303)
        { /* block id: 91 */
            if (g_158)
                goto lbl_313;
        }
    }
    (*p_125) ^= ((*l_271) || (&p_122 != (((**l_270) | ((**l_270) && (((((**l_270) | (safe_lshift_func_uint64_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */((((safe_unary_minus_func_uint32_t_u_unsafe_macro/*126*//* ___SAFE__OP */((*p_124))) < 65527UL) == g_158), 29))) < ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */((((*l_321) = ((safe_div_func_uint16_t_u_u_unsafe_macro/*128*//* ___SAFE__OP */(0xBABAL, g_157)) ^ (**l_270))) >= 4294967295UL), (*l_271))) >= p_123)) & g_297.f2) | (**l_270)))) , (*l_252))));
    l_326--;
    return g_297.f5;
}


/* ------------------------------------------ */
/* 
 * reads : g_159 g_173
 * writes: g_159 g_173
 */
static uint32_t * func_127(uint64_t  p_128, int8_t  p_129, uint64_t * p_130)
{ /* block id: 31 */
    int32_t *l_146 = &g_44;
    int32_t *l_147 = (void*)0;
    int32_t l_148 = 0xCFD9A5CCL;
    int32_t *l_149 = &g_44;
    int32_t l_150[9][6][4] = {{{1L,(-4L),(-1L),0x60D6E8A3L},{0xA0BB31F0L,0xE7EF8C87L,0x2AD0072BL,0x81F2D68BL},{(-4L),0xF27325EFL,0x54759984L,0x4D00042AL},{0x385C65EBL,0x54759984L,0x385C65EBL,0L},{0x81F2D68BL,0xC2E694C0L,0x1A0E2963L,(-9L)},{1L,0x58545D76L,1L,0xC2E694C0L}},{{0x51AD0A0FL,(-8L),1L,0x03E92686L},{1L,0x385C65EBL,0x1A0E2963L,0x60D6E8A3L},{0x81F2D68BL,3L,0x385C65EBL,(-2L)},{0x385C65EBL,(-2L),0x54759984L,0x51AD0A0FL},{(-4L),1L,0x2AD0072BL,(-1L)},{0xA0BB31F0L,0xC2E694C0L,(-1L),0x7EA209B0L}},{{1L,(-7L),0x5B79E8ABL,0x2AA67735L},{0x51AD0A0FL,0x03E92686L,0L,0xF27325EFL},{0x54759984L,0xDA1D7361L,0x958104EEL,0x60D6E8A3L},{(-8L),0xCA001A1BL,0xCA001A1BL,(-8L)},{0xDA1D7361L,0L,0x54759984L,0xD43CF306L},{0x2AD0072BL,1L,3L,0x958104EEL}},{{0xF27325EFL,0xC2E694C0L,(-9L),0x958104EEL},{(-7L),1L,0x60D6E8A3L,0xD43CF306L},{0x51AD0A0FL,0L,(-9L),(-8L)},{1L,0xCA001A1BL,(-3L),0x60D6E8A3L},{0x03E92686L,0xDA1D7361L,0xE7EF8C87L,0xF27325EFL},{0xCA001A1BL,0x03E92686L,0x54759984L,0x2AA67735L}},{{0xE7EF8C87L,(-7L),0x4D00042AL,0x60D6E8A3L},{3L,0x1A0E2963L,0L,1L},{0L,1L,1L,0x7EA209B0L},{0x7EA209B0L,3L,0xAAD6EEDDL,3L},{0xABECF346L,0x2AA67735L,0x60D6E8A3L,0x58545D76L},{0x385C65EBL,0xD43CF306L,0xC2E694C0L,0xE7EF8C87L}},{{0x2AA67735L,0xDA1D7361L,0xD04652DBL,0x1A0E2963L},{0x2AA67735L,0L,0xC2E694C0L,(-3L)},{0x385C65EBL,0x1A0E2963L,0x60D6E8A3L,0L},{0xABECF346L,0xD04652DBL,0xAAD6EEDDL,0L},{0x7EA209B0L,(-4L),1L,0x2AD0072BL},{0L,0x51AD0A0FL,0L,0x58545D76L}},{{3L,0xC2E694C0L,0x4D00042AL,0xCA001A1BL},{0x51AD0A0FL,0x2AD0072BL,0xD04652DBL,(-1L)},{1L,0xABECF346L,0x51AD0A0FL,0x313BC257L},{0xE7EF8C87L,0x1A0E2963L,(-9L),(-9L)},{0L,0L,1L,(-9L)},{0x7EA209B0L,0xCA001A1BL,0x58545D76L,0x385C65EBL}},{{0x1FE2E2A7L,(-1L),(-3L),0x58545D76L},{(-4L),(-1L),0x2AA67735L,0x385C65EBL},{(-1L),0xCA001A1BL,0xD04652DBL,(-9L)},{0x4D00042AL,0L,1L,(-9L)},{0xDA1D7361L,0x1A0E2963L,0x5B79E8ABL,0x313BC257L},{0xD04652DBL,0xABECF346L,1L,(-1L)}},{{0x7EA209B0L,0x2AD0072BL,0x54759984L,0xCA001A1BL},{0x86A01D58L,0xC2E694C0L,1L,0x58545D76L},{0xCA001A1BL,0x51AD0A0FL,(-1L),0x2AD0072BL},{0xC2E694C0L,(-4L),0xD04652DBL,0L},{0xD43CF306L,0xD04652DBL,0xD43CF306L,0L},{0x2AD0072BL,0x1A0E2963L,0x313BC257L,(-3L)}}};
    int32_t *l_151 = &l_150[0][624][24019];
    int32_t *l_152 = &l_150[26389][17917][6554];
    int32_t *l_153 = &l_148;
    int32_t *l_154 = &l_150[2][7020][30017];
    int32_t *l_155 = &g_44;
    int32_t *l_156[7][4][7] = {{{&l_150[19014][18935][23279],&l_148,&g_44,&l_148,&l_150[19014][18935][23279],&l_150[19014][18935][23279],&l_148},{&g_15,&l_148,&g_15,&g_44,&g_44,&g_15,&l_148},{&l_148,&g_46,&g_44,&g_44,&g_46,&l_148,&g_46},{&g_15,&g_44,&g_44,&g_15,&l_148,&g_15,&g_44}},{{&l_150[19014][18935][23279],&l_150[19014][18935][23279],&l_148,&g_44,&l_148,&l_150[19014][18935][23279],&l_150[19014][18935][23279]},{&l_150[1][18736][32679],&g_44,&g_15,&g_44,&l_150[1][18736][32679],&l_150[1][18736][32679],&g_44},{&g_46,&g_46,&g_46,&l_148,&l_148,&g_46,&g_46},{&g_44,&l_148,&g_15,&g_15,&l_148,&g_44,&l_148}},{{&g_46,&l_148,&l_148,&g_46,&g_46,&g_46,&l_148},{&l_150[1][18736][32679],&l_150[1][18736][32679],&g_44,&g_15,&g_44,&l_150[1][18736][32679],&l_150[1][18736][32679]},{&l_150[19014][18935][23279],&l_148,&g_46,&g_46,&l_148,&l_148,&g_46},{&g_15,&l_150[1][18736][32679],&g_15,&g_15,&g_15,&g_15,&l_150[1][18736][32679]}},{{&g_46,&l_150[19014][18935][23279],&g_46,&g_46,&l_150[19014][18935][23279],&g_46,&l_150[19014][18935][23279]},{&g_15,&g_15,&g_15,&g_15,&l_150[1][18736][32679],&g_15,&g_15},{&l_148,&l_148,&g_46,&g_46,&g_46,&l_148,&l_148},{&g_44,&g_15,&l_148,&g_15,&g_44,&g_44,&g_15}},{{&g_44,&l_150[19014][18935][23279],&g_44,&g_46,&g_46,&g_44,&l_150[19014][18935][23279]},{&g_15,&l_150[1][18736][32679],&l_148,&l_148,&l_150[1][18736][32679],&g_15,&l_150[1][18736][32679]},{&g_44,&g_46,&g_46,&g_44,&l_150[19014][18935][23279],&g_44,&g_46},{&g_44,&g_44,&g_15,&l_148,&g_15,&g_44,&g_44}},{{&l_148,&g_46,&g_46,&g_46,&l_148,&l_148,&g_46},{&g_15,&l_150[1][18736][32679],&g_15,&g_15,&g_15,&g_15,&l_150[1][18736][32679]},{&g_46,&l_150[19014][18935][23279],&g_46,&g_46,&l_150[19014][18935][23279],&g_46,&l_150[19014][18935][23279]},{&g_15,&g_15,&g_15,&g_15,&l_150[1][18736][32679],&g_15,&g_15}},{{&l_148,&l_148,&g_46,&g_46,&g_46,&l_148,&l_148},{&g_44,&g_15,&l_148,&g_15,&g_44,&g_44,&g_15},{&g_44,&l_150[19014][18935][23279],&g_44,&g_46,&g_46,&g_44,&l_150[19014][18935][23279]},{&g_15,&l_150[1][18736][32679],&l_148,&l_148,&l_150[1][18736][32679],&g_15,&l_150[1][18736][32679]}}};
    int32_t **l_176 = &l_152;
    int i, j, k;
    ++g_159;
    for (p_129 = 0; (p_129 >= (-2)); p_129--)
    { /* block id: 35 */
        uint64_t l_165 = 7UL;
        int32_t l_168 = 0x981B1BC7L;
        int32_t l_169 = 1L;
        int32_t l_170 = 0x14682580L;
        int32_t l_171[5];
        int i;
        for (i = 0; i < 5; i++)
            l_171[i] = 0xCF6CD2DBL;
        if (p_129)
        { /* block id: 36 */
            int64_t * const l_164 = &g_64[0][4];
            (*l_151) = ((-8L) | ((void*)0 != l_164));
        }
        else
        { /* block id: 38 */
            return l_155;
        }
        ++l_165;
        g_173++;
    }
    (*l_176) = &l_148;
    return l_149;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_41[i], "g_41[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_64[i][j], "g_64[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_65[i][j], "g_65[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_204, "g_204", print_hash_value);
    transparent_crc(g_244, "g_244", print_hash_value);
    transparent_crc(g_292.f0, "g_292.f0", print_hash_value);
    transparent_crc(g_292.f1, "g_292.f1", print_hash_value);
    transparent_crc(g_292.f2, "g_292.f2", print_hash_value);
    transparent_crc(g_292.f3, "g_292.f3", print_hash_value);
    transparent_crc(g_292.f4, "g_292.f4", print_hash_value);
    transparent_crc(g_292.f5, "g_292.f5", print_hash_value);
    transparent_crc(g_297.f0, "g_297.f0", print_hash_value);
    transparent_crc(g_297.f1, "g_297.f1", print_hash_value);
    transparent_crc(g_297.f2, "g_297.f2", print_hash_value);
    transparent_crc(g_297.f3, "g_297.f3", print_hash_value);
    transparent_crc(g_297.f4, "g_297.f4", print_hash_value);
    transparent_crc(g_297.f5, "g_297.f5", print_hash_value);
    transparent_crc(g_308, "g_308", print_hash_value);
    transparent_crc(g_341, "g_341", print_hash_value);
    transparent_crc(g_342, "g_342", print_hash_value);
    transparent_crc(g_351, "g_351", print_hash_value);
    transparent_crc(g_354, "g_354", print_hash_value);
    transparent_crc(g_356, "g_356", print_hash_value);
    transparent_crc(g_447, "g_447", print_hash_value);
    transparent_crc(g_453, "g_453", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_455[i], "g_455[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_456, "g_456", print_hash_value);
    transparent_crc(g_457, "g_457", print_hash_value);
    transparent_crc(g_460, "g_460", print_hash_value);
    transparent_crc(g_464.f0, "g_464.f0", print_hash_value);
    transparent_crc(g_464.f1, "g_464.f1", print_hash_value);
    transparent_crc(g_464.f2, "g_464.f2", print_hash_value);
    transparent_crc(g_489, "g_489", print_hash_value);
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_555.f0, "g_555.f0", print_hash_value);
    transparent_crc(g_555.f1, "g_555.f1", print_hash_value);
    transparent_crc(g_555.f2, "g_555.f2", print_hash_value);
    transparent_crc(g_555.f3, "g_555.f3", print_hash_value);
    transparent_crc(g_555.f4, "g_555.f4", print_hash_value);
    transparent_crc(g_555.f5, "g_555.f5", print_hash_value);
    transparent_crc(g_555.f6, "g_555.f6", print_hash_value);
    transparent_crc(g_555.f7, "g_555.f7", print_hash_value);
    transparent_crc(g_599.f0, "g_599.f0", print_hash_value);
    transparent_crc(g_599.f1, "g_599.f1", print_hash_value);
    transparent_crc(g_599.f2, "g_599.f2", print_hash_value);
    transparent_crc(g_599.f3, "g_599.f3", print_hash_value);
    transparent_crc(g_599.f4, "g_599.f4", print_hash_value);
    transparent_crc(g_599.f5, "g_599.f5", print_hash_value);
    transparent_crc(g_599.f6, "g_599.f6", print_hash_value);
    transparent_crc(g_599.f7, "g_599.f7", print_hash_value);
    transparent_crc(g_604, "g_604", print_hash_value);
    transparent_crc(g_630, "g_630", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_631[i][j][k], "g_631[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_678, "g_678", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_755[i][j][k], "g_755[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_778, "g_778", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_998.f0, "g_998.f0", print_hash_value);
    transparent_crc(g_998.f1, "g_998.f1", print_hash_value);
    transparent_crc(g_998.f2, "g_998.f2", print_hash_value);
    transparent_crc(g_998.f3, "g_998.f3", print_hash_value);
    transparent_crc(g_998.f4, "g_998.f4", print_hash_value);
    transparent_crc(g_998.f5, "g_998.f5", print_hash_value);
    transparent_crc(g_998.f6, "g_998.f6", print_hash_value);
    transparent_crc(g_998.f7, "g_998.f7", print_hash_value);
    transparent_crc(g_998.f8, "g_998.f8", print_hash_value);
    transparent_crc(g_999.f0, "g_999.f0", print_hash_value);
    transparent_crc(g_999.f1, "g_999.f1", print_hash_value);
    transparent_crc(g_999.f2, "g_999.f2", print_hash_value);
    transparent_crc(g_999.f3, "g_999.f3", print_hash_value);
    transparent_crc(g_999.f4, "g_999.f4", print_hash_value);
    transparent_crc(g_999.f5, "g_999.f5", print_hash_value);
    transparent_crc(g_999.f6, "g_999.f6", print_hash_value);
    transparent_crc(g_999.f7, "g_999.f7", print_hash_value);
    transparent_crc(g_999.f8, "g_999.f8", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1000[i][j].f0, "g_1000[i][j].f0", print_hash_value);
            transparent_crc(g_1000[i][j].f1, "g_1000[i][j].f1", print_hash_value);
            transparent_crc(g_1000[i][j].f2, "g_1000[i][j].f2", print_hash_value);
            transparent_crc(g_1000[i][j].f3, "g_1000[i][j].f3", print_hash_value);
            transparent_crc(g_1000[i][j].f4, "g_1000[i][j].f4", print_hash_value);
            transparent_crc(g_1000[i][j].f5, "g_1000[i][j].f5", print_hash_value);
            transparent_crc(g_1000[i][j].f6, "g_1000[i][j].f6", print_hash_value);
            transparent_crc(g_1000[i][j].f7, "g_1000[i][j].f7", print_hash_value);
            transparent_crc(g_1000[i][j].f8, "g_1000[i][j].f8", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1001.f0, "g_1001.f0", print_hash_value);
    transparent_crc(g_1001.f1, "g_1001.f1", print_hash_value);
    transparent_crc(g_1001.f2, "g_1001.f2", print_hash_value);
    transparent_crc(g_1001.f3, "g_1001.f3", print_hash_value);
    transparent_crc(g_1001.f4, "g_1001.f4", print_hash_value);
    transparent_crc(g_1001.f5, "g_1001.f5", print_hash_value);
    transparent_crc(g_1001.f6, "g_1001.f6", print_hash_value);
    transparent_crc(g_1001.f7, "g_1001.f7", print_hash_value);
    transparent_crc(g_1001.f8, "g_1001.f8", print_hash_value);
    transparent_crc(g_1004.f0, "g_1004.f0", print_hash_value);
    transparent_crc(g_1004.f1, "g_1004.f1", print_hash_value);
    transparent_crc(g_1004.f2, "g_1004.f2", print_hash_value);
    transparent_crc(g_1004.f3, "g_1004.f3", print_hash_value);
    transparent_crc(g_1004.f4, "g_1004.f4", print_hash_value);
    transparent_crc(g_1004.f5, "g_1004.f5", print_hash_value);
    transparent_crc(g_1004.f6, "g_1004.f6", print_hash_value);
    transparent_crc(g_1004.f7, "g_1004.f7", print_hash_value);
    transparent_crc(g_1004.f8, "g_1004.f8", print_hash_value);
    transparent_crc(g_1083.f0, "g_1083.f0", print_hash_value);
    transparent_crc(g_1083.f1, "g_1083.f1", print_hash_value);
    transparent_crc(g_1083.f2, "g_1083.f2", print_hash_value);
    transparent_crc(g_1083.f3, "g_1083.f3", print_hash_value);
    transparent_crc(g_1083.f4, "g_1083.f4", print_hash_value);
    transparent_crc(g_1083.f5, "g_1083.f5", print_hash_value);
    transparent_crc(g_1083.f6, "g_1083.f6", print_hash_value);
    transparent_crc(g_1083.f7, "g_1083.f7", print_hash_value);
    transparent_crc(g_1180.f0, "g_1180.f0", print_hash_value);
    transparent_crc(g_1180.f1, "g_1180.f1", print_hash_value);
    transparent_crc(g_1180.f2, "g_1180.f2", print_hash_value);
    transparent_crc(g_1180.f3, "g_1180.f3", print_hash_value);
    transparent_crc(g_1180.f4, "g_1180.f4", print_hash_value);
    transparent_crc(g_1180.f5, "g_1180.f5", print_hash_value);
    transparent_crc(g_1180.f6, "g_1180.f6", print_hash_value);
    transparent_crc(g_1180.f7, "g_1180.f7", print_hash_value);
    transparent_crc(g_1180.f8, "g_1180.f8", print_hash_value);
    transparent_crc(g_1182.f0, "g_1182.f0", print_hash_value);
    transparent_crc(g_1182.f1, "g_1182.f1", print_hash_value);
    transparent_crc(g_1182.f2, "g_1182.f2", print_hash_value);
    transparent_crc(g_1182.f3, "g_1182.f3", print_hash_value);
    transparent_crc(g_1182.f4, "g_1182.f4", print_hash_value);
    transparent_crc(g_1182.f5, "g_1182.f5", print_hash_value);
    transparent_crc(g_1182.f6, "g_1182.f6", print_hash_value);
    transparent_crc(g_1182.f7, "g_1182.f7", print_hash_value);
    transparent_crc(g_1182.f8, "g_1182.f8", print_hash_value);
    transparent_crc(g_1183.f0, "g_1183.f0", print_hash_value);
    transparent_crc(g_1183.f1, "g_1183.f1", print_hash_value);
    transparent_crc(g_1183.f2, "g_1183.f2", print_hash_value);
    transparent_crc(g_1183.f3, "g_1183.f3", print_hash_value);
    transparent_crc(g_1183.f4, "g_1183.f4", print_hash_value);
    transparent_crc(g_1183.f5, "g_1183.f5", print_hash_value);
    transparent_crc(g_1183.f6, "g_1183.f6", print_hash_value);
    transparent_crc(g_1183.f7, "g_1183.f7", print_hash_value);
    transparent_crc(g_1183.f8, "g_1183.f8", print_hash_value);
    transparent_crc(g_1184.f0, "g_1184.f0", print_hash_value);
    transparent_crc(g_1184.f1, "g_1184.f1", print_hash_value);
    transparent_crc(g_1184.f2, "g_1184.f2", print_hash_value);
    transparent_crc(g_1184.f3, "g_1184.f3", print_hash_value);
    transparent_crc(g_1184.f4, "g_1184.f4", print_hash_value);
    transparent_crc(g_1184.f5, "g_1184.f5", print_hash_value);
    transparent_crc(g_1184.f6, "g_1184.f6", print_hash_value);
    transparent_crc(g_1184.f7, "g_1184.f7", print_hash_value);
    transparent_crc(g_1184.f8, "g_1184.f8", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1185[i].f0, "g_1185[i].f0", print_hash_value);
        transparent_crc(g_1185[i].f1, "g_1185[i].f1", print_hash_value);
        transparent_crc(g_1185[i].f2, "g_1185[i].f2", print_hash_value);
        transparent_crc(g_1185[i].f3, "g_1185[i].f3", print_hash_value);
        transparent_crc(g_1185[i].f4, "g_1185[i].f4", print_hash_value);
        transparent_crc(g_1185[i].f5, "g_1185[i].f5", print_hash_value);
        transparent_crc(g_1185[i].f6, "g_1185[i].f6", print_hash_value);
        transparent_crc(g_1185[i].f7, "g_1185[i].f7", print_hash_value);
        transparent_crc(g_1185[i].f8, "g_1185[i].f8", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1186.f0, "g_1186.f0", print_hash_value);
    transparent_crc(g_1186.f1, "g_1186.f1", print_hash_value);
    transparent_crc(g_1186.f2, "g_1186.f2", print_hash_value);
    transparent_crc(g_1186.f3, "g_1186.f3", print_hash_value);
    transparent_crc(g_1186.f4, "g_1186.f4", print_hash_value);
    transparent_crc(g_1186.f5, "g_1186.f5", print_hash_value);
    transparent_crc(g_1186.f6, "g_1186.f6", print_hash_value);
    transparent_crc(g_1186.f7, "g_1186.f7", print_hash_value);
    transparent_crc(g_1186.f8, "g_1186.f8", print_hash_value);
    transparent_crc(g_1187.f0, "g_1187.f0", print_hash_value);
    transparent_crc(g_1187.f1, "g_1187.f1", print_hash_value);
    transparent_crc(g_1187.f2, "g_1187.f2", print_hash_value);
    transparent_crc(g_1187.f3, "g_1187.f3", print_hash_value);
    transparent_crc(g_1187.f4, "g_1187.f4", print_hash_value);
    transparent_crc(g_1187.f5, "g_1187.f5", print_hash_value);
    transparent_crc(g_1187.f6, "g_1187.f6", print_hash_value);
    transparent_crc(g_1187.f7, "g_1187.f7", print_hash_value);
    transparent_crc(g_1187.f8, "g_1187.f8", print_hash_value);
    transparent_crc(g_1188.f0, "g_1188.f0", print_hash_value);
    transparent_crc(g_1188.f1, "g_1188.f1", print_hash_value);
    transparent_crc(g_1188.f2, "g_1188.f2", print_hash_value);
    transparent_crc(g_1188.f3, "g_1188.f3", print_hash_value);
    transparent_crc(g_1188.f4, "g_1188.f4", print_hash_value);
    transparent_crc(g_1188.f5, "g_1188.f5", print_hash_value);
    transparent_crc(g_1188.f6, "g_1188.f6", print_hash_value);
    transparent_crc(g_1188.f7, "g_1188.f7", print_hash_value);
    transparent_crc(g_1188.f8, "g_1188.f8", print_hash_value);
    transparent_crc(g_1189.f0, "g_1189.f0", print_hash_value);
    transparent_crc(g_1189.f1, "g_1189.f1", print_hash_value);
    transparent_crc(g_1189.f2, "g_1189.f2", print_hash_value);
    transparent_crc(g_1189.f3, "g_1189.f3", print_hash_value);
    transparent_crc(g_1189.f4, "g_1189.f4", print_hash_value);
    transparent_crc(g_1189.f5, "g_1189.f5", print_hash_value);
    transparent_crc(g_1189.f6, "g_1189.f6", print_hash_value);
    transparent_crc(g_1189.f7, "g_1189.f7", print_hash_value);
    transparent_crc(g_1189.f8, "g_1189.f8", print_hash_value);
    transparent_crc(g_1222, "g_1222", print_hash_value);
    transparent_crc(g_1256, "g_1256", print_hash_value);
    transparent_crc(g_1257, "g_1257", print_hash_value);
    transparent_crc(g_1263, "g_1263", print_hash_value);
    transparent_crc(g_1374.f0, "g_1374.f0", print_hash_value);
    transparent_crc(g_1374.f1, "g_1374.f1", print_hash_value);
    transparent_crc(g_1374.f2, "g_1374.f2", print_hash_value);
    transparent_crc(g_1374.f3, "g_1374.f3", print_hash_value);
    transparent_crc(g_1374.f4, "g_1374.f4", print_hash_value);
    transparent_crc(g_1374.f5, "g_1374.f5", print_hash_value);
    transparent_crc(g_1374.f6, "g_1374.f6", print_hash_value);
    transparent_crc(g_1374.f7, "g_1374.f7", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1376[i].f0, "g_1376[i].f0", print_hash_value);
        transparent_crc(g_1376[i].f1, "g_1376[i].f1", print_hash_value);
        transparent_crc(g_1376[i].f2, "g_1376[i].f2", print_hash_value);
        transparent_crc(g_1376[i].f3, "g_1376[i].f3", print_hash_value);
        transparent_crc(g_1376[i].f4, "g_1376[i].f4", print_hash_value);
        transparent_crc(g_1376[i].f5, "g_1376[i].f5", print_hash_value);
        transparent_crc(g_1376[i].f6, "g_1376[i].f6", print_hash_value);
        transparent_crc(g_1376[i].f7, "g_1376[i].f7", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1459, "g_1459", print_hash_value);
    transparent_crc(g_1501.f0, "g_1501.f0", print_hash_value);
    transparent_crc(g_1501.f1, "g_1501.f1", print_hash_value);
    transparent_crc(g_1501.f2, "g_1501.f2", print_hash_value);
    transparent_crc(g_1549, "g_1549", print_hash_value);
    transparent_crc(g_1574.f0, "g_1574.f0", print_hash_value);
    transparent_crc(g_1574.f1, "g_1574.f1", print_hash_value);
    transparent_crc(g_1574.f2, "g_1574.f2", print_hash_value);
    transparent_crc(g_1574.f3, "g_1574.f3", print_hash_value);
    transparent_crc(g_1574.f4, "g_1574.f4", print_hash_value);
    transparent_crc(g_1574.f5, "g_1574.f5", print_hash_value);
    transparent_crc(g_1574.f6, "g_1574.f6", print_hash_value);
    transparent_crc(g_1574.f7, "g_1574.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 365
   depth: 1, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 16
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 3
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 39
breakdown:
   indirect level: 0, occurrence: 15
   indirect level: 1, occurrence: 16
   indirect level: 2, occurrence: 4
   indirect level: 3, occurrence: 2
   indirect level: 4, occurrence: 2
XXX full-bitfields structs in the program: 7
breakdown:
   indirect level: 0, occurrence: 7
XXX times a bitfields struct's address is taken: 30
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 25
XXX times a single bitfield on LHS: 3
XXX times a single bitfield on RHS: 59

XXX max expression depth: 33
breakdown:
   depth: 1, occurrence: 113
   depth: 2, occurrence: 20
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 6, occurrence: 2
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 3
   depth: 30, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1

XXX total number of pointers: 370

XXX times a variable address is taken: 932
XXX times a pointer is dereferenced on RHS: 183
breakdown:
   depth: 1, occurrence: 127
   depth: 2, occurrence: 41
   depth: 3, occurrence: 12
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
XXX times a pointer is dereferenced on LHS: 178
breakdown:
   depth: 1, occurrence: 153
   depth: 2, occurrence: 20
   depth: 3, occurrence: 4
   depth: 4, occurrence: 0
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 41
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 5152

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 816
   level: 2, occurrence: 249
   level: 3, occurrence: 97
   level: 4, occurrence: 15
   level: 5, occurrence: 11
XXX number of pointers point to pointers: 135
XXX number of pointers point to scalars: 211
XXX number of pointers point to structs: 24
XXX percent of pointers has null in alias set: 27.3
XXX average alias set size: 1.57

XXX times a non-volatile is read: 1293
XXX times a non-volatile is write: 596
XXX times a volatile is read: 22
XXX    times read thru a pointer: 12
XXX times a volatile is write: 4
XXX    times written thru a pointer: 3
XXX times a volatile is available for access: 625
XXX percentage of non-volatile access: 98.6

XXX forward jumps: 1
XXX backward jumps: 4

XXX stmts: 106
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 18
   depth: 2, occurrence: 21
   depth: 3, occurrence: 18
   depth: 4, occurrence: 12
   depth: 5, occurrence: 6

XXX percentage a fresh-made variable is used: 16
XXX percentage an existing variable is used: 84
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

