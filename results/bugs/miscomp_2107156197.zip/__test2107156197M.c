/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 2107156197 --bitfields --packed-struct
 * Seed:      2107156197
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint32_t  f0;
   uint32_t  f1;
   uint8_t  f2;
   const uint16_t  f3;
   volatile uint16_t  f4;
};

union U1 {
   const signed f0 : 27;
};

union U2 {
   int64_t  f0;
   uint32_t  f1;
   const uint32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_11 = 0x2DAAB72BL;
static int32_t *g_16[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int32_t g_18 = 1L;/* VOLATILE GLOBAL g_18 */
static volatile int32_t g_19 = (-4L);/* VOLATILE GLOBAL g_19 */
static volatile int32_t g_20 = (-6L);/* VOLATILE GLOBAL g_20 */
static int32_t g_21 = 7L;
static volatile int32_t g_31 = 1L;/* VOLATILE GLOBAL g_31 */
static int32_t g_32 = 0xAAB39E22L;
static volatile int32_t g_35[10][4] = {{0xB6BD0D42L,0x868FDADFL,0xBEFA025EL,0xCFDFE924L},{(-6L),0xB6BD0D42L,0L,0x434A938FL},{0x38F58595L,0x5604491DL,0x38F58595L,0x434A938FL},{0L,0xB6BD0D42L,(-6L),0xCFDFE924L},{0xBEFA025EL,0x868FDADFL,0xB6BD0D42L,0xB6BD0D42L},{0L,0L,0xB6BD0D42L,0x38F58595L},{0xBEFA025EL,0x6095610AL,(-6L),0x868FDADFL},{0L,(-6L),0x38F58595L,(-6L)},{0x38F58595L,(-6L),0L,0x868FDADFL},{(-6L),0x6095610AL,0xBEFA025EL,0x868FDADFL}};
static int32_t g_36 = 0xB01D976DL;
static uint8_t g_55[2][4] = {{0xA1L,8UL,8UL,0xA1L},{8UL,0xA1L,8UL,8UL}};
static union U1 g_64[6] = {{0x816E149FL},{0x816E149FL},{0x816E149FL},{0x816E149FL},{0x816E149FL},{0x816E149FL}};
static int64_t g_77 = (-1L);
static uint64_t g_79 = 0x48991CD3C6E85A6ELL;
static int32_t g_126 = 9L;
static uint16_t g_130 = 0x8C28L;
static int32_t g_157 = 0L;
static int64_t g_159 = 1L;
static uint32_t g_160 = 1UL;
static volatile union U0 g_171 = {1UL};/* VOLATILE GLOBAL g_171 */
static uint32_t g_177[2][1][5] = {{{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL}},{{0x4FB7190DL,0x4FB7190DL,0x4FB7190DL,0x4FB7190DL,0x4FB7190DL}}};
static uint64_t *g_185 = &g_79;
static int8_t g_199 = 0x78L;
static int8_t g_201[2][10] = {{0L,1L,0L,1L,0L,1L,0L,1L,0L,1L},{0L,1L,0L,1L,0L,1L,0L,1L,0L,1L}};
static int32_t **g_210 = (void*)0;
static union U1 *g_221 = &g_64[0];
static union U1 **g_220 = &g_221;
static union U0 g_223[1][2] = {{{0xA3E45E3BL},{0xA3E45E3BL}}};
static uint32_t g_228 = 4294967289UL;
static uint8_t g_310[2] = {251UL,251UL};
static volatile uint32_t g_355 = 0xEF8E918BL;/* VOLATILE GLOBAL g_355 */
static volatile uint32_t * volatile g_354[10] = {&g_355,(void*)0,(void*)0,&g_355,(void*)0,(void*)0,&g_355,(void*)0,(void*)0,&g_355};
static int16_t g_367 = 0x2F45L;
static union U0 *g_432 = (void*)0;
static uint32_t g_461 = 4UL;
static uint64_t g_482 = 0xD7F427BA4EDF6DA9LL;
static int16_t g_483 = (-1L);
static union U0 **g_488[8] = {&g_432,&g_432,&g_432,&g_432,&g_432,&g_432,&g_432,&g_432};
static union U0 *** volatile g_487 = &g_488[4];/* VOLATILE GLOBAL g_487 */
static int32_t ***g_492 = &g_210;
static int32_t *** const *g_491 = &g_492;
static int32_t *** const ** volatile g_490 = &g_491;/* VOLATILE GLOBAL g_490 */
static volatile uint32_t g_515 = 18446744073709551615UL;/* VOLATILE GLOBAL g_515 */
static int32_t g_579[8] = {0x998E5016L,0x998E5016L,0x998E5016L,0x998E5016L,0x998E5016L,0x998E5016L,0x998E5016L,0x998E5016L};
static int16_t *g_594 = &g_483;
static int16_t *g_595 = &g_483;
static int16_t *g_596 = &g_483;
static int16_t *g_597 = &g_367;
static int16_t *g_598 = &g_367;
static int16_t *g_599 = &g_367;
static int16_t *g_600 = (void*)0;
static int16_t ** const g_593[4][8] = {{&g_599,(void*)0,&g_598,&g_595,&g_598,(void*)0,&g_599,(void*)0},{&g_598,(void*)0,&g_599,(void*)0,&g_594,&g_594,(void*)0,&g_599},{&g_596,&g_596,(void*)0,(void*)0,&g_594,&g_595,(void*)0,&g_595},{&g_598,&g_599,(void*)0,&g_599,&g_598,&g_600,&g_596,&g_595}};
static int16_t ** const *g_592 = &g_593[1][2];
static uint16_t *g_620 = &g_130;
static uint16_t * const *g_619[10] = {&g_620,&g_620,&g_620,&g_620,&g_620,&g_620,&g_620,&g_620,&g_620,&g_620};
static uint16_t * const **g_618 = &g_619[8];
static const int16_t *g_720 = (void*)0;
static const int16_t **g_719[8][7][4] = {{{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,(void*)0,&g_720},{&g_720,&g_720,(void*)0,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,&g_720,(void*)0}},{{&g_720,&g_720,(void*)0,&g_720},{&g_720,&g_720,(void*)0,(void*)0},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,(void*)0,&g_720},{&g_720,&g_720,(void*)0,&g_720}},{{&g_720,(void*)0,&g_720,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,&g_720,(void*)0},{&g_720,&g_720,(void*)0,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,(void*)0}},{{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,&g_720,&g_720,&g_720}},{{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720}},{{&g_720,(void*)0,(void*)0,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,(void*)0},{&g_720,&g_720,&g_720,&g_720}},{{&g_720,(void*)0,&g_720,(void*)0},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,&g_720,&g_720}},{{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,(void*)0},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,&g_720,(void*)0},{&g_720,(void*)0,&g_720,&g_720},{&g_720,&g_720,&g_720,&g_720},{&g_720,(void*)0,(void*)0,&g_720}}};
static const int16_t ***g_718 = &g_719[0][5][3];
static uint16_t g_735 = 0x23F7L;
static int32_t ****g_801 = (void*)0;
static int32_t *****g_800 = &g_801;
static union U0 g_860 = {0x8AD7C2CAL};/* VOLATILE GLOBAL g_860 */
static union U0 ***g_873 = &g_488[4];
static union U0 ****g_872 = &g_873;
static union U0 **g_877 = &g_432;
static union U0 *** const g_876[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U0 *** const *g_875 = &g_876[4];
static volatile union U0 g_915 = {0x9A65CCC7L};/* VOLATILE GLOBAL g_915 */
static volatile uint8_t * volatile *g_931 = (void*)0;
static union U0 g_953 = {1UL};/* VOLATILE GLOBAL g_953 */
static union U0 g_958 = {18446744073709551609UL};/* VOLATILE GLOBAL g_958 */
static uint64_t g_975 = 18446744073709551615UL;
static volatile uint8_t g_978 = 0UL;/* VOLATILE GLOBAL g_978 */
static uint8_t *g_990 = (void*)0;
static uint8_t **g_989 = &g_990;
static union U1 g_1036[3][8][3] = {{{{0xBC152042L},{9L},{0x375494D8L}},{{0L},{0x7BA8E910L},{0xD5B5F685L}},{{9L},{0xBC152042L},{0x375494D8L}},{{0x56312286L},{-1L},{0xD5B5F685L}},{{-1L},{-1L},{0x375494D8L}},{{-1L},{0L},{0xD5B5F685L}},{{0xBC152042L},{9L},{0x375494D8L}},{{0L},{0x7BA8E910L},{0xD5B5F685L}}},{{{9L},{0xBC152042L},{0x375494D8L}},{{0x56312286L},{-1L},{0xD5B5F685L}},{{-1L},{-1L},{0x375494D8L}},{{0xA1CE641DL},{0x86D84672L},{0L}},{{5L},{0x33679597L},{-1L}},{{0xA3E34B8BL},{4L},{0L}},{{0x33679597L},{5L},{-1L}},{{4L},{-1L},{0L}}},{{{-5L},{-5L},{-1L}},{{0xA1CE641DL},{0x86D84672L},{0L}},{{5L},{0x33679597L},{-1L}},{{0xA3E34B8BL},{4L},{0L}},{{0x33679597L},{5L},{-1L}},{{4L},{-1L},{0L}},{{-5L},{-5L},{-1L}},{{0xA1CE641DL},{0x86D84672L},{0L}}}};
static union U1 *g_1035 = &g_1036[2][6][1];
static volatile union U0 g_1037 = {0xCD39313CL};/* VOLATILE GLOBAL g_1037 */
static union U1 g_1073[9][7] = {{{-8L},{7L},{0xE42D3F66L},{0x05001F32L},{0xE42D3F66L},{7L},{-8L}},{{0xAE725720L},{0x8E33DD5EL},{0x45A1B4EAL},{0x62C74A34L},{0x45A1B4EAL},{0x8E33DD5EL},{0xAE725720L}},{{-8L},{7L},{0xE42D3F66L},{0x05001F32L},{0xE42D3F66L},{7L},{-8L}},{{0xAE725720L},{0x8E33DD5EL},{0x45A1B4EAL},{0x62C74A34L},{0x45A1B4EAL},{0x8E33DD5EL},{0xAE725720L}},{{-8L},{7L},{0xE42D3F66L},{0x05001F32L},{0xE42D3F66L},{7L},{-8L}},{{0xAE725720L},{0x8E33DD5EL},{0x45A1B4EAL},{0x62C74A34L},{0x45A1B4EAL},{0x8E33DD5EL},{0xAE725720L}},{{-8L},{7L},{0xE42D3F66L},{0x05001F32L},{0xE42D3F66L},{7L},{-8L}},{{0xAE725720L},{0x8E33DD5EL},{0x45A1B4EAL},{0x62C74A34L},{0x45A1B4EAL},{0x8E33DD5EL},{0xAE725720L}},{{-8L},{7L},{0xE42D3F66L},{0x05001F32L},{0xE42D3F66L},{7L},{-8L}}};
static union U2 g_1086 = {0L};
static union U2 g_1135 = {0x79809780EA896396LL};
static uint64_t g_1152 = 18446744073709551612UL;
static int32_t g_1177 = 0xAA073AF6L;
static volatile union U0 g_1204[5][6] = {{{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL}},{{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL}},{{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL}},{{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL}},{{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL},{0x5422FD3EL}}};
static volatile int64_t g_1291 = 5L;/* VOLATILE GLOBAL g_1291 */
static int32_t ** volatile g_1308 = &g_16[1];/* VOLATILE GLOBAL g_1308 */
static uint8_t ***g_1402 = &g_989;
static uint8_t ****g_1401 = &g_1402;
static uint8_t *****g_1400 = &g_1401;
static volatile int16_t g_1421 = (-6L);/* VOLATILE GLOBAL g_1421 */
static volatile int16_t *g_1420 = &g_1421;
static union U0 g_1539[7][4][8] = {{{{0x4BFC09FDL},{0xD9FD5AA6L},{1UL},{0x5495B59CL},{0xBE79C242L},{0xE0CB516BL},{0x6CFDADECL},{0xD9FD5AA6L}},{{18446744073709551615UL},{0x6CFDADECL},{0x83CC4666L},{0xA8BF9BDBL},{4UL},{18446744073709551614UL},{18446744073709551614UL},{4UL}},{{0x446E5573L},{0x33ACDF2EL},{0x33ACDF2EL},{0x446E5573L},{18446744073709551615UL},{1UL},{0x739F83BFL},{1UL}},{{0x6CFDADECL},{0x446E5573L},{0xE2B90A9CL},{0x739F83BFL},{0xAFFD59A4L},{0x0EA0037BL},{0x6CFDADECL},{0xBE79C242L}}},{{{0x83CC4666L},{0x446E5573L},{0x4A364685L},{1UL},{0xD9FD5AA6L},{1UL},{1UL},{0x6CFDADECL}},{{4UL},{0x33ACDF2EL},{0x5679F94DL},{18446744073709551615UL},{1UL},{18446744073709551614UL},{0x4BFC09FDL},{18446744073709551614UL}},{{0xAFFD59A4L},{0x6CFDADECL},{0x4B054526L},{0x6CFDADECL},{0xAFFD59A4L},{0xE0CB516BL},{4UL},{0x739F83BFL}},{{0x4A364685L},{0xD9FD5AA6L},{1UL},{0xE0CB516BL},{0xA8BF9BDBL},{0x4B054526L},{0xE2B90A9CL},{18446744073709551614UL}}},{{{0x33ACDF2EL},{0x0EA0037BL},{0x4B054526L},{1UL},{0x1B7AC8B1L},{1UL},{18446744073709551614UL},{0xE9D28540L}},{{0xA8BF9BDBL},{1UL},{0x5495B59CL},{0x4A364685L},{1UL},{0x4BFC09FDL},{18446744073709551615UL},{18446744073709551615UL}},{{0x4B054526L},{0x5679F94DL},{18446744073709551611UL},{18446744073709551611UL},{0x5679F94DL},{0x4B054526L},{0xE9D28540L},{18446744073709551614UL}},{{18446744073709551615UL},{0xE2B90A9CL},{18446744073709551606UL},{0x5679F94DL},{0xE9D28540L},{0x0EA0037BL},{18446744073709551614UL},{0xE2B90A9CL}}},{{{0xA8BF9BDBL},{18446744073709551614UL},{0x4BFC09FDL},{0x5679F94DL},{18446744073709551614UL},{0x6CFDADECL},{0x4A364685L},{18446744073709551614UL}},{{18446744073709551611UL},{18446744073709551614UL},{0x1B7AC8B1L},{18446744073709551611UL},{0xA8BF9BDBL},{0xE2B90A9CL},{1UL},{18446744073709551615UL}},{{18446744073709551614UL},{18446744073709551611UL},{1UL},{0x4A364685L},{1UL},{18446744073709551611UL},{18446744073709551614UL},{0xE9D28540L}},{{1UL},{0x33ACDF2EL},{0x0B6004AEL},{1UL},{0x83CC4666L},{0xAFFD59A4L},{1UL},{18446744073709551614UL}}},{{{0x1B7AC8B1L},{18446744073709551614UL},{18446744073709551611UL},{0xE0CB516BL},{0x83CC4666L},{1UL},{0x4B054526L},{0x4A364685L}},{{1UL},{18446744073709551606UL},{0xE0CB516BL},{18446744073709551614UL},{1UL},{0x0EA0037BL},{18446744073709551614UL},{1UL}},{{18446744073709551614UL},{0x83CC4666L},{18446744073709551615UL},{0xA8BF9BDBL},{0xA8BF9BDBL},{18446744073709551615UL},{0x83CC4666L},{18446744073709551614UL}},{{18446744073709551611UL},{0x5679F94DL},{0x4B054526L},{0xE9D28540L},{18446744073709551614UL},{1UL},{0x1B7AC8B1L},{1UL}}},{{{0xA8BF9BDBL},{18446744073709551615UL},{0xE0CB516BL},{0x4A364685L},{0xE9D28540L},{1UL},{18446744073709551615UL},{0x4B054526L}},{{18446744073709551615UL},{0x5679F94DL},{4UL},{0x33ACDF2EL},{0x5679F94DL},{18446744073709551615UL},{1UL},{18446744073709551614UL}},{{0x4B054526L},{0x83CC4666L},{18446744073709551606UL},{0x0EA0037BL},{1UL},{0x0EA0037BL},{18446744073709551606UL},{0x83CC4666L}},{{0xA8BF9BDBL},{18446744073709551606UL},{1UL},{0x5679F94DL},{0x1B7AC8B1L},{1UL},{0x4A364685L},{0x1B7AC8B1L}}},{{{0x33ACDF2EL},{18446744073709551614UL},{0x739F83BFL},{0x33ACDF2EL},{0xA8BF9BDBL},{0xAFFD59A4L},{0x4A364685L},{18446744073709551615UL}},{{18446744073709551606UL},{0x33ACDF2EL},{1UL},{1UL},{1UL},{18446744073709551611UL},{18446744073709551606UL},{1UL}},{{1UL},{18446744073709551611UL},{18446744073709551606UL},{1UL},{0xE2B90A9CL},{0xE2B90A9CL},{1UL},{18446744073709551606UL}},{{18446744073709551614UL},{18446744073709551614UL},{4UL},{0xA8BF9BDBL},{0x83CC4666L},{0x6CFDADECL},{18446744073709551615UL},{0x4A364685L}}}};
static int32_t ** volatile g_1560 = &g_16[1];/* VOLATILE GLOBAL g_1560 */
static int32_t ** volatile g_1591 = &g_16[0];/* VOLATILE GLOBAL g_1591 */
static int32_t *g_1633 = &g_21;
static volatile uint32_t g_1639 = 0x1DBE0968L;/* VOLATILE GLOBAL g_1639 */
static volatile union U0 g_1666 = {1UL};/* VOLATILE GLOBAL g_1666 */
static union U0 *****g_1700 = &g_872;
static union U0 g_1702 = {6UL};/* VOLATILE GLOBAL g_1702 */
static int32_t * volatile g_1704 = (void*)0;/* VOLATILE GLOBAL g_1704 */
static int32_t g_1732 = 0xAC9926E8L;
static union U2 *g_1760 = &g_1086;
static union U2 * volatile * const  volatile g_1759 = &g_1760;/* VOLATILE GLOBAL g_1759 */
static const int32_t ** volatile g_1786[5][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0}};
static const union U0 *g_1790 = (void*)0;
static const union U0 ** volatile g_1789 = &g_1790;/* VOLATILE GLOBAL g_1789 */
static volatile int64_t * volatile g_1860[1][9] = {{&g_1291,&g_1291,&g_1291,&g_1291,&g_1291,&g_1291,&g_1291,&g_1291,&g_1291}};
static volatile int64_t * volatile * volatile g_1859 = &g_1860[0][6];/* VOLATILE GLOBAL g_1859 */
static volatile int64_t * volatile * volatile * volatile g_1861[3] = {&g_1859,&g_1859,&g_1859};
static volatile int64_t * volatile * volatile * volatile g_1862 = &g_1859;/* VOLATILE GLOBAL g_1862 */
static union U2 g_1894[9][2][9] = {{{{0x4E6087F3C05055E8LL},{-10L},{0xF28383D9718F7DA2LL},{-4L},{-10L},{0xAA820DBF37C65069LL},{-7L},{1L},{0xC4AE4641534311E0LL}},{{0x4E6087F3C05055E8LL},{0L},{3L},{0xE6EF01DB5D256CEELL},{0x9B02969B33203AEDLL},{0x6DB7619BED4E85AELL},{0xCF9EDEAE03541F23LL},{1L},{4L}}},{{{-9L},{0x9B02969B33203AEDLL},{0L},{0xC4AE4641534311E0LL},{0x5467B394C132B16ELL},{0x6DB7619BED4E85AELL},{-7L},{0x9B02969B33203AEDLL},{0L}},{{3L},{1L},{-9L},{0xC4AE4641534311E0LL},{0x9B02969B33203AEDLL},{0xAA820DBF37C65069LL},{0x0B03FF8544B78C80LL},{0L},{0xE6EF01DB5D256CEELL}}},{{{0xDE7BC8BF15C97AF5LL},{1L},{0L},{0xE6EF01DB5D256CEELL},{-10L},{1L},{1L},{-10L},{0xE6EF01DB5D256CEELL}},{{3L},{0x9B02969B33203AEDLL},{3L},{-4L},{0xD2589430F301D06DLL},{-7L},{1L},{0L},{0L}}},{{{-9L},{0L},{0xF28383D9718F7DA2LL},{-1L},{0xD2589430F301D06DLL},{1L},{0x0B03FF8544B78C80LL},{0x9B02969B33203AEDLL},{4L}},{{0x4E6087F3C05055E8LL},{-10L},{0xF28383D9718F7DA2LL},{-4L},{-10L},{0xAA820DBF37C65069LL},{-7L},{1L},{0xC4AE4641534311E0LL}}},{{{0x4E6087F3C05055E8LL},{0L},{3L},{0xE6EF01DB5D256CEELL},{0x9B02969B33203AEDLL},{0x6DB7619BED4E85AELL},{0xCF9EDEAE03541F23LL},{1L},{4L}},{{-9L},{0x9B02969B33203AEDLL},{0L},{0xC4AE4641534311E0LL},{0x5467B394C132B16ELL},{0x6DB7619BED4E85AELL},{-7L},{0x9B02969B33203AEDLL},{0L}}},{{{3L},{1L},{-9L},{0xC4AE4641534311E0LL},{0x9B02969B33203AEDLL},{0xAA820DBF37C65069LL},{0x0B03FF8544B78C80LL},{0L},{0xE6EF01DB5D256CEELL}},{{0xDE7BC8BF15C97AF5LL},{1L},{0L},{0xE6EF01DB5D256CEELL},{-10L},{1L},{1L},{-10L},{0xE6EF01DB5D256CEELL}}},{{{3L},{0x9B02969B33203AEDLL},{3L},{-4L},{0xD2589430F301D06DLL},{-7L},{1L},{0L},{0L}},{{-9L},{0L},{0xF28383D9718F7DA2LL},{-1L},{0xD2589430F301D06DLL},{1L},{0x0B03FF8544B78C80LL},{0x9B02969B33203AEDLL},{4L}}},{{{0x4E6087F3C05055E8LL},{-10L},{0xF28383D9718F7DA2LL},{-4L},{-10L},{0xAA820DBF37C65069LL},{-7L},{1L},{0xC4AE4641534311E0LL}},{{0x4E6087F3C05055E8LL},{0L},{3L},{0xE6EF01DB5D256CEELL},{0x9B02969B33203AEDLL},{0x6DB7619BED4E85AELL},{0xCF9EDEAE03541F23LL},{1L},{4L}}},{{{-9L},{0x9B02969B33203AEDLL},{0L},{0xC4AE4641534311E0LL},{0x5467B394C132B16ELL},{0x6DB7619BED4E85AELL},{-7L},{0x9B02969B33203AEDLL},{0L}},{{3L},{1L},{-9L},{0xC4AE4641534311E0LL},{0x9B02969B33203AEDLL},{0xAA820DBF37C65069LL},{0x0B03FF8544B78C80LL},{0L},{0xE6EF01DB5D256CEELL}}}};
static union U2 *g_1893 = &g_1894[1][1][7];
static union U0 g_1944[4] = {{0xC7CDA584L},{0xC7CDA584L},{0xC7CDA584L},{0xC7CDA584L}};
static int32_t ** volatile g_1959 = &g_16[1];/* VOLATILE GLOBAL g_1959 */
static union U0 g_2033 = {0x66E51D14L};/* VOLATILE GLOBAL g_2033 */
static int32_t ** volatile g_2053[9][4] = {{&g_1633,&g_16[1],&g_16[1],&g_16[6]},{&g_16[6],&g_16[1],&g_16[1],&g_16[6]},{&g_1633,&g_16[1],&g_16[1],&g_16[6]},{&g_16[6],&g_16[1],&g_16[1],&g_16[6]},{&g_1633,&g_16[1],&g_16[1],&g_16[6]},{&g_16[6],&g_16[1],&g_16[1],&g_16[6]},{&g_1633,&g_16[1],&g_16[1],&g_16[6]},{&g_16[6],&g_16[1],&g_16[1],&g_16[6]},{&g_1633,&g_16[1],&g_16[1],&g_16[6]}};
static int32_t ** volatile g_2054 = &g_1633;/* VOLATILE GLOBAL g_2054 */
static uint8_t g_2072 = 0x8EL;
static const int16_t ****g_2079[7][7] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static const int16_t ***** volatile g_2078 = &g_2079[0][2];/* VOLATILE GLOBAL g_2078 */


/* --- FORWARD DECLARATIONS --- */
static union U2  func_1(void);
static int32_t * func_2(int32_t * p_3, const int32_t * p_4, int32_t * p_5);
static int32_t * func_6(int8_t  p_7, const uint64_t  p_8, uint16_t  p_9, int16_t  p_10);
static uint16_t  func_12(int32_t * p_13, int32_t * p_14, const int32_t * p_15);
static int32_t  func_24(union U1  p_25);
static int16_t  func_28(const uint32_t  p_29);
static int32_t  func_39(uint64_t  p_40, uint64_t  p_41);
static uint64_t  func_43(int32_t * p_44, uint8_t  p_45);
static int32_t * func_46(int8_t  p_47, int16_t  p_48);
static uint16_t  func_60(int32_t  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_16 g_21 g_18 g_36 g_64.f0 g_77 g_79 g_32 g_55 g_157 g_159 g_20 g_126 g_171 g_177 g_19 g_873 g_488 g_1086 g_618 g_619 g_620 g_130 g_185 g_515 g_310 g_595 g_975 g_1152 g_1135.f0 g_1177 g_223.f0 g_1204 g_461 g_915.f0 g_735 g_958 g_35 g_1308 g_199 g_1035 g_1036 g_367 g_597 g_579 g_1666 g_201 g_1633 g_592 g_593 g_1702 g_1591 g_1732 g_491 g_492 g_1759 g_989 g_990 g_1760 g_1086.f0 g_1789 g_596 g_872 g_220 g_1859 g_1862 g_221 g_1860 g_1291 g_800 g_801 g_1420 g_1421 g_1944 g_1959 g_1560
 * writes: g_21 g_32 g_36 g_55 g_77 g_79 g_126 g_130 g_157 g_159 g_160 g_177 g_185 g_199 g_201 g_228 g_1086.f0 g_16 g_958.f1 g_482 g_220 g_483 g_975 g_1152 g_1177 g_860.f2 g_461 g_1135.f0 g_735 g_1700 g_310 g_1790 g_1702.f2 g_488 g_221 g_1859 g_579 g_1893 g_11 g_367
 */
static union U2  func_1(void)
{ /* block id: 0 */
    const int32_t *l_17 = (void*)0;
    int32_t l_1329[2][8] = {{(-4L),0x2A8DAEC1L,0x2A8DAEC1L,(-4L),0x2A8DAEC1L,0x2A8DAEC1L,(-4L),0x2A8DAEC1L},{(-4L),(-4L),0xA60017B3L,(-4L),(-4L),0xA60017B3L,(-4L),(-4L)}};
    int32_t **l_2168 = (void*)0;
    int32_t **l_2169[9][10] = {{&g_16[1],(void*)0,&g_16[1],&g_1633,&g_16[1],(void*)0,&g_16[1],&g_1633,&g_16[1],&g_16[1]},{&g_16[6],&g_16[5],(void*)0,&g_16[1],(void*)0,&g_16[1],&g_16[1],&g_1633,&g_16[1],&g_1633},{&g_1633,&g_16[5],&g_1633,(void*)0,(void*)0,(void*)0,&g_16[1],&g_16[1],&g_16[1],&g_16[1]},{&g_1633,(void*)0,&g_16[1],&g_16[1],(void*)0,&g_1633,&g_1633,&g_1633,&g_1633,&g_16[6]},{&g_16[1],&g_16[1],&g_16[1],(void*)0,&g_16[1],&g_1633,&g_1633,&g_1633,&g_16[5],&g_1633},{&g_16[1],&g_16[2],&g_1633,&g_16[5],(void*)0,&g_1633,&g_1633,(void*)0,&g_1633,&g_1633},{&g_1633,&g_1633,(void*)0,&g_1633,&g_1633,(void*)0,&g_16[5],&g_1633,&g_16[2],&g_16[1]},{&g_1633,&g_16[5],&g_1633,&g_1633,&g_1633,&g_16[1],(void*)0,&g_16[1],&g_16[1],&g_16[1]},{&g_16[6],&g_1633,&g_1633,&g_1633,&g_1633,(void*)0,&g_16[1],&g_16[1],(void*)0,&g_1633}};
    int i, j;
    (*g_1308) = func_2(((*g_1591) = func_6((g_11 | func_12(g_16[1], g_16[1], l_17)), (((safe_div_func_int8_t_s_s_unsafe_macro/*0*//* ___SAFE__OP */(0x7EL, l_1329[0][7])) , (((safe_add_func_uint16_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(18446744073709551615UL, g_367)), l_1329[0][7])) && l_1329[0][3]) , 65535UL)) ^ (-1L)), l_1329[1][7], (*g_597))), &l_1329[0][7], &l_1329[0][7]);
    return (**g_1759);
}


/* ------------------------------------------ */
/* 
 * reads : g_310 g_579 g_1666 g_1086 g_185 g_79 g_201 g_1633 g_620 g_130 g_592 g_593 g_1702 g_21 g_1308 g_16 g_64.f0 g_975 g_1732 g_36 g_491 g_492 g_1759 g_618 g_619 g_55 g_989 g_990 g_1760 g_1086.f0 g_1789 g_1035 g_1036 g_596 g_872 g_873 g_367 g_199 g_220 g_1859 g_1862 g_221 g_1860 g_1291 g_11 g_800 g_801 g_597 g_1420 g_1421 g_1177 g_1944 g_595 g_157 g_159 g_20 g_126 g_171 g_177 g_19 g_1959 g_1560 g_32
 * writes: g_1177 g_201 g_79 g_21 g_130 g_1700 g_36 g_199 g_310 g_1790 g_1135.f0 g_1086.f0 g_483 g_1702.f2 g_488 g_221 g_1859 g_579 g_1893 g_220 g_160 g_11 g_77 g_126 g_157 g_159 g_177 g_185 g_16 g_367 g_32
 */
static int32_t * func_2(int32_t * p_3, const int32_t * p_4, int32_t * p_5)
{ /* block id: 733 */
    uint32_t l_1706 = 0xA913C20EL;
    uint8_t l_1709[9][9][3] = {{{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,5UL},{5UL,255UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL}},{{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,5UL,0xCCL},{0xCCL,0xCCL,255UL}},{{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL},{255UL,0xCCL,255UL}}};
    uint16_t **l_1718[6] = {&g_620,&g_620,&g_620,&g_620,&g_620,&g_620};
    uint16_t ***l_1717[3][7] = {{(void*)0,&l_1718[0],&l_1718[0],(void*)0,(void*)0,&l_1718[0],&l_1718[0]},{&l_1718[0],&l_1718[2],&l_1718[0],&l_1718[2],&l_1718[0],&l_1718[2],&l_1718[0]},{(void*)0,(void*)0,&l_1718[0],&l_1718[0],(void*)0,(void*)0,&l_1718[0]}};
    uint16_t ****l_1716[1][4];
    uint16_t *****l_1719 = &l_1716[0][2];
    uint16_t ****l_1720[3];
    int32_t l_1723[1][7][9] = {{{1L,(-1L),0x775840E4L,1L,0xB1F17677L,(-8L),0xB1F17677L,1L,0x775840E4L},{0x1D8EF303L,0x1D8EF303L,0L,6L,(-1L),(-8L),0xB98648A1L,(-8L),(-1L)},{1L,0xB1F17677L,0xB1F17677L,1L,0xB6A4ED9FL,0x8A7187A1L,(-6L),0x775840E4L,(-6L)},{0xB98648A1L,0x042516FDL,0L,0L,0x042516FDL,0xB98648A1L,1L,0x1D8EF303L,0xAE8D3FE6L},{0xEF6CEBCCL,0x8A7187A1L,0x775840E4L,0xB6A4ED9FL,0xB6A4ED9FL,0x775840E4L,0x8A7187A1L,0xEF6CEBCCL,(-1L)},{0xAE8D3FE6L,0L,0L,1L,(-1L),(-1L),1L,0L,0L},{0xB6A4ED9FL,0xEF6CEBCCL,(-8L),(-1L),0xB1F17677L,(-6L),(-6L),0xB1F17677L,(-1L)}}};
    int32_t l_1726 = 0L;
    const int64_t l_1729 = 1L;
    int16_t l_1730[6][7] = {{0xD760L,(-2L),0xD760L,0xD760L,(-2L),0xD760L,0xD760L},{(-6L),(-6L),0xF5E9L,(-6L),(-6L),0xF5E9L,(-6L)},{(-2L),0xD760L,0xD760L,(-2L),0xD760L,0xD760L,(-2L)},{0L,(-6L),0L,0L,(-6L),0L,0L},{(-2L),(-2L),0x4310L,(-2L),(-2L),0x4310L,(-2L)},{(-6L),0L,0L,(-6L),0L,0L,(-6L)}};
    int32_t l_1731 = (-1L);
    int32_t *l_1733 = &g_36;
    int32_t ***l_1747 = &g_210;
    union U2 **l_1761 = (void*)0;
    uint64_t l_1813 = 0x2A1C438EEFB51C10LL;
    uint16_t l_1883 = 1UL;
    int32_t l_1914 = 0L;
    uint64_t l_1954 = 18446744073709551610UL;
    union U1 l_1996 = {0xABCEE258L};
    int8_t l_2037[3][8];
    int32_t l_2070 = 0xFAA4B2B5L;
    union U0 * const *l_2090 = &g_432;
    union U0 * const **l_2089 = &l_2090;
    int32_t *l_2113 = &g_32;
    uint8_t ****l_2148 = &g_1402;
    int16_t **l_2161[5] = {&g_594,&g_594,&g_594,&g_594,&g_594};
    int16_t ***l_2160 = &l_2161[3];
    int16_t ****l_2159[4][5] = {{&l_2160,&l_2160,&l_2160,&l_2160,&l_2160},{&l_2160,&l_2160,&l_2160,&l_2160,&l_2160},{&l_2160,&l_2160,&l_2160,&l_2160,&l_2160},{&l_2160,&l_2160,&l_2160,&l_2160,&l_2160}};
    int16_t *****l_2158[10][10][2] = {{{(void*)0,(void*)0},{&l_2159[1][3],&l_2159[2][3]},{&l_2159[3][4],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]}},{{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]}},{{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0}},{{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]}},{{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]}},{{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]}},{{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0}},{{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]},{&l_2159[2][1],&l_2159[1][0]}},{{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],&l_2159[1][3]},{(void*)0,&l_2159[1][0]},{&l_2159[1][0],&l_2159[1][0]},{(void*)0,&l_2159[1][3]}},{{&l_2159[2][1],&l_2159[1][0]},{&l_2159[1][1],(void*)0},{&l_2159[3][4],&l_2159[1][1]},{&l_2159[2][3],&l_2159[1][0]},{&l_2159[2][3],&l_2159[1][1]},{&l_2159[3][4],(void*)0},{&l_2159[1][1],&l_2159[1][0]},{&l_2159[2][1],(void*)0},{&l_2159[1][0],&l_2159[2][0]},{&l_2159[2][0],&l_2159[2][0]}}};
    int32_t *l_2167 = &g_157;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
            l_1716[i][j] = &l_1717[0][6];
    }
    for (i = 0; i < 3; i++)
        l_1720[i] = (void*)0;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
            l_2037[i][j] = 7L;
    }
lbl_1960:
    p_4 = func_6(l_1706, l_1706, l_1706, l_1706);
    if ((((*l_1733) = ((*p_5) = (((l_1706 , l_1709[5][7][0]) != (((safe_mul_func_int8_t_s_s_unsafe_macro/*3*//* ___SAFE__OP */(((!((+(l_1731 = ((safe_lshift_func_int32_t_s_s(((((*l_1719) = l_1716[0][0]) == l_1720[0]) <= (safe_mod_func_uint64_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */((((((l_1723[0][5][4] = (*g_620)) == (safe_mod_func_int8_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */(l_1709[8][2][2], (l_1726 = 0xFDL)))) <= (safe_add_func_int32_t_s_s_unsafe_macro/*7*//* ___SAFE__OP */(l_1709[8][7][1], (((((*g_1633) = ((l_1709[5][7][0] | 0x9A2EL) && 0x0953231591DF3BFBLL)) | l_1709[5][7][0]) , l_1706) ^ g_64[3].f0)))) , l_1729) & l_1729), (*g_185)))), l_1709[1][2][0])) , l_1730[0][0]))) <= g_975)) ^ (*p_5)), l_1730[3][1])) == 0xF8E9L) != g_1732)) & l_1706))) && (*p_5)))
    { /* block id: 742 */
        uint32_t l_1734 = 0xB4154514L;
        int32_t l_1744 = 1L;
        uint8_t l_1768 = 0xE9L;
        const union U0 *l_1788 = (void*)0;
        uint32_t l_1816[1];
        uint16_t **l_1833 = (void*)0;
        int32_t l_1852 = 0xE9DACC6DL;
        int32_t l_1853[10][1][1] = {{{0x074AA17AL}},{{7L}},{{0x074AA17AL}},{{7L}},{{0x074AA17AL}},{{7L}},{{0x074AA17AL}},{{7L}},{{0x074AA17AL}},{{7L}}};
        uint32_t *l_1930 = &g_160;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1816[i] = 1UL;
        l_1734++;
        for (g_21 = 14; (g_21 < (-16)); g_21--)
        { /* block id: 746 */
            uint64_t l_1743 = 8UL;
            int32_t ****l_1748 = (void*)0;
            int32_t ****l_1749 = &l_1747;
            uint16_t l_1751 = 0xECEBL;
            int8_t *l_1752 = &g_199;
            int32_t l_1772 = 0x21AEECE8L;
            union U0 **l_1848[8][1] = {{&g_432},{&g_432},{&g_432},{&g_432},{&g_432},{&g_432},{&g_432},{&g_432}};
            int32_t l_1851[5] = {(-9L),(-9L),(-9L),(-9L),(-9L)};
            uint32_t l_1856 = 4294967292UL;
            int16_t *l_1890 = &g_367;
            int8_t l_1891 = 0x8EL;
            int i, j;
            if (((((safe_lshift_func_uint8_t_u_s_unsafe_macro/*8*//* ___SAFE__OP */((*l_1733), ((((safe_rshift_func_uint8_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */(l_1743, ((l_1744 = l_1743) && (247UL == (safe_add_func_uint8_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */((((*l_1749) = l_1747) != (((*l_1752) = (g_201[0][4] = (l_1751 ^= (+(*l_1733))))) , (*g_491))), (safe_lshift_func_int8_t_s_s_unsafe_macro/*11*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_s_unsafe_macro/*12*//* ___SAFE__OP */((l_1734 > ((safe_sub_func_int16_t_s_s_unsafe_macro/*13*//* ___SAFE__OP */((g_1759 != l_1761), (***g_618))) , 0xC86950D9A9BF1F1CLL)), 15)) || (*p_5)), 3)))))))) && 1UL) || (*p_5)) == g_1732))) <= g_55[1][0]) , l_1744) <= 0UL))
            { /* block id: 752 */
                uint64_t l_1773 = 0x9D04D13AB51E2FD5LL;
                int32_t l_1775 = 0x2957A4FAL;
                if (((l_1744 ^ l_1734) , (((*l_1733) < l_1734) , (*l_1733))))
                { /* block id: 753 */
                    int32_t *l_1774[10][7] = {{&l_1726,&g_21,&l_1723[0][5][4],&l_1772,&g_126,(void*)0,&g_126},{(void*)0,&g_1732,&g_1732,(void*)0,(void*)0,&l_1772,&l_1726},{&l_1726,&l_1772,(void*)0,(void*)0,&g_1732,&g_1732,(void*)0},{&g_126,(void*)0,&g_126,&l_1772,&l_1723[0][5][4],&g_21,&l_1726},{(void*)0,&g_1177,&g_126,(void*)0,&g_1732,(void*)0,&g_126},{&l_1723[0][5][4],&l_1723[0][5][4],(void*)0,&l_1723[0][2][4],&g_32,&g_21,(void*)0},{&l_1723[0][2][4],&l_1723[0][5][4],&g_1732,&g_21,&g_21,&g_1732,&l_1723[0][5][4]},{&g_1732,&g_1177,&l_1723[0][5][4],&g_126,&g_32,&l_1772,&l_1723[0][2][4]},{&g_1732,(void*)0,&g_1732,&l_1723[0][5][4],&g_1732,(void*)0,&g_1732},{&l_1723[0][2][4],&l_1772,&g_32,&g_126,&l_1723[0][5][4],&g_1177,&g_1732}};
                    int i, j;
                    l_1775 |= ((*l_1733) = ((safe_mul_func_uint16_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */(((*g_620) ^= 0x0040L), (((g_201[0][4] = (65532UL | (safe_mod_func_uint64_t_u_u_unsafe_macro/*15*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*16*//* ___SAFE__OP */(l_1768, (+(l_1744 = (safe_mul_func_int32_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */(((((((*g_989) != (void*)0) != ((0x8A7717FC3762908BLL ^ 0xEA1C3EE57AA7DDF0LL) && (0x3A1F64C3L & (l_1768 ^ 4UL)))) == l_1772) && 0x25L) | (*l_1733)), (*p_5))))))), 9L)))) < (*l_1733)) > l_1773))) || (*l_1733)));
                    for (g_199 = 1; (g_199 <= 7); ++g_199)
                    { /* block id: 761 */
                        uint64_t l_1784 = 0xFFFFBC99578448B5LL;
                        uint8_t *l_1785[7] = {&g_310[1],&g_310[1],&g_310[1],&g_310[1],&g_310[1],&g_310[1],&g_310[1]};
                        const int32_t **l_1787 = (void*)0;
                        int i;
                        (*p_5) = ((safe_mul_func_int32_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */((*l_1733), (*p_5))) <= (((**g_1759) , g_1086.f0) & (safe_sub_func_uint64_t_u_u_unsafe_macro/*19*//* ___SAFE__OP */((+(0x2BAAB890C3972F27LL > (*g_185))), (safe_unary_minus_func_uint8_t_u_unsafe_macro/*20*//* ___SAFE__OP */((g_310[0] = (l_1784 &= 255UL))))))));
                        if (l_1784)
                            continue;
                        p_4 = p_4;
                    }
                }
                else
                { /* block id: 768 */
                    l_1744 ^= (p_3 == (void*)0);
                }
                (*g_1789) = l_1788;
                if (((*l_1733) = l_1768))
                { /* block id: 773 */
                    int8_t l_1792 = 0L;
                    (*l_1733) = l_1744;
                    if ((safe_unary_minus_func_int64_t_s_unsafe_macro/*21*//* ___SAFE__OP */(l_1792)))
                    { /* block id: 775 */
                        int64_t *l_1798 = &g_1135.f0;
                        int64_t *l_1799 = &g_1086.f0;
                        int32_t l_1802 = 0xD8C514A9L;
                        (*l_1733) &= 0x9315876CL;
                        if ((*l_1733))
                            break;
                        if ((*l_1733))
                            break;
                        (*p_5) = (safe_mul_func_int16_t_s_s_unsafe_macro/*22*//* ___SAFE__OP */((((*g_185)++) && (+(1UL || ((*l_1799) = ((*l_1798) = l_1773))))), (safe_mul_func_uint64_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */(l_1792, (4294967288UL != (l_1802 & (((void*)0 == &g_228) > (l_1768 >= (safe_mul_func_int8_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */(0L, l_1802))))))))));
                    }
                    else
                    { /* block id: 783 */
                        union U2 **l_1819 = &g_1760;
                        uint8_t *l_1826[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int32_t l_1827 = 0L;
                        int i;
                        (*p_5) ^= (+(safe_mod_func_uint16_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */(((*g_596) = ((!(l_1813 , ((safe_add_func_int32_t_s_s_unsafe_macro/*28*//* ___SAFE__OP */(l_1816[0], (-1L))) < (safe_lshift_func_int16_t_s_u_unsafe_macro/*29*//* ___SAFE__OP */(((l_1744 , ((*l_1733) ^= (((void*)0 != l_1819) < (safe_lshift_func_int32_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */(((*g_1035) , ((safe_add_func_int64_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */(((~((+4294967286UL) & 1UL)) <= l_1734), 0xE6BEBE1219837A0BLL)) & (*g_185))), 13))))) > l_1773), (***g_618)))))) ^ (-5L))), l_1775)), l_1792)), (***g_618))));
                        l_1827 |= (*l_1733);
                        if (l_1744)
                            break;
                        if (l_1775)
                            continue;
                    }
                }
                else
                { /* block id: 791 */
                    for (g_1702.f2 = (-23); (g_1702.f2 <= 59); ++g_1702.f2)
                    { /* block id: 794 */
                        return p_5;
                    }
                }
            }
            else
            { /* block id: 798 */
                uint16_t **l_1832[5];
                uint8_t *l_1838[4] = {&l_1709[7][3][2],&l_1709[7][3][2],&l_1709[7][3][2],&l_1709[7][3][2]};
                int32_t l_1841 = 8L;
                union U0 **l_1847 = &g_432;
                int32_t l_1854[1];
                int16_t l_1855[3];
                int8_t l_1888 = 0L;
                union U1 ***l_1915 = &g_220;
                int32_t *l_1925 = &g_1732;
                int i;
                for (i = 0; i < 5; i++)
                    l_1832[i] = (void*)0;
                for (i = 0; i < 1; i++)
                    l_1854[i] = (-6L);
                for (i = 0; i < 3; i++)
                    l_1855[i] = 0x0DB1L;
                if ((safe_mod_func_int64_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */((l_1832[1] != l_1833), ((*g_185) |= ((safe_add_func_uint32_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*34*//* ___SAFE__OP */((*l_1733), ((void*)0 == l_1838[1]))), (safe_div_func_int16_t_s_s_unsafe_macro/*35*//* ___SAFE__OP */((-5L), ((l_1841 < ((*l_1752) ^= ((safe_mod_func_uint8_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */((l_1744 = (safe_add_func_uint16_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */((safe_unary_minus_func_int64_t_s_unsafe_macro/*38*//* ___SAFE__OP */((((**g_872) = l_1847) != l_1848[0][0]))), l_1841))), (*l_1733))) , g_367))) , l_1744))))) >= 0x90964966L)))))
                { /* block id: 803 */
                    union U1 *l_1849[9] = {&g_64[3],&g_64[3],&g_64[3],&g_64[3],&g_64[3],&g_64[3],&g_64[3],&g_64[3],&g_64[3]};
                    int32_t *l_1850[9] = {&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3],&l_1723[0][6][3]};
                    int32_t ****l_1887 = &l_1747;
                    union U2 *l_1892 = &g_1135;
                    int i;
                    (*g_220) = l_1849[1];
                    l_1856--;
                    if ((*l_1733))
                        continue;
                    if ((*p_5))
                    { /* block id: 807 */
                        uint32_t l_1873 = 4294967295UL;
                        uint64_t l_1884 = 0UL;
                        uint32_t *l_1885 = (void*)0;
                        uint32_t *l_1886 = &l_1816[0];
                        int32_t *l_1889 = &g_579[7];
                        (*g_1862) = g_1859;
                        (*p_5) = (((safe_div_func_int32_t_s_s_unsafe_macro/*39*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */(l_1855[2], ((*l_1733) ^= ((*g_620) = ((((((*g_220) == (((safe_sub_func_uint8_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */((((*l_1889) = (((safe_mul_func_uint16_t_u_u_unsafe_macro/*42*//* ___SAFE__OP */((((l_1873 <= (safe_mul_func_uint16_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((((((((safe_unary_minus_func_int64_t_s_unsafe_macro/*44*//* ___SAFE__OP */(0x1B039DD039B8863DLL)) != (safe_div_func_uint32_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */(l_1883, (((*l_1752) = l_1884) > (18446744073709551615UL > (((*l_1886) = ((*g_185) < 0x38DFBA48AB05BE9DLL)) , (***g_1862)))))) || l_1841), g_201[0][4])), 0x5334BD2EL))) <= g_11) , l_1887) != (*g_800)) <= l_1888) || l_1884), 8L))) & 6L) ^ 4294967295UL), (*g_597))) == 65535UL) && l_1855[0])) , l_1873), 1L)) & 1UL) , (void*)0)) , l_1890) != (void*)0) < 0UL) >= (*p_5)))))), 0x8D82DC61L)) == 1UL) , l_1891);
                    }
                    else
                    { /* block id: 815 */
                        g_1893 = l_1892;
                    }
                }
                else
                { /* block id: 818 */
                    int8_t l_1913[5] = {0x61L,0x61L,0x61L,0x61L,0x61L};
                    int i;
                    (*p_5) &= (0x66E52CB9L > ((void*)0 != l_1788));
                    for (g_1702.f2 = (-12); (g_1702.f2 <= 35); g_1702.f2++)
                    { /* block id: 822 */
                        uint32_t l_1897 = 0xEBD34CA8L;
                        int32_t l_1905 = 0x311F592EL;
                        int32_t l_1906[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
                        int8_t l_1912[7][6][6] = {{{(-8L),0L,0x0EL,9L,(-1L),0L},{0x68L,1L,1L,1L,0x68L,(-1L)},{(-1L),0xD1L,1L,(-7L),0xBCL,0x17L},{1L,(-1L),0xA9L,0xD1L,0x9EL,0x17L},{(-8L),0x0EL,1L,0x5BL,(-1L),(-1L)},{0x9EL,1L,1L,0x9EL,(-8L),0L}},{{0x5BL,1L,0x0EL,(-8L),9L,0L},{0x68L,(-8L),0L,(-9L),0xD1L,0L},{9L,(-1L),0x68L,1L,1L,1L},{0xE4L,(-9L),0xE4L,0x0EL,0L,0xD1L},{0xD1L,1L,(-7L),0xBCL,0x17L,(-1L)},{1L,0L,9L,0xBCL,0x9EL,0x0EL}},{{0xD1L,0x68L,1L,0x0EL,0x0EL,1L},{0xE4L,0xE4L,0xA9L,1L,(-1L),1L},{9L,(-7L),(-1L),(-9L),(-8L),0xA9L},{0x68L,9L,(-1L),1L,0xE4L,1L},{0L,1L,0xA9L,0x17L,0xA9L,1L},{0x17L,0xA9L,1L,0L,0L,0x0EL}},{{1L,(-1L),9L,0x68L,(-9L),(-1L)},{(-9L),(-1L),(-7L),9L,0L,0xD1L},{1L,0xA9L,0xE4L,0xE4L,0xA9L,1L},{0x0EL,1L,0x68L,0xD1L,0xE4L,0L},{0xBCL,9L,0L,1L,(-8L),(-7L)},{0xBCL,(-7L),1L,0xD1L,(-1L),(-8L)}},{{0x0EL,0xE4L,(-9L),0xE4L,0x0EL,0L},{1L,0x68L,(-1L),9L,0x9EL,(-1L)},{(-9L),0L,(-8L),0x68L,0x17L,(-1L)},{1L,1L,(-1L),0L,0L,0L},{0x17L,(-9L),(-9L),0x17L,1L,(-8L)},{0L,(-1L),1L,1L,0xD1L,(-7L)}},{{0x68L,(-8L),0L,(-9L),0xD1L,0L},{9L,(-1L),0x68L,1L,1L,1L},{0xE4L,(-9L),0xE4L,0x0EL,0L,0xD1L},{0xD1L,1L,(-7L),0xBCL,0x17L,(-1L)},{1L,0L,9L,0xBCL,0x9EL,0x0EL},{0xD1L,0x68L,1L,0x0EL,0x0EL,1L}},{{0xE4L,0xE4L,0xA9L,1L,(-1L),1L},{9L,(-7L),(-1L),(-9L),(-8L),0xA9L},{0x68L,9L,(-1L),1L,0xE4L,(-1L)},{(-7L),(-9L),(-8L),(-1L),(-8L),(-9L)},{(-1L),(-8L),(-9L),(-7L),(-8L),1L},{(-9L),1L,0xD1L,0x0EL,0x5BL,0L}}};
                        int i, j, k;
                        l_1852 &= (l_1897 , (safe_mul_func_int64_t_s_s_unsafe_macro/*48*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */((((l_1913[2] &= ((safe_unary_minus_func_int64_t_s_unsafe_macro/*50*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */(((((g_310[0]--) == l_1768) < (***g_618)) >= ((0xFCA8C135L && (+4294967295UL)) | 0x34FCC53DL)), l_1853[4][0][0])))) != (((safe_sub_func_int32_t_s_s_unsafe_macro/*52*//* ___SAFE__OP */(((***g_618) , (*p_5)), l_1854[0])) || l_1912[3][4][3]) , l_1855[2]))) , 65534UL) <= (*g_1420)), l_1906[7])), g_1177)));
                        if ((*p_5))
                            break;
                        (*p_5) &= 1L;
                    }
                }
                (*l_1915) = (((*l_1733) | ((**g_1862) != (void*)0)) , ((l_1854[0] <= l_1914) , &g_1035));
                (*p_5) = (8L <= l_1852);
                for (g_130 = (-29); (g_130 == 43); ++g_130)
                { /* block id: 834 */
                    int32_t *l_1918 = (void*)0;
                    int32_t *l_1919 = &l_1854[0];
                    int32_t *l_1920[6][4] = {{&g_1732,(void*)0,&g_1732,(void*)0},{&g_1732,(void*)0,&g_1732,(void*)0},{&g_1732,(void*)0,&g_1732,(void*)0},{&g_1732,(void*)0,&g_1732,(void*)0},{&g_1732,(void*)0,&g_1732,(void*)0},{&g_1732,(void*)0,&g_1732,(void*)0}};
                    uint16_t l_1921 = 0xAC52L;
                    int i, j;
                    --l_1921;
                    if ((!(65535UL && l_1734)))
                    { /* block id: 836 */
                        if ((*p_5))
                            break;
                        l_1925 = (p_3 = p_5);
                    }
                    else
                    { /* block id: 840 */
                        (*l_1733) ^= 0x7D1982E3L;
                    }
                    if (l_1853[4][0][0])
                        continue;
                }
            }
            return p_5;
        }
        (*g_1633) &= (safe_rshift_func_uint8_t_u_u_unsafe_macro/*53*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*54*//* ___SAFE__OP */(((*l_1930) = (*l_1733)), (0x1733FF9BD514A1C5LL > (((l_1734 && (safe_mul_func_uint32_t_u_u_unsafe_macro/*55*//* ___SAFE__OP */(((((((*l_1733) && (*g_185)) != (*l_1733)) , (safe_rshift_func_uint32_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */(0x832DB4AFL, (((*p_5) = ((g_201[1][6] , (void*)0) == (void*)0)) , 0x893A46B0L)))) ^ l_1744) & (*l_1733)), 4294967295UL))) || (*l_1733)) ^ l_1744)))), l_1816[0]));
    }
    else
    { /* block id: 851 */
        uint16_t l_1937[8][4] = {{65535UL,2UL,65535UL,0xC5A5L},{65530UL,2UL,0xA3F5L,2UL},{65530UL,0xC5A5L,65535UL,2UL},{65535UL,2UL,65535UL,0xC5A5L},{65530UL,2UL,0xA3F5L,2UL},{65530UL,0xC5A5L,65535UL,2UL},{65535UL,2UL,65535UL,0xC5A5L},{65530UL,2UL,0xA3F5L,2UL}};
        union U0 ** const l_1956[9][6][4] = {{{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432}},{{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432}},{{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432}},{{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432}},{{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432}},{{(void*)0,&g_432,(void*)0,&g_432},{&g_432,&g_432,&g_432,&g_432},{&g_432,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432}},{{&g_432,&g_432,&g_432,&g_432},{&g_432,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{&g_432,&g_432,&g_432,&g_432}},{{&g_432,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{&g_432,&g_432,&g_432,&g_432},{&g_432,&g_432,(void*)0,&g_432}},{{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,&g_432,&g_432},{(void*)0,&g_432,(void*)0,&g_432},{&g_432,&g_432,&g_432,&g_432},{&g_432,&g_432,(void*)0,&g_432},{(void*)0,&g_432,&g_432,&g_432}}};
        int16_t **l_1971 = (void*)0;
        int16_t ***l_1970[2];
        int16_t **** const l_1969[8][8][4] = {{{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[1],(void*)0,(void*)0},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],(void*)0,(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]}},{{&l_1970[1],&l_1970[0],&l_1970[1],&l_1970[0]},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]}},{{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[1],(void*)0,(void*)0},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],(void*)0,(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]}},{{&l_1970[1],&l_1970[0],&l_1970[1],&l_1970[0]},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]}},{{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[1],(void*)0,(void*)0},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],(void*)0,(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]}},{{&l_1970[1],&l_1970[0],&l_1970[1],&l_1970[0]},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]}},{{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[1],(void*)0,(void*)0},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],(void*)0,(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]}},{{&l_1970[1],&l_1970[0],&l_1970[1],&l_1970[0]},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],&l_1970[1],&l_1970[1],&l_1970[1]},{&l_1970[1],&l_1970[1],(void*)0,&l_1970[1]},{&l_1970[1],(void*)0,&l_1970[1],(void*)0},{&l_1970[1],&l_1970[0],(void*)0,&l_1970[0]}}};
        int32_t l_1976[4][2][5] = {{{(-8L),0xA93F1B03L,(-8L),(-8L),0xA93F1B03L},{0xA93F1B03L,(-8L),(-8L),0xA93F1B03L,(-8L)}},{{0xA93F1B03L,0xA93F1B03L,(-10L),0xA93F1B03L,0xA93F1B03L},{(-8L),0xA93F1B03L,(-8L),(-8L),0xA93F1B03L}},{{0xA93F1B03L,(-8L),(-8L),0xA93F1B03L,(-8L)},{(-8L),(-8L),0xA93F1B03L,(-8L),(-8L)}},{{(-10L),(-8L),(-10L),(-10L),(-8L)},{(-8L),(-10L),(-10L),(-8L),(-10L)}}};
        uint16_t l_1984[3][6][2] = {{{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL}},{{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL}},{{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL},{0x3807L,65533UL},{1UL,65533UL}}};
        int32_t *l_2017 = &l_1914;
        union U1 l_2034 = {0L};
        uint64_t l_2061 = 0UL;
        uint16_t ***l_2105 = &l_1718[0];
        uint8_t ****l_2149 = &g_1402;
        int16_t ****l_2157 = (void*)0;
        int16_t *****l_2156[5] = {&l_2157,&l_2157,&l_2157,&l_2157,&l_2157};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1970[i] = &l_1971;
        if (((1UL < ((safe_mul_func_int16_t_s_s_unsafe_macro/*57*//* ___SAFE__OP */(l_1937[7][1], l_1937[7][1])) == (safe_lshift_func_uint32_t_u_s_unsafe_macro/*58*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u(((safe_mul_func_int16_t_s_s_unsafe_macro/*60*//* ___SAFE__OP */((((g_1944[2] , ((safe_mod_func_int64_t_s_s((**g_1859), (safe_rshift_func_int32_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u_unsafe_macro/*63*//* ___SAFE__OP */((*g_185), (l_1937[3][0] > (!(safe_sub_func_uint16_t_u_u_unsafe_macro/*64*//* ___SAFE__OP */((*l_1733), (l_1937[7][1] <= 251UL))))))) & 0x1E247EE86EA347ACLL), 8)))) & l_1937[6][0])) <= l_1937[6][2]) , 0xA8FEL), 0xBE88L)) < 0UL), l_1954)), 13)))) , l_1937[7][1]))
        { /* block id: 852 */
            union U0 **l_1955 = &g_432;
            uint32_t *l_1957 = &g_11;
            int8_t *l_1958 = &g_201[1][0];
            (*g_1959) = func_46(((*l_1958) |= ((l_1955 != l_1956[3][0][1]) < ((g_160 = ((*l_1957) = l_1937[2][1])) <= (*l_1733)))), ((*g_595) = (*l_1733)));
            return (*g_1560);
        }
        else
        { /* block id: 859 */
            if (g_21)
                goto lbl_1960;
            for (g_367 = 0; (g_367 < (-17)); --g_367)
            { /* block id: 863 */
                int32_t *l_1963 = (void*)0;
                int32_t **l_1964 = &g_16[5];
                (*l_1964) = l_1963;
            }
        }
        (*g_1633) ^= (safe_sub_func_int8_t_s_s_unsafe_macro/*65*//* ___SAFE__OP */(((*g_597) >= ((***g_618) = (*l_1733))), g_1086.f0));
        for (l_1726 = (-30); (l_1726 == 1); ++l_1726)
        { /* block id: 871 */
            int32_t l_1986 = 1L;
            int32_t *****l_1989 = &g_801;
            uint32_t l_2019 = 0UL;
            const uint64_t l_2036[2][6][2] = {{{0UL,1UL},{0UL,0UL},{0UL,1UL},{0UL,0UL},{1UL,0UL},{0UL,1UL}},{{0UL,0UL},{0UL,1UL},{0UL,0UL},{1UL,0UL},{0UL,1UL},{0UL,0UL}}};
            union U1 **l_2075 = &g_1035;
            const uint64_t l_2111 = 0x342D399D288687E6LL;
            int16_t l_2117 = 0xE72EL;
            int16_t l_2121 = 1L;
            int32_t l_2122 = 0xE3300A19L;
            int32_t l_2123 = 1L;
            int32_t l_2125 = 9L;
            int32_t l_2126 = 0L;
            int32_t l_2127 = 0x9EFAB9FCL;
            int32_t l_2129 = 0L;
            int32_t l_2130 = (-1L);
            int32_t l_2131 = 0x06B7EC85L;
            int32_t l_2132 = (-2L);
            int32_t l_2133 = 0xF1279821L;
            int32_t l_2134 = 1L;
            int32_t l_2135 = 0xCB9B13A9L;
            int32_t l_2136[9][6] = {{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}};
            int i, j, k;
        }
        (*l_2113) = ((((l_2158[0][2][0] = l_2156[4]) == &l_2159[1][4]) == (&l_1996 == (void*)0)) >= (safe_mod_func_uint64_t_u_u_unsafe_macro/*66*//* ___SAFE__OP */(((*g_185) ^= 0xC7D1CF837B3CFE01LL), (safe_add_func_uint64_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */(((*l_1733) && (((*l_2017) ^ (*l_1733)) || (!((*l_2017) || (*l_2113))))), 0x849A6DD77A2328FCLL)))));
    }
    return l_2167;
}


/* ------------------------------------------ */
/* 
 * reads : g_1177 g_310 g_579 g_1666 g_1086 g_185 g_79 g_201 g_1633 g_620 g_130 g_592 g_593 g_1702 g_21 g_1308 g_16
 * writes: g_1177 g_201 g_79 g_21 g_130 g_1700
 */
static int32_t * func_6(int8_t  p_7, const uint64_t  p_8, uint16_t  p_9, int16_t  p_10)
{ /* block id: 585 */
    int64_t l_1353 = (-1L);
    uint64_t **l_1377 = &g_185;
    int32_t l_1379 = 0xB85BAFCEL;
    uint32_t l_1451 = 18446744073709551609UL;
    int32_t l_1483 = (-9L);
    int32_t l_1484 = 0xC9784C2BL;
    int32_t l_1485 = 0x04E56F72L;
    int32_t l_1486 = 0x29AF78BBL;
    int32_t l_1487 = 0xEA753121L;
    int32_t l_1488[8];
    uint32_t l_1513 = 0xEAB0D199L;
    uint16_t l_1549 = 1UL;
    uint64_t l_1559[4];
    union U1 l_1568 = {0x42C4BA64L};
    int16_t l_1638 = (-5L);
    int i;
    for (i = 0; i < 8; i++)
        l_1488[i] = (-2L);
    for (i = 0; i < 4; i++)
        l_1559[i] = 2UL;
    for (g_1177 = (-26); (g_1177 <= 12); g_1177++)
    { /* block id: 588 */
        int16_t l_1342[9] = {0L,0xA19BL,0L,0L,0xA19BL,0L,0L,0xA19BL,0L};
        int32_t l_1354 = (-1L);
        int16_t l_1355 = 0x467AL;
        uint16_t **l_1364 = &g_620;
        const union U2 l_1387 = {0L};
        int32_t *l_1447[1];
        uint8_t l_1456 = 0x05L;
        int32_t l_1489[4] = {0x34C821FEL,0x34C821FEL,0x34C821FEL,0x34C821FEL};
        uint32_t l_1491 = 0x33EDBCD4L;
        uint64_t l_1521 = 0x6CA60FAEADD05486LL;
        int32_t *l_1524 = &g_21;
        const int32_t l_1546 = 3L;
        uint16_t l_1562[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
        int i;
        for (i = 0; i < 1; i++)
            l_1447[i] = &g_579[4];
    }
    for (l_1483 = 1; (l_1483 >= 0); l_1483 -= 1)
    { /* block id: 712 */
        int32_t l_1682[5];
        union U1 ** const l_1683 = &g_1035;
        int i;
        for (i = 0; i < 5; i++)
            l_1682[i] = 0L;
        if (g_310[l_1483])
            break;
        for (l_1353 = 1; (l_1353 >= 0); l_1353 -= 1)
        { /* block id: 716 */
            int16_t * const *l_1681[7];
            int8_t *l_1684 = (void*)0;
            int8_t *l_1685 = &g_201[1][0];
            int8_t *l_1686 = (void*)0;
            int8_t *l_1687 = (void*)0;
            int8_t *l_1688[5][2];
            int32_t l_1689 = 0xF8B4736DL;
            union U0 *****l_1701 = &g_872;
            int64_t *l_1703 = (void*)0;
            int32_t *l_1705 = &l_1488[0];
            int i, j;
            for (i = 0; i < 7; i++)
                l_1681[i] = &g_599;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1688[i][j] = (void*)0;
            }
            (*g_1633) = ((g_310[l_1483] == g_579[(l_1353 + 6)]) | ((safe_sub_func_uint16_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */((g_579[(l_1353 + 1)] <= ((*g_185) = (safe_div_func_uint32_t_u_u_unsafe_macro/*69*//* ___SAFE__OP */(g_579[(l_1353 + 1)], (safe_lshift_func_int64_t_s_s_unsafe_macro/*70*//* ___SAFE__OP */((g_1666 , ((((safe_rshift_func_int8_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*72*//* ___SAFE__OP */(0xB96AL, g_579[(l_1353 + 6)])), 6)) == (safe_sub_func_int8_t_s_s_unsafe_macro/*73*//* ___SAFE__OP */((l_1689 ^= ((((*l_1685) &= (((safe_mul_func_uint16_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */((p_9 &= (safe_lshift_func_int32_t_s_s_unsafe_macro/*75*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*76*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */(((l_1682[1] |= ((g_579[(l_1353 + 1)] , ((g_1086 , l_1681[3]) != (void*)0)) , (*g_185))) , 0xCC2BD6F6BBD75329LL), 18446744073709551615UL)), p_10)), 12))), p_7)) , l_1683) != &g_221)) & l_1486) == g_579[(l_1353 + 6)])), p_10))) ^ (*g_185)) != l_1488[0])), 5)))))), g_310[l_1483])) , l_1682[3]));
            (*l_1705) = ((*g_1633) = ((((*g_620)++) >= 0x2612L) , ((safe_sub_func_uint32_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */(((0x47BDL & ((l_1682[1] = ((safe_sub_func_int64_t_s_s_unsafe_macro/*79*//* ___SAFE__OP */(((void*)0 != (*g_592)), ((((safe_mod_func_uint16_t_u_u_unsafe_macro/*80*//* ___SAFE__OP */(l_1682[1], (safe_sub_func_uint32_t_u_u_unsafe_macro/*81*//* ___SAFE__OP */((((g_1700 = (void*)0) == (l_1701 = &g_872)) != 0x0741L), (((g_1702 , 0L) | 65533UL) > p_9))))) , p_10) < g_579[(l_1353 + 1)]) , (*g_185)))) >= (*g_185))) >= g_310[l_1483])) > (*g_1633)), 0xB3A5306CL)) ^ 1L)));
        }
    }
    return (*g_1308);
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_18 g_36 g_64.f0 g_77 g_79 g_32 g_55 g_11 g_157 g_159 g_20 g_126 g_171 g_177 g_19 g_16 g_873 g_488 g_1086 g_618 g_619 g_620 g_130 g_185 g_515 g_310 g_595 g_975 g_1152 g_1135.f0 g_1177 g_223.f0 g_1204 g_461 g_915.f0 g_735 g_958 g_35 g_1308 g_199 g_1035 g_1036
 * writes: g_21 g_32 g_36 g_55 g_77 g_79 g_126 g_130 g_157 g_159 g_160 g_177 g_185 g_199 g_201 g_228 g_1086.f0 g_16 g_958.f1 g_482 g_220 g_483 g_975 g_1152 g_1177 g_860.f2 g_461 g_1135.f0 g_735
 */
static uint16_t  func_12(int32_t * p_13, int32_t * p_14, const int32_t * p_15)
{ /* block id: 1 */
    union U2 *l_1137[4][8] = {{&g_1135,&g_1135,&g_1135,&g_1135,(void*)0,&g_1135,&g_1135,&g_1135},{&g_1135,(void*)0,&g_1135,&g_1135,(void*)0,&g_1135,&g_1135,&g_1135},{&g_1135,&g_1135,&g_1135,&g_1135,&g_1135,&g_1135,(void*)0,&g_1135},{&g_1135,&g_1135,&g_1135,&g_1135,&g_1135,&g_1135,&g_1135,&g_1135}};
    union U2 **l_1136 = &l_1137[2][7];
    union U0 ** const l_1143 = &g_432;
    union U0 **l_1145 = &g_432;
    int32_t l_1149 = (-8L);
    union U1 l_1153 = {0xB08383ABL};
    int16_t ** const **l_1181 = &g_592;
    int8_t l_1193 = 1L;
    int16_t l_1194 = (-1L);
    int32_t *l_1195[9] = {&g_36,&g_21,&g_36,&g_21,&g_36,&g_21,&g_21,&g_36,&g_21};
    uint16_t l_1196 = 1UL;
    const uint64_t l_1245 = 0UL;
    int16_t l_1282[1][10] = {{0L,9L,0L,0L,9L,0L,0L,9L,0L,0L}};
    uint32_t l_1322 = 18446744073709551615UL;
    int i, j;
    for (g_21 = 0; (g_21 >= (-9)); g_21 = safe_sub_func_uint32_t_u_u_unsafe_macro/*82*//* ___SAFE__OP */(g_21, 6))
    { /* block id: 4 */
        const uint16_t l_30 = 0x0D13L;
        union U2 *l_1134 = &g_1135;
        union U2 **l_1133 = &l_1134;
        union U0 ***l_1144[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint64_t *l_1150 = &g_975;
        uint64_t *l_1151 = &g_1152;
        int32_t *l_1176 = &g_1177;
        int i;
        (*l_1176) ^= func_24((((safe_add_func_uint64_t_u_u_unsafe_macro/*83*//* ___SAFE__OP */((func_28(l_30) ^ (safe_lshift_func_int64_t_s_s((((safe_sub_func_uint64_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((l_1133 != l_1136), (((*l_1151) ^= ((*l_1150) ^= (safe_div_func_int16_t_s_s(l_30, ((*g_595) = (+(safe_mod_func_int16_t_s_s_unsafe_macro/*87*//* ___SAFE__OP */((l_1143 == (l_1145 = (void*)0)), (+((safe_mul_func_int64_t_s_s_unsafe_macro/*88*//* ___SAFE__OP */((l_1149 >= ((l_30 < g_310[0]) != 0L)), l_30)) < l_30)))))))))) == l_1149))) | g_1135.f0) == 2L), g_1135.f0))), l_1149)) || (*g_620)) , l_1153));
    }
    if ((l_1196 ^= ((safe_unary_minus_func_int64_t_s_unsafe_macro/*89*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*90*//* ___SAFE__OP */(((void*)0 != l_1181), (((void*)0 == &g_201[0][4]) || (safe_rshift_func_int8_t_s_u((((safe_rshift_func_int16_t_s_s((+l_1149), 4)) , (safe_mul_func_uint16_t_u_u_unsafe_macro/*93*//* ___SAFE__OP */(65535UL, ((safe_mod_func_int32_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */(l_1149, l_1153.f0)) != ((safe_add_func_int8_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */(((0xC735A4B8L | l_1193) && l_1149), l_1193)) | (-5L)))))) | l_1194), 5))))) & 8UL))) & (***g_618))))
    { /* block id: 525 */
        uint8_t *l_1197 = (void*)0;
        uint8_t *l_1198 = (void*)0;
        uint8_t *l_1199 = (void*)0;
        uint8_t *l_1200 = &g_860.f2;
        int64_t *l_1201 = &g_159;
        const int32_t l_1203 = 0xC2E93DA8L;
        int8_t *l_1217 = &g_201[0][4];
        int32_t l_1218 = 8L;
        l_1218 ^= ((((*l_1201) ^= (g_223[0][0].f0 != ((*l_1200) = ((void*)0 != l_1181)))) && 0xB7FB54CB314AE90DLL) , (((*g_620) = (~l_1203)) >= ((g_1204[4][3] , (safe_mod_func_int64_t_s_s_unsafe_macro/*96*//* ___SAFE__OP */(((*l_1201) = (safe_rshift_func_int16_t_s_s((safe_add_func_int32_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_u_unsafe_macro/*99*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*100*//* ___SAFE__OP */(((safe_div_func_uint64_t_u_u_unsafe_macro/*101*//* ___SAFE__OP */(18446744073709551615UL, (*g_185))) < (((*l_1217) = (l_1203 & (-1L))) | g_177[0][0][3])), l_1203)), 22)) > 65535UL), l_1203)), l_1203))), (-1L)))) == l_1203)));
    }
    else
    { /* block id: 532 */
        uint8_t l_1226[3];
        uint32_t l_1250 = 0x783775D0L;
        int32_t l_1253 = 0x74AAB75DL;
        union U1 **l_1266 = &g_1035;
        int32_t l_1285 = 0x0FBA8E47L;
        int32_t l_1287 = 1L;
        int32_t l_1290 = 1L;
        int32_t l_1292 = (-1L);
        int32_t l_1294 = 0x87C8D270L;
        int32_t l_1296 = 0x33B076DCL;
        int32_t l_1298 = 0x93E6EA16L;
        int32_t l_1299 = 0x6F3ED6D3L;
        int32_t l_1303 = (-4L);
        uint32_t l_1305 = 0UL;
        int8_t l_1311 = 1L;
        int i;
        for (i = 0; i < 3; i++)
            l_1226[i] = 0xE6L;
        for (g_461 = 0; (g_461 <= 1); g_461 += 1)
        { /* block id: 535 */
            int16_t l_1230 = 0x5989L;
            union U2 **l_1241 = (void*)0;
            union U2 l_1244 = {0x59F8B7255BCF0283LL};
            uint16_t l_1246[4];
            int32_t l_1249[6][8][3] = {{{(-1L),0x29503B17L,(-9L)},{0xD5CE9E83L,(-3L),0x21470776L},{8L,0x29503B17L,0xECC633C3L},{0x21470776L,0x8F37A8ACL,0x20E6C0A7L},{8L,0x9308995EL,8L},{0xD5CE9E83L,0x371A78AAL,0x20E6C0A7L},{(-1L),0x55FF70DDL,0xECC633C3L},{1L,0x371A78AAL,0x21470776L}},{{0xECC633C3L,0x9308995EL,(-9L)},{1L,0x8F37A8ACL,1L},{(-1L),0x29503B17L,(-9L)},{0xD5CE9E83L,(-3L),0x21470776L},{8L,0x29503B17L,0xECC633C3L},{0x21470776L,0x8F37A8ACL,0x20E6C0A7L},{8L,0x9308995EL,8L},{0xD5CE9E83L,0x371A78AAL,0x20E6C0A7L}},{{(-1L),0x55FF70DDL,0xECC633C3L},{1L,0x371A78AAL,0x21470776L},{0xECC633C3L,0x9308995EL,(-9L)},{1L,0x8F37A8ACL,1L},{(-1L),0x29503B17L,(-9L)},{0xD5CE9E83L,(-3L),0x21470776L},{8L,0x29503B17L,0xECC633C3L},{0x21470776L,0x8F37A8ACL,0x20E6C0A7L}},{{8L,0x9308995EL,8L},{0xD5CE9E83L,0x371A78AAL,0x20E6C0A7L},{(-1L),0x55FF70DDL,0xECC633C3L},{1L,0x371A78AAL,0x21470776L},{0xECC633C3L,0x9308995EL,(-9L)},{1L,0x8F37A8ACL,1L},{(-1L),0x29503B17L,(-9L)},{0xD5CE9E83L,(-3L),0x21470776L}},{{8L,0x29503B17L,0xECC633C3L},{0x21470776L,0x8F37A8ACL,0x20E6C0A7L},{8L,0x9308995EL,8L},{0xD5CE9E83L,0x371A78AAL,0x20E6C0A7L},{(-1L),0x55FF70DDL,0xECC633C3L},{1L,0x371A78AAL,0x21470776L},{0xECC633C3L,0x9308995EL,(-9L)},{1L,0x8F37A8ACL,1L}},{{(-1L),0x29503B17L,(-9L)},{0xD5CE9E83L,(-3L),0x21470776L},{8L,0x29503B17L,0xECC633C3L},{0x21470776L,0x8F37A8ACL,0x20E6C0A7L},{8L,0x9308995EL,8L},{0xD5CE9E83L,0x371A78AAL,0x20E6C0A7L},{(-1L),0x55FF70DDL,0xECC633C3L},{1L,0x371A78AAL,0x21470776L}}};
            uint64_t l_1280 = 3UL;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_1246[i] = 0UL;
            if ((((safe_sub_func_uint8_t_u_u_unsafe_macro/*102*//* ___SAFE__OP */((((*g_185) = (((safe_rshift_func_int16_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */(0xE62CL, (((+(safe_add_func_int16_t_s_s_unsafe_macro/*104*//* ___SAFE__OP */(l_1226[2], (safe_sub_func_int16_t_s_s_unsafe_macro/*105*//* ___SAFE__OP */(((!1UL) && l_1230), (-1L)))))) != (safe_mul_func_int16_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */(((((l_1230 ^ (safe_rshift_func_int8_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*108*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*109*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*110*//* ___SAFE__OP */((l_1241 == l_1241), (g_1135.f0 ^= (safe_div_func_int16_t_s_s_unsafe_macro/*111*//* ___SAFE__OP */(l_1230, l_1230))))), 255UL)), 10)), 7))) != l_1226[2]) <= g_915.f0) != l_1230), l_1226[2]))) != g_310[0]))) == 0x7FADD3D4L) , (*g_185))) == l_1230), l_1226[2])) , l_1244) , l_1245))
            { /* block id: 538 */
                l_1246[1]++;
                --l_1250;
                l_1253 = 0x868BAC8DL;
            }
            else
            { /* block id: 542 */
                uint32_t l_1257[6][1] = {{8UL},{18446744073709551615UL},{8UL},{18446744073709551615UL},{8UL},{18446744073709551615UL}};
                int32_t l_1284 = 1L;
                int32_t l_1286 = 9L;
                int32_t l_1288 = (-2L);
                int32_t l_1289 = 0xF1C7F24DL;
                int32_t l_1293 = 0x49313A70L;
                int32_t l_1295 = 0x675CFBB9L;
                int32_t l_1297 = 0x111BA144L;
                int32_t l_1300 = 0L;
                int32_t l_1301 = 1L;
                int32_t l_1302 = 0x6CFFA81DL;
                int32_t l_1304[8] = {0x5B35964FL,3L,0x5B35964FL,3L,0x5B35964FL,3L,0x5B35964FL,3L};
                int i, j;
                l_1249[1][4][2] &= (!(safe_add_func_uint8_t_u_u_unsafe_macro/*112*//* ___SAFE__OP */(l_1226[2], (l_1257[2][0] = 0UL))));
                for (g_735 = 0; (g_735 <= 3); g_735 += 1)
                { /* block id: 547 */
                    uint16_t l_1281[3];
                    int32_t l_1283[1][3][1];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_1281[i] = 65528UL;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 3; j++)
                        {
                            for (k = 0; k < 1; k++)
                                l_1283[i][j][k] = 0x99CEAF29L;
                        }
                    }
                    l_1283[0][0][0] |= ((safe_add_func_int32_t_s_s_unsafe_macro/*113*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*114*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*115*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */(((void*)0 == l_1266), l_1246[2])) == (safe_unary_minus_func_uint32_t_u_unsafe_macro/*117*//* ___SAFE__OP */((g_958 , l_1226[1])))), (safe_div_func_int32_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*119*//* ___SAFE__OP */(l_1257[2][0], ((safe_mul_func_int8_t_s_s_unsafe_macro/*120*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*121*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*122*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*123*//* ___SAFE__OP */(((l_1250 <= (&l_1196 != (void*)0)) & 0x525DAE679A9ED357LL), l_1253)), l_1280)) , 0x65566A0DL), l_1281[1])), l_1230)) <= (*g_620)))) != 0xC8L) ^ l_1282[0][8]), l_1257[3][0])))), l_1226[0])), l_1257[2][0])) != l_1250);
                }
                ++l_1305;
                l_1290 = l_1298;
            }
            for (g_735 = 0; (g_735 <= 3); g_735 += 1)
            { /* block id: 555 */
                int16_t l_1321 = 1L;
                for (l_1303 = 0; (l_1303 <= 1); l_1303 += 1)
                { /* block id: 558 */
                    for (l_1244.f1 = 0; (l_1244.f1 <= 2); l_1244.f1 += 1)
                    { /* block id: 561 */
                        int i, j, k;
                        (*g_1308) = func_46(g_35[(g_461 + 7)][g_735], l_1249[(l_1303 + 1)][l_1244.f1][l_1303]);
                    }
                }
                for (g_199 = 0; (g_199 <= 9); g_199 += 1)
                { /* block id: 567 */
                    int8_t l_1316 = 0x7AL;
                    uint32_t *l_1325[5] = {&g_160,&g_160,&g_160,&g_160,&g_160};
                    int32_t l_1326[6][9] = {{1L,0xAD2ABBCDL,0L,0xEF90DABCL,(-8L),8L,0L,0xB88E1AC0L,0xEF90DABCL},{0xEE2832FBL,0xC3E5ADFEL,0x614BEB31L,(-3L),(-1L),1L,0xC3E5ADFEL,1L,(-1L)},{0x614BEB31L,0xB88E1AC0L,0xB88E1AC0L,0x614BEB31L,5L,1L,(-3L),(-8L),0x6D0F9EECL},{0L,(-3L),0x72254B68L,(-1L),(-7L),8L,0x6A8CC7B1L,0x72254B68L,0xB88E1AC0L},{(-8L),1L,0xF8097918L,0x93383BC0L,5L,(-8L),5L,0x93383BC0L,0xF8097918L},{(-7L),(-7L),(-8L),0x93383BC0L,(-1L),0L,0L,(-3L),0x93383BC0L}};
                    int i, j;
                    if ((l_1326[3][8] &= ((0x5CADF9B6L != (g_228 = (((safe_mod_func_uint64_t_u_u_unsafe_macro/*124*//* ___SAFE__OP */(18446744073709551611UL, ((l_1311 ^ ((safe_lshift_func_int64_t_s_s_unsafe_macro/*125*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s_unsafe_macro/*126*//* ___SAFE__OP */(l_1316, ((safe_sub_func_uint32_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*128*//* ___SAFE__OP */(((l_1249[1][4][2] = l_1321) < l_1316), l_1321)) <= l_1322), (safe_add_func_uint64_t_u_u_unsafe_macro/*129*//* ___SAFE__OP */((7L > l_1321), 0xC3C5A8988AB23CA7LL)))) >= l_1321))) ^ l_1321) & l_1246[1]), 11)) <= (*g_185))) && (*g_185)))) < 4294967293UL) ^ 65535UL))) == (*g_620))))
                    { /* block id: 571 */
                        int i, j;
                        l_1137[g_735][g_461] = (*l_1136);
                        l_1290 |= ((*g_1035) , 1L);
                        return l_1294;
                    }
                    else
                    { /* block id: 575 */
                        if (l_1326[5][1])
                            break;
                        return (***g_618);
                    }
                }
            }
        }
        return l_1250;
    }
    return (***g_618);
}


/* ------------------------------------------ */
/* 
 * reads : g_32
 * writes:
 */
static int32_t  func_24(union U1  p_25)
{ /* block id: 518 */
    int64_t l_1154[2];
    int32_t *l_1155 = &g_157;
    int32_t *l_1156 = &g_36;
    int32_t *l_1157 = &g_126;
    int32_t *l_1158 = &g_32;
    int32_t *l_1159 = (void*)0;
    int32_t l_1160 = 0x5CE920C7L;
    int32_t l_1161 = 0xD00E2229L;
    int32_t *l_1162 = &l_1160;
    int32_t *l_1163 = &g_126;
    int32_t *l_1164 = &l_1161;
    int32_t *l_1165 = &g_126;
    int32_t *l_1166 = &l_1160;
    int32_t *l_1167 = (void*)0;
    int32_t l_1168 = 0xFC299B39L;
    int32_t *l_1169 = (void*)0;
    int32_t *l_1170[7][7] = {{&g_126,&g_32,&g_32,&g_126,&l_1168,&l_1168,&l_1168},{&g_36,&g_32,&g_32,&g_32,&g_36,&g_32,&g_32},{&l_1168,&g_126,&g_32,&g_32,&g_126,&l_1168,&l_1168},{&l_1168,&g_126,&l_1168,&g_32,&l_1168,&g_126,&l_1168},{&l_1168,&g_32,&l_1168,&g_126,&g_126,&l_1168,&g_32},{&g_36,&g_126,&g_32,&g_126,&g_36,&g_126,&g_32},{&g_126,&g_126,&l_1168,&g_32,&l_1168,&l_1168,&g_32}};
    int32_t l_1171[8][1][2];
    int32_t l_1172 = 0x8C585692L;
    uint32_t l_1173 = 0x977A2A63L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1154[i] = 0x85F7DB6E9188172ELL;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
                l_1171[i][j][k] = 0xDF127216L;
        }
    }
    ++l_1173;
    l_1164 = &l_1160;
    return (*l_1158);
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_18 g_36 g_21 g_64.f0 g_77 g_79 g_55 g_11 g_157 g_159 g_20 g_126 g_171 g_177 g_19 g_16 g_873 g_488 g_1086 g_618 g_619 g_620 g_130 g_185 g_515 g_958.f1 g_482
 * writes: g_32 g_36 g_55 g_77 g_79 g_126 g_130 g_157 g_159 g_160 g_177 g_185 g_199 g_201 g_228 g_1086.f0 g_16 g_958.f1 g_482 g_220
 */
static int16_t  func_28(const uint32_t  p_29)
{ /* block id: 5 */
    const int8_t l_124 = 0x00L;
    int32_t *l_1075[6];
    int32_t l_1120[2];
    int32_t *l_1121 = &l_1120[1];
    union U1 **l_1128[10];
    int i;
    for (i = 0; i < 6; i++)
        l_1075[i] = &g_126;
    for (i = 0; i < 2; i++)
        l_1120[i] = 0x2E6698BBL;
    for (i = 0; i < 10; i++)
        l_1128[i] = &g_221;
    for (g_32 = 10; (g_32 != (-9)); --g_32)
    { /* block id: 8 */
        int32_t l_49 = 0x7854C3EBL;
        int64_t l_127 = (-2L);
        for (g_36 = 23; (g_36 != (-13)); g_36 = safe_sub_func_uint64_t_u_u_unsafe_macro/*130*//* ___SAFE__OP */(g_36, 9))
        { /* block id: 11 */
            uint8_t *l_54 = &g_55[0][1];
            int32_t *l_125 = &g_126;
            uint16_t *l_128 = (void*)0;
            uint16_t *l_129 = &g_130;
            l_1120[1] &= func_39(((!1L) , func_43((l_1075[2] = func_46((l_49 >= 7L), ((safe_sub_func_int64_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*132*//* ___SAFE__OP */(g_18, ((*l_129) = (((*l_125) = (((*l_54) = (6UL == (g_36 && g_21))) , ((safe_mul_func_int8_t_s_s_unsafe_macro/*133*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*134*//* ___SAFE__OP */((func_60(p_29) <= 65535UL), l_124)), 0x20L)) , 0x39807974L))) ^ l_127)))), 0x227E61D7D123A237LL)) ^ g_32))), p_29)), g_36);
        }
    }
    l_1121 = &l_1120[1];
    for (g_958.f1 = 0; (g_958.f1 >= 47); ++g_958.f1)
    { /* block id: 503 */
        int8_t l_1124[7][7][4] = {{{(-1L),0xBCL,(-4L),0xCFL},{0x45L,0x9BL,0xD0L,0xBCL},{0xBCL,(-8L),0xD0L,0xCCL},{0x45L,0L,(-4L),0xD0L},{(-1L),0x9AL,9L,0x4BL},{9L,0x4BL,0x9BL,2L},{0L,0x9BL,(-1L),(-4L)}},{{0x4BL,(-5L),0xB3L,0xB3L},{0x45L,0x45L,0L,0xC9L},{2L,(-8L),0x8CL,0x4BL},{(-1L),0L,(-4L),0x8CL},{(-1L),0L,(-1L),0x4BL},{0L,(-8L),1L,0xC9L},{0L,0x45L,0L,0xB3L}},{{(-1L),(-5L),0xCFL,(-4L)},{(-1L),0x9BL,0L,2L},{0xA1L,0x4BL,0xD0L,0x4BL},{0x9BL,0x9AL,0xB3L,0xD0L},{(-1L),0L,0L,0xCCL},{9L,(-8L),(-1L),0xBCL},{9L,0x9BL,0L,0xCFL}},{{(-1L),0xBCL,0xB3L,(-4L)},{0x9BL,(-10L),0xD0L,0x70L},{(-4L),0L,(-1L),0x9AL},{(-1L),0xA1L,0xD0L,(-1L)},{(-1L),2L,2L,(-1L)},{0xBCL,9L,0L,0xCFL},{2L,0xE6L,(-5L),0x60L}},{{0L,(-4L),0x8CL,0x60L},{(-1L),0xE6L,1L,0xCFL},{0xB3L,9L,(-1L),(-1L)},{9L,2L,0x60L,(-1L)},{9L,0xA1L,(-5L),0x9AL},{0xBCL,0L,5L,0x70L},{0xC9L,0xE6L,0xC9L,0x8CL}},{{(-1L),0xCFL,0x8CL,0xD0L},{9L,5L,(-10L),0xCFL},{0xCFL,0L,(-10L),0x9AL},{9L,0xBCL,0x8CL,(-10L)},{(-1L),0xA1L,0xC9L,9L},{0xC9L,9L,5L,0xB3L},{0xBCL,5L,(-5L),0x8CL}},{{9L,0x6DL,0x60L,0x60L},{9L,9L,(-1L),0x70L},{0xB3L,0L,1L,9L},{(-1L),2L,0x8CL,1L},{0L,2L,(-5L),9L},{2L,0L,0L,0x70L},{0xBCL,9L,2L,0x60L}}};
        union U1 ** const l_1127 = &g_221;
        int i, j, k;
        if (l_1124[2][3][1])
            break;
        for (g_482 = 0; (g_482 != 38); ++g_482)
        { /* block id: 507 */
            return p_29;
        }
        (*l_1121) = ((void*)0 != l_1127);
    }
    g_220 = l_1128[9];
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_36
 * writes: g_16
 */
static int32_t  func_39(uint64_t  p_40, uint64_t  p_41)
{ /* block id: 491 */
    int32_t * const l_1101 = &g_36;
    int32_t **l_1102 = &g_16[6];
    int32_t *l_1103 = &g_126;
    int32_t *l_1104 = &g_157;
    int32_t *l_1105 = (void*)0;
    int32_t *l_1106 = &g_126;
    int32_t *l_1107 = &g_126;
    int32_t *l_1108 = &g_126;
    int32_t *l_1109 = &g_157;
    int32_t l_1110 = (-5L);
    int32_t *l_1111 = (void*)0;
    int32_t *l_1112 = &l_1110;
    int32_t *l_1113[8][8] = {{&g_21,&g_36,(void*)0,(void*)0,&g_36,&g_21,&l_1110,&g_21},{&g_36,&g_21,&l_1110,&g_21,&g_36,(void*)0,(void*)0,&g_36},{&g_21,&l_1110,&l_1110,&g_21,&g_157,&g_36,&g_157,&g_21},{&l_1110,&g_157,&l_1110,(void*)0,&l_1110,&l_1110,(void*)0,&l_1110},{&g_157,&g_157,&l_1110,&g_36,&g_36,&g_36,&l_1110,&g_157},{&g_157,&l_1110,(void*)0,&l_1110,&l_1110,(void*)0,&l_1110,&g_157},{&l_1110,&g_21,&g_157,&g_36,&g_157,&g_21,&l_1110,&l_1110},{&g_21,&g_36,(void*)0,(void*)0,&g_36,&g_21,&l_1110,&g_21}};
    uint32_t l_1114[9][10] = {{0xCC3A541BL,0x5EBD08F3L,0xC06FE823L,0x39BBE7C4L,1UL,18446744073709551609UL,1UL,0x39BBE7C4L,0xC06FE823L,0x5EBD08F3L},{1UL,0UL,0xD5055EAFL,18446744073709551615UL,0x60D6EDBFL,0x3744235FL,1UL,1UL,0xA1C04892L,18446744073709551615UL},{0xD5055EAFL,0x5EBD08F3L,0xC06FE823L,0UL,0xD5055EAFL,0UL,0xC06FE823L,1UL,0x8BC776E9L,6UL},{0x60D6EDBFL,0UL,0xCC3A541BL,1UL,0xD5055EAFL,0x5EBD08F3L,0xA1C04892L,0x3744235FL,0xCC3A541BL,0x3744235FL},{0xD5055EAFL,18446744073709551609UL,0xB408B79EL,1UL,0xB408B79EL,18446744073709551609UL,0xD5055EAFL,6UL,0x8BC776E9L,1UL},{0x8BC776E9L,0x3744235FL,0xB408B79EL,0UL,0x60D6EDBFL,6UL,0xC06FE823L,0x3744235FL,0xC06FE823L,6UL},{0xA1C04892L,0x3744235FL,0xCC3A541BL,0x3744235FL,0xA1C04892L,0x5EBD08F3L,0xD5055EAFL,1UL,0xCC3A541BL,0UL},{0xA1C04892L,18446744073709551609UL,0xC06FE823L,0UL,0xB408B79EL,6UL,0xA1C04892L,6UL,0xB408B79EL,0UL},{0x8BC776E9L,0UL,0x8BC776E9L,0UL,0xA1C04892L,18446744073709551609UL,0xC06FE823L,0UL,0xB408B79EL,6UL}};
    uint32_t l_1117 = 4UL;
    int i, j;
    (*l_1102) = l_1101;
    (*l_1102) = (*l_1102);
    ++l_1114[7][8];
    ++l_1117;
    return (*l_1101);
}


/* ------------------------------------------ */
/* 
 * reads : g_873 g_488 g_1086 g_618 g_619 g_620 g_130 g_157 g_185 g_79 g_515 g_55 g_177 g_126
 * writes: g_130 g_201 g_159 g_228 g_77 g_1086.f0 g_79 g_126
 */
static uint64_t  func_43(int32_t * p_44, uint8_t  p_45)
{ /* block id: 479 */
    union U0 **l_1081 = &g_432;
    int16_t **l_1088 = &g_599;
    int16_t ***l_1087 = &l_1088;
    int16_t ****l_1089 = &l_1087;
    union U1 **l_1094 = &g_1035;
    int64_t *l_1095 = &g_159;
    int32_t l_1096[8] = {0x52C4BD86L,0x52C4BD86L,0x52C4BD86L,0x52C4BD86L,0x52C4BD86L,0x52C4BD86L,0x52C4BD86L,0x52C4BD86L};
    int32_t l_1097 = 0x75831773L;
    uint32_t *l_1098 = &g_228;
    union U2 *l_1099 = (void*)0;
    int32_t *l_1100 = &g_126;
    int i;
    (*l_1100) = ((safe_div_func_int64_t_s_s_unsafe_macro/*135*//* ___SAFE__OP */((((*g_185) = (((g_1086.f0 = (g_77 = ((+(safe_mul_func_uint64_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */(((l_1081 != (*g_873)) , ((((((*l_1098) = (safe_rshift_func_int64_t_s_s((safe_mod_func_int16_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */((((((g_1086 , (l_1096[3] = (0xA6FC92D1F983E6BBLL && ((((***g_618) ^= (((*l_1089) = l_1087) != &g_719[0][5][3])) , ((safe_mod_func_uint64_t_u_u((&g_592 != (void*)0), ((*l_1095) = (safe_rshift_func_int32_t_s_u_unsafe_macro/*140*//* ___SAFE__OP */(((g_201[0][4] = (l_1094 != &g_1035)) ^ p_45), 11))))) && 0x9D540F495C8E5EDFLL)) && g_157)))) == l_1097) || 0x03L) || (-4L)) ^ (*g_185)), p_45)), l_1097))) < l_1097) , (void*)0) != l_1099) == 0x42D42BEDL)), g_515))) & g_157))) , 0UL) < 0x87F2L)) & g_55[0][2]), g_177[0][0][2])) ^ l_1097);
    return (*l_1100);
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_11 g_157 g_159 g_20 g_64.f0 g_126 g_21 g_171 g_177 g_19 g_16
 * writes: g_77 g_126 g_130 g_157 g_159 g_160 g_177 g_185 g_199 g_201
 */
static int32_t * func_46(int8_t  p_47, int16_t  p_48)
{ /* block id: 41 */
    uint32_t l_158 = 0x79A4C43AL;
    int32_t l_162 = 0x2A3EB5BAL;
    uint64_t *l_187[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t **l_208 = &g_16[0];
    int32_t ***l_209[2];
    int64_t *l_211 = &g_159;
    union U2 l_216 = {-1L};
    union U1 **l_222 = &g_221;
    int8_t *l_314 = (void*)0;
    uint64_t l_347 = 18446744073709551608UL;
    int32_t *l_349[5];
    int16_t l_408 = 0xCA1EL;
    uint32_t l_423 = 4294967293UL;
    int32_t *l_463 = &g_157;
    int16_t *l_550 = &l_408;
    int16_t **l_549 = &l_550;
    int16_t *** const l_548[1] = {&l_549};
    uint16_t *l_552 = &g_130;
    uint16_t **l_551 = &l_552;
    uint64_t **l_566 = &g_185;
    union U0 ***l_668 = &g_488[4];
    uint16_t l_711 = 0x8CB6L;
    const uint16_t l_745 = 2UL;
    int32_t l_883 = 0xE8922C8CL;
    const uint16_t *l_938 = (void*)0;
    const uint16_t **l_937 = &l_938;
    const uint16_t ***l_936[7];
    const uint16_t ****l_935 = &l_936[0];
    union U0 *l_957[5];
    uint32_t l_979 = 0UL;
    int32_t l_1011 = 0x37DFAF7AL;
    int32_t *l_1034 = (void*)0;
    int32_t *l_1074 = &l_162;
    int i;
    for (i = 0; i < 2; i++)
        l_209[i] = &l_208;
    for (i = 0; i < 5; i++)
        l_349[i] = &l_162;
    for (i = 0; i < 7; i++)
        l_936[i] = &l_937;
    for (i = 0; i < 5; i++)
        l_957[i] = &g_958;
    for (g_77 = 9; (g_77 <= (-23)); g_77 = safe_sub_func_int32_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */(g_77, 1))
    { /* block id: 44 */
        int32_t l_145 = 0xB8DE4F0EL;
        uint8_t *l_165[6][8][4] = {{{&g_55[1][2],&g_55[1][3],&g_55[1][0],&g_55[0][1]},{(void*)0,&g_55[1][3],(void*)0,&g_55[0][2]},{&g_55[0][1],(void*)0,&g_55[0][1],&g_55[0][1]},{&g_55[0][1],&g_55[1][0],&g_55[1][3],(void*)0},{&g_55[0][1],&g_55[1][1],&g_55[1][2],&g_55[0][1]},{&g_55[0][2],&g_55[1][3],&g_55[1][1],(void*)0},{&g_55[1][1],&g_55[0][1],&g_55[0][1],(void*)0},{&g_55[1][1],&g_55[0][1],&g_55[1][0],&g_55[1][0]}},{{(void*)0,(void*)0,&g_55[1][1],&g_55[1][3]},{&g_55[1][3],&g_55[0][2],&g_55[1][3],(void*)0},{(void*)0,&g_55[0][1],&g_55[0][1],&g_55[1][3]},{&g_55[0][1],&g_55[0][1],&g_55[1][2],(void*)0},{&g_55[0][1],&g_55[0][2],(void*)0,&g_55[1][3]},{&g_55[1][2],(void*)0,(void*)0,&g_55[1][0]},{(void*)0,&g_55[0][1],&g_55[1][3],(void*)0},{&g_55[1][2],&g_55[0][1],(void*)0,(void*)0}},{{&g_55[0][0],&g_55[1][3],&g_55[0][1],&g_55[0][1]},{&g_55[0][1],&g_55[1][1],&g_55[0][2],(void*)0},{&g_55[1][3],&g_55[1][0],&g_55[0][1],&g_55[0][1]},{(void*)0,(void*)0,(void*)0,&g_55[0][2]},{&g_55[0][1],&g_55[1][3],&g_55[0][1],&g_55[0][1]},{&g_55[1][3],&g_55[1][3],&g_55[0][1],&g_55[1][1]},{&g_55[0][1],&g_55[1][1],&g_55[0][1],&g_55[1][1]},{&g_55[1][2],&g_55[1][3],&g_55[1][3],&g_55[1][3]}},{{&g_55[1][0],(void*)0,&g_55[0][1],&g_55[0][1]},{&g_55[1][2],&g_55[1][2],&g_55[0][1],&g_55[0][1]},{&g_55[1][2],&g_55[0][1],(void*)0,&g_55[1][3]},{&g_55[0][1],&g_55[0][1],&g_55[0][2],&g_55[0][1]},{&g_55[1][3],&g_55[0][3],&g_55[0][1],&g_55[1][3]},{(void*)0,&g_55[0][1],&g_55[1][1],&g_55[0][1]},{&g_55[0][1],&g_55[1][0],&g_55[1][1],(void*)0},{&g_55[1][2],(void*)0,&g_55[0][1],&g_55[1][2]}},{{&g_55[0][1],&g_55[0][1],&g_55[1][3],&g_55[1][3]},{&g_55[0][1],(void*)0,&g_55[1][0],&g_55[0][1]},{&g_55[1][3],&g_55[1][3],&g_55[0][1],(void*)0},{&g_55[1][0],&g_55[0][1],&g_55[1][3],(void*)0},{&g_55[0][1],&g_55[1][3],&g_55[1][2],&g_55[0][1]},{&g_55[1][3],&g_55[0][1],&g_55[0][1],&g_55[1][3]},{(void*)0,(void*)0,&g_55[0][1],&g_55[0][1]},{&g_55[1][3],&g_55[0][1],&g_55[0][1],&g_55[1][2]}},{{(void*)0,&g_55[1][3],&g_55[1][2],&g_55[1][2]},{&g_55[0][1],&g_55[0][1],&g_55[0][1],&g_55[0][1]},{&g_55[0][2],(void*)0,&g_55[1][3],&g_55[1][3]},{&g_55[0][1],&g_55[0][1],&g_55[0][1],&g_55[0][1]},{(void*)0,&g_55[1][3],(void*)0,(void*)0},{&g_55[1][3],&g_55[0][1],&g_55[0][1],(void*)0},{&g_55[0][2],&g_55[1][3],&g_55[0][0],&g_55[0][1]},{&g_55[1][3],(void*)0,&g_55[0][2],&g_55[1][3]}}};
        uint64_t *l_184 = &g_79;
        const int64_t *l_195 = &g_159;
        int i, j, k;
        for (g_126 = 1; (g_126 != 6); g_126 = safe_add_func_int8_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */(g_126, 1))
        { /* block id: 47 */
            int16_t l_135 = 0x23F9L;
            const int32_t l_161 = (-3L);
            uint64_t **l_186 = &l_184;
            int8_t *l_196 = (void*)0;
            int8_t *l_197 = (void*)0;
            int8_t *l_198 = &g_199;
            int8_t *l_200 = &g_201[0][4];
            int8_t l_202[2];
            int32_t l_203 = (-1L);
            int i;
            for (i = 0; i < 2; i++)
                l_202[i] = 0x9EL;
            for (p_47 = 0; (p_47 <= 1); p_47 += 1)
            { /* block id: 50 */
                int32_t *l_155 = (void*)0;
                int32_t *l_156 = &g_157;
                union U1 *l_179 = &g_64[3];
                union U1 **l_178 = &l_179;
                uint8_t *l_181[7][4] = {{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]},{&g_55[1][3],&g_55[1][3],&g_55[1][3],&g_55[1][3]}};
                int i, j;
                for (g_130 = 0; (g_130 <= 6); g_130 += 1)
                { /* block id: 53 */
                    for (p_48 = 0; (p_48 <= 1); p_48 += 1)
                    { /* block id: 56 */
                        int i, j;
                        if (g_55[p_47][p_48])
                            break;
                        if (l_135)
                            break;
                    }
                }
                l_162 &= (((safe_add_func_int16_t_s_s_unsafe_macro/*143*//* ___SAFE__OP */(g_55[p_47][(p_47 + 1)], (g_160 = (safe_sub_func_uint8_t_u_u_unsafe_macro/*144*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*145*//* ___SAFE__OP */(((!(safe_lshift_func_uint32_t_u_s_unsafe_macro/*146*//* ___SAFE__OP */((l_145 <= (safe_rshift_func_int8_t_s_u_unsafe_macro/*147*//* ___SAFE__OP */((((safe_lshift_func_uint32_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*149*//* ___SAFE__OP */(0xA53A4EB9L, 29)), (safe_unary_minus_func_uint64_t_u_unsafe_macro/*150*//* ___SAFE__OP */(p_47)))) ^ (g_11 != 0xB125L)) & 0x0FBDL), (p_48 | ((((g_159 ^= ((safe_mod_func_int32_t_s_s_unsafe_macro/*151*//* ___SAFE__OP */(((*l_156) ^= 0x1466A041L), p_48)) , l_158)) ^ g_20) <= l_158) >= p_47))))), p_48))) >= g_64[3].f0), g_64[3].f0)), g_126))))) ^ l_161) > p_47);
                if (l_162)
                    break;
                for (p_48 = 0; (p_48 <= 1); p_48 += 1)
                { /* block id: 68 */
                    uint8_t **l_166[5];
                    int32_t l_174 = 0x2C0AA69CL;
                    uint64_t *l_180 = &g_79;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_166[i] = &l_165[1][1][0];
                    (*l_156) ^= (safe_mul_func_int32_t_s_s_unsafe_macro/*152*//* ___SAFE__OP */(((l_165[3][0][0] = l_165[0][0][0]) == (l_181[2][2] = ((safe_sub_func_uint32_t_u_u_unsafe_macro/*153*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */(g_21, (g_171 , ((((safe_sub_func_int32_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */(l_174, (p_48 >= ((((((p_47 , l_161) >= ((g_177[0][0][3] ^= (safe_rshift_func_int16_t_s_s_unsafe_macro/*156*//* ___SAFE__OP */(p_48, 2))) & ((l_178 == &l_179) <= g_55[0][1]))) , l_180) == (void*)0) > g_55[0][1]) && 18446744073709551615UL)))) == 0x2165L) == 65527UL) , g_19)))), g_55[0][1])) , (void*)0))), p_48));
                }
            }
            l_203 &= (safe_mod_func_uint8_t_u_u_unsafe_macro/*157*//* ___SAFE__OP */(((((g_55[0][0] && (g_157 == (((*l_186) = (g_185 = l_184)) == (l_187[6] = (void*)0)))) ^ p_48) & (safe_mul_func_uint8_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */((g_55[0][3] == (safe_mod_func_int32_t_s_s_unsafe_macro/*159*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*160*//* ___SAFE__OP */((!(((*l_200) = ((*l_198) = ((p_47 , l_195) == l_195))) || 0x9AL)), l_145)), p_47))), l_202[0]))) | l_145), 0x8DL));
        }
    }
    return (*l_208);
}


/* ------------------------------------------ */
/* 
 * reads : g_64.f0 g_77 g_36 g_79
 * writes: g_77 g_79
 */
static uint16_t  func_60(int32_t  p_61)
{ /* block id: 13 */
    union U1 *l_63[4][1][10] = {{{(void*)0,(void*)0,&g_64[4],&g_64[3],&g_64[3],&g_64[4],(void*)0,(void*)0,&g_64[4],(void*)0}},{{&g_64[3],&g_64[1],&g_64[3],&g_64[3],&g_64[3],&g_64[1],&g_64[3],(void*)0,(void*)0,&g_64[3]}},{{(void*)0,(void*)0,&g_64[3],&g_64[3],(void*)0,(void*)0,&g_64[1],(void*)0,&g_64[1],(void*)0}},{{(void*)0,(void*)0,&g_64[4],(void*)0,(void*)0,&g_64[4],&g_64[3],&g_64[3],&g_64[4],(void*)0}}};
    union U1 **l_62 = &l_63[0][0][6];
    int32_t l_65 = (-6L);
    uint8_t *l_72[3];
    int8_t l_73 = (-5L);
    int64_t *l_76 = &g_77;
    uint64_t *l_78 = &g_79;
    int32_t *l_80 = &l_65;
    int32_t l_98 = 0xC926164AL;
    int32_t l_99 = 0xC69B762BL;
    int32_t l_100[7][3][4] = {{{0x55587106L,0x55587106L,0x1D611CF5L,0x62B9925CL},{0x0F0EF91DL,(-1L),0x0F0EF91DL,0x1D611CF5L},{0x0F0EF91DL,0x1D611CF5L,0x1D611CF5L,0x0F0EF91DL}},{{0x55587106L,0x1D611CF5L,0x62B9925CL,0x1D611CF5L},{0x1D611CF5L,(-1L),0x62B9925CL,0x62B9925CL},{0x55587106L,0x55587106L,0x1D611CF5L,0x62B9925CL}},{{0x0F0EF91DL,(-1L),0x0F0EF91DL,0x1D611CF5L},{0x0F0EF91DL,0x1D611CF5L,0x1D611CF5L,0x0F0EF91DL},{0x55587106L,0x1D611CF5L,0x62B9925CL,0x1D611CF5L}},{{0x0F0EF91DL,0x55587106L,(-1L),(-1L)},{0x1D611CF5L,0x1D611CF5L,0x0F0EF91DL,(-1L)},{0x62B9925CL,0x55587106L,0x62B9925CL,0x0F0EF91DL}},{{0x62B9925CL,0x0F0EF91DL,0x0F0EF91DL,0x62B9925CL},{0x1D611CF5L,0x0F0EF91DL,(-1L),0x0F0EF91DL},{0x0F0EF91DL,0x55587106L,(-1L),(-1L)}},{{0x1D611CF5L,0x1D611CF5L,0x0F0EF91DL,(-1L)},{0x62B9925CL,0x55587106L,0x62B9925CL,0x0F0EF91DL},{0x62B9925CL,0x0F0EF91DL,0x0F0EF91DL,0x62B9925CL}},{{0x1D611CF5L,0x0F0EF91DL,(-1L),0x0F0EF91DL},{0x0F0EF91DL,0x55587106L,(-1L),(-1L)},{0x1D611CF5L,0x1D611CF5L,0x0F0EF91DL,(-1L)}}};
    int16_t l_101 = 5L;
    uint16_t l_103 = 65530UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_72[i] = &g_55[0][2];
    (*l_62) = (void*)0;
    (*l_80) = (((((l_65 > g_64[3].f0) ^ (safe_sub_func_uint16_t_u_u_unsafe_macro/*161*//* ___SAFE__OP */(0x3AD3L, (safe_add_func_uint64_t_u_u_unsafe_macro/*162*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u(((void*)0 == l_72[2]), ((l_73 != (safe_mul_func_int64_t_s_s(0x79F1A7DFAE38EDFCLL, ((*l_78) ^= (((*l_76) &= l_73) != g_36))))) , 0x79897364L))), l_65))))) & 0x40L) ^ l_73) <= l_65);
    (*l_80) = p_61;
    for (l_73 = (-21); (l_73 < 10); l_73 = safe_add_func_uint32_t_u_u_unsafe_macro/*165*//* ___SAFE__OP */(l_73, 7))
    { /* block id: 21 */
        int32_t **l_83 = (void*)0;
        int32_t **l_84 = &l_80;
        int32_t *l_85 = &l_65;
        int32_t *l_86 = &l_65;
        int32_t *l_87 = (void*)0;
        int32_t *l_88 = &l_65;
        int32_t *l_89 = &l_65;
        int32_t *l_90 = &l_65;
        int32_t *l_91 = &l_65;
        int32_t *l_92 = &l_65;
        int32_t *l_93 = &l_65;
        int32_t l_94[4];
        int32_t *l_95 = &l_65;
        int32_t *l_96 = &l_94[1];
        int32_t *l_97[1][1];
        int8_t l_102 = (-9L);
        int i, j;
        for (i = 0; i < 4; i++)
            l_94[i] = (-1L);
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
                l_97[i][j] = &l_94[3];
        }
        (*l_80) = p_61;
        (*l_84) = &l_65;
        l_103++;
        for (l_102 = 0; (l_102 < 21); l_102++)
        { /* block id: 27 */
            uint64_t l_108 = 0x266805FA10622CD6LL;
            uint64_t *l_113 = (void*)0;
            uint64_t *l_114 = (void*)0;
            uint64_t *l_115 = &l_108;
            uint64_t *l_116 = (void*)0;
            int32_t l_117 = 0xF1DF6FF7L;
            if ((*l_80))
                break;
            l_100[5][1][2] = ((*l_88) = (l_108 & 1UL));
            (*l_96) ^= (((l_117 = ((*l_115) = ((*l_78) = ((safe_rshift_func_int32_t_s_u_unsafe_macro/*166*//* ___SAFE__OP */(((*l_80) , (safe_div_func_uint32_t_u_u_unsafe_macro/*167*//* ___SAFE__OP */(l_108, l_108))), 4)) == p_61)))) || (++(*l_115))) && (((((safe_rshift_func_int8_t_s_u_unsafe_macro/*168*//* ___SAFE__OP */((&l_63[1][0][9] == (void*)0), 7)) != p_61) | (safe_mod_func_uint16_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */(((void*)0 == &g_79), l_108))) , g_64[3].f0) != 1UL));
        }
    }
    return p_61;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_35[i][j], "g_35[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_55[i][j], "g_55[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_64[i].f0, "g_64[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_171.f0, "g_171.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_177[i][j][k], "g_177[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_199, "g_199", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_201[i][j], "g_201[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_223[i][j].f0, "g_223[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_228, "g_228", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_310[i], "g_310[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_355, "g_355", print_hash_value);
    transparent_crc(g_367, "g_367", print_hash_value);
    transparent_crc(g_461, "g_461", print_hash_value);
    transparent_crc(g_482, "g_482", print_hash_value);
    transparent_crc(g_483, "g_483", print_hash_value);
    transparent_crc(g_515, "g_515", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_579[i], "g_579[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_735, "g_735", print_hash_value);
    transparent_crc(g_915.f0, "g_915.f0", print_hash_value);
    transparent_crc(g_953.f0, "g_953.f0", print_hash_value);
    transparent_crc(g_975, "g_975", print_hash_value);
    transparent_crc(g_978, "g_978", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1036[i][j][k].f0, "g_1036[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1037.f0, "g_1037.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1073[i][j].f0, "g_1073[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1086.f0, "g_1086.f0", print_hash_value);
    transparent_crc(g_1135.f0, "g_1135.f0", print_hash_value);
    transparent_crc(g_1152, "g_1152", print_hash_value);
    transparent_crc(g_1177, "g_1177", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_1204[i][j].f0, "g_1204[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1291, "g_1291", print_hash_value);
    transparent_crc(g_1421, "g_1421", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_1539[i][j][k].f0, "g_1539[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1639, "g_1639", print_hash_value);
    transparent_crc(g_1666.f0, "g_1666.f0", print_hash_value);
    transparent_crc(g_1732, "g_1732", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_1894[i][j][k].f0, "g_1894[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1944[i].f0, "g_1944[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2033.f0, "g_2033.f0", print_hash_value);
    transparent_crc(g_2072, "g_2072", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 585
XXX total union variables: 31

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 27
breakdown:
   indirect level: 0, occurrence: 11
   indirect level: 1, occurrence: 4
   indirect level: 2, occurrence: 11
   indirect level: 3, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 12
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 12
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 18

XXX max expression depth: 40
breakdown:
   depth: 1, occurrence: 136
   depth: 2, occurrence: 36
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 4
   depth: 20, occurrence: 3
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 3
   depth: 26, occurrence: 3
   depth: 33, occurrence: 2
   depth: 40, occurrence: 2

XXX total number of pointers: 457

XXX times a variable address is taken: 1127
XXX times a pointer is dereferenced on RHS: 241
breakdown:
   depth: 1, occurrence: 209
   depth: 2, occurrence: 15
   depth: 3, occurrence: 17
XXX times a pointer is dereferenced on LHS: 272
breakdown:
   depth: 1, occurrence: 251
   depth: 2, occurrence: 10
   depth: 3, occurrence: 9
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 54
XXX times a pointer is compared with address of another variable: 13
XXX times a pointer is compared with another pointer: 6
XXX times a pointer is qualified to be dereferenced: 7551

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1072
   level: 2, occurrence: 241
   level: 3, occurrence: 236
   level: 4, occurrence: 148
   level: 5, occurrence: 136
XXX number of pointers point to pointers: 188
XXX number of pointers point to scalars: 242
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.1
XXX average alias set size: 1.46

XXX times a non-volatile is read: 1683
XXX times a non-volatile is write: 847
XXX times a volatile is read: 84
XXX    times read thru a pointer: 21
XXX times a volatile is write: 15
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 5.37e+03
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 1
XXX backward jumps: 8

XXX stmts: 142
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 22
   depth: 2, occurrence: 17
   depth: 3, occurrence: 21
   depth: 4, occurrence: 20
   depth: 5, occurrence: 29

XXX percentage a fresh-made variable is used: 17
XXX percentage an existing variable is used: 83
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

