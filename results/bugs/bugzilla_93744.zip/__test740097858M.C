/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 900729a
 * Options:   --seed 740097858 --bitfields --packed-struct
 * Seed:      740097858
 */

#include "unsafe_math_macros_eCast.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x0AD6F2EEL;
static volatile int32_t g_5 = (-1L);/* VOLATILE GLOBAL g_5 */
static volatile uint32_t g_6 = 18446744073709551612UL;/* VOLATILE GLOBAL g_6 */
static uint16_t g_28 = 0x347DL;
static const uint16_t g_60 = 65530UL;
static uint8_t g_67 = 250UL;
static uint16_t g_81 = 65535UL;
static uint32_t g_83 = 0xC308456AL;
static uint32_t g_85 = 0x0EE42AC9L;
static int32_t g_88[4][1][2] = {{{0x02143632L,0x02143632L}},{{0x02143632L,0x02143632L}},{{0x02143632L,0x02143632L}},{{0x02143632L,0x02143632L}}};
static int32_t * volatile g_87[5] = {&g_88[3][0][1],&g_88[3][0][1],&g_88[3][0][1],&g_88[3][0][1],&g_88[3][0][1]};
static int32_t * volatile g_89 = &g_88[1][0][1];/* VOLATILE GLOBAL g_89 */
static int8_t g_106 = 0xCEL;
static uint32_t *g_111 = &g_83;
static int8_t g_114 = 0x7EL;
static uint64_t g_137[8] = {18446744073709551612UL,0x3BB6A5CECF82584FLL,18446744073709551612UL,0x3BB6A5CECF82584FLL,18446744073709551612UL,0x3BB6A5CECF82584FLL,18446744073709551612UL,0x3BB6A5CECF82584FLL};
static uint8_t g_138 = 0x19L;
static uint64_t g_171 = 0x97B2EA2622DB6E2BLL;
static volatile int32_t ** volatile g_173 = (void*)0;/* VOLATILE GLOBAL g_173 */
static int32_t *g_177 = (void*)0;
static int32_t ** volatile g_176[8][6][5] = {{{&g_177,(void*)0,&g_177,&g_177,&g_177},{(void*)0,&g_177,(void*)0,(void*)0,&g_177},{&g_177,&g_177,&g_177,(void*)0,&g_177},{(void*)0,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177}},{{(void*)0,(void*)0,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,(void*)0,&g_177},{&g_177,&g_177,(void*)0,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,(void*)0,&g_177,&g_177}},{{&g_177,&g_177,&g_177,(void*)0,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{(void*)0,&g_177,&g_177,&g_177,&g_177},{(void*)0,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,(void*)0,&g_177,&g_177},{&g_177,&g_177,(void*)0,&g_177,&g_177}},{{&g_177,&g_177,(void*)0,(void*)0,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,(void*)0,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177}},{{&g_177,&g_177,(void*)0,(void*)0,&g_177},{&g_177,&g_177,&g_177,(void*)0,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,(void*)0}},{{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,(void*)0,&g_177,&g_177,(void*)0},{&g_177,&g_177,&g_177,&g_177,(void*)0},{&g_177,(void*)0,&g_177,(void*)0,(void*)0},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177}},{{&g_177,&g_177,&g_177,&g_177,(void*)0},{&g_177,&g_177,&g_177,&g_177,(void*)0},{&g_177,&g_177,&g_177,&g_177,(void*)0},{(void*)0,(void*)0,&g_177,&g_177,&g_177},{(void*)0,&g_177,&g_177,(void*)0,(void*)0},{&g_177,&g_177,&g_177,&g_177,&g_177}},{{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,(void*)0,&g_177,(void*)0,&g_177},{&g_177,&g_177,&g_177,&g_177,&g_177},{&g_177,(void*)0,&g_177,&g_177,&g_177},{(void*)0,&g_177,&g_177,&g_177,&g_177},{&g_177,&g_177,(void*)0,&g_177,(void*)0}}};
static int32_t ** volatile g_178 = &g_177;/* VOLATILE GLOBAL g_178 */
static volatile int32_t ** volatile ** volatile g_180 = (void*)0;/* VOLATILE GLOBAL g_180 */
static const int32_t *g_206 = &g_3;
static const int32_t ** volatile g_205 = &g_206;/* VOLATILE GLOBAL g_205 */
static volatile int64_t g_256 = 0L;/* VOLATILE GLOBAL g_256 */
static uint16_t g_284 = 0x487DL;
static uint16_t g_287 = 65535UL;
static uint64_t *g_319 = (void*)0;
static uint64_t **g_318 = &g_319;
static int64_t g_341 = 0xABEAF8259E7A3714LL;
static volatile int8_t g_344 = 0L;/* VOLATILE GLOBAL g_344 */
static int8_t *g_407 = &g_106;
static int8_t ** const  volatile g_406 = &g_407;/* VOLATILE GLOBAL g_406 */
static const volatile uint32_t g_443 = 4UL;/* VOLATILE GLOBAL g_443 */
static const uint64_t *g_491 = (void*)0;
static const uint64_t **g_490[6][5][2] = {{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}},{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}},{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}},{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}},{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}},{{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491},{&g_491,&g_491}}};
static const int8_t g_567 = 0L;
static const int8_t *g_569 = &g_106;
static const int8_t **g_568 = &g_569;
static volatile int32_t ***g_660 = (void*)0;
static volatile int32_t ****g_659 = &g_660;
static int32_t ** volatile g_662 = &g_177;/* VOLATILE GLOBAL g_662 */
static uint16_t *g_702 = (void*)0;
static int8_t g_786 = 1L;
static volatile uint16_t g_806[2] = {65535UL,65535UL};
static uint32_t **g_870 = (void*)0;
static const uint32_t g_931 = 0UL;
static uint32_t g_933 = 4UL;
static int32_t g_998 = 0x70A0BBB7L;
static int32_t *g_997[3][4][3] = {{{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998}},{{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998}},{{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998},{&g_998,&g_998,&g_998}}};
static int32_t **g_996 = &g_997[1][3][2];
static int32_t *** volatile g_995 = &g_996;/* VOLATILE GLOBAL g_995 */
static int8_t g_1017 = 6L;
static uint16_t g_1155 = 0xD2B5L;
static uint16_t *g_1154 = &g_1155;
static int32_t * volatile g_1190 = &g_88[3][0][1];/* VOLATILE GLOBAL g_1190 */
static int64_t g_1235 = 0L;
static uint32_t g_1236[9] = {18446744073709551614UL,0xBC33A654L,0xBC33A654L,18446744073709551614UL,0xBC33A654L,0xBC33A654L,18446744073709551614UL,0xBC33A654L,0xBC33A654L};
static int16_t g_1257 = (-1L);
static int32_t ** volatile g_1258 = &g_177;/* VOLATILE GLOBAL g_1258 */
static uint32_t g_1289 = 0UL;
static const int32_t **g_1351[3] = {&g_206,&g_206,&g_206};
static const int32_t ***g_1350 = &g_1351[1];
static const int32_t ****g_1349 = &g_1350;
static uint32_t g_1384[10][3][8] = {{{0xC8340914L,0x63A9AC8FL,0UL,0x0CB05435L,0x6FEE3785L,0x6FEE3785L,0x0CB05435L,0UL},{0xD2A15ED3L,0xD2A15ED3L,0xEB88405FL,1UL,0x4C7F8862L,18446744073709551615UL,18446744073709551606UL,18446744073709551611UL},{0x39A77076L,0x503B7570L,0x6FEE3785L,0x63A9AC8FL,0x25E0D403L,0x7BFEC1FBL,0x5195389EL,18446744073709551611UL}},{{0x503B7570L,0UL,0x03AE96ABL,1UL,0x6FC6D81AL,0x8E93118DL,0UL,0UL},{0xC16950F9L,18446744073709551615UL,0xC6DF2EDDL,0x0CB05435L,1UL,0UL,0UL,1UL},{0x5195389EL,0xE1A2E7D7L,3UL,0x03AE96ABL,0xC16950F9L,18446744073709551614UL,0UL,0x4C7F8862L}},{{18446744073709551615UL,0x03AE96ABL,0x6FC6D81AL,0x7958128DL,18446744073709551615UL,0x6FC6D81AL,0UL,1UL},{0x63A9AC8FL,0x5195389EL,0x7958128DL,0x03AE96ABL,0UL,1UL,0x79B3E830L,0x37D58EC1L},{0UL,0x39A77076L,0xEB88405FL,6UL,0x03AE96ABL,0xC4BE0E18L,18446744073709551615UL,0xD466265DL}},{{0x7BFEC1FBL,18446744073709551615UL,6UL,18446744073709551614UL,6UL,18446744073709551615UL,0x7BFEC1FBL,1UL},{0xD466265DL,18446744073709551615UL,0xE1A2E7D7L,1UL,0UL,0x4C7F8862L,5UL,0UL},{18446744073709551606UL,5UL,0x660F026CL,18446744073709551615UL,0UL,18446744073709551615UL,0x17B36D2CL,18446744073709551614UL}},{{0xD466265DL,6UL,18446744073709551610UL,0UL,6UL,0UL,0x8E93118DL,18446744073709551606UL},{0x7BFEC1FBL,0x6FEE3785L,0UL,0x5195389EL,0x03AE96ABL,0x503B7570L,18446744073709551615UL,0x6FC6D81AL},{0UL,1UL,6UL,18446744073709551615UL,0UL,18446744073709551606UL,1UL,0UL}},{{0x63A9AC8FL,18446744073709551610UL,6UL,0UL,18446744073709551615UL,0xEB88405FL,0x03AE96ABL,0x17B36D2CL},{0x03AE96ABL,0UL,0x503B7570L,0x37D58EC1L,18446744073709551614UL,0xE1A2E7D7L,0xD466265DL,0UL},{6UL,0x8E93118DL,0xFE6D00CCL,0x660F026CL,0x5F080BC9L,0x348E529DL,0x348E529DL,0x5F080BC9L}},{{18446744073709551614UL,6UL,6UL,18446744073709551614UL,18446744073709551615UL,0xC6DF2EDDL,0x39A77076L,0UL},{1UL,0x2B4A9601L,1UL,0x79B3E830L,0x6FC6D81AL,18446744073709551611UL,18446744073709551615UL,0x37D58EC1L},{18446744073709551615UL,0x2B4A9601L,18446744073709551606UL,0x348E529DL,0x8E93118DL,0xC6DF2EDDL,6UL,0x03AE96ABL}},{{0UL,6UL,18446744073709551610UL,0x63A9AC8FL,0xEB88405FL,0x348E529DL,18446744073709551614UL,6UL},{0x5195389EL,0x8E93118DL,18446744073709551615UL,18446744073709551615UL,0x79B3E830L,0xE1A2E7D7L,5UL,0x2B4A9601L},{18446744073709551615UL,0UL,18446744073709551615UL,0xC4BE0E18L,5UL,0xEB88405FL,0xC4BE0E18L,0x6FEE3785L}},{{0UL,18446744073709551610UL,6UL,0xD466265DL,6UL,18446744073709551606UL,0UL,1UL},{0x37D58EC1L,1UL,18446744073709551615UL,0UL,0x6FC6D81AL,0x503B7570L,0x79B3E830L,0x39A77076L},{0x660F026CL,0x6FEE3785L,0UL,0UL,0x5195389EL,0UL,0UL,0x6FEE3785L}},{{18446744073709551614UL,6UL,18446744073709551615UL,0x7BFEC1FBL,1UL,18446744073709551615UL,0x6FEE3785L,0xFE6D00CCL},{0x79B3E830L,5UL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL,0x4C7F8862L,0x6FEE3785L,0x8E93118DL},{0x348E529DL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0x63A9AC8FL,18446744073709551615UL,0UL,0x03AE96ABL}}};
static int32_t * volatile g_1386 = &g_88[3][0][1];/* VOLATILE GLOBAL g_1386 */
static uint16_t g_1394 = 0UL;
static uint16_t *g_1393 = &g_1394;
static int8_t * const *g_1413 = &g_407;
static int8_t * const **g_1412 = &g_1413;
static int32_t * volatile g_1416 = &g_88[3][0][1];/* VOLATILE GLOBAL g_1416 */
static int8_t **g_1424[7] = {&g_407,&g_407,&g_407,&g_407,&g_407,&g_407,&g_407};
static int8_t ***g_1423[10][4][6] = {{{(void*)0,(void*)0,&g_1424[6],&g_1424[6],&g_1424[6],&g_1424[5]},{(void*)0,&g_1424[6],&g_1424[4],&g_1424[6],&g_1424[3],&g_1424[5]},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[6],(void*)0,&g_1424[6]},{&g_1424[5],&g_1424[6],(void*)0,&g_1424[3],&g_1424[4],&g_1424[4]}},{{(void*)0,(void*)0,&g_1424[6],(void*)0,&g_1424[4],(void*)0},{&g_1424[6],&g_1424[6],&g_1424[6],&g_1424[6],(void*)0,(void*)0},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[4],&g_1424[3],&g_1424[1]},{&g_1424[3],&g_1424[6],&g_1424[6],&g_1424[4],&g_1424[6],&g_1424[6]}},{{&g_1424[6],(void*)0,&g_1424[1],&g_1424[6],(void*)0,&g_1424[6]},{&g_1424[6],&g_1424[4],&g_1424[6],(void*)0,(void*)0,&g_1424[1]},{(void*)0,&g_1424[4],&g_1424[6],&g_1424[3],(void*)0,&g_1424[6]},{&g_1424[5],(void*)0,&g_1424[1],&g_1424[6],(void*)0,&g_1424[6]}},{{&g_1424[6],(void*)0,&g_1424[6],&g_1424[6],&g_1424[4],&g_1424[1]},{(void*)0,(void*)0,&g_1424[6],&g_1424[6],(void*)0,(void*)0},{(void*)0,(void*)0,&g_1424[6],&g_1424[1],(void*)0,(void*)0},{&g_1424[6],&g_1424[4],&g_1424[6],(void*)0,(void*)0,&g_1424[4]}},{{&g_1424[6],&g_1424[4],(void*)0,&g_1424[1],(void*)0,&g_1424[6]},{(void*)0,(void*)0,&g_1424[6],&g_1424[6],&g_1424[6],&g_1424[5]},{(void*)0,&g_1424[6],&g_1424[4],&g_1424[6],&g_1424[3],&g_1424[5]},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[6],(void*)0,&g_1424[6]}},{{&g_1424[5],&g_1424[6],(void*)0,&g_1424[3],&g_1424[4],&g_1424[4]},{(void*)0,(void*)0,&g_1424[6],(void*)0,&g_1424[4],(void*)0},{&g_1424[6],&g_1424[6],&g_1424[6],&g_1424[6],(void*)0,(void*)0},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[4],&g_1424[3],&g_1424[1]}},{{&g_1424[3],&g_1424[6],&g_1424[6],&g_1424[4],&g_1424[6],&g_1424[6]},{&g_1424[6],(void*)0,&g_1424[1],&g_1424[6],(void*)0,&g_1424[6]},{&g_1424[6],&g_1424[4],&g_1424[6],(void*)0,(void*)0,&g_1424[1]},{(void*)0,&g_1424[4],&g_1424[6],&g_1424[3],(void*)0,&g_1424[6]}},{{&g_1424[5],(void*)0,&g_1424[1],&g_1424[6],(void*)0,&g_1424[6]},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[6],&g_1424[4],&g_1424[1]},{(void*)0,(void*)0,&g_1424[6],&g_1424[6],(void*)0,(void*)0},{(void*)0,(void*)0,&g_1424[6],&g_1424[1],(void*)0,&g_1424[5]}},{{&g_1424[6],&g_1424[1],&g_1424[5],&g_1424[2],&g_1424[6],&g_1424[6]},{&g_1424[6],&g_1424[6],&g_1424[2],(void*)0,&g_1424[6],&g_1424[4]},{(void*)0,(void*)0,&g_1424[1],&g_1424[6],&g_1424[6],(void*)0},{&g_1424[6],(void*)0,&g_1424[6],&g_1424[4],&g_1424[6],(void*)0}},{{&g_1424[1],&g_1424[6],&g_1424[1],&g_1424[1],&g_1424[1],&g_1424[4]},{(void*)0,(void*)0,&g_1424[2],&g_1424[1],&g_1424[6],&g_1424[6]},{&g_1424[2],&g_1424[1],&g_1424[5],&g_1424[5],&g_1424[6],&g_1424[5]},{&g_1424[6],(void*)0,&g_1424[6],(void*)0,&g_1424[1],&g_1424[6]}}};
static int8_t ****g_1422[8][2] = {{&g_1423[5][3][2],&g_1423[6][2][1]},{&g_1423[4][0][0],&g_1423[6][2][1]},{&g_1423[5][3][2],&g_1423[4][0][0]},{(void*)0,(void*)0},{(void*)0,&g_1423[4][0][0]},{&g_1423[5][3][2],&g_1423[6][2][1]},{&g_1423[4][0][0],&g_1423[6][2][1]},{&g_1423[5][3][2],&g_1423[4][0][0]}};
static uint64_t *g_1490 = &g_137[2];
static uint64_t ** const g_1489 = &g_1490;
static uint64_t ** const *g_1488 = &g_1489;
static uint64_t ** const **g_1487 = &g_1488;
static uint8_t g_1543[4][1] = {{255UL},{0xE3L},{255UL},{0xE3L}};
static int32_t **g_1577 = (void*)0;
static uint64_t g_1628 = 0UL;
static uint16_t * volatile *g_1661 = &g_1393;
static uint16_t * volatile **g_1660 = &g_1661;
static uint64_t ** volatile g_1691 = (void*)0;/* VOLATILE GLOBAL g_1691 */
static volatile uint32_t g_1785 = 4294967295UL;/* VOLATILE GLOBAL g_1785 */
static uint16_t * const g_1816 = (void*)0;
static uint16_t * const *g_1815 = &g_1816;
static uint16_t * const **g_1814 = &g_1815;
static int32_t *g_1893 = &g_3;
static volatile int8_t g_1921 = 1L;/* VOLATILE GLOBAL g_1921 */
static int32_t g_1960 = 0xD4733BC5L;
static int64_t g_2015 = 1L;
static uint64_t *** volatile g_2019 = &g_318;/* VOLATILE GLOBAL g_2019 */
static int64_t *g_2042 = (void*)0;
static int64_t * volatile *g_2041 = &g_2042;
static uint64_t ****g_2102 = (void*)0;
static int32_t *g_2182 = &g_88[0][0][0];
static int8_t g_2303 = 0xADL;
static int32_t g_2379 = 0x9D14EA4BL;
static int64_t **g_2440 = &g_2042;
static int64_t ** const *g_2439 = &g_2440;
static uint64_t * const *g_2489[8] = {&g_1490,&g_1490,&g_1490,&g_1490,&g_1490,&g_1490,&g_1490,&g_1490};
static uint64_t * const **g_2488 = &g_2489[2];
static uint64_t * const ***g_2487 = &g_2488;
static volatile uint32_t g_2621[3] = {0UL,0UL,0UL};
static int8_t g_2631[9][2][6] = {{{0x76L,(-1L),(-1L),(-3L),(-3L),(-9L)},{1L,0x22L,0xF8L,0x22L,1L,0x08L}},{{1L,0xA8L,(-7L),0x41L,4L,(-1L)},{7L,0xA9L,1L,0xA8L,6L,(-1L)}},{{1L,0x36L,(-7L),1L,(-1L),0x08L},{6L,(-1L),0xF8L,1L,0xA8L,(-9L)}},{{0x8BL,(-1L),(-1L),(-1L),(-1L),1L},{0xF8L,0xA2L,(-7L),(-7L),0xA2L,0xF8L}},{{1L,1L,(-3L),(-1L),(-2L),0x76L},{0x36L,(-3L),0L,0xA2L,(-1L),1L}},{{0x36L,0x50L,0xA2L,(-1L),0x8BL,7L},{1L,(-2L),(-9L),(-7L),(-7L),(-3L)}},{{0xF8L,1L,0x50L,(-1L),1L,1L},{0x8BL,(-1L),1L,1L,1L,(-1L)}},{{6L,(-7L),0x8BL,1L,0x08L,0x51L},{1L,0x76L,1L,0xA8L,0xA9L,(-1L)}},{{7L,0x76L,(-1L),0x41L,0x08L,6L},{1L,(-7L),0xA8L,0x22L,1L,(-1L)}}};
static int32_t **g_2654[5][8] = {{&g_1893,&g_177,(void*)0,&g_177,&g_2182,&g_177,&g_1893,&g_2182},{&g_1893,&g_1893,&g_177,(void*)0,&g_2182,&g_2182,&g_2182,(void*)0},{&g_177,&g_1893,&g_177,&g_2182,&g_1893,&g_177,&g_2182,&g_177},{(void*)0,&g_2182,&g_177,&g_2182,(void*)0,&g_177,&g_1893,(void*)0},{(void*)0,&g_177,&g_1893,(void*)0,&g_1893,&g_177,(void*)0,&g_2182}};
static int32_t ***g_2653 = &g_2654[2][4];
static int32_t ****g_2652 = &g_2653;
static int32_t *****g_2651[8] = {&g_2652,&g_2652,&g_2652,&g_2652,&g_2652,&g_2652,&g_2652,&g_2652};
static int32_t ***g_2686 = (void*)0;
static int32_t g_2739 = (-4L);


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint8_t  func_9(int32_t * p_10, int32_t * p_11, int8_t  p_12, uint32_t  p_13);
static int32_t * func_14(int32_t * p_15, int32_t  p_16, int32_t * p_17);
static int32_t * func_18(uint8_t  p_19, int8_t  p_20);
static int32_t  func_29(int32_t  p_30, int32_t  p_31, int32_t  p_32);
static uint8_t  func_38(uint32_t  p_39, uint32_t  p_40, uint16_t * p_41);
static uint32_t  func_42(uint32_t  p_43, int64_t  p_44);
static int8_t  func_51(uint16_t * p_52, uint16_t * p_53);
static uint16_t * func_54(int32_t  p_55, const int32_t * p_56, int8_t  p_57, const int32_t * p_58);
static int8_t  func_62(uint32_t  p_63);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_5 g_3 g_67 g_81 g_60 g_89 g_111 g_114 g_88 g_138 g_83 g_137 g_205 g_206 g_287 g_341 g_284 g_406 g_407 g_106 g_85 g_443 g_171 g_178 g_177 g_256 g_569 g_786 g_567 g_806 g_344 g_931 g_995 g_996 g_997 g_998 g_702 g_1154 g_1155 g_1190 g_1236 g_1258 g_1289 g_1349 g_933 g_1350 g_1351 g_1384 g_1386 g_1393 g_1412 g_1416 g_1394 g_1413 g_1490 g_1543 g_1235 g_87 g_1628 g_1660 g_1691 g_1489 g_1661 g_1017 g_1785 g_1257 g_1488 g_1893 g_1921 g_1960 g_2019 g_2041 g_2015 g_28 g_2102 g_2182 g_2303 g_659 g_660 g_2439 g_2440 g_2621 g_2042
 * writes: g_6 g_28 g_67 g_81 g_83 g_85 g_88 g_106 g_111 g_137 g_138 g_287 g_177 g_114 g_5 g_490 g_341 g_318 g_568 g_284 g_171 g_702 g_786 g_806 g_206 g_870 g_933 g_996 g_1017 g_1235 g_1236 g_1257 g_1289 g_1154 g_1349 g_1155 g_1412 g_1394 g_1422 g_3 g_1487 g_1543 g_998 g_87 g_1577 g_659 g_1785 g_1814 g_1960 g_2015 g_407 g_995 g_2439 g_2487 g_2631 g_2042 g_2686
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3;
    int32_t *l_4[4][5][2] = {{{(void*)0,(void*)0},{&g_3,(void*)0},{(void*)0,&g_3},{(void*)0,(void*)0},{&g_3,(void*)0}},{{(void*)0,(void*)0},{&g_3,(void*)0},{(void*)0,&g_3},{(void*)0,(void*)0},{&g_3,(void*)0}},{{(void*)0,(void*)0},{&g_3,(void*)0},{(void*)0,&g_3},{(void*)0,(void*)0},{&g_3,(void*)0}},{{(void*)0,(void*)0},{&g_3,(void*)0},{(void*)0,&g_3},{(void*)0,(void*)0},{&g_3,(void*)0}}};
    int16_t l_21 = (-3L);
    int16_t *l_1542 = (void*)0;
    uint32_t l_1544 = 18446744073709551609UL;
    const uint8_t l_1547 = 255UL;
    int32_t l_2700 = (-5L);
    int32_t *l_2778[7] = {&l_2700,&l_2700,&l_2700,&l_2700,&l_2700,&l_2700,&l_2700};
    uint64_t l_2801[8] = {8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL};
    uint8_t l_2802 = 1UL;
    uint8_t l_2803 = 0x3AL;
    int32_t l_2804 = 5L;
    int i, j, k;
    g_6--;
    (*g_1893) = (func_9(&g_3, (l_4[3][0][1] = func_14(func_18(l_21, g_5), ((safe_sub_func_uint16_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */(g_998, ((65535UL > (g_1543[2][0] = (~18446744073709551615UL))) & ((l_1544 , (safe_lshift_func_uint64_t_u_u(((0L && g_60) ^ g_931), l_1547))) > 0x92D1B96DE8E5E438LL)))) , (-1L)), g_997[0][3][2])), l_2700, g_1628) != 0x32L);
    (**g_1350) = &l_2700;
    (*g_2182) ^= (((((((***g_1660) == (((((safe_lshift_func_int64_t_s_u((safe_rshift_func_uint16_t_u_s_unsafe_macro/*3*//* ___SAFE__OP */((***g_1660), 5)), 45)) >= (*l_2)) && (***g_1488)) <= 0x2195L) & (**g_1413))) , (&g_1423[4][0][0] != (void*)0)) , (*g_1154)) == 1L) == (**g_1489)) ^ 1UL);
    return (***g_1660);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_1489 g_1490 g_137 g_1393 g_1394 g_1412 g_1413 g_407 g_111 g_85 g_171 g_1488 g_6 g_2182 g_933
 * writes: g_137 g_138 g_1394 g_1257 g_83 g_3 g_2015 g_88 g_933
 */
static uint8_t  func_9(int32_t * p_10, int32_t * p_11, int8_t  p_12, uint32_t  p_13)
{ /* block id: 1101 */
    int8_t l_2709[3][4][9] = {{{0x4EL,1L,(-2L),0xBFL,0x87L,0x87L,0xBFL,(-2L),1L},{(-1L),(-2L),0xD3L,0x15L,0x87L,0xD3L,0x4EL,1L,(-2L)},{0xB3L,(-1L),0xD3L,0xBFL,(-1L),0xAAL,0x15L,0xAAL,(-1L)},{0xB3L,(-2L),(-2L),0xB3L,1L,(-1L),(-1L),0xAAL,(-2L)}},{{(-1L),1L,0x87L,0L,0L,(-1L),0x15L,1L,1L},{0x4EL,0xAAL,1L,0L,1L,0xAAL,0x4EL,(-2L),0xAAL},{0L,0xAAL,0x87L,0xB3L,(-1L),0xD3L,0xBFL,(-1L),0xAAL},{0x4EL,1L,(-2L),0xBFL,0x87L,0x87L,0xBFL,(-2L),1L}},{{(-1L),(-2L),0xD3L,0x15L,0x87L,0xD3L,0x4EL,1L,(-2L)},{0xB3L,(-1L),0xD3L,0xBFL,(-1L),0xAAL,0x15L,0xAAL,(-1L)},{(-2L),(-7L),(-7L),(-2L),4L,4L,0L,(-1L),(-7L)},{0L,4L,(-1L),0xD3L,0x61L,4L,1L,4L,4L}}};
    int32_t l_2714 = 0x5BAE4C89L;
    uint64_t *l_2720 = &g_171;
    int32_t l_2746 = 0x5E658F83L;
    int32_t **l_2758 = &g_997[1][3][2];
    int16_t l_2764 = 0x9FD1L;
    int i, j, k;
lbl_2775:
    if ((safe_rshift_func_uint16_t_u_s(((safe_rshift_func_int64_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */(((*p_10) , (l_2709[2][0][7] ^ (safe_mul_func_int64_t_s_s_unsafe_macro/*8*//* ___SAFE__OP */((l_2709[2][3][5] , (l_2709[1][1][5] > (0UL <= p_12))), ((safe_mul_func_uint64_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */((l_2714 |= ((**g_1489) ^= 0x56988B79AED7060ALL)), (((void*)0 != &g_111) , 1L))) <= 8L))))), l_2709[1][1][1])) <= 0xD38B32CD8DC90489LL), l_2709[2][0][7])), l_2709[1][2][0])) == l_2709[1][1][2]), l_2709[2][0][5])))
    { /* block id: 1104 */
        uint8_t *l_2717 = &g_138;
        uint64_t *l_2721 = &g_137[3];
        const int32_t l_2742 = 0x58CBF984L;
        int16_t *l_2745 = &g_1257;
        int32_t l_2747 = (-9L);
        int32_t **l_2759 = &g_997[1][3][2];
        int64_t l_2765 = 0x5D0FBC60878E13C5LL;
        int32_t l_2766 = 0x07015147L;
        int32_t l_2767 = 1L;
        int64_t *l_2768 = (void*)0;
        int64_t *l_2769 = &g_2015;
        int32_t l_2770 = 0x94F59CC5L;
        (*p_10) = ((safe_lshift_func_uint32_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */((((*l_2717) = 0x7BL) , ((safe_add_func_uint8_t_u_u_unsafe_macro/*11*//* ___SAFE__OP */((((l_2720 == l_2721) && (safe_sub_func_uint8_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */((l_2746 |= (safe_sub_func_int32_t_s_s_unsafe_macro/*13*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*15*//* ___SAFE__OP */((((((((*g_111) = ((safe_unary_minus_func_uint32_t_u_unsafe_macro/*16*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */(((l_2714 = (safe_lshift_func_uint8_t_u_s_unsafe_macro/*18*//* ___SAFE__OP */(((*l_2717) = 255UL), ((((safe_rshift_func_int16_t_s_u_unsafe_macro/*19*//* ___SAFE__OP */((((safe_lshift_func_uint16_t_u_s_unsafe_macro/*20*//* ___SAFE__OP */(((*g_1393)--), 7)) ^ ((0UL < (l_2714 && (l_2742 , (1L > (((safe_div_func_int16_t_s_s_unsafe_macro/*21*//* ___SAFE__OP */(((*l_2745) = 0xDA70L), 65531UL)) && l_2714) , 0x391CD93EL))))) ^ 0x759756C9CD8ABC47LL)) < p_13), 11)) ^ p_12) , (**g_1412)) == &l_2709[2][0][7])))) > p_12), (*p_10))))) >= l_2709[2][0][8])) || (*p_10)) | l_2742) <= p_13) , g_85) & l_2742), 56)), 0UL)), p_13))), l_2709[2][0][7]))) == 0UL), p_13)) == (-8L))), l_2747)) , 0x9BF2F575L);
        (*g_2182) = ((safe_rshift_func_int64_t_s_u_unsafe_macro/*22*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*23*//* ___SAFE__OP */((l_2770 = ((*l_2769) = (l_2767 |= ((0xD69E7574E01FF162LL == (l_2766 |= ((((0x401B76CCL < (safe_mul_func_int64_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */((g_171 ^ ((l_2759 = l_2758) == l_2758)), 0xA5DA1887L)) && (safe_mul_func_uint16_t_u_u_unsafe_macro/*27*//* ___SAFE__OP */((((***g_1488) |= (((safe_mul_func_int16_t_s_s_unsafe_macro/*28*//* ___SAFE__OP */((0xD0D219FDFB4CDF53LL & 0x4FE7404C714D629FLL), (p_13 >= l_2764))) & l_2747) & l_2765)) , 0x4175L), l_2714))) , (*g_1393)), p_13)), 0xD7ADB17102662646LL))) , 0x944DL) | l_2742) && l_2709[0][3][0]))) != l_2714)))), p_13)) > 1L), l_2742)) == g_6);
        if (l_2764)
            goto lbl_2775;
    }
    else
    { /* block id: 1120 */
        uint64_t * const l_2771 = &g_137[7];
        int32_t l_2774 = (-1L);
        (*p_10) = (((void*)0 != l_2771) && (safe_mod_func_int16_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */((p_12 , l_2774), l_2774)));
    }
    for (g_933 = 0; (g_933 <= 31); g_933 = safe_add_func_int16_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */(g_933, 1))
    { /* block id: 1126 */
        return l_2764;
    }
    return l_2709[2][3][5];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_998 g_1393 g_1394 g_1543 g_87 g_1350 g_1351 g_1349 g_60 g_341 g_5 g_111 g_83 g_1384 g_106 g_1154 g_1155 g_284 g_407 g_256 g_1628 g_1660 g_786 g_1691 g_933 g_1235 g_1489 g_1490 g_137 g_206 g_1661 g_81 g_1190 g_89 g_88 g_287 g_1017 g_931 g_1785 g_171 g_67 g_1488 g_1236 g_1893 g_1921 g_1416 g_1412 g_1413 g_1960 g_1386 g_85 g_1257 g_2019 g_2041 g_806 g_406 g_28 g_2102 g_567 g_2182 g_569 g_443 g_2303 g_114 g_177 g_6 g_659 g_660 g_1289 g_2439 g_2440 g_2621 g_138 g_2042 g_2015
 * writes: g_998 g_138 g_1235 g_933 g_114 g_87 g_206 g_67 g_3 g_28 g_1577 g_83 g_341 g_1155 g_85 g_1257 g_659 g_786 g_81 g_177 g_137 g_1394 g_88 g_1543 g_1785 g_1814 g_287 g_1960 g_171 g_2015 g_318 g_106 g_407 g_284 g_995 g_2439 g_2487 g_2631 g_2042 g_2686
 */
static int32_t * func_14(int32_t * p_15, int32_t  p_16, int32_t * p_17)
{ /* block id: 590 */
    uint8_t *l_1553[6][5] = {{&g_67,&g_1543[0][0],(void*)0,&g_1543[2][0],&g_67},{&g_67,&g_67,&g_138,&g_1543[2][0],&g_1543[2][0]},{(void*)0,&g_67,(void*)0,&g_67,&g_1543[2][0]},{&g_67,&g_1543[0][0],(void*)0,&g_1543[2][0],&g_67},{&g_67,&g_67,&g_138,&g_1543[2][0],&g_1543[2][0]},{(void*)0,&g_67,(void*)0,&g_67,&g_1543[2][0]}};
    int32_t l_1554 = 0xCD41014CL;
    uint32_t l_1555 = 18446744073709551609UL;
    int8_t ***** const l_1566 = &g_1422[5][0];
    int64_t l_1567[2];
    const int32_t **l_1578 = (void*)0;
    int8_t l_1669 = (-5L);
    const uint64_t **l_1692 = &g_491;
    const uint64_t **l_1702 = (void*)0;
    int32_t **l_1708 = &g_177;
    int32_t ***l_1707 = &l_1708;
    int32_t ****l_1706 = &l_1707;
    int32_t l_1791 = 0x71AD7AFCL;
    int32_t l_1801 = 6L;
    int32_t l_1802[10][7] = {{7L,7L,7L,7L,7L,7L,7L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{7L,7L,7L,7L,7L,7L,7L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{7L,7L,7L,7L,7L,7L,7L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{7L,7L,7L,7L,7L,7L,7L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{7L,7L,7L,7L,7L,7L,7L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
    uint32_t l_1840 = 0x01920B3AL;
    int32_t l_1845 = 0x9D8BD413L;
    uint16_t **l_1936[10] = {&g_1393,&g_1393,&g_1393,&g_1393,&g_1393,&g_1393,&g_1393,&g_1393,&g_1393,&g_1393};
    uint32_t * const *l_2020 = (void*)0;
    uint32_t l_2034 = 0xAB9A7855L;
    int8_t ****l_2036 = (void*)0;
    const int16_t l_2156 = 0x601FL;
    int16_t l_2157 = 0x99C7L;
    int32_t l_2194[7] = {0L,0L,0x1A00AB38L,0L,0L,0x1A00AB38L,0L};
    int8_t **l_2203 = &g_407;
    int32_t l_2255 = 0L;
    int64_t **l_2355 = &g_2042;
    int32_t * const *l_2545[2];
    int64_t * const * const l_2630[9][6] = {{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042}};
    int64_t * const * const *l_2629 = &l_2630[0][0];
    int64_t * const * const **l_2628 = &l_2629;
    uint32_t l_2645 = 0x216A80D1L;
    uint32_t l_2648[9] = {0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL,0xB3B2B88CL};
    int32_t *****l_2655[9][3] = {{&g_2652,&g_2652,&l_1706},{&l_1706,&l_1706,&g_2652},{&g_2652,&g_2652,&g_2652},{&g_2652,&l_1706,&g_2652},{&l_1706,&g_2652,&g_2652},{&g_2652,&g_2652,&g_2652},{&l_1706,&l_1706,&l_1706},{&g_2652,&g_2652,&l_1706},{&l_1706,&l_1706,&g_2652}};
    int32_t ***l_2684 = &g_1577;
    int32_t ***l_2685 = &g_996;
    int32_t *l_2699 = (void*)0;
    int i, j;
    for (i = 0; i < 2; i++)
        l_1567[i] = 0xC4B3EBAF2DEF8424LL;
    for (i = 0; i < 2; i++)
        l_2545[i] = &g_997[0][3][2];
lbl_1710:
    (*p_17) ^= (*p_15);
lbl_2065:
    if ((safe_lshift_func_int64_t_s_s((((p_16 == ((+((((p_16 < (-3L)) && 0UL) || ((*p_17) &= (*p_15))) && (safe_mod_func_int64_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */((((((--l_1555) , (((safe_add_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((((safe_add_func_int16_t_s_s_unsafe_macro/*34*//* ___SAFE__OP */(((((safe_mod_func_uint8_t_u_u_unsafe_macro/*35*//* ___SAFE__OP */((l_1555 < (safe_div_func_uint16_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */((*g_1393), ((((253UL <= (g_138 = (l_1566 != l_1566))) , 7UL) > l_1554) ^ l_1555)))), 0x14L)) != l_1555) & 1UL) , g_1543[3][0]), p_16)) , l_1554) >= l_1567[0]), p_16)) <= l_1555) == 0x673BL)) ^ l_1567[1]) , &g_111) == (void*)0), 9L)))) , (-1L))) , p_16) , 0x92D3CCAC2C6AB944LL), l_1567[0])))
    { /* block id: 595 */
        int32_t *l_1568 = &g_3;
        return l_1568;
    }
    else
    { /* block id: 597 */
        int32_t *l_1580 = (void*)0;
        int8_t * const ** const *l_1610[3][9] = {{&g_1412,&g_1412,&g_1412,&g_1412,&g_1412,&g_1412,&g_1412,&g_1412,&g_1412},{&g_1412,&g_1412,&g_1412,(void*)0,&g_1412,&g_1412,&g_1412,&g_1412,(void*)0},{(void*)0,&g_1412,(void*)0,&g_1412,&g_1412,(void*)0,&g_1412,(void*)0,&g_1412}};
        int8_t * const ** const **l_1609 = &l_1610[2][1];
        int16_t l_1611 = 0L;
        uint8_t l_1616 = 0x86L;
        int32_t **l_1636 = (void*)0;
        int32_t ***l_1635 = &l_1636;
        int32_t ****l_1634 = &l_1635;
        int32_t l_1670 = (-1L);
        int32_t l_1798 = 0x200BD288L;
        int32_t l_1800 = 0L;
        int32_t l_1805 = 0x944E83CCL;
        int32_t l_1807 = 0x41811556L;
        const int32_t l_1846 = 0x185DF8F9L;
        int32_t l_1860 = 5L;
        uint64_t l_1866 = 4UL;
        int32_t *l_1892 = &l_1670;
        uint16_t **l_1940 = &g_1393;
        uint64_t l_1942 = 0x132BDD589134B039LL;
        int8_t **l_2021 = &g_407;
        int i, j;
        for (g_1235 = 2; (g_1235 <= 6); g_1235 += 1)
        { /* block id: 600 */
            int32_t *l_1570 = &g_3;
            uint16_t * const *l_1572 = &g_1154;
            uint16_t * const **l_1571 = &l_1572;
            int32_t **l_1575[7] = {(void*)0,&g_997[1][3][2],&g_997[1][3][2],(void*)0,&g_997[1][3][2],&g_997[1][3][2],(void*)0};
            int32_t **l_1596[4][1];
            int32_t ***l_1595 = &l_1596[3][0];
            int16_t l_1612 = 0xE35EL;
            int8_t l_1626 = (-1L);
            uint16_t l_1629 = 65534UL;
            int8_t *****l_1658 = &g_1422[1][0];
            uint64_t l_1672 = 0xB9FA55345096009CLL;
            int64_t l_1711 = 0xCD9637B163DE8F3FLL;
            int64_t *l_1719[10][9] = {{&g_1235,(void*)0,&l_1567[0],&g_1235,(void*)0,&g_1235,(void*)0,&g_1235,&l_1567[0]},{&g_341,&g_341,&l_1711,&g_341,(void*)0,&g_341,&l_1711,&g_341,&g_341},{&l_1567[0],&g_1235,(void*)0,&g_1235,(void*)0,&g_1235,&l_1567[0],(void*)0,&g_1235},{&g_341,&l_1567[1],&l_1711,&l_1567[1],&g_341,(void*)0,(void*)0,&g_341,&l_1567[1]},{&l_1567[0],&l_1711,&l_1567[0],&l_1567[1],&g_1235,&l_1567[0],&g_1235,(void*)0,(void*)0},{&g_341,&l_1567[0],(void*)0,&l_1711,&l_1711,(void*)0,&l_1567[0],&g_341,&l_1567[0]},{&g_1235,&g_1235,&g_1235,&l_1567[1],&g_1235,&g_1235,&g_1235,&g_1235,&g_1235},{&l_1567[1],&l_1567[0],&l_1567[0],&l_1567[1],&g_341,&g_341,&g_341,&l_1567[1],&l_1567[0]},{(void*)0,&l_1711,&g_1235,&g_1235,&g_341,&g_1235,&g_1235,&l_1711,(void*)0},{&l_1567[0],&l_1567[1],&g_341,&g_341,&g_341,&l_1567[1],&l_1567[0],&l_1567[0],&l_1567[1]}};
            int i, j;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1596[i][j] = &g_177;
            }
            for (g_933 = 0; (g_933 <= 6); g_933 += 1)
            { /* block id: 603 */
                uint8_t l_1569 = 0x80L;
                int8_t **l_1579 = &g_407;
                for (g_114 = 1; (g_114 <= 6); g_114 += 1)
                { /* block id: 606 */
                    if ((*p_15))
                        break;
                }
                for (g_998 = 4; (g_998 >= 0); g_998 -= 1)
                { /* block id: 611 */
                    int i;
                    g_87[g_998] = g_87[g_998];
                    (**g_1350) = &p_16;
                    for (g_67 = 2; (g_67 <= 6); g_67 += 1)
                    { /* block id: 616 */
                        l_1569 ^= ((*p_15) = 0x5864EBD0L);
                    }
                    for (g_28 = 0; (g_28 <= 6); g_28 += 1)
                    { /* block id: 622 */
                        return l_1570;
                    }
                }
                for (g_998 = 6; (g_998 >= 2); g_998 -= 1)
                { /* block id: 628 */
                    int32_t ***l_1576 = &g_996;
                    for (g_28 = 2; (g_28 <= 6); g_28 += 1)
                    { /* block id: 631 */
                        l_1571 = (void*)0;
                        if ((*p_15))
                            continue;
                    }
                    if (l_1567[0])
                        break;
                    (*l_1570) |= ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */(((g_1577 = l_1575[2]) == l_1578), 2)) == ((void*)0 == l_1579));
                }
            }
            (***g_1349) = l_1580;
            if ((65535UL == (safe_div_func_int8_t_s_s_unsafe_macro/*38*//* ___SAFE__OP */((((p_16 , ((((((safe_sub_func_int64_t_s_s_unsafe_macro/*39*//* ___SAFE__OP */((((safe_mod_func_uint64_t_u_u_unsafe_macro/*40*//* ___SAFE__OP */((~(safe_add_func_uint32_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */((((((!(safe_mod_func_int16_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((l_1595 != &l_1596[3][0]), 0)), l_1554))) & ((((*p_17) | ((((safe_mod_func_int16_t_s_s_unsafe_macro/*44*//* ___SAFE__OP */(((g_67 = ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*45*//* ___SAFE__OP */(0xD001649E5BF44AB4LL, 30)) > (safe_mul_func_int16_t_s_s_unsafe_macro/*46*//* ___SAFE__OP */(((safe_mod_func_int64_t_s_s_unsafe_macro/*47*//* ___SAFE__OP */(((((((l_1554 , (safe_mul_func_uint64_t_u_u_unsafe_macro/*48*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */((((p_16 , g_60) != l_1567[1]) & p_16), (-1L))), g_341))) , (void*)0) != &l_1596[3][0]) <= 0x321CFEF4L) & g_5) ^ (*g_111)), g_1384[3][1][2])) & g_106), (*g_1393))))) && (*l_1570)), (*g_1154))) >= p_16) & 0L) | 4294967290UL)) == (*g_1393)) < 1L)) , l_1609) != (void*)0) != g_284), (*p_17)))), l_1611)) <= 0UL) > g_998), 0x08AC3C13E2C5BF11LL)) != l_1554) , p_16) , p_16) > (*g_407)) <= l_1612)) & 5UL) , 0L), l_1567[0]))))
            { /* block id: 642 */
                int32_t l_1613 = 0x65E4E178L;
                int32_t l_1615 = 0xBF32F588L;
                int32_t l_1663 = 0x75D315B0L;
                int32_t l_1665 = 0xF94088D2L;
                int32_t l_1666 = (-1L);
                int32_t l_1671 = 0xD99DFEB3L;
                (*p_15) = l_1613;
                for (g_83 = 0; (g_83 <= 2); g_83 += 1)
                { /* block id: 646 */
                    int8_t l_1614 = 0x32L;
                    uint16_t l_1623[3][8][9] = {{{0x174AL,65535UL,0xCF15L,65533UL,1UL,65533UL,0xCF15L,65535UL,0x174AL},{1UL,0x648FL,3UL,1UL,5UL,0xD4E9L,0xD4E9L,5UL,1UL},{65532UL,65535UL,65532UL,5UL,65528UL,65533UL,65532UL,65535UL,65532UL},{1UL,65535UL,0xD4E9L,3UL,5UL,65527UL,65528UL,0xD4E9L,0x8EF5L},{0xD786L,5UL,1UL,0x45E8L,0x174AL,0x45E8L,1UL,5UL,0xD786L},{65527UL,3UL,0x29D0L,0x8EF5L,1UL,0x29D0L,65528UL,65527UL,65527UL},{65535UL,5UL,65535UL,1UL,65532UL,0x45E8L,65535UL,65533UL,65535UL},{65527UL,1UL,65528UL,65528UL,1UL,65527UL,0x29D0L,0xD4E9L,65527UL}},{{0xD786L,65533UL,1UL,1UL,0x174AL,1UL,1UL,65533UL,0xD786L},{0x8EF5L,3UL,65528UL,0x8EF5L,65527UL,0x29D0L,0x29D0L,65527UL,0x8EF5L},{65535UL,65533UL,65535UL,0x45E8L,65532UL,1UL,65535UL,5UL,65535UL},{0x8EF5L,1UL,0x29D0L,65528UL,65527UL,65527UL,65528UL,0xD4E9L,0x8EF5L},{0xD786L,5UL,1UL,0x45E8L,0x174AL,0x45E8L,1UL,5UL,0xD786L},{65527UL,3UL,0x29D0L,0x8EF5L,1UL,0x29D0L,65528UL,65527UL,65527UL},{65535UL,5UL,65535UL,1UL,65532UL,0x45E8L,65535UL,65533UL,65535UL},{65527UL,1UL,65528UL,65528UL,1UL,65527UL,0x29D0L,0xD4E9L,65527UL}},{{0xD786L,65533UL,1UL,1UL,0x174AL,1UL,1UL,65533UL,0xD786L},{0x8EF5L,3UL,65528UL,0x8EF5L,65527UL,0x29D0L,0x29D0L,65527UL,0x8EF5L},{65535UL,65533UL,65535UL,0x45E8L,65532UL,1UL,65535UL,5UL,65535UL},{0x8EF5L,1UL,0x29D0L,65528UL,65527UL,65527UL,65528UL,0xD4E9L,0x8EF5L},{0xD786L,5UL,1UL,0x45E8L,0x174AL,0x45E8L,1UL,5UL,0xD786L},{65527UL,3UL,0x29D0L,0x8EF5L,1UL,0x29D0L,65528UL,65527UL,65527UL},{65535UL,5UL,65535UL,1UL,65532UL,0x45E8L,65535UL,65533UL,65535UL},{65527UL,1UL,65528UL,65528UL,1UL,65527UL,0x29D0L,0xD4E9L,65527UL}}};
                    int32_t **l_1655 = &l_1580;
                    int8_t l_1662 = (-10L);
                    int32_t l_1664 = 0xD5E3AC02L;
                    int i, j, k;
                    for (g_341 = 0; (g_341 <= 2); g_341 += 1)
                    { /* block id: 649 */
                        l_1616--;
                        l_1554 = ((safe_div_func_uint16_t_u_u_unsafe_macro/*50*//* ___SAFE__OP */(((((safe_add_func_uint16_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */(((void*)0 != &p_15), l_1623[2][3][0])) , ((safe_div_func_int16_t_s_s_unsafe_macro/*52*//* ___SAFE__OP */(((l_1626 ^ ((l_1567[0] && 0x895F8D28DD48F6A0LL) & g_256)) < (((0x3FB0L != (~4294967294UL)) & p_16) > l_1623[2][3][0])), (*g_1154))) < g_1628)) , p_16) <= l_1629), 0x9256L)) == 0x730BF1A6L);
                    }
                    if ((*l_1570))
                    { /* block id: 653 */
                        int32_t *****l_1637 = &l_1634;
                        uint32_t *l_1659 = &g_85;
                        int i, j;
                        (*l_1570) = (safe_sub_func_uint8_t_u_u_unsafe_macro/*53*//* ___SAFE__OP */(((p_16 || (safe_lshift_func_uint16_t_u_u_unsafe_macro/*54*//* ___SAFE__OP */(((**l_1572) = (&l_1595 == ((*l_1637) = l_1634))), (((safe_sub_func_uint8_t_u_u_unsafe_macro/*55*//* ___SAFE__OP */(g_1543[2][0], (safe_mul_func_uint8_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*57*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*58*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*59*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*60*//* ___SAFE__OP */(((((safe_unary_minus_func_int8_t_s_unsafe_macro/*61*//* ___SAFE__OP */((0x8CA4119BF71E70C3LL < (safe_rshift_func_int32_t_s_s_unsafe_macro/*62*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*63*//* ___SAFE__OP */(l_1614, ((l_1655 == &p_17) >= (safe_mul_func_uint32_t_u_u_unsafe_macro/*64*//* ___SAFE__OP */(((*l_1659) = (&l_1610[g_83][(g_83 + 2)] == l_1658)), 0x8BADC6C2L))))), 20))))) | 2L) , (void*)0) != g_1660), l_1613)), (*g_111))), (-1L))), 0UL)), p_16)))) <= 247UL) ^ p_16)))) , 255UL), l_1555));
                    }
                    else
                    { /* block id: 658 */
                        int16_t l_1667 = (-1L);
                        int32_t l_1668 = 0x583A00BBL;
                        (***g_1349) = &p_16;
                        ++l_1672;
                        if ((*l_1570))
                            break;
                    }
                    for (g_1257 = 1; (g_1257 >= 0); g_1257 -= 1)
                    { /* block id: 665 */
                        volatile int32_t *****l_1675 = &g_659;
                        (**g_1350) = &p_16;
                        if ((*p_15))
                            break;
                        (*l_1675) = &g_660;
                    }
                }
                for (l_1613 = 0; (l_1613 <= 6); l_1613 += 1)
                { /* block id: 673 */
                    int32_t *l_1688 = (void*)0;
                    for (g_786 = 0; (g_786 <= 4); g_786 += 1)
                    { /* block id: 676 */
                        const uint64_t ***l_1693 = &g_490[3][0][0];
                        const uint64_t ***l_1694 = (void*)0;
                        const uint64_t ***l_1695 = &g_490[3][2][1];
                        const uint64_t ***l_1696 = &g_490[2][3][1];
                        const uint64_t ***l_1697 = &g_490[3][2][1];
                        const uint64_t ***l_1698 = &g_490[3][2][1];
                        const uint64_t ***l_1699 = &g_490[3][2][1];
                        const uint64_t ***l_1700 = &g_490[4][2][1];
                        const uint64_t ***l_1701[3][10] = {{&g_490[2][0][1],&g_490[3][2][1],&g_490[0][0][0],&g_490[0][0][0],&g_490[3][2][1],&g_490[2][0][1],&g_490[3][2][1],&g_490[3][2][1],&g_490[3][2][1],(void*)0},{&g_490[3][2][1],(void*)0,&g_490[3][2][1],&g_490[3][2][1],(void*)0,&g_490[3][2][1],(void*)0,&g_490[3][2][1],&g_490[3][2][1],(void*)0},{&g_490[3][2][1],(void*)0,&g_490[3][2][1],&g_490[3][2][1],(void*)0,&g_490[3][2][1],(void*)0,&g_490[3][2][1],&g_490[3][2][1],(void*)0}};
                        int32_t *** const *l_1705[7] = {&l_1595,&l_1595,&l_1595,&l_1595,&l_1595,&l_1595,&l_1595};
                        uint8_t *l_1709[9] = {&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67};
                        int i, j;
                        g_87[g_786] = g_87[g_786];
                        (***g_1349) = ((safe_sub_func_uint32_t_u_u_unsafe_macro/*65*//* ___SAFE__OP */(((((void*)0 == &g_111) || (safe_rshift_func_uint16_t_u_u_unsafe_macro/*66*//* ___SAFE__OP */((l_1567[0] , 0xA516L), 1))) ^ (safe_mod_func_int32_t_s_s_unsafe_macro/*67*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*68*//* ___SAFE__OP */((*p_15), (safe_rshift_func_uint32_t_u_s_unsafe_macro/*69*//* ___SAFE__OP */(((*g_111) = 0xA86F248FL), (*p_17))))), (*p_17)))), (safe_sub_func_int32_t_s_s_unsafe_macro/*70*//* ___SAFE__OP */(0L, 0L)))) , l_1688);
                        (*p_17) = ((safe_rshift_func_int32_t_s_u_unsafe_macro/*71*//* ___SAFE__OP */((g_1691 == (l_1702 = (l_1692 = l_1692))), 2)) & (((g_1257 = (((g_933 != (safe_sub_func_uint32_t_u_u_unsafe_macro/*72*//* ___SAFE__OP */((((((l_1705[4] != l_1706) || p_16) < (g_1235 & ((*g_1154) < ((void*)0 != l_1709[1])))) ^ (-1L)) , p_16), (-8L)))) ^ (*p_17)) || p_16)) < 65535UL) >= (*g_111)));
                    }
                }
            }
            else
            { /* block id: 686 */
                int64_t *l_1718 = &g_341;
                int32_t **l_1736 = &g_177;
                int32_t l_1766 = 8L;
                int64_t l_1784 = 0L;
                int8_t l_1792 = 0x96L;
                int32_t l_1794 = 9L;
                int32_t l_1797 = 1L;
                int32_t l_1806 = 0xAFB402ADL;
                int32_t l_1809 = 4L;
                int32_t l_1810 = (-5L);
                if (((-5L) >= g_786))
                { /* block id: 687 */
                    for (g_114 = 0; (g_114 <= 6); g_114 += 1)
                    { /* block id: 690 */
                        if (l_1626)
                            goto lbl_1710;
                    }
                    if ((*p_15))
                        continue;
                    for (g_81 = 0; (g_81 <= 6); g_81 += 1)
                    { /* block id: 696 */
                        (**l_1595) = &p_16;
                        (*p_17) = 0L;
                    }
                    for (g_138 = 2; (g_138 <= 6); g_138 += 1)
                    { /* block id: 702 */
                        (*l_1708) = &p_16;
                        if (l_1711)
                            break;
                    }
                }
                else
                { /* block id: 706 */
                    int64_t *l_1717 = &l_1567[0];
                    int64_t **l_1716 = &l_1717;
                    int32_t l_1747 = 0L;
                    int32_t * const l_1750 = &g_998;
                    uint16_t **l_1762[8][4] = {{&g_702,&g_1154,(void*)0,&g_702},{&g_702,&g_1393,&g_702,&g_1393},{&g_702,&g_1393,&g_1393,&g_1393},{&g_702,&g_1393,&g_702,&g_702},{&g_702,&g_1154,&g_1393,(void*)0},{&g_702,&g_702,&g_1393,&g_1393},{&g_702,&g_702,&g_1393,&g_702},{&g_702,&g_1393,&g_702,&g_1154}};
                    uint16_t ***l_1761 = &l_1762[0][0];
                    uint32_t l_1763 = 7UL;
                    int i, j;
                    if ((safe_sub_func_int64_t_s_s_unsafe_macro/*73*//* ___SAFE__OP */(((*p_17) | (safe_sub_func_uint64_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */((((*l_1716) = (void*)0) != (l_1719[6][7] = l_1718)), ((safe_lshift_func_uint8_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */((--(**g_1489)), (p_16 ^ ((*g_1393) = (0UL >= (safe_mod_func_uint32_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */(0x861C7DBAL, (safe_sub_func_uint16_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */((*g_1393), (((-5L) ^ (safe_lshift_func_uint8_t_u_s_unsafe_macro/*80*//* ___SAFE__OP */(((0UL < 0x00A584EBL) , p_16), 2))) , p_16)))))))))), 0xA56EL)), p_16)) | 0x72C48DD9L)))), g_341)))
                    { /* block id: 711 */
                        (**g_1350) = (***g_1349);
                        (**g_1350) = (***g_1349);
                        (*l_1570) = ((((safe_lshift_func_int64_t_s_u_unsafe_macro/*81*//* ___SAFE__OP */(((void*)0 == l_1736), 44)) | (safe_div_func_uint16_t_u_u_unsafe_macro/*82*//* ___SAFE__OP */((**g_1661), (((safe_lshift_func_int32_t_s_s_unsafe_macro/*83*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*84*//* ___SAFE__OP */((0xA730E6179C177077LL || ((**g_1489) |= ((((*g_1190) = ((safe_div_func_uint32_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((18446744073709551611UL <= ((safe_add_func_uint64_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(((*p_15) , ((l_1747 <= g_81) <= (safe_div_func_uint8_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */((l_1750 == p_15), p_16)))), p_16)) | 0x7C20D6F1L)), p_16)) | p_16)) | (-1L)) ^ p_16))), 0xF9B64CB26C886EEFLL)), (*p_15))) , 0x7C73L) , (-1L))))) != g_1155) ^ 0x7FL);
                    }
                    else
                    { /* block id: 717 */
                        uint32_t *l_1764[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int32_t l_1765 = 0xBFD6C9BDL;
                        int i;
                        if ((*g_89))
                            break;
                        (*p_17) ^= (0x80D3L == ((safe_lshift_func_int64_t_s_s_unsafe_macro/*88*//* ___SAFE__OP */(((((**l_1572) = (0x98L < (l_1766 &= (l_1747 , (((*g_1490) = ((((safe_sub_func_int64_t_s_s_unsafe_macro/*89*//* ___SAFE__OP */(((((*l_1718) ^= g_287) , (safe_add_func_uint64_t_u_u_unsafe_macro/*90*//* ___SAFE__OP */(4UL, ((*g_111) ^ (g_85 = ((((safe_lshift_func_uint16_t_u_s_unsafe_macro/*91*//* ___SAFE__OP */(0xEF8BL, l_1747)) < (((void*)0 != l_1761) | l_1763)) , 1UL) <= g_1235)))))) ^ 0xF3L), (-10L))) <= (***g_1660)) , p_16) , l_1765)) != 18446744073709551609UL))))) , g_1017) , g_3), 59)) <= 0xACD7L));
                    }
                }
                if ((((safe_rshift_func_uint8_t_u_u_unsafe_macro/*92*//* ___SAFE__OP */(g_81, 7)) , (safe_sub_func_uint16_t_u_u_unsafe_macro/*93*//* ___SAFE__OP */(((g_931 <= (safe_lshift_func_int8_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_s_unsafe_macro/*95*//* ___SAFE__OP */((((0UL | (safe_sub_func_int64_t_s_s_unsafe_macro/*96*//* ___SAFE__OP */(1L, (p_16 , (+p_16))))) && (((*l_1718) ^= ((0x6F73979BF8702BA8LL >= (safe_lshift_func_uint16_t_u_u_unsafe_macro/*97*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((((*p_17) ^= (((safe_rshift_func_uint8_t_u_u_unsafe_macro/*99*//* ___SAFE__OP */((g_1543[2][0] = 0x28L), 0)) <= (1L ^ (-7L))) , (*p_15))) || (*g_111)) > (*p_15)), (-10L))) >= p_16), (**g_1661)))) >= 0xC2L)) <= 0x5E6C3105580E1748LL)) , (*g_1154)), p_16)), l_1784))) != (***g_1660)), p_16))) , (*p_15)))
                { /* block id: 730 */
                    for (l_1616 = 0; (l_1616 <= 6); l_1616 += 1)
                    { /* block id: 733 */
                        --g_1785;
                        (*l_1736) = &p_16;
                    }
                    for (g_786 = 6; (g_786 >= 0); g_786 -= 1)
                    { /* block id: 739 */
                        uint8_t l_1788 = 255UL;
                        (*p_17) = (g_1235 , (g_60 != p_16));
                        l_1788++;
                    }
                }
                else
                { /* block id: 743 */
                    int64_t l_1793 = (-1L);
                    int32_t l_1804 = (-7L);
                    int32_t l_1808[3];
                    uint64_t l_1811 = 0x4DC4F005D534640FLL;
                    int8_t l_1817[4][7] = {{0xA4L,(-5L),0xA4L,0xD0L,0xD0L,0xA4L,(-5L)},{0xB9L,0L,7L,7L,0L,0xB9L,0L},{0xA4L,0xD0L,0xD0L,0xA4L,(-5L),0xA4L,0xD0L},{9L,9L,0xB9L,7L,0xB9L,9L,9L}};
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_1808[i] = 0x9E87D6E6L;
                    for (g_138 = 0; (g_138 <= 6); g_138 += 1)
                    { /* block id: 746 */
                        int32_t l_1795 = 0x09B5AA5BL;
                        int32_t l_1796 = (-4L);
                        int32_t l_1799 = 0x40FE114CL;
                        int32_t l_1803[2][8] = {{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L}};
                        int i, j;
                        l_1811++;
                        (*p_15) &= (*p_17);
                        (*l_1570) = (-1L);
                        (*p_17) = (l_1817[2][5] ^= ((g_1814 = &l_1572) == (void*)0));
                    }
                    (*p_17) = (+(safe_rshift_func_uint32_t_u_s_unsafe_macro/*100*//* ___SAFE__OP */(p_16, 21)));
                    for (g_786 = 6; (g_786 >= 0); g_786 -= 1)
                    { /* block id: 757 */
                        (***g_1349) = ((*l_1708) = &p_16);
                    }
                }
            }
        }
        (*p_17) = (-1L);
        for (g_1257 = 22; (g_1257 == (-27)); --g_1257)
        { /* block id: 767 */
            const uint8_t l_1834 = 9UL;
            int32_t l_1855 = 0x877DAE20L;
            int32_t l_1859 = 0x8AF1FFCBL;
            int32_t l_1864 = 0x27E5A151L;
            int32_t l_1920 = 0x82C8FA4CL;
            uint32_t l_2016 = 4294967295UL;
            if ((safe_rshift_func_uint32_t_u_s_unsafe_macro/*101*//* ___SAFE__OP */((((((safe_div_func_uint8_t_u_u_unsafe_macro/*102*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_s_unsafe_macro/*103*//* ___SAFE__OP */(((0xE409D24B8CA60A67LL <= ((*g_1190) || (safe_rshift_func_uint8_t_u_u_unsafe_macro/*104*//* ___SAFE__OP */((~(((safe_sub_func_int8_t_s_s_unsafe_macro/*105*//* ___SAFE__OP */(((((0x24BAF2ADL <= l_1834) & ((safe_unary_minus_func_uint64_t_u_unsafe_macro/*106*//* ___SAFE__OP */(((0xDAL ^ ((safe_lshift_func_int32_t_s_u_unsafe_macro/*107*//* ___SAFE__OP */((((safe_lshift_func_uint8_t_u_u_unsafe_macro/*108*//* ___SAFE__OP */(0xE1L, 4)) & (l_1840 = 0xD2L)) & (safe_lshift_func_uint8_t_u_u_unsafe_macro/*109*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*110*//* ___SAFE__OP */((l_1791 && ((*g_111) = l_1834)), g_341)), g_171))), l_1834)) , p_16)) == p_16))) ^ 0xD02A3274L)) == 0xF4D1L) <= 65528UL), l_1834)) ^ l_1845) != (-4L))), l_1834)))) <= p_16), 9)) , p_16), l_1834)) < p_16) | 0UL) > l_1846) < g_67), 30)))
            { /* block id: 770 */
                uint32_t l_1853 = 0xDF5D567EL;
                uint64_t *l_1854 = &g_1628;
                int32_t l_1883 = 0xC7C9D833L;
                int32_t l_1884 = 1L;
                int32_t l_1885 = 0x313E59D0L;
                for (l_1791 = 0; (l_1791 < (-5)); --l_1791)
                { /* block id: 773 */
                    int32_t l_1856 = 1L;
                    uint32_t l_1861 = 4294967295UL;
                    int32_t l_1865[7] = {0xD2AA6E93L,0xD2AA6E93L,0xD2AA6E93L,0xD2AA6E93L,0xD2AA6E93L,0xD2AA6E93L,0xD2AA6E93L};
                    int32_t *l_1891 = &l_1798;
                    uint16_t **l_1911 = &g_1154;
                    int32_t *l_1923 = &l_1865[3];
                    int i;
                    for (l_1805 = 28; (l_1805 >= (-29)); l_1805--)
                    { /* block id: 776 */
                        int32_t *l_1857 = (void*)0;
                        int32_t *l_1858[4][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
                        int i, j;
                        (*p_15) = (safe_rshift_func_uint64_t_u_u_unsafe_macro/*111*//* ___SAFE__OP */((((*g_1154) = (p_16 != l_1853)) ^ ((void*)0 == l_1854)), (***g_1488)));
                        --l_1861;
                        l_1866++;
                        (***l_1706) = &l_1856;
                    }
                    for (g_287 = 6; (g_287 <= 38); ++g_287)
                    { /* block id: 785 */
                        if ((*p_17))
                            break;
                    }
                    for (l_1860 = 3; (l_1860 <= 8); l_1860 += 1)
                    { /* block id: 790 */
                        int32_t *l_1871 = &l_1798;
                        int32_t *l_1872 = (void*)0;
                        int32_t l_1873[5][6][8] = {{{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL}},{{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL}},{{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL}},{{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL}},{{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL},{0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL,0x7D1F1B2DL}}};
                        int32_t *l_1874 = &l_1798;
                        int32_t *l_1875 = &l_1802[8][3];
                        int32_t *l_1876 = &g_88[3][0][1];
                        int32_t *l_1877 = &g_3;
                        int32_t *l_1878 = (void*)0;
                        int32_t *l_1879 = (void*)0;
                        int32_t *l_1880 = &l_1856;
                        int32_t *l_1881 = (void*)0;
                        int32_t *l_1882[9];
                        uint64_t l_1886 = 18446744073709551615UL;
                        int32_t **l_1890 = &l_1871;
                        int32_t ***l_1889 = &l_1890;
                        int i, j, k;
                        for (i = 0; i < 9; i++)
                            l_1882[i] = &l_1856;
                        ++l_1886;
                        l_1859 = ((0xF026BAC7A17554B3LL <= (((*l_1635) = ((**l_1706) = &p_15)) != ((*l_1889) = &p_15))) || g_1236[l_1860]);
                        return g_1893;
                    }
                    for (l_1845 = 0; (l_1845 == (-19)); l_1845 = safe_sub_func_int64_t_s_s_unsafe_macro/*112*//* ___SAFE__OP */(l_1845, 4))
                    { /* block id: 800 */
                        uint32_t l_1906 = 0xF3EE1504L;
                        uint16_t **l_1910 = &g_1393;
                        uint16_t ***l_1909[7][3] = {{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910},{&l_1910,&l_1910,&l_1910}};
                        int32_t *l_1922 = &l_1856;
                        int32_t *l_1924 = &l_1859;
                        int32_t *l_1925[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                        int i, j;
                        (*p_15) &= (l_1864 == (safe_rshift_func_uint32_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */(((p_16 | ((*l_1891) > ((***g_1488) != (safe_lshift_func_int32_t_s_u_unsafe_macro/*114*//* ___SAFE__OP */((*p_17), (*g_111)))))) , (safe_add_func_int8_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */((p_16 & (p_16 , (p_16 <= l_1864))), p_16))), l_1906)));
                        if ((*g_1893))
                            continue;
                        (*p_15) = (((p_16 <= 1L) == (&g_659 == &g_659)) && ((((l_1911 = (void*)0) != (void*)0) ^ 0L) , (((safe_lshift_func_int32_t_s_u_unsafe_macro/*116*//* ___SAFE__OP */(((l_1920 &= (safe_mul_func_uint16_t_u_u_unsafe_macro/*117*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_u_unsafe_macro/*118*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*119*//* ___SAFE__OP */(0x4F4AL, g_67)), 5)), g_341))) != 1L), g_1921)) ^ p_16) || p_16)));
                        return l_1925[0];
                    }
                }
            }
            else
            { /* block id: 809 */
                uint64_t l_1939 = 0xC44E7939330FF9CFLL;
                const int32_t l_1943 = (-1L);
                int32_t l_1955 = 0x9D59AE36L;
                int16_t *l_1956 = &l_1611;
                uint32_t l_1959 = 0x536869F6L;
                int32_t l_1961 = 0x358958DDL;
                int32_t ** const l_2040 = &l_1580;
                for (l_1801 = (-15); (l_1801 == 3); l_1801 = safe_add_func_uint16_t_u_u_unsafe_macro/*120*//* ___SAFE__OP */(l_1801, 4))
                { /* block id: 812 */
                    uint64_t l_1928 = 18446744073709551612UL;
                    int32_t ** const l_1933[2] = {&g_177,&g_177};
                    int8_t l_1941 = 0xC7L;
                    int i;
                    (*p_15) = l_1928;
                    (*p_17) = ((*g_1416) = ((*p_15) = (((((safe_rshift_func_int8_t_s_u_unsafe_macro/*121*//* ___SAFE__OP */((((*g_111) && ((((*l_1892) = (safe_mul_func_int16_t_s_s_unsafe_macro/*122*//* ___SAFE__OP */((((((*g_1490) & ((l_1933[1] == (void*)0) , g_3)) , (((safe_rshift_func_int8_t_s_u_unsafe_macro/*123*//* ___SAFE__OP */(((((p_16 ^ (l_1936[6] == (((safe_sub_func_int64_t_s_s_unsafe_macro/*124*//* ___SAFE__OP */(l_1939, 1UL)) ^ p_16) , l_1940))) != 65535UL) , &g_1487) == &g_1487), 5)) , l_1864) ^ 0xD0F55FC4L)) <= l_1939) | p_16), 0x487DL))) <= (*p_15)) | l_1941)) ^ l_1942), 2)) > (*g_1416)) , g_1384[4][0][2]) >= 0UL) | l_1943)));
                }
                if ((safe_div_func_int32_t_s_s_unsafe_macro/*125*//* ___SAFE__OP */(((*p_15) == (((safe_mul_func_int8_t_s_s_unsafe_macro/*126*//* ___SAFE__OP */(((l_1961 ^= ((safe_sub_func_int64_t_s_s_unsafe_macro/*127*//* ___SAFE__OP */(((***g_1412) < (((safe_lshift_func_int8_t_s_s_unsafe_macro/*128*//* ___SAFE__OP */((~((((*l_1956) = (l_1955 = (l_1943 , ((safe_sub_func_int32_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */(l_1943, 0xCAD0D9A7L)) < (1L > l_1939))))) != ((safe_add_func_int64_t_s_s_unsafe_macro/*130*//* ___SAFE__OP */((0xC2L <= (-1L)), l_1959)) ^ l_1959)) > l_1959)), 5)) && g_1960) & 0xC0L)), l_1939)) , (*g_1393))) != 0x556EL), p_16)) == l_1943) != (*g_111))), (*g_1386))))
                { /* block id: 822 */
                    uint16_t l_1971 = 1UL;
                    if ((*p_15))
                        break;
                    for (g_1960 = 0; (g_1960 > 10); ++g_1960)
                    { /* block id: 826 */
                        int32_t *l_1964 = (void*)0;
                        int32_t *l_1965 = &l_1864;
                        int32_t *l_1966 = &l_1798;
                        int32_t *l_1967 = &l_1798;
                        int32_t *l_1968 = &l_1864;
                        int32_t *l_1969 = &g_3;
                        int32_t *l_1970[8][2] = {{(void*)0,(void*)0},{&g_88[1][0][1],(void*)0},{(void*)0,&g_88[1][0][1]},{(void*)0,(void*)0},{&g_88[1][0][1],(void*)0},{(void*)0,&g_88[1][0][1]},{(void*)0,(void*)0},{&g_88[1][0][1],(void*)0}};
                        int i, j;
                        l_1971++;
                        if (g_931)
                            goto lbl_1710;
                    }
                    for (g_171 = 0; (g_171 <= 19); g_171 = safe_add_func_int32_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */(g_171, 9))
                    { /* block id: 832 */
                        uint32_t *l_1980[7][1][2] = {{{&g_85,&g_85}},{{&g_85,&g_85}},{{&g_85,&g_85}},{{&g_85,&g_85}},{{&g_85,&g_85}},{{&g_85,&g_85}},{{&g_85,&g_85}}};
                        int i, j, k;
                        (*p_17) &= (((safe_lshift_func_int32_t_s_u_unsafe_macro/*132*//* ___SAFE__OP */((((safe_mul_func_int32_t_s_s_unsafe_macro/*133*//* ___SAFE__OP */((((*g_111) > (g_85 &= p_16)) , 2L), ((*p_15) = (safe_mod_func_int64_t_s_s_unsafe_macro/*134*//* ___SAFE__OP */((p_16 <= ((**g_1489) && 18446744073709551614UL)), 1L))))) , (((~(safe_mul_func_uint8_t_u_u_unsafe_macro/*135*//* ___SAFE__OP */((0xEA13L != (safe_mod_func_uint32_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */(0x271CA394L, (*p_15)))), (**g_1413)))) >= l_1855) , (*g_1154))) | g_5), 2)) , (*g_111)) , l_1864);
                    }
                }
                else
                { /* block id: 837 */
                    uint32_t l_2012 = 18446744073709551615UL;
                    int32_t *l_2013 = (void*)0;
                    int32_t *l_2014 = &l_1791;
                    int8_t **l_2022 = &g_407;
                    uint16_t ***l_2033[4][1][8];
                    int8_t ** const l_2035 = &g_407;
                    int8_t *****l_2037 = &g_1422[3][1];
                    int8_t *****l_2038 = &g_1422[1][0];
                    int8_t *****l_2039 = &l_2036;
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 1; j++)
                        {
                            for (k = 0; k < 8; k++)
                                l_2033[i][j][k] = &l_1940;
                        }
                    }
                    (*p_15) = ((safe_unary_minus_func_uint16_t_u_unsafe_macro/*137*//* ___SAFE__OP */(65528UL)) , (0UL >= ((safe_mod_func_int64_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */(((*g_111) && (safe_rshift_func_uint32_t_u_s_unsafe_macro/*139*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*140*//* ___SAFE__OP */((((safe_mul_func_int16_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */((g_2015 = ((*p_15) || (~((p_16 , (((**g_1413) & (safe_add_func_int64_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */((0x65BBL | (((safe_lshift_func_int16_t_s_u_unsafe_macro/*143*//* ___SAFE__OP */(((*l_1956) ^= (((*l_1892) ^= (safe_div_func_int32_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */(((((*l_2014) = (safe_div_func_int64_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_u_unsafe_macro/*146*//* ___SAFE__OP */(((*g_111) = ((safe_mul_func_uint16_t_u_u_unsafe_macro/*147*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */(l_2012, (*g_1893))), p_16)) == p_16)), 0)), p_16))) , &g_997[1][3][2]) != &g_997[1][3][2]), (*p_17)))) , 0xBD15L)), l_2012)) > l_1943) ^ p_16)), (**g_1489)))) & 0xDCBB2F3BL)) , p_16)))), g_1257)) <= l_2016) || p_16), p_16)), 29))), 0x17237DC59B22BFACLL)) >= l_1959)));
                    for (g_341 = 1; (g_341 <= 21); g_341 = safe_add_func_int8_t_s_s_unsafe_macro/*149*//* ___SAFE__OP */(g_341, 9))
                    { /* block id: 846 */
                        (*g_2019) = (p_16 , (*g_1488));
                    }
                    (*p_17) = (((((l_1943 , l_2020) != &g_111) && ((((l_2022 = l_2021) != ((((safe_mul_func_int8_t_s_s_unsafe_macro/*150*//* ___SAFE__OP */((***g_1412), (safe_lshift_func_int8_t_s_u_unsafe_macro/*151*//* ___SAFE__OP */(((safe_sub_func_int32_t_s_s_unsafe_macro/*152*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*153*//* ___SAFE__OP */((l_2012 , (g_1960 >= (safe_mod_func_uint16_t_u_u_unsafe_macro/*154*//* ___SAFE__OP */((((l_1940 = &g_1154) != (void*)0) && p_16), g_284)))), (**g_1661))) | l_2034), 4294967291UL)) , l_1859), 5)))) , l_1553[5][1]) != (void*)0) , l_2035)) >= (*p_17)) && (**g_1661))) >= 0x57A589D3L) <= p_16);
                    (*p_17) = ((&g_1423[4][0][0] == ((*l_2039) = l_2036)) != (&p_17 == l_2040));
                }
            }
            (*g_1893) ^= (g_2041 == (void*)0);
        }
    }
    if ((~(safe_sub_func_int64_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */(p_16, (0x6BC3757E7418AC98LL >= (safe_div_func_uint32_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */(((p_16 > (-9L)) == p_16), (safe_add_func_uint32_t_u_u_unsafe_macro/*157*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */(((p_16 && (((**g_1413) = (*g_407)) | ((((*g_111) && (((~(safe_add_func_uint16_t_u_u_unsafe_macro/*160*//* ___SAFE__OP */((*g_1393), 0xA419L))) , &p_16) == &p_16)) >= (*p_15)) & 255UL))) >= g_806[1]), 8L)), 1UL)), (-10L))))))))))
    { /* block id: 860 */
        uint32_t l_2091 = 0x483C342EL;
        int32_t l_2096[10][3][4] = {{{0x26AA5F3EL,0x26AA5F3EL,0x544FE020L,0x2F0DCB17L},{5L,0x10584174L,0xD7B0E284L,0xEBA8AE9FL},{1L,0x16EA934DL,0x5F4201B7L,0xD7B0E284L}},{{0xAA9F8527L,0x16EA934DL,8L,0xEBA8AE9FL},{0x16EA934DL,0x10584174L,(-10L),0x2F0DCB17L},{0x0E67C97DL,0x26AA5F3EL,0x08FAA6D3L,0x1E63CD53L}},{{0xBBBB45C1L,0x7CAC6F4FL,5L,1L},{0xD7B0E284L,0x544FE020L,2L,0xB6F45ACFL},{0xAA9F8527L,(-2L),0x2F0DCB17L,0x9353992CL}},{{2L,0x28ACD887L,1L,0xB0BFA196L},{1L,0xAD4D6698L,0x544FE020L,0x1E63CD53L},{0x2B91A156L,0x34339ED2L,0xBBBB45C1L,0x5F4201B7L}},{{5L,0L,0x16EA934DL,6L},{0xFA0D3926L,0x16EA934DL,0x2F0DCB17L,0x16EA934DL},{0x5F4201B7L,(-3L),8L,0x13F9C598L}},{{0x2B5D0C55L,0xFAAF846EL,0L,0x2F0DCB17L},{0xBBBB45C1L,0x34339ED2L,0x2B91A156L,0x544FE020L},{0xBBBB45C1L,0xEBA8AE9FL,0L,0xF90B11EDL}},{{0x2B5D0C55L,0x544FE020L,8L,0x9353992CL},{0x5F4201B7L,1L,0x2F0DCB17L,4L},{0xFA0D3926L,0x0E67C97DL,0x16EA934DL,0xB0BFA196L}},{{5L,0x7CAC6F4FL,0xBBBB45C1L,0x544FE020L},{0x2B91A156L,0x08FAA6D3L,0x544FE020L,(-1L)},{1L,0L,1L,0xEBA8AE9FL}},{{2L,(-3L),0x2F0DCB17L,1L},{0xAA9F8527L,0x2B5D0C55L,2L,0x13F9C598L},{0xD7B0E284L,0x10584174L,5L,0x5F4201B7L}},{{0xBBBB45C1L,0x08FAA6D3L,0x08FAA6D3L,0xBBBB45C1L},{0x0E67C97DL,0xEBA8AE9FL,(-10L),1L},{0x16EA934DL,0x28ACD887L,8L,4L}}};
        int16_t *l_2111 = (void*)0;
        uint8_t l_2168 = 249UL;
        uint8_t l_2173 = 0xB1L;
        int32_t *l_2200[3];
        int8_t **l_2201 = &g_407;
        int64_t ** const l_2204[7] = {&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042,&g_2042};
        uint64_t ***l_2238 = &g_318;
        uint64_t ****l_2237 = &l_2238;
        int32_t *l_2259 = &l_1801;
        uint32_t l_2318[2][1];
        uint16_t *** const l_2344 = &l_1936[0];
        int8_t l_2396[3][7];
        uint8_t l_2403 = 0x60L;
        uint32_t l_2405 = 1UL;
        uint16_t l_2412 = 1UL;
        int64_t ** const **l_2441 = &g_2439;
        uint16_t l_2454 = 0UL;
        int64_t ***l_2457 = &g_2440;
        int64_t ****l_2456 = &l_2457;
        int64_t *****l_2455 = &l_2456;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2200[i] = (void*)0;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 1; j++)
                l_2318[i][j] = 0xD5390567L;
        }
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 7; j++)
                l_2396[i][j] = 0x57L;
        }
        for (g_2015 = (-1); (g_2015 <= (-23)); g_2015 = safe_sub_func_uint32_t_u_u_unsafe_macro/*161*//* ___SAFE__OP */(g_2015, 7))
        { /* block id: 863 */
            int16_t l_2109 = 0xCE87L;
            const int32_t *l_2110[1][8] = {{&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2],&l_2096[9][2][2]}};
            int32_t l_2113 = 7L;
            uint32_t ***l_2136 = &g_870;
            int32_t l_2193 = 0xB3361137L;
            int32_t l_2195 = (-6L);
            int32_t l_2196[6][2][10] = {{{(-1L),0x6518E0F1L,0xF657656BL,0xF657656BL,0x6518E0F1L,0x049135EBL,0L,8L,0L,(-5L)},{0L,5L,0xE7D17986L,0x86555306L,1L,(-2L),3L,0x96BB89ABL,5L,0x9F85BA15L}},{{0L,8L,0x2FDBB40EL,1L,0xE27D96E1L,0x049135EBL,0x9F85BA15L,0xA88F9101L,6L,(-6L)},{0x049135EBL,0x9F85BA15L,0xA88F9101L,6L,(-6L),1L,0xF63A8A1EL,1L,0x39DBEE95L,0xE7D17986L}},{{5L,0x6518E0F1L,0xA315F8C5L,1L,0L,0xE157C2C3L,0xA88F9101L,5L,0xA88F9101L,0xE157C2C3L},{0x5A52AC1FL,0x72016991L,0L,0x72016991L,0x5A52AC1FL,3L,0x86555306L,0x65EEE903L,(-1L),0L}},{{(-6L),0xE27D96E1L,1L,(-3L),0x4618E0DBL,0L,0x36686972L,(-1L),0x2FDBB40EL,0L},{1L,(-3L),3L,(-5L),0x5A52AC1FL,6L,0L,(-1L),0L,0xE157C2C3L}},{{0x6518E0F1L,(-6L),0L,0xA315F8C5L,0L,(-2L),(-5L),0x9F85BA15L,(-6L),0xE7D17986L},{0xA88F9101L,(-1L),0x2FDBB40EL,0L,(-6L),8L,0xE7D17986L,0xE7D17986L,8L,(-6L)}},{{1L,0x39DBEE95L,0x39DBEE95L,1L,0xE27D96E1L,0x65EEE903L,0xF63A8A1EL,0x049135EBL,0xE7D17986L,0x9F85BA15L},{0xF63A8A1EL,0L,0xE157C2C3L,1L,1L,0xDF17B991L,0x39DBEE95L,0xF63A8A1EL,0xE7D17986L,(-5L)}}};
            int8_t **l_2202 = &g_407;
            uint64_t *l_2256[5][4][1] = {{{&g_171},{&g_137[2]},{&g_171},{&g_137[2]}},{{&g_171},{&g_137[2]},{&g_171},{&g_137[2]}},{{&g_171},{&g_137[2]},{&g_171},{&g_137[2]}},{{&g_171},{&g_137[2]},{&g_171},{&g_137[2]}},{{&g_171},{&g_137[2]},{&g_171},{&g_137[2]}}};
            int64_t l_2278 = 0x594B47D9F2BB8E24LL;
            uint64_t l_2319 = 0x79FBAD1F152F30E8LL;
            int8_t **** const *l_2342[8];
            uint16_t *** const l_2343 = &l_1936[4];
            int64_t **l_2357[5][5] = {{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042},{&g_2042,&g_2042,&g_2042,&g_2042,&g_2042}};
            int16_t *l_2404 = &g_1257;
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_2342[i] = &l_2036;
            for (g_287 = 0; (g_287 == 35); g_287 = safe_add_func_int64_t_s_s_unsafe_macro/*162*//* ___SAFE__OP */(g_287, 8))
            { /* block id: 866 */
                int32_t l_2070 = 0x71ECAD8AL;
                const uint16_t l_2095 = 0xD518L;
                uint64_t ***l_2101 = &g_318;
                uint64_t ****l_2100 = &l_2101;
                uint64_t ****l_2104 = &l_2101;
                int32_t l_2123 = 9L;
                int32_t l_2137 = 0x0B1CEBF1L;
                for (p_16 = 28; (p_16 > 29); p_16++)
                { /* block id: 869 */
                    int64_t l_2080 = 0x13E210FE88C64E05LL;
                    uint64_t *****l_2103[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    const int32_t *l_2108 = &l_1554;
                    int i;
                    for (l_1840 = 23; (l_1840 >= 38); l_1840 = safe_add_func_int64_t_s_s_unsafe_macro/*163*//* ___SAFE__OP */(l_1840, 7))
                    { /* block id: 872 */
                        int16_t l_2090[6] = {0L,0L,0L,0L,0L,0L};
                        int16_t *l_2092 = (void*)0;
                        int16_t *l_2093 = (void*)0;
                        int16_t *l_2094 = &g_1257;
                        int16_t *l_2097 = &l_2090[0];
                        int i;
                        if (l_1791)
                            goto lbl_2065;
                        if ((*g_89))
                            continue;
                        (*p_15) &= (safe_mul_func_int8_t_s_s_unsafe_macro/*164*//* ___SAFE__OP */((((*l_2097) = ((safe_div_func_int8_t_s_s_unsafe_macro/*165*//* ___SAFE__OP */(l_2070, (safe_rshift_func_uint16_t_u_s_unsafe_macro/*166*//* ___SAFE__OP */(p_16, (safe_mod_func_int32_t_s_s_unsafe_macro/*167*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*168*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s_unsafe_macro/*169*//* ___SAFE__OP */(((***g_1412) = (safe_sub_func_int16_t_s_s_unsafe_macro/*170*//* ___SAFE__OP */(((*l_2094) &= (((l_2080 , (!(!0xD039BDA2323E03BDLL))) && ((safe_sub_func_uint16_t_u_u_unsafe_macro/*171*//* ___SAFE__OP */(p_16, ((l_2091 ^= ((*g_1393) < (((l_2070 && (+(((safe_lshift_func_int32_t_s_u_unsafe_macro/*172*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */(18446744073709551615UL, 18446744073709551615UL)), 9)) | l_2080) || l_2070))) == (**g_406)) == l_2090[0]))) || g_85))) && 65527UL)) | 0x0F59EF0FD54890C5LL)), l_2095))))), l_2096[9][2][2])), p_16)))))) != l_2096[7][0][0])) & p_16), g_28));
                    }
                    if ((*p_15))
                        break;
                    if (((safe_mul_func_int16_t_s_s_unsafe_macro/*174*//* ___SAFE__OP */((0L >= (l_2100 != (l_2104 = g_2102))), ((safe_rshift_func_uint16_t_u_u_unsafe_macro/*175*//* ___SAFE__OP */((~((p_16 , &g_1257) == (l_2091 , l_2111))), 8)) < (-5L)))) != (*g_111)))
                    { /* block id: 884 */
                        int64_t *l_2112[7][1][7] = {{{(void*)0,(void*)0,(void*)0,&l_1567[1],&l_1567[1],(void*)0,(void*)0}},{{&l_1567[1],(void*)0,&g_1235,&g_1235,(void*)0,&l_1567[1],(void*)0}},{{(void*)0,&l_1567[1],&l_1567[1],&g_1235,&g_341,&g_1235,(void*)0}},{{&l_1567[1],&l_1567[1],(void*)0,(void*)0,(void*)0,&l_1567[1],&l_1567[1]}},{{&l_1567[1],(void*)0,(void*)0,(void*)0,&l_1567[1],&l_1567[1],(void*)0}},{{&g_1235,&g_341,&g_1235,(void*)0,(void*)0,&g_1235,&g_341}},{{(void*)0,&g_341,(void*)0,(void*)0,&g_341,(void*)0,&g_341}}};
                        int32_t l_2138 = (-10L);
                        const int32_t l_2139[5] = {0x2B99FC1EL,0x2B99FC1EL,0x2B99FC1EL,0x2B99FC1EL,0x2B99FC1EL};
                        int i, j, k;
                        (*p_15) = (((((***g_1488) = (g_60 != ((((l_2113 = 0xE69169918EBFFDF3LL) <= ((safe_lshift_func_uint8_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */((((l_2138 |= (l_2137 = ((l_2095 , (void*)0) == (((+(((safe_sub_func_int64_t_s_s_unsafe_macro/*177*//* ___SAFE__OP */(0xF771CE5F8FBA9384LL, ((safe_sub_func_uint64_t_u_u_unsafe_macro/*178*//* ___SAFE__OP */(p_16, (safe_add_func_int16_t_s_s_unsafe_macro/*179*//* ___SAFE__OP */(((l_2123 = 0x3F08FC61AAA60A44LL) > ((((*g_407) = (((((safe_sub_func_uint16_t_u_u_unsafe_macro/*180*//* ___SAFE__OP */(((((safe_sub_func_int32_t_s_s_unsafe_macro/*181*//* ___SAFE__OP */((+(safe_add_func_uint16_t_u_u_unsafe_macro/*182*//* ___SAFE__OP */((!(***g_1488)), ((safe_sub_func_int16_t_s_s_unsafe_macro/*183*//* ___SAFE__OP */((((safe_sub_func_int64_t_s_s_unsafe_macro/*184*//* ___SAFE__OP */(l_2096[1][1][1], p_16)) == 1UL) ^ p_16), l_2096[9][2][2])) | 0x1B7EE374711465B8LL)))), p_16)) < p_16) > (*l_2108)) || 0x50B949C1FDCDBBA9LL), p_16)) | 1L) , p_16) < 0xE8C6L) | 0L)) & 252UL) && l_2070)), 65528UL)))) & 0xC8L))) > 3UL) <= (-5L))) , 65527UL) , l_2136)))) > p_16) > l_2139[0]), 4)) & (*g_89))) | l_2070) == 255UL))) , p_16) != 0x34FBEAF778B42E63LL) ^ 0x5C472DC2L);
                    }
                    else
                    { /* block id: 892 */
                        if (l_1554)
                            goto lbl_1710;
                    }
                }
                if ((safe_mod_func_uint8_t_u_u_unsafe_macro/*185*//* ___SAFE__OP */(((safe_div_func_int32_t_s_s_unsafe_macro/*186*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */(((void*)0 == (**g_1412)), ((((*p_15) = ((((--(**g_1489)) & (((safe_lshift_func_int16_t_s_s_unsafe_macro/*188*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_s_unsafe_macro/*189*//* ___SAFE__OP */((**g_1413), 6)), 4)) ^ (!p_16)) < (safe_mul_func_uint8_t_u_u_unsafe_macro/*190*//* ___SAFE__OP */((!(((void*)0 == (*g_1488)) , p_16)), (p_16 <= (((p_16 < l_2156) >= p_16) < g_567)))))) != 0x5322A15BL) , (*p_15))) ^ l_2157) & l_2137))), l_2070)) ^ l_2096[1][1][2]), (**g_406))))
                { /* block id: 898 */
                    int32_t *l_2158 = &l_2113;
                    int32_t *l_2159 = &l_1802[0][4];
                    int32_t *l_2160 = (void*)0;
                    int32_t *l_2161 = &l_2096[9][2][2];
                    int32_t *l_2162 = &g_88[3][0][1];
                    int32_t *l_2163 = (void*)0;
                    int32_t *l_2164 = (void*)0;
                    int32_t *l_2165 = (void*)0;
                    int32_t *l_2166 = (void*)0;
                    int32_t *l_2167[8] = {&l_1802[5][3],&l_1802[5][3],&l_1802[5][3],&l_1802[5][3],&l_1802[5][3],&l_1802[5][3],&l_1802[5][3],&l_1802[5][3]};
                    int i;
                    (*p_15) ^= (*p_17);
                    ++l_2168;
                }
                else
                { /* block id: 901 */
                    int32_t *l_2171 = &l_1554;
                    int32_t *l_2172[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_2172[i] = &l_2096[7][2][3];
                    l_2173++;
                }
                for (l_1555 = 5; (l_1555 < 38); l_1555++)
                { /* block id: 906 */
                    int32_t *l_2180[4][1];
                    uint16_t l_2197 = 0UL;
                    int i, j;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_2180[i][j] = &l_1802[8][3];
                    }
                    for (l_1840 = 13; (l_1840 == 1); l_1840--)
                    { /* block id: 909 */
                        int32_t *l_2181 = &l_1554;
                        return g_2182;
                    }
                    (*g_1893) ^= (safe_add_func_int8_t_s_s_unsafe_macro/*191*//* ___SAFE__OP */((l_2096[4][0][2] ^= (((safe_lshift_func_int8_t_s_u_unsafe_macro/*192*//* ___SAFE__OP */((-1L), 7)) <= p_16) == (g_1543[1][0] = (((safe_sub_func_int8_t_s_s_unsafe_macro/*193*//* ___SAFE__OP */(p_16, p_16)) != ((safe_sub_func_int64_t_s_s_unsafe_macro/*194*//* ___SAFE__OP */(p_16, (safe_mod_func_int8_t_s_s_unsafe_macro/*195*//* ___SAFE__OP */((0xBE71L && g_60), 0x49L)))) < 0x9943558FL)) < 6L)))), p_16));
                    if ((*p_17))
                        continue;
                    ++l_2197;
                }
                return l_2200[0];
            }
            if (((((((*g_407) = (((l_2202 = l_2201) != (void*)0) , ((l_2203 = l_2201) == l_2201))) ^ (l_2204[0] == (void*)0)) != 0UL) | p_16) , ((safe_add_func_int16_t_s_s_unsafe_macro/*196*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*197*//* ___SAFE__OP */(g_1236[8], p_16)) , p_16), p_16)) & p_16)))
            { /* block id: 923 */
                uint16_t l_2209 = 1UL;
                l_2209--;
            }
            else
            { /* block id: 925 */
                const int8_t ***l_2216 = &g_568;
                int32_t l_2218[10][8] = {{0x6018D4EDL,(-1L),0L,0L,0xAAFBF82AL,0xAAFBF82AL,0L,0L},{0x2C6369A8L,0x2C6369A8L,0L,(-3L),0L,0x675F40BEL,7L,0x2C6369A8L},{(-1L),0x6018D4EDL,1L,0xAAFBF82AL,7L,1L,0L,0x2C6369A8L},{0x6018D4EDL,9L,(-1L),(-3L),(-1L),9L,0x6018D4EDL,0L},{5L,(-3L),0x8794D380L,0L,(-3L),7L,7L,5L},{7L,5L,0xAAFBF82AL,9L,(-3L),1L,1L,(-3L)},{5L,0L,0L,5L,(-1L),7L,0x2C6369A8L,9L},{0x6018D4EDL,0x2C6369A8L,0x29969301L,0L,7L,0L,0L,0x6018D4EDL},{(-1L),0x2C6369A8L,0xAAFBF82AL,7L,0L,7L,0xAAFBF82AL,0x2C6369A8L},{0x2C6369A8L,0L,1L,7L,0xAAFBF82AL,1L,0x6018D4EDL,(-1L)}};
                int32_t *l_2257[5] = {&l_2218[3][5],&l_2218[3][5],&l_2218[3][5],&l_2218[3][5],&l_2218[3][5]};
                int16_t *l_2279 = &l_2157;
                int i, j;
                for (l_2034 = 0; (l_2034 == 37); l_2034++)
                { /* block id: 928 */
                    uint32_t l_2217[3];
                    uint32_t *l_2227 = &g_85;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2217[i] = 0x9FA1FB9FL;
                    if (((safe_sub_func_uint16_t_u_u_unsafe_macro/*198*//* ___SAFE__OP */(p_16, ((*g_1154) = p_16))) || ((*p_15) = ((*p_15) | (l_2218[3][5] = (l_2216 == ((l_2217[0] & p_16) , l_2216)))))))
                    { /* block id: 932 */
                        uint32_t l_2234 = 4UL;
                        if (g_786)
                            goto lbl_1710;
                        (*p_15) |= (safe_mul_func_uint8_t_u_u_unsafe_macro/*199*//* ___SAFE__OP */((((safe_rshift_func_uint32_t_u_u_unsafe_macro/*200*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_s_unsafe_macro/*201*//* ___SAFE__OP */(((*l_2227) = (safe_div_func_uint32_t_u_u_unsafe_macro/*202*//* ___SAFE__OP */(((l_2227 != ((+(++g_67)) , l_2227)) <= p_16), ((*g_111) |= (g_1628 != ((((safe_rshift_func_int64_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(((((7UL | 0x47L) , l_2237) != &g_1488) | p_16), 2)) , 0UL) , 0x6EB6ECB9L) , (*g_569))))))), 14)), 28)) > p_16) < l_2234), p_16));
                        (*p_17) = ((void*)0 != &g_996);
                    }
                    else
                    { /* block id: 939 */
                        int32_t *l_2258 = &l_2195;
                        (*p_15) = (safe_unary_minus_func_uint8_t_u_unsafe_macro/*204*//* ___SAFE__OP */((g_1628 > (safe_sub_func_int32_t_s_s_unsafe_macro/*205*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*206*//* ___SAFE__OP */((p_16 <= 1L), ((p_16 >= p_16) || (0x2DL >= (((safe_div_func_uint32_t_u_u_unsafe_macro/*207*//* ___SAFE__OP */(((*g_111) = (((~(safe_sub_func_uint64_t_u_u_unsafe_macro/*208*//* ___SAFE__OP */((p_16 > (safe_add_func_uint16_t_u_u_unsafe_macro/*209*//* ___SAFE__OP */((((safe_mod_func_uint32_t_u_u_unsafe_macro/*210*//* ___SAFE__OP */((((((*g_2182) = (g_806[1] || (((l_2255 & p_16) , 0xE7L) < g_83))) , p_16) == 7UL) != p_16), (*g_111))) , (*g_1489)) == l_2256[2][2][0]), l_2218[1][1]))), 0UL))) & p_16) <= p_16)), (*p_15))) != p_16) || g_1785))))), 0L)))));
                        return l_2227;
                    }
                }
                (*l_2259) = ((((*l_2202) = (*l_2201)) == (void*)0) && ((*p_15) = (safe_add_func_uint8_t_u_u_unsafe_macro/*211*//* ___SAFE__OP */((0xDFA351E9FAC84427LL ^ (g_1235 = ((((6L || (l_2196[3][1][5] = ((*l_2279) = ((*g_111) | (safe_sub_func_int64_t_s_s_unsafe_macro/*212*//* ___SAFE__OP */((+65529UL), ((l_2195 = (((+(+0L)) , (safe_mod_func_uint64_t_u_u_unsafe_macro/*213*//* ___SAFE__OP */((!(safe_mod_func_int64_t_s_s_unsafe_macro/*214*//* ___SAFE__OP */(((g_1155 == ((safe_mod_func_uint32_t_u_u_unsafe_macro/*215*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*216*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*217*//* ___SAFE__OP */((((*l_2259) ^ l_2278) <= (***g_1488)), p_16)), p_16)), (*l_2259))) ^ p_16)) , p_16), p_16))), (*l_2259)))) <= p_16)) | p_16))))))) , &l_2020) == (void*)0) <= g_1257))), 0x0CL))));
                (*l_2259) = (((+((*l_2279) = (*l_2259))) == (g_1235 = p_16)) ^ p_16);
                for (l_2195 = 0; (l_2195 >= 13); l_2195 = safe_add_func_uint32_t_u_u_unsafe_macro/*218*//* ___SAFE__OP */(l_2195, 9))
                { /* block id: 958 */
                    uint16_t l_2302 = 1UL;
                    uint32_t l_2305 = 0UL;
                    int8_t l_2320 = (-9L);
                    uint32_t l_2321 = 0xEC54E835L;
                    int32_t l_2345 = 0x586A2C61L;
                    int8_t l_2370 = 9L;
                    for (g_284 = (-29); (g_284 < 8); ++g_284)
                    { /* block id: 961 */
                        int64_t l_2304[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                        int32_t l_2306 = 0L;
                        int i;
                        (*p_15) = (safe_mod_func_int16_t_s_s_unsafe_macro/*219*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */((!((safe_div_func_int16_t_s_s_unsafe_macro/*221*//* ___SAFE__OP */(((l_2306 = ((safe_div_func_uint32_t_u_u_unsafe_macro/*222*//* ___SAFE__OP */(((((*l_2259) <= (safe_add_func_int16_t_s_s_unsafe_macro/*223*//* ___SAFE__OP */(p_16, g_28))) < (*g_1893)) , 0x890E5A55L), (*g_111))) > (safe_add_func_uint64_t_u_u_unsafe_macro/*224*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*225*//* ___SAFE__OP */(0L, p_16)), (((l_2305 ^= (((safe_lshift_func_int64_t_s_u_unsafe_macro/*226*//* ___SAFE__OP */((((g_443 == 0x8CL) != (**g_1661)) > (*g_111)), l_2302)) == g_2303) | l_2304[5])) , l_2304[0]) & 0x30D6L))))) & 0UL), p_16)) && p_16)), 0x2175DF495F0EC319LL)), p_16));
                    }
                    if (((safe_lshift_func_int64_t_s_u_unsafe_macro/*227*//* ___SAFE__OP */((((safe_div_func_uint8_t_u_u_unsafe_macro/*228*//* ___SAFE__OP */((((safe_div_func_int32_t_s_s_unsafe_macro/*229*//* ___SAFE__OP */((((255UL ^ ((safe_div_func_uint32_t_u_u_unsafe_macro/*230*//* ___SAFE__OP */(6UL, (((-1L) | (((4294967288UL ^ ((*g_111) ^ (safe_sub_func_int8_t_s_s_unsafe_macro/*231*//* ___SAFE__OP */(l_2305, ((p_16 , ((safe_unary_minus_func_uint8_t_u_unsafe_macro/*232*//* ___SAFE__OP */((l_2318[1][0] != 1L))) , 0xB43999707C91B964LL)) || l_2319))))) & l_2320) < g_28)) & (*l_2259)))) , 0xA3L)) , l_2321) > (*g_1393)), p_16)) >= l_2321) && p_16), 0x5EL)) , g_114) <= g_998), p_16)) > (*g_1490)))
                    { /* block id: 966 */
                        int64_t ***l_2356 = &l_2355;
                        int64_t ***l_2358 = &l_2357[3][1];
                        int32_t l_2359 = (-9L);
                        (**g_1350) = ((***l_1706) = &p_16);
                        g_995 = &g_996;
                        (*g_177) = (((safe_sub_func_int64_t_s_s_unsafe_macro/*233*//* ___SAFE__OP */((l_2196[2][0][3] ^= (safe_lshift_func_uint32_t_u_s_unsafe_macro/*234*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*235*//* ___SAFE__OP */((-1L), (safe_add_func_uint8_t_u_u_unsafe_macro/*236*//* ___SAFE__OP */((l_2359 = (safe_unary_minus_func_int8_t_s_unsafe_macro/*237*//* ___SAFE__OP */((((*l_2356) = l_2355) == ((*l_2358) = l_2357[0][1]))))), 0xE0L)))), (safe_sub_func_int8_t_s_s_unsafe_macro/*238*//* ___SAFE__OP */(((**g_1413) = (safe_lshift_func_uint8_t_u_s_unsafe_macro/*239*//* ___SAFE__OP */((g_1543[2][0] = (l_2345 = g_83)), ((void*)0 == &g_1815)))), (safe_lshift_func_int64_t_s_u_unsafe_macro/*240*//* ___SAFE__OP */(((((safe_rshift_func_int64_t_s_s_unsafe_macro/*241*//* ___SAFE__OP */((g_1017 <= ((safe_lshift_func_int64_t_s_u_unsafe_macro/*242*//* ___SAFE__OP */(l_2370, (***g_1488))) < 0x5905L)), 8)) & g_5) , l_2305) != (***l_1707)), 6))))))), (****l_1706))) | 0xA31828E5BDD3720ALL) || p_16);
                        (*p_15) |= ((****l_1706) &= (((*g_1154) &= 0x34AFL) ^ g_6));
                    }
                    else
                    { /* block id: 986 */
                        int32_t * const l_2378 = &g_2379;
                        int32_t * const *l_2377[3][4] = {{&l_2378,&l_2378,&l_2378,&l_2378},{&l_2378,&l_2378,&l_2378,&l_2378},{&l_2378,&l_2378,&l_2378,&l_2378}};
                        int32_t * const **l_2376 = &l_2377[1][2];
                        int16_t * const l_2380 = (void*)0;
                        int i, j;
                        (***l_1706) = &p_16;
                        (**g_1350) = &p_16;
                        (*g_2182) ^= (safe_div_func_uint16_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */((((***g_1660) = ((safe_mul_func_uint8_t_u_u_unsafe_macro/*244*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*245*//* ___SAFE__OP */((((***g_1488) = p_16) != (p_16 && (safe_mul_func_int32_t_s_s_unsafe_macro/*246*//* ___SAFE__OP */((**l_1708), ((safe_mul_func_int8_t_s_s_unsafe_macro/*247*//* ___SAFE__OP */((p_16 & ((*p_17) != ((((safe_rshift_func_uint32_t_u_s_unsafe_macro/*248*//* ___SAFE__OP */((+((*g_659) == (*g_659))), ((((*l_2279) = 0x07EFL) , (**l_1708)) & 0xDE836DC6A69412CBLL))) , p_16) , (void*)0) != l_2342[4]))), (*l_2259))) || g_931))))), l_2396[0][1])), 0x8EL)) > 0xEDAD46FEL)) > p_16), (-8L)));
                    }
                }
            }
            if ((safe_rshift_func_int32_t_s_s_unsafe_macro/*249*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*250*//* ___SAFE__OP */((((p_16 | (((*l_2404) &= (safe_mod_func_uint32_t_u_u_unsafe_macro/*251*//* ___SAFE__OP */(l_2403, (*g_111)))) <= 65526UL)) | (((l_2412 ^= ((((((-7L) || (0UL != (((l_2405 != ((*p_15) ^ (((l_2195 = (safe_mod_func_int64_t_s_s_unsafe_macro/*252*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*253*//* ___SAFE__OP */(((**l_2202) = p_16), p_16)), p_16))) , &g_111) != (void*)0))) & 0xFBB3L) , 0xB0DAL))) <= p_16) >= g_88[3][0][1]) || g_1543[2][0]) , (*l_2259))) != 0x0FL) & g_1543[2][0])) < 0x7AD0L), 0x78L)), 7)))
            { /* block id: 1001 */
                int32_t *l_2413 = &g_88[3][0][1];
                return l_2413;
            }
            else
            { /* block id: 1003 */
                uint8_t l_2418 = 0x45L;
                int32_t l_2431 = 0L;
                for (g_81 = 0; (g_81 == 42); ++g_81)
                { /* block id: 1006 */
                    int8_t l_2416 = 0x25L;
                    int32_t l_2417 = 0x9D5758CBL;
                    ++l_2418;
                    if (l_1554)
                        goto lbl_1710;
                    (*g_1893) = (l_2418 > (!((0x67L & (+(-9L))) < (safe_add_func_int16_t_s_s_unsafe_macro/*254*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*255*//* ___SAFE__OP */(((0x9D347E2736077C86LL != ((safe_div_func_int8_t_s_s_unsafe_macro/*256*//* ___SAFE__OP */(((((((-8L) == (*p_17)) | ((*l_2259) | 0UL)) >= (((**g_1489)--) < (safe_unary_minus_func_int32_t_s_unsafe_macro/*257*//* ___SAFE__OP */((!(&l_2157 != &g_1257)))))) >= 1UL) == g_1384[3][1][0]), (*g_407))) , (***g_1488))) != l_2418), p_16)) == p_16), g_1289)))));
                }
                for (g_85 = 0; (g_85 == 54); g_85 = safe_add_func_uint16_t_u_u_unsafe_macro/*258*//* ___SAFE__OP */(g_85, 1))
                { /* block id: 1014 */
                    int16_t l_2438 = 0xD1E5L;
                    (*p_17) = l_2438;
                }
                if ((*p_17))
                    continue;
            }
        }
        (*g_1893) |= (0x064E3A06L < (&l_2204[0] == ((*l_2441) = g_2439)));
        (*g_1893) = (p_16 & ((((((((0xE0DAC560824BB56BLL <= 0UL) || ((*g_2439) != l_2355)) && ((*l_2259) <= ((safe_rshift_func_uint16_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */(0x8463L, 13)) & 0xCEF7A8F38F9629D7LL))) , ((g_1543[3][0] = (safe_unary_minus_func_uint32_t_u_unsafe_macro/*260*//* ___SAFE__OP */(((~((safe_add_func_int32_t_s_s_unsafe_macro/*261*//* ___SAFE__OP */(((((l_2454 = (((safe_rshift_func_int8_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */((p_16 >= 65531UL), 6)) < 1L) > 0x27L)) >= (-2L)) || (*g_111)) & (*p_15)), p_16)) & 0UL)) & 7L)))) <= g_171)) | 1L) >= 0xF6L) && 255UL) <= (-1L)));
        (*g_2182) ^= (((((*l_2455) = (void*)0) != (((*g_111) = (~(safe_lshift_func_uint16_t_u_s_unsafe_macro/*263*//* ___SAFE__OP */((p_16 != p_16), 0)))) , &g_2439)) <= ((*g_407) ^= p_16)) , 0xF7AC2FCEL);
    }
    else
    { /* block id: 1029 */
        int64_t ***l_2469 = &l_2355;
        int64_t ****l_2468 = &l_2469;
        int8_t *l_2470[5];
        int32_t l_2471 = (-2L);
        int32_t l_2474 = 0xFAAC1D25L;
        int16_t *l_2477 = &g_1257;
        uint64_t * const *l_2485 = &g_1490;
        uint64_t * const **l_2484[9][7] = {{&l_2485,&l_2485,(void*)0,&l_2485,(void*)0,&l_2485,&l_2485},{(void*)0,&l_2485,&l_2485,&l_2485,&l_2485,(void*)0,&l_2485},{&l_2485,&l_2485,&l_2485,&l_2485,&l_2485,&l_2485,&l_2485},{&l_2485,&l_2485,&l_2485,&l_2485,(void*)0,&l_2485,&l_2485},{(void*)0,&l_2485,(void*)0,&l_2485,&l_2485,&l_2485,(void*)0},{&l_2485,&l_2485,&l_2485,&l_2485,&l_2485,(void*)0,&l_2485},{(void*)0,&l_2485,&l_2485,&l_2485,&l_2485,&l_2485,(void*)0},{(void*)0,&l_2485,&l_2485,(void*)0,(void*)0,&l_2485,&l_2485},{(void*)0,&l_2485,&l_2485,&l_2485,(void*)0,&l_2485,(void*)0}};
        uint64_t * const ***l_2483 = &l_2484[3][4];
        uint64_t * const ****l_2486 = &l_2483;
        uint16_t l_2490 = 8UL;
        int32_t ***l_2491 = &g_1577;
        int32_t l_2592 = (-1L);
        int32_t l_2593 = 0xBC48ACFCL;
        int32_t l_2596[5] = {0x5AA96141L,0x5AA96141L,0x5AA96141L,0x5AA96141L,0x5AA96141L};
        uint32_t l_2632 = 0xA03C9D26L;
        int8_t ****l_2634 = &g_1423[4][0][0];
        int64_t l_2697 = 0xA70B08318785BF4ELL;
        uint8_t l_2698 = 0x66L;
        int i, j;
        for (i = 0; i < 5; i++)
            l_2470[i] = &g_114;
        (*p_15) = ((safe_unary_minus_func_int64_t_s_unsafe_macro/*264*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*265*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*266*//* ___SAFE__OP */((*p_17), (((**g_1489) = (((p_16 < ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*267*//* ___SAFE__OP */(((void*)0 == l_2468), ((l_2471 = ((**g_1412) != l_2470[4])) | (((*l_2477) = (((safe_div_func_int64_t_s_s_unsafe_macro/*268*//* ___SAFE__OP */(l_2474, (safe_add_func_int16_t_s_s_unsafe_macro/*269*//* ___SAFE__OP */(0x8F99L, l_2474)))) < 0x51L) ^ l_2474)) < 0UL)))) , 0xAAL)) ^ 0x43L) | (*g_111))) , (*p_17)))), l_2474)))) & l_2474);
        for (g_106 = 3; (g_106 > (-8)); g_106--)
        { /* block id: 1036 */
            int32_t *l_2482[6][5] = {{&l_1801,&l_1801,&g_88[0][0][1],&l_1801,&l_1801},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1801,&l_2471,&l_2471,&l_1801,&l_2471},{(void*)0,(void*)0,&g_88[0][0][0],(void*)0,(void*)0},{&l_2471,&l_1801,&l_2471,&l_2471,&l_1801},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            int i, j;
            (*p_17) ^= (safe_rshift_func_uint64_t_u_u_unsafe_macro/*270*//* ___SAFE__OP */((l_2482[1][1] == (void*)0), 31));
        }
        g_2487 = ((*l_2486) = l_2483);
        if (((*p_17) = (((*l_2491) = (l_2490 , &g_997[1][3][2])) == l_1578)))
        { /* block id: 1043 */
            uint8_t l_2502 = 0UL;
            int32_t **l_2544 = &g_997[1][3][2];
            uint32_t l_2546 = 4294967294UL;
            int32_t l_2547 = (-1L);
            int64_t ***l_2548[5] = {&g_2440,&g_2440,&g_2440,&g_2440,&g_2440};
            uint64_t * const ** const *l_2564 = &l_2484[3][4];
            uint64_t * const ** const **l_2563 = &l_2564;
            int32_t l_2589[10];
            uint64_t l_2598 = 1UL;
            int32_t l_2633 = 0L;
            int32_t ***l_2640[2][4][1] = {{{&l_1708},{&l_1708},{&l_1708},{&l_1708}},{{&l_1708},{&l_1708},{&l_1708},{&l_1708}}};
            int i, j, k;
            for (i = 0; i < 10; i++)
                l_2589[i] = 0x71E82C1CL;
            if (((safe_mul_func_uint16_t_u_u_unsafe_macro/*271*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*272*//* ___SAFE__OP */(((safe_unary_minus_func_uint64_t_u_unsafe_macro/*273*//* ___SAFE__OP */((((safe_add_func_uint16_t_u_u_unsafe_macro/*274*//* ___SAFE__OP */(65532UL, (safe_rshift_func_uint16_t_u_u_unsafe_macro/*275*//* ___SAFE__OP */((((safe_lshift_func_int32_t_s_u_unsafe_macro/*276*//* ___SAFE__OP */((l_2502 == ((safe_mul_func_uint16_t_u_u_unsafe_macro/*277*//* ___SAFE__OP */(((+(safe_sub_func_int8_t_s_s_unsafe_macro/*278*//* ___SAFE__OP */(((**l_2203) = (safe_mod_func_int8_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u_unsafe_macro/*280*//* ___SAFE__OP */((l_2547 = ((safe_mul_func_uint64_t_u_u_unsafe_macro/*281*//* ___SAFE__OP */((safe_unary_minus_func_uint16_t_u_unsafe_macro/*282*//* ___SAFE__OP */((((((safe_lshift_func_int8_t_s_s_unsafe_macro/*283*//* ___SAFE__OP */((safe_unary_minus_func_uint32_t_u_unsafe_macro/*284*//* ___SAFE__OP */(p_16)), (safe_rshift_func_uint32_t_u_u_unsafe_macro/*285*//* ___SAFE__OP */(((*g_1393) | ((safe_add_func_uint8_t_u_u_unsafe_macro/*286*//* ___SAFE__OP */((!l_2490), (safe_mul_func_int16_t_s_s_unsafe_macro/*287*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u_unsafe_macro/*288*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*289*//* ___SAFE__OP */(((((safe_lshift_func_int16_t_s_u_unsafe_macro/*290*//* ___SAFE__OP */(((((((((safe_mul_func_int16_t_s_s_unsafe_macro/*291*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*292*//* ___SAFE__OP */(((((safe_lshift_func_int32_t_s_s_unsafe_macro/*293*//* ___SAFE__OP */(((((*g_1154) &= p_16) & (((safe_lshift_func_int64_t_s_u_unsafe_macro/*294*//* ___SAFE__OP */(p_16, ((((safe_unary_minus_func_uint32_t_u_unsafe_macro/*295*//* ___SAFE__OP */(p_16)) > (safe_rshift_func_int16_t_s_s_unsafe_macro/*296*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u_unsafe_macro/*297*//* ___SAFE__OP */((((*l_2491) = l_2544) == l_2545[1]), g_2303)) & p_16), 0))) != 0xBF13L) & 0x05L))) , l_2490) <= p_16)) , 0x8F5F6ED7L), 31)) >= (*p_17)) >= p_16) , l_2546), l_2546)), p_16)) | g_81) , g_81) != l_2502) , p_16) ^ 0x2B50L) <= l_2546) != l_2502), 2)) <= 0x91B5L) , (***g_1660)) < p_16), p_16)), p_16)) <= 0x7C1D4F01L), p_16)))) == p_16)), (*g_111))))) , 0UL) , l_2474) >= p_16) == 0x97AC926C9FB80EC7LL))), l_2546)) , 0x912EL)), p_16)) , 0xADL), p_16))), p_16))) >= l_2546), l_2490)) < l_2502)), p_16)) , l_2548[3]) != &g_2041), l_2546)))) >= p_16) > 0x128CL))) , l_2547))), p_16)) > 0x738E62D122FA7A02LL))
            { /* block id: 1048 */
                uint64_t l_2562[5][3] = {{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0xF0F8FE2A914BF0CFLL,0xF0F8FE2A914BF0CFLL,0xF0F8FE2A914BF0CFLL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0xF0F8FE2A914BF0CFLL,0xF0F8FE2A914BF0CFLL,0xF0F8FE2A914BF0CFLL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL}};
                uint16_t l_2565 = 8UL;
                int32_t l_2594 = 1L;
                int32_t l_2595 = 0x543BEB71L;
                int32_t l_2597 = (-6L);
                int i, j;
                if (g_567)
                    goto lbl_1710;
                for (g_341 = 0; (g_341 <= 5); ++g_341)
                { /* block id: 1052 */
                    uint64_t l_2570 = 8UL;
                    int32_t l_2591[7] = {7L,(-1L),(-1L),7L,(-1L),(-1L),7L};
                    int i;
                    (*g_1893) = (safe_rshift_func_uint8_t_u_s_unsafe_macro/*298*//* ___SAFE__OP */((((void*)0 == &g_1488) , ((safe_add_func_uint32_t_u_u_unsafe_macro/*299*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*300*//* ___SAFE__OP */((p_16 ^ p_16), (*g_111))), (((safe_rshift_func_int32_t_s_u_unsafe_macro/*301*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*302*//* ___SAFE__OP */(((**g_1413) = l_2490), (safe_unary_minus_func_int8_t_s_unsafe_macro/*303*//* ___SAFE__OP */(l_2562[1][2])))), (&g_2487 == l_2563))) == p_16) | 0xBFL))) || l_2565)), 0));
                    if (((((safe_sub_func_int32_t_s_s_unsafe_macro/*304*//* ___SAFE__OP */((((((safe_mul_func_int8_t_s_s_unsafe_macro/*305*//* ___SAFE__OP */((0x2E61E7DA0A205148LL < l_2570), (safe_div_func_uint8_t_u_u_unsafe_macro/*306*//* ___SAFE__OP */(g_5, l_2547)))) , (safe_add_func_uint16_t_u_u_unsafe_macro/*307*//* ___SAFE__OP */((**g_1661), 4UL))) || (safe_mod_func_int32_t_s_s_unsafe_macro/*308*//* ___SAFE__OP */(((l_2474 |= ((safe_add_func_int16_t_s_s_unsafe_macro/*309*//* ___SAFE__OP */((((p_16 ^ ((((l_2471 , p_16) > g_1236[0]) < l_2570) > p_16)) & p_16) <= p_16), g_60)) ^ l_2565)) < l_2562[1][2]), 0xC874F408L))) , l_2546) & l_2490), l_2471)) == p_16) || p_16) != p_16))
                    { /* block id: 1056 */
                        int32_t *l_2579 = &l_1802[8][3];
                        (**g_1350) = l_2579;
                    }
                    else
                    { /* block id: 1058 */
                        int32_t *l_2584 = &g_3;
                        int32_t *l_2585 = (void*)0;
                        int32_t *l_2586 = &g_2379;
                        int32_t l_2587[4] = {(-1L),(-1L),(-1L),(-1L)};
                        int32_t *l_2588[10] = {&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1],&g_88[1][0][1]};
                        int32_t l_2590 = 0xB701795EL;
                        int i;
                        (*p_15) ^= (((safe_lshift_func_int8_t_s_s_unsafe_macro/*310*//* ___SAFE__OP */(l_2570, 6)) , l_2562[1][2]) || ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*311*//* ___SAFE__OP */(18446744073709551615UL, 41)) >= l_2474));
                        (*g_1893) = l_2565;
                        --l_2598;
                    }
                    if ((*p_17))
                        continue;
                    for (l_2594 = (-23); (l_2594 <= 23); l_2594 = safe_add_func_uint8_t_u_u_unsafe_macro/*312*//* ___SAFE__OP */(l_2594, 1))
                    { /* block id: 1066 */
                        (**l_1707) = &p_16;
                    }
                }
            }
            else
            { /* block id: 1070 */
                uint16_t ***l_2639 = (void*)0;
                int64_t * const l_2641 = &g_341;
                const int32_t l_2644 = 0x996F54E6L;
                l_2633 ^= ((safe_rshift_func_int32_t_s_u_unsafe_macro/*313*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*314*//* ___SAFE__OP */(l_2490, ((safe_lshift_func_int8_t_s_s_unsafe_macro/*315*//* ___SAFE__OP */((~((((!(safe_div_func_int8_t_s_s_unsafe_macro/*316*//* ___SAFE__OP */(0xE2L, ((((safe_add_func_int64_t_s_s_unsafe_macro/*317*//* ___SAFE__OP */((p_16 ^ (safe_sub_func_uint8_t_u_u_unsafe_macro/*318*//* ___SAFE__OP */(p_16, (((g_2631[8][0][2] = (((safe_add_func_uint16_t_u_u_unsafe_macro/*319*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*320*//* ___SAFE__OP */(g_2621[1], (safe_div_func_int16_t_s_s_unsafe_macro/*321*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s_unsafe_macro/*322*//* ___SAFE__OP */((l_2589[1] & (g_1543[2][0] = (--g_138))), 0xD5BB0C7F2BAC4117LL)) != (((*g_2182) ^= ((*p_15) |= (l_2628 != (void*)0))) & (*p_17))), l_2589[1])))), g_1235)) , p_16) , 0x709C1800L)) , 0x11L) > 0x3DL)))), l_2547)) , l_2632) , l_2547) ^ 1UL)))) , 1L) , (*p_17)) , 0x7FA6L)), 3)) == p_16))), p_16)) , (*g_2182));
                l_1554 |= (l_2634 == (((safe_lshift_func_int32_t_s_u_unsafe_macro/*323*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s_unsafe_macro/*324*//* ___SAFE__OP */(6L, 5)), 2)) < ((((*l_2355) = (***l_2468)) == (((&l_1936[6] != l_2639) == (l_2640[1][1][0] == (void*)0)) , l_2641)) <= (((safe_lshift_func_int32_t_s_u_unsafe_macro/*325*//* ___SAFE__OP */((*p_15), l_2644)) & p_16) , p_16))) , &g_1412));
                --l_2645;
            }
            l_2648[0]--;
            (***g_1349) = &p_16;
        }
        else
        { /* block id: 1085 */
            int32_t l_2662 = (-2L);
            int64_t l_2683 = 0x9FB24213AC705596LL;
            uint32_t **l_2689 = &g_111;
            for (g_284 = 0; (g_284 <= 59); ++g_284)
            { /* block id: 1088 */
                uint8_t l_2660 = 0xB4L;
                uint32_t l_2661 = 0UL;
                int32_t l_2674 = 0L;
                (*p_15) = ((-1L) > (safe_mod_func_uint64_t_u_u_unsafe_macro/*326*//* ___SAFE__OP */((((l_2661 = l_2660) != l_2662) == (safe_lshift_func_int16_t_s_s_unsafe_macro/*327*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*328*//* ___SAFE__OP */((((safe_mod_func_int16_t_s_s_unsafe_macro/*329*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u_unsafe_macro/*330*//* ___SAFE__OP */((((safe_unary_minus_func_uint8_t_u_unsafe_macro/*331*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*332*//* ___SAFE__OP */((l_2674 &= 0xB2FC5B69L), ((safe_rshift_func_int32_t_s_u_unsafe_macro/*333*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*334*//* ___SAFE__OP */(0x85619850909C1F5ALL, (((safe_lshift_func_int8_t_s_u_unsafe_macro/*335*//* ___SAFE__OP */(((safe_sub_func_uint32_t_u_u_unsafe_macro/*336*//* ___SAFE__OP */(4294967289UL, ((*g_1393) ^ g_2303))) , 1L), 7)) != 0xAC08942CFE6923C3LL) & l_2662))), l_2660)) <= l_2662))))) > l_2662) & p_16), 1L)), p_16)) >= p_16) == l_2490), (***g_1412))) || 255UL), g_6))), 9L)));
            }
            (*g_2182) &= (((*p_17) && (l_2683 == ((p_16 , (((l_2684 = l_2684) != (g_2686 = l_2685)) || ((((((safe_div_func_uint32_t_u_u_unsafe_macro/*337*//* ___SAFE__OP */(((((void*)0 != l_2689) , (safe_lshift_func_uint32_t_u_s_unsafe_macro/*338*//* ___SAFE__OP */(((((safe_sub_func_int64_t_s_s_unsafe_macro/*339*//* ___SAFE__OP */(((!(-1L)) > (safe_mod_func_uint32_t_u_u_unsafe_macro/*340*//* ___SAFE__OP */(((((1UL & 0x7CB702D6E2B20D12LL) & p_16) != 0xFEBA7B4AAB06B514LL) <= g_60), l_2697))), 0xF1E76E659DC61332LL)) && 7L) && 1UL) <= l_2683), (*p_15)))) <= l_2683), 0x458E1398L)) , 0x468EL) , (*g_111)) , p_16) ^ 4L) && p_16))) == l_2683))) | l_2698);
            (**g_1350) = &p_16;
        }
    }
    return l_2699;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_67 g_81 g_5 g_60 g_89 g_111 g_114 g_88 g_138 g_83 g_137 g_205 g_206 g_287 g_341 g_284 g_406 g_407 g_106 g_85 g_443 g_171 g_178 g_177 g_256 g_569 g_786 g_567 g_806 g_344 g_931 g_995 g_996 g_997 g_998 g_702 g_1154 g_1155 g_1190 g_1236 g_1258 g_1289 g_1349 g_933 g_1350 g_1351 g_1384 g_1386 g_1393 g_1412 g_1416 g_1394 g_1413 g_1490
 * writes: g_28 g_67 g_81 g_83 g_85 g_88 g_106 g_111 g_137 g_138 g_287 g_177 g_114 g_5 g_490 g_341 g_318 g_568 g_284 g_171 g_702 g_786 g_806 g_206 g_870 g_933 g_996 g_1017 g_1235 g_1236 g_1257 g_1289 g_1154 g_1349 g_1155 g_1412 g_1394 g_1422 g_3 g_1487
 */
static int32_t * func_18(uint8_t  p_19, int8_t  p_20)
{ /* block id: 2 */
    int32_t *l_26[4][9][3] = {{{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3}}};
    uint16_t *l_27 = &g_28;
    uint64_t ** const **l_1525 = &g_1488;
    uint64_t ** const ***l_1524 = &l_1525;
    uint64_t **l_1529 = &g_1490;
    uint64_t ***l_1528 = &l_1529;
    uint64_t ****l_1527 = &l_1528;
    uint64_t *****l_1526 = &l_1527;
    const uint64_t * const *l_1536[2];
    const uint64_t * const **l_1535 = &l_1536[0];
    const uint64_t * const ***l_1534 = &l_1535;
    const uint64_t * const ****l_1533[4][5] = {{&l_1534,&l_1534,&l_1534,&l_1534,&l_1534},{&l_1534,(void*)0,&l_1534,(void*)0,&l_1534},{&l_1534,&l_1534,&l_1534,&l_1534,&l_1534},{&l_1534,(void*)0,&l_1534,(void*)0,&l_1534}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1536[i] = (void*)0;
    (*g_1386) = ((safe_rshift_func_int64_t_s_s((safe_mod_func_uint16_t_u_u_unsafe_macro/*342*//* ___SAFE__OP */(((*l_27) = (l_26[1][6][2] == l_26[2][6][0])), ((func_29(g_3, p_19, (safe_unary_minus_func_int32_t_s_unsafe_macro/*343*//* ___SAFE__OP */((-1L)))) <= (~(((*l_1524) = &g_1488) != ((*l_1526) = (void*)0)))) , (safe_mul_func_int64_t_s_s_unsafe_macro/*344*//* ___SAFE__OP */((((safe_unary_minus_func_int32_t_s_unsafe_macro/*345*//* ___SAFE__OP */((l_1533[3][0] == &l_1534))) , p_19) & (*g_407)), (*g_1490)))))), 49)) > 0xBFL);
    return l_26[1][5][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_3 g_67 g_81 g_5 g_60 g_89 g_111 g_114 g_88 g_138 g_83 g_137 g_205 g_206 g_287 g_341 g_284 g_406 g_407 g_106 g_85 g_443 g_171 g_178 g_177 g_256 g_569 g_786 g_567 g_806 g_344 g_931 g_995 g_996 g_997 g_998 g_702 g_1154 g_1155 g_1190 g_1236 g_1258 g_1289 g_1349 g_933 g_1350 g_1351 g_1384 g_1386 g_1393 g_1412 g_1416 g_1394 g_1413
 * writes: g_67 g_81 g_83 g_85 g_88 g_106 g_111 g_137 g_138 g_287 g_177 g_114 g_5 g_490 g_341 g_318 g_568 g_284 g_171 g_702 g_786 g_806 g_206 g_870 g_933 g_996 g_1017 g_1235 g_1236 g_1257 g_1289 g_1154 g_1349 g_1155 g_1412 g_1394 g_1422 g_3 g_1487
 */
static int32_t  func_29(int32_t  p_30, int32_t  p_31, int32_t  p_32)
{ /* block id: 4 */
    int64_t l_34 = 0L;
    int32_t l_35 = (-1L);
    const uint16_t *l_59 = &g_60;
    uint8_t *l_66 = &g_67;
    uint16_t *l_80 = &g_81;
    uint32_t *l_82 = &g_83;
    uint32_t *l_84 = &g_85;
    uint16_t **l_700 = (void*)0;
    uint16_t **l_701[9] = {&l_80,&l_80,&l_80,&l_80,&l_80,&l_80,&l_80,&l_80,&l_80};
    const int32_t *l_703 = &g_3;
    uint32_t l_1389 = 0xD85AF3A8L;
    int32_t l_1392 = (-2L);
    int32_t l_1492 = 7L;
    uint64_t ***l_1508 = (void*)0;
    int i;
    if ((g_6 || ((l_35 = l_34) >= (safe_rshift_func_uint8_t_u_s_unsafe_macro/*346*//* ___SAFE__OP */(((((p_31 > func_38(((l_1392 &= func_42(g_3, (!(!((safe_rshift_func_uint32_t_u_s_unsafe_macro/*347*//* ___SAFE__OP */(((((safe_sub_func_int64_t_s_s_unsafe_macro/*348*//* ___SAFE__OP */(((func_51(func_54(((l_59 == (g_702 = (((~18446744073709551610UL) , func_62(((safe_lshift_func_uint8_t_u_u_unsafe_macro/*349*//* ___SAFE__OP */((--(*l_66)), 5)) , ((*l_84) = ((safe_lshift_func_int16_t_s_s_unsafe_macro/*350*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*351*//* ___SAFE__OP */((((safe_mod_func_int16_t_s_s_unsafe_macro/*352*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*353*//* ___SAFE__OP */((((((l_34 || ((*l_82) = ((-1L) < (safe_rshift_func_uint16_t_u_u_unsafe_macro/*354*//* ___SAFE__OP */(((*l_80) &= (g_3 < p_32)), g_5))))) | p_31) ^ p_31) > g_60) != g_3), g_67)), 0x64EBL)) == g_3) != p_32), 3L)), 12)) >= g_3))))) , (void*)0))) || 0x7058L), l_703, (*l_703), &g_3), g_1154) || (*l_703)) <= 0L), 0xA2FD33E38201D050LL)) , l_1389) || 4294967290UL) , 4294967295UL), 3)) & p_30))))) && p_30), g_1384[4][0][2], g_1393)) , 0UL) , 0x46B8L) > p_31), 4)))))
    { /* block id: 541 */
        const uint32_t *l_1443 = &g_931;
        const uint32_t ** const l_1442 = &l_1443;
        const uint32_t **l_1445 = &l_1443;
        const uint32_t ***l_1444 = &l_1445;
        (*l_1444) = l_1442;
    }
    else
    { /* block id: 543 */
        int32_t *l_1446 = &g_3;
        int16_t l_1465 = 0xD44FL;
        int8_t * const ***l_1476 = (void*)0;
        int8_t * const **** const l_1475 = &l_1476;
        int32_t l_1497[6] = {0x21258BC1L,0x21258BC1L,(-1L),0x21258BC1L,0x21258BC1L,(-1L)};
        uint32_t l_1500 = 3UL;
        uint32_t * const *l_1503 = &g_111;
        uint32_t * const *l_1507 = &l_82;
        const uint64_t ** const l_1509 = &g_491;
        int32_t **l_1514 = &l_1446;
        int64_t *l_1519 = &g_1235;
        int32_t *l_1520 = (void*)0;
        int32_t *l_1521 = &l_1392;
        int32_t *l_1522 = &l_1497[5];
        int i;
        (**g_1350) = l_1446;
        for (g_171 = 9; (g_171 <= 31); ++g_171)
        { /* block id: 547 */
            uint64_t **l_1466 = &g_319;
            int32_t l_1467 = 0x2C7757A4L;
            int8_t *****l_1474 = &g_1422[1][0];
            int32_t l_1482 = 2L;
            uint64_t ** const **l_1491 = &g_1488;
            uint32_t * const **l_1504 = (void*)0;
            uint32_t * const **l_1505 = (void*)0;
            uint32_t * const **l_1506 = &l_1503;
            for (g_81 = 0; (g_81 <= 0); g_81 += 1)
            { /* block id: 550 */
                int32_t *l_1449 = &g_3;
                int32_t l_1498 = 0L;
                int32_t l_1499 = 0x20733F96L;
                l_1446 = l_1449;
                (*l_1449) = ((+((p_32 < (safe_add_func_uint32_t_u_u_unsafe_macro/*355*//* ___SAFE__OP */(0x2AB6EB95L, (safe_mod_func_uint8_t_u_u_unsafe_macro/*356*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*357*//* ___SAFE__OP */(0UL, (safe_mod_func_int64_t_s_s_unsafe_macro/*358*//* ___SAFE__OP */((1UL >= g_1289), (safe_div_func_uint8_t_u_u_unsafe_macro/*359*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*360*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*361*//* ___SAFE__OP */((((l_1465 , &g_491) == ((*l_1446) , l_1466)) , l_1467), g_1289)), 6UL)), g_60)))))) == p_32), 6UL))))) >= p_30)) & 0xD2EB14F4L);
                for (g_1394 = 0; (g_1394 <= 0); g_1394 += 1)
                { /* block id: 555 */
                    int32_t ***l_1468 = &g_996;
                    int32_t *l_1493 = &g_88[3][0][1];
                    int32_t *l_1494 = &l_1482;
                    int32_t *l_1495 = (void*)0;
                    int32_t *l_1496[5][10] = {{&l_1492,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1467,(void*)0,&l_1467,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1492,&l_1492,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1467},{&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1492,&l_1492,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1467,(void*)0,&l_1467,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1492,&l_1492},{&l_1467,&l_1492,&l_1392,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1392,&l_1492,&l_1467,&l_1492,&l_1392},{(void*)0,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],(void*)0,&l_1392,&l_1392,(void*)0,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&g_88[(g_81 + 3)][g_1394][(g_81 + 1)]},{&l_1467,&l_1467,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],(void*)0,(void*)0,(void*)0,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)],&l_1467,&l_1467,&g_88[(g_81 + 3)][g_1394][(g_81 + 1)]}};
                    int i, j, k;
                    l_1482 ^= (l_1468 == ((safe_sub_func_uint64_t_u_u_unsafe_macro/*362*//* ___SAFE__OP */((g_88[(g_81 + 3)][g_1394][(g_81 + 1)] = (safe_div_func_uint32_t_u_u_unsafe_macro/*363*//* ___SAFE__OP */(((~((l_1474 = (void*)0) != l_1475)) >= (safe_sub_func_int64_t_s_s_unsafe_macro/*364*//* ___SAFE__OP */((-1L), (safe_mod_func_uint8_t_u_u_unsafe_macro/*365*//* ___SAFE__OP */(((*l_66) ^= g_88[(g_81 + 3)][g_1394][(g_81 + 1)]), 255UL))))), (+(0xFFL != (**g_1413)))))), (((*l_1446) = l_1467) ^ (*g_1393)))) , (void*)0));
                    for (l_35 = 2; (l_35 <= 6); l_35 += 1)
                    { /* block id: 563 */
                        uint64_t ** const *l_1484 = (void*)0;
                        uint64_t ** const **l_1483[6][6] = {{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484},{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484},{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484},{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484},{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484},{&l_1484,&l_1484,&l_1484,&l_1484,&l_1484,&l_1484}};
                        uint64_t ** const ***l_1485 = (void*)0;
                        uint64_t ** const ***l_1486[1];
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_1486[i] = &l_1483[5][2];
                        (**g_1350) = ((*g_178) = &p_31);
                        l_1491 = (g_1487 = l_1483[5][2]);
                        return (*l_1449);
                    }
                    ++l_1500;
                }
            }
            if ((****g_1349))
                break;
            l_1507 = ((*l_1506) = l_1503);
        }
        (*l_1522) |= (p_31 = ((((void*)0 != l_1508) , l_1509) != ((((*l_1521) = (((((((*g_1393) = ((safe_sub_func_uint8_t_u_u_unsafe_macro/*366*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*367*//* ___SAFE__OP */((((*l_1514) = &l_1392) == &p_32), (safe_rshift_func_uint16_t_u_s_unsafe_macro/*368*//* ___SAFE__OP */((((p_32 <= (safe_lshift_func_int64_t_s_u_unsafe_macro/*369*//* ___SAFE__OP */((g_1384[4][0][2] ^ g_88[3][0][0]), (((**g_1413) &= ((&g_256 != l_1519) , 0L)) , l_1465)))) | g_344) || (*g_1393)), g_931)))), (*l_703))) > p_31)) <= g_1289) | (*g_111)) < 0xDEL) == p_31) > g_88[1][0][1])) , (*l_703)) , l_1509)));
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_1289 g_284 g_1412 g_407 g_106 g_1416 g_88 g_1393 g_1394 g_1349 g_1350 g_1351 g_3
 * writes: g_1289 g_1412 g_88 g_1394 g_1422 g_206 g_177
 */
static uint8_t  func_38(uint32_t  p_39, uint32_t  p_40, uint16_t * p_41)
{ /* block id: 523 */
    uint64_t l_1411 = 0x8798B96A29756A22LL;
    int32_t l_1415 = 0x3A5C9BD0L;
    int8_t ****l_1425 = &g_1423[5][0][5];
    int32_t **l_1437 = &g_177;
    int32_t l_1438 = 0x317C156CL;
    uint32_t l_1439 = 0x1C62936CL;
    for (g_1289 = 28; (g_1289 < 22); g_1289--)
    { /* block id: 526 */
        int32_t l_1405 = 8L;
        int32_t l_1410 = 0xB774F240L;
        int8_t * const ***l_1414 = &g_1412;
        int8_t **l_1420 = &g_407;
        int8_t ***l_1419 = &l_1420;
        int8_t ****l_1418 = &l_1419;
        int8_t *****l_1421[9];
        int32_t *l_1431 = &g_88[3][0][1];
        int32_t *l_1432[8] = {&g_3,&l_1415,&g_3,&g_3,&l_1415,&g_3,&g_3,&l_1415};
        int i;
        for (i = 0; i < 9; i++)
            l_1421[i] = &l_1418;
        (*g_1416) ^= (safe_add_func_uint32_t_u_u_unsafe_macro/*370*//* ___SAFE__OP */((((safe_rshift_func_int64_t_s_u_unsafe_macro/*371*//* ___SAFE__OP */(p_39, (safe_mul_func_uint16_t_u_u_unsafe_macro/*372*//* ___SAFE__OP */(((safe_lshift_func_int8_t_s_u_unsafe_macro/*373*//* ___SAFE__OP */(l_1405, (safe_mul_func_uint32_t_u_u_unsafe_macro/*374*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*375*//* ___SAFE__OP */(((l_1415 = ((l_1405 < (g_284 , l_1405)) == (l_1410 != (((l_1411 && ((((*l_1414) = g_1412) != &g_568) && l_1410)) && 0x4FA1C86DL) < p_39)))) > p_39), l_1410)), l_1410)))) <= p_40), l_1405)))) == (*g_407)) >= l_1410), p_40));
        l_1438 = ((safe_unary_minus_func_uint32_t_u_unsafe_macro/*376*//* ___SAFE__OP */(((((*g_1393) |= l_1405) , &g_1412) != (l_1425 = (g_1422[1][0] = l_1418))))) ^ (safe_sub_func_uint16_t_u_u_unsafe_macro/*377*//* ___SAFE__OP */(l_1405, ((+l_1410) < (((safe_sub_func_int32_t_s_s_unsafe_macro/*378*//* ___SAFE__OP */(p_40, (l_1415 = ((*l_1431) = p_40)))) == (safe_sub_func_int8_t_s_s_unsafe_macro/*379*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*380*//* ___SAFE__OP */(((p_40 , l_1437) == &l_1432[6]), 0UL)), p_40))) < p_39)))));
        l_1439--;
        (***g_1349) = &l_1438;
    }
    (*l_1437) = (void*)0;
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_1386 g_88
 * writes:
 */
static uint32_t  func_42(uint32_t  p_43, int64_t  p_44)
{ /* block id: 515 */
    for (p_43 = 0; (p_43 > 25); p_43 = safe_add_func_int64_t_s_s_unsafe_macro/*381*//* ___SAFE__OP */(p_43, 3))
    { /* block id: 518 */
        if ((*g_1386))
            break;
    }
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_138 g_111 g_1155 g_407 g_106 g_1190 g_88 g_83 g_171 g_81 g_6 g_931 g_1236 g_89 g_1258 g_287 g_1154 g_206 g_3 g_177 g_1289 g_60 g_67 g_137 g_341 g_1349 g_933 g_1350 g_1351 g_344 g_567 g_806 g_1384 g_1386 g_114
 * writes: g_138 g_83 g_106 g_88 g_341 g_1235 g_1236 g_1257 g_177 g_287 g_1289 g_81 g_1154 g_67 g_137 g_1349 g_206 g_1155 g_114
 */
static int8_t  func_51(uint16_t * p_52, uint16_t * p_53)
{ /* block id: 437 */
    uint8_t l_1160[2];
    uint8_t l_1161 = 255UL;
    int32_t l_1165[8] = {0xAA9DF09BL,6L,0xAA9DF09BL,6L,0xAA9DF09BL,6L,0xAA9DF09BL,6L};
    int32_t *l_1168 = (void*)0;
    uint8_t *l_1169 = &g_138;
    int32_t l_1188 = 1L;
    int32_t l_1207 = 0L;
    int32_t l_1265 = 0L;
    uint32_t * const * const l_1286 = &g_111;
    uint32_t * const * const *l_1285 = &l_1286;
    int16_t l_1381 = 0x0F07L;
    int i;
    for (i = 0; i < 2; i++)
        l_1160[i] = 0x9FL;
    if ((safe_mul_func_int64_t_s_s_unsafe_macro/*382*//* ___SAFE__OP */(((0L & (safe_lshift_func_int16_t_s_s_unsafe_macro/*383*//* ___SAFE__OP */((((65534UL > ((l_1160[0] < l_1161) & (((*g_111) = (!((safe_lshift_func_int64_t_s_u_unsafe_macro/*384*//* ___SAFE__OP */(((l_1165[6] , ((*l_1169) |= (safe_sub_func_int8_t_s_s_unsafe_macro/*385*//* ___SAFE__OP */(((void*)0 != l_1168), ((l_1160[1] || (0x76L >= l_1165[2])) ^ 0x6632L))))) <= l_1165[5]), 34)) | (-1L)))) >= (-6L)))) <= l_1165[6]) == (*p_53)), l_1165[7]))) > l_1165[6]), 0xE693CDA01C60B2EFLL)))
    { /* block id: 440 */
        uint8_t l_1181 = 0xC8L;
        int32_t l_1186[5];
        int8_t l_1187 = 0x48L;
        int32_t *l_1189 = (void*)0;
        uint32_t *l_1206[10][6] = {{(void*)0,(void*)0,&g_85,(void*)0,(void*)0,&g_85},{(void*)0,(void*)0,&g_85,(void*)0,(void*)0,&g_85},{(void*)0,(void*)0,&g_85,(void*)0,(void*)0,&g_85},{(void*)0,(void*)0,&g_85,(void*)0,(void*)0,&g_85},{(void*)0,(void*)0,&g_85,(void*)0,(void*)0,&g_85},{&g_83,&g_83,(void*)0,&g_83,&g_83,(void*)0},{&g_83,&g_83,(void*)0,&g_83,&g_83,(void*)0},{&g_83,&g_83,(void*)0,&g_83,&g_83,(void*)0},{&g_83,&g_83,(void*)0,&g_83,&g_83,(void*)0},{&g_83,&g_83,(void*)0,&g_83,&g_83,(void*)0}};
        int32_t **l_1214 = &l_1189;
        int i, j;
        for (i = 0; i < 5; i++)
            l_1186[i] = 0xD98BE87DL;
        (*g_1190) |= (safe_mod_func_uint16_t_u_u_unsafe_macro/*386*//* ___SAFE__OP */((l_1188 &= (((*g_407) &= (safe_lshift_func_int64_t_s_u_unsafe_macro/*387*//* ___SAFE__OP */(((~0UL) && (l_1186[4] ^= (safe_rshift_func_int16_t_s_u_unsafe_macro/*388*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*389*//* ___SAFE__OP */((((0x91EB7CE3L > (safe_rshift_func_uint8_t_u_u_unsafe_macro/*390*//* ___SAFE__OP */((l_1181 >= (((l_1161 <= l_1181) & (l_1165[1] != (((safe_rshift_func_uint32_t_u_s_unsafe_macro/*391*//* ___SAFE__OP */(l_1165[6], (&g_1154 != &g_702))) != l_1165[0]) > 4L))) && g_1155)), l_1181))) , l_1165[0]) & 0xF943L), 0xCCD5L)) <= (*p_53)), (*p_53))))), l_1161))) >= l_1187)), 65535UL));
        l_1188 = (safe_add_func_uint32_t_u_u_unsafe_macro/*392*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*393*//* ___SAFE__OP */((((safe_mul_func_int8_t_s_s_unsafe_macro/*394*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*395*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*396*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*397*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s_unsafe_macro/*398*//* ___SAFE__OP */(((~(((((l_1188 == (l_1207 ^= (*g_111))) && 0x224C30B42AE76FDELL) , (~((safe_div_func_int64_t_s_s_unsafe_macro/*399*//* ___SAFE__OP */(((*g_111) ^ ((((0x74929A1AL | 4294967286UL) < (((+(safe_add_func_int64_t_s_s_unsafe_macro/*400*//* ___SAFE__OP */((l_1187 != 0x97254DC2B8C80384LL), (l_1206[3][4] != l_1206[3][4])))) , l_1165[6]) , l_1188)) != 8UL) == g_171)), g_81)) , 4294967295UL))) , l_1161) < 0x33L)) == l_1186[4]), 1L)) < g_1155), l_1160[1])), l_1161)), 7UL)), l_1160[0])) , 0x311AL) > l_1160[0]), 0x659E0C4DC4E8E72BLL)), 0xFBD84C46L));
        (*l_1214) = &l_1165[6];
    }
    else
    { /* block id: 448 */
        int64_t l_1217[6][9][4] = {{{0x84DF75768746CC2CLL,0x644A622AD264AF70LL,0x33B34F8D29C207C8LL,(-8L)},{0L,1L,1L,0x46FCA66B23940474LL},{0x46FCA66B23940474LL,0x5CDAAB82E2D72926LL,(-8L),(-8L)},{0xA3627A5D7919B631LL,0xA3627A5D7919B631LL,0x46FCA66B23940474LL,1L},{0x9010E120BACD2D14LL,0x63477433F7E7A015LL,(-8L),0x33B34F8D29C207C8LL},{1L,0x46FCA66B23940474LL,1L,(-8L)},{(-7L),0x46FCA66B23940474LL,0x7A086D171B7552D9LL,0x33B34F8D29C207C8LL},{0x46FCA66B23940474LL,0x63477433F7E7A015LL,0L,1L},{0xB993A5F3E825CD43LL,0xA3627A5D7919B631LL,0x70877813F1BBE5A3LL,(-8L)}},{{(-8L),0x5CDAAB82E2D72926LL,(-8L),0x46FCA66B23940474LL},{0x5894553A79D83359LL,1L,0x644A622AD264AF70LL,(-8L)},{0L,0x644A622AD264AF70LL,(-1L),1L},{0x46FCA66B23940474LL,(-4L),(-1L),0x7A086D171B7552D9LL},{0L,0xA3627A5D7919B631LL,0x644A622AD264AF70LL,0L},{0x5894553A79D83359LL,3L,(-8L),0x70877813F1BBE5A3LL},{(-8L),0x70877813F1BBE5A3LL,0x70877813F1BBE5A3LL,(-8L)},{0xB993A5F3E825CD43LL,0x33B34F8D29C207C8LL,0L,0x644A622AD264AF70LL},{0x46FCA66B23940474LL,1L,0x7A086D171B7552D9LL,(-1L)}},{{(-7L),0xA3627A5D7919B631LL,1L,(-1L)},{1L,1L,(-8L),0x644A622AD264AF70LL},{0x9010E120BACD2D14LL,0x33B34F8D29C207C8LL,0x46FCA66B23940474LL,(-8L)},{0xA3627A5D7919B631LL,0x70877813F1BBE5A3LL,(-8L),0x70877813F1BBE5A3LL},{0x46FCA66B23940474LL,3L,1L,0L},{0L,0xA3627A5D7919B631LL,0x33B34F8D29C207C8LL,0x7A086D171B7552D9LL},{0x84DF75768746CC2CLL,(-4L),(-8L),1L},{0x84DF75768746CC2CLL,0x644A622AD264AF70LL,0x33B34F8D29C207C8LL,(-8L)},{0L,1L,1L,0x46FCA66B23940474LL}},{{0x46FCA66B23940474LL,0x5CDAAB82E2D72926LL,(-8L),(-8L)},{0xA3627A5D7919B631LL,0xA3627A5D7919B631LL,0x46FCA66B23940474LL,1L},{0x9010E120BACD2D14LL,0x63477433F7E7A015LL,(-8L),0x33B34F8D29C207C8LL},{1L,0x46FCA66B23940474LL,1L,(-8L)},{(-7L),0x46FCA66B23940474LL,0x7A086D171B7552D9LL,0x33B34F8D29C207C8LL},{0x46FCA66B23940474LL,0x63477433F7E7A015LL,0L,1L},{0xB993A5F3E825CD43LL,0xA3627A5D7919B631LL,0x70877813F1BBE5A3LL,(-8L)},{(-8L),0x5CDAAB82E2D72926LL,(-8L),0x46FCA66B23940474LL},{0x5894553A79D83359LL,1L,0x644A622AD264AF70LL,(-8L)}},{{0L,0x644A622AD264AF70LL,(-1L),1L},{0x46FCA66B23940474LL,(-4L),(-1L),0x7A086D171B7552D9LL},{0L,0xA3627A5D7919B631LL,0x644A622AD264AF70LL,0L},{0x5894553A79D83359LL,3L,(-8L),0x70877813F1BBE5A3LL},{(-8L),(-8L),(-8L),(-1L)},{0x33B34F8D29C207C8LL,0x5894553A79D83359LL,(-4L),1L},{0x84DF75768746CC2CLL,0L,0x63477433F7E7A015LL,3L},{0x644A622AD264AF70LL,0x46FCA66B23940474LL,0x9010E120BACD2D14LL,3L},{(-8L),0L,(-1L),1L}},{{0x7A086D171B7552D9LL,0x5894553A79D83359LL,0x84DF75768746CC2CLL,(-1L)},{0x46FCA66B23940474LL,(-8L),0x5CDAAB82E2D72926LL,(-8L)},{0x84DF75768746CC2CLL,0xB993A5F3E825CD43LL,1L,(-4L)},{0x70877813F1BBE5A3LL,0x46FCA66B23940474LL,0x5894553A79D83359LL,0x63477433F7E7A015LL},{1L,(-7L),(-1L),0x9010E120BACD2D14LL},{1L,1L,0x5894553A79D83359LL,(-1L)},{0x70877813F1BBE5A3LL,0x9010E120BACD2D14LL,1L,0x84DF75768746CC2CLL},{0x84DF75768746CC2CLL,0xA3627A5D7919B631LL,0x5CDAAB82E2D72926LL,0x5CDAAB82E2D72926LL},{0x46FCA66B23940474LL,0x46FCA66B23940474LL,0x84DF75768746CC2CLL,1L}}};
        int32_t l_1238 = (-8L);
        int32_t l_1288[3];
        int32_t l_1312 = 0xF345EF9DL;
        uint16_t l_1324[10][10][2] = {{{1UL,65535UL},{65530UL,0UL},{65532UL,65531UL},{0xE6D0L,1UL},{6UL,0xCDEFL},{0x68C3L,0x652FL},{0UL,0x2114L},{0x2ADFL,0xC342L},{2UL,0xF7DFL},{0xD2CFL,65528UL}},{{0xCDEFL,1UL},{0x0FEFL,0xBD30L},{0x1F5FL,0xBBDCL},{7UL,1UL},{0xB808L,6UL},{1UL,0x6D75L},{0x7774L,65530UL},{4UL,7UL},{0x7640L,0xCE3EL},{0x23C3L,1UL}},{{1UL,0x3969L},{0xF7DFL,0xB808L},{0x2114L,5UL},{0x29B8L,65532UL},{1UL,0x98D8L},{0x6D75L,65527UL},{65532UL,8UL},{65528UL,8UL},{65532UL,65527UL},{0x6D75L,0x98D8L}},{{1UL,65532UL},{0x29B8L,5UL},{0x2114L,0xB808L},{0xF7DFL,0x3969L},{1UL,1UL},{0x23C3L,0xCE3EL},{0x7640L,7UL},{4UL,65530UL},{0x7774L,0x6D75L},{1UL,6UL}},{{0xB808L,1UL},{7UL,0xBBDCL},{0x1F5FL,0xBD30L},{0x0FEFL,1UL},{0xCDEFL,65528UL},{0xD2CFL,0xF7DFL},{2UL,0xC342L},{0x2ADFL,0x2114L},{0UL,0x652FL},{0x68C3L,0xCDEFL}},{{6UL,1UL},{0xE6D0L,65531UL},{65532UL,0UL},{65530UL,65535UL},{1UL,2UL},{3UL,0x0063L},{65535UL,0UL},{0x0048L,65532UL},{65530UL,0x133AL},{0xD20FL,0xCEA7L}},{{0UL,65532UL},{65535UL,0x907CL},{1UL,0x23C3L},{8UL,0x1F5FL},{0x77ADL,0x7774L},{0xFACCL,0x3E93L},{0x6BB6L,0x6BB6L},{65529UL,65535UL},{65532UL,0x3969L},{6UL,65529UL}},{{0xB808L,6UL},{0x0FEFL,0x907CL},{0x0FEFL,6UL},{0xB808L,65529UL},{6UL,0x3969L},{65532UL,0x0048L},{1UL,0x3E93L},{0x3E93L,0UL},{0xE751L,65529UL},{0xD20FL,1UL}},{{0x0063L,65529UL},{0x4F45L,2UL},{0x0048L,65535UL},{0x7774L,1UL},{0x98D8L,0xC342L},{0xBBDCL,0x08B8L},{0UL,0UL},{7UL,3UL},{0x907CL,0x29B8L},{6UL,7UL}},{{0x23C3L,65535UL},{0UL,0xCEA7L},{65530UL,0x4F45L},{0x4EC2L,0xCE3EL},{8UL,0x0FEFL},{0UL,0xF7DFL},{1UL,0UL},{0x29B8L,0x1F5FL},{1UL,4UL},{0xCE3EL,0x5AE8L}}};
        const int32_t *****l_1383 = &g_1349;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1288[i] = (-3L);
        if ((safe_add_func_uint32_t_u_u_unsafe_macro/*401*//* ___SAFE__OP */((*g_111), ((0x5B2EE2A8L != ((l_1217[3][1][3] || ((*l_1169) = (safe_rshift_func_uint32_t_u_u_unsafe_macro/*402*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*403*//* ___SAFE__OP */((g_6 ^ (safe_mod_func_int64_t_s_s_unsafe_macro/*404*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*405*//* ___SAFE__OP */(l_1217[4][7][3], ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*406*//* ___SAFE__OP */(18446744073709551609UL, l_1217[3][6][1])) ^ l_1217[3][1][3]))) != (l_1168 == (void*)0)), 7UL))), g_88[1][0][1])), 27)))) && l_1188)) , l_1207))))
        { /* block id: 450 */
            int32_t *l_1230 = &l_1188;
            uint16_t **l_1232 = &g_1154;
            int64_t *l_1233 = (void*)0;
            int64_t *l_1234 = &g_1235;
            int32_t *l_1237[5] = {&l_1165[0],&l_1165[0],&l_1165[0],&l_1165[0],&l_1165[0]};
            const uint16_t l_1242[1] = {65527UL};
            const int64_t l_1247 = 0x06E4451C431CA27BLL;
            uint64_t *l_1254 = (void*)0;
            uint64_t *l_1255[10][1][10] = {{{&g_137[1],&g_171,&g_137[1],(void*)0,(void*)0,&g_171,(void*)0,(void*)0,&g_137[1],&g_171}},{{&g_137[2],(void*)0,&g_137[2],&g_137[2],&g_137[2],&g_137[2],&g_137[2],(void*)0,&g_137[2],(void*)0}},{{(void*)0,&g_137[2],&g_137[1],&g_171,&g_137[1],&g_137[2],(void*)0,&g_171,(void*)0,&g_137[2]}},{{&g_137[2],&g_171,(void*)0,&g_171,&g_137[2],&g_171,(void*)0,&g_171,&g_137[2],&g_171}},{{&g_137[1],&g_171,&g_137[1],&g_137[2],(void*)0,&g_171,(void*)0,&g_137[2],&g_137[1],&g_171}},{{&g_137[2],&g_137[2],&g_137[2],(void*)0,&g_137[2],(void*)0,&g_137[2],&g_137[2],&g_137[2],&g_137[2]}},{{(void*)0,(void*)0,&g_137[1],&g_171,&g_137[1],(void*)0,(void*)0,&g_171,(void*)0,(void*)0}},{{&g_137[2],&g_171,(void*)0,&g_171,&g_137[2],&g_171,(void*)0,&g_171,&g_137[2],&g_171}},{{&g_137[1],&g_171,&g_137[1],(void*)0,(void*)0,&g_171,(void*)0,(void*)0,&g_137[1],&g_171}},{{&g_137[2],(void*)0,&g_137[2],&g_137[2],&g_137[2],&g_137[2],&g_137[2],(void*)0,&g_137[2],(void*)0}}};
            int16_t *l_1256 = &g_1257;
            uint32_t l_1284 = 0x82B95D43L;
            const int32_t **l_1311 = (void*)0;
            const int32_t ***l_1310 = &l_1311;
            int32_t l_1380 = 1L;
            int32_t l_1382 = 0xCA24C068L;
            int i, j, k;
            (*g_89) |= (l_1238 ^= (l_1165[0] = (safe_mod_func_int32_t_s_s_unsafe_macro/*407*//* ___SAFE__OP */(((*l_1230) |= 0L), (l_1207 = ((((+0x114BC287L) && (l_1217[3][1][3] != (g_1236[8] |= ((((0xE098B4D60BCF14E8LL <= (((((((*l_1234) = (g_341 = ((void*)0 != l_1232))) , (l_1217[3][1][3] , 251UL)) <= 1L) , l_1161) < 0xF21E82EDL) , g_931)) || l_1217[2][4][3]) & 0x568AE692BF7EDEAFLL) <= 4294967295UL)))) >= l_1165[6]) , l_1217[3][1][3]))))));
            l_1238 |= ((1UL > (safe_unary_minus_func_uint8_t_u_unsafe_macro/*408*//* ___SAFE__OP */(((*l_1169) = (safe_mul_func_uint8_t_u_u_unsafe_macro/*409*//* ___SAFE__OP */(l_1242[0], (((safe_mod_func_int64_t_s_s_unsafe_macro/*410*//* ___SAFE__OP */(0xEF80E0CCCA71E0ADLL, (safe_lshift_func_int64_t_s_s_unsafe_macro/*411*//* ___SAFE__OP */((l_1247 || ((safe_mod_func_int8_t_s_s_unsafe_macro/*412*//* ___SAFE__OP */((*l_1230), 0x2EL)) != (0xCBB2D8EB96C96819LL < (((*l_1256) = ((((l_1165[0] = ((safe_mul_func_int8_t_s_s_unsafe_macro/*413*//* ___SAFE__OP */((0x7122B0CCL < (*g_111)), 1L)) == l_1217[3][8][3])) | 0xAF1A2D0D442FECFDLL) & l_1188) < l_1217[3][1][3])) ^ g_138)))), g_88[0][0][0])))) , 0xEDA4C7A95C1C2746LL) , 0x90L))))))) < 8UL);
            if (((*l_1230) = l_1165[6]))
            { /* block id: 464 */
                uint64_t l_1270 = 18446744073709551607UL;
                uint16_t *l_1279 = &g_287;
                int32_t l_1287[7] = {0x0BF5BFA8L,0x0BF5BFA8L,0x0BF5BFA8L,0x0BF5BFA8L,0x0BF5BFA8L,0x0BF5BFA8L,0x0BF5BFA8L};
                int i;
                (*g_1258) = &l_1207;
                (*g_177) &= (safe_div_func_uint16_t_u_u_unsafe_macro/*414*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*415*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*416*//* ___SAFE__OP */(g_88[0][0][1], (l_1265 |= (*p_53)))), 9)), ((safe_rshift_func_int32_t_s_s_unsafe_macro/*417*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*418*//* ___SAFE__OP */(l_1270, (((6UL == ((((((safe_sub_func_uint64_t_u_u_unsafe_macro/*419*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*420*//* ___SAFE__OP */(l_1270, (0x83539400L != ((safe_sub_func_uint8_t_u_u_unsafe_macro/*421*//* ___SAFE__OP */((((l_1270 ^ (((safe_add_func_uint8_t_u_u_unsafe_macro/*422*//* ___SAFE__OP */(((*l_1169) = (((*l_1279) |= 0x9A13L) != (safe_sub_func_int64_t_s_s_unsafe_macro/*423*//* ___SAFE__OP */(((safe_add_func_uint8_t_u_u_unsafe_macro/*424*//* ___SAFE__OP */(l_1284, l_1217[3][1][3])) && g_83), 0xFDD7DC0D7E8B3F27LL)))), (*g_407))) < l_1217[3][1][3]) ^ 0L)) | l_1217[3][1][3]) > l_1238), 0x09L)) <= 0x1DE0F5B2L)))), l_1238)) , (void*)0) == l_1285) || (*g_1154)) >= (*l_1230)) < l_1238)) & l_1165[7]) && 0x4B27L))), (*g_206))) || l_1238)));
                (*g_177) &= (*l_1230);
                g_1289--;
            }
            else
            { /* block id: 472 */
                uint32_t l_1296 = 0UL;
                int64_t l_1307[7][10][3] = {{{0L,0x4D02A1C34F918C6ALL,(-1L)},{0x022677551AB57AEALL,0x588009CB3D60E3D8LL,0L},{0x897149F7D43E3B43LL,0xA9925082C146B62DLL,0x588009CB3D60E3D8LL},{(-6L),0xC3BCCAF10E9B195ELL,0L},{0x329DDABF7EDC3483LL,0xF67B671C55D6B586LL,0xFA51FC648E250294LL},{0xA0003B10161B871DLL,8L,0xC4BE05907F790D46LL},{(-1L),0x8F8AF4352B342630LL,0xE9CFEF8B396492D8LL},{0x1C59F4D72F522477LL,1L,1L},{(-5L),0xE89F3E84F20B0BFDLL,7L},{8L,(-5L),0x4D02A1C34F918C6ALL}},{{(-1L),0xDDDF51014F12B2FALL,9L},{0x93220A60E05745F2LL,0x329DDABF7EDC3483LL,1L},{0x8F8AF4352B342630LL,0x0913CE5AB8C503D5LL,(-5L)},{0x897149F7D43E3B43LL,0x0913CE5AB8C503D5LL,(-3L)},{0xFA51FC648E250294LL,0x329DDABF7EDC3483LL,0x0EF708808837B4B9LL},{7L,0xDDDF51014F12B2FALL,2L},{(-8L),(-5L),0xBEF5402A56E20D8DLL},{0xDDDF51014F12B2FALL,0xE89F3E84F20B0BFDLL,0xE8B1A69AE7441677LL},{0x6DFB582FC3992BB4LL,1L,0x34CCF36B16CA3450LL},{(-1L),0x8F8AF4352B342630LL,0x1C59F4D72F522477LL}},{{0xB2489BD945BA6D80LL,8L,0xB5B12850EAA2959CLL},{1L,0xF67B671C55D6B586LL,1L},{0xE89F3E84F20B0BFDLL,0xB5B12850EAA2959CLL,0xE89F3E84F20B0BFDLL},{0L,0x9B2CFCDE31E6183ALL,0L},{0L,(-1L),(-4L)},{0xE8BA649C8C8CD098LL,0x65893FF3E6DF539CLL,(-1L)},{0x930AACAD9F480139LL,0x5D97968A03067C06LL,0x8833A9422821530ELL},{0xE8BA649C8C8CD098LL,0xE8B1A69AE7441677LL,(-4L)},{0L,(-3L),1L},{0L,0x5304FF463EFE4483LL,1L}},{{0xE89F3E84F20B0BFDLL,0xFA51FC648E250294LL,6L},{1L,0xF5DF3C0F9E633DC2LL,0x588009CB3D60E3D8LL},{0xB2489BD945BA6D80LL,0x022677551AB57AEALL,0xFF4A72DE47BAEA46LL},{(-1L),(-8L),0x897149F7D43E3B43LL},{0x6DFB582FC3992BB4LL,0L,0xE8BA649C8C8CD098LL},{0xDDDF51014F12B2FALL,0x0EF708808837B4B9LL,0L},{(-8L),0xC3BCCAF10E9B195ELL,8L},{7L,(-6L),0xE9FBFACA0E395C36LL},{0xFA51FC648E250294LL,0L,0x022677551AB57AEALL},{0x897149F7D43E3B43LL,8L,0x022677551AB57AEALL}},{{0x8F8AF4352B342630LL,(-3L),0xE9FBFACA0E395C36LL},{0x93220A60E05745F2LL,0x7A0AB679D16C38E5LL,8L},{(-1L),0xC4BE05907F790D46LL,0L},{8L,1L,0xE8BA649C8C8CD098LL},{(-5L),1L,0x897149F7D43E3B43LL},{0x1C59F4D72F522477LL,1L,0xFF4A72DE47BAEA46LL},{(-1L),1L,0x588009CB3D60E3D8LL},{0xA0003B10161B871DLL,0xE8BA649C8C8CD098LL,6L},{0xE9CFEF8B396492D8LL,1L,1L},{0x171EFB5E419B77DFLL,0x6DFB582FC3992BB4LL,1L}},{{0xFF4A72DE47BAEA46LL,2L,(-4L)},{0L,0x4406D9808DC0EE63LL,0x8833A9422821530ELL},{0L,0x171EFB5E419B77DFLL,(-1L)},{0x7A0AB679D16C38E5LL,0x4406D9808DC0EE63LL,(-4L)},{0x65893FF3E6DF539CLL,2L,0L},{(-5L),0x6DFB582FC3992BB4LL,0xE89F3E84F20B0BFDLL},{0x5304FF463EFE4483LL,1L,1L},{0xBEF5402A56E20D8DLL,0xE8BA649C8C8CD098LL,0xB5B12850EAA2959CLL},{0xC4BE05907F790D46LL,1L,0x1C59F4D72F522477LL},{0xE9FBFACA0E395C36LL,1L,0x34CCF36B16CA3450LL}},{{1L,1L,0xE8B1A69AE7441677LL},{1L,1L,0xBEF5402A56E20D8DLL},{0L,0xC4BE05907F790D46LL,2L},{1L,0x7A0AB679D16C38E5LL,0x0EF708808837B4B9LL},{0xF5DF3C0F9E633DC2LL,(-3L),(-3L)},{0x5D97968A03067C06LL,8L,(-5L)},{0x5D97968A03067C06LL,0L,1L},{0xF5DF3C0F9E633DC2LL,(-6L),9L},{0x8F8AF4352B342630LL,0xB5B12850EAA2959CLL,0x65893FF3E6DF539CLL},{0L,1L,(-4L)}}};
                int32_t l_1313[8][2] = {{(-5L),0L},{(-5L),(-5L)},{0L,(-5L)},{(-5L),0L},{(-5L),(-5L)},{0L,(-5L)},{(-5L),0L},{(-5L),(-5L)}};
                uint8_t *l_1330 = &g_67;
                const int32_t ****l_1353[10];
                int i, j, k;
                for (i = 0; i < 10; i++)
                    l_1353[i] = &l_1310;
                for (g_81 = 0; (g_81 > 55); g_81 = safe_add_func_uint64_t_u_u_unsafe_macro/*425*//* ___SAFE__OP */(g_81, 9))
                { /* block id: 475 */
                    int32_t **l_1294 = &g_177;
                    int32_t l_1295 = (-1L);
                    (*l_1294) = &l_1238;
                    --l_1296;
                    (**l_1294) = (!(safe_unary_minus_func_uint8_t_u_unsafe_macro/*426*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*427*//* ___SAFE__OP */(((l_1288[2] >= (0xDC9D2F82L && ((void*)0 != &g_180))) , (safe_add_func_uint64_t_u_u_unsafe_macro/*428*//* ___SAFE__OP */(l_1217[5][6][1], 0x04600F97B4A32F8FLL))), ((((((((safe_add_func_uint8_t_u_u_unsafe_macro/*429*//* ___SAFE__OP */(l_1296, (l_1307[2][1][2] , l_1307[2][8][2]))) | l_1217[3][1][3]) == l_1207) , l_1265) >= l_1165[6]) , (void*)0) == &g_870) != g_60))))));
                    if (((safe_lshift_func_uint32_t_u_u_unsafe_macro/*430*//* ___SAFE__OP */(0UL, 0)) == (l_1310 != &l_1311)))
                    { /* block id: 479 */
                        uint32_t l_1314[3][5][2] = {{{0x94C4E4A6L,4294967295UL},{0xD337CC33L,0xFFD99D8EL},{1UL,1UL},{1UL,4294967295UL},{4294967291UL,4294967295UL}},{{1UL,1UL},{1UL,0xFFD99D8EL},{0xD337CC33L,4294967295UL},{0x94C4E4A6L,0xAFCF8F82L},{4294967295UL,0x94C4E4A6L}},{{1UL,1UL},{1UL,0x94C4E4A6L},{4294967295UL,0xAFCF8F82L},{0x94C4E4A6L,4294967295UL},{0xD337CC33L,0xFFD99D8EL}}};
                        int i, j, k;
                        --l_1314[1][0][0];
                    }
                    else
                    { /* block id: 481 */
                        int16_t l_1325 = (-5L);
                        int32_t l_1331 = 0x33B81255L;
                        const int32_t *****l_1352 = &g_1349;
                        l_1288[2] = ((*l_1230) = (safe_mod_func_uint32_t_u_u_unsafe_macro/*431*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*432*//* ___SAFE__OP */(((((**l_1294) = 1UL) || ((safe_add_func_int64_t_s_s_unsafe_macro/*433*//* ___SAFE__OP */(((l_1165[2] &= (((~l_1324[8][0][1]) < (((*g_407) ^= (l_1325 && (safe_add_func_uint16_t_u_u_unsafe_macro/*434*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*435*//* ___SAFE__OP */(((*l_1256) = ((((*l_1330) ^= (((*l_1232) = &g_1155) != ((l_1330 != &g_67) , &g_1155))) || (l_1288[2] | (g_137[6]--))) >= (safe_rshift_func_int64_t_s_u_unsafe_macro/*436*//* ___SAFE__OP */(l_1238, 10)))), l_1324[8][0][1])), (**l_1294))))) == (-3L))) ^ l_1238)) , (**l_1294)), l_1296)) , (*g_111))) >= (*p_53)), (-5L))) > 0xECL), l_1188)));
                        l_1265 = (safe_lshift_func_int32_t_s_u_unsafe_macro/*437*//* ___SAFE__OP */((*g_206), ((safe_unary_minus_func_uint32_t_u_unsafe_macro/*438*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*439*//* ___SAFE__OP */((l_1256 != &g_1257), g_341)))) == ((p_52 == ((0x3AD8300BL > ((safe_div_func_int64_t_s_s_unsafe_macro/*440*//* ___SAFE__OP */(((safe_div_func_int8_t_s_s_unsafe_macro/*441*//* ___SAFE__OP */(((*g_407) |= ((safe_add_func_int32_t_s_s_unsafe_macro/*442*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u_unsafe_macro/*443*//* ___SAFE__OP */(((l_1353[1] = ((*l_1352) = g_1349)) != &l_1310), 27)), (~(**l_1294)))) < l_1217[4][0][1])), l_1325)) & 0x91764660L), g_933)) < l_1324[8][0][1])) , (void*)0)) , 0xDA7DE9115AF3B638LL))));
                        (**g_1350) = &l_1288[2];
                    }
                }
            }
            l_1238 ^= (~(0x90L ^ (((((safe_sub_func_uint32_t_u_u_unsafe_macro/*444*//* ___SAFE__OP */(((((*g_1154) |= (((l_1312 , (safe_mod_func_uint32_t_u_u_unsafe_macro/*445*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*446*//* ___SAFE__OP */(l_1161, l_1265)) ^ (safe_mul_func_int32_t_s_s_unsafe_macro/*447*//* ___SAFE__OP */(((((safe_add_func_int32_t_s_s_unsafe_macro/*448*//* ___SAFE__OP */((l_1217[3][1][3] == 0x0175FFAAL), (((safe_mod_func_int8_t_s_s_unsafe_macro/*449*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*450*//* ___SAFE__OP */((g_137[2] = ((((*l_1234) = ((safe_add_func_int8_t_s_s_unsafe_macro/*451*//* ___SAFE__OP */(l_1288[2], (((*g_111)++) , ((((((safe_mul_func_uint8_t_u_u_unsafe_macro/*452*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*453*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u_unsafe_macro/*454*//* ___SAFE__OP */(((4UL ^ ((void*)0 != (*l_1310))) & l_1165[6]), l_1165[6])) , l_1165[4]), l_1165[6])), 0x30L)) != g_344) , l_1160[0]) == g_567) ^ l_1217[3][1][3]) | l_1188)))) & 0UL)) | (-1L)) | l_1380)), l_1324[8][0][1])), l_1381)) , g_806[1]) , l_1165[3]))) & 5UL) != g_67) || l_1161), l_1382))), (-10L)))) , (void*)0) != l_1383)) & (*****l_1383)) & g_931), 4294967295UL)) & 0x65L) , l_1160[0]) > l_1188) , g_1384[4][0][2])));
        }
        else
        { /* block id: 504 */
            uint8_t l_1385 = 1UL;
            (*g_1386) |= l_1385;
            return (*****l_1383);
        }
    }
    for (g_114 = 12; (g_114 > 11); g_114 = safe_sub_func_uint8_t_u_u_unsafe_macro/*455*//* ___SAFE__OP */(g_114, 1))
    { /* block id: 511 */
        if (l_1165[5])
            break;
    }
    return l_1265;
}


/* ------------------------------------------ */
/* 
 * reads : g_406 g_407 g_106 g_3 g_138 g_111 g_83 g_60 g_114 g_81 g_88 g_171 g_287 g_85 g_284 g_5 g_786 g_567 g_806 g_89 g_341 g_67 g_344 g_569 g_206 g_137 g_443 g_931 g_177 g_995 g_996 g_997 g_998 g_702 g_256
 * writes: g_106 g_171 g_83 g_786 g_85 g_81 g_806 g_206 g_284 g_490 g_341 g_870 g_933 g_67 g_177 g_996 g_1017 g_88
 */
static uint16_t * func_54(int32_t  p_55, const int32_t * p_56, int8_t  p_57, const int32_t * p_58)
{ /* block id: 256 */
    int64_t l_723 = (-10L);
    int32_t **l_733 = &g_177;
    int32_t ***l_734 = &l_733;
    int32_t **l_736 = &g_177;
    int32_t ***l_735 = &l_736;
    uint64_t l_737[10][2][7] = {{{0UL,0x15C089BB2572AA9FLL,18446744073709551611UL,0x21B53607505CDDE8LL,0x3C77DDAD1EF6A0BFLL,0x678845A26E135FCCLL,0x3C77DDAD1EF6A0BFLL},{0UL,0x3C77DDAD1EF6A0BFLL,0x3C77DDAD1EF6A0BFLL,0UL,18446744073709551615UL,18446744073709551606UL,0x7282918FA1519C42LL}},{{18446744073709551615UL,18446744073709551606UL,18446744073709551611UL,18446744073709551615UL,18446744073709551615UL,18446744073709551611UL,18446744073709551606UL},{18446744073709551615UL,18446744073709551615UL,0x678845A26E135FCCLL,0x15C089BB2572AA9FLL,0x3C77DDAD1EF6A0BFLL,0x7282918FA1519C42LL,0x7282918FA1519C42LL}},{{0x678845A26E135FCCLL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0x678845A26E135FCCLL,0x15C089BB2572AA9FLL,0x3C77DDAD1EF6A0BFLL},{18446744073709551611UL,18446744073709551606UL,18446744073709551615UL,0x15C089BB2572AA9FLL,0x21B53607505CDDE8LL,0x15C089BB2572AA9FLL,18446744073709551615UL}},{{0x3C77DDAD1EF6A0BFLL,0x3C77DDAD1EF6A0BFLL,0UL,18446744073709551615UL,18446744073709551606UL,0x7282918FA1519C42LL,18446744073709551611UL},{18446744073709551611UL,0x15C089BB2572AA9FLL,0UL,0UL,0x15C089BB2572AA9FLL,18446744073709551611UL,0x21B53607505CDDE8LL}},{{0x678845A26E135FCCLL,0UL,18446744073709551615UL,0x21B53607505CDDE8LL,18446744073709551606UL,18446744073709551606UL,0x21B53607505CDDE8LL},{18446744073709551615UL,0x7B3A1FBF18F30C6FLL,18446744073709551615UL,0x7282918FA1519C42LL,0x21B53607505CDDE8LL,0x678845A26E135FCCLL,18446744073709551611UL}},{{18446744073709551615UL,0UL,0x678845A26E135FCCLL,0x7282918FA1519C42LL,0x678845A26E135FCCLL,0UL,18446744073709551615UL},{0UL,0x15C089BB2572AA9FLL,18446744073709551611UL,0x21B53607505CDDE8LL,0x3C77DDAD1EF6A0BFLL,0x678845A26E135FCCLL,0x3C77DDAD1EF6A0BFLL}},{{0UL,0x3C77DDAD1EF6A0BFLL,0x3C77DDAD1EF6A0BFLL,0UL,18446744073709551615UL,18446744073709551606UL,0x7282918FA1519C42LL},{18446744073709551615UL,18446744073709551606UL,18446744073709551611UL,18446744073709551615UL,18446744073709551615UL,18446744073709551611UL,18446744073709551606UL}},{{18446744073709551615UL,18446744073709551615UL,0x678845A26E135FCCLL,0x15C089BB2572AA9FLL,0x3C77DDAD1EF6A0BFLL,0x7282918FA1519C42LL,0x7282918FA1519C42LL},{0x678845A26E135FCCLL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0x678845A26E135FCCLL,0x15C089BB2572AA9FLL,0x3C77DDAD1EF6A0BFLL}},{{18446744073709551611UL,18446744073709551606UL,18446744073709551615UL,0x15C089BB2572AA9FLL,0x21B53607505CDDE8LL,0x15C089BB2572AA9FLL,18446744073709551615UL},{0x3C77DDAD1EF6A0BFLL,0x3C77DDAD1EF6A0BFLL,0UL,18446744073709551615UL,18446744073709551606UL,0x7282918FA1519C42LL,18446744073709551611UL}},{{18446744073709551611UL,0x15C089BB2572AA9FLL,0UL,0UL,0x15C089BB2572AA9FLL,18446744073709551611UL,0x21B53607505CDDE8LL},{0x678845A26E135FCCLL,0UL,18446744073709551615UL,0x21B53607505CDDE8LL,18446744073709551606UL,18446744073709551606UL,18446744073709551606UL}}};
    uint64_t l_738 = 18446744073709551615UL;
    uint64_t *l_739 = &g_171;
    int8_t **l_740 = &g_407;
    uint16_t *l_751 = (void*)0;
    int32_t l_752[4][2][10] = {{{(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L),1L},{(-5L),(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L)}},{{(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L),1L},{(-5L),(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L)}},{{(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L),1L},{(-5L),(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L)}},{{(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L),1L},{(-5L),(-5L),1L,1L,(-5L),(-5L),1L,1L,(-5L),(-5L)}}};
    int32_t *l_787 = &l_752[3][1][2];
    uint8_t l_795 = 247UL;
    uint32_t **l_868 = &g_111;
    uint64_t l_872[2][4];
    uint64_t l_913 = 1UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
            l_872[i][j] = 0xE4D82130743C4341LL;
    }
    if ((safe_mod_func_uint8_t_u_u_unsafe_macro/*456*//* ___SAFE__OP */((((((((*l_739) |= (((safe_mul_func_uint64_t_u_u_unsafe_macro/*457*//* ___SAFE__OP */(((((safe_div_func_uint16_t_u_u_unsafe_macro/*458*//* ___SAFE__OP */(((safe_div_func_int16_t_s_s_unsafe_macro/*459*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*460*//* ___SAFE__OP */((((p_57 != ((+(safe_add_func_int16_t_s_s_unsafe_macro/*461*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*462*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u_unsafe_macro/*463*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*464*//* ___SAFE__OP */((1L < (l_723 > (safe_mod_func_int32_t_s_s_unsafe_macro/*465*//* ___SAFE__OP */((((safe_add_func_int8_t_s_s_unsafe_macro/*466*//* ___SAFE__OP */(0x27L, ((((!(l_723 == l_723)) != (safe_mod_func_int8_t_s_s_unsafe_macro/*467*//* ___SAFE__OP */(((*g_407) = ((safe_mod_func_int64_t_s_s_unsafe_macro/*468*//* ___SAFE__OP */(((p_57 <= l_723) | (((*l_735) = ((*l_734) = l_733)) == &p_56)), p_57)) , (**g_406))), g_3))) , (*p_58)) < l_737[1][0][3]))) < p_57) || g_138), (*g_111))))), (*p_58))), g_60)) != p_57), p_57)), p_57))) <= p_57)) & p_55) , 0x82L), l_738)), g_114)) > p_55), g_81)) > 1L) && l_723) >= g_88[2][0][0]), p_55)) , 1UL) && 4UL)) == 0UL) ^ g_287) , &g_407) != l_740) > (*p_58)), g_85)))
    { /* block id: 261 */
        int32_t ****l_744[3][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
        int32_t *****l_743 = &l_744[0][1];
        uint32_t *l_747 = (void*)0;
        uint32_t *l_748[6][4] = {{&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85},{&g_85,&g_85,&g_85,&g_85}};
        int16_t l_749 = 0xCADAL;
        uint16_t *l_750 = &g_81;
        int i, j;
        l_752[3][0][8] |= (((((((safe_mod_func_uint8_t_u_u_unsafe_macro/*469*//* ___SAFE__OP */((((((*g_407) = (-1L)) , p_57) & ((l_743 != (void*)0) , 1UL)) || ((((*g_111) , ((l_749 = ((*g_111) = (safe_sub_func_int16_t_s_s_unsafe_macro/*470*//* ___SAFE__OP */(p_57, p_55)))) , l_750)) == l_751) , p_57)), g_85)) < g_284) , 0x3211L) > 0x8C30L) != 1UL) >= g_114) , 0xA33F0C48L);
    }
    else
    { /* block id: 266 */
        uint16_t l_784 = 0x4A9FL;
        int8_t *l_785 = &g_786;
        int32_t l_799 = 1L;
        int32_t l_804[3][7] = {{6L,6L,6L,6L,6L,6L,6L},{8L,0xC2498E00L,8L,0xC2498E00L,8L,0xC2498E00L,8L},{6L,6L,6L,6L,6L,6L,6L}};
        int8_t l_805 = 0x2CL;
        uint32_t **l_871 = &g_111;
        int64_t l_914 = 0L;
        uint16_t **l_929 = &g_702;
        uint32_t l_974[4][7][4] = {{{0UL,7UL,1UL,0UL},{1UL,7UL,0xC2191F8AL,0x1FBECFC8L},{7UL,0x0BF6C46BL,0x5BDCA24FL,0x466180A0L},{1UL,4294967295UL,1UL,9UL},{0x6E320B6AL,0xC2191F8AL,1UL,0x6A3F9726L},{0x18981943L,0xA09B3E91L,0x9283743AL,0xA4087628L},{0xC0626F13L,0x1F0FEAD5L,1UL,4294967289UL}},{{0x466180A0L,0UL,0xDB019E06L,4294967295UL},{0x71037BE9L,0x84DE69A8L,0x71037BE9L,3UL},{1UL,0x9F8EBE06L,4294967295UL,0xC2191F8AL},{0x0BF6C46BL,4294967289UL,3UL,0x9F8EBE06L},{0UL,0x4D9C1214L,3UL,4294967295UL},{0x0BF6C46BL,0x6E320B6AL,4294967295UL,0x9283743AL},{1UL,0x3F180D55L,0x71037BE9L,4294967288UL}},{{0x71037BE9L,4294967288UL,4294967295UL,0x5BDCA24FL},{0xD4E71765L,3UL,0x1FBECFC8L,0x9FCD6DF8L},{0xDB019E06L,4294967295UL,1UL,0UL},{0x184BECCBL,0xDB019E06L,3UL,1UL},{0UL,0x6E320B6AL,0x6E320B6AL,0UL},{0x1FBECFC8L,3UL,4294967295UL,3UL},{0x9F8EBE06L,0UL,0x0BF6C46BL,0x9283743AL}},{{0x6E320B6AL,7UL,9UL,0x9283743AL},{0x1F0FEAD5L,0UL,8UL,3UL},{0xC2191F8AL,3UL,0x184BECCBL,0UL},{0x18981943L,0x6E320B6AL,0xC2191F8AL,1UL},{0x9FCD6DF8L,0xDB019E06L,0UL,0UL},{4294967295UL,4294967295UL,0x6A3F9726L,0x9FCD6DF8L},{0UL,3UL,0xA09B3E91L,0x5BDCA24FL}}};
        int32_t *l_994 = (void*)0;
        int32_t **l_993 = &l_994;
        int8_t **l_1018 = &g_407;
        uint64_t l_1049 = 0UL;
        int8_t l_1080 = (-6L);
        int i, j, k;
        if (((safe_sub_func_uint16_t_u_u_unsafe_macro/*471*//* ___SAFE__OP */(((safe_unary_minus_func_uint32_t_u_unsafe_macro/*472*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*473*//* ___SAFE__OP */((((((((*g_111)++) || (*g_111)) , ((safe_div_func_int64_t_s_s_unsafe_macro/*474*//* ___SAFE__OP */(0x9CE346E0961FB28ELL, ((18446744073709551615UL || 0x66164D3ED030CE1ELL) , p_57))) <= ((((*p_58) | ((((**l_740) = (0x5BL | (~((safe_lshift_func_int16_t_s_s_unsafe_macro/*475*//* ___SAFE__OP */(g_81, 4)) | (safe_sub_func_int8_t_s_s_unsafe_macro/*476*//* ___SAFE__OP */(((*l_785) |= ((safe_div_func_int64_t_s_s_unsafe_macro/*477*//* ___SAFE__OP */((((safe_sub_func_int16_t_s_s_unsafe_macro/*478*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s_unsafe_macro/*479*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*480*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*481*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*482*//* ___SAFE__OP */(((safe_unary_minus_func_int16_t_s_unsafe_macro/*483*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_u_unsafe_macro/*484*//* ___SAFE__OP */(((*l_739) |= l_784), 2)) , g_106))) <= g_114), p_57)), (*p_58))), 4294967291UL)) , (*g_111)), 10)), g_3)) ^ g_5) || p_55), p_57)) > 0x61L)), g_567)))))) || p_55) > p_55)) > 0UL) < 0UL))) == p_55) , p_57) ^ 0xECE3L), 6)))) < 0L), g_284)) , (*p_56)))
        { /* block id: 271 */
            int32_t l_798 = 0xEE498042L;
            int32_t *l_800 = &l_752[2][1][8];
            int32_t *l_801 = &l_799;
            int32_t *l_802 = &l_798;
            int32_t *l_803[2];
            int i;
            for (i = 0; i < 2; i++)
                l_803[i] = &l_798;
lbl_790:
            l_787 = (void*)0;
            for (g_786 = (-24); (g_786 == 20); g_786++)
            { /* block id: 275 */
                int32_t l_797 = 8L;
                if (g_60)
                    goto lbl_790;
                for (g_85 = 0; (g_85 > 40); g_85++)
                { /* block id: 279 */
                    int32_t *l_796 = &l_752[1][0][3];
                    for (g_81 = 23; (g_81 != 31); ++g_81)
                    { /* block id: 282 */
                        if (l_784)
                            break;
                    }
                    (*l_796) ^= l_795;
                    l_798 |= l_797;
                }
            }
            --g_806[1];
        }
        else
        { /* block id: 290 */
            uint64_t l_814 = 0xFB7211B73E6CDDD6LL;
            uint64_t ***l_820 = &g_318;
            int32_t l_849[7];
            int16_t l_850 = 1L;
            int16_t l_851 = 0xF8FAL;
            uint32_t *l_897 = &g_85;
            uint32_t **l_896 = &l_897;
            int32_t ***l_911 = &l_736;
            uint8_t *l_912 = &l_795;
            uint16_t **l_930 = (void*)0;
            int i;
            for (i = 0; i < 7; i++)
                l_849[i] = 1L;
            if ((*g_89))
            { /* block id: 291 */
                const int32_t * const l_817 = &g_3;
                for (l_784 = 0; (l_784 <= 1); l_784 += 1)
                { /* block id: 294 */
                    int32_t *l_809 = (void*)0;
                    int32_t *l_810 = &l_752[1][1][3];
                    int32_t *l_811 = (void*)0;
                    int32_t *l_812 = (void*)0;
                    int32_t *l_813[8][1] = {{&g_3},{&g_88[3][0][1]},{&g_3},{&g_88[3][0][1]},{&g_3},{&g_88[3][0][1]},{&g_3},{&g_88[3][0][1]}};
                    const int32_t **l_818 = (void*)0;
                    const int32_t **l_819 = &g_206;
                    int i, j;
                    l_814++;
                    (*l_819) = l_817;
                    for (p_57 = 0; (p_57 <= 1); p_57 += 1)
                    { /* block id: 299 */
                        uint32_t l_821 = 0xB83D421FL;
                        l_821 = ((void*)0 != l_820);
                        if ((*p_56))
                            break;
                        if (l_805)
                            continue;
                        (*l_787) = ((safe_rshift_func_int32_t_s_s_unsafe_macro/*485*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u_unsafe_macro/*486*//* ___SAFE__OP */((((safe_sub_func_uint64_t_u_u_unsafe_macro/*487*//* ___SAFE__OP */(0xE99467C254A7DB4DLL, ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*488*//* ___SAFE__OP */(p_57, 60)) <= ((*g_111)--)))) != 1L) ^ (safe_mul_func_uint16_t_u_u_unsafe_macro/*489*//* ___SAFE__OP */(g_106, (safe_mul_func_int8_t_s_s_unsafe_macro/*490*//* ___SAFE__OP */((*l_817), 0xABL))))))), (safe_add_func_int32_t_s_s_unsafe_macro/*491*//* ___SAFE__OP */((*p_56), ((safe_mul_func_uint64_t_u_u_unsafe_macro/*492*//* ___SAFE__OP */(l_804[1][2], l_805)) != p_55))))) >= p_55);
                    }
                }
                for (g_81 = 0; g_81 < 6; g_81 += 1)
                {
                    for (l_799 = 0; l_799 < 5; l_799 += 1)
                    {
                        for (g_284 = 0; g_284 < 2; g_284 += 1)
                        {
                            g_490[g_81][l_799][g_284] = &g_491;
                        }
                    }
                }
            }
            else
            { /* block id: 308 */
                int32_t *l_839 = &g_88[2][0][1];
                int32_t *l_840 = &g_88[3][0][1];
                int32_t *l_841 = &l_804[0][6];
                int32_t *l_842 = &l_804[0][6];
                int32_t *l_843 = &l_799;
                int32_t *l_844 = &l_752[3][0][8];
                int32_t *l_845 = &g_88[3][0][1];
                int32_t *l_846 = (void*)0;
                int32_t *l_847 = &l_804[0][4];
                int32_t *l_848[9] = {(void*)0,(void*)0,&g_3,(void*)0,(void*)0,&g_3,(void*)0,(void*)0,&g_3};
                uint32_t l_852 = 0x7AAFD90FL;
                int i;
                ++l_852;
                for (g_341 = 0; (g_341 < (-17)); g_341 = safe_sub_func_int16_t_s_s_unsafe_macro/*493*//* ___SAFE__OP */(g_341, 2))
                { /* block id: 312 */
                    uint32_t ***l_869[6];
                    int16_t *l_873 = &l_851;
                    int32_t l_874 = (-1L);
                    uint8_t *l_875 = &l_795;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_869[i] = &l_868;
                    (*l_847) |= ((5UL ^ (safe_rshift_func_uint8_t_u_s_unsafe_macro/*494*//* ___SAFE__OP */(((*l_875) = (safe_add_func_uint64_t_u_u_unsafe_macro/*495*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*496*//* ___SAFE__OP */(((((~((0xEB755AED900EAB4FLL < (p_57 , ((18446744073709551608UL ^ p_57) >= 65531UL))) , (((safe_mod_func_uint8_t_u_u_unsafe_macro/*497*//* ___SAFE__OP */(((((((g_67 >= ((*l_873) = ((1L & (((((safe_rshift_func_uint16_t_u_s_unsafe_macro/*498*//* ___SAFE__OP */((((g_870 = l_868) != l_871) | (-6L)), p_57)) <= l_872[0][1]) > p_55) > 0xEB62DA68L) , p_55)) > g_85))) <= 0xAFD0L) || 0x691A4122D02D5874LL) ^ g_85) != g_344) >= l_874), l_874)) != (*l_845)) , p_57))) <= 0x509BL) > p_57) != 0UL), p_55)), g_85))), 3))) , (*p_56));
                }
            }
            p_55 = (safe_mod_func_uint8_t_u_u_unsafe_macro/*499*//* ___SAFE__OP */((!(safe_sub_func_uint16_t_u_u_unsafe_macro/*500*//* ___SAFE__OP */((((safe_div_func_uint32_t_u_u_unsafe_macro/*501*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*502*//* ___SAFE__OP */(((**g_406) && p_57), (((safe_sub_func_uint8_t_u_u_unsafe_macro/*503*//* ___SAFE__OP */((((*l_912) = (0x51A9L == (safe_sub_func_uint32_t_u_u_unsafe_macro/*504*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*505*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*506*//* ___SAFE__OP */((((!((l_804[0][4] ^= (safe_sub_func_uint64_t_u_u_unsafe_macro/*507*//* ___SAFE__OP */((((**l_871) = ((*l_868) == ((*l_896) = (*l_868)))) > ((*l_787) |= ((safe_lshift_func_int32_t_s_u_unsafe_macro/*508*//* ___SAFE__OP */((p_57 , (-3L)), 3)) < (safe_sub_func_uint32_t_u_u_unsafe_macro/*509*//* ___SAFE__OP */(((safe_lshift_func_uint32_t_u_u_unsafe_macro/*510*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*511*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*512*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*513*//* ___SAFE__OP */((!(*g_569)), 3)), (((*g_407) < p_55) & 18446744073709551615UL))), g_3)), 4)) || p_57), l_850))))), 0L))) && l_851)) , (void*)0) != l_911), l_805)), p_55)) , 4294967295UL), (*g_206))))) & g_137[2]), 5L)) <= 1L) < g_67))), p_55)) >= g_67) > l_805), l_913))), p_57));
            if ((l_914 & ((safe_add_func_uint32_t_u_u_unsafe_macro/*514*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s_unsafe_macro/*515*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*516*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*517*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u_unsafe_macro/*518*//* ___SAFE__OP */(((((safe_rshift_func_uint32_t_u_s_unsafe_macro/*519*//* ___SAFE__OP */(p_57, 8)) != (((((void*)0 != &p_58) > (*g_407)) ^ (((((*l_739) ^= (p_55 > (g_443 == 18446744073709551611UL))) != p_55) , l_929) != l_930)) == 0x9EE8FACAL)) ^ l_805) >= p_57), 7)) <= p_55), 0xE808L)), 5)), g_931)) == 0xEB6E969FC333DC7FLL), (*g_206))) , l_799)))
            { /* block id: 326 */
                uint32_t l_937 = 1UL;
                for (l_814 = 0; (l_814 <= 4); l_814 += 1)
                { /* block id: 329 */
                    int64_t l_950 = 0L;
                    uint16_t *l_960 = (void*)0;
                    uint16_t *l_961[9] = {&g_81,&g_81,&g_287,&g_81,&g_81,&g_287,&g_81,&g_81,&g_287};
                    int32_t l_972[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_972[i] = 7L;
                    for (l_805 = 1; (l_805 <= 4); l_805 += 1)
                    { /* block id: 332 */
                        int16_t *l_932[6][6][1];
                        const int32_t l_951 = (-4L);
                        int i, j, k;
                        for (i = 0; i < 6; i++)
                        {
                            for (j = 0; j < 6; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_932[i][j][k] = &l_851;
                            }
                        }
                        (*l_787) = (((g_933 = (p_57 == p_55)) ^ (0x371AL == (0x4EDBC2C952FF08EALL < (safe_mod_func_uint64_t_u_u_unsafe_macro/*520*//* ___SAFE__OP */(((safe_unary_minus_func_uint32_t_u_unsafe_macro/*521*//* ___SAFE__OP */(p_55)) != l_937), (safe_div_func_uint8_t_u_u_unsafe_macro/*522*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*523*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*524*//* ___SAFE__OP */(0x504ADB9DL, (((safe_add_func_int8_t_s_s_unsafe_macro/*525*//* ___SAFE__OP */(((*l_785) = ((1UL < (safe_add_func_int64_t_s_s_unsafe_macro/*526*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*527*//* ___SAFE__OP */(l_851, (*g_111))), p_55))) == l_950)), g_567)) , 1L) & 0x72743ED0FFF10AE5LL))), 0x2C80L)), p_55))))))) && l_951);
                    }
                    l_804[1][5] &= ((safe_rshift_func_int16_t_s_s_unsafe_macro/*528*//* ___SAFE__OP */(p_57, 15)) != ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*529*//* ___SAFE__OP */((l_950 | p_55), 61)) >= (l_799 = (safe_div_func_int64_t_s_s_unsafe_macro/*530*//* ___SAFE__OP */(p_55, (--(*l_739)))))));
                    if (g_106)
                        goto lbl_999;
                    for (g_171 = 0; (g_171 <= 4); g_171 += 1)
                    { /* block id: 342 */
                        uint32_t l_962[2];
                        int16_t *l_967 = &l_850;
                        int32_t l_973 = 0xE4868557L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_962[i] = 0xC99B0CA8L;
                        l_972[0] = (l_962[1] != (safe_div_func_uint64_t_u_u_unsafe_macro/*531*//* ___SAFE__OP */((g_138 & (safe_lshift_func_uint16_t_u_s_unsafe_macro/*532*//* ___SAFE__OP */(5UL, ((*l_967) |= p_57)))), (safe_rshift_func_uint16_t_u_u_unsafe_macro/*533*//* ___SAFE__OP */((((*l_787) = l_950) ^ ((((((p_57 == 0x7EB9L) >= ((((l_962[0] , ((safe_rshift_func_int64_t_s_u_unsafe_macro/*534*//* ___SAFE__OP */((p_55 < l_937), 44)) < 7L)) < p_55) | l_950) == (-1L))) < l_950) ^ 0x10L) & l_937) , l_937)), l_799)))));
                        ++l_974[2][2][0];
                    }
                }
                (*l_787) = ((!l_937) & ((((((((safe_rshift_func_uint8_t_u_u_unsafe_macro/*535*//* ___SAFE__OP */(((*l_912) = g_138), g_931)) > (2L || l_937)) , ((l_937 , (void*)0) != (p_57 , &l_896))) == l_937) != l_799) , 3L) || (*l_787)) | g_806[1]));
lbl_999:
                for (g_67 = 0; (g_67 <= 42); g_67 = safe_add_func_uint32_t_u_u_unsafe_macro/*536*//* ___SAFE__OP */(g_67, 7))
                { /* block id: 353 */
                    uint16_t l_990 = 1UL;
                    for (l_738 = 29; (l_738 <= 50); l_738 = safe_add_func_int32_t_s_s_unsafe_macro/*537*//* ___SAFE__OP */(l_738, 8))
                    { /* block id: 356 */
                        int32_t l_984 = 0xF0E2F77DL;
                        int32_t *l_985 = &l_752[3][0][8];
                        int32_t *l_986 = &l_752[2][1][9];
                        int32_t *l_987 = &l_849[5];
                        int32_t *l_988 = &l_804[2][4];
                        int32_t *l_989[9][5][1];
                        int i, j, k;
                        for (i = 0; i < 9; i++)
                        {
                            for (j = 0; j < 5; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_989[i][j][k] = &g_88[0][0][0];
                            }
                        }
                        (*l_733) = &p_55;
                        (*l_787) |= (*g_177);
                        if (g_284)
                            goto lbl_999;
                        l_990--;
                        (*g_995) = l_993;
                    }
                    if ((*p_56))
                        break;
                }
                l_804[0][4] |= (safe_add_func_int8_t_s_s_unsafe_macro/*538*//* ___SAFE__OP */(((*l_785) = p_57), g_3));
            }
            else
            { /* block id: 368 */
                int8_t l_1016 = 0L;
                int32_t l_1019 = 1L;
                l_1019 = (((safe_rshift_func_uint32_t_u_s_unsafe_macro/*539*//* ___SAFE__OP */((*g_111), 19)) , &l_723) != (((((safe_lshift_func_uint32_t_u_s_unsafe_macro/*540*//* ___SAFE__OP */((&g_407 == ((((safe_mul_func_int16_t_s_s_unsafe_macro/*541*//* ___SAFE__OP */(g_137[2], ((safe_div_func_uint64_t_u_u_unsafe_macro/*542*//* ___SAFE__OP */(l_799, ((safe_sub_func_int32_t_s_s_unsafe_macro/*543*//* ___SAFE__OP */(1L, (*p_58))) || (safe_mod_func_int16_t_s_s_unsafe_macro/*544*//* ___SAFE__OP */((((*l_912) = ((((--(*l_739)) && ((g_1017 = (l_1016 <= 9UL)) > p_57)) || l_1016) , p_55)) , g_3), g_931))))) < l_804[0][5]))) || 1UL) ^ 2L) , l_1018)), (*g_89))) , p_57) == p_57) , (***g_995)) , (void*)0));
            }
            for (g_786 = 0; (g_786 <= 6); g_786 += 1)
            { /* block id: 376 */
                int64_t l_1048 = 0xC671D5A99EF7BABFLL;
                int32_t l_1075 = 0x94BA6DE6L;
                int32_t *l_1088 = &g_998;
                int32_t l_1095 = (-1L);
                int32_t l_1096 = 0x2033AF75L;
                int32_t l_1097 = (-1L);
                int32_t l_1101 = 4L;
                int32_t l_1102 = 0x20C357F3L;
                int32_t l_1103 = 0xFEC1938DL;
                int32_t l_1104 = (-1L);
                int32_t l_1105 = 0x755DE046L;
                int32_t l_1106[7] = {0x7AF8AEC8L,0x7AF8AEC8L,0xE4E6683CL,0x7AF8AEC8L,0x7AF8AEC8L,0xE4E6683CL,0x7AF8AEC8L};
                uint16_t **l_1151 = &g_702;
                int i;
                for (l_850 = 4; (l_850 >= 0); l_850 -= 1)
                { /* block id: 379 */
                    int64_t *l_1056 = (void*)0;
                    int64_t *l_1057 = &l_1048;
                    uint8_t l_1068 = 0x40L;
                    int16_t *l_1081 = (void*)0;
                    int16_t *l_1082 = &l_851;
                    int i;
                    g_88[3][0][1] &= (((safe_mul_func_int8_t_s_s_unsafe_macro/*545*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*546*//* ___SAFE__OP */(((((safe_add_func_int8_t_s_s_unsafe_macro/*547*//* ___SAFE__OP */(0x3EL, l_849[(l_850 + 2)])) >= (*p_56)) , (((safe_lshift_func_uint64_t_u_u_unsafe_macro/*548*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*549*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_s_unsafe_macro/*550*//* ___SAFE__OP */(l_804[1][0], ((safe_add_func_int32_t_s_s_unsafe_macro/*551*//* ___SAFE__OP */(0L, ((safe_add_func_int32_t_s_s_unsafe_macro/*552*//* ___SAFE__OP */(((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*553*//* ___SAFE__OP */(p_57, (safe_lshift_func_uint8_t_u_s_unsafe_macro/*554*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*555*//* ___SAFE__OP */(p_55, ((((safe_div_func_uint64_t_u_u_unsafe_macro/*556*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*557*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*558*//* ___SAFE__OP */((((l_1048 || (((**g_406) & g_83) , 5UL)) , g_998) >= 9UL), l_784)), p_55)) ^ p_55), 0x503159E90770D798LL)) < 0UL) != (*p_56)) , p_55))), (*g_407))))) ^ l_849[(l_850 + 2)]) && g_341) && g_137[3]), p_57)) && p_57))) > 0x44L))) > 0x0E8BL), (*g_206))), l_849[(l_850 + 2)])) <= l_1049) || (*l_787))) || 0xB47C7D96D1FB7FE5LL), l_804[2][3])), 1L)) , p_57) , (*p_56));
                    (*l_787) = 1L;
                    p_55 = ((safe_mod_func_uint32_t_u_u_unsafe_macro/*559*//* ___SAFE__OP */((((((1UL & (((*l_1082) = ((l_1080 = ((((safe_mul_func_int32_t_s_s_unsafe_macro/*560*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*561*//* ___SAFE__OP */(g_341, ((*l_1057) = p_55))), (*p_56))) || ((safe_sub_func_int64_t_s_s_unsafe_macro/*562*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*563*//* ___SAFE__OP */(g_341, (safe_mul_func_uint32_t_u_u_unsafe_macro/*564*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s_unsafe_macro/*565*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*566*//* ___SAFE__OP */(((*l_739) ^= l_1068), (((safe_sub_func_int16_t_s_s_unsafe_macro/*567*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_u_unsafe_macro/*568*//* ___SAFE__OP */(((safe_div_func_int32_t_s_s_unsafe_macro/*569*//* ___SAFE__OP */(l_1075, (safe_div_func_int64_t_s_s_unsafe_macro/*570*//* ___SAFE__OP */(((*l_1057) = (safe_sub_func_int16_t_s_s_unsafe_macro/*571*//* ___SAFE__OP */(g_67, 0xC27CL))), 0xDAE3D5F6F9ED1C61LL)))) & (*p_56)), 5)), 65529UL)) | 0x8AL) , p_55))) > (*g_111)), 36)), l_804[2][6])))), p_55)) != l_974[2][2][2])) , 65534UL) , (*p_58))) , p_55)) , 18446744073709551609UL)) , 0xE2L) > g_344) ^ 0x24L) & 1L), (*g_206))) | l_1075);
                    for (l_1080 = 0; (l_1080 <= 2); l_1080 += 1)
                    { /* block id: 390 */
                        return (*l_929);
                    }
                }
                for (l_913 = 0; (l_913 <= 1); l_913 += 1)
                { /* block id: 396 */
                    uint16_t *l_1083[5] = {&l_784,&l_784,&l_784,&l_784,&l_784};
                    int32_t l_1098 = 3L;
                    int32_t l_1099 = 0x8E722FC0L;
                    int32_t l_1100[8];
                    uint64_t l_1131 = 0UL;
                    int i;
                    for (i = 0; i < 8; i++)
                        l_1100[i] = 0x9C1220D0L;
                    for (l_850 = 1; (l_850 >= 0); l_850 -= 1)
                    { /* block id: 399 */
                        return &g_284;
                    }
                    if ((safe_mul_func_int16_t_s_s_unsafe_macro/*572*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*573*//* ___SAFE__OP */(l_849[l_913], ((void*)0 == l_1088))), (safe_rshift_func_int64_t_s_u_unsafe_macro/*574*//* ___SAFE__OP */(l_849[l_913], ((*l_739) = p_57))))))
                    { /* block id: 403 */
                        int32_t *l_1091 = &l_752[3][0][8];
                        int32_t *l_1092 = &l_1075;
                        int32_t *l_1093 = &l_849[4];
                        int32_t *l_1094[8];
                        uint8_t l_1107[7][9][1] = {{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}},{{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L},{255UL},{255UL},{0x06L}}};
                        int i, j, k;
                        for (i = 0; i < 8; i++)
                            l_1094[i] = &l_804[0][6];
                        l_1107[6][6][0]++;
                        (**l_734) = &p_55;
                    }
                    else
                    { /* block id: 406 */
                        int64_t l_1118[5][3][7] = {{{5L,0x56270BA4FB19D6E6LL,(-8L),0xD542CAD181743921LL,(-1L),0xD542CAD181743921LL,(-8L)},{0x80C9A123962FD0C5LL,0x80C9A123962FD0C5LL,0x3E335CDA51FB91F3LL,0x7F386D3B8DB698DELL,1L,1L,0x1EAC2BB35715803BLL},{(-4L),0xCC0B52664EFC5643LL,0x4BF51E342C8F64A7LL,0L,5L,3L,0x1567ADD80DD1FE89LL}},{{1L,(-2L),1L,0x1EAC2BB35715803BLL,1L,(-2L),1L},{0L,0xD542CAD181743921LL,0xAB955A3EB9BCB465LL,0x4BF51E342C8F64A7LL,(-1L),0x1567ADD80DD1FE89LL,0L},{0x79676D1FAAC4927ALL,0x6E62485093A411B8LL,0x7F386D3B8DB698DELL,0x80C9A123962FD0C5LL,(-2L),0x505991FAC675BEE8LL,0x505991FAC675BEE8LL}},{{8L,0L,0xCC0B52664EFC5643LL,0L,8L,0x4BF51E342C8F64A7LL,0L},{0L,0x6C9D62A4103BF776LL,(-1L),(-2L),0x79676D1FAAC4927ALL,1L,(-2L)},{0L,(-4L),0xF84879CA2F536798LL,(-8L),0xCC0B52664EFC5643LL,0xCC0B52664EFC5643LL,(-8L)}},{{0L,(-2L),0L,0x3E335CDA51FB91F3LL,0x629E83061722B753LL,0x6E62485093A411B8LL,(-1L)},{8L,3L,0xD542CAD181743921LL,0x4BF51E342C8F64A7LL,(-8L),0L,1L},{1L,0L,0x6E62485093A411B8LL,1L,1L,0x6E62485093A411B8LL,0L}},{{1L,5L,(-1L),0xAB955A3EB9BCB465LL,3L,0xCC0B52664EFC5643LL,0x51CC673C71FD0D7DLL},{(-2L),0x7F386D3B8DB698DELL,1L,(-1L),(-1L),1L,0x80C9A123962FD0C5LL},{0x4BF51E342C8F64A7LL,0xCD0B7D34D3B991CBLL,0xAB955A3EB9BCB465LL,0xAB955A3EB9BCB465LL,0xCD0B7D34D3B991CBLL,0x4BF51E342C8F64A7LL,0L}}};
                        int16_t *l_1130 = &l_851;
                        uint32_t l_1132 = 0x6200EC28L;
                        int32_t l_1133 = (-1L);
                        int i, j, k;
                        (*l_787) |= ((((0xDD4CL > p_57) && 0x46D9L) == ((l_1131 = (safe_rshift_func_uint8_t_u_s_unsafe_macro/*575*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*576*//* ___SAFE__OP */(((4294967288UL || (((safe_mul_func_uint8_t_u_u_unsafe_macro/*577*//* ___SAFE__OP */((((*l_1130) = (safe_div_func_uint16_t_u_u_unsafe_macro/*578*//* ___SAFE__OP */(l_1118[3][0][2], (safe_mod_func_uint8_t_u_u_unsafe_macro/*579*//* ___SAFE__OP */((!(--(*l_739))), (safe_lshift_func_uint32_t_u_u_unsafe_macro/*580*//* ___SAFE__OP */(((255UL < (safe_lshift_func_uint16_t_u_s_unsafe_macro/*581*//* ___SAFE__OP */(p_55, l_1097))) && (safe_rshift_func_uint8_t_u_s_unsafe_macro/*582*//* ___SAFE__OP */(p_57, 0))), 13))))))) == p_57), p_55)) ^ l_1098) | (-5L))) , (-3L)), l_1118[3][0][2])), 1))) ^ g_256)) <= 0L);
                        if (l_1132)
                            break;
                        (*l_787) &= (&g_180 != (void*)0);
                        l_1133 = l_1132;
                    }
                    for (l_1096 = 1; (l_1096 >= 0); l_1096 -= 1)
                    { /* block id: 417 */
                        int i, j, k;
                        l_752[(l_913 + 1)][l_1096][(l_913 + 8)] = (safe_rshift_func_uint8_t_u_s_unsafe_macro/*583*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s_unsafe_macro/*584*//* ___SAFE__OP */(((l_1100[2] = (l_804[0][4] |= (l_752[(l_913 + 1)][l_1096][(l_913 + 7)] < (safe_rshift_func_uint64_t_u_s_unsafe_macro/*585*//* ___SAFE__OP */(((g_806[l_1096] | 1UL) == ((safe_rshift_func_int32_t_s_s_unsafe_macro/*586*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*587*//* ___SAFE__OP */(0x93D111D3L, (--(*g_111)))), (safe_rshift_func_int16_t_s_u_unsafe_macro/*588*//* ___SAFE__OP */(g_786, (5L != (safe_add_func_uint8_t_u_u_unsafe_macro/*589*//* ___SAFE__OP */(g_3, (p_57 >= (!(&l_1100[6] != (void*)0)))))))))) ^ g_341)), 19))))) > p_57), (*p_58))) , 0x03BEL) || l_1131), 7));
                    }
                    for (l_1131 = 0; (l_1131 <= 1); l_1131 += 1)
                    { /* block id: 425 */
                        uint16_t *l_1153 = &g_81;
                        int i, j, k;
                        l_1151 = &l_1083[2];
                        l_752[l_1131][l_1131][(g_786 + 2)] = ((!((*l_912) ^= l_752[(l_1131 + 1)][l_1131][(l_913 + 5)])) | l_752[l_1131][l_913][(l_913 + 2)]);
                        return l_1153;
                    }
                }
            }
        }
    }
    (*l_733) = &p_55;
    return l_751;
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_111 g_5 g_114 g_3 g_67 g_88 g_138 g_83 g_137 g_60 g_205 g_206 g_287 g_81 g_341 g_284 g_406 g_407 g_106 g_85 g_443 g_171 g_178 g_177 g_6 g_256 g_569
 * writes: g_88 g_67 g_106 g_111 g_137 g_83 g_85 g_138 g_287 g_177 g_114 g_5 g_490 g_341 g_318 g_568 g_284 g_171
 */
static int8_t  func_62(uint32_t  p_63)
{ /* block id: 10 */
    const int16_t l_86 = 1L;
    uint8_t *l_104 = &g_67;
    int32_t l_115[3][8][6] = {{{0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL,0xDAEFF8EEL},{0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L,0xE6A276D0L,0xA7320B69L},{0xA7320B69L,0xE6A276D0L,0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L},{0xDAEFF8EEL,0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL},{0x584DF831L,0xE6A276D0L,0x599F3DF3L,0x599F3DF3L,0xE6A276D0L,0x584DF831L},{0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL,0xDAEFF8EEL},{0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L,0xE6A276D0L,0xA7320B69L},{0xA7320B69L,0xE6A276D0L,0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L}},{{0xDAEFF8EEL,0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL},{0x584DF831L,0xE6A276D0L,0x599F3DF3L,0x599F3DF3L,0xE6A276D0L,0x584DF831L},{0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL,0xDAEFF8EEL},{0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L,0xE6A276D0L,0xA7320B69L},{0xA7320B69L,0xE6A276D0L,0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L},{0xDAEFF8EEL,0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL},{0x584DF831L,0xE6A276D0L,0x599F3DF3L,0x599F3DF3L,0xE6A276D0L,0x584DF831L},{0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL,0xDAEFF8EEL}},{{0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L,0xE6A276D0L,0xA7320B69L},{0xA7320B69L,0xE6A276D0L,0xA7320B69L,0x584DF831L,0x584DF831L,0xA7320B69L},{0xDAEFF8EEL,0xDAEFF8EEL,0x584DF831L,0x599F3DF3L,0x584DF831L,0xDAEFF8EEL},{0x584DF831L,0xE6A276D0L,0x599F3DF3L,0x599F3DF3L,0xE6A276D0L,0x584DF831L},{0xDAEFF8EEL,0x584DF831L,0xE6A276D0L,0xA7320B69L,0x584DF831L,0x584DF831L},{0x599F3DF3L,0xA7320B69L,0xA7320B69L,0x599F3DF3L,0xDAEFF8EEL,0x599F3DF3L},{0x599F3DF3L,0xDAEFF8EEL,0x599F3DF3L,0xA7320B69L,0xA7320B69L,0x599F3DF3L},{0x584DF831L,0x584DF831L,0xA7320B69L,0xE6A276D0L,0xA7320B69L,0x584DF831L}}};
    uint32_t l_135 = 0x0925A641L;
    int8_t *l_164 = &g_114;
    int8_t *l_166 = &g_114;
    uint32_t **l_281 = &g_111;
    int32_t l_330[5][7][6] = {{{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L},{1L,7L,0xF55DB20FL,7L,1L,(-1L)},{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL},{0xD297B412L,0xAC9608DBL,0xA6035907L,7L,(-1L),0x2D1BC9CAL},{1L,(-1L),0x3E406031L,5L,(-1L),(-1L)},{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L},{1L,7L,0xF55DB20FL,7L,1L,(-1L)}},{{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL},{0xD297B412L,0xAC9608DBL,0xA6035907L,7L,(-1L),0x2D1BC9CAL},{1L,(-1L),0x3E406031L,5L,(-1L),(-1L)},{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L},{1L,7L,0xF55DB20FL,7L,1L,(-1L)},{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL},{0xD297B412L,0xAC9608DBL,0xA6035907L,7L,(-1L),0x2D1BC9CAL}},{{1L,(-1L),0x3E406031L,5L,(-1L),(-1L)},{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L},{1L,7L,0xF55DB20FL,7L,1L,(-1L)},{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL},{0xD297B412L,0xAC9608DBL,0xA6035907L,7L,(-1L),0x2D1BC9CAL},{1L,(-1L),0x3E406031L,5L,(-1L),(-1L)},{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L}},{{1L,7L,0xF55DB20FL,7L,1L,(-1L)},{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL},{0xD297B412L,0xAC9608DBL,0xA6035907L,7L,(-1L),0x2D1BC9CAL},{1L,(-1L),0x3E406031L,5L,(-1L),(-1L)},{(-1L),0xAC9608DBL,0xF55DB20FL,5L,0L,0L},{1L,7L,0xF55DB20FL,7L,1L,(-1L)},{0xD297B412L,7L,0x3E406031L,0x3F7FB9CFL,0L,0x2D1BC9CAL}},{{0xE0FBD0E1L,(-9L),0xB9AF1AAAL,0xDC0B329DL,0L,5L},{0x16B41D62L,(-1L),0xD297B412L,0x4B4E9711L,0L,7L},{0L,(-9L),0L,0x4B4E9711L,(-9L),0x3F7FB9CFL},{0x16B41D62L,0xDC0B329DL,0L,0xDC0B329DL,0x16B41D62L,7L},{0xE0FBD0E1L,0xDC0B329DL,0xD297B412L,(-1L),(-9L),5L},{0xE0FBD0E1L,(-9L),0xB9AF1AAAL,0xDC0B329DL,0L,5L},{0x16B41D62L,(-1L),0xD297B412L,0x4B4E9711L,0L,7L}}};
    int8_t **l_409 = (void*)0;
    int8_t ***l_408 = &l_409;
    int32_t l_456 = 0xB86F9420L;
    uint8_t l_479 = 2UL;
    uint64_t * const *l_486 = &g_319;
    uint32_t l_557 = 2UL;
    uint16_t l_578[2];
    int32_t l_582[4] = {0xE703BB9DL,0xE703BB9DL,0xE703BB9DL,0xE703BB9DL};
    int32_t *l_692 = &l_330[1][5][4];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_578[i] = 65535UL;
lbl_175:
    (*g_89) = l_86;
    for (g_67 = (-16); (g_67 != 36); g_67 = safe_add_func_uint16_t_u_u_unsafe_macro/*590*//* ___SAFE__OP */(g_67, 1))
    { /* block id: 14 */
        int8_t *l_105 = &g_106;
        uint32_t **l_112 = &g_111;
        int8_t *l_113[10][2] = {{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114},{&g_114,&g_114}};
        int32_t l_116 = 0x5C2614ACL;
        int32_t *l_117 = &g_88[2][0][1];
        int i, j;
        (*l_117) = ((safe_div_func_uint16_t_u_u_unsafe_macro/*591*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*592*//* ___SAFE__OP */(((l_86 <= 0x582DL) != 0x6B0CL), ((safe_mod_func_uint64_t_u_u_unsafe_macro/*593*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*594*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_u_unsafe_macro/*595*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*596*//* ___SAFE__OP */(((void*)0 != l_104), ((*l_105) = 0x18L))), 51)) < ((l_115[2][5][0] = ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*597*//* ___SAFE__OP */(((safe_lshift_func_int16_t_s_u_unsafe_macro/*598*//* ___SAFE__OP */(1L, (&g_83 != ((*l_112) = g_111)))) != g_5), 20)) , p_63)) >= 0xEEL)), g_114)), p_63)) || l_116))), 1UL)) ^ g_114);
    }
    for (g_67 = 0; (g_67 < 20); ++g_67)
    { /* block id: 22 */
        int16_t l_120 = 0xDC5EL;
        uint64_t *l_136 = &g_137[2];
        int32_t *l_139 = &g_88[1][0][0];
        volatile int32_t *l_174 = &g_5;
        int32_t l_215 = 0x5D3BFB39L;
        int32_t l_222 = (-7L);
        int32_t l_226 = 9L;
        int32_t l_228 = 1L;
        int32_t l_229 = 0x14671A0EL;
        uint32_t l_258 = 0xA2E6060EL;
        uint16_t l_259 = 7UL;
        int8_t l_419 = 0xA9L;
        int32_t l_427 = 0xEEB07A1AL;
        int32_t l_430 = 4L;
        int32_t **** const *l_546 = (void*)0;
        uint8_t l_583 = 0x5DL;
        uint64_t *** const l_600 = &g_318;
        uint32_t **l_617 = &g_111;
        if (l_120)
            break;
        (*l_139) = ((0x9E9DC621C653C2ADLL & (((safe_add_func_uint64_t_u_u_unsafe_macro/*599*//* ___SAFE__OP */((4UL ^ ((g_3 < l_115[2][5][0]) >= (safe_add_func_int8_t_s_s_unsafe_macro/*600*//* ___SAFE__OP */(g_67, 0xDBL)))), 1L)) & (((safe_lshift_func_int32_t_s_s_unsafe_macro/*601*//* ___SAFE__OP */((((((safe_mul_func_int32_t_s_s_unsafe_macro/*602*//* ___SAFE__OP */((((&p_63 == (((*l_136) = (safe_rshift_func_uint64_t_u_u_unsafe_macro/*603*//* ___SAFE__OP */(((void*)0 != &g_114), l_135))) , &p_63)) & 0x801F5D8E54FB1927LL) && 0xA81A3A0DL), p_63)) == p_63) && l_120) && 0x5DL) , (*g_89)), l_86)) || p_63) != l_120)) < g_138)) , 0x9AD4046EL);
        if ((((*g_111) |= (p_63 , (8L < (g_88[2][0][0] || ((safe_sub_func_int16_t_s_s_unsafe_macro/*604*//* ___SAFE__OP */(p_63, 5UL)) || l_135))))) == (((((safe_mul_func_uint32_t_u_u_unsafe_macro/*605*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*606*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*607*//* ___SAFE__OP */((l_115[0][6][3] = (safe_rshift_func_uint32_t_u_s_unsafe_macro/*608*//* ___SAFE__OP */((l_136 != l_136), 31))), ((safe_mod_func_int64_t_s_s_unsafe_macro/*609*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s_unsafe_macro/*610*//* ___SAFE__OP */(((g_137[2] || p_63) != 7L), 2)), l_86)) != l_86))), g_67)), l_86)) > g_67) , 1L) <= g_137[0]) , (*g_89))))
        { /* block id: 28 */
            const int32_t l_172 = 0x97DF8BE5L;
            uint64_t l_186[5] = {0x1DCDCBB970F0A5B6LL,0x1DCDCBB970F0A5B6LL,0x1DCDCBB970F0A5B6LL,0x1DCDCBB970F0A5B6LL,0x1DCDCBB970F0A5B6LL};
            uint32_t * const *l_199 = &g_111;
            int32_t l_216 = 0xDE322FC8L;
            int32_t l_218 = 0x45AB6F4DL;
            int32_t l_225 = 8L;
            int32_t l_231 = 0xD68A634AL;
            int16_t l_232 = 0x0EF6L;
            int32_t l_234 = 0xCF7C3CB9L;
            int32_t l_235[10][8] = {{0x730DB234L,0x551B8815L,0L,0x730DB234L,0L,0L,0L,0L},{0L,0L,0L,0L,0x730DB234L,0L,0x551B8815L,0x730DB234L},{0L,0x551B8815L,0x3E42A8C7L,0L,0L,0x3E42A8C7L,0x551B8815L,0L},{0x730DB234L,0x551B8815L,0L,0x730DB234L,0L,0L,0L,0L},{0L,0L,0L,0L,0x730DB234L,0L,0x551B8815L,0x730DB234L},{0L,0x551B8815L,0x3E42A8C7L,0L,0L,0x3E42A8C7L,0x551B8815L,0L},{0x730DB234L,0x551B8815L,0L,0x730DB234L,0L,0L,0L,0L},{0L,0L,0L,0L,0x730DB234L,0L,0x551B8815L,0x730DB234L},{0L,0x551B8815L,0x3E42A8C7L,0L,0L,0x3E42A8C7L,0x551B8815L,0L},{0x730DB234L,0x551B8815L,0L,0x730DB234L,0L,0L,0L,0L}};
            uint64_t l_308 = 0UL;
            uint8_t *l_339 = &g_138;
            int32_t **l_351 = (void*)0;
            int32_t ***l_350 = &l_351;
            int32_t ****l_349[10][3] = {{&l_350,(void*)0,(void*)0},{(void*)0,&l_350,&l_350},{&l_350,(void*)0,(void*)0},{(void*)0,&l_350,&l_350},{&l_350,(void*)0,(void*)0},{(void*)0,&l_350,&l_350},{&l_350,(void*)0,(void*)0},{(void*)0,&l_350,&l_350},{&l_350,(void*)0,(void*)0},{(void*)0,&l_350,&l_350}};
            int32_t *****l_348 = &l_349[8][0];
            int i, j;
            for (g_106 = 1; (g_106 <= 7); g_106 += 1)
            { /* block id: 31 */
                int8_t **l_165[1];
                uint64_t *l_170 = &g_171;
                volatile int32_t ** volatile *l_181 = (void*)0;
                uint32_t ** const l_198[10] = {&g_111,&g_111,&g_111,(void*)0,&g_111,&g_111,&g_111,&g_111,(void*)0,&g_111};
                int32_t l_217 = 0xEB5F6837L;
                int32_t l_219 = 0L;
                int32_t l_223 = 0L;
                int32_t l_224 = 0x434410D6L;
                int32_t l_227 = 1L;
                int32_t l_230 = 0x28F2B3A5L;
                int32_t l_233 = 1L;
                const uint32_t l_288 = 0x077A0422L;
                int i;
                for (i = 0; i < 1; i++)
                    l_165[i] = (void*)0;
            }
            for (l_120 = 20; (l_120 > 28); l_120 = safe_add_func_int32_t_s_s_unsafe_macro/*611*//* ___SAFE__OP */(l_120, 5))
            { /* block id: 106 */
                for (l_258 = (-7); (l_258 == 16); ++l_258)
                { /* block id: 109 */
                    int32_t *l_357 = &l_226;
                    for (g_85 = 0; (g_85 <= 4); g_85 += 1)
                    { /* block id: 112 */
                        int32_t *l_356 = &l_231;
                        const int8_t * const l_360 = &g_106;
                        const int8_t * const *l_359 = &l_360;
                        const int8_t * const **l_358 = &l_359;
                        l_357 = l_356;
                        (*l_358) = (void*)0;
                    }
                    for (g_138 = 21; (g_138 > 21); g_138 = safe_add_func_int16_t_s_s_unsafe_macro/*612*//* ___SAFE__OP */(g_138, 1))
                    { /* block id: 118 */
                        return g_60;
                    }
                }
                (*l_139) = (**g_205);
            }
        }
        else
        { /* block id: 124 */
            uint32_t l_368 = 4294967289UL;
            uint32_t **l_410 = &g_111;
            int32_t l_411 = 9L;
            int32_t l_413 = 0x941DC917L;
            int32_t l_414 = 0x3CE270EBL;
            int32_t l_417 = 0x79BC4A57L;
            int32_t l_418 = 0x74DEC6D6L;
            int32_t l_425 = 0L;
            int32_t l_428 = 1L;
            int32_t l_478 = 0x62943D1CL;
            const uint64_t *l_488 = &g_137[4];
            const uint64_t **l_487 = &l_488;
            int8_t l_507 = 0xD0L;
            int8_t ***l_523 = &l_409;
            const int8_t *l_566 = &g_567;
            const int8_t **l_565 = &l_566;
            uint32_t l_576 = 0x51A05AE7L;
            int32_t l_594[10][6] = {{(-1L),(-1L),(-8L),(-1L),(-1L),9L},{(-1L),(-1L),9L,9L,(-1L),(-1L)},{0L,(-1L),0xC8CFD391L,(-1L),0xC8CFD391L,(-1L)},{0xC8CFD391L,0L,9L,(-8L),(-8L),9L},{0xC8CFD391L,0xC8CFD391L,(-8L),(-1L),0xC150FF79L,(-1L)},{0L,0xC8CFD391L,0L,9L,(-8L),(-8L)},{(-1L),0L,0L,(-1L),0xC8CFD391L,(-1L)},{(-1L),(-1L),(-8L),(-1L),(-1L),9L},{(-1L),(-1L),9L,9L,(-1L),(-1L)},{0L,(-1L),0xC8CFD391L,(-1L),0xC8CFD391L,(-1L)}};
            int32_t **l_598 = &g_177;
            int i, j;
            for (g_287 = 1; (g_287 <= 7); g_287 += 1)
            { /* block id: 127 */
                int32_t l_363 = 0x8342909EL;
                int8_t **l_405[2][10][4] = {{{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0}},{{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_164,(void*)0},{(void*)0,&l_164,&l_166,(void*)0}}};
                int8_t *** const l_404 = &l_405[1][5][0];
                int32_t l_415 = (-3L);
                int32_t l_416 = 5L;
                int32_t l_421 = 0L;
                int32_t l_424[8][3][2] = {{{0L,2L},{0L,1L},{1L,2L}},{{1L,1L},{0L,2L},{0L,1L}},{{1L,2L},{1L,1L},{0L,2L}},{{0L,1L},{1L,2L},{1L,1L}},{{0L,2L},{0L,1L},{1L,2L}},{{1L,1L},{0L,2L},{0L,1L}},{{1L,2L},{1L,1L},{0L,2L}},{{0L,1L},{1L,2L},{1L,1L}}};
                uint8_t l_431 = 255UL;
                int32_t l_471 = 0L;
                uint8_t l_512 = 255UL;
                const int32_t l_558 = 1L;
                uint32_t *l_592[2];
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_592[i] = &l_368;
                (*l_139) &= (*l_174);
                if ((l_363 && p_63))
                { /* block id: 129 */
                    int16_t *l_371 = &l_120;
                    uint16_t *l_372 = &l_259;
                    int32_t l_383 = 0x6C3AD2EFL;
                    int32_t l_420 = (-10L);
                    int32_t l_422 = 0x83EA0A88L;
                    int32_t l_423 = 0x33A2C637L;
                    int32_t l_429[9][6] = {{4L,(-1L),0L,0L,0x707B3AF8L,1L},{(-1L),1L,0xA7F14450L,0x707B3AF8L,0xA7F14450L,1L},{0xA7F14450L,(-1L),0L,8L,8L,0L},{0xA7F14450L,0xA7F14450L,8L,0x707B3AF8L,4L,0x707B3AF8L},{(-1L),0xA7F14450L,(-1L),0L,8L,8L},{1L,(-1L),(-1L),1L,0xA7F14450L,0x707B3AF8L},{0x707B3AF8L,1L,8L,1L,0x707B3AF8L,0L},{1L,0x707B3AF8L,0L,0L,0x707B3AF8L,1L},{(-1L),1L,0xA7F14450L,0x707B3AF8L,0xA7F14450L,1L}};
                    int32_t *l_476[5] = {&l_115[2][5][0],&l_115[2][5][0],&l_115[2][5][0],&l_115[2][5][0],&l_115[2][5][0]};
                    int i, j;
                    if ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*613*//* ___SAFE__OP */((g_137[g_287] = (p_63 && (*g_206))), (safe_add_func_int32_t_s_s_unsafe_macro/*614*//* ___SAFE__OP */((l_368 == ((*l_372) ^= (safe_mod_func_int16_t_s_s_unsafe_macro/*615*//* ___SAFE__OP */((g_81 , ((*l_371) = g_81)), (*l_139))))), (safe_mul_func_int16_t_s_s_unsafe_macro/*616*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_s_unsafe_macro/*617*//* ___SAFE__OP */(((safe_rshift_func_uint8_t_u_u_unsafe_macro/*618*//* ___SAFE__OP */(((g_341 >= ((*l_139) != (((safe_add_func_uint8_t_u_u_unsafe_macro/*619*//* ___SAFE__OP */(((safe_div_func_int16_t_s_s_unsafe_macro/*620*//* ___SAFE__OP */(((g_81 , l_383) >= (-4L)), g_67)) ^ 0xD9AD2610L), g_284)) != g_88[1][0][0]) , p_63))) || 5L), l_363)) != g_138), l_363)) == g_5), g_138)))))))
                    { /* block id: 133 */
                        (*l_139) = (safe_div_func_uint64_t_u_u_unsafe_macro/*621*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*622*//* ___SAFE__OP */(((((safe_rshift_func_uint8_t_u_s_unsafe_macro/*623*//* ___SAFE__OP */(((p_63 || ((*l_371) |= (((g_284 | ((safe_sub_func_uint64_t_u_u_unsafe_macro/*624*//* ___SAFE__OP */(((safe_sub_func_uint8_t_u_u_unsafe_macro/*625*//* ___SAFE__OP */(248UL, (safe_rshift_func_int8_t_s_u_unsafe_macro/*626*//* ___SAFE__OP */(l_368, 1)))) , p_63), (l_411 |= (safe_div_func_int64_t_s_s_unsafe_macro/*627*//* ___SAFE__OP */(((0x27FCC671L < (safe_lshift_func_uint16_t_u_s_unsafe_macro/*628*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*629*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u_unsafe_macro/*630*//* ___SAFE__OP */((((((((((l_404 == ((g_406 != &g_407) , l_408)) , 255UL) , 0xC272FBF6197B71F3LL) , p_63) , 0x07L) , 0x01BBE4BEL) , l_410) != (void*)0) <= p_63), (*g_407))) < 0x8CL), p_63)), 0))) > 2UL), 18446744073709551615UL))))) , 18446744073709551614UL)) != g_85) , g_106))) , l_363), 4)) > l_363) == g_341) >= p_63), 8)), p_63));
                    }
                    else
                    { /* block id: 137 */
                        int32_t *l_412[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int64_t l_426 = 2L;
                        uint32_t *l_453 = &l_368;
                        int i;
                        (*l_139) = l_330[3][3][3];
                        --l_431;
                        l_456 |= (safe_add_func_int64_t_s_s_unsafe_macro/*631*//* ___SAFE__OP */((~(p_63 || (safe_mul_func_int64_t_s_s_unsafe_macro/*632*//* ___SAFE__OP */(0xAB30C8E3E57D41B5LL, ((*l_136)--))))), (l_411 = ((safe_rshift_func_int32_t_s_s_unsafe_macro/*633*//* ___SAFE__OP */(g_443, ((*l_139) = (safe_unary_minus_func_uint64_t_u_unsafe_macro/*634*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u_unsafe_macro/*635*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*636*//* ___SAFE__OP */(((*g_111) && 0x6BD0EFF9L), 38))))))))) >= (safe_lshift_func_uint64_t_u_u_unsafe_macro/*637*//* ___SAFE__OP */((g_85 | (safe_div_func_int32_t_s_s_unsafe_macro/*638*//* ___SAFE__OP */(((!g_171) && 0x23L), (--(*l_453))))), 33))))));
                    }
                    for (l_363 = 0; (l_363 <= 4); l_363 += 1)
                    { /* block id: 148 */
                        uint32_t l_459[1][4];
                        int32_t **l_474 = &g_177;
                        int32_t **l_475[4];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 4; j++)
                                l_459[i][j] = 0x1D1E1F2AL;
                        }
                        for (i = 0; i < 4; i++)
                            l_475[i] = &l_139;
                        (*l_174) = (((safe_rshift_func_int16_t_s_u_unsafe_macro/*639*//* ___SAFE__OP */(g_341, l_459[0][2])) || (~g_60)) || (((safe_lshift_func_int16_t_s_u_unsafe_macro/*640*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*641*//* ___SAFE__OP */(((safe_mod_func_uint16_t_u_u_unsafe_macro/*642*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*643*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*644*//* ___SAFE__OP */(l_471, (safe_lshift_func_uint32_t_u_u_unsafe_macro/*645*//* ___SAFE__OP */((((((((p_63 ^ (((*l_166) &= (((*l_474) = (*g_178)) != (l_476[3] = (void*)0))) , l_115[2][5][3])) , g_6) >= g_88[3][0][1]) < 0x2FFAFC6703545E39LL) < l_416) != g_106) != p_63), 24)))), (*g_206))), 0x4CB1L)) , (*g_111)), (*g_206))), g_106)) && 0UL) , p_63));
                        return p_63;
                    }
                }
                else
                { /* block id: 155 */
                    int32_t *l_477[2][5][5] = {{{(void*)0,&l_425,&l_425,(void*)0,(void*)0},{&l_413,&l_425,&l_425,&l_413,&l_417},{(void*)0,&l_425,&l_425,(void*)0,(void*)0},{&l_413,&l_425,&l_425,&l_413,&l_417},{(void*)0,&l_425,&l_425,(void*)0,(void*)0}},{{&l_413,&l_425,&l_425,&l_413,&l_417},{(void*)0,&l_425,&l_425,(void*)0,(void*)0},{&l_413,&l_425,&l_425,&l_413,&l_417},{(void*)0,&l_425,&l_425,(void*)0,(void*)0},{&l_413,&l_425,&l_425,&l_413,&l_417}}};
                    const uint64_t ***l_489[3];
                    uint32_t l_510[3][10] = {{0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL,0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL},{0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL,0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL},{0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL,0x36715649L,0xC0D5100BL,0xC0D5100BL,0x36715649L,18446744073709551611UL}};
                    int64_t *l_511[7];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_489[i] = &l_487;
                    for (i = 0; i < 7; i++)
                        l_511[i] = &g_341;
                    l_479++;
                    (*l_174) = (safe_sub_func_int64_t_s_s_unsafe_macro/*646*//* ___SAFE__OP */((g_256 == ((safe_add_func_uint32_t_u_u_unsafe_macro/*647*//* ___SAFE__OP */((((l_486 != (g_490[3][2][1] = l_487)) == (*l_139)) && (safe_rshift_func_int8_t_s_s_unsafe_macro/*648*//* ___SAFE__OP */((~(safe_div_func_int8_t_s_s_unsafe_macro/*649*//* ___SAFE__OP */((((((void*)0 == &l_330[2][5][3]) | (safe_div_func_int16_t_s_s_unsafe_macro/*650*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*651*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*652*//* ___SAFE__OP */(((((*l_139) = (safe_lshift_func_int16_t_s_s_unsafe_macro/*653*//* ___SAFE__OP */((p_63 || (0x7D4E932CL || ((*g_111)++))), (l_86 , 0L)))) ^ g_3) | p_63), 0x814A8E7D9123E0B6LL)), (-9L))), 0x2124L))) , p_63) , (-4L)), p_63))), l_507))), (*g_206))) , 0x653D2BDE94D0BBD6LL)), p_63));
                    (*l_139) &= (((*l_136) = (safe_lshift_func_uint64_t_u_s_unsafe_macro/*654*//* ___SAFE__OP */(0x606FC67D272D4C25LL, (g_341 &= l_510[0][7])))) < l_512);
                    (*l_408) = ((*l_404) = &g_407);
                }
                for (l_368 = 0; (l_368 <= 0); l_368 += 1)
                { /* block id: 169 */
                    uint32_t l_521 = 0xCD69C878L;
                    int32_t ***l_549 = (void*)0;
                    int32_t ****l_548 = &l_549;
                    int32_t *****l_547[9][5][4] = {{{&l_548,(void*)0,&l_548,(void*)0},{&l_548,&l_548,&l_548,&l_548},{(void*)0,&l_548,&l_548,(void*)0},{&l_548,&l_548,(void*)0,&l_548},{&l_548,&l_548,&l_548,&l_548}},{{&l_548,(void*)0,&l_548,(void*)0},{&l_548,&l_548,&l_548,&l_548},{(void*)0,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,(void*)0,(void*)0}},{{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,(void*)0,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548}},{{&l_548,(void*)0,&l_548,(void*)0},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{(void*)0,(void*)0,(void*)0,&l_548},{&l_548,&l_548,(void*)0,&l_548}},{{&l_548,(void*)0,&l_548,(void*)0},{&l_548,(void*)0,&l_548,&l_548},{(void*)0,&l_548,&l_548,&l_548},{&l_548,(void*)0,(void*)0,&l_548},{&l_548,&l_548,(void*)0,&l_548}},{{(void*)0,&l_548,&l_548,(void*)0},{(void*)0,(void*)0,&l_548,&l_548},{(void*)0,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{(void*)0,&l_548,&l_548,&l_548}},{{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,(void*)0,&l_548},{&l_548,&l_548,&l_548,&l_548}},{{&l_548,&l_548,(void*)0,(void*)0},{&l_548,(void*)0,&l_548,&l_548},{&l_548,&l_548,(void*)0,&l_548},{&l_548,&l_548,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548}},{{&l_548,&l_548,(void*)0,&l_548},{(void*)0,(void*)0,&l_548,&l_548},{&l_548,&l_548,&l_548,&l_548},{(void*)0,(void*)0,(void*)0,&l_548},{&l_548,&l_548,&l_548,&l_548}}};
                    uint64_t ***l_554 = &g_318;
                    const int8_t *l_563[1][10][3] = {{{(void*)0,&l_419,&l_419},{&l_419,&g_114,&l_419},{(void*)0,&g_114,(void*)0},{&l_419,&l_419,&l_419},{&l_419,&l_419,&l_419},{(void*)0,&l_419,&l_419},{&l_419,&g_114,&l_419},{(void*)0,&g_114,(void*)0},{&l_419,&l_419,&l_419},{&l_419,&l_419,&l_419}}};
                    const int8_t **l_562 = &l_563[0][4][1];
                    int16_t l_577 = 0x36F4L;
                    int32_t *l_588 = &l_416;
                    int64_t l_593 = 0xBB5D6E20A448BCF3LL;
                    uint16_t l_595[2];
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_595[i] = 0x114EL;
                    if (g_88[l_368][l_368][(l_368 + 1)])
                    { /* block id: 170 */
                        int i, j, k;
                        l_115[l_368][(l_368 + 2)][(l_368 + 1)] ^= ((safe_rshift_func_int16_t_s_s_unsafe_macro/*655*//* ___SAFE__OP */(0L, 13)) & g_88[(l_368 + 1)][l_368][(l_368 + 1)]);
                    }
                    else
                    { /* block id: 172 */
                        uint64_t l_532 = 0x0AFB3C50344CFDE7LL;
                        int32_t *l_533 = &l_215;
                        (*l_533) |= (0x2EL != (safe_mod_func_int8_t_s_s_unsafe_macro/*656*//* ___SAFE__OP */((((*l_166) |= (safe_rshift_func_int32_t_s_s_unsafe_macro/*657*//* ___SAFE__OP */(l_424[7][2][1], 0))) <= ((*g_89) || ((*l_139) &= l_421))), (safe_mod_func_uint16_t_u_u_unsafe_macro/*658*//* ___SAFE__OP */(((l_521 && (!(l_523 == (void*)0))) & (safe_mul_func_int64_t_s_s_unsafe_macro/*659*//* ___SAFE__OP */(l_521, (safe_sub_func_int32_t_s_s_unsafe_macro/*660*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*661*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*662*//* ___SAFE__OP */((l_532 ^= g_3), p_63)) | (-1L)), (*g_407))) | 18446744073709551615UL), p_63))))), 0x76F6L)))));
                        if (l_512)
                            goto lbl_175;
                    }
                    if ((safe_sub_func_uint16_t_u_u_unsafe_macro/*663*//* ___SAFE__OP */((((*g_111) ^= ((safe_lshift_func_int64_t_s_s_unsafe_macro/*664*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*665*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*666*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*667*//* ___SAFE__OP */(g_284, (safe_rshift_func_uint16_t_u_s_unsafe_macro/*668*//* ___SAFE__OP */(((((l_546 != (l_521 , l_547[7][3][3])) > (safe_div_func_uint8_t_u_u_unsafe_macro/*669*//* ___SAFE__OP */(((*l_174) <= (safe_sub_func_uint32_t_u_u_unsafe_macro/*670*//* ___SAFE__OP */((3UL >= (-1L)), (((*l_554) = &g_319) != ((safe_lshift_func_uint8_t_u_u_unsafe_macro/*671*//* ___SAFE__OP */(((&l_488 != &g_491) || 4294967292UL), l_557)) , (void*)0))))), l_115[1][5][1]))) , (void*)0) == &l_136), l_558)))), p_63)), (*g_206))), 32)) , p_63)) > 0xD35E9979L), l_428)))
                    { /* block id: 181 */
                        uint8_t l_559[9][5] = {{246UL,255UL,246UL,255UL,246UL},{255UL,247UL,247UL,255UL,255UL},{253UL,255UL,253UL,255UL,253UL},{255UL,255UL,247UL,247UL,255UL},{246UL,255UL,246UL,255UL,246UL},{255UL,247UL,247UL,255UL,255UL},{253UL,255UL,253UL,255UL,253UL},{255UL,255UL,247UL,247UL,255UL},{246UL,255UL,246UL,255UL,246UL}};
                        const int8_t ***l_564[1];
                        int32_t l_579 = 0x873BCF1FL;
                        int32_t l_580 = (-3L);
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_564[i] = &l_562;
                        --l_559[5][3];
                        g_568 = (l_565 = l_562);
                        l_580 = (l_579 ^= ((0x37L != ((safe_lshift_func_int32_t_s_s_unsafe_macro/*672*//* ___SAFE__OP */((((((-1L) >= 7UL) > p_63) != (g_81 >= (&g_83 != &p_63))) <= (((*l_136) &= ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*673*//* ___SAFE__OP */(g_114, (((((*l_139) > 0xDDB6L) <= l_576) || l_577) > 0x617DL))) & l_578[0])) > l_559[5][3])), p_63)) == p_63)) > p_63));
                        if (l_478)
                            continue;
                    }
                    else
                    { /* block id: 189 */
                        int16_t l_581 = 0x3A7BL;
                        if (l_512)
                            goto lbl_175;
                        --l_583;
                    }
                    for (g_284 = 0; (g_284 != 8); g_284 = safe_add_func_uint16_t_u_u_unsafe_macro/*674*//* ___SAFE__OP */(g_284, 8))
                    { /* block id: 195 */
                        int32_t *l_589 = &l_416;
                        l_589 = l_588;
                        (*l_174) = p_63;
                        (*l_139) ^= (safe_div_func_int8_t_s_s_unsafe_macro/*675*//* ___SAFE__OP */(((*l_166) = (((((**g_406) & (&g_83 == ((2UL & l_418) , l_592[0]))) > (-1L)) >= 0x51F3L) ^ (p_63 , ((((0L && p_63) ^ g_60) | 4L) <= p_63)))), 7UL));
                        if ((**g_205))
                            break;
                    }
                    l_595[1]++;
                }
            }
            (*l_598) = &l_115[1][6][2];
            (*l_174) = ((0xF1L > ((**l_598) > ((safe_unary_minus_func_int32_t_s_unsafe_macro/*676*//* ___SAFE__OP */(((void*)0 != l_600))) , (((*g_111) && 1UL) && ((+p_63) , (safe_div_func_uint32_t_u_u_unsafe_macro/*677*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*678*//* ___SAFE__OP */((0x4CF0F075L || (((safe_sub_func_uint64_t_u_u_unsafe_macro/*679*//* ___SAFE__OP */(((safe_div_func_int8_t_s_s_unsafe_macro/*680*//* ___SAFE__OP */((safe_unary_minus_func_int32_t_s_unsafe_macro/*681*//* ___SAFE__OP */((*g_177))), g_5)) ^ (*g_569)), p_63)) , p_63) , l_557)), 29)), p_63))))))) , (*l_174));
        }
        for (l_228 = (-6); (l_228 <= (-21)); l_228 = safe_sub_func_uint8_t_u_u_unsafe_macro/*682*//* ___SAFE__OP */(l_228, 7))
        { /* block id: 210 */
            uint32_t **l_615[1][10];
            int32_t l_631 = 0x5E2D5ECDL;
            uint64_t l_680 = 18446744073709551607UL;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 10; j++)
                    l_615[i][j] = (void*)0;
            }
            for (g_171 = (-15); (g_171 > 46); ++g_171)
            { /* block id: 213 */
                uint8_t *l_626 = &l_583;
                int32_t l_667 = 0L;
                int32_t l_677 = 1L;
            }
        }
    }
    return (**g_406);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_88[i][j][k], "g_88[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_137[i], "g_137[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_256, "g_256", print_hash_value);
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_287, "g_287", print_hash_value);
    transparent_crc(g_341, "g_341", print_hash_value);
    transparent_crc(g_344, "g_344", print_hash_value);
    transparent_crc(g_443, "g_443", print_hash_value);
    transparent_crc(g_567, "g_567", print_hash_value);
    transparent_crc(g_786, "g_786", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_806[i], "g_806[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_931, "g_931", print_hash_value);
    transparent_crc(g_933, "g_933", print_hash_value);
    transparent_crc(g_998, "g_998", print_hash_value);
    transparent_crc(g_1017, "g_1017", print_hash_value);
    transparent_crc(g_1155, "g_1155", print_hash_value);
    transparent_crc(g_1235, "g_1235", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1236[i], "g_1236[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1257, "g_1257", print_hash_value);
    transparent_crc(g_1289, "g_1289", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_1384[i][j][k], "g_1384[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1394, "g_1394", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1543[i][j], "g_1543[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1628, "g_1628", print_hash_value);
    transparent_crc(g_1785, "g_1785", print_hash_value);
    transparent_crc(g_1921, "g_1921", print_hash_value);
    transparent_crc(g_1960, "g_1960", print_hash_value);
    transparent_crc(g_2015, "g_2015", print_hash_value);
    transparent_crc(g_2303, "g_2303", print_hash_value);
    transparent_crc(g_2379, "g_2379", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2621[i], "g_2621[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_2631[i][j][k], "g_2631[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2739, "g_2739", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 611
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 67
breakdown:
   depth: 1, occurrence: 369
   depth: 2, occurrence: 103
   depth: 3, occurrence: 5
   depth: 4, occurrence: 4
   depth: 5, occurrence: 5
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 4
   depth: 15, occurrence: 3
   depth: 16, occurrence: 5
   depth: 17, occurrence: 4
   depth: 18, occurrence: 2
   depth: 19, occurrence: 4
   depth: 20, occurrence: 4
   depth: 21, occurrence: 4
   depth: 22, occurrence: 8
   depth: 23, occurrence: 2
   depth: 24, occurrence: 6
   depth: 25, occurrence: 8
   depth: 26, occurrence: 4
   depth: 27, occurrence: 3
   depth: 28, occurrence: 4
   depth: 29, occurrence: 2
   depth: 30, occurrence: 4
   depth: 31, occurrence: 2
   depth: 33, occurrence: 3
   depth: 35, occurrence: 4
   depth: 37, occurrence: 2
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 44, occurrence: 1
   depth: 46, occurrence: 3
   depth: 48, occurrence: 1
   depth: 57, occurrence: 1
   depth: 67, occurrence: 1

XXX total number of pointers: 539

XXX times a variable address is taken: 1070
XXX times a pointer is dereferenced on RHS: 309
breakdown:
   depth: 1, occurrence: 249
   depth: 2, occurrence: 34
   depth: 3, occurrence: 22
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
XXX times a pointer is dereferenced on LHS: 358
breakdown:
   depth: 1, occurrence: 306
   depth: 2, occurrence: 36
   depth: 3, occurrence: 15
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 48
XXX times a pointer is compared with address of another variable: 14
XXX times a pointer is compared with another pointer: 16
XXX times a pointer is qualified to be dereferenced: 7601

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1533
   level: 2, occurrence: 405
   level: 3, occurrence: 252
   level: 4, occurrence: 106
   level: 5, occurrence: 9
XXX number of pointers point to pointers: 270
XXX number of pointers point to scalars: 269
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.6
XXX average alias set size: 1.33

XXX times a non-volatile is read: 2149
XXX times a non-volatile is write: 1059
XXX times a volatile is read: 85
XXX    times read thru a pointer: 16
XXX times a volatile is write: 35
XXX    times written thru a pointer: 12
XXX times a volatile is available for access: 1.43e+03
XXX percentage of non-volatile access: 96.4

XXX forward jumps: 3
XXX backward jumps: 11

XXX stmts: 387
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 38
   depth: 2, occurrence: 37
   depth: 3, occurrence: 56
   depth: 4, occurrence: 96
   depth: 5, occurrence: 129

XXX percentage a fresh-made variable is used: 15.1
XXX percentage an existing variable is used: 84.9
********************* end of statistics **********************/

