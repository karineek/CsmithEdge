/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 2041001934 --bitfields --packed-struct
 * Seed:      2041001934
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   const uint64_t  f0;
   uint64_t  f1;
   uint8_t  f2;
   int8_t * f3;
};

/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_3 = (-6L);/* VOLATILE GLOBAL g_3 */
static volatile int8_t *g_2 = &g_3;
static union U0 g_32 = {0UL};
static int32_t g_34 = 0x8CDF8ABFL;
static uint32_t g_36 = 0x992DB756L;
static int8_t *g_43 = (void*)0;
static int8_t *g_45 = (void*)0;
static uint16_t g_61[3][6] = {{0xA473L,0xA473L,0xA473L,0xA473L,0xA473L,0xA473L},{0xA473L,0xA473L,0xA473L,0xA473L,0xA473L,0xA473L},{0xA473L,0xA473L,0xA473L,0xA473L,0xA473L,0xA473L}};
static int32_t *g_82 = &g_34;
static uint32_t g_92 = 0x3EB41E22L;
static int16_t g_104 = 0xFD65L;
static int32_t g_111 = (-1L);
static int32_t g_113 = 8L;
static int8_t g_126 = 0xC1L;
static uint16_t *g_136 = (void*)0;
static uint32_t g_139[9][8][3] = {{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}},{{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL},{0x7EE3387EL,0x7EE3387EL,0x7EE3387EL},{4294967294UL,7UL,4294967294UL}}};
static uint64_t g_189[4] = {1UL,1UL,1UL,1UL};
static int64_t g_212 = (-1L);
static uint16_t g_258[7][8][4] = {{{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL}},{{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL}},{{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L}},{{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL}},{{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL}},{{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,65530UL,0xA427L,0xA427L},{65530UL,65530UL,0x01FEL,65530UL},{65530UL,0xA427L,0xA427L,65530UL},{0xA427L,0xA427L,0x01FEL,0x01FEL}},{{0xA427L,0xA427L,65530UL,0xA427L},{0xA427L,0x01FEL,0x01FEL,0xA427L},{0x01FEL,0xA427L,0x01FEL,0x01FEL},{0xA427L,0xA427L,65530UL,0xA427L},{0xA427L,0x01FEL,0x01FEL,0xA427L},{0x01FEL,0xA427L,0x01FEL,0x01FEL},{0xA427L,0xA427L,65530UL,0xA427L},{0xA427L,0x01FEL,0x01FEL,0xA427L}}};
static union U0 g_297 = {0UL};
static const int8_t * const *g_298 = (void*)0;
static uint16_t *g_350 = &g_258[3][1][1];
static uint16_t **g_377 = &g_350;
static uint16_t ***g_376 = &g_377;
static int64_t g_391[8] = {0x584E6BC05B62413DLL,0x4EA310EAAE944D6ALL,0x584E6BC05B62413DLL,0x584E6BC05B62413DLL,0x4EA310EAAE944D6ALL,0x584E6BC05B62413DLL,0x584E6BC05B62413DLL,0x4EA310EAAE944D6ALL};
static uint64_t g_407 = 18446744073709551606UL;
static uint32_t *g_416 = (void*)0;
static uint32_t **g_415 = &g_416;
static int8_t g_430 = 0L;
static const int8_t *g_429 = &g_430;
static const int8_t **g_428 = &g_429;
static volatile uint8_t g_444[7] = {6UL,0x2EL,0x2EL,6UL,0x2EL,0x2EL,6UL};
static volatile uint8_t *g_443 = &g_444[2];
static volatile uint8_t * volatile *g_442 = &g_443;
static volatile uint8_t * volatile ** const g_441 = &g_442;
static uint16_t ****g_475 = (void*)0;
static int32_t g_480 = 0x97FAF36EL;
static int8_t g_520 = (-4L);
static int64_t g_521[5] = {1L,1L,1L,1L,1L};
static int32_t g_522 = 0x30735F3FL;
static int16_t g_523 = 0xEBAAL;
static uint64_t g_525 = 0x047D0D4D99733C2BLL;
static uint16_t g_614[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static uint8_t g_649 = 0xF1L;
static int8_t g_677 = 0x8AL;
static int32_t g_678[6] = {0xE426E6B2L,0xE426E6B2L,0xE426E6B2L,0xE426E6B2L,0xE426E6B2L,0xE426E6B2L};
static int64_t **g_737[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint16_t g_784 = 65535UL;
static uint64_t g_814 = 8UL;
static union U0 g_832 = {1UL};
static union U0 *g_831 = &g_832;
static uint8_t g_900 = 0xCBL;
static int16_t g_936 = 2L;
static int8_t g_1045[2] = {7L,7L};
static int32_t ** volatile g_1056 = (void*)0;/* VOLATILE GLOBAL g_1056 */
static int32_t ** volatile g_1108 = &g_82;/* VOLATILE GLOBAL g_1108 */
static uint64_t *g_1148 = &g_814;
static uint64_t *g_1149 = &g_814;
static uint32_t g_1221 = 0xA6DFCC19L;
static int32_t ** volatile g_1233 = &g_82;/* VOLATILE GLOBAL g_1233 */
static int32_t ** volatile g_1241 = &g_82;/* VOLATILE GLOBAL g_1241 */
static uint8_t * volatile * volatile *g_1287 = (void*)0;
static uint8_t * volatile * volatile * volatile *g_1286 = &g_1287;
static uint8_t * volatile * volatile * volatile * volatile *g_1285 = &g_1286;
static int32_t ** volatile g_1338 = &g_82;/* VOLATILE GLOBAL g_1338 */
static int32_t * volatile g_1343 = &g_678[1];/* VOLATILE GLOBAL g_1343 */
static uint16_t ** const **g_1359 = (void*)0;
static uint16_t ** const ***g_1358[8] = {&g_1359,&g_1359,&g_1359,&g_1359,&g_1359,&g_1359,&g_1359,&g_1359};
static int16_t g_1390 = 0x46F0L;
static int8_t ** const g_1403 = (void*)0;
static int8_t ** const *g_1402 = &g_1403;
static union U0 ** volatile g_1424 = &g_831;/* VOLATILE GLOBAL g_1424 */
static uint16_t g_1427 = 1UL;
static int32_t * volatile g_1473 = &g_113;/* VOLATILE GLOBAL g_1473 */
static uint16_t g_1478 = 0UL;
static int32_t * volatile g_1479[2] = {&g_111,&g_111};
static int32_t * const  volatile g_1480 = (void*)0;/* VOLATILE GLOBAL g_1480 */
static int8_t g_1500 = 0x67L;
static int32_t g_1527 = 0x575A9388L;
static int32_t ** volatile g_1593[5] = {&g_82,&g_82,&g_82,&g_82,&g_82};
static int32_t ** volatile g_1594 = &g_82;/* VOLATILE GLOBAL g_1594 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint64_t  func_7(uint32_t  p_8, union U0  p_9, int8_t * p_10);
static int32_t  func_15(int8_t  p_16, int8_t * p_17, const int8_t * p_18, int8_t * p_19);
static int64_t  func_23(int8_t * p_24, int64_t  p_25, int8_t * p_26, int8_t * p_27);
static int8_t * func_28(union U0  p_29, const int32_t  p_30, uint32_t  p_31);
static int32_t  func_46(int8_t  p_47);
static int32_t  func_48(int8_t * p_49, uint8_t  p_50, int32_t  p_51, int32_t * p_52);
static int64_t  func_53(int8_t ** p_54, const int8_t * const * p_55, uint16_t  p_56, int32_t  p_57);
static uint8_t  func_64(uint64_t  p_65, union U0  p_66, uint8_t  p_67, const int64_t  p_68, uint8_t  p_69);
static int8_t ** func_72(int32_t * p_73, uint16_t * p_74, uint32_t  p_75, uint32_t  p_76, int32_t  p_77);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_32 g_32.f0 g_36 g_34 g_43 g_45 g_61 g_82 g_92 g_104 g_113 g_111 g_126 g_139 g_189 g_258 g_297 g_298 g_212 g_377 g_350 g_480 g_428 g_429 g_430 g_391 g_525 g_407 g_521 g_376 g_297.f0 g_522 g_614 g_649 g_415 g_441 g_442 g_520 g_737 g_677 g_784 g_814 g_900 g_678 g_523 g_1045 g_443 g_444 g_1108 g_832.f0 g_1221 g_936 g_1233 g_1241 g_1149 g_1148 g_1285 g_832 g_1473 g_1478 g_1500 g_1594 g_1427
 * writes: g_36 g_34 g_43 g_61 g_82 g_92 g_104 g_111 g_113 g_136 g_139 g_126 g_189 g_212 g_258 g_350 g_475 g_480 g_525 g_415 g_376 g_520 g_649 g_614 g_814 g_831 g_521 g_900 g_784 g_678 g_522 g_677 g_523 g_391 g_1148 g_1149 g_1221 g_936 g_430 g_407 g_1478 g_1500 g_32.f1 g_1045 g_1427
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_22 = 0x04L;
    int8_t **l_44 = &g_43;
    int64_t l_1457 = 0x36E910E7BDEB863BLL;
    uint32_t l_1458 = 0x4955CA87L;
    uint16_t *l_1474 = &g_614[6];
    uint16_t *l_1475[6] = {&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427};
    int32_t l_1476 = (-1L);
    uint32_t *l_1477[5][4] = {{&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2]},{&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2]},{&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2]},{&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2]},{&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2],&g_139[8][3][2]}};
    int32_t *l_1481 = &g_522;
    uint16_t * const *l_1494 = &g_136;
    uint16_t * const **l_1493 = &l_1494;
    uint16_t * const *** const l_1492 = &l_1493;
    int64_t *l_1499 = &g_521[1];
    uint8_t *l_1504 = &g_649;
    uint8_t *l_1514[1];
    int8_t l_1515[1][1];
    int32_t l_1522[1][1][6] = {{{0xD551BD56L,0xD551BD56L,0xD551BD56L,0xD551BD56L,0xD551BD56L,0xD551BD56L}}};
    int32_t l_1523 = 0x6453025DL;
    int64_t l_1525 = 0L;
    int64_t l_1542 = 0xB16DBF7FBC092F8BLL;
    const uint8_t *l_1568 = &g_649;
    const uint8_t * const *l_1567 = &l_1568;
    const uint8_t * const **l_1566 = &l_1567;
    int8_t l_1575 = 0x82L;
    int32_t *l_1582 = &g_522;
    int32_t l_1606 = 0xC33EC374L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1514[i] = &g_32.f2;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_1515[i][j] = 0L;
    }
    (*l_1481) = ((g_1478 ^= (g_139[5][4][0] = (((void*)0 == g_2) >= (~((l_1476 &= ((*l_1474) = (safe_mul_func_uint64_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */(func_7(((((safe_div_func_int32_t_s_s_unsafe_macro/*1*//* ___SAFE__OP */(((safe_mul_func_uint8_t_u_u_unsafe_macro/*2*//* ___SAFE__OP */(((func_15((((safe_rshift_func_uint64_t_u_s_unsafe_macro/*3*//* ___SAFE__OP */(l_22, 6)) <= ((void*)0 == &g_3)) == func_23(&l_22, (g_3 != (l_22 , (((*l_44) = func_28(g_32, l_22, g_32.f0)) != g_2))), &l_22, g_45)), g_45, g_45, g_45) ^ 0xFB2FD721L) , 0xF7L), l_1457)) != 18446744073709551606UL), l_22)) & l_22) , l_22) == l_1458), g_832, &l_22), 0xDB162AAF359F0857LL)))) , 0x6A74F6BB3273B903LL))))) < 0x7C5B5525L);
    if ((((l_1515[0][0] &= (safe_add_func_int32_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*5*//* ___SAFE__OP */((((l_1476 = ((((safe_rshift_func_uint32_t_u_s_unsafe_macro/*6*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*8*//* ___SAFE__OP */((l_1492 == &l_1493), (((*l_1481) |= 0x90C3L) >= (safe_rshift_func_uint32_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */((g_1500 = (safe_sub_func_int64_t_s_s_unsafe_macro/*10*//* ___SAFE__OP */(((*l_1499) = l_1476), 0x4B5F8716F773D0B9LL))), 5))))), (4L != (-1L)))) || (safe_add_func_uint8_t_u_u_unsafe_macro/*11*//* ___SAFE__OP */((~g_407), ((*l_1504)--)))), (safe_lshift_func_int16_t_s_u_unsafe_macro/*12*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*13*//* ___SAFE__OP */((!(safe_div_func_uint32_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */(l_1476, 0xDC2465A3L))), l_1476)), 1)))) == l_22) , (*l_1481)) >= l_1457)) && (*l_1481)) && 0x6ECDL), 0xC96FL)), g_61[1][1]))) | 0x74L) < 0x9EL))
    { /* block id: 737 */
        int32_t *l_1516 = &g_111;
        int32_t *l_1517 = &g_34;
        int32_t *l_1518 = &g_113;
        int32_t *l_1519 = &g_113;
        int32_t *l_1520 = (void*)0;
        int32_t *l_1521[8][7][2] = {{{&g_678[5],(void*)0},{&g_678[2],&g_678[2]},{&g_678[2],(void*)0},{&g_678[5],&g_113},{(void*)0,(void*)0},{&g_522,&l_1476},{&g_113,&g_678[2]}},{{&g_678[2],&g_678[2]},{&g_113,&l_1476},{&g_522,(void*)0},{(void*)0,&g_113},{&g_678[5],(void*)0},{&g_678[2],&g_678[2]},{&g_678[2],(void*)0}},{{&g_678[5],&g_113},{(void*)0,(void*)0},{&g_522,&l_1476},{&g_113,&g_678[2]},{&g_678[2],&g_678[2]},{&g_113,&l_1476},{&g_522,(void*)0}},{{(void*)0,&g_113},{&g_678[5],(void*)0},{&g_678[2],&g_678[2]},{&g_678[2],(void*)0},{&g_678[5],&g_113},{(void*)0,(void*)0},{&g_522,&l_1476}},{{&g_113,&g_678[2]},{&g_678[2],&g_678[2]},{&g_113,&l_1476},{&g_522,(void*)0},{(void*)0,&g_113},{&g_522,&g_678[2]},{&l_1476,&l_1476}},{{&l_1476,&g_678[2]},{&g_522,&g_678[2]},{&g_678[2],&g_678[5]},{&g_678[2],&g_113},{&g_678[2],&g_113},{&g_113,&g_113},{&g_678[2],&g_113}},{{&g_678[2],&g_678[5]},{&g_678[2],&g_678[2]},{&g_522,&g_678[2]},{&l_1476,&l_1476},{&l_1476,&g_678[2]},{&g_522,&g_678[2]},{&g_678[2],&g_678[5]}},{{&g_678[2],&g_113},{&g_678[2],&g_113},{&g_113,&g_113},{&g_678[2],&g_113},{&g_678[2],&g_678[5]},{&g_678[2],&g_678[2]},{&g_522,&g_678[2]}}};
        int32_t l_1524[3][6] = {{1L,1L,0x2DD852DAL,1L,1L,0x2DD852DAL},{1L,1L,0x2DD852DAL,1L,1L,0x2DD852DAL},{1L,1L,0x2DD852DAL,1L,1L,0x2DD852DAL}};
        int32_t l_1526 = 0x5BB3C31CL;
        int64_t l_1528 = 9L;
        uint8_t l_1529 = 0UL;
        uint64_t *l_1536 = &g_32.f1;
        int8_t ***l_1539 = (void*)0;
        int8_t ***l_1540 = (void*)0;
        int8_t ***l_1541 = &l_44;
        int i, j, k;
        ++l_1529;
        (*l_1516) = (safe_sub_func_uint32_t_u_u_unsafe_macro/*15*//* ___SAFE__OP */((((safe_div_func_uint32_t_u_u_unsafe_macro/*16*//* ___SAFE__OP */((((*g_350) = (3L < ((*l_1536) = (*l_1518)))) , (((*l_1481) | (((*l_1481) == ((0xDA4DL && ((*l_1516) >= (safe_rshift_func_uint64_t_u_s((((*l_1541) = l_44) != (void*)0), 58)))) , 0x1F47A886370318DALL)) & g_678[1])) || l_1542)), (*l_1481))) >= 0x1F74DF9C2298426ELL) , 1UL), (*l_1481)));
    }
    else
    { /* block id: 743 */
        uint64_t l_1545 = 6UL;
        int32_t *l_1552 = &g_678[2];
        int8_t *l_1563 = &g_1045[0];
        const uint8_t * const ***l_1569 = &l_1566;
        const union U0 l_1572 = {0UL};
        int32_t l_1578 = 0xA4BE7C60L;
        int32_t *l_1583 = &g_678[4];
        int32_t *l_1584 = &g_1527;
        int32_t *l_1585 = (void*)0;
        int32_t *l_1586 = &l_1522[0][0][1];
        int32_t *l_1587 = &g_678[2];
        int32_t l_1588 = (-8L);
        int32_t *l_1589[10] = {&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111};
        uint32_t l_1590 = 0x9CE8AA72L;
        int i;
        (*l_1552) ^= ((*g_350) <= (safe_mul_func_uint8_t_u_u_unsafe_macro/*18*//* ___SAFE__OP */((*g_443), (((((--l_1545) , (0xE908L >= l_1545)) >= ((-10L) > (safe_mod_func_int64_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */((*l_1481), ((*l_1499) = ((((safe_div_func_uint16_t_u_u_unsafe_macro/*20*//* ___SAFE__OP */((0xBE0ACEC6L || (*l_1481)), 1UL)) || 0xF38A3E74L) & 0x05C6AE21F7E184CBLL) & 2UL)))))) > (*l_1481)) , (*l_1481)))));
        (*l_1582) = (safe_lshift_func_int32_t_s_u_unsafe_macro/*21*//* ___SAFE__OP */(((safe_mod_func_uint32_t_u_u_unsafe_macro/*22*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*23*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u_unsafe_macro/*24*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */((((*l_1563) &= (*g_429)) <= (safe_mod_func_uint64_t_u_u_unsafe_macro/*26*//* ___SAFE__OP */(((**g_442) > ((*l_1552) & (((((*l_1569) = l_1566) != &g_442) | (((safe_lshift_func_uint64_t_u_u_unsafe_macro/*27*//* ___SAFE__OP */(((l_1572 , (safe_div_func_uint16_t_u_u_unsafe_macro/*28*//* ___SAFE__OP */(l_1575, (safe_rshift_func_uint32_t_u_s_unsafe_macro/*29*//* ___SAFE__OP */((l_1578 |= (*l_1481)), 13))))) == ((safe_rshift_func_uint8_t_u_s_unsafe_macro/*30*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s_unsafe_macro/*31*//* ___SAFE__OP */(((*l_1481) >= g_520))), (*l_1552))) != g_36)), (*l_1481))) , l_1582) != (void*)0)) | 0xDE89L))), (*l_1552)))), (*l_1582))), (*l_1552))) && (*l_1481)), g_1500)), (*l_1552))) >= 2L), 9));
        l_1590--;
        (*g_1594) = &l_1522[0][0][2];
    }
    for (g_1427 = (-1); (g_1427 <= 58); g_1427++)
    { /* block id: 756 */
        int8_t l_1597[3];
        int32_t l_1604 = 0xEFFD8FDDL;
        int32_t l_1605 = 0xA50CB773L;
        int32_t l_1607 = 0x9A295B3FL;
        uint8_t l_1608 = 1UL;
        int i;
        for (i = 0; i < 3; i++)
            l_1597[i] = (-1L);
        if (l_1597[1])
            break;
        if (l_1597[1])
            continue;
        for (g_407 = 0; (g_407 != 48); g_407 = safe_add_func_int8_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */(g_407, 4))
        { /* block id: 761 */
            int32_t *l_1600 = &g_111;
            int32_t l_1601 = 0x19A78D48L;
            int32_t *l_1602 = &l_1522[0][0][2];
            int32_t *l_1603[7][4][7] = {{{&l_1601,&g_34,&g_111,(void*)0,&l_1522[0][0][2],&l_1522[0][0][2],&g_522},{&g_34,&l_1601,&l_1522[0][0][1],&g_678[4],&g_678[3],&g_34,&g_34},{&l_1601,(void*)0,(void*)0,(void*)0,&l_1601,&g_678[1],&g_522},{&g_678[3],&g_678[4],&l_1522[0][0][1],&l_1601,&g_34,&g_34,&g_111}},{{&l_1522[0][0][2],(void*)0,&g_111,&g_34,&l_1601,&l_1522[0][0][2],&l_1522[0][0][2]},{&g_678[3],&l_1601,&g_678[2],&l_1601,&g_678[3],(void*)0,&g_111},{&l_1601,&g_34,&g_111,(void*)0,&l_1522[0][0][2],&l_1522[0][0][2],&g_522},{&g_34,&l_1601,&l_1522[0][0][1],&g_678[4],&g_678[3],&g_34,&g_34}},{{&l_1601,(void*)0,(void*)0,(void*)0,&l_1601,&g_678[1],&g_522},{&g_678[3],&g_678[4],&l_1522[0][0][1],&l_1601,&g_34,&g_34,&g_111},{&l_1522[0][0][2],(void*)0,&g_111,&g_34,&l_1601,&l_1522[0][0][2],&l_1522[0][0][2]},{&g_678[3],&l_1601,&g_678[2],&l_1601,&g_678[3],(void*)0,&g_111}},{{&l_1601,&g_34,&g_111,(void*)0,&l_1522[0][0][2],&l_1522[0][0][2],&g_522},{&g_34,&l_1601,&l_1522[0][0][1],&g_678[4],&g_678[3],&g_34,&g_34},{&l_1601,(void*)0,(void*)0,(void*)0,&l_1601,&g_678[1],&g_522},{&g_678[3],&g_678[4],&l_1522[0][0][1],&l_1601,&g_34,&g_34,&g_111}},{{&l_1522[0][0][2],(void*)0,&g_111,&g_34,&l_1601,(void*)0,(void*)0},{&g_34,&g_113,&l_1476,&g_113,&g_34,&l_1476,&l_1522[0][0][1]},{&l_1522[0][0][2],(void*)0,&g_522,(void*)0,&g_678[1],(void*)0,&g_111},{(void*)0,&g_113,&l_1476,&l_1522[0][0][2],&g_34,&g_678[2],&g_678[2]}},{{&l_1522[0][0][2],(void*)0,(void*)0,(void*)0,&l_1522[0][0][2],&g_522,&g_111},{&g_34,&l_1522[0][0][2],&l_1476,&g_113,(void*)0,&g_678[2],&l_1522[0][0][1]},{&g_678[1],(void*)0,&g_522,(void*)0,&l_1522[0][0][2],(void*)0,(void*)0},{&g_34,&g_113,&l_1476,&g_113,&g_34,&l_1476,&l_1522[0][0][1]}},{{&l_1522[0][0][2],(void*)0,&g_522,(void*)0,&g_678[1],(void*)0,&g_111},{(void*)0,&g_113,&l_1476,&l_1522[0][0][2],&g_34,&g_678[2],&g_678[2]},{&l_1522[0][0][2],(void*)0,(void*)0,(void*)0,&l_1522[0][0][2],&g_522,&g_111},{&g_34,&l_1522[0][0][2],&l_1476,&g_113,(void*)0,&g_678[2],&l_1522[0][0][1]}}};
            int i, j, k;
            l_1608++;
        }
        if (l_1605)
            break;
    }
    return (*l_1481);
}


/* ------------------------------------------ */
/* 
 * reads : g_649 g_521 g_1473
 * writes: g_649 g_113
 */
static uint64_t  func_7(uint32_t  p_8, union U0  p_9, int8_t * p_10)
{ /* block id: 721 */
    int8_t l_1459 = 0x37L;
    uint8_t *l_1460[10] = {&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2,&g_832.f2};
    uint64_t **l_1463 = &g_1148;
    uint64_t * const *l_1464 = (void*)0;
    uint64_t * const **l_1465 = &l_1464;
    uint8_t *****l_1470 = (void*)0;
    int i;
    (*g_1473) = (1UL && ((g_649--) <= (((l_1463 != ((*l_1465) = l_1464)) , (safe_mul_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((0L == (((safe_lshift_func_uint64_t_u_u((((void*)0 != l_1470) & l_1459), 53)) != ((0x135072037EF22629LL || (safe_rshift_func_uint32_t_u_s_unsafe_macro/*35*//* ___SAFE__OP */(p_9.f0, 28))) & l_1459)) ^ l_1459)), g_521[1]))) == p_8)));
    return l_1459;
}


/* ------------------------------------------ */
/* 
 * reads : g_36 g_45 g_3 g_32 g_61 g_32.f0 g_43 g_82 g_34 g_92 g_104 g_113 g_111 g_126 g_139 g_189 g_258 g_297 g_298 g_212 g_377 g_350 g_480 g_428 g_429 g_430 g_391 g_525 g_407 g_521 g_376 g_297.f0 g_522 g_614 g_649 g_415 g_441 g_442 g_520 g_737 g_677 g_784 g_814 g_900 g_678 g_523 g_1045 g_443 g_444 g_1108 g_2 g_832.f0 g_1221 g_936 g_1233 g_1241 g_1149 g_1148 g_1285
 * writes: g_61 g_82 g_34 g_92 g_104 g_111 g_113 g_136 g_139 g_126 g_189 g_212 g_258 g_350 g_475 g_480 g_36 g_525 g_415 g_376 g_520 g_649 g_614 g_814 g_831 g_521 g_900 g_784 g_678 g_522 g_677 g_523 g_391 g_1148 g_1149 g_1221 g_936 g_430 g_407
 */
static int32_t  func_15(int8_t  p_16, int8_t * p_17, const int8_t * p_18, int8_t * p_19)
{ /* block id: 13 */
    uint16_t *l_79[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_295 = 0L;
    int8_t *l_867 = (void*)0;
    uint8_t * const l_1043[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint8_t * const *l_1042 = &l_1043[3];
    uint8_t * const **l_1041 = &l_1042;
    int32_t l_1083[9][6] = {{0x6920FA26L,0xA333CA04L,1L,0L,0xF1ED2B84L,0x6E620EBDL},{1L,0x7C72A653L,0x9F2EA845L,0xA333CA04L,0L,0x6E620EBDL},{1L,0L,1L,1L,0L,1L},{0L,0L,0xF1ED2B84L,0xBCFE1F75L,0x6920FA26L,0L},{0L,0x9F2EA845L,0x6920FA26L,(-7L),(-1L),0x06513D59L},{0L,0L,(-7L),0xBCFE1F75L,(-7L),0L},{0L,0x6920FA26L,0xA333CA04L,1L,0L,0xF1ED2B84L},{1L,(-3L),0xBCFE1F75L,0xA333CA04L,0x6E620EBDL,(-7L)},{1L,(-3L),0x7C72A653L,0L,0L,0x7C72A653L}};
    union U0 l_1087 = {18446744073709551607UL};
    int8_t **l_1143 = &g_43;
    int8_t ***l_1142 = &l_1143;
    int64_t *l_1249 = &g_212;
    int64_t **l_1248 = &l_1249;
    uint16_t * const *l_1261 = &g_350;
    uint16_t * const **l_1260 = &l_1261;
    uint32_t l_1270 = 0x4DFBFD2CL;
    uint64_t l_1289[4][1];
    int32_t l_1391 = 7L;
    int32_t l_1409 = (-5L);
    uint8_t l_1421 = 1UL;
    int32_t **l_1456 = &g_82;
    int i, j;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
            l_1289[i][j] = 0xB396DC05075CC1E6LL;
    }
    if (g_36)
    { /* block id: 14 */
        uint16_t *l_60 = &g_61[1][1];
        int32_t *l_78 = (void*)0;
        int8_t **l_85 = &g_43;
        int8_t ***l_84 = &l_85;
        union U0 l_86 = {0xB66FFBA242739A3ALL};
        uint8_t *l_294 = &l_86.f2;
        int32_t *l_296 = &g_113;
        int32_t *l_946 = &l_295;
        uint32_t ***l_968 = &g_415;
        uint32_t ****l_967 = &l_968;
        uint8_t **l_1032[2][2] = {{&l_294,&l_294},{&l_294,&l_294}};
        uint8_t ***l_1031 = &l_1032[0][0];
        uint8_t ****l_1030 = &l_1031;
        uint8_t * const *l_1040[6][8] = {{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294,&l_294}};
        uint8_t * const **l_1039[3];
        int64_t l_1082 = 0x0CF637F499B520D5LL;
        int64_t l_1105[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        uint64_t *l_1150 = &g_814;
        int32_t l_1186 = 0xB9681513L;
        int32_t l_1212 = 1L;
        int32_t l_1214 = 0L;
        int32_t l_1215[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        const uint8_t ****l_1231 = (void*)0;
        const uint8_t *****l_1230 = &l_1231;
        int i, j;
        for (i = 0; i < 3; i++)
            l_1039[i] = &l_1040[1][3];
        if (func_23(g_45, g_3, func_28(g_32, (&p_16 != (func_46(((func_48(func_28(g_32, (func_23((func_53(&g_43, ((((safe_add_func_int32_t_s_s_unsafe_macro/*36*//* ___SAFE__OP */(((*l_296) = (((*l_60) |= 9UL) , ((safe_mod_func_uint8_t_u_u(((*l_294) = func_64((safe_div_func_int32_t_s_s_unsafe_macro/*38*//* ___SAFE__OP */((((&p_17 != ((*l_84) = func_72(l_78, l_79[2], p_16, g_36, g_32.f0))) , g_43) == &p_16), g_36)), l_86, p_16, g_61[1][1], g_36)), l_295)) <= g_36))), (-2L))) , g_297) , (*g_82)) , g_298), p_16, p_16) , &p_16), p_16, &g_430, l_867) , p_16), g_677), l_295, g_297.f0, &l_295) , p_16) >= 1UL)) , l_867)), p_16), &g_677))
        { /* block id: 453 */
            uint64_t l_947 = 0x9D5FFE5B085B9D6ALL;
            int32_t l_971 = 0xEE5C2762L;
            int32_t l_972 = 0x64CC4E74L;
            int16_t l_984 = 7L;
            union U0 l_1019[3][4] = {{{1UL},{1UL},{0x32D44D7C5CB7D082LL},{1UL}},{{1UL},{18446744073709551611UL},{18446744073709551611UL},{1UL}},{{18446744073709551611UL},{1UL},{18446744073709551611UL},{18446744073709551611UL}}};
            uint8_t **l_1029 = &l_294;
            uint8_t ***l_1028 = &l_1029;
            uint8_t ****l_1027 = &l_1028;
            int i, j;
            for (g_784 = 0; (g_784 < 46); g_784 = safe_add_func_int8_t_s_s_unsafe_macro/*39*//* ___SAFE__OP */(g_784, 4))
            { /* block id: 456 */
                int32_t **l_944 = (void*)0;
                int32_t **l_945[6][8][1] = {{{&l_296},{&l_78},{&l_296},{&l_78},{&l_296},{(void*)0},{&l_296},{&l_78}},{{&l_296},{&l_78},{&l_296},{(void*)0},{&l_296},{&l_78},{&l_296},{&l_78}},{{&l_296},{(void*)0},{&l_296},{&l_78},{&l_296},{&l_78},{&l_296},{(void*)0}},{{&l_296},{&l_78},{&l_296},{&l_78},{&l_296},{(void*)0},{&l_296},{&l_78}},{{&l_296},{&l_78},{&l_296},{(void*)0},{&l_296},{&l_78},{&l_296},{&l_78}},{{&l_296},{(void*)0},{&l_296},{&l_78},{&l_296},{&l_78},{&l_296},{(void*)0}}};
                int8_t l_969 = 0x9DL;
                uint8_t ****l_1034 = &l_1031;
                int i, j, k;
                g_82 = (l_946 = &g_678[2]);
                l_947--;
                for (g_814 = 0; (g_814 <= 3); g_814 += 1)
                { /* block id: 462 */
                    int i;
                    (*l_946) = (-1L);
                    return g_391[(g_814 + 4)];
                }
                if ((*g_82))
                { /* block id: 466 */
                    uint32_t ***l_964 = &g_415;
                    uint32_t ****l_963 = &l_964;
                    uint32_t *****l_965 = &l_963;
                    int32_t l_966 = 1L;
                    int8_t *l_970 = &g_677;
                    uint16_t l_973 = 0xDC3DL;
                    int32_t l_1009[7][4][2] = {{{0x8918D1CDL,0L},{0x8918D1CDL,0x5D636B97L},{0xEDBB5E16L,7L},{0x5D636B97L,(-10L)}},{{0x3B864216L,0x62FE3EE4L},{7L,(-1L)},{(-1L),(-1L)},{7L,0x62FE3EE4L}},{{0x3B864216L,(-10L)},{0x5D636B97L,7L},{0xEDBB5E16L,0x5D636B97L},{0x8918D1CDL,0L}},{{0x8918D1CDL,0x5D636B97L},{0xEDBB5E16L,7L},{0x5D636B97L,(-10L)},{0x3B864216L,0x62FE3EE4L}},{{7L,(-1L)},{(-1L),(-1L)},{7L,0x62FE3EE4L},{0x3B864216L,(-10L)}},{{0x5D636B97L,7L},{0xEDBB5E16L,0x5D636B97L},{0x8918D1CDL,0L},{0x8918D1CDL,0x5D636B97L}},{{0xEDBB5E16L,7L},{0x5D636B97L,(-10L)},{0x3B864216L,0x62FE3EE4L},{7L,(-1L)}}};
                    int16_t l_1013 = (-2L);
                    int32_t l_1016 = (-1L);
                    int i, j, k;
                    for (g_525 = 0; (g_525 <= 0); g_525 += 1)
                    { /* block id: 469 */
                        int32_t *l_950 = &g_678[0];
                        l_950 = l_950;
                    }
                    for (g_522 = 0; (g_522 == 7); g_522++)
                    { /* block id: 474 */
                        return l_947;
                    }
                    (*g_82) = (*g_82);
                    if ((((safe_div_func_int8_t_s_s_unsafe_macro/*40*//* ___SAFE__OP */(0xD2L, (-8L))) & 0x15620670D5370F52LL) , (((safe_lshift_func_uint8_t_u_s_unsafe_macro/*41*//* ___SAFE__OP */(((*l_296) , ((safe_rshift_func_int8_t_s_u_unsafe_macro/*42*//* ___SAFE__OP */(((*l_970) = (l_969 = (safe_div_func_uint8_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*44*//* ___SAFE__OP */(0UL, (p_16 <= (((*l_965) = l_963) == ((((((void*)0 != p_17) & l_966) , p_16) <= g_189[0]) , l_967))))), l_295)))), 0)) & 0x5402L)), l_966)) ^ 0x828A29C58FB8ECD0LL) > g_614[6])))
                    { /* block id: 481 */
                        l_973--;
                    }
                    else
                    { /* block id: 483 */
                        uint64_t *l_995 = &l_947;
                        int32_t l_1006 = 0x6039F93DL;
                        uint64_t *l_1012 = &g_189[0];
                        int16_t *l_1014 = (void*)0;
                        int16_t *l_1015 = &g_523;
                        (*l_296) ^= (l_1016 |= (safe_mul_func_uint16_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */(((((*l_1015) &= (p_16 , (((safe_mod_func_uint64_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */(((safe_div_func_int32_t_s_s_unsafe_macro/*47*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*48*//* ___SAFE__OP */(l_984, ((((safe_mul_func_int16_t_s_s_unsafe_macro/*49*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*50*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*52*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*53*//* ___SAFE__OP */((l_966 , g_104), (((*l_995)++) < ((*l_1012) = (safe_lshift_func_uint64_t_u_s_unsafe_macro/*54*//* ___SAFE__OP */((((l_971 = (((safe_mul_func_uint8_t_u_u_unsafe_macro/*55*//* ___SAFE__OP */(p_16, ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*56*//* ___SAFE__OP */((g_900++), 1)) & l_1006))) ^ (safe_div_func_uint32_t_u_u_unsafe_macro/*57*//* ___SAFE__OP */((l_1009[6][3][1] = p_16), (safe_rshift_func_uint64_t_u_s_unsafe_macro/*58*//* ___SAFE__OP */(g_189[1], 13))))) ^ (0x5B77859FL < (*g_82)))) , p_16) < l_1006), l_973)))))), 12)), 14)), (***g_376))), p_16)) , 0xD619133FL) , (-1L)) , p_16))), l_972)) <= (*g_429)), l_984)) != 0x0EFCL) ^ l_1013))) || 0x6DE5L) <= l_1006), l_1006)));
                        (*l_946) &= 0x3EE99137L;
                        l_1016 ^= (l_972 <= (safe_mod_func_uint64_t_u_u_unsafe_macro/*59*//* ___SAFE__OP */((l_1019[1][0] , 0x2AD47859DCE6DFA3LL), (((((safe_rshift_func_uint16_t_u_s_unsafe_macro/*60*//* ___SAFE__OP */(((*g_350) = p_16), 13)) , 6UL) ^ ((l_1009[4][1][0] = ((*g_82) = ((*l_296) = ((safe_div_func_int16_t_s_s_unsafe_macro/*61*//* ___SAFE__OP */(g_297.f0, 1UL)) > ((void*)0 != &g_441))))) == l_295)) | p_16) ^ l_1006))));
                    }
                }
                else
                { /* block id: 499 */
                    int8_t *l_1026[5] = {&g_126,&g_126,&g_126,&g_126,&g_126};
                    uint8_t *****l_1033[10] = {&l_1030,&l_1030,(void*)0,&l_1030,(void*)0,&l_1030,&l_1030,(void*)0,&l_1030,(void*)0};
                    int32_t l_1048 = 1L;
                    int i;
                    (*l_946) = l_295;
                    if ((safe_lshift_func_int64_t_s_u_unsafe_macro/*62*//* ___SAFE__OP */((((((*l_296) |= l_1019[1][0].f0) , l_1027) != (l_1034 = l_1030)) > (((-5L) & ((safe_add_func_int8_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */(l_972, ((*l_1030) == (l_1041 = l_1039[1])))) >= ((safe_unary_minus_func_int16_t_s_unsafe_macro/*64*//* ___SAFE__OP */(g_1045[0])) , (safe_lshift_func_int8_t_s_u_unsafe_macro/*65*//* ___SAFE__OP */((l_1048 ^= (*g_429)), (***g_441)))))) != (*g_82))), 49)))
                    { /* block id: 505 */
                        if ((*g_82))
                            break;
                    }
                    else
                    { /* block id: 507 */
                        (*l_296) = (safe_rshift_func_uint8_t_u_s_unsafe_macro/*66*//* ___SAFE__OP */((p_16 , 0x7FL), ((-1L) != (((*l_296) | ((void*)0 != (*l_967))) ^ 0UL))));
                    }
                }
            }
        }
        else
        { /* block id: 512 */
            int16_t *l_1054 = &g_104;
            int32_t l_1080 = 0L;
            uint8_t **l_1107[7][7][5] = {{{&l_294,&l_294,(void*)0,(void*)0,&l_294},{(void*)0,(void*)0,&l_294,&l_294,&l_294},{(void*)0,(void*)0,(void*)0,&l_294,&l_294},{&l_294,&l_294,(void*)0,&l_294,&l_294},{&l_294,(void*)0,&l_294,&l_294,(void*)0},{&l_294,(void*)0,&l_294,&l_294,&l_294},{&l_294,(void*)0,&l_294,(void*)0,&l_294}},{{(void*)0,&l_294,&l_294,(void*)0,&l_294},{&l_294,(void*)0,&l_294,&l_294,(void*)0},{&l_294,(void*)0,&l_294,&l_294,&l_294},{&l_294,&l_294,(void*)0,&l_294,&l_294},{&l_294,&l_294,&l_294,(void*)0,&l_294},{&l_294,(void*)0,&l_294,(void*)0,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294}},{{&l_294,&l_294,&l_294,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,&l_294,&l_294},{(void*)0,(void*)0,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,(void*)0,&l_294,&l_294,&l_294},{(void*)0,(void*)0,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,(void*)0}},{{(void*)0,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{(void*)0,&l_294,(void*)0,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294}},{{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,(void*)0,(void*)0,&l_294},{&l_294,(void*)0,&l_294,&l_294,&l_294},{&l_294,(void*)0,&l_294,(void*)0,&l_294},{(void*)0,&l_294,&l_294,(void*)0,&l_294},{&l_294,(void*)0,&l_294,&l_294,(void*)0}},{{&l_294,(void*)0,&l_294,&l_294,&l_294},{&l_294,&l_294,(void*)0,&l_294,&l_294},{&l_294,&l_294,&l_294,(void*)0,&l_294},{&l_294,(void*)0,&l_294,(void*)0,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,&l_294,&l_294}},{{(void*)0,(void*)0,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,(void*)0},{&l_294,&l_294,(void*)0,(void*)0,&l_294},{&l_294,&l_294,&l_294,(void*)0,&l_294},{&l_294,&l_294,&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294,&l_294,(void*)0},{&l_294,&l_294,(void*)0,(void*)0,(void*)0}}};
            const int8_t ***l_1144 = &g_428;
            const uint8_t ****l_1209 = (void*)0;
            int32_t l_1218 = 1L;
            int32_t **l_1232 = (void*)0;
            int i, j, k;
            if ((+((*l_1054) = g_391[5])))
            { /* block id: 514 */
                int8_t l_1058[8][4][5] = {{{0L,0xA3L,0x00L,1L,0x00L},{0xB2L,0xB2L,(-5L),1L,0xF6L},{0x00L,(-10L),1L,7L,0x5FL},{(-3L),(-1L),0xCCL,0x96L,0x9CL}},{{1L,(-10L),8L,0xF6L,0x3BL},{0x2CL,0xB2L,7L,0xF6L,0x51L},{1L,0xA3L,(-4L),0xAEL,8L},{(-1L),0x2CL,0xF6L,0xF6L,0x2CL}},{{0x5FL,1L,0L,0xF6L,0x3AL},{0xDAL,0x9CL,0xB2L,0x96L,7L},{0x14L,(-9L),0L,7L,0L},{0xDAL,(-5L),0xDAL,1L,0L}},{{0x5FL,0xF9L,0L,1L,(-1L)},{(-1L),0x96L,0x51L,0xB2L,0x60L},{1L,0x2BL,0L,0x2BL,1L},{0x2CL,0xA4L,0xDAL,0x9CL,0xB2L}},{{1L,(-1L),0L,0L,(-4L)},{(-3L),0xDAL,0xB2L,0xA4L,0xB2L},{0x00L,0L,0L,(-1L),1L},{0xB2L,7L,0xF6L,0x51L,0x60L}},{{0L,0x2CL,(-4L),(-9L),(-1L)},{(-2L),7L,7L,(-2L),0L},{0x3AL,0L,8L,0L,0L},{0xF6L,0xDAL,0xCCL,(-3L),7L}},{{(-1L),(-1L),1L,0L,0x3AL},{0x60L,0xA4L,(-5L),(-2L),0x2CL},{0x2FL,0x2BL,0x00L,(-9L),8L},{0xA4L,0x96L,1L,0x51L,0x51L}},{{0x2FL,0xF9L,0x2FL,(-1L),0x3BL},{0x60L,(-5L),(-3L),0xA4L,0x9CL},{(-1L),(-9L),0L,0L,0x5FL},{0xF6L,0x9CL,(-3L),0x9CL,0xF6L}}};
                int i, j, k;
                for (g_677 = 2; (g_677 >= 0); g_677 -= 1)
                { /* block id: 517 */
                    int32_t l_1081 = 2L;
                    for (g_92 = 0; (g_92 <= 2); g_92 += 1)
                    { /* block id: 520 */
                        int32_t **l_1055 = (void*)0;
                        int32_t **l_1057 = &g_82;
                        uint32_t ****l_1067 = (void*)0;
                        union U0 l_1079 = {18446744073709551614UL};
                        (*l_1057) = l_78;
                        l_1083[5][0] &= ((l_1058[1][1][4] &= p_16) , ((safe_mod_func_uint64_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*68*//* ___SAFE__OP */(0xA3L, (*g_429))), p_16)) , (((safe_add_func_int8_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s_unsafe_macro/*70*//* ___SAFE__OP */(((((void*)0 != l_1067) >= 0xD4L) < (safe_add_func_int8_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_u_unsafe_macro/*72*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_s_unsafe_macro/*73*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*74*//* ___SAFE__OP */((+((safe_sub_func_uint16_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */((((g_784 == (((((l_1080 |= (l_1079 , (**g_428))) || p_16) || l_1058[1][1][4]) || 2UL) || (*l_946))) > g_520) < l_1081), 0xA74EL)) , g_36)), p_16)), 30)) ^ 65528UL), 4)), l_1082))), p_16)), (**g_428))) != l_295) == p_16)));
                        if (p_16)
                            continue;
                    }
                    for (g_36 = 0; (g_36 <= 8); g_36 += 1)
                    { /* block id: 529 */
                        int i;
                        return g_614[(g_677 + 6)];
                    }
                    if (l_1083[5][0])
                        continue;
                }
                if (l_1080)
                    goto lbl_1084;
lbl_1084:
                (*l_296) = (p_16 < 7L);
                for (g_104 = 0; (g_104 < (-30)); g_104 = safe_sub_func_int16_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */(g_104, 9))
                { /* block id: 538 */
                    int64_t *l_1088 = &g_391[5];
                    int64_t *l_1089 = &g_521[1];
                    int32_t **l_1092 = &l_78;
                    int8_t *l_1093 = &l_1058[1][1][4];
                    uint32_t *l_1104 = &g_139[7][7][0];
                    uint8_t **l_1106 = &l_294;
                    (*l_946) ^= ((l_1087 , 6L) ^ ((l_1107[2][3][4] = ((((*l_1089) = ((*l_1088) = p_16)) || ((safe_mod_func_int8_t_s_s_unsafe_macro/*77*//* ___SAFE__OP */(((*l_1093) = (((*l_1092) = &l_295) == &l_1080)), (((safe_sub_func_uint32_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */((((safe_mul_func_int8_t_s_s_unsafe_macro/*80*//* ___SAFE__OP */((((((*l_1104) &= (((safe_lshift_func_int32_t_s_u_unsafe_macro/*81*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u_unsafe_macro/*82*//* ___SAFE__OP */(p_16, 65528UL)), 20)) >= p_16) , (*l_296))) > l_1105[1]) == 4294967292UL) != 0UL), p_16)) , 9UL) && p_16), g_520)), 0x6F6FD41BL)) > 0xFE0E9903L) & p_16))) != 0xD274D86BCC53BD16LL)) , l_1106)) != (*g_441)));
                }
            }
            else
            { /* block id: 547 */
                uint64_t *l_1120 = &l_1087.f1;
                int64_t *l_1121 = &g_212;
                int32_t l_1145 = 0x10B39C7BL;
                int8_t l_1146 = 0x6FL;
                uint64_t **l_1147[5][6][6] = {{{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,(void*)0},{(void*)0,&l_1120,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,(void*)0,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120}},{{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,(void*)0},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,(void*)0},{(void*)0,&l_1120,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,(void*)0,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,&l_1120}},{{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,(void*)0},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,(void*)0},{(void*)0,&l_1120,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,(void*)0,&l_1120,&l_1120,(void*)0,&l_1120}},{{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,(void*)0},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,(void*)0},{(void*)0,&l_1120,&l_1120,&l_1120,(void*)0,&l_1120}},{{&l_1120,(void*)0,&l_1120,&l_1120,(void*)0,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,(void*)0,&l_1120,(void*)0},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,&l_1120},{&l_1120,&l_1120,&l_1120,&l_1120,&l_1120,(void*)0}}};
                int32_t *l_1161 = (void*)0;
                int32_t l_1216 = 0xCD227C92L;
                int32_t l_1217 = 0x8490BE68L;
                int32_t l_1219[7] = {0x30CA0F54L,6L,0x30CA0F54L,0x30CA0F54L,6L,0x30CA0F54L,0x30CA0F54L};
                int i, j, k;
                (*g_1108) = &l_1083[5][0];
                if ((safe_mod_func_uint8_t_u_u_unsafe_macro/*83*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*84*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((+(safe_div_func_uint8_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */((((((((g_1149 = (g_1148 = (((safe_mul_func_uint64_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */(((*l_1120) = p_16), p_16)) < (((*l_1121) = p_16) || ((safe_mul_func_uint64_t_u_u_unsafe_macro/*88*//* ___SAFE__OP */((((*l_294) = (safe_lshift_func_int32_t_s_u_unsafe_macro/*89*//* ___SAFE__OP */(((safe_div_func_int8_t_s_s_unsafe_macro/*90*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */((+((((safe_add_func_int8_t_s_s_unsafe_macro/*92*//* ___SAFE__OP */(((l_1080 = ((~p_16) > ((((safe_sub_func_int32_t_s_s_unsafe_macro/*93*//* ___SAFE__OP */((l_60 == l_1054), ((*g_2) <= ((safe_sub_func_uint16_t_u_u_unsafe_macro/*94*//* ___SAFE__OP */(((*l_60) = ((*g_350)++)), (safe_lshift_func_int32_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */((((l_1142 == l_1144) ^ g_520) , 0xA8DBE120L), 19)))) == (*l_946))))) < l_1145) , l_1146) & l_1145))) & 1L), 4UL)) == p_16) , 65530UL) ^ p_16)), 0x5FL)), 0x2DL)) , 0x6C1BDE1AL), p_16))) ^ 8L), p_16)) , p_16))) , (void*)0))) == l_1150) >= l_295) ^ l_1146) , l_1145) < l_1083[5][0]) > 0x26L), l_1083[7][4]))), 0x68L)), l_295)), g_1045[0])))
                { /* block id: 557 */
                    int64_t l_1172 = 0xD870F5E7B9978244LL;
lbl_1163:
                    if (((*l_296) |= ((*g_82) <= ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*96*//* ___SAFE__OP */(((*l_1120) &= 0UL), 26)) && (((***g_376) &= (safe_div_func_int8_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */(0x02L, (p_16 &= l_295)))) == l_1145)))))
                    { /* block id: 562 */
                        uint32_t l_1160 = 0UL;
                        l_1160 = (~(--(*l_1120)));
                        l_1161 = &l_1083[5][0];
                        if (l_295)
                            goto lbl_1163;
                    }
                    else
                    { /* block id: 566 */
                        int32_t l_1162 = 0x925213DCL;
                        return l_1162;
                    }
                    (*l_296) &= ((*l_946) ^= (safe_add_func_int64_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*99*//* ___SAFE__OP */(p_16, p_16)) ^ (**g_428)), (safe_sub_func_uint16_t_u_u_unsafe_macro/*100*//* ___SAFE__OP */(((void*)0 == &l_1161), (l_1083[5][0] != ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*101*//* ___SAFE__OP */((((l_1080 = (&g_1148 != &l_1150)) , (*l_84)) != &p_17), 0)) == l_1172)))))));
                    (*l_946) &= (((((safe_rshift_func_int32_t_s_s_unsafe_macro/*102*//* ___SAFE__OP */((l_1172 || (safe_add_func_int64_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */((g_189[0] >= (*l_1161)), (++(*l_1150))))), 30)) > (safe_add_func_int32_t_s_s_unsafe_macro/*104*//* ___SAFE__OP */(0x87047A27L, p_16))) || 0L) ^ 7UL) >= (*g_443));
                }
                else
                { /* block id: 575 */
                    uint32_t *l_1181 = &g_139[1][4][0];
                    uint16_t ****l_1195 = &g_376;
                    int32_t l_1198 = 0xD6D6D696L;
                    const int16_t *l_1210 = &g_523;
                    int32_t *l_1211 = &l_1080;
                    int32_t *l_1213[4][8][8] = {{{&g_34,&g_111,&l_295,&g_111,&g_34,&g_34,&g_111,(void*)0},{&l_1212,&g_113,&l_1198,&l_1145,&g_111,&l_1212,&l_1212,&g_111},{(void*)0,&l_1198,&l_1198,(void*)0,&g_34,&l_295,&g_111,&l_1198},{&g_111,&l_1083[5][0],&l_1083[5][0],(void*)0,&l_1083[5][0],&l_295,&l_1083[5][0],(void*)0},{&l_295,&l_1083[5][0],&l_295,&l_1198,&g_111,&l_295,&g_34,(void*)0},{&g_113,&l_1198,&l_1145,&g_111,&l_1212,&l_1212,&g_111,&l_1145},{&g_113,&g_113,&l_295,(void*)0,&g_111,&g_111,&g_113,&g_111},{&l_295,&g_111,&l_1198,&l_295,&l_1083[5][0],&l_295,&l_1198,&g_111}},{{&g_111,&g_34,&l_1145,(void*)0,&g_34,&l_1198,&l_1083[5][0],&l_1145},{(void*)0,&l_1083[5][0],&l_1083[5][0],&g_111,&g_111,&l_1083[5][0],&l_1083[5][0],(void*)0},{&l_1212,&g_111,&l_1145,&l_1198,&g_113,&l_1212,&l_1198,(void*)0},{&g_113,&l_1212,&l_1198,(void*)0,&l_1198,&l_1212,&g_113,&l_1198},{(void*)0,&g_111,&l_295,(void*)0,&l_1083[5][0],&l_1083[5][0],&g_111,&g_111},{&l_1198,&l_1083[5][0],&l_1145,&l_1145,&l_1083[5][0],&l_1198,&g_34,(void*)0},{(void*)0,&g_34,&l_295,&g_111,&l_1198,&l_295,&l_1083[5][0],&l_295},{&g_113,&g_111,&l_1083[5][0],&g_111,&g_113,&g_111,&g_111,(void*)0}},{{&l_1212,&g_113,&l_1198,&l_1145,&g_111,&l_1212,&l_1212,&g_111},{(void*)0,&l_1198,&l_1198,(void*)0,&g_34,&l_295,&g_111,&l_1198},{&g_111,&l_1083[5][0],&l_1083[5][0],(void*)0,&l_1083[5][0],&l_295,&l_1083[5][0],(void*)0},{&l_295,&l_1083[5][0],&l_295,&l_1198,&g_111,&l_295,&g_34,(void*)0},{&g_113,&l_1198,&l_1145,&g_111,&l_1212,&l_1212,&g_111,&l_1145},{&g_113,&g_113,&l_295,(void*)0,&g_111,&g_111,&g_113,&g_111},{&l_295,&g_111,&l_1198,&l_295,&l_1083[5][0],&l_295,&l_1198,&g_111},{&g_111,&g_34,&l_1145,(void*)0,&g_34,&l_1198,&l_1083[5][0],&l_1145}},{{(void*)0,&l_1083[5][0],&l_1083[5][0],&g_111,&g_111,(void*)0,&l_1212,&l_1145},{&l_295,&l_295,&g_34,&l_1083[5][0],&l_1198,&l_295,&l_1083[5][0],&g_34},{&l_1198,&l_295,&l_1083[5][0],&g_34,&l_1083[5][0],&l_295,&l_1198,&l_1083[5][0]},{&l_1145,&l_295,(void*)0,&l_1145,&l_1212,(void*)0,&l_295,&l_295},{&l_1083[5][0],&l_1212,&g_34,&g_34,&l_1212,&l_1083[5][0],&g_111,&g_34},{&l_1145,&g_111,&l_1083[5][0],&l_295,&l_1083[5][0],&l_1083[5][0],&l_1212,&l_1083[5][0]},{&l_1198,&l_295,&l_1083[5][0],&l_295,&l_1198,&g_111,&l_295,&g_34},{&l_295,&l_1198,&l_1083[5][0],&g_34,&l_295,&l_295,&l_295,&l_295}}};
                    int32_t l_1220[5];
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_1220[i] = 6L;
                    g_113 ^= (((--(*l_1181)) != (safe_rshift_func_uint64_t_u_s_unsafe_macro/*105*//* ___SAFE__OP */(((*l_1150) = l_1186), 43))) , (safe_mod_func_int16_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */(((safe_mul_func_int16_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */((((((l_1083[8][1] && (((*l_1195) = (void*)0) != (void*)0)) > ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*108*//* ___SAFE__OP */(l_1198, 49)) == ((*l_1054) |= ((safe_mul_func_int64_t_s_s_unsafe_macro/*109*//* ___SAFE__OP */((18446744073709551613UL <= ((((**g_428) != (0x396AD4C4L < ((safe_mod_func_uint8_t_u_u_unsafe_macro/*110*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*111*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*112*//* ___SAFE__OP */(((((l_1209 == (void*)0) , g_832.f0) , l_1080) <= p_16), 0L)), p_16)), (**g_442))) >= 0x4C77L))) ^ 3UL) , 18446744073709551615UL)), p_16)) & p_16)))) , l_60) == l_1210) != 7UL), (*g_350))) == 0L), (-1L))));
                    g_1221++;
                    for (g_900 = 0; (g_900 < 35); g_900 = safe_add_func_uint32_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */(g_900, 5))
                    { /* block id: 584 */
                        const int32_t *l_1226 = (void*)0;
                        const int32_t **l_1227 = &l_1226;
                        (*l_1227) = l_1226;
                    }
                }
                for (g_480 = 0; (g_480 <= 9); g_480 += 1)
                { /* block id: 590 */
                    int32_t **l_1228 = &l_296;
                    int i;
                    l_1161 = ((*l_1228) = (*g_1108));
                    for (g_936 = 6; (g_936 >= 0); g_936 -= 1)
                    { /* block id: 595 */
                        int i;
                        (*l_1228) = &l_1215[g_480];
                        if (p_16)
                            continue;
                    }
                    l_1215[g_480] &= (g_936 , (+(-1L)));
                }
                l_1230 = &l_1209;
            }
            (*g_1233) = &l_1215[8];
            for (g_430 = 0; (g_430 == 20); g_430 = safe_add_func_uint16_t_u_u_unsafe_macro/*114*//* ___SAFE__OP */(g_430, 2))
            { /* block id: 606 */
                int64_t l_1236 = 0xC53AE88B4406BEB2LL;
                if (p_16)
                    break;
                if (l_1236)
                    break;
            }
            for (g_407 = 25; (g_407 != 32); ++g_407)
            { /* block id: 612 */
                for (g_784 = 23; (g_784 == 2); g_784 = safe_sub_func_int16_t_s_s_unsafe_macro/*115*//* ___SAFE__OP */(g_784, 1))
                { /* block id: 615 */
                    if ((**g_1108))
                        break;
                }
                (*g_1241) = (*g_1233);
            }
        }
    }
    else
    { /* block id: 621 */
        const int64_t *l_1252 = &g_391[4];
        const int64_t **l_1251[4][2] = {{&l_1252,&l_1252},{&l_1252,&l_1252},{&l_1252,&l_1252},{&l_1252,&l_1252}};
        int32_t l_1263 = (-1L);
        int32_t l_1280[7];
        int64_t l_1334 = (-1L);
        int16_t l_1380 = 0x1EBAL;
        int16_t l_1392[6][8] = {{4L,0x2349L,0x0BF2L,(-2L),1L,(-1L),4L,4L},{7L,(-2L),0L,0L,(-2L),7L,1L,0x2349L},{(-2L),7L,1L,0x2349L,(-1L),0L,9L,(-1L)},{0x2349L,4L,(-8L),0x2349L,1L,0xD86AL,1L,0x2349L},{(-6L),1L,(-6L),0L,1L,1L,0L,4L},{1L,(-10L),1L,(-2L),0x66A8L,(-1L),1L,(-10L)}};
        int32_t **l_1455 = &g_82;
        int i, j;
        for (i = 0; i < 7; i++)
            l_1280[i] = 0x15D59931L;
        if (((g_678[2] , &g_376) == (void*)0))
        { /* block id: 622 */
            l_1083[2][2] = ((*g_82) = 0x2B31CE80L);
            (*g_82) = (~p_16);
        }
        else
        { /* block id: 626 */
            uint64_t l_1245 = 18446744073709551614UL;
            int32_t l_1262 = 0L;
            int32_t l_1277[2][1];
            int32_t l_1279 = 0x62E0621AL;
            uint8_t * volatile * volatile * volatile * volatile *l_1288 = &g_1286;
            uint32_t l_1293 = 18446744073709551615UL;
            const uint32_t *l_1324 = &g_1221;
            const uint32_t **l_1323 = &l_1324;
            const uint32_t ***l_1322 = &l_1323;
            uint16_t ** const ***l_1355 = (void*)0;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1277[i][j] = 0xC193A225L;
            }
            for (g_34 = 0; (g_34 <= 1); g_34 += 1)
            { /* block id: 629 */
                int64_t ***l_1250 = &l_1248;
                const int64_t ***l_1253 = &l_1251[2][0];
                int32_t *l_1264 = &g_113;
                int32_t l_1269 = 0x6F299FB1L;
                int32_t l_1276 = 0x99CA1182L;
                int32_t l_1278[3][3][4] = {{{0x05781211L,(-1L),0x3FC8E5F8L,0L},{0L,(-1L),1L,0x94F9D50BL},{(-1L),4L,(-1L),3L}},{{1L,1L,0L,0x05781211L},{0L,1L,3L,1L},{0x94F9D50BL,0x3A9CF815L,3L,(-6L)}},{{0L,0L,0L,0L},{1L,0x94F9D50BL,(-1L),0xA67A7CCBL},{(-1L),0xA67A7CCBL,1L,0x3A9CF815L}}};
                uint32_t l_1282 = 0xD5FC5197L;
                int i, j, k;
                (*l_1264) |= (safe_div_func_int16_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */(((l_1245 = g_1045[g_34]) | (safe_lshift_func_int32_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */(1L, ((((g_1045[g_34] | ((l_295 = (((*l_1250) = l_1248) == ((*l_1253) = l_1251[2][0]))) == (((((-1L) || (((0x0E09L && (safe_div_func_uint32_t_u_u_unsafe_macro/*118*//* ___SAFE__OP */(p_16, (safe_sub_func_uint16_t_u_u_unsafe_macro/*119*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*120*//* ___SAFE__OP */((((((void*)0 != l_1260) , 0x019A7627AEF4F52BLL) >= (*g_1149)) <= (*g_1149)), 4)), l_1262))))) ^ (*g_1148)) & (*g_1149))) & 0x33L) , g_1045[g_34]) != l_1263))) & (**g_442)) ^ l_1083[3][5]) && (**g_1233))))), 0xFB91L));
                if (p_16)
                    break;
                for (g_480 = 0; (g_480 <= 8); g_480 += 1)
                { /* block id: 638 */
                    int32_t *l_1265 = &l_1263;
                    int32_t l_1266 = 0x597196CDL;
                    int32_t *l_1267 = &g_678[2];
                    int32_t *l_1268[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1268[i] = (void*)0;
                    --l_1270;
                    for (g_113 = 0; (g_113 <= 8); g_113 += 1)
                    { /* block id: 642 */
                        int32_t **l_1273 = (void*)0;
                        int32_t **l_1274 = &g_82;
                        int32_t **l_1275 = &l_1265;
                        int32_t l_1281 = 0xF018A55FL;
                        if ((*g_82))
                            break;
                        (*l_1275) = ((*l_1274) = &l_1263);
                        --l_1282;
                    }
                    l_1288 = g_1285;
                    return l_1289[1][0];
                }
            }
            for (g_520 = 5; (g_520 >= 0); g_520 -= 1)
            { /* block id: 654 */
                const uint16_t *l_1290 = (void*)0;
                int32_t *l_1294 = (void*)0;
                uint16_t ** const *l_1341[9][9][2] = {{{(void*)0,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,(void*)0},{&g_377,&g_377},{(void*)0,(void*)0},{(void*)0,&g_377},{&g_377,(void*)0},{&g_377,&g_377}},{{&g_377,&g_377},{(void*)0,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,(void*)0},{&g_377,&g_377},{(void*)0,(void*)0},{(void*)0,&g_377},{&g_377,(void*)0}},{{&g_377,&g_377},{&g_377,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,(void*)0},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377}},{{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,(void*)0},{(void*)0,&g_377},{&g_377,&g_377}},{{&g_377,&g_377},{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,(void*)0},{(void*)0,&g_377}},{{&g_377,&g_377},{&g_377,&g_377},{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,(void*)0}},{{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,&g_377}},{{&g_377,(void*)0},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377}},{{(void*)0,&g_377},{&g_377,(void*)0},{(void*)0,&g_377},{&g_377,&g_377},{&g_377,&g_377},{(void*)0,(void*)0},{&g_377,&g_377},{(void*)0,&g_377},{&g_377,&g_377}}};
                int32_t l_1378 = 0x61496BBDL;
                int32_t l_1379 = 0L;
                int32_t l_1382 = 0xF03ECC8DL;
                int32_t l_1386 = (-6L);
                int32_t l_1387 = (-2L);
                int32_t l_1388 = (-1L);
                int32_t l_1389[2][4][10] = {{{3L,(-6L),(-1L),(-10L),(-6L),0x2EEE6D3CL,0x0FEF762DL,3L,(-3L),(-10L)},{0L,(-1L),(-1L),(-10L),0x6FF34A56L,0x6FF34A56L,(-10L),(-1L),(-1L),0L},{(-1L),3L,(-1L),6L,0x6C88F427L,9L,(-1L),0L,9L,(-1L)},{3L,0L,(-1L),3L,0x6C88F427L,(-3L),0x6C88F427L,3L,(-1L),0L}},{{0x6C88F427L,(-1L),(-8L),0x0FEF762DL,0x6FF34A56L,(-8L),0L,(-1L),(-1L),(-10L)},{6L,3L,0x6FF34A56L,9L,(-6L),(-8L),(-8L),(-6L),9L,0x6FF34A56L},{0x6C88F427L,0x6C88F427L,1L,(-6L),0x7288399FL,(-3L),0x0FEF762DL,0x6C88F427L,0x7288399FL,(-1L)},{(-1L),(-1L),1L,0x6FF34A56L,(-1L),(-1L),(-1L),(-1L),(-1L),0x6FF34A56L}}};
                int32_t l_1393 = 0x59D3DA32L;
                uint32_t l_1394 = 4294967295UL;
                int32_t *l_1430 = &l_1387;
                int32_t *l_1431 = &g_34;
                int32_t *l_1432 = &l_1382;
                int32_t *l_1433[1];
                uint8_t l_1434 = 0x78L;
                uint64_t *l_1437[2];
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_1433[i] = (void*)0;
                for (i = 0; i < 2; i++)
                    l_1437[i] = (void*)0;
            }
            (*g_82) = ((safe_unary_minus_func_int16_t_s_unsafe_macro/*121*//* ___SAFE__OP */(p_16)) | ((((safe_rshift_func_int16_t_s_u_unsafe_macro/*122*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*123*//* ___SAFE__OP */(0x58C4L, 2)), 0)) ^ 0x85L) != (l_1262 = 65535UL)) >= l_1421));
        }
        (*l_1455) = &l_1083[6][1];
    }
    (*l_1456) = &l_1083[7][1];
    (*l_1456) = (*l_1456);
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_36
 * writes:
 */
static int64_t  func_23(int8_t * p_24, int64_t  p_25, int8_t * p_26, int8_t * p_27)
{ /* block id: 11 */
    return g_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_36 g_34 g_43
 * writes: g_36 g_34
 */
static int8_t * func_28(union U0  p_29, const int32_t  p_30, uint32_t  p_31)
{ /* block id: 1 */
    int32_t *l_33 = &g_34;
    int32_t *l_35[10][2] = {{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34}};
    int i, j;
    g_36--;
    (*l_33) = (safe_rshift_func_int64_t_s_u(g_34, 9));
    for (g_36 = 24; (g_36 <= 25); g_36 = safe_add_func_int16_t_s_s_unsafe_macro/*125*//* ___SAFE__OP */(g_36, 1))
    { /* block id: 6 */
        if (p_29.f0)
            break;
    }
    return g_43;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_46(int8_t  p_47)
{ /* block id: 448 */
    int32_t *l_920 = &g_522;
    int32_t *l_921 = (void*)0;
    int32_t *l_922 = &g_34;
    int32_t *l_923 = &g_34;
    int32_t l_924[6];
    int32_t *l_925[8][10] = {{&g_113,&l_924[2],(void*)0,(void*)0,&l_924[2],&g_113,&g_34,(void*)0,&g_111,&g_678[2]},{(void*)0,&g_678[1],&g_111,&g_113,(void*)0,&g_678[2],&g_34,&g_111,&g_34,&g_678[2]},{(void*)0,(void*)0,&g_113,(void*)0,(void*)0,&g_113,&g_678[2],&g_34,&g_522,&g_113},{&g_113,&g_678[2],&g_34,&g_522,&g_113,&g_678[2],&l_924[2],&l_924[2],&g_678[2],&g_113},{&g_113,&g_522,&g_522,&g_113,(void*)0,&g_678[1],&g_111,&g_113,(void*)0,&g_678[2]},{&g_34,(void*)0,&g_111,&g_678[2],(void*)0,&g_111,&g_522,&g_111,(void*)0,&g_678[2]},{&g_678[2],&g_34,&g_678[2],&g_113,&l_924[2],&g_111,(void*)0,&g_34,&g_678[2],(void*)0},{(void*)0,&g_111,(void*)0,&g_522,&g_34,&g_113,&g_113,&g_34,&g_522,(void*)0}};
    uint16_t l_926 = 0xFF25L;
    int16_t l_929 = 6L;
    uint32_t l_930 = 5UL;
    int64_t l_933[9] = {0x0B8278354BE006DBLL,0x0B8278354BE006DBLL,0L,0x0B8278354BE006DBLL,0x0B8278354BE006DBLL,0L,0x0B8278354BE006DBLL,0x0B8278354BE006DBLL,0L};
    int8_t l_934 = 1L;
    int16_t l_935 = 0xF8FAL;
    int16_t l_937 = 0x258CL;
    int64_t l_938 = 0xFF5E1F0ECE601AA6LL;
    uint16_t l_939 = 65535UL;
    int i, j;
    for (i = 0; i < 6; i++)
        l_924[i] = 0xA782CE0EL;
    --l_926;
    l_930++;
    --l_939;
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_212 g_521 g_614 g_900 g_649 g_61 g_376 g_377 g_350 g_391
 * writes: g_212 g_900 g_649 g_475 g_82
 */
static int32_t  func_48(int8_t * p_49, uint8_t  p_50, int32_t  p_51, int32_t * p_52)
{ /* block id: 412 */
    uint32_t l_880[8] = {0x19E51071L,0x19E51071L,0x19E51071L,0x19E51071L,0x19E51071L,0x19E51071L,0x19E51071L,0x19E51071L};
    int8_t ***l_881 = (void*)0;
    int32_t l_895 = 0xCE506908L;
    int32_t l_896 = 4L;
    int32_t l_897 = 0L;
    int32_t l_898 = 0xA52F676EL;
    int32_t l_899[3][7] = {{6L,9L,6L,6L,9L,6L,6L},{(-7L),(-7L),0xB3A348FCL,(-7L),(-7L),0xB3A348FCL,(-7L)},{9L,6L,6L,9L,6L,6L,9L}};
    uint16_t ****l_911[1][8][4] = {{{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376},{&g_376,&g_376,&g_376,&g_376}}};
    int32_t **l_919 = &g_82;
    int i, j, k;
lbl_907:
    for (g_212 = 0; (g_212 < (-26)); g_212 = safe_sub_func_uint8_t_u_u_unsafe_macro/*126*//* ___SAFE__OP */(g_212, 9))
    { /* block id: 415 */
        uint16_t ***l_870[5];
        uint16_t ****l_871 = (void*)0;
        uint16_t ****l_872 = (void*)0;
        uint16_t ****l_873 = &l_870[3];
        int i;
        for (i = 0; i < 5; i++)
            l_870[i] = &g_377;
        (*l_873) = l_870[3];
        return p_50;
    }
    if (g_521[4])
    { /* block id: 419 */
        uint16_t l_884 = 0x850BL;
        int32_t l_885 = (-2L);
        int32_t l_891 = 0L;
        int32_t l_893 = 0L;
        int32_t l_894[1][7][5] = {{{0xCB90718DL,0x28606DE2L,0x60FA50E4L,0x7B23A9C2L,0x7B23A9C2L},{0x28606DE2L,0xCB90718DL,0x28606DE2L,0x60FA50E4L,0xCB90718DL},{0x60FA50E4L,0x28606DE2L,0xCB90718DL,0x28606DE2L,0x60FA50E4L},{(-3L),0x28606DE2L,0L,0x60FA50E4L,0L},{0L,0L,0xCB90718DL,0x60FA50E4L,0x8AFCF2D8L},{0x28606DE2L,(-3L),(-3L),0x28606DE2L,0L},{0x28606DE2L,0x60FA50E4L,0x7B23A9C2L,0x7B23A9C2L,0x60FA50E4L}}};
        int32_t *l_909 = &l_895;
        int i, j, k;
        if (((*p_52) ^= (safe_add_func_int64_t_s_s_unsafe_macro/*127*//* ___SAFE__OP */((&g_480 != (void*)0), (safe_mod_func_int8_t_s_s_unsafe_macro/*128*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_s((l_880[1] > (l_881 != &g_298)), l_880[1])) ^ (safe_mul_func_uint32_t_u_u_unsafe_macro/*130*//* ___SAFE__OP */((g_614[7] , ((p_50 , (0xED73L && l_880[4])) , l_884)), l_880[1]))), 0x12L))))))
        { /* block id: 421 */
            int32_t *l_886 = &g_678[1];
            int32_t *l_887 = &g_678[3];
            int32_t l_888[5] = {0xB764FD86L,0xB764FD86L,0xB764FD86L,0xB764FD86L,0xB764FD86L};
            int32_t *l_889 = &l_888[4];
            int32_t *l_890 = &l_888[4];
            int32_t *l_892[5][9] = {{&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891},{&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4]},{&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891},{&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4],&g_522,&l_888[4]},{&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891,&l_891}};
            int i, j;
            g_900++;
            for (l_885 = 0; (l_885 <= 2); l_885 = safe_add_func_uint8_t_u_u_unsafe_macro/*131*//* ___SAFE__OP */(l_885, 7))
            { /* block id: 425 */
                for (g_649 = 0; (g_649 <= 21); ++g_649)
                { /* block id: 428 */
                    int32_t **l_908 = &l_890;
                    if (g_649)
                        goto lbl_907;
                    (*l_908) = (void*)0;
                    if (l_885)
                    { /* block id: 431 */
                        (*l_908) = l_909;
                        return g_61[1][1];
                    }
                    else
                    { /* block id: 434 */
                        return p_50;
                    }
                }
            }
        }
        else
        { /* block id: 439 */
            uint16_t *****l_910 = &g_475;
            (*p_52) &= (((((*l_910) = &g_376) != l_911[0][4][3]) < (((((void*)0 != (**g_376)) ^ (safe_unary_minus_func_uint32_t_u_unsafe_macro/*132*//* ___SAFE__OP */(p_50))) && ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*133*//* ___SAFE__OP */(g_391[1], (((safe_add_func_uint64_t_u_u_unsafe_macro/*134*//* ___SAFE__OP */(((safe_unary_minus_func_int16_t_s_unsafe_macro/*135*//* ___SAFE__OP */((~p_51))) == 0x5994L), (-1L))) , p_51) , 1UL))) || 0xFBEEL)) , 0UL)) ^ p_51);
        }
    }
    else
    { /* block id: 443 */
        return g_61[1][4];
    }
    (*l_919) = &g_678[2];
    return p_51;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_34 g_126 g_258 g_212 g_113 g_111 g_45 g_61 g_189 g_139 g_377 g_350 g_297 g_480 g_36 g_43 g_428 g_429 g_430 g_104 g_391 g_525 g_407 g_521 g_92 g_376 g_297.f0 g_522 g_614 g_649 g_32 g_415 g_441 g_442 g_520 g_737 g_32.f0 g_677 g_784 g_814
 * writes: g_126 g_61 g_113 g_34 g_350 g_111 g_475 g_480 g_36 g_139 g_189 g_525 g_415 g_258 g_376 g_520 g_212 g_82 g_649 g_104 g_614 g_814 g_831 g_521
 */
static int64_t  func_53(int8_t ** p_54, const int8_t * const * p_55, uint16_t  p_56, int32_t  p_57)
{ /* block id: 104 */
    int64_t *l_299 = &g_212;
    int64_t *l_300 = &g_212;
    int32_t l_316 = 0xEAD5827AL;
    int32_t l_317 = 0x7445598BL;
    int32_t **l_339 = &g_82;
    int32_t **l_340 = (void*)0;
    uint16_t *l_351 = (void*)0;
    const int64_t l_353 = (-8L);
    uint32_t * const l_375 = &g_139[7][2][0];
    int8_t **l_420 = &g_43;
    const int8_t **l_431 = &g_429;
    int32_t *l_466 = (void*)0;
    int32_t **l_556 = (void*)0;
    int64_t l_574[6];
    uint16_t ***l_577 = &g_377;
    uint16_t * const l_613 = &g_614[6];
    uint16_t * const *l_612 = &l_613;
    uint8_t *l_648 = &g_649;
    uint8_t **l_647 = &l_648;
    uint8_t *** const l_646 = &l_647;
    int32_t l_687 = 0xAE9B6DB0L;
    int32_t l_688 = 0x86EEA1EDL;
    int32_t l_700 = 8L;
    int32_t l_801 = 0xFB6B164FL;
    int32_t l_802[7][4] = {{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),0x7E44163DL,(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)},{(-2L),(-2L),0x7E44163DL,(-2L)},{(-2L),(-1L),(-1L),(-2L)},{(-1L),(-2L),(-1L),(-1L)}};
    union U0 *l_833[6][7][4] = {{{&g_32,&g_297,&g_32,(void*)0},{&g_832,&g_32,&g_832,&g_32},{&g_32,&g_832,&g_297,(void*)0},{&g_297,(void*)0,&g_32,&g_832},{&g_32,&g_297,&g_32,&g_32},{&g_297,(void*)0,&g_297,(void*)0},{&g_32,&g_32,&g_832,&g_32}},{{&g_832,&g_32,&g_32,&g_32},{&g_32,&g_297,&g_297,&g_32},{&g_32,&g_832,&g_32,(void*)0},{&g_32,&g_32,&g_32,&g_832},{(void*)0,&g_32,&g_32,&g_832},{(void*)0,&g_32,&g_32,&g_297},{(void*)0,&g_832,&g_32,(void*)0}},{{(void*)0,(void*)0,&g_297,&g_297},{&g_32,(void*)0,(void*)0,&g_297},{(void*)0,&g_32,&g_32,&g_32},{&g_297,&g_32,&g_832,&g_832},{&g_297,&g_32,&g_32,&g_32},{&g_32,&g_32,&g_832,(void*)0},{&g_832,(void*)0,(void*)0,&g_832}},{{&g_297,(void*)0,&g_32,&g_832},{(void*)0,&g_297,&g_32,(void*)0},{&g_297,&g_32,&g_297,(void*)0},{&g_297,&g_832,&g_832,(void*)0},{(void*)0,&g_832,(void*)0,(void*)0},{&g_832,(void*)0,&g_832,&g_32},{&g_297,&g_832,&g_832,&g_32}},{{&g_32,&g_832,&g_832,(void*)0},{&g_32,&g_832,&g_832,&g_32},{&g_832,(void*)0,(void*)0,&g_32},{&g_832,&g_832,&g_32,&g_32},{&g_832,&g_297,(void*)0,&g_32},{(void*)0,(void*)0,&g_32,&g_32},{&g_832,&g_32,&g_297,&g_832}},{{&g_32,&g_832,&g_32,&g_297},{&g_32,&g_832,&g_297,&g_832},{&g_832,&g_297,(void*)0,(void*)0},{&g_32,&g_297,&g_32,(void*)0},{&g_832,&g_297,&g_32,&g_32},{&g_832,&g_32,&g_32,&g_832},{&g_32,&g_32,(void*)0,&g_832}}};
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_574[i] = (-3L);
    if (((l_299 = &g_212) == l_300))
    { /* block id: 106 */
        uint8_t l_305 = 247UL;
        int8_t *l_306 = &g_126;
        uint16_t *l_318 = &g_61[1][1];
        int32_t *l_319 = &g_113;
        int32_t l_408 = 0L;
        uint8_t ***l_445 = (void*)0;
        int32_t l_458 = 0L;
        int32_t l_459 = 0x5C97F00FL;
        const union U0 *l_464 = &g_32;
        int64_t l_509 = (-1L);
        (*l_319) ^= (((*g_82) | (safe_add_func_int16_t_s_s_unsafe_macro/*136*//* ___SAFE__OP */(0x8D78L, ((safe_rshift_func_uint16_t_u_s(((*l_318) = (((*l_306) |= l_305) <= (l_317 ^= (safe_sub_func_uint8_t_u_u_unsafe_macro/*138*//* ___SAFE__OP */(((((safe_sub_func_uint16_t_u_u_unsafe_macro/*139*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*140*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*141*//* ___SAFE__OP */(0UL, 1)), l_305)), ((~(l_305 == g_258[2][0][1])) <= ((-9L) >= (l_316 || l_305))))) != p_57) < l_316) != l_316), 255UL))))), g_212)) , 0xD2CDL)))) > 0x0131B42E5B4E503ALL);
        if ((p_56 > 0xA7L))
        { /* block id: 111 */
            uint16_t **l_321 = (void*)0;
            uint16_t ***l_320 = &l_321;
            uint32_t *l_332 = &g_139[4][7][0];
            uint32_t **l_331 = &l_332;
            uint32_t *l_335[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint8_t *l_337 = (void*)0;
            uint8_t **l_336 = &l_337;
            int i;
            (*l_320) = &g_136;
            (*l_319) = (((((!(safe_mul_func_int16_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */(p_56, (safe_mul_func_uint8_t_u_u_unsafe_macro/*143*//* ___SAFE__OP */(g_111, p_56))))) < ((((*g_82) = 0x94A6969CL) >= (*l_319)) > (safe_add_func_int64_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */(((g_45 == ((*l_336) = ((((*l_331) = (void*)0) == (((safe_sub_func_int16_t_s_s_unsafe_macro/*146*//* ___SAFE__OP */((&g_82 == &l_319), 65535UL)) > p_56) , l_335[2])) , (void*)0))) ^ l_316), p_56)), p_57)))) , 0x24L) ^ (-10L)) , p_57);
        }
        else
        { /* block id: 117 */
            uint16_t *l_347 = &g_258[0][4][0];
            uint16_t **l_348 = &g_136;
            uint16_t **l_349[4][9] = {{&l_318,&l_318,&l_318,&l_318,&l_318,&l_318,&l_318,&l_318,&l_318},{&g_136,&l_347,&l_347,&g_136,&g_136,&g_136,&l_347,&l_347,&g_136},{&l_318,&l_318,&g_136,&l_318,&l_318,&l_318,&l_318,&g_136,&l_318},{&l_347,&g_136,(void*)0,(void*)0,&g_136,&l_347,&g_136,(void*)0,(void*)0}};
            int32_t l_352 = 0x3256DE87L;
            int32_t *l_354 = &l_317;
            uint8_t *l_387 = (void*)0;
            uint8_t **l_418 = &l_387;
            uint8_t ** const *l_417[4][10][4] = {{{(void*)0,&l_418,&l_418,&l_418},{&l_418,(void*)0,&l_418,&l_418},{&l_418,&l_418,(void*)0,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,(void*)0,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,(void*)0},{(void*)0,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,(void*)0},{&l_418,&l_418,&l_418,&l_418}},{{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,(void*)0,&l_418},{&l_418,&l_418,(void*)0,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,(void*)0,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{(void*)0,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418}},{{(void*)0,&l_418,(void*)0,&l_418},{(void*)0,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{(void*)0,&l_418,&l_418,&l_418},{&l_418,(void*)0,&l_418,(void*)0},{&l_418,(void*)0,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418}},{{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{(void*)0,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418},{(void*)0,&l_418,(void*)0,&l_418},{(void*)0,&l_418,&l_418,&l_418},{&l_418,&l_418,&l_418,&l_418}}};
            int i, j, k;
            (*l_354) |= ((p_56 == (((safe_unary_minus_func_int32_t_s_unsafe_macro/*147*//* ___SAFE__OP */((l_339 == l_340))) | (((safe_rshift_func_uint16_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */(p_57, 9)) | (g_34 , (((l_352 |= (safe_div_func_uint64_t_u_u_unsafe_macro/*149*//* ___SAFE__OP */((g_61[1][1] ^ ((p_56 != (safe_div_func_int16_t_s_s_unsafe_macro/*150*//* ___SAFE__OP */((((((g_350 = l_347) == (l_318 = l_351)) <= (-7L)) , p_56) != g_113), 0x528EL))) == (-1L))), (*l_319)))) | p_57) <= 0xAAE3L))) ^ l_353)) , g_189[3])) ^ (*l_319));
            for (g_111 = 0; (g_111 <= 2); g_111 += 1)
            { /* block id: 124 */
                int16_t *l_369 = &g_104;
                int32_t l_374[6][3] = {{0x73D204DFL,0x73D204DFL,(-2L)},{1L,(-2L),(-2L)},{(-2L),0x73A31FFBL,0x748EBBB2L},{1L,0x73A31FFBL,1L},{0x73D204DFL,(-2L),0x748EBBB2L},{0x73D204DFL,0x73D204DFL,(-2L)}};
                int32_t l_393 = 0x0E3AF4C3L;
                int32_t l_454 = 0xFD88F71AL;
                int i, j;
            }
            if ((g_139[0][5][1] ^ p_57))
            { /* block id: 214 */
                uint16_t ****l_474 = &g_376;
                uint16_t ***l_477 = (void*)0;
                int64_t *l_553 = (void*)0;
                for (l_305 = 0; (l_305 == 32); l_305++)
                { /* block id: 217 */
                    int32_t l_473 = 4L;
                    uint16_t ***l_476 = &l_349[0][5];
                    uint32_t l_482 = 0xD6ABD421L;
                    for (g_126 = 13; (g_126 < (-12)); g_126 = safe_sub_func_int64_t_s_s_unsafe_macro/*151*//* ___SAFE__OP */(g_126, 6))
                    { /* block id: 220 */
                        int32_t *l_478 = (void*)0;
                        int32_t *l_479 = &g_480;
                        int16_t *l_481[2][6][4] = {{{(void*)0,&g_104,&g_104,(void*)0},{&g_104,(void*)0,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104},{(void*)0,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104},{&g_104,(void*)0,(void*)0,(void*)0}},{{&g_104,&g_104,&g_104,&g_104},{(void*)0,&g_104,&g_104,(void*)0},{&g_104,(void*)0,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104},{(void*)0,&g_104,&g_104,&g_104},{&g_104,&g_104,(void*)0,&g_104}}};
                        int i, j, k;
                        if ((**l_339))
                            break;
                        (*l_319) = ((0x3281L | (((safe_rshift_func_uint16_t_u_u_unsafe_macro/*152*//* ___SAFE__OP */((l_473 , (&g_377 != &l_348)), (**g_377))) , func_28(g_297, ((*l_479) |= (((g_475 = l_474) == &g_376) || (l_476 != l_477))), l_473)) == (*g_428))) , (*g_82));
                        (*l_319) = (((*l_354) = p_56) ^ l_482);
                    }
                }
                for (g_126 = 0; (g_126 >= (-8)); g_126 = safe_sub_func_int8_t_s_s_unsafe_macro/*153*//* ___SAFE__OP */(g_126, 7))
                { /* block id: 231 */
                    const uint32_t *l_495 = &g_92;
                    const uint32_t **l_494[5];
                    const uint32_t ***l_493 = &l_494[2];
                    uint64_t *l_512[3][7][9] = {{{&g_407,&g_189[0],&g_407,&g_407,&g_407,&g_189[0],&g_407,&g_189[0],&g_407},{(void*)0,&g_189[1],&g_189[0],&g_407,&g_189[1],&g_189[1],&g_407,&g_189[0],&g_189[1]},{&g_189[0],&g_189[0],(void*)0,&g_407,(void*)0,&g_189[0],&g_189[0],&g_189[0],(void*)0},{(void*)0,&g_189[0],&g_189[0],(void*)0,&g_189[1],&g_189[0],&g_189[0],&g_407,&g_407},{&g_407,&g_189[2],&g_407,&g_189[0],&g_407,&g_189[2],&g_407,&g_189[2],&g_407},{&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407,&g_189[0],&g_189[0],&g_407},{(void*)0,&g_189[2],&g_189[0],&g_189[0],&g_189[0],&g_189[2],(void*)0,&g_189[2],&g_189[0]}},{{&g_189[1],&g_189[0],&g_189[0],&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407},{&g_407,&g_189[2],&g_407,&g_189[0],&g_407,&g_189[2],&g_407,&g_189[2],&g_407},{&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407,&g_189[0],&g_189[0],&g_407},{(void*)0,&g_189[2],&g_189[0],&g_189[0],&g_189[0],&g_189[2],(void*)0,&g_189[2],&g_189[0]},{&g_189[1],&g_189[0],&g_189[0],&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407},{&g_407,&g_189[2],&g_407,&g_189[0],&g_407,&g_189[2],&g_407,&g_189[2],&g_407},{&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407,&g_189[0],&g_189[0],&g_407}},{{(void*)0,&g_189[2],&g_189[0],&g_189[0],&g_189[0],&g_189[2],(void*)0,&g_189[2],&g_189[0]},{&g_189[1],&g_189[0],&g_189[0],&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407},{&g_407,&g_189[2],&g_407,&g_189[0],&g_407,&g_189[2],&g_407,&g_189[2],&g_407},{&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407,&g_189[0],&g_189[0],&g_407},{(void*)0,&g_189[2],&g_189[0],&g_189[0],&g_189[0],&g_189[2],(void*)0,&g_189[2],&g_189[0]},{&g_189[1],&g_189[0],&g_189[0],&g_189[1],&g_407,&g_189[0],&g_189[0],&g_407,&g_407},{&g_407,&g_189[2],&g_407,&g_189[0],&g_407,&g_189[2],&g_407,&g_189[2],&g_407}}};
                    int32_t l_516[10] = {(-7L),0x801B87AFL,0x801B87AFL,(-7L),0x801B87AFL,0x801B87AFL,(-7L),0x801B87AFL,0x801B87AFL,(-7L)};
                    int32_t l_524 = (-5L);
                    int32_t l_536 = 1L;
                    uint64_t l_554 = 18446744073709551611UL;
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_494[i] = &l_495;
                    if ((5UL | ((((*l_354) , (((safe_lshift_func_uint16_t_u_u_unsafe_macro/*154*//* ___SAFE__OP */(p_56, 13)) & ((*l_319) = 0xCEF642E6L)) , 0x1F51L)) , (safe_mul_func_uint16_t_u_u_unsafe_macro/*155*//* ___SAFE__OP */((p_57 <= (*g_82)), (((*l_375) = (g_61[1][1] | ((*g_429) == (*l_319)))) && p_56)))) , (*l_319))))
                    { /* block id: 234 */
                        uint32_t l_490 = 9UL;
                        uint32_t ****l_496 = (void*)0;
                        uint32_t ****l_497 = (void*)0;
                        uint32_t ****l_498 = (void*)0;
                        uint32_t ***l_500 = &g_415;
                        uint32_t ****l_499 = &l_500;
                        uint64_t *l_504 = (void*)0;
                        uint64_t *l_505 = &g_297.f1;
                        uint64_t *l_506 = (void*)0;
                        uint64_t *l_507 = &g_189[0];
                        int32_t l_508 = 0L;
                        l_508 |= (((+l_490) & ((safe_add_func_uint32_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */((l_493 != ((*l_499) = &g_415)), ((safe_lshift_func_int64_t_s_s_unsafe_macro/*157*//* ___SAFE__OP */((+((*g_82) < (*g_82))), 24)) && (*l_354)))) != ((*l_507) |= ((*l_319) &= g_104)))) < ((&g_391[5] == &g_391[5]) >= p_56));
                        (**l_339) = (*g_82);
                        if (l_509)
                            continue;
                    }
                    else
                    { /* block id: 241 */
                        if ((**l_339))
                            break;
                    }
                    (*l_354) ^= (safe_sub_func_uint8_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */((((g_189[2] ^= 0x83C03B8CA4421C1DLL) & 1UL) <= ((safe_add_func_int64_t_s_s_unsafe_macro/*159*//* ___SAFE__OP */(((g_391[5] <= (0xDCAAD3A0L > (p_56 && (!((*g_429) && l_516[6]))))) < (((*l_375) = ((!(safe_add_func_uint8_t_u_u_unsafe_macro/*160*//* ___SAFE__OP */(((--g_525) | (safe_lshift_func_uint16_t_u_u_unsafe_macro/*161*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*162*//* ___SAFE__OP */(((((g_61[0][3] |= (safe_rshift_func_int16_t_s_s_unsafe_macro/*163*//* ___SAFE__OP */((((safe_add_func_uint32_t_u_u_unsafe_macro/*164*//* ___SAFE__OP */(0xCC7E63A4L, (*g_82))) == p_57) , g_258[2][0][1]), g_139[7][4][0]))) , 0xB4ACBCA5L) > p_57) && p_57), p_57)), 2))), p_56))) & 0xCB340751C18EDC46LL)) ^ p_57)), (**l_339))) >= p_57)), l_536));
                    for (g_111 = 0; (g_111 <= 3); g_111 += 1)
                    { /* block id: 251 */
                        int64_t l_551 = 0xADC35C49650F0EF7LL;
                        int32_t l_552 = (-9L);
                        (*l_354) = (((safe_div_func_int16_t_s_s_unsafe_macro/*165*//* ___SAFE__OP */(0x24FDL, ((((l_536 == ((*l_319) = g_391[6])) & (safe_rshift_func_uint64_t_u_u_unsafe_macro/*166*//* ___SAFE__OP */(g_407, ((p_56 , (((l_552 |= ((251UL > (-5L)) , ((((safe_mul_func_int64_t_s_s_unsafe_macro/*167*//* ___SAFE__OP */(2L, (safe_mul_func_int32_t_s_s_unsafe_macro/*168*//* ___SAFE__OP */(((**l_339) = ((l_551 ^= (safe_rshift_func_uint16_t_u_s_unsafe_macro/*169*//* ___SAFE__OP */(((safe_mod_func_int64_t_s_s_unsafe_macro/*170*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*171*//* ___SAFE__OP */(p_57, p_56)), g_258[1][3][2])) || g_521[3]), 11))) >= 18446744073709551606UL)), 0L)))) && l_516[4]) > (*l_354)) , (*g_350)))) , p_56) , &g_391[5])) != l_553)))) >= l_554) && p_57))) >= p_56) <= p_57);
                        (*l_354) = p_56;
                    }
                    (*l_319) ^= 1L;
                }
            }
            else
            { /* block id: 261 */
                (*l_354) &= (*g_82);
            }
        }
    }
    else
    { /* block id: 265 */
        int32_t **l_555 = (void*)0;
        uint32_t ***l_557 = &g_415;
        int32_t l_570 = 0x9F338683L;
        int16_t l_571 = 0x5705L;
        int32_t *l_572[3];
        uint16_t ***l_578 = &g_377;
        int32_t l_598 = 0x8CF32747L;
        int64_t l_601 = (-4L);
        int16_t l_602[8][6][2] = {{{0L,(-1L)},{0L,0x8CEDL},{(-3L),0xBF23L},{0x8CEDL,(-5L)},{0xAC2BL,8L},{0xBD8AL,0x3CFDL}},{{0x3CFDL,3L},{(-1L),0xA8BBL},{0x3EB3L,0L},{7L,0x0E0DL},{8L,0x4A07L},{3L,(-1L)}},{{(-5L),0xA8BBL},{0x57EEL,0x3EB3L},{3L,(-5L)},{0L,0xBD8AL},{0x3CFDL,(-1L)},{(-1L),0x57EEL}},{{0x086AL,0x086AL},{0x0E0DL,3L},{0xBF23L,(-1L)},{7L,0x8CEDL},{(-1L),7L},{0xBD8AL,(-3L)}},{{0xBD8AL,7L},{(-1L),0x8CEDL},{7L,(-1L)},{0xBF23L,3L},{0x0E0DL,0x086AL},{0x086AL,0x57EEL}},{{(-1L),(-1L)},{0x3CFDL,0xBD8AL},{0L,(-5L)},{3L,0x3EB3L},{0x57EEL,0xA8BBL},{(-5L),0xA8BBL}},{{0x57EEL,0x3EB3L},{3L,(-5L)},{0L,0xBD8AL},{0x3CFDL,(-1L)},{(-1L),0x57EEL},{0x086AL,0x086AL}},{{0x0E0DL,3L},{0xBF23L,(-1L)},{7L,0x8CEDL},{(-1L),7L},{0xBD8AL,(-3L)},{0xBD8AL,7L}}};
        uint32_t l_623 = 0xC4A3E8A9L;
        int32_t *l_624 = &g_111;
        uint32_t l_639 = 0UL;
        uint64_t l_663 = 4UL;
        int32_t l_679 = 0x2A41DEB0L;
        int64_t **l_748 = &l_299;
        uint32_t l_756 = 6UL;
        int64_t l_806[3][8] = {{(-1L),0xCA682DEB60026FFALL,0xCA682DEB60026FFALL,(-1L),0L,0x005F33A944834A74LL,0L,(-1L)},{0xCA682DEB60026FFALL,0L,0xCA682DEB60026FFALL,(-4L),(-10L),(-10L),(-4L),0xCA682DEB60026FFALL},{0L,0L,(-10L),0x005F33A944834A74LL,0x81ACCC2F6187CDC1LL,0x005F33A944834A74LL,(-10L),0L}};
        int8_t l_808 = (-1L);
        int32_t l_811 = 0x8F6A7D3AL;
        int32_t l_813 = (-10L);
        union U0 *l_829 = &g_297;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_572[i] = &g_111;
        l_317 ^= ((l_555 != l_556) == ((***g_376) = ((((18446744073709551607UL & g_521[4]) || (((*l_557) = (void*)0) != &l_375)) , (safe_sub_func_int64_t_s_s_unsafe_macro/*172*//* ___SAFE__OP */(((safe_div_func_uint64_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*174*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u_unsafe_macro/*175*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*176*//* ___SAFE__OP */((-9L), (safe_div_func_uint64_t_u_u_unsafe_macro/*177*//* ___SAFE__OP */((l_570 < 0x1C583FD0L), (**l_339))))), g_212)), p_56)) , g_92), g_521[4])) | p_56), l_571))) == (**g_377))));
        if (p_57)
            goto lbl_573;
        if ((*g_82))
        { /* block id: 269 */
lbl_573:
            (**l_339) = (**l_339);
lbl_757:
            l_574[4] = (*g_82);
            for (g_480 = (-6); (g_480 > (-13)); g_480--)
            { /* block id: 275 */
                uint16_t ****l_579 = &g_376;
                int32_t l_581 = (-1L);
                int8_t *l_591 = &g_520;
                uint64_t *l_597 = &g_189[0];
                int32_t l_599 = 0x59477401L;
                int32_t *l_600 = &l_570;
                l_602[6][5][0] = ((g_92 ^ ((l_577 != ((*l_579) = l_578)) , (+(l_581 && (+(safe_unary_minus_func_int8_t_s_unsafe_macro/*178*//* ___SAFE__OP */((((((*l_600) |= ((safe_lshift_func_uint8_t_u_s_unsafe_macro/*179*//* ___SAFE__OP */(((p_56 , (!(((safe_mod_func_uint16_t_u_u_unsafe_macro/*180*//* ___SAFE__OP */((~(+(p_57 ^ ((((*l_591) = (*g_429)) , ((safe_unary_minus_func_uint64_t_u_unsafe_macro/*181*//* ___SAFE__OP */(((safe_rshift_func_uint8_t_u_u_unsafe_macro/*182*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*183*//* ___SAFE__OP */((p_57 , (((*l_597) = g_61[1][5]) <= p_57)), l_598)), p_57)) & 0UL))) , 1UL)) , l_599)))), p_57)) && g_189[3]) >= 0UL))) | l_581), 0)) | p_57)) , p_56) , l_601) <= p_57)))))))) != 0x6E8AL);
                for (l_581 = 0; (l_581 <= 2); l_581 += 1)
                { /* block id: 283 */
                    uint16_t * const *l_611 = &g_136;
                    int i;
                    for (g_212 = 2; (g_212 >= 0); g_212 -= 1)
                    { /* block id: 286 */
                        int i;
                        return g_521[(g_212 + 2)];
                    }
                    (**l_339) = (safe_mod_func_int64_t_s_s_unsafe_macro/*184*//* ___SAFE__OP */((((g_521[l_581] , ((!((*l_375) &= ((0xC340L == (safe_add_func_uint32_t_u_u_unsafe_macro/*185*//* ___SAFE__OP */(p_57, (!((((safe_lshift_func_uint32_t_u_s_unsafe_macro/*186*//* ___SAFE__OP */((((*l_578) == (l_612 = l_611)) || (safe_add_func_uint64_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */(18446744073709551608UL, (g_297.f0 ^ (safe_sub_func_uint8_t_u_u_unsafe_macro/*188*//* ___SAFE__OP */(p_57, (safe_lshift_func_uint8_t_u_u_unsafe_macro/*189*//* ___SAFE__OP */((((((safe_mod_func_int16_t_s_s_unsafe_macro/*190*//* ___SAFE__OP */(((void*)0 != &g_429), 65535UL)) | 0L) , p_57) && 1UL) > 0xD7C9D478F680B5AELL), 0)))))))), p_56)) >= g_522) | g_189[0]) || g_34))))) & l_623))) == l_599)) , 0x7EB926B2L) , p_57), 18446744073709551612UL));
                    return (**l_339);
                }
            }
            (*l_339) = l_624;
        }
        else
        { /* block id: 296 */
            uint32_t l_640[7][5] = {{0UL,3UL,7UL,0xF62966B2L,0xF62966B2L},{0xC557D89FL,5UL,0xC557D89FL,0xA4D8FAABL,1UL},{18446744073709551609UL,18446744073709551615UL,0xF62966B2L,18446744073709551615UL,18446744073709551609UL},{0xC557D89FL,0xA246E98BL,5UL,0xC81B8B2BL,5UL},{0UL,0UL,0xF62966B2L,18446744073709551609UL,0xA65D40BDL},{0xA246E98BL,0xC557D89FL,0xC557D89FL,0xA246E98BL,5UL},{18446744073709551615UL,18446744073709551609UL,7UL,7UL,18446744073709551609UL}};
            int16_t l_675 = 0x204FL;
            int32_t l_681[2];
            uint32_t l_701 = 4294967287UL;
            int8_t * const *l_729 = &g_45;
            const int32_t *l_736 = &l_700;
            const int32_t **l_735 = &l_736;
            int i, j;
            for (i = 0; i < 2; i++)
                l_681[i] = 9L;
            (*l_624) = 0x1BF4CB5FL;
            for (p_57 = (-18); (p_57 == (-23)); p_57--)
            { /* block id: 300 */
                union U0 l_636 = {0UL};
                int32_t l_638 = (-9L);
                for (l_316 = (-28); (l_316 <= (-17)); ++l_316)
                { /* block id: 303 */
                    uint64_t l_643 = 18446744073709551609UL;
                    if ((p_56 <= ((*l_299) = ((safe_sub_func_int32_t_s_s_unsafe_macro/*191*//* ___SAFE__OP */(((safe_sub_func_int32_t_s_s_unsafe_macro/*192*//* ___SAFE__OP */(1L, (-1L))) <= ((+(((((((l_638 = (safe_sub_func_int64_t_s_s_unsafe_macro/*193*//* ___SAFE__OP */((0x9EL >= (g_521[4] <= 0xE78FD3185044645ALL)), (((*g_82) , l_636) , ((((*l_375) = (safe_unary_minus_func_int8_t_s_unsafe_macro/*194*//* ___SAFE__OP */(p_56))) > g_113) > p_57))))) > g_258[6][5][0]) & (-9L)) & g_525) | g_614[6]) >= (*g_82)) != 0xDAF639DCL)) , l_639)), 4294967293UL)) , p_57))))
                    { /* block id: 307 */
                        --l_640[4][2];
                    }
                    else
                    { /* block id: 309 */
                        return p_56;
                    }
                    l_643--;
                }
            }
            if ((*g_82))
            { /* block id: 315 */
                (*l_624) ^= 1L;
            }
            else
            { /* block id: 317 */
                int64_t l_658 = 1L;
                int32_t l_683 = 0L;
                int32_t l_686 = 2L;
                int16_t l_689 = 0xDE00L;
                int32_t l_694 = 0x42E48B42L;
                int32_t l_696[6] = {1L,0L,0L,1L,0L,0L};
                uint32_t ** const l_704[6] = {&g_416,&g_416,&g_416,&g_416,&g_416,&g_416};
                uint8_t **l_755 = &l_648;
                int i;
                if ((0x0F26312D901FD64DLL >= (&g_442 == l_646)))
                { /* block id: 318 */
                    uint64_t l_657 = 0xB3A5899808B2AC89LL;
                    int16_t *l_674 = &g_104;
                    int32_t *l_676[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_676[i] = &l_316;
                    if (((safe_mod_func_int16_t_s_s_unsafe_macro/*195*//* ___SAFE__OP */(9L, ((*l_613) ^= (safe_add_func_int16_t_s_s_unsafe_macro/*196*//* ___SAFE__OP */((((!(((*l_624) = (((safe_sub_func_uint64_t_u_u_unsafe_macro/*197*//* ___SAFE__OP */(18446744073709551612UL, l_657)) != ((g_480 & (l_658 || l_657)) && ((*l_674) = ((safe_mod_func_uint8_t_u_u_unsafe_macro/*198*//* ___SAFE__OP */(p_57, (((safe_add_func_uint8_t_u_u_unsafe_macro/*199*//* ___SAFE__OP */(l_663, ((**l_647)++))) , (((safe_sub_func_int8_t_s_s_unsafe_macro/*200*//* ___SAFE__OP */(((((((safe_div_func_uint64_t_u_u_unsafe_macro/*201*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*202*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(0xDF847F5803C5DA9FLL, 18446744073709551615UL)), p_57)), g_521[4])) , g_32) , l_658) | g_258[5][1][2]) | 1L) , (*g_429)), 0xB9L)) | (*g_82)) , 0x7F3CL)) && g_189[0]))) != (**l_339))))) , (*g_82))) > l_640[0][4])) || 1UL) || 0x35C77ACF0830DE5DLL), l_675))))) >= p_56))
                    { /* block id: 323 */
                        l_676[3] = &g_111;
                        return g_189[0];
                    }
                    else
                    { /* block id: 326 */
                        return g_189[0];
                    }
                }
                else
                { /* block id: 329 */
                    int16_t l_680 = (-5L);
                    int32_t l_684 = 0xCDF4D3C1L;
                    int32_t l_690 = 0x8C225DE8L;
                    int32_t l_691 = (-1L);
                    int32_t l_692 = 0x37CF793FL;
                    int32_t l_693 = 0x3122AB75L;
                    int32_t l_695 = 0x0062A4D2L;
                    int32_t l_697 = 0x82F7B318L;
                    int32_t l_698 = 0xA315E670L;
                    int32_t l_699 = 0L;
                    uint8_t **l_713 = &l_648;
                    int16_t *l_716 = &g_104;
                    uint16_t *** const * const l_754 = &g_376;
                    if ((&g_521[4] == (g_212 , (void*)0)))
                    { /* block id: 330 */
                        int64_t l_682 = 1L;
                        int32_t l_685[7][4] = {{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L},{0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L,0x3FBAA5E8L}};
                        int i, j;
                        --l_701;
                    }
                    else
                    { /* block id: 332 */
                        uint32_t * const *l_706 = &l_375;
                        uint32_t * const **l_705 = &l_706;
                        (*l_339) = &l_692;
                        (*l_624) = ((((-8L) <= g_522) , l_704[1]) != ((*l_705) = (*l_557)));
                    }
                    if ((safe_mul_func_uint64_t_u_u_unsafe_macro/*204*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*205*//* ___SAFE__OP */(l_658, 0x61A5L)), (0x8FL && ((((safe_sub_func_uint8_t_u_u_unsafe_macro/*206*//* ___SAFE__OP */(p_57, (((*l_646) = l_713) == (*g_441)))) && (l_683 , ((*l_716) = (safe_div_func_uint8_t_u_u_unsafe_macro/*207*//* ___SAFE__OP */(p_56, (l_681[1] = ((**l_713) ^= ((**g_428) | g_480)))))))) , 1UL) > 0x6AL)))))
                    { /* block id: 341 */
                        uint32_t l_717 = 0UL;
                        --l_717;
                        (*l_339) = (void*)0;
                    }
                    else
                    { /* block id: 344 */
                        uint16_t l_724 = 0x49F5L;
                        uint64_t *l_725 = &g_297.f1;
                        uint64_t *l_726 = (void*)0;
                        int8_t * const **l_730 = &l_729;
                        int32_t l_749 = 0xA7A2216AL;
                        l_691 = (safe_sub_func_uint64_t_u_u_unsafe_macro/*208*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */(((g_189[3] |= (g_525 |= l_724)) ^ ((l_695 = (((((safe_sub_func_int32_t_s_s_unsafe_macro/*210*//* ___SAFE__OP */((-1L), (*g_82))) < 0UL) < (((*l_730) = l_729) == &g_429)) , p_56) == (((p_57 , (g_520 < p_56)) >= 0UL) < 0UL))) , g_61[1][1])), 35)), p_56));
                        (*l_339) = (*l_339);
                        (**l_339) = (safe_mul_func_int16_t_s_s_unsafe_macro/*211*//* ___SAFE__OP */(0L, (1L >= (safe_add_func_int64_t_s_s_unsafe_macro/*212*//* ___SAFE__OP */(l_724, (((void*)0 != l_735) , (l_696[1] < ((l_749 &= (((g_737[3] != ((safe_add_func_uint8_t_u_u_unsafe_macro/*213*//* ___SAFE__OP */(((((safe_add_func_uint8_t_u_u_unsafe_macro/*214*//* ___SAFE__OP */(((safe_lshift_func_int8_t_s_u_unsafe_macro/*215*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*216*//* ___SAFE__OP */(g_212, (safe_rshift_func_int8_t_s_u_unsafe_macro/*217*//* ___SAFE__OP */(((void*)0 != &g_82), 1)))), p_57)) & l_683), l_724)) ^ (-10L)) < (**g_428)) , p_57), 248UL)) , l_748)) == g_32.f0) || 0x57B2L)) == 1L))))))));
                        l_694 ^= (safe_mod_func_int32_t_s_s_unsafe_macro/*218*//* ___SAFE__OP */((((safe_rshift_func_int64_t_s_u_unsafe_macro/*219*//* ___SAFE__OP */((*l_736), (p_57 >= ((((l_754 == (void*)0) < p_56) , (l_755 == l_755)) > (((l_724 && ((**l_735) < 0x2B2B6160E2454DDDLL)) | 65528UL) == g_36))))) <= (-3L)) ^ p_56), l_696[3]));
                    }
                    return l_756;
                }
            }
            (**l_339) ^= p_57;
        }
        if (g_407)
            goto lbl_757;
        for (l_623 = 0; (l_623 != 18); l_623 = safe_add_func_int8_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */(l_623, 9))
        { /* block id: 363 */
            int16_t l_762 = 0x0B2FL;
            int32_t l_766 = 3L;
            int32_t l_767 = 8L;
            int32_t l_768 = 0L;
            uint64_t l_769 = 0xBB73B891639FA7EBLL;
            int64_t *l_789 = &g_521[3];
            int32_t l_792 = (-7L);
            int32_t l_799 = 3L;
            int32_t l_800 = 0x1F991CD4L;
            int32_t l_803 = 0L;
            int32_t l_804 = 0xA2C0EF01L;
            int32_t l_805 = 0xACFEF654L;
            int32_t l_807 = 0L;
            int32_t l_809 = 0x5AB89483L;
            int32_t l_810[5][1][9] = {{{0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL}},{{2L,2L,2L,2L,2L,2L,2L,2L,2L}},{{0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL}},{{2L,2L,2L,2L,2L,2L,2L,2L,2L}},{{0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL,0x9F17F60AL}}};
            int8_t l_812 = 0xC1L;
            union U0 *l_836 = &g_32;
            int i, j, k;
            for (l_756 = 28; (l_756 != 54); ++l_756)
            { /* block id: 366 */
                int32_t l_763[4][10][6] = {{{0x57E3AB2AL,0x97EC9F4CL,0xDDA2D072L,2L,0x98D6255BL,0xDDA2D072L},{0x01EDCE5DL,0x90BD28C9L,6L,0x8317F8EBL,(-2L),0x49D494F4L},{0x55BA35AAL,0x98D6255BL,0L,1L,0L,6L},{0xD27BA36CL,0x3EFDEC61L,0L,0x49D494F4L,0x90BD28C9L,0x49D494F4L},{6L,1L,6L,0x4FAF8020L,3L,0xDDA2D072L},{0x4FAF8020L,3L,0xDDA2D072L,0xB57566FCL,1L,(-3L)},{0x8317F8EBL,0x6FAED831L,0xAD967815L,0xB57566FCL,(-1L),0x4FAF8020L},{0x4FAF8020L,0L,0x2F449240L,0x4FAF8020L,0x3EFDEC61L,2L},{6L,0x6BAD2649L,(-3L),0x49D494F4L,0x76D994CAL,0L},{0xD27BA36CL,0L,0x01EDCE5DL,1L,0x76D994CAL,1L}},{{0x55BA35AAL,0x6BAD2649L,0x4FAF8020L,0x8317F8EBL,0x3EFDEC61L,1L},{0x01EDCE5DL,0L,0x57E3AB2AL,2L,(-1L),0xD27BA36CL},{0x57E3AB2AL,0x6FAED831L,0x55BA35AAL,0x2F449240L,1L,0xD27BA36CL},{1L,3L,0x57E3AB2AL,0x57E3AB2AL,3L,1L},{1L,1L,0x4FAF8020L,0xAD967815L,0x90BD28C9L,1L},{0x49D494F4L,0x3EFDEC61L,0x01EDCE5DL,(-3L),0L,0L},{0x49D494F4L,0x98D6255BL,(-3L),0xAD967815L,(-2L),2L},{1L,0x90BD28C9L,0x2F449240L,0x57E3AB2AL,0x98D6255BL,0x4FAF8020L},{1L,0x97EC9F4CL,0xAD967815L,0x2F449240L,0xB317847AL,(-3L)},{0x57E3AB2AL,0x97EC9F4CL,0xDDA2D072L,2L,0x98D6255BL,0xDDA2D072L}},{{0x01EDCE5DL,0x90BD28C9L,6L,0x8317F8EBL,(-2L),0x49D494F4L},{0x55BA35AAL,0x98D6255BL,0L,1L,0L,6L},{0xD27BA36CL,0x3EFDEC61L,0L,0x49D494F4L,0x90BD28C9L,0x49D494F4L},{6L,1L,6L,0x4FAF8020L,3L,0xDDA2D072L},{0x4FAF8020L,3L,0xDDA2D072L,0xB57566FCL,1L,(-3L)},{0x8317F8EBL,0x6FAED831L,0xAD967815L,0xB57566FCL,(-1L),0x4FAF8020L},{0x4FAF8020L,0L,0x2F449240L,0x4FAF8020L,0x3EFDEC61L,2L},{6L,0x6BAD2649L,(-3L),0L,0x57E3AB2AL,0xF85FED94L},{0xE85E7BF9L,0L,(-2L),0L,0x57E3AB2AL,1L},{1L,0x2F449240L,(-1L),(-4L),0x8317F8EBL,0L}},{{(-2L),0x01EDCE5DL,0x23FC4AD7L,0x3F3EA73BL,6L,0xE85E7BF9L},{0x23FC4AD7L,1L,1L,(-1L),2L,0xE85E7BF9L},{0L,0xB57566FCL,0x23FC4AD7L,0x23FC4AD7L,0xB57566FCL,0L},{0x330F6954L,0xDDA2D072L,(-1L),0xBECF6A51L,0xD27BA36CL,1L},{0L,0x8317F8EBL,(-2L),0xE30651D0L,0L,0xF85FED94L},{0L,(-3L),0xE30651D0L,0xBECF6A51L,0x55BA35AAL,0x3F3EA73BL},{0x330F6954L,0xD27BA36CL,(-1L),0x23FC4AD7L,(-3L),(-1L)},{0L,1L,0xBECF6A51L,(-1L),(-1L),0xE30651D0L},{0x23FC4AD7L,1L,0x61C01CE1L,0x3F3EA73BL,(-3L),0x61C01CE1L},{(-2L),0xD27BA36CL,(-7L),(-4L),0x55BA35AAL,0L}}};
                int32_t l_764 = 0xE6DE794EL;
                int32_t l_765 = 0x94581043L;
                uint64_t *l_790 = &g_189[1];
                int64_t *l_791[5] = {&l_574[4],&l_574[4],&l_574[4],&l_574[4],&l_574[4]};
                int i, j, k;
                --l_769;
                l_765 ^= (safe_sub_func_uint64_t_u_u_unsafe_macro/*221*//* ___SAFE__OP */((0xBFC4B0FCL > (l_768 = (safe_mul_func_uint8_t_u_u_unsafe_macro/*222*//* ___SAFE__OP */((!(l_792 ^= ((*l_300) = ((l_764 , ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*223*//* ___SAFE__OP */(((*l_790) = (((((((l_766 = (9L <= ((safe_sub_func_uint32_t_u_u_unsafe_macro/*224*//* ___SAFE__OP */(((safe_lshift_func_int32_t_s_s_unsafe_macro/*225*//* ___SAFE__OP */(((**l_339) = 0x1272203BL), 26)) && ((((**g_377) &= l_763[3][6][0]) | (~0x49392956B03BFC3ALL)) <= g_677)), (((*l_375) = g_784) >= (((safe_rshift_func_uint8_t_u_u_unsafe_macro/*226*//* ___SAFE__OP */(((safe_sub_func_int8_t_s_s_unsafe_macro/*227*//* ___SAFE__OP */((p_56 ^ 0xF7D3888139B56FEFLL), 0xB9L)) > p_56), 6)) != l_764) && p_57)))) >= l_767))) , (*l_748)) == l_789) == 9UL) || (**g_428)) & l_768) | p_57)), g_521[3])) || p_56)) <= 0x392D0285222EF674LL)))), 1UL)))), (-1L)));
            }
            (*l_624) = (safe_div_func_uint16_t_u_u_unsafe_macro/*228*//* ___SAFE__OP */((p_56 = (**g_377)), (safe_mod_func_int64_t_s_s_unsafe_macro/*229*//* ___SAFE__OP */(p_57, (safe_lshift_func_int16_t_s_s_unsafe_macro/*230*//* ___SAFE__OP */(l_792, 8))))));
            ++g_814;
            for (l_801 = (-1); (l_801 > 22); ++l_801)
            { /* block id: 383 */
                uint64_t *l_821 = &g_189[0];
                union U0 **l_830[2];
                int32_t l_843 = 0x178C08E8L;
                int32_t l_844 = 0x5AE17CACL;
                int i;
                for (i = 0; i < 2; i++)
                    l_830[i] = (void*)0;
                if ((l_844 |= ((*g_82) = (safe_div_func_uint8_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */(((0x6F564DADL == (p_56 <= (--(*l_821)))) >= (((safe_rshift_func_int16_t_s_u_unsafe_macro/*232*//* ___SAFE__OP */(((g_737[3] != &l_789) == (~((((*l_789) = ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*233*//* ___SAFE__OP */((((**l_748) = (((g_831 = l_829) != l_833[4][2][1]) & (safe_sub_func_int16_t_s_s_unsafe_macro/*234*//* ___SAFE__OP */(((((((l_836 != &g_832) != (((((safe_sub_func_uint16_t_u_u_unsafe_macro/*235*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*236*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*237*//* ___SAFE__OP */(0L, 18446744073709551615UL)), 0x36L)), (**g_377))) , (*g_350)) <= l_843) , g_212) != (**l_339))) , l_843) != 0L) <= (*g_82)) < p_57), (***g_376))))) < 4L), 0)) > 0UL)) > 0x475DE2C97F813995LL) >= 0x409035E7L))), 8)) != (-9L)) <= (*g_82))), l_843)))))
                { /* block id: 390 */
                    int8_t *l_850[7] = {&l_808,(void*)0,(void*)0,&l_808,(void*)0,(void*)0,&l_808};
                    int32_t l_853 = 1L;
                    int i;
                    (*g_82) ^= (((safe_add_func_uint8_t_u_u_unsafe_macro/*238*//* ___SAFE__OP */(p_57, p_57)) || ((~g_258[0][7][2]) < p_57)) >= (safe_rshift_func_int8_t_s_s_unsafe_macro/*239*//* ___SAFE__OP */((((p_56 , (*g_428)) != l_850[1]) || (1L | ((p_56 < p_57) & g_92))), 6)));
                    if (p_57)
                        break;
                    for (l_807 = 0; (l_807 != 18); l_807 = safe_add_func_int16_t_s_s_unsafe_macro/*240*//* ___SAFE__OP */(l_807, 6))
                    { /* block id: 395 */
                        uint32_t l_854 = 4294967295UL;
                        if ((*g_82))
                            break;
                        --l_854;
                    }
                    for (l_767 = 0; (l_767 >= (-17)); l_767 = safe_sub_func_uint64_t_u_u_unsafe_macro/*241*//* ___SAFE__OP */(l_767, 2))
                    { /* block id: 401 */
                        uint8_t l_862 = 0xE0L;
                        (*g_82) = (p_57 == (safe_div_func_uint32_t_u_u_unsafe_macro/*242*//* ___SAFE__OP */((((((*l_836) , ((g_391[5] > ((~2L) & l_862)) , (((p_56 , ((g_649 != p_56) < (safe_mul_func_uint8_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */(((safe_mod_func_uint8_t_u_u_unsafe_macro/*244*//* ___SAFE__OP */(l_844, l_809)) <= p_57), 0x1DL)))) != p_57) , l_862))) < (**g_428)) == 0x7350L) , p_56), (-3L))));
                        return p_56;
                    }
                }
                else
                { /* block id: 405 */
                    return p_57;
                }
            }
        }
    }
    return p_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_34 g_92 g_32.f0 g_104 g_113 g_111 g_36 g_61 g_126 g_139 g_189 g_32 g_258
 * writes: g_34 g_92 g_104 g_111 g_113 g_136 g_139 g_126 g_189 g_212 g_258 g_61
 */
static uint8_t  func_64(uint64_t  p_65, union U0  p_66, uint8_t  p_67, const int64_t  p_68, uint8_t  p_69)
{ /* block id: 21 */
    uint16_t l_97 = 1UL;
    int32_t l_137 = 0x8986B1ECL;
    int32_t l_168 = 0L;
    uint32_t *l_268 = &g_139[3][2][0];
    int32_t l_293 = 1L;
    if (((*g_82) = (*g_82)))
    { /* block id: 23 */
        int32_t l_100 = 0xFBDD559FL;
        const int8_t *l_125 = &g_126;
        uint16_t *l_135 = &l_97;
        uint64_t l_138[2][7];
        int32_t l_174 = 0x3257E1E0L;
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 7; j++)
                l_138[i][j] = 18446744073709551609UL;
        }
        for (g_34 = 2; (g_34 >= 0); g_34 -= 1)
        { /* block id: 26 */
            uint32_t *l_91 = &g_92;
            int16_t *l_103 = &g_104;
            int32_t l_107[2];
            int32_t *l_110 = &g_111;
            int32_t *l_112 = &g_113;
            int i;
            for (i = 0; i < 2; i++)
                l_107[i] = 0x8E356D6BL;
            (*l_112) ^= ((safe_rshift_func_uint64_t_u_s_unsafe_macro/*245*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */(((*l_91)--), ((((safe_mod_func_int32_t_s_s_unsafe_macro/*247*//* ___SAFE__OP */(((p_67 = 255UL) & 4UL), l_97)) , 8L) | (p_69 > (safe_rshift_func_uint8_t_u_s_unsafe_macro/*248*//* ___SAFE__OP */(l_100, 4)))) && (safe_add_func_uint8_t_u_u_unsafe_macro/*249*//* ___SAFE__OP */((((*l_103) &= g_32.f0) == (safe_add_func_int32_t_s_s_unsafe_macro/*250*//* ___SAFE__OP */(l_107[1], ((*l_110) = (safe_div_func_int64_t_s_s_unsafe_macro/*251*//* ___SAFE__OP */(((*g_82) >= l_107[1]), 18446744073709551611UL)))))), l_100))))), 14)) , (*g_82));
            (*l_112) |= p_69;
            (*l_110) = (((safe_rshift_func_int32_t_s_u(0x9BC9383AL, (0xF6L >= ((safe_rshift_func_uint16_t_u_s_unsafe_macro/*253*//* ___SAFE__OP */((((safe_add_func_int32_t_s_s_unsafe_macro/*254*//* ___SAFE__OP */(((l_97 , 9L) >= ((safe_mul_func_uint8_t_u_u_unsafe_macro/*255*//* ___SAFE__OP */((~(((*l_112) = (g_34 == (-1L))) ^ (((safe_rshift_func_uint64_t_u_s((((*l_110) , l_125) == (void*)0), 52)) , p_68) ^ 0x92L))), (-1L))) && p_69)), p_65)) == 1UL) , 0x67ADL), g_111)) < 0UL)))) | 1L) > 0x58AA494CAA1C64ACLL);
            if ((*g_82))
                continue;
            for (p_67 = 0; (p_67 <= 2); p_67 += 1)
            { /* block id: 38 */
                g_113 = ((g_36 , (g_139[4][7][0] = (((safe_mod_func_int8_t_s_s_unsafe_macro/*257*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_s_unsafe_macro/*258*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*259*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*260*//* ___SAFE__OP */(((*l_110) = (p_66.f0 , l_97)), (((g_136 = l_135) != (void*)0) | ((*l_103) = l_137)))), 10)), ((g_61[1][1] > l_100) ^ 0L))), p_68)) == g_61[1][1]) == l_138[0][0]))) != (-1L));
                for (g_126 = 0; (g_126 <= 2); g_126 += 1)
                { /* block id: 46 */
                    (*l_112) = ((*l_110) = (*g_82));
                }
            }
        }
        for (l_100 = (-30); (l_100 < (-13)); l_100 = safe_add_func_int32_t_s_s_unsafe_macro/*261*//* ___SAFE__OP */(l_100, 9))
        { /* block id: 54 */
            uint32_t *l_171 = &g_92;
            int32_t l_175 = 0x1CB1BBB9L;
            uint16_t l_176 = 0x0DA0L;
            int8_t *l_246 = (void*)0;
            uint64_t *l_255 = &g_189[2];
            union U0 l_256 = {0x510E3700449F6A1BLL};
            uint64_t l_257 = 18446744073709551606UL;
            int32_t *l_259[6][9] = {{&l_175,(void*)0,(void*)0,&l_175,&g_111,(void*)0,(void*)0,&g_111,&l_175},{&g_113,&l_175,&g_113,&g_34,(void*)0,&g_34,&g_113,&l_175,&g_113},{&l_175,&g_111,(void*)0,(void*)0,&g_111,&l_175,(void*)0,(void*)0,&l_175},{&g_111,&l_175,&g_111,&g_34,&l_175,&g_34,&g_111,&l_175,&g_111},{&l_175,(void*)0,(void*)0,&l_175,&g_111,(void*)0,(void*)0,&g_111,&l_175},{&g_113,&l_175,&g_113,&g_34,(void*)0,&g_34,&g_113,&l_175,&g_113}};
            int i, j;
            if (((safe_add_func_int32_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u((((safe_mul_func_int64_t_s_s_unsafe_macro/*264*//* ___SAFE__OP */(((safe_unary_minus_func_uint64_t_u_unsafe_macro/*265*//* ___SAFE__OP */(((g_34 >= (safe_sub_func_int64_t_s_s_unsafe_macro/*266*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s_unsafe_macro/*267*//* ___SAFE__OP */((((((p_65 ^ (safe_add_func_uint64_t_u_u_unsafe_macro/*268*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*269*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*270*//* ___SAFE__OP */((*g_82), ((safe_div_func_uint16_t_u_u_unsafe_macro/*271*//* ___SAFE__OP */((((safe_mul_func_int64_t_s_s_unsafe_macro/*272*//* ___SAFE__OP */(p_68, (safe_lshift_func_uint16_t_u_s_unsafe_macro/*273*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s_unsafe_macro/*274*//* ___SAFE__OP */((l_168 = 0xE9L))), 8)))) ^ (((p_66 , (((safe_div_func_uint32_t_u_u_unsafe_macro/*275*//* ___SAFE__OP */(4294967295UL, l_100)) < ((((*l_171)++) , (((1UL > g_104) & (-4L)) ^ 8UL)) <= g_104)) , p_69)) , &g_43) == (void*)0)) && p_66.f0), l_97)) | g_139[4][7][0]))), 0x9CC89D979A8B53E2LL)) && 0L), l_174))) != l_137) & g_139[4][7][0]) , g_61[2][2]) , p_65), p_67)) , p_68) >= p_67), 0x2E8761BCA9B0E0A5LL))) , g_126))) != g_111), l_175)) != p_69) ^ g_104), 11)), l_176)) , l_176))
            { /* block id: 57 */
                (*g_82) = 0x190672B4L;
                for (l_97 = (-6); (l_97 >= 27); l_97 = safe_add_func_int16_t_s_s_unsafe_macro/*276*//* ___SAFE__OP */(l_97, 5))
                { /* block id: 61 */
                    int32_t *l_179 = &g_113;
                    int32_t *l_180 = &l_175;
                    int32_t *l_181 = (void*)0;
                    int32_t l_182 = 0x113F68E7L;
                    int32_t *l_183 = &g_113;
                    int32_t *l_184 = (void*)0;
                    int32_t *l_185 = &l_175;
                    int32_t *l_186 = &g_113;
                    int32_t l_187 = 0xABE801A4L;
                    int32_t *l_188[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_188[i] = &l_175;
                    --g_189[0];
                    (*g_82) = p_66.f0;
                }
            }
            else
            { /* block id: 65 */
                const int32_t *l_192 = &l_168;
                const int32_t **l_193 = &l_192;
                int8_t *l_198 = &g_126;
                int64_t *l_211 = &g_212;
                int32_t l_213 = 0L;
                int16_t *l_223 = (void*)0;
                int16_t *l_224 = &g_104;
                (*l_193) = l_192;
                l_213 |= (safe_mul_func_uint64_t_u_u_unsafe_macro/*277*//* ___SAFE__OP */(18446744073709551615UL, (safe_div_func_uint16_t_u_u_unsafe_macro/*278*//* ___SAFE__OP */((((0x0BL != ((*l_198) &= p_68)) , ((((safe_lshift_func_int8_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */(((*l_198) &= p_65), 5)) , ((*l_198) = (safe_mod_func_int64_t_s_s_unsafe_macro/*280*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*281*//* ___SAFE__OP */((((g_32 , (((l_175 == (((safe_add_func_int32_t_s_s_unsafe_macro/*282*//* ___SAFE__OP */((g_139[4][3][0] && ((*l_211) = (safe_rshift_func_uint16_t_u_s_unsafe_macro/*283*//* ___SAFE__OP */(((*l_192) & (safe_mul_func_int16_t_s_s_unsafe_macro/*284*//* ___SAFE__OP */(((((((l_138[0][0] <= p_65) & 0x9CDCE665L) , 7UL) != (-6L)) == 0x0FB3CCEBL) <= (**l_193)), 0UL))), g_139[7][1][1])))), l_97)) & p_66.f0) , g_36)) <= p_69) >= 0UL)) ^ p_66.f0) >= l_176), l_100)), 0x00B84BF07F47E08CLL)))) || (*l_192)) != p_69)) < 0x12L), g_189[1]))));
                l_175 = (safe_div_func_int8_t_s_s_unsafe_macro/*285*//* ___SAFE__OP */(((((safe_mul_func_uint16_t_u_u_unsafe_macro/*286*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u_unsafe_macro/*287*//* ___SAFE__OP */((((0x2A21L || ((((((safe_mul_func_int16_t_s_s_unsafe_macro/*288*//* ___SAFE__OP */((safe_unary_minus_func_uint16_t_u_unsafe_macro/*289*//* ___SAFE__OP */(p_68)), ((&g_212 != &g_212) != ((*g_82) = ((((*l_224) = 0x7DCBL) , ((~(*g_82)) <= (p_68 < (safe_mod_func_int16_t_s_s_unsafe_macro/*290*//* ___SAFE__OP */((l_168 = (p_69 < (safe_mul_func_int8_t_s_s_unsafe_macro/*291*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*292*//* ___SAFE__OP */(((l_176 , g_113) , 0x497654C1894117C0LL), p_65)) < (**l_193)), l_138[1][3])))), g_139[4][2][0]))))) >= 0x5E78L))))) != p_67) && p_69) <= g_61[1][1]) && p_69) != p_67)) == l_138[0][2]) | l_137), g_92)), 0x5CBEL)) == 0x55L) < g_111) ^ g_111), l_174));
                (*l_193) = &g_34;
            }
            g_111 &= (+(safe_mul_func_int64_t_s_s_unsafe_macro/*293*//* ___SAFE__OP */(l_176, ((*g_82) <= (safe_mod_func_uint32_t_u_u_unsafe_macro/*294*//* ___SAFE__OP */(((*l_171) ^= ((safe_rshift_func_int16_t_s_u((safe_sub_func_uint64_t_u_u_unsafe_macro/*296*//* ___SAFE__OP */((g_258[2][0][1] |= (((!(l_168 , (safe_rshift_func_uint64_t_u_s_unsafe_macro/*297*//* ___SAFE__OP */(((((safe_add_func_int16_t_s_s_unsafe_macro/*298*//* ___SAFE__OP */((((g_126 ^= 0xE7L) > (((safe_rshift_func_int16_t_s_u_unsafe_macro/*299*//* ___SAFE__OP */(((l_100 != ((safe_mul_func_int32_t_s_s_unsafe_macro/*300*//* ___SAFE__OP */(p_67, (safe_sub_func_int64_t_s_s_unsafe_macro/*301*//* ___SAFE__OP */((l_176 ^ 0x2E74A5ACE6E74F6ALL), ((*l_255) = g_32.f0))))) > g_34)) <= g_104), 10)) , l_256) , l_257)) , g_113), 0x0385L)) , l_175) | l_137) >= p_69), 9)))) != l_175) < l_137)), l_137)), 8)) , g_113)), (*g_82)))))));
            for (l_257 = 22; (l_257 < 5); l_257 = safe_sub_func_uint8_t_u_u_unsafe_macro/*302*//* ___SAFE__OP */(l_257, 6))
            { /* block id: 85 */
                uint64_t l_262 = 1UL;
                (*g_82) ^= p_67;
                l_262--;
            }
        }
        return l_97;
    }
    else
    { /* block id: 91 */
        uint32_t l_265[7];
        int8_t **l_281 = &g_43;
        uint16_t *l_287 = (void*)0;
        uint16_t *l_288 = &g_61[1][1];
        int8_t *l_289 = &g_126;
        int32_t l_290 = 0x6A960B59L;
        int32_t l_291 = (-5L);
        int32_t *l_292[2][5][5] = {{{&g_113,&l_168,&l_168,&g_113,&l_168},{&g_113,&l_168,&l_168,&g_113,&g_113},{&g_111,&g_113,(void*)0,&l_168,&l_168},{&g_113,&g_113,&g_113,&g_113,&g_113},{&l_168,&l_168,&g_113,&l_168,&g_113}},{{&l_168,&l_168,(void*)0,&g_113,&g_111},{&g_113,&g_111,&g_113,&g_113,&g_111},{&g_111,&l_168,&g_113,&g_111,&g_113},{&g_113,&g_111,(void*)0,&g_111,&g_113},{&g_113,&l_168,&l_168,&g_113,&l_168}}};
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_265[i] = 4294967295UL;
        l_265[4]--;
        l_293 |= (l_291 = ((l_268 != (void*)0) ^ (l_290 |= ((((((safe_sub_func_uint32_t_u_u_unsafe_macro/*303*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*304*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*305*//* ___SAFE__OP */(((safe_sub_func_uint32_t_u_u_unsafe_macro/*306*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s_unsafe_macro/*307*//* ___SAFE__OP */(0x439EL, (&g_34 == (((*l_289) = ((safe_div_func_int64_t_s_s_unsafe_macro/*308*//* ___SAFE__OP */(((l_281 = &g_43) != (((1UL | 0xAA2DL) >= ((*l_288) = (((safe_lshift_func_int8_t_s_u_unsafe_macro/*309*//* ___SAFE__OP */((!l_168), 5)) || ((safe_rshift_func_int32_t_s_u_unsafe_macro/*310*//* ___SAFE__OP */(((*g_82) = (*g_82)), l_265[3])) ^ l_265[1])) > g_36))) , &g_2)), g_258[2][0][1])) != p_66.f0)) , (void*)0)))) != g_189[2]), l_137)) ^ 5L), 0x575D05C0FEA6540CLL)), 1)), l_168)) | l_168) <= 0xDCC0L) && p_69) & l_265[4]) , l_137))));
    }
    return l_168;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_82
 */
static int8_t ** func_72(int32_t * p_73, uint16_t * p_74, uint32_t  p_75, uint32_t  p_76, int32_t  p_77)
{ /* block id: 16 */
    int32_t *l_81 = &g_34;
    int32_t **l_80[5][10][5] = {{{(void*)0,&l_81,(void*)0,&l_81,(void*)0},{&l_81,&l_81,&l_81,(void*)0,&l_81},{&l_81,(void*)0,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,(void*)0,&l_81,&l_81,(void*)0},{&l_81,&l_81,(void*)0,&l_81,(void*)0},{&l_81,&l_81,(void*)0,(void*)0,&l_81},{&l_81,(void*)0,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81}},{{&l_81,&l_81,&l_81,&l_81,(void*)0},{&l_81,(void*)0,&l_81,&l_81,(void*)0},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{(void*)0,&l_81,(void*)0,&l_81,&l_81},{&l_81,&l_81,(void*)0,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,(void*)0},{(void*)0,&l_81,&l_81,(void*)0,&l_81}},{{&l_81,&l_81,(void*)0,&l_81,&l_81},{(void*)0,&l_81,&l_81,&l_81,(void*)0},{&l_81,&l_81,(void*)0,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{(void*)0,&l_81,&l_81,(void*)0,&l_81},{(void*)0,&l_81,&l_81,(void*)0,(void*)0},{&l_81,&l_81,&l_81,&l_81,(void*)0},{(void*)0,&l_81,&l_81,&l_81,&l_81},{(void*)0,&l_81,(void*)0,&l_81,(void*)0},{(void*)0,(void*)0,&l_81,&l_81,&l_81}},{{&l_81,&l_81,(void*)0,&l_81,(void*)0},{(void*)0,&l_81,&l_81,(void*)0,&l_81},{(void*)0,&l_81,&l_81,&l_81,(void*)0},{(void*)0,(void*)0,&l_81,&l_81,(void*)0},{&l_81,&l_81,(void*)0,(void*)0,&l_81},{(void*)0,&l_81,&l_81,&l_81,&l_81},{(void*)0,(void*)0,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,&l_81,&l_81}},{{(void*)0,&l_81,(void*)0,&l_81,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81},{&l_81,&l_81,(void*)0,&l_81,(void*)0},{(void*)0,&l_81,&l_81,(void*)0,(void*)0},{&l_81,(void*)0,&l_81,&l_81,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81},{(void*)0,&l_81,&l_81,(void*)0,&l_81},{&l_81,&l_81,&l_81,(void*)0,&l_81},{&l_81,(void*)0,&l_81,&l_81,&l_81}}};
    int8_t **l_83 = (void*)0;
    int i, j, k;
    g_82 = &g_34;
    p_73 = p_73;
    return l_83;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_61[i][j], "g_61[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_139[i][j][k], "g_139[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_189[i], "g_189[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_212, "g_212", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_258[i][j][k], "g_258[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_297.f0, "g_297.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_391[i], "g_391[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_407, "g_407", print_hash_value);
    transparent_crc(g_430, "g_430", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_444[i], "g_444[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_480, "g_480", print_hash_value);
    transparent_crc(g_520, "g_520", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_521[i], "g_521[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_522, "g_522", print_hash_value);
    transparent_crc(g_523, "g_523", print_hash_value);
    transparent_crc(g_525, "g_525", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_614[i], "g_614[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_649, "g_649", print_hash_value);
    transparent_crc(g_677, "g_677", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_678[i], "g_678[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_784, "g_784", print_hash_value);
    transparent_crc(g_814, "g_814", print_hash_value);
    transparent_crc(g_832.f0, "g_832.f0", print_hash_value);
    transparent_crc(g_900, "g_900", print_hash_value);
    transparent_crc(g_936, "g_936", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1045[i], "g_1045[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1221, "g_1221", print_hash_value);
    transparent_crc(g_1390, "g_1390", print_hash_value);
    transparent_crc(g_1427, "g_1427", print_hash_value);
    transparent_crc(g_1478, "g_1478", print_hash_value);
    transparent_crc(g_1500, "g_1500", print_hash_value);
    transparent_crc(g_1527, "g_1527", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 391
XXX total union variables: 9

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 55
breakdown:
   depth: 1, occurrence: 247
   depth: 2, occurrence: 58
   depth: 3, occurrence: 5
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 3
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 2
   depth: 18, occurrence: 3
   depth: 19, occurrence: 3
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 22, occurrence: 3
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 3
   depth: 29, occurrence: 5
   depth: 30, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 42, occurrence: 1
   depth: 48, occurrence: 1
   depth: 55, occurrence: 1

XXX total number of pointers: 398

XXX times a variable address is taken: 841
XXX times a pointer is dereferenced on RHS: 175
breakdown:
   depth: 1, occurrence: 134
   depth: 2, occurrence: 37
   depth: 3, occurrence: 4
XXX times a pointer is dereferenced on LHS: 233
breakdown:
   depth: 1, occurrence: 214
   depth: 2, occurrence: 17
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 22
XXX times a pointer is compared with address of another variable: 7
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 5955

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 664
   level: 2, occurrence: 143
   level: 3, occurrence: 41
   level: 4, occurrence: 12
   level: 5, occurrence: 4
XXX number of pointers point to pointers: 170
XXX number of pointers point to scalars: 222
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.4
XXX average alias set size: 1.37

XXX times a non-volatile is read: 1215
XXX times a non-volatile is write: 674
XXX times a volatile is read: 27
XXX    times read thru a pointer: 16
XXX times a volatile is write: 10
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 713
XXX percentage of non-volatile access: 98.1

XXX forward jumps: 3
XXX backward jumps: 2

XXX stmts: 244
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 30
   depth: 2, occurrence: 39
   depth: 3, occurrence: 41
   depth: 4, occurrence: 51
   depth: 5, occurrence: 53

XXX percentage a fresh-made variable is used: 15.8
XXX percentage an existing variable is used: 84.2
********************* end of statistics **********************/

