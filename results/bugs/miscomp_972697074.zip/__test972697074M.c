/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 972697074 --bitfields --packed-struct
 * Seed:      972697074
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   signed f0 : 7;
   signed : 0;
   const volatile signed f1 : 2;
   const volatile unsigned f2 : 6;
};

union U1 {
   uint32_t  f0;
   int8_t * f1;
   const int32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_32 = 0x4AL;
static int8_t *g_31 = &g_32;
static int32_t g_46 = (-1L);
static volatile int32_t g_49 = 1L;/* VOLATILE GLOBAL g_49 */
static volatile int32_t g_50[2][8][4] = {{{0xFC24489BL,0x784B52DDL,(-1L),9L},{9L,0x784B52DDL,9L,(-2L)},{0x784B52DDL,0x7F13BCF5L,(-10L),0xABA9A984L},{0xABA9A984L,9L,0xFC24489BL,0x7F13BCF5L},{(-10L),0xFC24489BL,0xFC24489BL,(-10L)},{0xABA9A984L,(-2L),(-10L),9L},{0x784B52DDL,(-5L),9L,0xF2E07230L},{9L,0xF2E07230L,(-1L),0xF2E07230L}},{{0xFC24489BL,(-5L),9L,9L},{0L,(-2L),0xF2E07230L,(-10L)},{9L,0xFC24489BL,0x7F13BCF5L,0x7F13BCF5L},{9L,9L,0x784B52DDL,(-2L)},{9L,0xFC24489BL,0xF2E07230L,(-5L)},{(-10L),0xABA9A984L,0L,0xF2E07230L},{0x7F13BCF5L,0xABA9A984L,0x7F13BCF5L,(-5L)},{0xABA9A984L,0xFC24489BL,(-1L),(-2L)}}};
static int32_t g_51[5][8] = {{0x3C8A0C09L,0x55752783L,0x3C8A0C09L,0xE4879289L,8L,8L,0xE4879289L,0x3C8A0C09L},{0x55752783L,0x55752783L,8L,2L,0x2449EF57L,2L,8L,0x55752783L},{0x55752783L,0x3C8A0C09L,0xE4879289L,8L,8L,0xE4879289L,0x3C8A0C09L,0x55752783L},{0x3C8A0C09L,2L,0x55752783L,2L,0x55752783L,2L,0x3C8A0C09L,0x3C8A0C09L},{2L,2L,0xE4879289L,0xE4879289L,2L,2L,8L,2L}};
static uint32_t g_81 = 2UL;
static volatile uint32_t g_85 = 0x51F1B003L;/* VOLATILE GLOBAL g_85 */
static volatile uint32_t *g_84[7][5][4] = {{{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0}},{{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0}},{{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0}},{{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0}},{{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0}},{{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0}},{{&g_85,&g_85,(void*)0,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,&g_85,(void*)0},{(void*)0,&g_85,&g_85,(void*)0},{&g_85,&g_85,(void*)0,(void*)0}}};
static volatile uint32_t * volatile *g_83 = &g_84[6][3][2];
static volatile uint32_t * volatile ** volatile g_86 = &g_83;/* VOLATILE GLOBAL g_86 */
static uint32_t g_98 = 0xF0D5DC53L;
static uint8_t g_121 = 0UL;
static int64_t g_125[6] = {0x4D78F30ED53B0E2DLL,0x4D78F30ED53B0E2DLL,0x0B1440D3F7D50A45LL,0x4D78F30ED53B0E2DLL,0x4D78F30ED53B0E2DLL,0x0B1440D3F7D50A45LL};
static int8_t g_129 = 0x57L;
static int32_t *g_154 = &g_51[0][6];
static int32_t ** volatile g_153 = &g_154;/* VOLATILE GLOBAL g_153 */
static const union U1 g_163 = {0xA0CCB0C8L};
static int32_t g_178 = 0xFAC94E5EL;
static int32_t * volatile g_177 = &g_178;/* VOLATILE GLOBAL g_177 */
static uint32_t g_193 = 0x8993EC06L;
static struct S0 g_203[8] = {{-4,0,0},{-4,0,0},{9,-1,0},{-4,0,0},{-4,0,0},{9,-1,0},{-4,0,0},{-4,0,0}};
static int16_t g_204 = 0L;
static uint64_t g_206 = 0x163BCB85B4EB12BCLL;
static uint32_t *g_228 = &g_81;
static int16_t g_241 = 2L;
static int32_t * volatile g_242 = &g_178;/* VOLATILE GLOBAL g_242 */
static uint32_t *g_287[6] = {(void*)0,&g_193,(void*)0,(void*)0,&g_193,(void*)0};
static uint32_t **g_286 = &g_287[3];
static volatile struct S0 g_322 = {3,-0,6};/* VOLATILE GLOBAL g_322 */
static int32_t ** volatile g_331 = &g_154;/* VOLATILE GLOBAL g_331 */
static volatile int32_t g_342 = 3L;/* VOLATILE GLOBAL g_342 */
static const union U1 *g_361 = (void*)0;
static struct S0 g_518 = {-2,-0,3};/* VOLATILE GLOBAL g_518 */
static volatile int8_t * volatile * volatile *g_528 = (void*)0;
static volatile uint32_t * volatile *** volatile g_540 = (void*)0;/* VOLATILE GLOBAL g_540 */
static volatile uint32_t * volatile **g_542[8] = {&g_83,&g_83,&g_83,&g_83,&g_83,&g_83,&g_83,&g_83};
static volatile uint32_t * volatile *** volatile g_541 = &g_542[3];/* VOLATILE GLOBAL g_541 */
static uint64_t g_546 = 0x752A23DB570181C2LL;
static int32_t * volatile * volatile *g_548 = (void*)0;
static int32_t * volatile * volatile * volatile *g_547[9] = {&g_548,(void*)0,(void*)0,&g_548,(void*)0,(void*)0,&g_548,(void*)0,(void*)0};
static uint64_t g_559 = 0x801B29B5C1D028D9LL;
static volatile uint32_t **g_590 = &g_84[6][2][0];
static const uint32_t *g_604[8][5] = {{&g_98,&g_81,&g_81,&g_81,&g_98},{&g_81,(void*)0,&g_81,(void*)0,&g_81},{&g_98,&g_81,&g_81,&g_81,&g_98},{&g_81,(void*)0,&g_81,(void*)0,&g_81},{&g_98,&g_81,&g_81,&g_81,&g_98},{&g_81,(void*)0,&g_81,(void*)0,&g_81},{&g_98,&g_81,&g_81,&g_81,&g_98},{&g_81,(void*)0,&g_81,(void*)0,&g_81}};
static const uint32_t **g_603[10] = {(void*)0,&g_604[3][2],(void*)0,(void*)0,&g_604[3][2],(void*)0,(void*)0,&g_604[3][2],(void*)0,(void*)0};
static const uint32_t ***g_602[5][3] = {{&g_603[5],&g_603[7],&g_603[5]},{&g_603[7],&g_603[7],&g_603[7]},{&g_603[5],&g_603[7],&g_603[5]},{&g_603[7],&g_603[7],&g_603[7]},{&g_603[5],&g_603[7],&g_603[5]}};
static uint32_t **g_614 = &g_228;
static int8_t g_659[3][6][5] = {{{0xB8L,7L,8L,0xFEL,(-1L)},{(-10L),0L,(-6L),0L,(-6L)},{0x13L,0x13L,9L,0x39L,(-7L)},{1L,0x8CL,5L,(-1L),(-4L)},{0x5CL,(-2L),0x13L,0x97L,0x9CL},{0xD8L,0x8CL,(-1L),(-1L),0x8CL}},{{(-1L),0x13L,0xFEL,0xB8L,0xBBL},{2L,0L,0x51L,0xD8L,(-1L)},{0x39L,7L,0x9CL,(-2L),0xC0L},{2L,0L,1L,0L,2L},{(-1L),0x12L,0xC0L,0x9CL,0x13L},{0xD8L,1L,0L,0L,0x60L}},{{0x5CL,8L,1L,0x12L,0x13L},{1L,0L,0L,1L,2L},{0x13L,0xFEL,0xB8L,0xBBL,0xC0L},{(-10L),2L,0xB0L,(-6L),(-1L)},{0xB8L,(-1L),0x97L,(-7L),(-7L)},{(-4L),5L,(-4L),1L,(-1L)}}};
static int32_t g_722 = 0x0D2E9A3CL;
static int16_t g_723 = 0x8D42L;
static union U1 g_733 = {1UL};
static union U1 *g_732 = &g_733;
static int32_t g_745 = 7L;
static int64_t g_749 = 0xE2EA8ED61F1CFF4DLL;
static uint16_t g_752[7][6][5] = {{{0xDC35L,65534UL,0x4FD2L,0UL,0x7642L},{0x1AA6L,0UL,0UL,9UL,1UL},{0x4D60L,0xF13AL,0xD80DL,0x27BBL,65534UL},{0x7642L,1UL,0x4978L,0UL,0x01D4L},{2UL,0UL,0x4978L,0UL,2UL},{0x1B44L,4UL,0xD80DL,0xEACEL,0x6AC4L}},{{8UL,4UL,0UL,0xF13AL,0UL},{0xA8C7L,0xE7FCL,0x4FD2L,0x8C26L,0UL},{0UL,65526UL,65533UL,4UL,0xDC35L},{0x4A57L,0x2275L,0x6EE9L,0x2275L,0x4A57L},{65535UL,0UL,0xEEA3L,0xEBAFL,65535UL},{0x876EL,0x6EE9L,0x6AC4L,0x4978L,65533UL}},{{2UL,0x2806L,1UL,0UL,65535UL},{0x8C26L,0x4978L,65526UL,0UL,0x4A57L},{65535UL,65535UL,4UL,0x74D1L,0xDC35L},{0x15E1L,0x7DF4L,0x27BBL,65535UL,0UL},{0x4B79L,0x4D60L,2UL,65527UL,0UL},{0UL,0x4FC6L,0x4A57L,0xD80DL,0x6AC4L}},{{65527UL,65535UL,2UL,0x7642L,2UL},{0x2275L,9UL,0xC1A4L,0UL,0x01D4L},{0UL,9UL,0xE7FCL,0x6EE9L,65534UL},{0UL,65535UL,2UL,0x9702L,1UL},{0x7DF4L,0x4FC6L,4UL,0UL,0x7642L},{4UL,0x4D60L,7UL,0UL,0UL}},{{0UL,0x7DF4L,9UL,2UL,4UL},{7UL,65535UL,65535UL,7UL,0x15E1L},{6UL,0x4978L,2UL,4UL,65530UL},{4UL,0x2806L,0UL,65527UL,65535UL},{4UL,0x6EE9L,65535UL,4UL,1UL},{65530UL,0UL,0x4B79L,7UL,1UL}},{{0UL,0x2275L,0xEACEL,2UL,0x8C26L},{0x27BBL,65526UL,0UL,0UL,9UL},{0UL,0xE7FCL,65534UL,0UL,65535UL},{65535UL,4UL,0x876EL,0x9702L,0x6EE9L},{0xE7FCL,4UL,4UL,0x6EE9L,65530UL},{0xEBAFL,0UL,6UL,0UL,0x4FC6L}},{{0xEBAFL,1UL,0xF13AL,65527UL,65526UL},{0xEBAFL,9UL,0x2806L,0x4978L,0x7642L},{9UL,4UL,0xC1A4L,65535UL,0UL},{0x4FC6L,65533UL,1UL,6UL,0x4FD2L},{65535UL,65527UL,65535UL,2UL,2UL},{4UL,65527UL,4UL,0x9702L,0x4D60L}}};
static const uint16_t g_811 = 0UL;
static int32_t ** volatile g_812[7] = {&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154};
static int32_t ** volatile g_813 = &g_154;/* VOLATILE GLOBAL g_813 */
static uint8_t *g_936 = &g_121;
static uint8_t ** volatile g_935 = &g_936;/* VOLATILE GLOBAL g_935 */
static uint8_t ** volatile *g_934 = &g_935;
static uint8_t ** volatile **g_933 = &g_934;
static uint8_t ** volatile ** volatile * volatile g_932[6] = {&g_933,&g_933,&g_933,&g_933,&g_933,&g_933};
static int8_t g_987 = 0x1FL;
static uint8_t g_993[4][1][3] = {{{0x0BL,1UL,0x0BL}},{{0x30L,0x30L,0x30L}},{{0x0BL,1UL,0x0BL}},{{0x30L,0x30L,0x30L}}};
static volatile struct S0 g_1017[1][1] = {{{-1,-1,1}}};
static uint8_t *****g_1042 = (void*)0;
static struct S0 g_1079 = {-9,-0,3};/* VOLATILE GLOBAL g_1079 */
static uint8_t ****g_1080 = (void*)0;
static int8_t **g_1083 = &g_31;
static int8_t *** volatile g_1082 = &g_1083;/* VOLATILE GLOBAL g_1082 */
static int32_t * volatile g_1096 = &g_51[0][6];/* VOLATILE GLOBAL g_1096 */
static uint8_t *** const *g_1155 = (void*)0;
static int32_t g_1214 = (-10L);
static uint8_t g_1227 = 0xF1L;
static volatile struct S0 g_1270 = {0,0,3};/* VOLATILE GLOBAL g_1270 */
static int32_t ** volatile g_1376 = &g_154;/* VOLATILE GLOBAL g_1376 */
static uint32_t ***g_1456 = &g_614;
static uint32_t ****g_1455[7] = {(void*)0,&g_1456,(void*)0,(void*)0,&g_1456,(void*)0,(void*)0};
static uint16_t g_1477 = 65535UL;
static int32_t ** volatile g_1525 = &g_154;/* VOLATILE GLOBAL g_1525 */
static struct S0 **g_1560 = (void*)0;
static struct S0 *** volatile g_1559 = &g_1560;/* VOLATILE GLOBAL g_1559 */
static volatile int32_t *g_1562 = &g_342;
static volatile int32_t ** volatile g_1561 = &g_1562;/* VOLATILE GLOBAL g_1561 */
static int32_t ****g_1626 = (void*)0;
static uint32_t g_1632[2][4] = {{0xCE386C36L,0xCE386C36L,0xCE386C36L,0xCE386C36L},{0xCE386C36L,0xCE386C36L,0xCE386C36L,0xCE386C36L}};
static int32_t *g_1634[5] = {&g_1214,&g_1214,&g_1214,&g_1214,&g_1214};
static int32_t **g_1633[7][8][4] = {{{&g_1634[4],(void*)0,&g_1634[1],(void*)0},{&g_1634[2],&g_1634[2],&g_1634[2],&g_1634[4]},{(void*)0,&g_1634[2],&g_1634[2],(void*)0},{&g_1634[1],(void*)0,&g_1634[4],&g_1634[4]},{&g_1634[1],&g_1634[4],&g_1634[2],&g_1634[2]},{(void*)0,&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[2],&g_1634[4],&g_1634[1],&g_1634[4]},{&g_1634[4],(void*)0,&g_1634[1],(void*)0}},{{&g_1634[2],&g_1634[2],&g_1634[2],&g_1634[4]},{(void*)0,&g_1634[2],&g_1634[2],(void*)0},{&g_1634[1],(void*)0,&g_1634[4],&g_1634[4]},{&g_1634[1],&g_1634[4],&g_1634[2],&g_1634[2]},{(void*)0,&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[2],&g_1634[4],&g_1634[1],&g_1634[4]},{&g_1634[4],(void*)0,&g_1634[1],(void*)0},{&g_1634[2],&g_1634[2],&g_1634[2],&g_1634[4]}},{{(void*)0,&g_1634[2],&g_1634[2],(void*)0},{&g_1634[1],(void*)0,&g_1634[4],&g_1634[4]},{&g_1634[1],&g_1634[4],&g_1634[2],&g_1634[2]},{(void*)0,&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[2],&g_1634[4],&g_1634[1],&g_1634[4]},{&g_1634[4],(void*)0,&g_1634[1],(void*)0},{&g_1634[2],&g_1634[2],&g_1634[2],&g_1634[4]},{(void*)0,&g_1634[2],&g_1634[2],(void*)0}},{{&g_1634[1],(void*)0,&g_1634[4],&g_1634[4]},{&g_1634[1],&g_1634[4],&g_1634[2],&g_1634[2]},{(void*)0,&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[2],&g_1634[4],&g_1634[1],&g_1634[4]},{&g_1634[4],(void*)0,&g_1634[1],(void*)0},{&g_1634[2],&g_1634[2],&g_1634[1],&g_1634[2]},{&g_1634[1],&g_1634[2],&g_1634[2],&g_1634[1]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[2]}},{{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[4],&g_1634[2]},{&g_1634[2],&g_1634[2],&g_1634[4],&g_1634[1]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[2]},{&g_1634[1],&g_1634[2],&g_1634[2],&g_1634[1]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[4]}},{{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[4],&g_1634[2]},{&g_1634[2],&g_1634[2],&g_1634[4],&g_1634[1]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[2]},{&g_1634[1],&g_1634[2],&g_1634[2],&g_1634[1]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[4]}},{{&g_1634[1],&g_1634[2],&g_1634[4],&g_1634[2]},{&g_1634[2],&g_1634[2],&g_1634[4],&g_1634[1]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[2]},{&g_1634[1],&g_1634[2],&g_1634[2],&g_1634[1]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[2]},{&g_1634[4],&g_1634[2],&g_1634[2],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[1],&g_1634[4]},{&g_1634[1],&g_1634[2],&g_1634[4],&g_1634[2]}}};
static int32_t *** volatile g_1635[6] = {&g_1633[0][1][0],&g_1633[0][1][0],&g_1633[0][1][0],&g_1633[0][1][0],&g_1633[0][1][0],&g_1633[0][1][0]};
static int32_t g_1652[4] = {0x516D7AEDL,0x516D7AEDL,0x516D7AEDL,0x516D7AEDL};
static uint32_t *** volatile g_1672 = &g_614;/* VOLATILE GLOBAL g_1672 */
static uint16_t g_1697 = 0xA6E6L;
static int32_t ** const  volatile g_1715[5][1] = {{&g_154},{&g_154},{&g_154},{&g_154},{&g_154}};
static int32_t ** volatile g_1716 = (void*)0;/* VOLATILE GLOBAL g_1716 */
static int32_t ** volatile g_1717 = (void*)0;/* VOLATILE GLOBAL g_1717 */
static uint8_t g_1746 = 0x65L;
static uint8_t g_1762 = 0UL;
static uint64_t g_1798 = 1UL;
static uint32_t g_1809 = 0x4E8C1F1DL;
static volatile uint16_t g_1812[7][8][4] = {{{0x7600L,65534UL,0x9FDEL,0xBC7BL},{0x8D0BL,0x7600L,65532UL,0x8BCCL},{0x9992L,65535UL,0x9992L,0x8BCCL},{65532UL,0x7600L,0x8D0BL,0xBC7BL},{0x9FDEL,65534UL,0x7600L,0x7600L},{1UL,1UL,0x7600L,0x9992L},{0x9FDEL,0x26E3L,0x8D0BL,65534UL},{65532UL,0x8D0BL,0x9992L,0x8D0BL}},{{0x9992L,0x8D0BL,65532UL,65534UL},{0x8D0BL,0x26E3L,0x9FDEL,0x9992L},{0x7600L,1UL,1UL,0x7600L},{0x7600L,65534UL,0x9FDEL,0xBC7BL},{0x8D0BL,0x7600L,65532UL,0x8BCCL},{0x9992L,65535UL,0x9992L,0x8BCCL},{65532UL,0x7600L,0x8D0BL,0xBC7BL},{0x9FDEL,65534UL,0x7600L,0x7600L}},{{1UL,1UL,0x7600L,0x9992L},{0x9FDEL,65532UL,65535UL,0x7600L},{0x9FDEL,65535UL,65534UL,65535UL},{65534UL,65535UL,0x9FDEL,0x7600L},{65535UL,65532UL,0x9992L,65534UL},{1UL,0x8BCCL,0x8BCCL,1UL},{1UL,0x7600L,0x9992L,0x26E3L},{65535UL,1UL,0x9FDEL,0x8D0BL}},{{65534UL,0xBC7BL,65534UL,0x8D0BL},{0x9FDEL,1UL,65535UL,0x26E3L},{0x9992L,0x7600L,1UL,1UL},{0x8BCCL,0x8BCCL,1UL,65534UL},{0x9992L,65532UL,65535UL,0x7600L},{0x9FDEL,65535UL,65534UL,65535UL},{65534UL,65535UL,0x9FDEL,0x7600L},{65535UL,65532UL,0x9992L,65534UL}},{{1UL,0x8BCCL,0x8BCCL,1UL},{1UL,0x7600L,0x9992L,0x26E3L},{65535UL,1UL,0x9FDEL,0x8D0BL},{65534UL,0xBC7BL,65534UL,0x8D0BL},{0x9FDEL,1UL,65535UL,0x26E3L},{0x9992L,0x7600L,1UL,1UL},{0x8BCCL,0x8BCCL,1UL,65534UL},{0x9992L,65532UL,65535UL,0x7600L}},{{0x9FDEL,65535UL,65534UL,65535UL},{65534UL,65535UL,0x9FDEL,0x7600L},{65535UL,65532UL,0x9992L,65534UL},{1UL,0x8BCCL,0x8BCCL,1UL},{1UL,0x7600L,0x9992L,0x26E3L},{65535UL,1UL,0x9FDEL,0x8D0BL},{65534UL,0xBC7BL,65534UL,0x8D0BL},{0x9FDEL,1UL,65535UL,0x26E3L}},{{0x9992L,0x7600L,1UL,1UL},{0x8BCCL,0x8BCCL,1UL,65534UL},{0x9992L,65532UL,65535UL,0x7600L},{0x9FDEL,65535UL,65534UL,65535UL},{65534UL,65535UL,0x9FDEL,0x7600L},{65535UL,65532UL,0x9992L,65534UL},{1UL,0x8BCCL,0x8BCCL,1UL},{1UL,0x7600L,0x9992L,0x26E3L}}};
static volatile uint16_t * volatile g_1811[8] = {&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1],&g_1812[5][0][1]};
static volatile uint16_t * volatile *g_1810 = &g_1811[2];
static volatile uint16_t * volatile ** volatile g_1813 = &g_1810;/* VOLATILE GLOBAL g_1813 */
static int32_t *g_1869 = &g_745;
static struct S0 *g_1877 = &g_203[5];
static struct S0 ** volatile g_1876 = &g_1877;/* VOLATILE GLOBAL g_1876 */
static const volatile struct S0 g_1883 = {-5,1,6};/* VOLATILE GLOBAL g_1883 */
static uint64_t *g_1895 = &g_206;
static struct S0 g_1915 = {10,0,7};/* VOLATILE GLOBAL g_1915 */
static volatile int64_t g_1924 = 0xE9D4F688B990F304LL;/* VOLATILE GLOBAL g_1924 */
static int32_t *****g_2011[2][3] = {{&g_1626,&g_1626,&g_1626},{&g_1626,&g_1626,&g_1626}};
static volatile int8_t g_2068[9][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
static const uint16_t ***g_2176 = (void*)0;
static const uint16_t ****g_2175 = &g_2176;
static struct S0 g_2191 = {-5,-1,0};/* VOLATILE GLOBAL g_2191 */
static volatile int32_t * volatile g_2242 = &g_342;/* VOLATILE GLOBAL g_2242 */
static uint32_t *****g_2324 = (void*)0;
static uint64_t *g_2336 = &g_1798;
static int16_t g_2337 = 0xFA56L;
static int64_t g_2353 = 0L;
static volatile uint8_t g_2364 = 0xEEL;/* VOLATILE GLOBAL g_2364 */
static int8_t *g_2389[3][7] = {{&g_987,(void*)0,&g_659[0][3][0],&g_659[1][1][0],&g_129,&g_987,&g_32},{&g_32,&g_987,&g_129,&g_659[1][1][0],&g_129,&g_987,&g_32},{&g_32,&g_987,&g_129,&g_659[1][1][0],&g_129,&g_987,&g_32}};
static union U1 g_2425 = {1UL};
static int16_t * volatile g_2444[6][5][8] = {{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}},{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}},{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}},{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}},{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}},{{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204},{&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204,&g_204}}};
static int16_t * volatile *g_2443 = &g_2444[2][1][4];
static uint64_t **g_2477 = &g_2336;
static uint32_t ** const *g_2515 = &g_614;
static uint32_t ** const **g_2514 = &g_2515;
static int16_t g_2586 = (-9L);
static int32_t ** const  volatile g_2590 = &g_154;/* VOLATILE GLOBAL g_2590 */
static int16_t * volatile **g_2649 = &g_2443;
static int16_t *g_2727 = &g_2337;
static int16_t **g_2726 = &g_2727;
static uint64_t g_2730 = 0x39B1626ADE5B3A74LL;
static const int32_t *g_2732 = &g_51[0][6];
static volatile int32_t g_2818 = 0L;/* VOLATILE GLOBAL g_2818 */
static uint32_t g_2863 = 0xDC669DE0L;
static int32_t **g_2887 = &g_1869;
static int32_t ** const *g_2886 = &g_2887;
static int32_t ** const **g_2885 = &g_2886;
static volatile uint16_t g_2908 = 1UL;/* VOLATILE GLOBAL g_2908 */
static int32_t g_2952 = 0xA817A129L;
static int32_t * const g_2951 = &g_2952;
static int32_t * const *g_2950 = &g_2951;
static volatile int32_t * volatile * volatile g_2964 = &g_1562;/* VOLATILE GLOBAL g_2964 */
static volatile int32_t * volatile * volatile * volatile g_2963 = &g_2964;/* VOLATILE GLOBAL g_2963 */
static volatile int32_t * volatile * volatile * volatile * volatile g_2962 = &g_2963;/* VOLATILE GLOBAL g_2962 */
static volatile int32_t * volatile * volatile * volatile * volatile * volatile g_2961 = &g_2962;/* VOLATILE GLOBAL g_2961 */
static uint32_t g_2969[9][2] = {{4294967286UL,0xEDA23630L},{4294967286UL,4294967286UL},{4294967286UL,0xEDA23630L},{4294967286UL,4294967286UL},{4294967286UL,0xEDA23630L},{4294967286UL,4294967286UL},{4294967286UL,0xEDA23630L},{4294967286UL,4294967286UL},{4294967286UL,0xEDA23630L}};
static struct S0 g_3003 = {-5,-1,6};/* VOLATILE GLOBAL g_3003 */
static const volatile int64_t g_3016 = 1L;/* VOLATILE GLOBAL g_3016 */
static const volatile struct S0 g_3022 = {2,-0,3};/* VOLATILE GLOBAL g_3022 */
static uint8_t **g_3089[5][6][2] = {{{(void*)0,&g_936},{&g_936,(void*)0},{&g_936,&g_936},{(void*)0,(void*)0},{&g_936,(void*)0},{&g_936,(void*)0}},{{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,(void*)0},{(void*)0,(void*)0}},{{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,(void*)0},{&g_936,(void*)0}},{{&g_936,(void*)0},{(void*)0,&g_936},{&g_936,(void*)0},{&g_936,&g_936},{(void*)0,(void*)0},{&g_936,(void*)0}},{{&g_936,(void*)0},{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,&g_936},{&g_936,(void*)0}}};
static uint8_t ***g_3088 = &g_3089[3][1][0];
static uint8_t **** const g_3087 = &g_3088;
static uint8_t **** const *g_3086 = &g_3087;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_2(uint8_t  p_3, int8_t * p_4, int8_t * p_5, int8_t  p_6, const uint32_t  p_7);
static uint32_t  func_8(int8_t  p_9, int8_t * p_10, int8_t * p_11, int8_t * const  p_12);
static int16_t  func_22(const int8_t  p_23, uint8_t  p_24, uint32_t  p_25);
static uint8_t  func_28(int8_t  p_29, int8_t * p_30);
static int8_t  func_35(int32_t  p_36, uint16_t  p_37, int8_t * p_38, int8_t * p_39, int8_t * p_40);
static int8_t * func_41(int32_t  p_42);
static int32_t * func_54(uint8_t  p_55, int16_t  p_56);
static int8_t  func_57(int64_t  p_58, const union U1  p_59, int8_t * p_60);
static uint32_t  func_61(uint32_t  p_62, int16_t  p_63, int32_t * p_64, int32_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_31 g_32 g_129 g_154 g_51 g_121 g_732 g_745 g_178 g_813 g_125 g_241 g_193 g_204 g_49 g_559 g_749 g_206 g_659 g_932 g_733 g_153 g_934 g_935 g_936 g_546 g_933 g_752 g_987 g_46 g_177 g_1017 g_163.f0 g_242 g_518.f1 g_203 g_993 g_1082 g_286 g_287 g_1096 g_1083 g_722 g_50 g_1227 g_541 g_542 g_342 g_1270 g_733.f0 g_98 g_1376 g_331 g_81 g_322.f2 g_1214 g_1455 g_83 g_84 g_1477 g_811 g_1079.f2 g_1525 g_518.f0 g_1456 g_614 g_228 g_1762 g_1697 g_1798 g_1810 g_1813 g_1877 g_1811 g_1812 g_1869 g_1079.f1 g_1895 g_1915.f0 g_2068 g_1652 g_1079 g_2175 g_2191 g_1809 g_723 g_2242 g_2337 g_2364 g_2443 g_2444 g_1632 g_1746 g_2514 g_2590 g_2353
 * writes: g_32 g_46 g_51 g_206 g_154 g_121 g_81 g_732 g_361 g_125 g_749 g_752 g_178 g_745 g_241 g_204 g_559 g_129 g_723 g_193 g_31 g_1042 g_1083 g_287 g_733.f0 g_1155 g_546 g_659 g_1227 g_98 g_1477 g_1697 g_1798 g_1809 g_1810 g_1762 g_2011 g_1214 g_1456 g_2324 g_2336 g_2337 g_2353 g_2389 g_1632 g_2477 g_1455 g_722 g_2514 g_934
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_19 = 0xD0L;
    int64_t l_1029 = 0x1EE3E5A3DDD031C6LL;
    uint16_t *l_1761 = &g_1477;
    const uint32_t l_1768 = 4294967295UL;
    int32_t l_2325 = 0x2FF5B9F8L;
    int8_t *l_2326 = &g_129;
    uint32_t **l_2333 = &g_287[3];
    uint64_t *l_2334 = (void*)0;
    uint64_t **l_2335[2][4] = {{&l_2334,&l_2334,&l_2334,&l_2334},{&l_2334,&l_2334,&l_2334,&l_2334}};
    int16_t *l_2338 = &g_2337;
    int16_t *l_2339[6][5][7] = {{{&g_204,&g_204,(void*)0,&g_204,&g_241,(void*)0,&g_204},{&g_241,&g_241,&g_204,&g_723,&g_241,&g_241,&g_723},{&g_723,&g_204,&g_723,&g_204,&g_241,&g_723,&g_241},{&g_723,&g_723,(void*)0,&g_241,&g_723,&g_204,&g_723},{&g_241,&g_204,&g_204,&g_241,&g_241,&g_723,&g_241}},{{&g_241,&g_204,&g_204,(void*)0,&g_723,&g_204,&g_204},{&g_204,&g_723,&g_204,&g_723,&g_204,&g_241,&g_723},{&g_204,&g_241,(void*)0,&g_723,&g_241,&g_204,&g_241},{&g_723,&g_241,&g_723,&g_723,&g_241,&g_723,(void*)0},{&g_204,&g_723,&g_723,(void*)0,&g_241,&g_241,&g_723}},{{&g_204,(void*)0,&g_723,&g_241,&g_723,(void*)0,&g_204},{&g_204,&g_723,&g_241,&g_723,&g_204,&g_204,&g_241},{(void*)0,&g_241,&g_204,&g_723,&g_723,&g_204,&g_241},{&g_723,&g_241,&g_241,(void*)0,(void*)0,&g_723,&g_241},{(void*)0,&g_723,&g_723,(void*)0,&g_241,(void*)0,&g_723}},{{&g_204,&g_241,&g_723,(void*)0,&g_723,&g_723,&g_204},{&g_204,&g_723,&g_723,&g_723,(void*)0,(void*)0,&g_723},{(void*)0,&g_241,(void*)0,&g_723,&g_723,&g_204,(void*)0},{&g_723,&g_241,&g_204,&g_241,&g_241,&g_241,&g_241},{&g_204,&g_723,&g_241,(void*)0,(void*)0,&g_204,&g_723}},{{(void*)0,&g_204,&g_723,&g_723,&g_723,(void*)0,(void*)0},{&g_204,&g_723,&g_723,&g_723,&g_204,&g_723,&g_723},{(void*)0,(void*)0,(void*)0,&g_723,&g_723,(void*)0,&g_241},{&g_241,&g_241,&g_241,(void*)0,&g_241,&g_723,(void*)0},{(void*)0,&g_723,&g_241,(void*)0,&g_241,&g_204,&g_723}},{{&g_204,&g_204,&g_241,(void*)0,&g_241,&g_204,&g_204},{(void*)0,&g_723,&g_723,&g_723,&g_204,(void*)0,&g_723},{&g_204,&g_241,&g_241,&g_723,&g_723,&g_241,&g_241},{&g_723,(void*)0,&g_723,&g_241,(void*)0,&g_723,&g_241},{(void*)0,&g_723,&g_241,&g_204,&g_241,&g_204,&g_241}}};
    int32_t l_2340[3][9] = {{0x130974D8L,0x130974D8L,0xA05DC376L,0xB8C3FE84L,0xA05DC376L,0x130974D8L,0x130974D8L,0xA05DC376L,0xB8C3FE84L},{(-5L),0L,(-5L),0x3EA0DD71L,0x3EA0DD71L,(-5L),0L,(-5L),0x3EA0DD71L},{0xB8C3FE84L,1L,1L,0xB8C3FE84L,0x130974D8L,0xB8C3FE84L,1L,1L,0xB8C3FE84L}};
    int64_t *l_2341 = &g_125[1];
    int32_t l_2366 = 1L;
    int32_t l_2383 = (-2L);
    int32_t l_2384 = 1L;
    uint8_t l_2405 = 1UL;
    int32_t l_2418[2];
    int32_t l_2449 = 0L;
    int32_t *l_2589 = &g_51[0][6];
    int8_t l_2606 = 0x50L;
    int32_t **l_2624 = &l_2589;
    int32_t ***l_2623 = &l_2624;
    const int32_t *l_2731 = &g_745;
    int32_t *l_2737 = &g_51[0][6];
    int64_t l_2759 = 0x918A449DAD4852F3LL;
    int32_t ****l_2833 = &l_2623;
    uint8_t ****l_2911 = (void*)0;
    uint8_t l_2924 = 0xC5L;
    uint16_t l_2936 = 0xE816L;
    int32_t **l_2947 = &g_1634[4];
    int64_t l_3041 = 0L;
    int8_t l_3066 = 5L;
    uint16_t l_3068[8] = {0UL,65527UL,0UL,65527UL,0UL,65527UL,0UL,65527UL};
    uint16_t l_3094 = 1UL;
    const union U1 * const *l_3095[8][9][3] = {{{(void*)0,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,(void*)0,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{(void*)0,(void*)0,&g_361}},{{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{(void*)0,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{(void*)0,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361}},{{(void*)0,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,(void*)0},{&g_361,&g_361,(void*)0},{&g_361,(void*)0,&g_361},{&g_361,&g_361,(void*)0},{&g_361,(void*)0,(void*)0},{&g_361,(void*)0,&g_361},{(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_361,&g_361},{(void*)0,&g_361,&g_361},{&g_361,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361}},{{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,(void*)0,&g_361},{&g_361,(void*)0,&g_361},{&g_361,(void*)0,&g_361},{&g_361,&g_361,&g_361},{(void*)0,(void*)0,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361}},{{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,(void*)0},{&g_361,&g_361,&g_361},{&g_361,&g_361,(void*)0},{&g_361,&g_361,&g_361}},{{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{(void*)0,(void*)0,&g_361},{(void*)0,&g_361,&g_361},{(void*)0,&g_361,&g_361},{&g_361,&g_361,(void*)0},{(void*)0,(void*)0,&g_361},{&g_361,&g_361,&g_361},{(void*)0,(void*)0,&g_361}},{{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{&g_361,&g_361,&g_361},{(void*)0,&g_361,(void*)0},{&g_361,&g_361,&g_361}}};
    const union U1 * const **l_3096 = &l_3095[5][6][1];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2418[i] = 0x44456E1EL;
    l_2325 = ((*g_1869) = func_2((func_8((safe_lshift_func_uint32_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s((((*l_1761) = ((safe_rshift_func_uint32_t_u_s_unsafe_macro/*2*//* ___SAFE__OP */(l_19, 5)) || (safe_mod_func_int16_t_s_s_unsafe_macro/*3*//* ___SAFE__OP */(func_22((safe_div_func_uint16_t_u_u_unsafe_macro/*4*//* ___SAFE__OP */((func_28(l_19, g_31) & (g_163.f0 , l_19)), 0x789BL)), l_1029, (0xE254L >= 1L)), 0xD31EL)))) == 0xEF8FL), g_1762)), 7)), &l_19, &g_987, &l_19) <= l_1029), &l_19, &l_19, l_1029, l_1768));
    if (((l_2325 & 0x00L) , ((((((*l_2326) |= 2L) || (l_2325 = (((*l_2341) = (safe_mul_func_uint16_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */((((g_204 = ((*l_2338) = ((safe_add_func_int32_t_s_s_unsafe_macro/*6*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*7*//* ___SAFE__OP */((l_2333 == l_2333), (*g_1895))), ((*g_1869) ^= ((g_2336 = l_2334) == (void*)0)))) ^ ((*l_2326) = g_2337)))) > g_559) || l_2340[2][6]), 0x6D94L))) <= l_2325))) , l_2340[2][4]) , 3L) , 0x8A27112EL)))
    { /* block id: 1157 */
        uint16_t l_2350 = 0xB0A0L;
        int32_t l_2365 = (-1L);
        uint8_t l_2371 = 251UL;
        int32_t l_2381 = (-10L);
        int32_t *l_2408 = &g_178;
        int64_t l_2410 = 0x2637608CD1B255A0LL;
        int32_t l_2415[1];
        union U1 l_2446[9] = {{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL},{0xF387460AL}};
        int8_t *l_2452 = &g_32;
        uint64_t *l_2526 = &g_546;
        uint64_t *l_2527 = &g_546;
        uint8_t **l_2544[1];
        int16_t l_2585 = 0x999BL;
        int32_t **l_2603 = &g_154;
        int32_t ***l_2602[4];
        int32_t ****l_2601 = &l_2602[1];
        const int32_t l_2605[7][9][2] = {{{0x42D4E2B1L,0x70774221L},{0xFECFCBD5L,0L},{8L,0x42D4E2B1L},{0L,(-6L)},{(-6L),1L},{0x9131E788L,0L},{0x1134A9E9L,8L},{0x9ADD132EL,1L},{0L,1L}},{{0x9ADD132EL,8L},{0x1134A9E9L,0L},{0x9131E788L,1L},{(-6L),(-6L)},{0L,0x42D4E2B1L},{8L,0L},{0xFECFCBD5L,0x70774221L},{0x42D4E2B1L,0xFECFCBD5L},{4L,(-3L)}},{{4L,0xFECFCBD5L},{0x42D4E2B1L,0x70774221L},{0xFECFCBD5L,0L},{8L,0x42D4E2B1L},{0L,(-6L)},{(-6L),1L},{0x9131E788L,0L},{0x1134A9E9L,8L},{0x9ADD132EL,1L}},{{0L,1L},{0x9ADD132EL,8L},{0x1134A9E9L,0L},{0x9131E788L,1L},{(-6L),(-6L)},{0L,0x42D4E2B1L},{8L,0L},{0xFECFCBD5L,0x70774221L},{0x42D4E2B1L,0xFECFCBD5L}},{{4L,(-3L)},{4L,0xFECFCBD5L},{0x42D4E2B1L,0x70774221L},{0xFECFCBD5L,0L},{8L,0x42D4E2B1L},{0L,(-6L)},{(-6L),1L},{0x9131E788L,0L},{0x1134A9E9L,8L}},{{0x9ADD132EL,1L},{0L,1L},{0x9ADD132EL,8L},{0x1134A9E9L,0L},{0x9131E788L,1L},{(-6L),(-6L)},{0L,0x42D4E2B1L},{8L,0L},{0xFECFCBD5L,0x70774221L}},{{0x42D4E2B1L,0xFECFCBD5L},{4L,(-3L)},{4L,0xFECFCBD5L},{0x42D4E2B1L,0x70774221L},{0xFECFCBD5L,0L},{8L,0x42D4E2B1L},{0L,(-6L)},{(-6L),1L},{0x9131E788L,0L}}};
        int32_t ***l_2618 = &g_1633[2][4][1];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2415[i] = 0L;
        for (i = 0; i < 1; i++)
            l_2544[i] = &g_936;
        for (i = 0; i < 4; i++)
            l_2602[i] = &l_2603;
        (*g_1869) &= (*g_1096);
        l_2325 &= (safe_lshift_func_int16_t_s_u((-5L), 3));
        if (((((safe_mod_func_int8_t_s_s(((l_1029 , ((safe_rshift_func_uint32_t_u_s_unsafe_macro/*10*//* ___SAFE__OP */(0x65CCBA45L, 29)) > 0xD2L)) , l_2350), (safe_rshift_func_int64_t_s_u_unsafe_macro/*11*//* ___SAFE__OP */((l_1768 || (g_2353 = 1UL)), 22)))) || ((((****g_933) = (l_2365 ^= (((safe_rshift_func_int8_t_s_s_unsafe_macro/*12*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*13*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */(((g_733 , ((safe_add_func_int32_t_s_s_unsafe_macro/*15*//* ___SAFE__OP */(l_2350, (safe_sub_func_int16_t_s_s_unsafe_macro/*16*//* ___SAFE__OP */(l_2340[2][6], 0xE635L)))) && 0x31BB729DD3CDC27CLL)) > g_2364), (*g_1895))), l_2350)), 0)) ^ g_81) >= l_1768))) <= 1UL) != l_2350)) <= 18446744073709551609UL) != l_2366))
        { /* block id: 1163 */
            return l_2325;
        }
        else
        { /* block id: 1165 */
            uint64_t l_2385 = 0UL;
            int8_t *l_2388 = (void*)0;
            int32_t *l_2407 = (void*)0;
            int32_t l_2409 = (-1L);
            int32_t l_2411 = 0x90F697B5L;
            int32_t l_2413 = 8L;
            int32_t l_2417 = 0L;
            int32_t l_2419 = 0xC49BBFC8L;
            int32_t l_2420 = 0xCFA9DFD7L;
            uint32_t l_2421 = 4UL;
            union U1 l_2432 = {0x4C5F2719L};
            int16_t **l_2445[8][8] = {{&l_2339[4][3][5],&l_2338,&l_2339[0][2][4],&l_2338,&l_2338,&l_2339[2][3][4],&l_2338,&l_2338},{&l_2339[4][4][6],(void*)0,&l_2339[4][4][6],&l_2339[0][0][4],&l_2339[5][0][6],&l_2339[4][4][6],(void*)0,&l_2339[4][4][6]},{&l_2339[2][1][4],&l_2339[0][0][4],&l_2338,&l_2338,&l_2339[4][1][1],&l_2339[3][3][1],&l_2338,&l_2338},{&l_2339[2][1][4],&l_2338,&l_2339[2][2][6],&l_2339[3][0][5],&l_2338,&l_2339[4][4][6],&l_2338,&l_2339[0][2][4]},{&l_2339[4][4][6],&l_2339[4][4][6],&l_2339[4][4][6],&l_2338,&l_2339[5][0][1],&l_2339[5][0][1],&l_2338,&l_2339[4][4][6]},{&l_2339[4][4][6],&l_2339[4][4][6],&l_2339[4][3][5],&l_2339[5][0][6],&l_2338,(void*)0,&l_2338,&l_2338},{&l_2339[5][0][6],&l_2339[3][0][5],&l_2338,&l_2339[4][4][6],&l_2339[4][4][6],&l_2338,&l_2338,&l_2338},{&l_2339[3][0][5],&l_2338,&l_2339[0][2][4],&l_2339[5][0][6],(void*)0,&l_2338,&l_2339[4][4][6],&l_2339[4][4][6]}};
            uint32_t l_2472 = 4294967289UL;
            uint64_t **l_2475 = (void*)0;
            const uint32_t * const *l_2508 = &g_604[4][2];
            const uint32_t * const **l_2507 = &l_2508;
            const uint32_t * const *** const l_2506[2][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_2507,(void*)0,(void*)0,(void*)0,(void*)0,&l_2507,(void*)0,(void*)0}};
            uint8_t **l_2545 = (void*)0;
            int16_t l_2647 = 0xBC96L;
            int i, j;
            for (g_1227 = 0; (g_1227 > 18); g_1227 = safe_add_func_int16_t_s_s_unsafe_macro/*17*//* ___SAFE__OP */(g_1227, 8))
            { /* block id: 1168 */
                int64_t l_2380[5][2][6] = {{{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L},{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L}},{{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L},{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L}},{{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L},{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L}},{{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L},{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L}},{{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L},{0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L,0x38A89A34895A382BLL,0x38A89A34895A382BLL,1L}}};
                int32_t l_2382 = (-7L);
                int8_t *l_2390 = &l_19;
                uint64_t l_2399 = 0x6712B9C9078721B7LL;
                int32_t l_2412 = 0xC4C40DF8L;
                int32_t l_2416[5][6][2] = {{{0xD14633AFL,0x17F859FEL},{0x0B32BABBL,0x0B32BABBL},{0x0B32BABBL,0x17F859FEL},{0xD14633AFL,1L},{0x17F859FEL,1L},{0xD14633AFL,0x17F859FEL}},{{0x0B32BABBL,0x0B32BABBL},{0x0B32BABBL,0x17F859FEL},{0xD14633AFL,1L},{0x17F859FEL,1L},{0xD14633AFL,0x17F859FEL},{0x0B32BABBL,0x0B32BABBL}},{{0x0B32BABBL,0x17F859FEL},{0xD14633AFL,1L},{0x17F859FEL,1L},{0xD14633AFL,0x17F859FEL},{0x0B32BABBL,0x0B32BABBL},{0x0B32BABBL,0x17F859FEL}},{{0xD14633AFL,1L},{0x17F859FEL,1L},{0xD14633AFL,0x17F859FEL},{0x0B32BABBL,0x0B32BABBL},{0x0B32BABBL,0x17F859FEL},{0xD14633AFL,1L}},{{0x17F859FEL,1L},{0xD14633AFL,0x17F859FEL},{0x0B32BABBL,0x0B32BABBL},{0x0B32BABBL,0x17F859FEL},{0xD14633AFL,1L},{0x17F859FEL,1L}}};
                int8_t **l_2451 = &g_2389[2][2];
                int i, j, k;
                for (g_121 = (-4); (g_121 >= 16); g_121 = safe_add_func_uint32_t_u_u_unsafe_macro/*18*//* ___SAFE__OP */(g_121, 1))
                { /* block id: 1171 */
                    if (l_2371)
                        break;
                }
                for (g_745 = 11; (g_745 > (-27)); g_745--)
                { /* block id: 1176 */
                    int32_t *l_2374 = &l_2325;
                    int32_t *l_2375 = &g_178;
                    int32_t *l_2376 = &g_51[4][0];
                    int32_t l_2377 = (-5L);
                    int32_t *l_2378 = (void*)0;
                    int32_t *l_2379[7][4] = {{(void*)0,(void*)0,&l_2377,&g_51[0][6]},{(void*)0,&g_51[1][1],&g_46,&g_178},{&g_745,&g_51[2][7],&g_51[3][1],&g_46},{&l_2325,&g_51[2][7],&l_2325,&g_178},{&g_51[2][7],&g_51[1][1],&l_2325,&g_51[0][6]},{&g_51[0][6],&g_46,&g_745,&g_51[1][1]},{(void*)0,&g_745,&g_745,(void*)0}};
                    uint32_t l_2402 = 0x5F3D4096L;
                    const union U1 *l_2424 = &g_2425;
                    int i, j;
                    l_2385++;
                }
                (*g_242) = (((*l_2408) >= (((*l_2338) = ((l_2446[6] , (safe_sub_func_uint32_t_u_u_unsafe_macro/*19*//* ___SAFE__OP */((((l_2449 , (!((*g_1083) != (l_2452 = ((*l_2451) = (void*)0))))) > (safe_rshift_func_int16_t_s_u_unsafe_macro/*20*//* ___SAFE__OP */((((0x0FL || (safe_add_func_uint8_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */(0x50L, ((safe_add_func_int64_t_s_s_unsafe_macro/*22*//* ___SAFE__OP */(((((safe_div_func_uint64_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */((*g_1895), 0xCE1BA6882967925FLL)) == 0L) > (*l_2408)) & (*l_2408)), l_2380[2][1][4])) , 0xD1L)))) >= 1L) , l_2449), 7))) && (**g_2443)), (*l_2408)))) && 0xCFE5L)) , 2L)) <= (*l_2408));
            }
            for (g_1798 = 0; (g_1798 <= 0); g_1798 += 1)
            { /* block id: 1205 */
                union U1 l_2465 = {0xDFFF56B2L};
                uint32_t *l_2468 = &g_193;
                uint32_t *l_2471 = &g_1632[0][2];
                uint64_t ***l_2476[1][9][1] = {{{&l_2335[0][0]},{(void*)0},{&l_2335[0][0]},{(void*)0},{&l_2335[0][0]},{(void*)0},{&l_2335[0][0]},{(void*)0},{&l_2335[0][0]}}};
                uint32_t * const * const l_2483 = &g_228;
                uint32_t * const * const *l_2482 = &l_2483;
                uint32_t * const * const **l_2481 = &l_2482;
                uint32_t * const * const ***l_2480[10][2] = {{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481},{&l_2481,&l_2481}};
                uint32_t ****l_2504 = (void*)0;
                int8_t ** const * const * const l_2550 = (void*)0;
                int8_t ***l_2552 = &g_1083;
                int8_t ****l_2551[4] = {&l_2552,&l_2552,&l_2552,&l_2552};
                uint64_t l_2600 = 0xD1E79E1218BFEE1DLL;
                int32_t *l_2616 = (void*)0;
                int32_t l_2650[1];
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_2650[i] = 0x9B40E96FL;
                if ((safe_mul_func_int16_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */(0x5859L, (safe_sub_func_int8_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */((l_2465 , 0xA6L), (7UL | (((g_2477 = (((((*l_2471) |= ((*l_2468)++)) != (((*l_2338) = l_2415[g_1798]) | ((**g_2443) = (((*g_936) = l_2472) & l_19)))) <= ((safe_div_func_int8_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */(((l_2418[0] , (l_2415[g_1798] > 4UL)) , l_2418[0]), 251UL)) && (*l_2408))) , l_2475)) == (void*)0) > (*l_2408))))))))
                { /* block id: 1212 */
                    uint32_t l_2484 = 0UL;
                    int i;
                    l_2415[g_1798] |= (safe_add_func_int8_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */(((g_1746 , &g_1080) != ((((void*)0 != l_2480[4][0]) , ((*l_2468) = 0xF0DDD862L)) , (void*)0)), ((l_2484 != (l_2484 ^ (((safe_div_func_int32_t_s_s(((void*)0 != l_2475), (*l_2408))) , l_2446[1]) , 4294967295UL))) <= (*l_2408))));
                }
                else
                { /* block id: 1215 */
                    int32_t l_2487 = (-1L);
                    const int32_t l_2492 = 0x4A3CD5C0L;
                    int32_t l_2517[10] = {0x8DE25F4AL,0x6112F3D8L,0x8DE25F4AL,0x3D0DFF1FL,0x3D0DFF1FL,0x8DE25F4AL,0x6112F3D8L,0x8DE25F4AL,0x3D0DFF1FL,0x3D0DFF1FL};
                    uint32_t ****l_2538 = &g_1456;
                    int i;
                    if ((l_2465.f0 != l_2487))
                    { /* block id: 1216 */
                        return l_2418[0];
                    }
                    else
                    { /* block id: 1218 */
                        uint32_t *****l_2505[3];
                        int32_t *l_2509 = &g_722;
                        uint32_t ** const ***l_2516 = &g_2514;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2505[i] = &g_1455[3];
                        l_2415[g_1798] = (safe_rshift_func_int8_t_s_s_unsafe_macro/*29*//* ___SAFE__OP */((((*l_2326) &= (safe_sub_func_uint32_t_u_u_unsafe_macro/*30*//* ___SAFE__OP */(((*l_2471) = (l_2492 && (*l_2408))), l_2340[2][8]))) == (safe_add_func_uint64_t_u_u_unsafe_macro/*31*//* ___SAFE__OP */((safe_unary_minus_func_uint16_t_u_unsafe_macro/*32*//* ___SAFE__OP */(0x193BL)), (safe_mod_func_uint32_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((l_2517[6] = (safe_div_func_int16_t_s_s_unsafe_macro/*34*//* ___SAFE__OP */(((((*l_2516) = ((safe_lshift_func_int32_t_s_u_unsafe_macro/*35*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s_unsafe_macro/*36*//* ___SAFE__OP */(((((*l_2509) = ((g_1455[3] = l_2504) != l_2506[0][8])) , l_2465.f0) <= (**g_1810)), 44)), (((safe_mul_func_uint32_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */(((safe_rshift_func_uint32_t_u_u_unsafe_macro/*38*//* ___SAFE__OP */(l_2384, l_2418[1])) ^ (*l_2408)), 0x4E95A778L)) >= (*l_2408)) < 5UL))) , g_2514)) != (void*)0) < (-8L)), l_2487))), l_2415[g_1798]))))), (*l_2408)));
                        (*g_1869) &= (safe_lshift_func_int16_t_s_s_unsafe_macro/*39*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*40*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */((((safe_div_func_int16_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */(((l_2526 = l_2526) != l_2527), 0x4488L)) , (l_2487 != (safe_mod_func_uint16_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_s_unsafe_macro/*44*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*45*//* ___SAFE__OP */((((safe_div_func_int32_t_s_s_unsafe_macro/*46*//* ___SAFE__OP */((*l_2408), (safe_mul_func_uint16_t_u_u_unsafe_macro/*47*//* ___SAFE__OP */((l_2538 != ((~((*l_1761) = ((*l_2408) | (l_2517[5] , (safe_add_func_uint64_t_u_u_unsafe_macro/*48*//* ___SAFE__OP */(l_2465.f0, g_2191.f2)))))) , (void*)0)), g_1762)))) <= l_2492) <= (-1L)), l_2517[3])), (*l_2408))), g_163.f0)))) | l_2415[g_1798]), 254UL)), (*g_1895))), (*l_2408)));
                    }
                }
                if ((*g_1869))
                { /* block id: 1231 */
                    uint64_t *l_2546 = (void*)0;
                    int32_t l_2549 = 0xFC3BAB70L;
                    int8_t l_2564 = 0x03L;
                    uint64_t * const *l_2581[1][8][8] = {{{&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895,&l_2546,&g_2336},{&l_2526,&g_1895,&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895},{&l_2526,&g_2336,&l_2334,&g_2336,&l_2526,&l_2334,&l_2526,&g_2336},{&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895,&l_2546,&g_2336},{&l_2526,&g_1895,&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895},{&l_2526,&g_2336,&l_2334,&g_2336,&l_2526,&l_2334,&l_2526,&g_2336},{&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895,&l_2546,&g_2336},{&l_2526,&g_1895,&l_2546,&g_2336,&l_2546,&g_1895,&l_2526,&g_1895}}};
                    uint64_t * const **l_2580 = &l_2581[0][3][5];
                    uint32_t l_2587 = 18446744073709551615UL;
                    int i, j, k;
                    for (g_749 = 3; (g_749 >= 0); g_749 -= 1)
                    { /* block id: 1234 */
                        int64_t l_2573 = 0xAF81589649B0F136LL;
                        uint64_t * const ***l_2582[3];
                        int32_t *l_2588[6];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2582[i] = &l_2580;
                        for (i = 0; i < 6; i++)
                            l_2588[i] = &l_2419;
                        (*g_1869) = (((**g_2443) ^= (safe_div_func_uint16_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */(((l_2544[0] != l_2545) <= ((*g_1895) & (&g_546 != l_2546))), ((safe_add_func_uint32_t_u_u_unsafe_macro/*50*//* ___SAFE__OP */(l_2549, (((l_2549 && (l_2550 != l_2551[1])) , (*g_1895)) | 0UL))) ^ 0UL)))) || l_2465.f0);
                        (*l_2408) = l_2549;
                        l_2408 = l_2588[1];
                        (*g_1869) = 0xC94BCD38L;
                    }
                    return l_2340[2][6];
                }
                else
                { /* block id: 1244 */
                    uint32_t l_2604 = 0UL;
                    int32_t l_2607 = 2L;
                    uint32_t l_2608 = 0UL;
                    for (g_178 = 0; (g_178 <= 3); g_178 += 1)
                    { /* block id: 1247 */
                        uint32_t *****l_2591 = (void*)0;
                        (*g_2590) = l_2589;
                        (*l_2589) = ((*g_1869) &= (((l_2591 = &g_1455[4]) == &g_540) & (((safe_lshift_func_uint32_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */(((((*l_2338) |= ((l_2415[g_1798] && ((safe_add_func_uint32_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */(((*l_2408) == ((((****g_933) == (safe_lshift_func_int32_t_s_u_unsafe_macro/*53*//* ___SAFE__OP */((((safe_rshift_func_int64_t_s_u_unsafe_macro/*54*//* ___SAFE__OP */(l_2600, ((void*)0 == l_2601))) >= (((l_2604 = (*l_2589)) > (*l_2408)) <= (-1L))) != (-1L)), 14))) ^ l_2605[0][6][0]) & (*g_936))), l_2606)) , 0xC661L)) <= 1L)) > l_2607) != (*l_2589)), l_2600)) , 0UL) , (*g_1895))));
                        (*g_933) = &l_2544[0];
                    }
                    for (l_2417 = 2; (l_2417 >= 0); l_2417 -= 1)
                    { /* block id: 1258 */
                        int32_t l_2615 = 0x315E5368L;
                        if (l_2608)
                            break;
                        l_2615 = ((safe_div_func_int16_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */(((!(safe_rshift_func_int16_t_s_s_unsafe_macro/*56*//* ___SAFE__OP */(l_2608, 11))) & (safe_unary_minus_func_uint8_t_u_unsafe_macro/*57*//* ___SAFE__OP */(l_2604))), l_2600)) || (**g_1810));
                    }
                    if ((*l_2589))
                        continue;
                }
                (***l_2601) = l_2616;
                for (g_1227 = 0; (g_1227 <= 2); g_1227 += 1)
                { /* block id: 1267 */
                    const uint32_t l_2617[4] = {4294967295UL,4294967295UL,4294967295UL,4294967295UL};
                    int32_t ****l_2619 = &l_2618;
                    uint32_t l_2637 = 4294967295UL;
                    union U1 l_2643 = {4294967295UL};
                    uint16_t l_2646 = 0xA0BEL;
                    int32_t *l_2648 = (void*)0;
                    int32_t l_2652 = 0L;
                    uint32_t l_2653 = 8UL;
                    int i, j;
                }
            }
            (*g_813) = &l_2417;
            for (g_129 = (-5); (g_129 != (-15)); --g_129)
            { /* block id: 1291 */
                uint32_t l_2658 = 4294967287UL;
                l_2658 &= (*g_154);
            }
        }
    }
    else
    { /* block id: 1295 */
        uint8_t l_2659 = 254UL;
        uint32_t *l_2668 = &g_1632[0][2];
        int32_t l_2678 = 0xDB744107L;
        uint32_t l_2689 = 0x491DAC71L;
        int32_t l_2690 = 1L;
        int32_t l_2739 = 0x73EB253AL;
        int32_t *l_2742 = &l_2449;
        uint32_t l_2779 = 4294967293UL;
        uint64_t l_2789[5][10][5] = {{{0UL,5UL,0UL,0xFE51FAF23C2A23CDLL,1UL},{18446744073709551615UL,0xDC578FEEFDA7A2B8LL,0xB5C243B78E922B05LL,0xFB6A84C218DC699CLL,0x3253487A9EAEF116LL},{0UL,3UL,0xADEB01E8F50EF0BELL,0x056B016A5C129541LL,0x19B622B762A8108DLL},{0x2F86D2AAA82ABCE3LL,1UL,8UL,1UL,0xB2DC287DF7AE1EDFLL},{3UL,0x32511F79CA10BF80LL,0x5CF0533AA7591C82LL,0x32511F79CA10BF80LL,3UL},{18446744073709551615UL,1UL,18446744073709551611UL,0UL,0xC2E502B58AE295EDLL},{18446744073709551612UL,1UL,0x236E6EC06BAB4CB9LL,1UL,0UL},{1UL,0xCD21BF88E7E58850LL,1UL,1UL,0xC2E502B58AE295EDLL},{0xADEB01E8F50EF0BELL,1UL,0x32511F79CA10BF80LL,0x0CF77A7E307E1D84LL,3UL},{0xC2E502B58AE295EDLL,1UL,0x381C143AC572380BLL,1UL,0xB2DC287DF7AE1EDFLL}},{{0xEB5FF0C4BC85C25BLL,0x5DA51E374491D211LL,0x178D318B0A996760LL,18446744073709551607UL,0UL},{0xB5C243B78E922B05LL,1UL,1UL,0xB2DC287DF7AE1EDFLL,1UL},{0x5CF0533AA7591C82LL,18446744073709551612UL,1UL,1UL,18446744073709551612UL},{18446744073709551613UL,0x3253487A9EAEF116LL,0x3742BA918884BC43LL,18446744073709551615UL,0x59571920AA994DADLL},{1UL,0xD17820EE1B17D1A4LL,18446744073709551612UL,0xADEB01E8F50EF0BELL,0x0E6E1AA6101C2532LL},{5UL,0xDC578FEEFDA7A2B8LL,18446744073709551611UL,0x3D2A7A9ED1EC55BALL,0xB2DC287DF7AE1EDFLL},{1UL,18446744073709551607UL,18446744073709551615UL,0UL,3UL},{18446744073709551613UL,0UL,1UL,0xF62056F3D11DD643LL,0x95D040A9C7755B8CLL},{0x5CF0533AA7591C82LL,1UL,6UL,18446744073709551615UL,0xEB5FF0C4BC85C25BLL},{0xB5C243B78E922B05LL,7UL,18446744073709551615UL,1UL,1UL}},{{0UL,0x19B622B762A8108DLL,0UL,18446744073709551615UL,0UL},{18446744073709551611UL,18446744073709551611UL,18446744073709551607UL,0xEC725B967A1DD1EALL,0xDC578FEEFDA7A2B8LL},{0x178D318B0A996760LL,6UL,0x5DA51E374491D211LL,0xD17820EE1B17D1A4LL,0xE5EBB4567380B5EDLL},{8UL,0xCD21BF88E7E58850LL,0x381C143AC572380BLL,18446744073709551615UL,18446744073709551606UL},{18446744073709551607UL,6UL,0UL,0x178D318B0A996760LL,0xD17820EE1B17D1A4LL},{1UL,18446744073709551611UL,8UL,1UL,0UL},{0xADEB01E8F50EF0BELL,0x19B622B762A8108DLL,3UL,1UL,0UL},{0xF62056F3D11DD643LL,7UL,1UL,0x3253487A9EAEF116LL,0xEC725B967A1DD1EALL},{18446744073709551615UL,1UL,0x0CF77A7E307E1D84LL,0x5DA51E374491D211LL,0x5DA51E374491D211LL},{0xCD21BF88E7E58850LL,0UL,0xCD21BF88E7E58850LL,0x2351B7EC969EE36ELL,0x3D2A7A9ED1EC55BALL}},{{1UL,18446744073709551607UL,3UL,0x236E6EC06BAB4CB9LL,0x0CF77A7E307E1D84LL},{0x381C143AC572380BLL,0xDC578FEEFDA7A2B8LL,0xFB6A84C218DC699CLL,0x2F86D2AAA82ABCE3LL,18446744073709551613UL},{0xF00386451156650FLL,0xD17820EE1B17D1A4LL,3UL,0x0CF77A7E307E1D84LL,0x32511F79CA10BF80LL},{18446744073709551606UL,0x3253487A9EAEF116LL,0xCD21BF88E7E58850LL,0x3742BA918884BC43LL,0xC2E502B58AE295EDLL},{6UL,18446744073709551612UL,0x0CF77A7E307E1D84LL,18446744073709551615UL,18446744073709551607UL},{0x3D2A7A9ED1EC55BALL,1UL,1UL,18446744073709551613UL,0x9C50B83BAFBE0CA4LL},{0xD17820EE1B17D1A4LL,0x0CF77A7E307E1D84LL,3UL,0xF9BE0907646176BELL,6UL},{0x95D040A9C7755B8CLL,8UL,8UL,0x95D040A9C7755B8CLL,1UL},{0x0CF77A7E307E1D84LL,18446744073709551615UL,0UL,18446744073709551612UL,1UL},{0x59571920AA994DADLL,0UL,0x381C143AC572380BLL,0UL,1UL}},{{0UL,1UL,0x5DA51E374491D211LL,18446744073709551612UL,0xF00386451156650FLL},{1UL,0xFB6A84C218DC699CLL,18446744073709551607UL,0x95D040A9C7755B8CLL,0xADE01FFFF71F8474LL},{0x745D2DE04A960CE1LL,1UL,0UL,0xF9BE0907646176BELL,18446744073709551615UL},{18446744073709551607UL,18446744073709551615UL,18446744073709551615UL,18446744073709551613UL,0x381C143AC572380BLL},{18446744073709551615UL,0x169E90D0E747ACFCLL,6UL,18446744073709551615UL,0xE1C318F515E3A622LL},{18446744073709551615UL,0x3742BA918884BC43LL,1UL,0x3742BA918884BC43LL,18446744073709551615UL},{5UL,0x236E6EC06BAB4CB9LL,18446744073709551615UL,0x0CF77A7E307E1D84LL,0UL},{1UL,0xB2DC287DF7AE1EDFLL,18446744073709551611UL,0x2F86D2AAA82ABCE3LL,0UL},{0xFE51FAF23C2A23CDLL,1UL,18446744073709551612UL,0x236E6EC06BAB4CB9LL,0UL},{1UL,0xF62056F3D11DD643LL,0xB2DC287DF7AE1EDFLL,0xB5C243B78E922B05LL,18446744073709551615UL}}};
        uint8_t l_2795 = 0x8BL;
        int32_t *l_2800 = &l_2449;
        uint32_t l_2817 = 0xD51C3837L;
        union U1 **l_2834 = &g_732;
        uint16_t l_2862 = 65528UL;
        int i, j, k;
        (*g_1869) &= ((***l_2623) == ((*l_2668) = (l_2659 || ((0x9C3DE7CAL > (safe_mod_func_uint16_t_u_u_unsafe_macro/*58*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_s_unsafe_macro/*59*//* ___SAFE__OP */((*g_1895), ((safe_rshift_func_uint32_t_u_s_unsafe_macro/*60*//* ___SAFE__OP */(0x2F36D312L, 2)) ^ (((*g_1895) <= l_2659) && (((~((+((g_203[6] , (((**g_1810) , 4294967295UL) , 0x7FAAD69023B96603LL)) >= g_81)) & 18446744073709551612UL)) , 0x9A9AA515L) >= l_2659))))) == 0xD3F8L), l_2659))) <= g_518.f0))));
        (*g_1869) = (-4L);
        for (g_178 = 0; (g_178 < (-12)); --g_178)
        { /* block id: 1301 */
            int8_t l_2671[6] = {9L,9L,9L,9L,9L,9L};
            int8_t *l_2679 = &l_19;
            int32_t *l_2691 = &g_51[0][6];
            uint8_t l_2696 = 0UL;
            union U1 l_2715 = {0x6A6ECA67L};
            int32_t l_2722 = (-1L);
            uint8_t l_2738 = 6UL;
            int32_t l_2751 = (-8L);
            const int32_t * const *l_2815 = &g_2732;
            const int32_t * const **l_2814 = &l_2815;
            const int32_t * const ***l_2813 = &l_2814;
            const int32_t * const ****l_2812 = &l_2813;
            const int32_t * const ****l_2816[4];
            uint32_t l_2840[3][8] = {{18446744073709551615UL,18446744073709551609UL,18446744073709551609UL,18446744073709551615UL,0xAB465A8CL,18446744073709551615UL,18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,0xAB465A8CL,0x5876E867L,0x5876E867L,0xAB465A8CL,18446744073709551609UL,0xAB465A8CL,0x5876E867L},{18446744073709551615UL,0xAB465A8CL,18446744073709551615UL,18446744073709551609UL,18446744073709551609UL,18446744073709551615UL,0xAB465A8CL,18446744073709551615UL}};
            uint16_t l_2841[3];
            int i, j;
            for (i = 0; i < 4; i++)
                l_2816[i] = &l_2813;
            for (i = 0; i < 3; i++)
                l_2841[i] = 0xCCB1L;
        }
    }
    for (g_2353 = 0; (g_2353 > (-7)); g_2353 = safe_sub_func_int64_t_s_s_unsafe_macro/*61*//* ___SAFE__OP */(g_2353, 8))
    { /* block id: 1387 */
        int8_t l_2874 = 0x32L;
        int32_t l_2882 = 1L;
        int32_t l_2896 = 0xA6D13835L;
        uint8_t **l_2907 = &g_936;
        uint8_t ***l_2906[7];
        uint8_t ****l_2905 = &l_2906[6];
        uint8_t *****l_2976 = &l_2911;
        uint8_t *l_3002 = &l_2405;
        uint32_t * const ****l_3007 = (void*)0;
        int32_t l_3065[1][9] = {{0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L,0x87A71238L}};
        union U1 l_3080 = {4294967292UL};
        int64_t l_3085[2];
        uint8_t ** const * const l_3092 = (void*)0;
        uint8_t ** const * const *l_3091 = &l_3092;
        uint8_t ** const * const **l_3090 = &l_3091;
        union U1 **l_3093 = &g_732;
        int i, j;
        for (i = 0; i < 7; i++)
            l_2906[i] = &l_2907;
        for (i = 0; i < 2; i++)
            l_3085[i] = 0L;
    }
    (*l_3096) = l_3095[7][6][1];
    return (**g_1810);
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_1697 g_518.f0 g_1798 g_1810 g_1813 g_1877 g_813 g_936 g_121 g_206 g_177 g_178 g_1811 g_1812 g_546 g_125 g_1869 g_50 g_193 g_287 g_242 g_1079.f1 g_241 g_1895 g_1915.f0 g_228 g_1525 g_154 g_745 g_993 g_331 g_1376 g_933 g_934 g_935 g_2068 g_1083 g_31 g_1652 g_1079 g_987 g_32 g_733.f0 g_286 g_2175 g_2191 g_752 g_723 g_2242 g_541 g_542 g_559 g_129 g_1809 g_1214 g_1477
 * writes: g_46 g_193 g_1697 g_752 g_1477 g_1798 g_32 g_1809 g_559 g_1810 g_154 g_121 g_745 g_1762 g_206 g_723 g_2011 g_129 g_178 g_31 g_1214 g_204 g_241 g_125 g_1456 g_2324
 */
static int32_t  func_2(uint8_t  p_3, int8_t * p_4, int8_t * p_5, int8_t  p_6, const uint32_t  p_7)
{ /* block id: 877 */
    int32_t *l_1769 = &g_46;
    int32_t *l_1770[3][2][5] = {{{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745},{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745}},{{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745},{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745}},{{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745},{&g_745,&g_745,&g_51[0][6],&g_51[0][6],&g_745}}};
    uint16_t l_1771 = 8UL;
    uint64_t *l_1774[2];
    int16_t l_1775 = 0xB455L;
    uint16_t *l_1781[4][9] = {{&g_752[5][4][0],&g_752[5][4][0],&g_752[5][2][0],&g_752[3][0][3],&g_752[5][4][0],&g_1697,&g_752[5][4][0],&g_752[3][0][3],&g_752[5][2][0]},{&g_752[5][4][0],&g_752[5][4][0],&g_752[5][4][0],&l_1771,&g_1477,&g_752[5][4][0],&g_752[5][2][0],&g_752[5][4][0],&g_1477},{&g_752[5][4][0],&g_752[5][4][0],&g_752[5][4][0],&g_752[5][4][0],&l_1771,&g_1477,&g_752[5][4][0],&g_752[5][2][0],&g_752[5][4][0]},{&g_752[5][2][0],&g_752[5][4][0],&g_752[5][4][0],&g_752[5][4][0],&g_752[5][4][0],&g_752[5][2][0],&g_752[3][0][3],&g_752[5][4][0],&g_1697}};
    uint16_t ** const l_1780 = &l_1781[2][5];
    uint16_t **l_1783 = &l_1781[1][1];
    uint16_t ***l_1782 = &l_1783;
    int32_t l_1799 = 0x026147D2L;
    int32_t **l_1808 = &l_1770[1][1][4];
    int32_t ***l_1807[4][9][7] = {{{&l_1808,(void*)0,(void*)0,(void*)0,&l_1808,&l_1808,&l_1808},{(void*)0,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,(void*)0},{&l_1808,&l_1808,&l_1808,(void*)0,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,(void*)0},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,(void*)0},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808}},{{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808}},{{&l_1808,(void*)0,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,(void*)0,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,(void*)0,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,(void*)0,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808}},{{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808},{&l_1808,(void*)0,(void*)0,&l_1808,&l_1808,&l_1808,&l_1808}}};
    uint8_t ***l_1832 = (void*)0;
    union U1 *l_1960[10][2][2] = {{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0}}};
    uint32_t l_1961 = 18446744073709551608UL;
    int16_t l_1994 = 0xD95EL;
    int32_t l_2003 = (-3L);
    const int32_t l_2056 = 0xE4E412C2L;
    uint32_t l_2075 = 0x282DC260L;
    struct S0 **l_2109 = &g_1877;
    uint32_t l_2125 = 3UL;
    uint16_t l_2139[10] = {0x9114L,0x9114L,0x9114L,0x9114L,0x9114L,0x9114L,0x9114L,0x9114L,0x9114L,0x9114L};
    uint32_t l_2149 = 2UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1774[i] = &g_546;
lbl_2120:
    ++l_1771;
lbl_2128:
    (*l_1769) = ((l_1775 = p_3) | (((((safe_lshift_func_int16_t_s_s((*l_1769), 1)) , l_1780) != ((*l_1782) = &l_1781[1][0])) && (((safe_rshift_func_uint16_t_u_s_unsafe_macro/*63*//* ___SAFE__OP */(p_6, ((((safe_mod_func_int8_t_s_s_unsafe_macro/*64*//* ___SAFE__OP */(((*l_1769) && ((*l_1769) ^ (safe_mul_func_int64_t_s_s_unsafe_macro/*65*//* ___SAFE__OP */(p_7, (safe_rshift_func_int16_t_s_s(0xABF4L, 4)))))), 1UL)) ^ p_6) , 0x9BF0L) || g_1697))) || (*l_1769)) >= g_518.f0)) < p_3));
    for (g_193 = 0; (g_193 <= 5); g_193 += 1)
    { /* block id: 884 */
        int8_t *l_1802 = &g_32;
        int32_t l_1818[9][6] = {{5L,(-2L),(-4L),5L,(-4L),(-2L)},{(-1L),(-2L),0x6F74F336L,(-1L),(-4L),(-4L)},{0xEE1DD500L,(-2L),(-2L),0xEE1DD500L,(-4L),0x6F74F336L},{5L,(-2L),(-4L),5L,(-4L),(-2L)},{(-1L),(-2L),0x6F74F336L,(-1L),(-4L),(-4L)},{0xEE1DD500L,(-2L),(-2L),0xEE1DD500L,(-4L),0x6F74F336L},{5L,(-2L),(-4L),5L,(-4L),(-2L)},{(-1L),(-2L),0x6F74F336L,(-1L),(-4L),(-4L)},{0xEE1DD500L,(-2L),(-2L),0xEE1DD500L,(-4L),0x6F74F336L}};
        union U1 l_1845 = {0xDC1BA832L};
        uint8_t **l_1852 = &g_936;
        uint32_t **** const *l_1855 = &g_1455[6];
        union U1 l_1870[8][8][2] = {{{{0x6AFE7967L},{4294967295UL}},{{0UL},{9UL}},{{0x93F66BFCL},{1UL}},{{5UL},{8UL}},{{4UL},{0x6BD91664L}},{{3UL},{0x9C863DBBL}},{{9UL},{0x9543913CL}},{{4294967294UL},{0x71D0B38EL}}},{{{0x1D9B7D7EL},{0x56D1B546L}},{{0UL},{4294967295UL}},{{1UL},{4294967295UL}},{{0UL},{0x56D1B546L}},{{0x1D9B7D7EL},{0x71D0B38EL}},{{4294967294UL},{0x9543913CL}},{{9UL},{0x9C863DBBL}},{{3UL},{0x6BD91664L}}},{{{4UL},{8UL}},{{5UL},{1UL}},{{0x93F66BFCL},{9UL}},{{0UL},{4294967295UL}},{{0x6AFE7967L},{1UL}},{{0x393FC312L},{8UL}},{{0x00F5624FL},{0x6AFE7967L}},{{0x9C863DBBL},{0x7F1A7ACCL}}},{{{0x71D0B38EL},{8UL}},{{0x2FF7FDC7L},{0x2FF7FDC7L}},{{9UL},{0x7286A018L}},{{4294967295UL},{0x1D9B7D7EL}},{{0x1D4D6021L},{0UL}},{{0x3D133DA9L},{0x1D4D6021L}},{{8UL},{4UL}},{{8UL},{0x1D4D6021L}}},{{{0x3D133DA9L},{0UL}},{{0x1D4D6021L},{0x1D9B7D7EL}},{{4294967295UL},{0x7286A018L}},{{9UL},{0x2FF7FDC7L}},{{0x2FF7FDC7L},{8UL}},{{0x71D0B38EL},{0x7F1A7ACCL}},{{0x9C863DBBL},{0x6AFE7967L}},{{0x00F5624FL},{8UL}}},{{{0x393FC312L},{1UL}},{{0x6AFE7967L},{4294967295UL}},{{0UL},{9UL}},{{0x93F66BFCL},{1UL}},{{5UL},{8UL}},{{4UL},{0x6BD91664L}},{{3UL},{0x9C863DBBL}},{{9UL},{0x9543913CL}}},{{{4294967294UL},{0x71D0B38EL}},{{0x1D9B7D7EL},{0x56D1B546L}},{{0UL},{4294967295UL}},{{1UL},{4294967295UL}},{{0UL},{0x56D1B546L}},{{0x9C863DBBL},{0x3D133DA9L}},{{9UL},{0x393FC312L}},{{0xC9082420L},{8UL}}},{{{4294967295UL},{9UL}},{{0x1D4D6021L},{0x56D1B546L}},{{4294967294UL},{0UL}},{{0UL},{0xC9082420L}},{{1UL},{8UL}},{{0xFEC743BFL},{0UL}},{{0UL},{4UL}},{{4294967293UL},{0xFEC743BFL}}}};
        union U1 **l_1873 = &g_732;
        uint8_t l_1878 = 0xAEL;
        struct S0 **l_1890 = &g_1877;
        int64_t l_1921 = 0x1406CF8E795EBBDELL;
        uint16_t l_1925 = 0x9738L;
        uint16_t l_1952 = 0xE949L;
        int32_t *l_2014 = &g_46;
        int32_t ***l_2055[7] = {&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808,&l_1808};
        uint16_t l_2106[8];
        uint8_t *****l_2166[10];
        int8_t ***l_2214 = (void*)0;
        uint8_t l_2221[1][7] = {{0x21L,0xC3L,0xC3L,0x21L,0xC3L,0xC3L,0x21L}};
        int32_t l_2222 = 0L;
        int32_t **l_2259 = &g_1634[2];
        int32_t l_2289 = (-1L);
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2106[i] = 0x2ECDL;
        for (i = 0; i < 10; i++)
            l_2166[i] = &g_1080;
        if ((g_1809 = (safe_add_func_uint16_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */(((**l_1780) = 65530UL), (safe_mod_func_uint16_t_u_u((g_1798 ^= (safe_rshift_func_uint16_t_u_u_unsafe_macro/*69*//* ___SAFE__OP */((0x657F1B34L && 4294967295UL), 14))), ((((l_1799 = ((*l_1769) = p_6)) , (void*)0) != ((safe_mul_func_int8_t_s_s_unsafe_macro/*70*//* ___SAFE__OP */(((*l_1802) = ((*p_5) = 0x82L)), (safe_div_func_uint16_t_u_u_unsafe_macro/*71*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*72*//* ___SAFE__OP */((((void*)0 == l_1807[2][6][3]) , ((-1L) < 0UL)), p_6)), p_3)))) , (void*)0)) & p_6)))))))
        { /* block id: 892 */
            int32_t *l_1819[3][8] = {{(void*)0,(void*)0,(void*)0,&l_1799,(void*)0,(void*)0,(void*)0,(void*)0},{&g_51[0][6],(void*)0,(void*)0,&g_51[0][6],&l_1799,&g_51[0][6],(void*)0,(void*)0},{(void*)0,&l_1799,&l_1799,&l_1799,&l_1799,(void*)0,&l_1799,&l_1799}};
            int8_t **l_1829 = (void*)0;
            union U1 l_1854 = {0UL};
            int32_t l_1871 = 0x74F11AEAL;
            uint32_t l_1874 = 18446744073709551606UL;
            int8_t l_1906 = 0x8EL;
            int8_t l_1908[5];
            int32_t l_1909[4] = {0xC2036C9EL,0xC2036C9EL,0xC2036C9EL,0xC2036C9EL};
            uint8_t l_1910[9][6][4] = {{{0x7CL,0x46L,0xF6L,0x7CL},{251UL,0x3CL,255UL,0x46L},{0x3CL,0x41L,255UL,255UL},{251UL,251UL,0xF6L,247UL},{0x7CL,8UL,0xCBL,0x46L},{0xCBL,0x46L,0x3CL,0xCBL}},{{251UL,0x46L,5UL,0x46L},{0x46L,8UL,255UL,247UL},{0x63L,251UL,0x3CL,255UL},{0x7CL,0x41L,2UL,0x46L},{0x7CL,0x3CL,0x3CL,0x7CL},{0x63L,0x46L,255UL,0x3CL}},{{0x46L,0x41L,5UL,247UL},{251UL,0x63L,0x3CL,247UL},{0xCBL,0x41L,0xCBL,0x3CL},{0x7CL,0x46L,0xF6L,0x7CL},{251UL,0x3CL,255UL,0x46L},{0x3CL,0x41L,255UL,255UL}},{{251UL,251UL,0xF6L,247UL},{0x7CL,8UL,0xCBL,0x46L},{0xCBL,0x46L,0x3CL,0xCBL},{251UL,0x46L,5UL,0x46L},{0x46L,8UL,255UL,247UL},{0x63L,251UL,0x3CL,255UL}},{{0x7CL,0x41L,2UL,0x46L},{0x7CL,0x3CL,0x3CL,0x7CL},{0x63L,0x46L,255UL,0x3CL},{0x46L,0x41L,5UL,247UL},{251UL,0x63L,0x3CL,247UL},{0xCBL,0x41L,0xCBL,0x3CL}},{{0x7CL,0x46L,0xF6L,0x7CL},{251UL,0x3CL,255UL,0xCBL},{2UL,0x63L,7UL,7UL},{0x3CL,0x3CL,0x7CL,8UL},{255UL,255UL,5UL,0xCBL},{5UL,0xCBL,2UL,5UL}},{{0x3CL,0xCBL,0x41L,0xCBL},{0xCBL,255UL,7UL,8UL},{0xF6L,0x3CL,2UL,7UL},{255UL,0x63L,247UL,0xCBL},{255UL,2UL,2UL,255UL},{0xF6L,0xCBL,7UL,2UL}},{{0xCBL,0x63L,0x41L,8UL},{0x3CL,0xF6L,2UL,8UL},{5UL,0x63L,5UL,2UL},{255UL,0xCBL,0x7CL,255UL},{0x3CL,2UL,7UL,0xCBL},{2UL,0x63L,7UL,7UL}},{{0x3CL,0x3CL,0x7CL,8UL},{255UL,255UL,5UL,0xCBL},{5UL,0xCBL,2UL,5UL},{0x3CL,0xCBL,0x41L,0xCBL},{0xCBL,255UL,7UL,8UL},{0xF6L,0x3CL,2UL,7UL}}};
            uint64_t l_1913 = 18446744073709551612UL;
            struct S0 *l_1914 = &g_1915;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_1908[i] = 0x02L;
            for (g_559 = 0; (g_559 <= 8); g_559 += 1)
            { /* block id: 895 */
                (*g_1813) = g_1810;
                return p_7;
            }
            for (g_559 = 1; (g_559 <= 4); g_559 += 1)
            { /* block id: 901 */
                int16_t l_1824 = 0x8399L;
                int32_t l_1834 = 0x58266EFEL;
                int8_t *l_1853 = &g_659[2][0][0];
                uint64_t *l_1891 = &g_546;
                int32_t l_1899 = 0L;
                int32_t l_1900 = (-1L);
                int32_t l_1901 = 0L;
                int32_t l_1902 = 4L;
                int32_t l_1903 = 1L;
                int32_t l_1904 = (-1L);
                int32_t l_1905[4];
                int64_t l_1907 = (-1L);
                int i;
                for (i = 0; i < 4; i++)
                    l_1905[i] = 1L;
            }
            l_1914 = (*l_1890);
            if (l_1818[1][3])
                continue;
        }
        else
        { /* block id: 942 */
            uint32_t l_1916 = 4UL;
            int32_t l_1919 = 0L;
            int32_t l_1920 = 0xD372127BL;
            int32_t l_1922 = 0x989084BEL;
            int32_t l_1923[6];
            int32_t l_1943 = 0x744FFE2CL;
            uint32_t **l_1992 = &g_228;
            int64_t l_1996 = (-7L);
            int32_t *****l_2010 = &g_1626;
            int i;
            for (i = 0; i < 6; i++)
                l_1923[i] = 0xB62FE02DL;
            --l_1916;
            l_1925--;
            for (g_559 = 0; (g_559 <= 3); g_559 += 1)
            { /* block id: 947 */
                uint16_t l_1944 = 1UL;
                int8_t *** const l_1957 = &g_1083;
                int32_t l_1968 = 0x84821990L;
                uint16_t ***l_1979 = (void*)0;
                uint32_t **l_1993 = (void*)0;
                int32_t l_1997[4][2];
                int32_t ***l_2036 = &g_1633[2][4][1];
                int i, j;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_1997[i][j] = 4L;
                }
                (*g_813) = ((*l_1808) = &l_1920);
                if ((((safe_div_func_int32_t_s_s_unsafe_macro/*73*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*74*//* ___SAFE__OP */(((0xBFEF355695956EB1LL & (safe_sub_func_uint8_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */(((((0x62L && (safe_mul_func_int8_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*77*//* ___SAFE__OP */(((~(*g_936)) != 0L), 7)), (safe_div_func_uint8_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*79*//* ___SAFE__OP */(g_206, ((***l_1782) = p_7))), 0x7DL))))) ^ (*l_1769)) < (*g_177)) != 0xE54EL), 2L))) > l_1921), l_1943)), 0x1DA96D9EL)) , l_1944) < p_7))
                { /* block id: 951 */
                    int32_t *l_1945 = &l_1922;
                    (*l_1808) = l_1945;
                }
                else
                { /* block id: 953 */
                    (*l_1769) &= p_7;
                }
                (*g_1869) = (safe_lshift_func_uint16_t_u_u_unsafe_macro/*80*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*81*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*82*//* ___SAFE__OP */(l_1952, 16)), (safe_rshift_func_uint16_t_u_s_unsafe_macro/*83*//* ___SAFE__OP */(((l_1957 == (void*)0) <= ((safe_mul_func_uint16_t_u_u_unsafe_macro/*84*//* ___SAFE__OP */((((-1L) & (l_1960[1][1][1] == ((((((l_1961 , ((0x3A13A1BAL && l_1923[1]) < ((((*g_936) = (safe_div_func_uint32_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(p_3, (*p_4))), 8L))) > 0xB3L) == (-1L)))) > 0xDEFEL) >= (*p_4)) != (***g_1813)) <= g_546) , (void*)0))) || 5L), g_125[1])) > l_1944)), l_1944)))) , p_6), l_1923[1]));
                for (l_1771 = 0; (l_1771 <= 1); l_1771 += 1)
                { /* block id: 960 */
                    uint32_t l_1970 = 18446744073709551615UL;
                    for (g_1762 = 0; (g_1762 <= 5); g_1762 += 1)
                    { /* block id: 963 */
                        int32_t l_1969 = 0x800570B1L;
                        int i, j, k;
                        l_1818[(l_1771 + 3)][g_193] = (safe_rshift_func_uint64_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */(g_50[l_1771][l_1771][(l_1771 + 2)], 37));
                        l_1970++;
                    }
                    for (g_745 = 4; (g_745 >= 0); g_745 -= 1)
                    { /* block id: 969 */
                        int i;
                        (*l_1808) = g_287[l_1771];
                        if (l_1916)
                            break;
                    }
                }
                for (l_1952 = 0; (l_1952 <= 5); l_1952 += 1)
                { /* block id: 976 */
                    uint32_t l_1973 = 2UL;
                    int32_t l_1974 = 5L;
                    int16_t *l_1991 = &g_723;
                    int16_t **l_1995 = &l_1991;
                    int32_t l_1998 = (-9L);
                    int32_t l_1999 = 0x45D162E7L;
                    int32_t l_2000 = 7L;
                    int32_t l_2001[9][7] = {{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L},{0L,0x0F595309L,0x0E1B72D4L,0x0E1B72D4L,0x0F595309L,0L,0L}};
                    uint16_t l_2007 = 0x3F89L;
                    int32_t ** const *l_2035[4][4][8] = {{{&g_1633[6][3][1],&g_1633[4][4][1],&g_1633[2][4][1],&g_1633[4][4][1],&g_1633[6][3][1],&g_1633[2][4][1],&g_1633[4][4][1],&g_1633[2][4][1]},{&g_1633[6][7][3],&g_1633[6][3][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[4][4][1],&g_1633[6][7][3],&g_1633[6][7][3],&g_1633[4][4][1]},{(void*)0,&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0,(void*)0,&g_1633[4][4][1],&g_1633[2][4][1]},{&g_1633[4][4][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1]}},{{(void*)0,&g_1633[2][4][1],(void*)0,&g_1633[2][4][1],&g_1633[4][4][1],(void*)0,&g_1633[2][4][1],&g_1633[2][4][1]},{&g_1633[2][4][1],(void*)0,(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0},{&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0,(void*)0,&g_1633[4][4][1],&g_1633[2][4][1],(void*)0},{&g_1633[2][4][1],(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[6][7][3],&g_1633[2][4][1],(void*)0,(void*)0}},{{(void*)0,&g_1633[2][4][1],(void*)0,(void*)0,&g_1633[2][4][1],(void*)0,&g_1633[6][7][3],(void*)0},{&g_1633[2][4][1],&g_1633[6][7][3],&g_1633[2][4][1],(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[6][7][3],&g_1633[2][4][1]},{&g_1633[2][4][1],(void*)0,(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0},{&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[2][4][1],(void*)0}},{{&g_1633[2][4][1],(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[6][7][3],&g_1633[2][4][1],(void*)0,(void*)0},{(void*)0,&g_1633[6][7][3],(void*)0,(void*)0,&g_1633[6][7][3],(void*)0,&g_1633[2][4][1],(void*)0},{&g_1633[2][4][1],&g_1633[2][4][1],&g_1633[2][4][1],(void*)0,(void*)0,&g_1633[2][4][1],&g_1633[6][7][3],&g_1633[2][4][1]},{&g_1633[2][4][1],(void*)0,&g_1633[2][4][1],(void*)0,&g_1633[2][4][1],&g_1633[4][4][1],(void*)0,(void*)0}}};
                    uint32_t l_2037 = 0xDAAFD55BL;
                    int i, j, k;
                    for (g_121 = 0; (g_121 <= 3); g_121 += 1)
                    { /* block id: 979 */
                        (*l_1769) = (l_1974 ^= l_1973);
                        if ((*g_242))
                            continue;
                    }
                    if (((safe_mul_func_int32_t_s_s_unsafe_macro/*88*//* ___SAFE__OP */(l_1845.f0, ((safe_sub_func_uint32_t_u_u_unsafe_macro/*89*//* ___SAFE__OP */(((((((g_1079.f1 >= p_3) | ((l_1922 ^= ((((((void*)0 == l_1979) >= (0x6BL <= (((safe_div_func_int32_t_s_s_unsafe_macro/*90*//* ___SAFE__OP */((((safe_sub_func_uint32_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */((((safe_unary_minus_func_uint32_t_u_unsafe_macro/*92*//* ___SAFE__OP */(((l_1818[1][1] = (((*l_1995) = ((((safe_mul_func_int64_t_s_s_unsafe_macro/*93*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */(((g_241 , (((*g_1895) ^= l_1870[3][2][0].f0) & ((((((*l_1991) = (safe_lshift_func_int8_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */(((((void*)0 == &g_1455[4]) , p_3) & 65535UL), l_1920))) > g_1915.f0) , l_1992) != l_1993) & l_1968))) != 0x2B452729CF19D0DALL), p_7)), (-7L))) , l_1994) >= 0x44L) , l_1991)) != &g_204)) | p_3))) || 1L) ^ (*p_5)), p_7)) ^ l_1952) | p_3), p_6)) <= g_46) <= 18446744073709551615UL))) , (*l_1992)) != (void*)0) == p_7)) , (*p_4))) != 255UL) ^ p_3) , 7L) <= p_3), l_1845.f0)) & 0x922920AFL))) <= 18446744073709551607UL))
                    { /* block id: 989 */
                        int8_t l_2002 = 0x87L;
                        int32_t l_2004 = 0x9C6236ADL;
                        int32_t l_2005 = (-9L);
                        int32_t l_2006 = 1L;
                        ++l_2007;
                        (*l_1769) = ((g_2011[0][2] = l_2010) == l_2010);
                    }
                    else
                    { /* block id: 993 */
                        if (l_1818[1][1])
                            break;
                        (*l_1808) = (*g_1525);
                        (*g_1869) |= p_3;
                        (*g_331) = (g_993[0][0][2] , l_2014);
                    }
                    l_1997[0][0] = (**g_1376);
                    for (l_1922 = 0; (l_1922 <= 5); l_1922 += 1)
                    { /* block id: 1002 */
                        uint32_t ***l_2027 = &l_1993;
                        int32_t l_2034 = 0x35B68906L;
                        int i, j, k;
                        (*l_1808) = &l_1998;
                    }
                }
            }
        }
        if (((*l_1769) = (-5L)))
        { /* block id: 1010 */
            uint16_t l_2043 = 1UL;
            int64_t *l_2057 = &l_1921;
            uint16_t ***l_2074 = &l_1783;
            int32_t *l_2081[8][5][6] = {{{&l_1799,(void*)0,&g_46,&g_178,&g_178,(void*)0},{&g_745,(void*)0,&l_1799,&g_178,&g_51[0][6],&g_178},{&g_178,&g_46,(void*)0,&g_46,&l_1799,(void*)0},{&g_46,&g_745,&g_745,(void*)0,&g_51[2][0],&g_46},{&g_51[0][5],&g_178,&g_51[3][0],&g_46,&l_1818[6][5],(void*)0}},{{&l_1818[1][1],&g_178,&g_51[0][6],&g_745,&g_51[0][5],&g_51[0][6]},{&g_51[0][6],&l_1799,&l_1818[1][1],&g_51[0][5],&g_178,&g_178},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1799,&l_1818[6][5]},{(void*)0,&l_1799,&g_745,(void*)0,&l_1799,&g_745},{&g_51[0][6],&g_51[0][6],&g_745,&g_178,&l_1799,&g_745}},{{(void*)0,&l_1799,(void*)0,&l_1799,&l_1799,&l_1818[2][2]},{&l_1818[1][1],(void*)0,&g_51[0][6],&l_1818[0][0],&g_178,(void*)0},{&g_46,&l_1799,(void*)0,&g_745,&g_51[0][5],&g_46},{&l_1799,&g_178,&g_46,&g_178,&l_1818[6][5],&l_1799},{(void*)0,&g_178,&g_51[0][6],&g_46,&g_51[2][0],&l_1818[0][2]}},{{(void*)0,&g_745,&g_745,(void*)0,&l_1799,(void*)0},{&g_46,&g_46,&g_46,&g_46,&g_51[0][6],&g_46},{&g_178,&l_1799,&l_1799,&g_46,&g_46,&l_1818[2][5]},{&g_178,&g_46,(void*)0,&g_46,&g_178,(void*)0},{&g_178,(void*)0,&l_1818[2][2],(void*)0,&g_51[0][6],&g_745}},{{(void*)0,&l_1818[1][1],&l_1799,(void*)0,&g_745,&g_51[0][6]},{&g_178,(void*)0,&l_1818[2][5],&g_46,&l_1799,(void*)0},{&l_1799,&g_51[0][6],&l_1818[1][1],&g_178,&g_51[0][6],&g_745},{(void*)0,&l_1799,&g_51[2][0],&g_178,&g_46,&g_46},{&g_745,&g_745,&l_1818[1][1],&g_178,&g_178,&l_1818[1][1]}},{{&g_46,&g_46,&l_1818[6][5],&g_46,&g_745,&l_1818[2][2]},{&g_46,&g_51[0][6],&g_178,&l_1818[2][5],(void*)0,&l_1818[6][5]},{&g_178,&g_46,&g_178,&g_51[0][6],&g_46,&l_1818[2][2]},{&g_51[0][5],&g_51[0][6],&l_1818[6][5],&g_51[0][6],&g_745,&l_1818[1][1]},{&g_51[0][6],&g_745,&l_1818[1][1],&l_1799,(void*)0,&g_46}},{{&g_51[0][6],&l_1799,&g_51[2][0],(void*)0,&l_1818[0][0],&g_745},{&l_1818[0][0],&g_51[2][0],&l_1818[1][1],&g_745,&g_178,(void*)0},{&l_1799,(void*)0,&l_1818[2][5],&g_178,&g_51[0][5],&g_51[0][6]},{(void*)0,&g_745,&l_1799,&g_51[3][0],&l_1799,&g_745},{&g_46,&g_51[0][5],&l_1818[2][2],&g_745,&g_51[3][0],(void*)0}},{{&l_1799,&l_1799,(void*)0,(void*)0,&g_51[0][6],&l_1818[2][5]},{&l_1818[1][1],&l_1799,&l_1799,&l_1799,&g_51[3][0],&g_46},{(void*)0,&g_51[0][5],(void*)0,&l_1818[1][1],&l_1799,(void*)0},{&g_51[0][6],&g_745,(void*)0,&g_51[0][6],&g_51[0][5],&g_178},{(void*)0,(void*)0,&l_1818[0][2],&g_46,&g_178,&g_51[2][0]}}};
            uint8_t ***l_2101 = &l_1852;
            union U1 l_2130 = {4294967295UL};
            int i, j, k;
            if ((safe_mod_func_uint8_t_u_u_unsafe_macro/*96*//* ___SAFE__OP */(7UL, (safe_unary_minus_func_int16_t_s_unsafe_macro/*97*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((*l_2057) = (l_2043 >= (safe_mod_func_int64_t_s_s_unsafe_macro/*99*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*100*//* ___SAFE__OP */(p_3, p_6)), ((safe_div_func_uint64_t_u_u_unsafe_macro/*101*//* ___SAFE__OP */((((0UL || (****g_933)) ^ (safe_mul_func_int32_t_s_s_unsafe_macro/*102*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */((-2L), ((safe_unary_minus_func_int32_t_s_unsafe_macro/*104*//* ___SAFE__OP */((l_1870[3][2][0] , (l_2055[4] == l_2055[4])))) ^ 0x7906852DL))), 0L))) , p_6), (*g_1895))) || l_2056))))), 1UL)) || 0UL))))))
            { /* block id: 1012 */
                uint16_t ****l_2073[6] = {&l_1782,&l_1782,&l_1782,&l_1782,&l_1782,&l_1782};
                uint32_t *l_2076 = &l_1870[3][2][0].f0;
                int i;
                (*g_1869) = (safe_unary_minus_func_uint32_t_u_unsafe_macro/*105*//* ___SAFE__OP */(((*l_2076) = ((+(safe_sub_func_int8_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */((-1L), ((*p_4) &= (((safe_rshift_func_int64_t_s_u_unsafe_macro/*107*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*108*//* ___SAFE__OP */((0x09B80730L != (safe_add_func_int16_t_s_s_unsafe_macro/*109*//* ___SAFE__OP */(g_2068[4][0], ((((void*)0 != (*g_1083)) == (~((safe_rshift_func_int32_t_s_u_unsafe_macro/*110*//* ___SAFE__OP */(((&g_1456 == &g_542[6]) < (safe_unary_minus_func_int16_t_s_unsafe_macro/*111*//* ___SAFE__OP */(((((l_2074 = (void*)0) != (void*)0) & l_2043) <= p_6)))), 3)) || l_2075))) | 5UL)))), 45)), (*g_1895))) < 0UL) <= 0x37L))))) == g_1652[3]))));
            }
            else
            { /* block id: 1017 */
                return (*g_177);
            }
            for (g_129 = 5; (g_129 >= 0); g_129 -= 1)
            { /* block id: 1022 */
                uint16_t l_2079 = 0xE0F9L;
                uint32_t ***l_2102 = (void*)0;
                int32_t l_2123 = 0x36351E38L;
                uint64_t **l_2144[3];
                uint64_t l_2152 = 0xD7E750E090713B03LL;
                uint32_t l_2194 = 0x206C7CCFL;
                int i;
                for (i = 0; i < 3; i++)
                    l_2144[i] = &l_1774[0];
                if ((safe_mod_func_uint8_t_u_u_unsafe_macro/*112*//* ___SAFE__OP */(0xB1L, ((****g_933) = 0x8DL))))
                { /* block id: 1024 */
                    uint32_t l_2082 = 4UL;
                    for (l_2043 = 0; (l_2043 <= 5); l_2043 += 1)
                    { /* block id: 1027 */
                        return (*g_1869);
                    }
                    for (g_178 = 0; (g_178 <= 5); g_178 += 1)
                    { /* block id: 1032 */
                        int32_t *l_2080 = &l_1818[4][2];
                        if (l_2079)
                            break;
                        l_2081[1][4][1] = (l_2080 = l_2080);
                    }
                    (*l_1808) = l_2081[1][4][1];
                    (*g_1869) = l_2082;
                }
                else
                { /* block id: 1039 */
                    int64_t l_2104 = 1L;
                    int32_t l_2105 = (-8L);
                    if (p_7)
                    { /* block id: 1040 */
                        uint32_t l_2103 = 0x1B9B51B9L;
                        l_2105 = ((safe_mul_func_int32_t_s_s_unsafe_macro/*113*//* ___SAFE__OP */(0x02E0EFCFL, ((safe_div_func_uint8_t_u_u_unsafe_macro/*114*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*115*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */(((safe_mod_func_uint32_t_u_u_unsafe_macro/*117*//* ___SAFE__OP */((((p_7 != ((p_3 <= (((*l_1769) = (safe_sub_func_uint8_t_u_u_unsafe_macro/*118*//* ___SAFE__OP */(((65535UL & ((safe_mul_func_uint64_t_u_u_unsafe_macro/*119*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_s_unsafe_macro/*120*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u_unsafe_macro/*121*//* ___SAFE__OP */(((*g_933) == l_2101), ((void*)0 != l_2102))), 1)), (*g_1895))) , p_3)) != p_6), p_7))) , l_2103)) && p_7)) & 0xF243L) != 18446744073709551612UL), p_3)) && 1L), l_2103)), l_2103)), 0xCFL)) == p_3))) && l_2104);
                        if (p_7)
                            break;
                    }
                    else
                    { /* block id: 1044 */
                        if (l_2104)
                            break;
                        if (p_7)
                            break;
                        if (l_2106[3])
                            break;
                    }
                }
                if (((safe_sub_func_int16_t_s_s_unsafe_macro/*122*//* ___SAFE__OP */(0L, (((void*)0 == l_2109) <= p_3))) , (0xB4DF1005L <= ((((*l_1769) ^= (safe_rshift_func_uint8_t_u_s_unsafe_macro/*123*//* ___SAFE__OP */((!((((*g_1083) = l_1802) != (l_2079 , (void*)0)) >= (safe_add_func_uint64_t_u_u_unsafe_macro/*124*//* ___SAFE__OP */((safe_mod_func_uint64_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */(l_2079, 0xB9C1A6072D4B5270LL)), l_2079)))), (*p_4)))) , p_6) || 249UL))))
                { /* block id: 1052 */
                    return p_6;
                }
                else
                { /* block id: 1054 */
                    int32_t l_2119[7] = {1L,0x6A0368A9L,1L,1L,0x6A0368A9L,1L,1L};
                    int32_t l_2122 = 0x68067CFBL;
                    int32_t l_2124 = 0x1AFA9DCFL;
                    int i;
                    if (p_6)
                    { /* block id: 1055 */
                        if (l_2079)
                            break;
                        (*g_1869) ^= ((safe_rshift_func_int16_t_s_u_unsafe_macro/*126*//* ___SAFE__OP */(0x15DAL, (l_2119[5] < 0xFB5A0E2DL))) , ((*l_1769) ^= l_2079));
                    }
                    else
                    { /* block id: 1059 */
                        int32_t *l_2121 = &g_745;
                        if (g_745)
                            goto lbl_2120;
                        (*l_1808) = (g_1079 , l_2121);
                    }
                    for (l_1994 = 4; (l_1994 >= 1); l_1994 -= 1)
                    { /* block id: 1065 */
                        int i;
                        if (g_125[(l_1994 + 1)])
                            break;
                        if (l_2079)
                            break;
                    }
                    l_2125++;
                    if (l_1921)
                        goto lbl_2128;
                }
                l_2123 = (!((&g_1455[3] == (l_2130 , (void*)0)) || p_3));
                if ((safe_mul_func_int64_t_s_s_unsafe_macro/*127*//* ___SAFE__OP */(((((safe_sub_func_int32_t_s_s_unsafe_macro/*128*//* ___SAFE__OP */(((***g_934) , (safe_mul_func_uint32_t_u_u_unsafe_macro/*129*//* ___SAFE__OP */(l_2079, (l_2139[0] >= (0xE3L != (safe_mod_func_uint64_t_u_u_unsafe_macro/*130*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */(((((l_2144[0] != (void*)0) | (3UL && (((((*l_2057) &= ((safe_sub_func_int64_t_s_s_unsafe_macro/*132*//* ___SAFE__OP */((p_7 <= (&g_163 != (void*)0)), p_7)) , 1L)) | 0x8005E257605C2336LL) ^ (-8L)) == 4294967295UL))) || l_2149) <= g_1079.f1), 3)), 1L))))))), p_3)) , p_6) < p_3) , p_3), g_987)))
                { /* block id: 1074 */
                    uint64_t l_2164 = 18446744073709551615UL;
                    int32_t l_2165 = (-8L);
                    const uint16_t **** const l_2178 = (void*)0;
                    (*l_1769) |= (safe_sub_func_uint32_t_u_u_unsafe_macro/*133*//* ___SAFE__OP */(((l_2152 <= (safe_mul_func_uint8_t_u_u_unsafe_macro/*134*//* ___SAFE__OP */(((((p_7 || 252UL) >= (safe_div_func_uint64_t_u_u_unsafe_macro/*135*//* ___SAFE__OP */((0xD4FD1129L == (((safe_add_func_uint64_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */(((void*)0 == &g_723), ((safe_mod_func_int64_t_s_s_unsafe_macro/*137*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s_unsafe_macro/*138*//* ___SAFE__OP */(0xD4D5L)), ((((safe_rshift_func_int32_t_s_u_unsafe_macro/*139*//* ___SAFE__OP */((l_2165 = (p_6 | (l_2164 ^ (**g_1083)))), 19)) == (*p_5)) >= g_733.f0) | l_2164))) != (****g_933)))) ^ (*g_1895)) >= p_3)), p_3))) , (*g_286)) == &p_7), (*p_4)))) , 0x636C5594L), p_6));
                    for (l_1775 = 5; (l_1775 >= 0); l_1775 -= 1)
                    { /* block id: 1079 */
                        const uint16_t ****l_2177 = &g_2176;
                        uint32_t l_2185[5][10] = {{0x8C7FB57EL,0x433E8011L,0x413F869BL,0x433E8011L,0x8C7FB57EL,18446744073709551615UL,0x62DFFD75L,0xB3ED8970L,0xDA813D15L,0x9AD741C7L},{0x62DFFD75L,0x9416F890L,0x9AD741C7L,18446744073709551615UL,0xB50B726DL,18446744073709551615UL,18446744073709551615UL,0xB50B726DL,18446744073709551615UL,0x9AD741C7L},{18446744073709551615UL,18446744073709551615UL,18446744073709551606UL,0x9AD741C7L,0x8C7FB57EL,0x3ABBA9BFL,0xB50B726DL,0x413F869BL,1UL,1UL},{0x413F869BL,0x759178C7L,0xB50B726DL,0xDA813D15L,0x433E8011L,0xDA813D15L,0xB50B726DL,0x759178C7L,0x413F869BL,0x413F869BL},{1UL,0x413F869BL,0xB50B726DL,0x3ABBA9BFL,0x8C7FB57EL,0x9AD741C7L,18446744073709551606UL,18446744073709551615UL,18446744073709551615UL,18446744073709551606UL}};
                        int i, j;
                        l_2185[0][4] = (((void*)0 == l_2166[8]) & (safe_mod_func_uint8_t_u_u_unsafe_macro/*140*//* ___SAFE__OP */((p_3 = (safe_mul_func_int16_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */(((safe_lshift_func_int32_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */(1L, (safe_mul_func_uint8_t_u_u_unsafe_macro/*143*//* ___SAFE__OP */(((l_2177 = g_2175) != l_2178), (*p_5))))) ^ 0xE9L), (safe_div_func_int32_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */((safe_div_func_int32_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */(p_3, ((safe_div_func_uint8_t_u_u_unsafe_macro/*146*//* ___SAFE__OP */((**g_935), (*p_5))) ^ (*g_31)))), p_6))))), (*p_5))));
                    }
                    (*l_2014) = ((safe_div_func_int32_t_s_s_unsafe_macro/*147*//* ___SAFE__OP */((!(safe_div_func_uint8_t_u_u_unsafe_macro/*148*//* ___SAFE__OP */(0x88L, ((((g_2191 , ((((safe_lshift_func_int64_t_s_u_unsafe_macro/*149*//* ___SAFE__OP */(((l_2194 , &p_5) == (((p_6 || ((p_3 <= (!(*p_4))) >= (*p_5))) && (safe_sub_func_int8_t_s_s_unsafe_macro/*150*//* ___SAFE__OP */(((*p_4) = (safe_div_func_uint32_t_u_u_unsafe_macro/*151*//* ___SAFE__OP */(4294967295UL, (*l_1769)))), p_7))) , &p_4)), (*g_1895))) == p_7) | (**g_1083)) , 0x1B5973A90B82205BLL)) && p_6) | (**g_1083)) , (*p_5))))), 0x80EA506BL)) > (*g_936));
                }
                else
                { /* block id: 1086 */
                    int64_t l_2205 = 0x4B05A58BF42A5326LL;
                    int32_t l_2219 = 0L;
                    int16_t *l_2220 = &g_723;
                    for (g_1809 = 0; (g_1809 <= 5); g_1809 += 1)
                    { /* block id: 1089 */
                        if (p_3)
                            break;
                        if (p_3)
                            continue;
                    }
                    (*g_242) = ((0xD6L >= (safe_add_func_uint32_t_u_u_unsafe_macro/*152*//* ___SAFE__OP */((l_2152 | (safe_div_func_uint16_t_u_u_unsafe_macro/*153*//* ___SAFE__OP */(((~(l_2205 = 0x7DC9C5CFL)) > (g_752[1][1][4]--)), (safe_mul_func_int16_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*155*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */(p_6, ((void*)0 == l_2214))), ((g_125[1] , (safe_add_func_int16_t_s_s_unsafe_macro/*157*//* ___SAFE__OP */(((*l_2220) |= (g_2068[3][1] , (safe_div_func_uint16_t_u_u_unsafe_macro/*158*//* ___SAFE__OP */(((*l_2014) | (*g_31)), l_2219)))), 1L))) ^ l_2221[0][6]))), 0xE9D2L))))), p_6))) | l_2079);
                }
            }
            return p_7;
        }
        else
        { /* block id: 1100 */
            uint8_t l_2228 = 0xA3L;
            uint32_t ***l_2267 = (void*)0;
            int32_t l_2279 = 0x2950DD1DL;
            int32_t l_2286 = 0xED231C7DL;
            int32_t l_2293 = 0L;
            int32_t l_2298[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int32_t ** const *l_2322 = (void*)0;
            int32_t ** const **l_2321 = &l_2322;
            int i;
            for (g_1214 = 5; (g_1214 >= 0); g_1214 -= 1)
            { /* block id: 1103 */
                int32_t l_2223 = (-8L);
                int32_t l_2224 = 0xC2238E3DL;
                uint32_t l_2225 = 4294967292UL;
                uint8_t l_2234[10];
                int32_t *l_2241 = &g_1652[3];
                int32_t l_2281 = 4L;
                int32_t l_2288 = 0x637C3563L;
                int32_t l_2296 = 0x4E08CBFAL;
                int32_t l_2297[7][10] = {{0x758533D8L,0xD7EBF04FL,0x96A91D9EL,0x93A2BE24L,0xC45B1799L,(-5L),0x923BFBB5L,0xF1FD500BL,0xCC5472C0L,0x6B44AD2AL},{0xB0A819CEL,(-5L),(-1L),0xD7EBF04FL,0xC45B1799L,(-1L),(-4L),1L,0x021A6010L,0x409AEBDDL},{0xC45B1799L,0x923BFBB5L,(-1L),7L,(-4L),7L,(-1L),0x923BFBB5L,0xC45B1799L,0x758533D8L},{0x96A91D9EL,6L,0xCC5472C0L,0xC616B5F8L,(-5L),0x93A2BE24L,0x021A6010L,(-1L),1L,0xB0A819CEL},{7L,0xB0A819CEL,(-4L),0xC616B5F8L,(-1L),0x6B44AD2AL,0xC824D222L,0x3AD07C3FL,0xC45B1799L,0xC45B1799L},{1L,(-1L),0x2B2E0209L,7L,7L,0x2B2E0209L,(-1L),1L,0x021A6010L,0x96A91D9EL},{0x923BFBB5L,1L,(-5L),0xD7EBF04FL,0x93A2BE24L,0x409AEBDDL,6L,0x021A6010L,0xCC5472C0L,7L}};
                int i, j;
                for (i = 0; i < 10; i++)
                    l_2234[i] = 1UL;
                l_2225--;
                if (p_3)
                    goto lbl_2120;
                for (g_204 = 5; (g_204 >= 0); g_204 -= 1)
                { /* block id: 1108 */
                    int32_t ***l_2229 = &l_1808;
                    int32_t l_2232 = 0x27653A47L;
                    union U1 l_2253[1][3] = {{{0x7BD36F7DL},{0x7BD36F7DL},{0x7BD36F7DL}}};
                    uint32_t ****l_2268 = (void*)0;
                    uint32_t ****l_2269 = &g_1456;
                    int16_t *l_2277 = &l_1775;
                    int32_t l_2283 = (-1L);
                    int32_t l_2284 = 0xF1940B1AL;
                    int32_t l_2292 = 0x1167556CL;
                    int32_t l_2294 = 0xFE4D0B5AL;
                    int32_t l_2295 = 0x66E3EBE7L;
                    int32_t l_2300 = (-10L);
                    uint32_t l_2301[7][3] = {{0xD823B66BL,0xD823B66BL,0xD823B66BL},{8UL,0x425D473EL,8UL},{0xD823B66BL,0xD823B66BL,0xD823B66BL},{8UL,0x425D473EL,8UL},{0xD823B66BL,0xD823B66BL,0xD823B66BL},{8UL,0x425D473EL,8UL},{0xD823B66BL,0xD823B66BL,0xD823B66BL}};
                    int i, j;
                    if ((l_2228 = 9L))
                    { /* block id: 1110 */
                        int32_t ****l_2230 = &l_2055[4];
                        (*l_2230) = l_2229;
                    }
                    else
                    { /* block id: 1112 */
                        int32_t *l_2231 = &g_745;
                        int32_t l_2233 = 1L;
                        int64_t *l_2260 = &g_125[1];
                        (*l_1808) = l_2231;
                        l_2234[7]--;
                        l_2224 |= (safe_mul_func_uint64_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */((((safe_mul_func_uint16_t_u_u_unsafe_macro/*160*//* ___SAFE__OP */((l_2241 == g_2242), ((***l_1782) = (safe_lshift_func_int64_t_s_s_unsafe_macro/*161*//* ___SAFE__OP */(((*l_2260) = (((~p_7) > 0x5308L) , (safe_rshift_func_uint32_t_u_u_unsafe_macro/*162*//* ___SAFE__OP */((p_7 > (safe_unary_minus_func_int32_t_s_unsafe_macro/*163*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_s_unsafe_macro/*164*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*165*//* ___SAFE__OP */((g_241 = (&g_1634[2] == (l_2253[0][0] , ((safe_div_func_int8_t_s_s_unsafe_macro/*166*//* ___SAFE__OP */((*p_5), (((safe_mul_func_uint8_t_u_u_unsafe_macro/*167*//* ___SAFE__OP */((!g_193), (*l_2231))) >= p_7) || (*g_1895)))) , l_2259)))), p_7)) , (*g_936)), l_2228)) , (*g_1869))))), 22)))), 17))))) | p_7) | 0x4763L), 1L));
                    }
                    (*l_1808) = (void*)0;
                    if ((p_7 >= (safe_sub_func_uint8_t_u_u_unsafe_macro/*168*//* ___SAFE__OP */((((0x2182FCCD7E025180LL | 0xDF269038BE0EB0DALL) != (safe_mod_func_uint64_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */(((*g_1895) = ((l_2228 , ((safe_rshift_func_int8_t_s_u_unsafe_macro/*170*//* ___SAFE__OP */((*p_4), 3)) >= (p_7 ^ (((((*l_2269) = l_2267) == ((safe_lshift_func_int16_t_s_s_unsafe_macro/*171*//* ___SAFE__OP */(((*l_2277) = (safe_mod_func_uint64_t_u_u_unsafe_macro/*172*//* ___SAFE__OP */(p_3, ((+(safe_mod_func_int64_t_s_s_unsafe_macro/*173*//* ___SAFE__OP */(1L, p_7))) , 18446744073709551611UL)))), 14)) , (*g_541))) || p_6) != 0x5E16FDFC689779EALL)))) && (*p_5))), 0xA35009253C893FE4LL))) == p_6), 253UL))))
                    { /* block id: 1124 */
                        if (l_2228)
                            break;
                        if (p_6)
                            continue;
                    }
                    else
                    { /* block id: 1127 */
                        int16_t l_2278 = 1L;
                        int32_t l_2280 = 9L;
                        int32_t l_2282 = 0x35149B1DL;
                        int16_t l_2285 = 0x3D0DL;
                        int32_t l_2287 = 0x85C18343L;
                        int32_t l_2290 = (-1L);
                        int32_t l_2291 = 0L;
                        int32_t l_2299[4][7][1];
                        uint32_t *****l_2323 = &g_1455[3];
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 7; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_2299[i][j][k] = 0xDEA73EE1L;
                            }
                        }
                        ++l_2301[4][0];
                        (*g_177) = ((**g_1810) > (safe_mod_func_uint32_t_u_u_unsafe_macro/*174*//* ___SAFE__OP */((((safe_lshift_func_uint8_t_u_s_unsafe_macro/*175*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*176*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u_unsafe_macro/*177*//* ___SAFE__OP */(l_2225, (l_2298[2] < (((((safe_add_func_int16_t_s_s_unsafe_macro/*178*//* ___SAFE__OP */(((*l_2277) ^= ((*l_2014) , (((p_3 , (safe_unary_minus_func_int64_t_s_unsafe_macro/*179*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*180*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*181*//* ___SAFE__OP */((p_6 || ((safe_sub_func_uint8_t_u_u_unsafe_macro/*182*//* ___SAFE__OP */(((((4UL && l_2280) , (l_2321 == &l_2229)) < 0xD4F1AB6FB1E97078LL) != p_3), 0x81L)) | p_6)), p_7)), 54))))) | p_3) && 0xD9L))), p_6)) && (*p_4)) , p_7) , (*g_1895)) < (*g_1895))))), 49)), 7)) & g_559) , l_2280), l_2281)));
                        g_2324 = l_2323;
                    }
                    return (*g_242);
                }
                for (g_1477 = 0; (g_1477 <= 6); g_1477 += 1)
                { /* block id: 1137 */
                    (*l_1808) = &l_2288;
                    return (*g_177);
                }
            }
            (*l_1769) = p_6;
        }
        if (l_1845.f0)
            goto lbl_2128;
    }
    return (*l_1769);
}


/* ------------------------------------------ */
/* 
 * reads : g_177 g_242
 * writes: g_178
 */
static uint32_t  func_8(int8_t  p_9, int8_t * p_10, int8_t * p_11, int8_t * const  p_12)
{ /* block id: 871 */
    int16_t l_1763 = 0xB96AL;
    int32_t l_1764 = 0xA7C36B00L;
    int32_t *l_1765[6];
    uint64_t l_1766 = 0x99AE970C827B3E01LL;
    uint32_t l_1767 = 0xB985B1C6L;
    int i;
    for (i = 0; i < 6; i++)
        l_1765[i] = &g_51[0][6];
    (*g_177) = (l_1763 < p_9);
    l_1767 = (((*g_242) = (l_1764 = ((*p_10) == 0xA4L))) <= l_1766);
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_242 g_178 g_49 g_518.f1 g_203 g_659 g_993 g_1082 g_286 g_287 g_1096 g_129 g_934 g_935 g_936 g_121 g_752 g_732 g_733 g_204 g_1083 g_31 g_722 g_987 g_46 g_749 g_32 g_50 g_1017.f0 g_1227 g_541 g_542 g_51 g_342 g_1270 g_177 g_733.f0 g_125 g_98 g_1017.f1 g_154 g_546 g_1376 g_331 g_193 g_81 g_322.f2 g_1214 g_241 g_1455 g_83 g_84 g_1477 g_811 g_1017.f2 g_153 g_1079.f2 g_1525 g_1017 g_518.f0 g_559 g_1456 g_614 g_228
 * writes: g_46 g_178 g_193 g_1042 g_32 g_206 g_1083 g_752 g_287 g_51 g_559 g_733.f0 g_121 g_204 g_241 g_723 g_1155 g_546 g_659 g_1227 g_81 g_125 g_749 g_154 g_98 g_732 g_1477
 */
static int16_t  func_22(const int8_t  p_23, uint8_t  p_24, uint32_t  p_25)
{ /* block id: 489 */
    uint16_t l_1032 = 0x9846L;
    int32_t l_1038 = (-3L);
    uint16_t *l_1041[10] = {&l_1032,&l_1032,&l_1032,&l_1032,&l_1032,&l_1032,&l_1032,&l_1032,&l_1032,&l_1032};
    uint8_t **l_1046 = &g_936;
    uint8_t ***l_1045 = &l_1046;
    uint8_t ****l_1044[4][9] = {{(void*)0,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,(void*)0,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,(void*)0,&l_1045,&l_1045}};
    uint8_t *****l_1043[5][2][3] = {{{&l_1044[1][4],&l_1044[1][7],&l_1044[1][4]},{(void*)0,&l_1044[1][4],&l_1044[1][4]}},{{&l_1044[1][4],&l_1044[1][7],&l_1044[1][4]},{(void*)0,&l_1044[1][4],&l_1044[1][4]}},{{&l_1044[1][4],&l_1044[1][7],&l_1044[1][4]},{(void*)0,&l_1044[1][4],&l_1044[1][4]}},{{&l_1044[1][4],&l_1044[1][7],&l_1044[1][4]},{(void*)0,&l_1044[1][4],&l_1044[1][4]}},{{&l_1044[1][4],&l_1044[1][7],&l_1044[1][4]},{(void*)0,&l_1044[1][4],&l_1044[1][4]}}};
    uint32_t ***l_1062 = (void*)0;
    uint32_t ****l_1061 = &l_1062;
    int32_t l_1069 = 0x5773C3D3L;
    int32_t l_1070[6] = {0L,0x0C53DCE6L,0x0C53DCE6L,0L,0x0C53DCE6L,0x0C53DCE6L};
    struct S0 *l_1076 = &g_518;
    int8_t **l_1081[9] = {&g_31,&g_31,&g_31,&g_31,&g_31,&g_31,&g_31,&g_31,&g_31};
    uint32_t * const l_1094 = &g_733.f0;
    union U1 l_1111[10] = {{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL}};
    int32_t l_1304 = 0x1BEA5531L;
    int32_t l_1350 = (-5L);
    uint32_t l_1372 = 0UL;
    int32_t l_1374 = (-1L);
    uint16_t l_1378 = 4UL;
    int32_t l_1416 = 0xE1B04A90L;
    int32_t **l_1528 = (void*)0;
    int32_t ***l_1527 = &l_1528;
    int32_t ****l_1526 = &l_1527;
    int8_t l_1556 = 0x77L;
    const int32_t *l_1589 = &g_1214;
    const int32_t **l_1588 = &l_1589;
    const int32_t ***l_1587 = &l_1588;
    uint32_t *l_1641 = &g_81;
    uint32_t ** const l_1640 = &l_1641;
    uint32_t ** const *l_1639 = &l_1640;
    int32_t l_1698 = 0x9C83EF6EL;
    const uint8_t *l_1711 = (void*)0;
    const uint8_t **l_1710 = &l_1711;
    uint8_t **l_1713 = (void*)0;
    uint8_t l_1714 = 0x87L;
    int32_t *l_1718 = &l_1070[3];
    uint32_t *l_1735 = &g_98;
    int i, j, k;
lbl_1174:
    for (g_46 = 0; (g_46 > (-13)); --g_46)
    { /* block id: 492 */
        int32_t *l_1033[4][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
        int i, j;
        (*g_242) ^= ((l_1032 == 0x13L) & 65535UL);
        for (g_193 = 22; (g_193 <= 18); --g_193)
        { /* block id: 496 */
            int32_t *l_1036 = &g_178;
            int32_t **l_1037 = &l_1033[2][0];
            (*l_1037) = l_1036;
            (*l_1036) &= (g_49 , p_24);
        }
    }
    if (((l_1038 = l_1032) , (safe_lshift_func_uint16_t_u_s_unsafe_macro/*183*//* ___SAFE__OP */(p_24, ((((((((void*)0 == l_1041[9]) > ((g_1042 = (void*)0) != l_1043[0][0][0])) || (safe_add_func_uint8_t_u_u_unsafe_macro/*184*//* ___SAFE__OP */(0x0AL, (p_24 <= ((p_25 & 0xB363F2610511EB3DLL) , g_518.f1))))) != l_1032) == p_24) < 0xB554L) && p_24)))))
    { /* block id: 503 */
        int32_t l_1055 = 0x8C26F65EL;
        int32_t l_1066 = 0x6D1F3C51L;
        int32_t l_1067 = 0x15D0EE76L;
        int32_t l_1068 = 0x7F03074AL;
        int32_t l_1071 = 7L;
        int32_t l_1072 = (-1L);
        uint8_t l_1073 = 5UL;
        struct S0 *l_1078 = &g_1079;
        for (p_25 = 0; (p_25 <= 58); p_25 = safe_add_func_int8_t_s_s_unsafe_macro/*185*//* ___SAFE__OP */(p_25, 8))
        { /* block id: 506 */
            uint32_t l_1064 = 0UL;
            int32_t l_1065 = 0L;
            for (l_1038 = (-10); (l_1038 < (-6)); l_1038 = safe_add_func_uint16_t_u_u_unsafe_macro/*186*//* ___SAFE__OP */(l_1038, 3))
            { /* block id: 509 */
                union U1 l_1058 = {4294967294UL};
                int32_t *l_1063[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                struct S0 **l_1077[4] = {&l_1076,&l_1076,&l_1076,&l_1076};
                int i;
                l_1064 |= (safe_add_func_int16_t_s_s_unsafe_macro/*187*//* ___SAFE__OP */(((g_203[2] , l_1055) >= (0x360FL | (safe_mod_func_uint16_t_u_u_unsafe_macro/*188*//* ___SAFE__OP */((l_1058 , (safe_mul_func_int8_t_s_s_unsafe_macro/*189*//* ___SAFE__OP */(((void*)0 == l_1061), ((((p_25 == p_23) & (p_23 && g_659[1][4][0])) < 0x246A247C9A880FEELL) && p_25)))), g_993[0][0][2])))), p_23));
                l_1073--;
                l_1078 = l_1076;
                for (g_32 = 0; g_32 < 5; g_32 += 1)
                {
                    for (l_1065 = 0; l_1065 < 2; l_1065 += 1)
                    {
                        for (g_206 = 0; g_206 < 3; g_206 += 1)
                        {
                            l_1043[g_32][l_1065][g_206] = &g_1080;
                        }
                    }
                }
            }
        }
        if (p_25)
            goto lbl_1084;
lbl_1084:
        (*g_1082) = l_1081[6];
        l_1067 = (safe_div_func_uint32_t_u_u_unsafe_macro/*190*//* ___SAFE__OP */(((((safe_mul_func_uint8_t_u_u_unsafe_macro/*191*//* ___SAFE__OP */(p_25, p_23)) >= l_1038) > (g_752[4][0][1] = 65535UL)) ^ l_1068), l_1072));
    }
    else
    { /* block id: 520 */
        int16_t l_1091 = 0x0BBDL;
        union U1 **l_1092 = &g_732;
        int16_t *l_1093 = &g_204;
        int32_t *l_1095 = (void*)0;
        int32_t l_1118 = 1L;
        int32_t l_1121 = 0xC9D1DDA3L;
        int32_t l_1122 = (-6L);
        int32_t l_1124 = 7L;
        int32_t l_1125 = 0x6C308212L;
        int32_t l_1126 = 1L;
        uint8_t *** const *l_1153 = &l_1045;
        int32_t l_1217 = 1L;
        int32_t l_1225 = 0L;
        int32_t l_1226[3][7][8] = {{{2L,(-4L),(-7L),0xBD47CE30L,0L,0L,2L,0xF385B7F1L},{0x4EE58F65L,0L,0L,3L,(-5L),1L,0xD540B792L,(-5L)},{0xBD47CE30L,0xD9FAF979L,0x59DCAB48L,(-5L),(-1L),0x59DCAB48L,0x48F32E36L,0x69B035DFL},{(-1L),0xBD47CE30L,0L,(-5L),0L,0L,0x92D06E2FL,0x97D74E09L},{0L,0x4A532759L,0x9933DE84L,0xD9FAF979L,(-5L),0xD9FAF979L,0x9933DE84L,0x4A532759L},{0xF385B7F1L,0x69B035DFL,0x98B1E97EL,1L,0x4EE58F65L,0x59DCAB48L,0L,0x9933DE84L},{0x4A532759L,0x48F32E36L,0x802E0359L,0L,0xF385B7F1L,8L,0L,(-5L)}},{{(-5L),0L,0x98B1E97EL,0x59DCAB48L,9L,0xA8A946A6L,0x9933DE84L,2L},{9L,0xA8A946A6L,0x9933DE84L,2L,0L,(-1L),0x92D06E2FL,0L},{(-4L),0x97D74E09L,0L,(-4L),0xB7AD13AFL,0xF8E9AA95L,0x48F32E36L,(-5L)},{0x053AC36FL,(-1L),0x59DCAB48L,(-5L),0xB715FDD5L,0xD540B792L,0xD540B792L,0xB715FDD5L},{1L,0L,0L,1L,0xD540B792L,(-5L),2L,(-7L)},{(-4L),(-5L),(-7L),0x48F32E36L,0x92D06E2FL,(-7L),0x4A532759L,0x97D74E09L},{3L,(-5L),0L,0x94EA1BE4L,9L,(-5L),0x053AC36FL,0xBD47CE30L}},{{0L,0L,3L,(-5L),1L,0xD540B792L,(-5L),0x94EA1BE4L},{0x4A532759L,(-1L),(-7L),9L,(-1L),0xF8E9AA95L,1L,0xF385B7F1L},{1L,0x97D74E09L,0L,0x69B035DFL,(-5L),(-1L),(-7L),0L},{2L,0xA8A946A6L,(-5L),0xBD47CE30L,(-5L),0xA8A946A6L,2L,1L},{(-1L),0L,1L,9L,(-5L),8L,0x98B1E97EL,(-5L)},{(-1L),(-7L),0L,(-7L),3L,0L,0xF8E9AA95L,0x053AC36FL},{0L,(-1L),(-9L),(-5L),(-4L),0xF8E9AA95L,0x9933DE84L,0L}}};
        uint32_t *** const l_1273 = &g_614;
        struct S0 *l_1280 = &g_203[5];
        uint16_t l_1299 = 9UL;
        uint32_t l_1351 = 0x76FB5E74L;
        int i, j, k;
        (*g_1096) = (safe_add_func_uint16_t_u_u_unsafe_macro/*192*//* ___SAFE__OP */(p_24, (l_1091 > (((*g_286) = (*g_286)) != l_1094))));
        for (g_559 = 18; (g_559 <= 42); g_559++)
        { /* block id: 526 */
            int32_t l_1110 = 0xA42179B6L;
            int64_t l_1112 = 0x151EECC3E27F3A42LL;
            int32_t *l_1113[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1113[i] = &g_178;
            l_1069 = (l_1070[3] &= (safe_add_func_int64_t_s_s_unsafe_macro/*193*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u_unsafe_macro/*194*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*195*//* ___SAFE__OP */(l_1038, p_25)), ((((safe_mod_func_uint32_t_u_u_unsafe_macro/*196*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*197*//* ___SAFE__OP */(((void*)0 == l_1076), g_129)), ((*l_1094) = (safe_unary_minus_func_uint16_t_u_unsafe_macro/*198*//* ___SAFE__OP */((g_752[6][3][3] = l_1110)))))) >= ((l_1111[7] , ((***g_934) , 18446744073709551611UL)) ^ g_203[5].f0)) > l_1110) , g_752[1][0][0]))), l_1112)));
        }
lbl_1303:
        for (g_121 = 0; (g_121 <= 8); g_121 += 1)
        { /* block id: 534 */
            int64_t l_1123 = 5L;
            int8_t l_1127 = 0xACL;
            int32_t l_1136 = 0xE93AD0C2L;
            int8_t *l_1147 = &g_987;
            int32_t l_1149 = (-5L);
            int32_t l_1165 = 0xDBE496C8L;
            uint8_t l_1166 = 248UL;
            (*g_1096) = 2L;
            for (g_178 = 0; (g_178 <= 4); g_178 += 1)
            { /* block id: 538 */
                uint64_t l_1128 = 0xC95687D3AB46C71BLL;
                uint16_t **l_1133[3];
                uint32_t l_1150 = 4294967295UL;
                int32_t l_1158 = 0L;
                int i;
                for (i = 0; i < 3; i++)
                    l_1133[i] = (void*)0;
                for (g_559 = 0; (g_559 <= 8); g_559 += 1)
                { /* block id: 541 */
                    int32_t *l_1114 = &g_745;
                    int32_t *l_1115 = &l_1070[3];
                    int32_t *l_1116 = &l_1038;
                    int32_t *l_1117 = (void*)0;
                    int32_t *l_1119 = &g_46;
                    int32_t *l_1120[9][5][5] = {{{&g_178,&l_1069,&g_46,&g_46,&l_1069},{(void*)0,&l_1070[2],&g_745,&g_745,&g_51[0][6]},{&g_178,&l_1118,&g_178,&g_46,&l_1038},{&l_1070[3],&l_1118,&g_51[0][6],&l_1118,&l_1070[3]},{&g_178,&g_178,&l_1118,&l_1069,&l_1118}},{{(void*)0,&l_1038,&g_51[0][6],&l_1038,&l_1118},{&g_178,&g_178,&g_178,&g_178,&l_1118},{&g_46,&l_1038,&g_745,&g_51[0][6],&l_1070[3]},{&l_1118,&g_178,&g_46,&l_1038,&l_1038},{&g_178,&l_1038,&g_178,&g_51[0][6],&g_51[0][6]}},{{&l_1069,&g_178,&l_1038,&g_178,&l_1069},{&g_178,&l_1118,(void*)0,&l_1038,(void*)0},{&l_1118,&l_1118,&l_1038,&l_1069,(void*)0},{&g_46,&l_1070[2],&g_178,&l_1118,(void*)0},{&g_178,&l_1069,&g_46,&g_46,&l_1069}},{{(void*)0,&l_1070[2],&g_745,&g_745,&g_51[0][6]},{&g_178,&l_1118,&g_178,&g_46,&l_1038},{&l_1070[3],&l_1118,&g_51[0][6],&l_1118,&l_1070[3]},{&g_178,&g_178,&l_1118,&l_1069,&l_1118},{(void*)0,&l_1038,&g_51[0][6],&l_1038,&l_1118}},{{&g_178,&g_178,&g_178,&g_178,&l_1118},{&g_46,&l_1038,&g_745,&g_51[0][6],&l_1070[3]},{&l_1118,&g_178,&g_46,&l_1038,&l_1038},{&g_178,&l_1038,&g_178,&g_51[0][6],&g_51[0][6]},{&l_1069,&g_178,&l_1038,&g_178,&l_1069}},{{&g_178,&l_1118,(void*)0,&l_1038,(void*)0},{&l_1118,&l_1118,&l_1038,&l_1069,(void*)0},{&g_46,&l_1070[2],&g_178,&l_1118,(void*)0},{&g_178,&l_1069,&g_46,&g_46,&l_1069},{(void*)0,&l_1070[2],&g_745,&g_745,&g_51[0][6]}},{{&g_178,&l_1118,&g_178,&g_46,&l_1038},{&l_1070[3],&l_1118,&g_51[0][6],&l_1118,&l_1070[3]},{&g_178,&g_178,&l_1118,&l_1069,&l_1118},{(void*)0,&l_1038,&g_51[0][6],&l_1038,&l_1118},{&g_178,&g_178,&g_178,&g_178,(void*)0}},{{&g_178,&g_51[0][6],&g_51[0][6],&g_745,&g_745},{(void*)0,&l_1069,&l_1038,&l_1118,&l_1118},{&l_1070[3],&l_1070[3],&l_1070[3],&g_745,(void*)0},{&g_46,&g_178,&l_1118,&g_178,&g_46},{&l_1070[3],&l_1070[2],&l_1118,&g_51[0][6],&l_1118}},{{(void*)0,(void*)0,&l_1118,&g_46,&g_178},{&g_178,&l_1038,&l_1070[3],&l_1070[2],&l_1118},{&g_178,&g_46,&l_1038,&l_1038,&g_46},{&l_1118,&l_1038,&g_51[0][6],&l_1038,(void*)0},{&l_1069,(void*)0,&l_1069,&l_1038,&l_1118}}};
                    int8_t ***l_1169 = &l_1081[6];
                    int i, j, k;
                    l_1128--;
                    if (((**l_1092) , g_752[(g_178 + 1)][g_178][g_178]))
                    { /* block id: 543 */
                        uint64_t l_1135[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
                        int16_t *l_1141 = &g_241;
                        int16_t *l_1142 = &l_1091;
                        int i;
                        (*l_1115) = (safe_sub_func_int32_t_s_s_unsafe_macro/*199*//* ___SAFE__OP */((((l_1133[1] == (((safe_unary_minus_func_int8_t_s_unsafe_macro/*200*//* ___SAFE__OP */(l_1135[8])) >= (p_24++)) , (void*)0)) <= ((((((*g_732) , ((safe_sub_func_uint16_t_u_u_unsafe_macro/*201*//* ___SAFE__OP */(((((*l_1142) ^= (g_723 = ((*l_1141) = ((*l_1093) |= 0x3CA7L)))) ^ (safe_div_func_uint64_t_u_u_unsafe_macro/*202*//* ___SAFE__OP */((((safe_sub_func_int8_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(p_23, ((-7L) >= (((((((**g_1082) == (l_1147 = (*g_1083))) , l_1070[3]) || p_25) , (*g_936)) , 247UL) || 0UL)))) > p_23) , 18446744073709551615UL), g_203[5].f0))) < p_25), p_25)) == l_1128)) < 1L) == g_722) == l_1128) > g_993[0][0][2])) & g_722), (-8L)));
                        return g_987;
                    }
                    else
                    { /* block id: 552 */
                        int32_t l_1148 = 0xDEEA87B3L;
                        uint8_t *** const **l_1154[9][7][3] = {{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153},{(void*)0,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,(void*)0},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,(void*)0}},{{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153},{(void*)0,&l_1153,(void*)0},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,(void*)0}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{(void*)0,(void*)0,&l_1153},{(void*)0,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153}},{{(void*)0,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,(void*)0,&l_1153}},{{&l_1153,&l_1153,&l_1153},{&l_1153,&l_1153,(void*)0},{&l_1153,&l_1153,&l_1153},{&l_1153,(void*)0,&l_1153},{&l_1153,&l_1153,(void*)0},{(void*)0,&l_1153,&l_1153},{&l_1153,&l_1153,&l_1153}}};
                        int i, j, k;
                        ++l_1150;
                        g_1155 = l_1153;
                    }
                    for (p_25 = 1; (p_25 == 44); p_25 = safe_add_func_uint16_t_u_u_unsafe_macro/*204*//* ___SAFE__OP */(p_25, 7))
                    { /* block id: 558 */
                        int64_t l_1159 = 0x0DE4BC46C9D3E00BLL;
                        int32_t l_1160 = 0x8143B5E8L;
                        int32_t l_1161 = 0x13A47456L;
                        int32_t l_1162 = (-2L);
                        int32_t l_1163 = 9L;
                        int32_t l_1164[4][8] = {{0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L},{0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L},{0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L},{0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L,0x4C6C2E47L}};
                        int8_t ***l_1170[1];
                        struct S0 **l_1171 = &l_1076;
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_1170[i] = &l_1081[6];
                        ++l_1166;
                        if (l_1165)
                            continue;
                        l_1170[0] = l_1169;
                        (*l_1171) = &g_203[5];
                    }
                    (*l_1119) ^= 0xCA4567EBL;
                }
                return p_23;
            }
        }
        for (l_1091 = (-17); (l_1091 == 19); ++l_1091)
        { /* block id: 571 */
            uint32_t l_1180 = 4294967287UL;
            uint8_t ****l_1183[8][6][5] = {{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{(void*)0,&l_1045,&l_1045,(void*)0,&l_1045}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,(void*)0,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,(void*)0,(void*)0,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,&l_1045,&l_1045}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,(void*)0},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{(void*)0,&l_1045,&l_1045,&l_1045,(void*)0}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,(void*)0,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{(void*)0,&l_1045,&l_1045,(void*)0,&l_1045},{&l_1045,&l_1045,(void*)0,&l_1045,&l_1045}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,(void*)0,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,(void*)0},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,&l_1045,(void*)0}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,&l_1045,&l_1045},{(void*)0,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,(void*)0,&l_1045}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,(void*)0,&l_1045,(void*)0},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,(void*)0}},{{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,(void*)0,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{(void*)0,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,&l_1045,&l_1045,&l_1045,&l_1045},{&l_1045,(void*)0,&l_1045,(void*)0,&l_1045}}};
            const union U1 l_1186 = {4UL};
            int32_t l_1190 = 0x7564ADF3L;
            int32_t l_1215 = 0x677A5582L;
            int32_t l_1216 = 0xC82425D7L;
            int32_t l_1218 = 1L;
            int32_t l_1219 = 0xD8438DCBL;
            int32_t l_1220 = 0xA126DAF3L;
            int32_t l_1221 = 0L;
            int32_t l_1222 = 0x849DE5C7L;
            int32_t l_1223[6] = {0x24F05790L,0x24F05790L,0x24F05790L,0x24F05790L,0x24F05790L,0x24F05790L};
            uint32_t ***l_1234[7][6][6] = {{{(void*)0,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,(void*)0,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,(void*)0,&g_614},{(void*)0,(void*)0,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614}},{{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,(void*)0,(void*)0,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,(void*)0,&g_614,(void*)0,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614}},{{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{(void*)0,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0}},{{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,(void*)0,(void*)0,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,(void*)0,&g_614,&g_614},{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,(void*)0,&g_614}},{{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,(void*)0,&g_614,(void*)0},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,&g_614,(void*)0,&g_614,&g_614}},{{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,&g_614,&g_614,&g_614,(void*)0},{&g_614,&g_614,&g_614,(void*)0,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,(void*)0,&g_614,&g_614,&g_614,(void*)0}},{{&g_614,(void*)0,&g_614,&g_614,(void*)0,&g_614},{(void*)0,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,(void*)0,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,(void*)0,&g_614,&g_614,&g_614},{&g_614,&g_614,&g_614,&g_614,&g_614,&g_614},{&g_614,&g_614,(void*)0,&g_614,&g_614,&g_614}}};
            uint8_t **l_1283 = &g_936;
            int32_t *l_1331 = (void*)0;
            uint16_t l_1375 = 0x9A28L;
            int i, j, k;
            if (g_129)
                goto lbl_1174;
            for (g_559 = 3; (g_559 <= 9); g_559 += 1)
            { /* block id: 575 */
                int32_t l_1189 = 5L;
                int i;
                l_1190 = (((safe_unary_minus_func_uint8_t_u_unsafe_macro/*205*//* ___SAFE__OP */((((safe_add_func_uint8_t_u_u_unsafe_macro/*206*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*207*//* ___SAFE__OP */(l_1180, (((p_25 < (((safe_lshift_func_uint8_t_u_u_unsafe_macro/*208*//* ___SAFE__OP */((***g_934), ((void*)0 == l_1183[7][3][1]))) | ((((p_25 <= ((g_752[5][4][0] ^= (((safe_sub_func_int32_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */(0x47F1DD4EL, (l_1186 , (l_1189 = ((safe_sub_func_uint8_t_u_u_unsafe_macro/*210*//* ___SAFE__OP */((l_1186.f0 >= p_25), l_1189)) && 0x779EF339L))))) , &l_1183[7][3][1]) == (void*)0)) , l_1186.f0)) , 0xB5L) <= l_1186.f0) , 65535UL)) < 0xBC75A52E150A1F7ELL)) , (void*)0) == &p_23))), p_23)) < g_749) != l_1180))) >= 0xD4F0A643L) <= g_129);
                for (g_546 = 3; (g_546 <= 9); g_546 += 1)
                { /* block id: 581 */
                    int32_t *l_1191 = &l_1189;
                    l_1191 = &l_1189;
                    for (g_32 = 1; (g_32 >= 0); g_32 -= 1)
                    { /* block id: 585 */
                        int i, j, k;
                        return g_50[g_32][(g_32 + 4)][(g_32 + 2)];
                    }
                }
            }
            if (((p_25 , l_1070[3]) != ((*l_1093) = ((l_1038 != (l_1069 = (g_659[2][1][3] = ((safe_rshift_func_int8_t_s_s_unsafe_macro/*211*//* ___SAFE__OP */((((p_24 > (safe_rshift_func_int8_t_s_u_unsafe_macro/*212*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*213*//* ___SAFE__OP */((safe_rshift_func_uint16_t_u_s_unsafe_macro/*214*//* ___SAFE__OP */(((p_24 > (l_1186.f0 , (safe_mul_func_uint32_t_u_u_unsafe_macro/*215*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_s_unsafe_macro/*216*//* ___SAFE__OP */(l_1111[7].f0, 62)), (safe_mod_func_int16_t_s_s_unsafe_macro/*217*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*218*//* ___SAFE__OP */(0UL, ((safe_sub_func_int64_t_s_s_unsafe_macro/*219*//* ___SAFE__OP */((+(((*l_1153) == (*l_1153)) , l_1111[7].f0)), g_1017[0][0].f0)) == p_23))), g_178)))))) , p_24), 7)), 65535UL)), p_24))) && p_24) <= p_25), 0)) , p_23)))) <= 0x4C20L))))
            { /* block id: 593 */
                int32_t *l_1211 = &l_1070[3];
                int32_t *l_1212 = &g_51[0][6];
                int32_t *l_1213[1][8][4] = {{{&g_51[4][4],&g_51[4][4],&l_1069,&g_51[4][4]},{&g_51[4][4],&l_1125,&l_1125,&g_51[4][4]},{&l_1125,&g_51[4][4],&l_1125,&l_1125},{&g_51[4][4],&g_51[4][4],&l_1069,&g_51[4][4]},{&g_51[4][4],&l_1125,&l_1125,&g_51[4][4]},{&l_1125,&g_51[4][4],&l_1125,&l_1125},{&g_51[4][4],&g_51[4][4],&l_1069,&g_51[4][4]},{&g_51[4][4],&l_1125,&l_1125,&g_51[4][4]}}};
                int8_t l_1224[9][1] = {{0xD5L},{8L},{0xD5L},{8L},{0xD5L},{8L},{0xD5L},{8L},{0xD5L}};
                uint32_t ***l_1235 = (void*)0;
                int32_t **l_1257 = &l_1213[0][1][3];
                int32_t ***l_1256 = &l_1257;
                int8_t **l_1259 = &g_31;
                int64_t *l_1278 = (void*)0;
                int64_t *l_1279 = &g_125[1];
                struct S0 **l_1281 = (void*)0;
                struct S0 **l_1282 = &l_1076;
                int i, j, k;
                g_1227++;
                for (g_204 = (-6); (g_204 == (-29)); g_204--)
                { /* block id: 597 */
                    int8_t l_1255 = 2L;
                    for (g_81 = 0; (g_81 >= 12); g_81 = safe_add_func_int8_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */(g_81, 4))
                    { /* block id: 600 */
                        int64_t l_1258 = 8L;
                        int64_t *l_1266 = &g_125[4];
                        l_1225 = (((*l_1061) = l_1234[3][2][2]) != ((0x4ECDL ^ ((l_1070[5] = (l_1235 != (((safe_rshift_func_int32_t_s_u_unsafe_macro/*221*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_u_unsafe_macro/*222*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*223*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*224*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_s_unsafe_macro/*225*//* ___SAFE__OP */((+(((((*l_1212) = ((safe_mod_func_int16_t_s_s_unsafe_macro/*226*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*227*//* ___SAFE__OP */((-4L), p_24)), 1UL)) == p_24)) , ((5UL <= (safe_div_func_int8_t_s_s_unsafe_macro/*228*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*229*//* ___SAFE__OP */(l_1215, p_23)) || l_1255), p_24))) , l_1256)) == (void*)0) == l_1038)), 3)), l_1255)), p_25)), l_1258)) && l_1070[5]), 9)) , 0x04AB6468L) , (*g_541)))) , p_24)) , (void*)0));
                        (*l_1211) ^= ((void*)0 != l_1259);
                        (*g_177) = ((((l_1255 > (*l_1212)) , (((safe_mod_func_int16_t_s_s_unsafe_macro/*230*//* ___SAFE__OP */(((~l_1258) , (safe_div_func_uint8_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */((~((*l_1266) = p_24)), (~l_1258)))), g_342)) <= (-6L)) && (safe_lshift_func_uint8_t_u_u_unsafe_macro/*232*//* ___SAFE__OP */((g_1270 , 255UL), 4)))) , 1L) < p_25);
                    }
                }
                if (((((((--(*l_1094)) ^ (l_1273 != l_1235)) | 0x6659FC14L) <= (safe_sub_func_int8_t_s_s_unsafe_macro/*233*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s_unsafe_macro/*234*//* ___SAFE__OP */((g_752[5][4][0] , ((l_1223[1] ^= (((l_1220 = ((*l_1279) |= p_23)) , (((*l_1282) = l_1280) == (l_1111[7] , l_1280))) && 0x7579A553956E8324LL)) != p_23)), l_1190)), p_23))) , l_1283) != (**l_1153)))
                { /* block id: 615 */
                    int8_t l_1291 = 0xEFL;
                    for (g_559 = 5; (g_559 != 5); g_559 = safe_add_func_uint32_t_u_u_unsafe_macro/*235*//* ___SAFE__OP */(g_559, 6))
                    { /* block id: 618 */
                        uint16_t l_1290 = 0xC0FBL;
                        int32_t l_1292 = 0xB96A1C94L;
                        (*l_1211) &= (g_98 ^ ((0x7C47084A48F83EB8LL >= 4L) , (-6L)));
                        l_1292 |= ((safe_sub_func_uint64_t_u_u_unsafe_macro/*236*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*237*//* ___SAFE__OP */(0xA83EC9A8L, 4294967295UL)), l_1290)) ^ (g_204 <= l_1291));
                    }
                    if ((safe_add_func_int32_t_s_s_unsafe_macro/*238*//* ___SAFE__OP */(6L, (safe_lshift_func_int32_t_s_u_unsafe_macro/*239*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u_unsafe_macro/*240*//* ___SAFE__OP */(l_1299, 17)), (safe_lshift_func_uint16_t_u_u_unsafe_macro/*241*//* ___SAFE__OP */(p_24, 8)))))))
                    { /* block id: 622 */
                        if (l_1222)
                            break;
                    }
                    else
                    { /* block id: 624 */
                        int64_t l_1302 = 0x91372E909733B42ALL;
                        if (g_32)
                            goto lbl_1174;
                        return l_1302;
                    }
                }
                else
                { /* block id: 628 */
                    if (l_1222)
                        goto lbl_1303;
                    return l_1304;
                }
            }
            else
            { /* block id: 632 */
                int32_t l_1307 = 8L;
                int64_t *l_1316 = &g_749;
                int32_t *l_1319 = (void*)0;
                int32_t l_1320 = 0xB092CFA8L;
                int32_t *l_1321 = &l_1216;
                (*l_1321) |= (l_1320 ^= (safe_mod_func_uint8_t_u_u_unsafe_macro/*242*//* ___SAFE__OP */(l_1307, (safe_add_func_uint8_t_u_u_unsafe_macro/*243*//* ___SAFE__OP */(((****l_1153) |= ((((safe_sub_func_int64_t_s_s_unsafe_macro/*244*//* ___SAFE__OP */(g_1017[0][0].f1, (safe_rshift_func_int64_t_s_u_unsafe_macro/*245*//* ___SAFE__OP */((0x84L | l_1307), g_722)))) | p_24) > (l_1215 = g_51[3][5])) , (safe_add_func_uint8_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */((((*l_1316) = g_46) ^ (safe_rshift_func_int32_t_s_s_unsafe_macro/*247*//* ___SAFE__OP */((*g_242), 7))), g_125[4])))), (-1L))))));
                (*l_1321) ^= p_24;
            }
            for (g_241 = (-10); (g_241 == (-8)); g_241++)
            { /* block id: 642 */
                int32_t *l_1330 = &l_1217;
                int32_t l_1343 = (-1L);
                int32_t l_1349[7] = {0x79C1D7E5L,0x79C1D7E5L,0x79C1D7E5L,0x79C1D7E5L,0x79C1D7E5L,0x79C1D7E5L,0x79C1D7E5L};
                int i;
                if ((*g_1096))
                { /* block id: 643 */
                    for (l_1219 = (-20); (l_1219 <= (-24)); l_1219 = safe_sub_func_uint16_t_u_u_unsafe_macro/*248*//* ___SAFE__OP */(l_1219, 5))
                    { /* block id: 646 */
                        const int32_t * const l_1326 = (void*)0;
                        const int32_t *l_1328 = &l_1217;
                        const int32_t **l_1327 = &l_1328;
                        (*l_1327) = l_1326;
                        if (p_25)
                            break;
                    }
                }
                else
                { /* block id: 650 */
                    int32_t **l_1329 = &g_154;
                    (*l_1329) = &l_1190;
                    if ((0xC4L | p_25))
                    { /* block id: 652 */
                        (**l_1329) = 0xB4BD0C5CL;
                        l_1331 = ((*l_1329) = l_1330);
                    }
                    else
                    { /* block id: 656 */
                        (*l_1329) = (*l_1329);
                    }
                }
                for (g_98 = 1; (g_98 < 4); g_98 = safe_add_func_int8_t_s_s_unsafe_macro/*249*//* ___SAFE__OP */(g_98, 1))
                { /* block id: 662 */
                    int16_t l_1336[8][7] = {{0x5C98L,0x5C98L,1L,0x5C98L,0x5C98L,1L,0x5C98L},{0x4C46L,1L,1L,0x4C46L,1L,1L,0x4C46L},{(-1L),0x5C98L,(-1L),(-1L),0x5C98L,(-1L),(-1L)},{0x4C46L,0x4C46L,0xC4D3L,0x4C46L,0x4C46L,0xC4D3L,0x4C46L},{0x5C98L,(-1L),(-1L),0x5C98L,(-1L),(-1L),0x5C98L},{1L,0x4C46L,1L,1L,0x4C46L,1L,1L},{0x5C98L,0x5C98L,1L,0x5C98L,0x5C98L,1L,0x5C98L},{0x4C46L,1L,1L,0x4C46L,1L,1L,0x4C46L}};
                    int32_t l_1348[3][10][7] = {{{4L,(-6L),0xD6EEE5BBL,0xAF55FEF5L,0x338CD4D2L,(-1L),(-1L)},{0x338CD4D2L,(-4L),0xE8EA26E2L,(-4L),0x338CD4D2L,4L,0x6B974C67L},{6L,(-4L),0xB9577EE2L,0x153D63CEL,0x995C6EDCL,(-1L),0x6B974C67L},{4L,0x153D63CEL,0x05D2C034L,0xAF55FEF5L,6L,0xBCAE0F87L,(-1L)},{6L,0x153D63CEL,0xE8EA26E2L,(-6L),7L,4L,0x64ED6A4BL},{0x338CD4D2L,(-4L),0x05D2C034L,(-6L),0x995C6EDCL,0x424A4E23L,0x3B6327A5L},{4L,(-4L),0xB9577EE2L,0xAF55FEF5L,7L,0x424A4E23L,(-1L)},{7L,(-6L),0xE8EA26E2L,0x153D63CEL,6L,4L,0x3B6327A5L},{7L,(-4L),0xD6EEE5BBL,(-4L),0x995C6EDCL,0xBCAE0F87L,0x64ED6A4BL},{4L,(-6L),0xD6EEE5BBL,0xAF55FEF5L,0x338CD4D2L,0xE8EA26E2L,0xE8EA26E2L}},{{(-1L),0x875BA351L,0x08B9401FL,0x875BA351L,(-1L),0x918D4FCEL,0xD6EEE5BBL},{0x424A4E23L,1L,1L,1L,0x97ED899AL,0xE8EA26E2L,0xD6EEE5BBL},{0L,1L,(-8L),1L,0x424A4E23L,(-6L),0xE8EA26E2L},{0x424A4E23L,1L,0x08B9401FL,0x06555138L,0xBCAE0F87L,0x918D4FCEL,0xB9577EE2L},{(-1L),1L,(-8L),0x06555138L,0x97ED899AL,5L,0x05D2C034L},{0L,0x875BA351L,1L,1L,0xBCAE0F87L,5L,0xE8EA26E2L},{0xBCAE0F87L,0x06555138L,0x08B9401FL,1L,0x424A4E23L,0x918D4FCEL,0x05D2C034L},{0xBCAE0F87L,1L,4L,0x875BA351L,0x97ED899AL,(-6L),0xB9577EE2L},{0L,0x06555138L,4L,1L,(-1L),0xE8EA26E2L,0xE8EA26E2L},{(-1L),0x875BA351L,0x08B9401FL,0x875BA351L,(-1L),0x918D4FCEL,0xD6EEE5BBL}},{{0x424A4E23L,1L,1L,1L,0x97ED899AL,0xE8EA26E2L,0xD6EEE5BBL},{0L,1L,(-8L),1L,0x424A4E23L,(-6L),0xE8EA26E2L},{0x424A4E23L,1L,0x08B9401FL,0x06555138L,0xBCAE0F87L,0x918D4FCEL,0xB9577EE2L},{(-1L),1L,(-8L),0x06555138L,0x97ED899AL,5L,0x05D2C034L},{0L,0x875BA351L,1L,1L,0xBCAE0F87L,5L,0xE8EA26E2L},{0xBCAE0F87L,0x06555138L,0x08B9401FL,1L,0x424A4E23L,0x918D4FCEL,0x05D2C034L},{0xBCAE0F87L,1L,4L,0x875BA351L,0x97ED899AL,(-6L),0xB9577EE2L},{0L,0x06555138L,4L,1L,(-1L),0xE8EA26E2L,0xE8EA26E2L},{(-1L),0x875BA351L,0x08B9401FL,0x875BA351L,(-1L),0x918D4FCEL,0xD6EEE5BBL},{0x424A4E23L,1L,1L,1L,0x97ED899AL,0xE8EA26E2L,0xD6EEE5BBL}}};
                    int i, j, k;
                    for (g_546 = 0; (g_546 == 2); g_546 = safe_add_func_uint32_t_u_u_unsafe_macro/*250*//* ___SAFE__OP */(g_546, 6))
                    { /* block id: 665 */
                        int32_t *l_1337 = (void*)0;
                        int32_t *l_1338 = &l_1216;
                        int32_t *l_1339 = &l_1125;
                        int32_t *l_1340 = &l_1124;
                        int32_t *l_1341 = (void*)0;
                        int32_t *l_1342 = &g_178;
                        int32_t *l_1344 = &l_1190;
                        int32_t *l_1345 = &l_1215;
                        int32_t *l_1346 = &l_1069;
                        int32_t *l_1347[4];
                        int32_t **l_1354 = &l_1341;
                        uint8_t ***l_1369 = &l_1046;
                        int64_t *l_1373 = &g_125[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_1347[i] = &l_1219;
                        l_1351++;
                        (*l_1354) = (void*)0;
                        if (g_733.f0)
                            goto lbl_1174;
                        (*l_1330) |= ((((safe_mul_func_int64_t_s_s_unsafe_macro/*251*//* ___SAFE__OP */(((*l_1373) |= (safe_sub_func_uint32_t_u_u_unsafe_macro/*252*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*253*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*254*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u_unsafe_macro/*255*//* ___SAFE__OP */(p_24, g_203[5].f2)), (l_1348[1][7][6] = l_1070[0]))), (safe_rshift_func_int8_t_s_s_unsafe_macro/*256*//* ___SAFE__OP */(p_25, ((*l_1346) = ((safe_lshift_func_int16_t_s_s_unsafe_macro/*257*//* ___SAFE__OP */((((void*)0 != l_1369) | (((safe_add_func_uint64_t_u_u_unsafe_macro/*258*//* ___SAFE__OP */(l_1372, g_546)) > (l_1190 = 0xEED6C69FL)) >= 0x36L)), 10)) < p_23)))))), 4294967295UL))), l_1374)) < 247UL) != l_1375) ^ g_752[1][3][3]);
                    }
                    for (l_1220 = 0; (l_1220 <= 2); l_1220 += 1)
                    { /* block id: 677 */
                        int32_t *l_1377[2][4][10] = {{{&l_1225,&l_1226[2][3][6],&l_1070[3],&l_1038,&l_1221,(void*)0,&l_1069,&l_1225,&l_1038,&l_1349[6]},{&g_178,&l_1223[2],&l_1070[3],&l_1221,&l_1218,&l_1225,&g_51[1][0],&g_178,&l_1070[3],&l_1349[6]},{(void*)0,&l_1226[0][6][7],(void*)0,&g_46,&l_1221,(void*)0,&g_51[1][0],(void*)0,&l_1221,&g_46},{&l_1223[2],&l_1223[2],&l_1223[2],&g_46,&l_1349[6],&l_1070[3],&l_1069,&l_1223[2],&l_1070[3],&g_46}},{{&l_1223[2],&l_1226[2][3][6],&g_178,&l_1221,&l_1070[3],(void*)0,(void*)0,&l_1223[2],&l_1223[2],&l_1226[0][6][7]},{&l_1226[1][6][3],&l_1125,(void*)0,&l_1223[2],&l_1226[0][6][7],&l_1124,&g_46,&l_1226[1][6][3],&l_1225,&l_1225},{&l_1126,&l_1125,(void*)0,&g_178,&g_178,(void*)0,&l_1125,&l_1126,&l_1225,&l_1070[3]},{&l_1124,&l_1122,&l_1220,&l_1223[2],(void*)0,(void*)0,&l_1221,&l_1124,&l_1223[2],&g_178}}};
                        int i, j, k;
                        (*g_1376) = &l_1069;
                        if (l_1348[2][1][5])
                            continue;
                        ++l_1378;
                        (*l_1330) &= (((safe_add_func_uint8_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */((((safe_lshift_func_int32_t_s_s_unsafe_macro/*260*//* ___SAFE__OP */((**g_331), 23)) <= (l_1111[7] , p_25)) > ((*l_1093) = p_25)), p_23)) | 0x8042L) <= (p_25 && g_125[0]));
                    }
                }
            }
        }
    }
    for (g_121 = 0; (g_121 == 1); g_121 = safe_add_func_int8_t_s_s_unsafe_macro/*261*//* ___SAFE__OP */(g_121, 4))
    { /* block id: 690 */
        uint16_t l_1389[7][4] = {{0xEE01L,0xB6EFL,0xEE01L,0x4E4AL},{0xEE01L,0x4E4AL,0x4E4AL,0xEE01L},{0x3A55L,0x4E4AL,0xB9D7L,0x4E4AL},{0x4E4AL,0xB6EFL,0xB9D7L,0xB9D7L},{0x3A55L,0x3A55L,0x4E4AL,0xB9D7L},{0xEE01L,0xB6EFL,0xEE01L,0x4E4AL},{0xEE01L,0x4E4AL,0x4E4AL,0xEE01L}};
        int i, j;
        for (g_193 = 0; (g_193 != 44); g_193 = safe_add_func_int8_t_s_s_unsafe_macro/*262*//* ___SAFE__OP */(g_193, 4))
        { /* block id: 693 */
            l_1389[2][3] = 0x226DEFFCL;
            if (l_1032)
                break;
        }
    }
    for (p_24 = 0; (p_24 <= 2); p_24 += 1)
    { /* block id: 700 */
        union U1 *l_1390 = &l_1111[3];
        union U1 **l_1391 = &g_732;
        int32_t l_1413[10];
        int32_t l_1415 = 0xAE20E7ACL;
        uint8_t l_1425 = 255UL;
        uint8_t **l_1518[8] = {&g_936,&g_936,&g_936,&g_936,&g_936,&g_936,&g_936,&g_936};
        int32_t *l_1592 = (void*)0;
        int32_t **l_1591 = &l_1592;
        int32_t ***l_1590 = &l_1591;
        uint32_t ** const *l_1642 = &l_1640;
        uint16_t *l_1644 = &g_1477;
        int32_t ***l_1745 = &l_1528;
        int32_t *****l_1760 = &l_1526;
        int i;
        for (i = 0; i < 10; i++)
            l_1413[i] = 0x91DEE2D0L;
        (*l_1391) = l_1390;
        for (g_81 = 0; (g_81 <= 2); g_81 += 1)
        { /* block id: 704 */
            int16_t *l_1395 = &g_241;
            int16_t *l_1400 = (void*)0;
            int16_t *l_1401 = &g_723;
            int32_t l_1422[4][5];
            uint32_t ****l_1460 = &g_1456;
            union U1 **l_1531 = (void*)0;
            uint32_t *l_1539[3][9] = {{&g_98,&g_98,&l_1372,&g_98,&g_81,&g_81,&g_98,&l_1372,&g_98},{&g_81,&g_81,(void*)0,&g_81,&g_81,&g_98,&g_81,&g_81,&g_98},{&g_81,&l_1372,&l_1372,&l_1372,&g_81,&g_81,&g_98,(void*)0,&g_98}};
            int32_t l_1557 = (-2L);
            struct S0 **l_1558 = (void*)0;
            int32_t l_1581[6] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
            uint16_t l_1602 = 0x0D0DL;
            uint32_t *****l_1667[10][8][3] = {{{&g_1455[6],&l_1460,&g_1455[5]},{&g_1455[1],&l_1460,&l_1460},{&l_1061,&l_1460,(void*)0},{&l_1460,&l_1460,&l_1061},{(void*)0,&l_1460,&g_1455[3]},{(void*)0,&l_1460,&g_1455[3]},{(void*)0,(void*)0,&l_1061},{&l_1460,(void*)0,&g_1455[3]}},{{&l_1460,&g_1455[5],&g_1455[3]},{&g_1455[4],&l_1460,&l_1061},{&l_1061,(void*)0,(void*)0},{&l_1061,&l_1061,&l_1460},{&g_1455[4],&g_1455[3],&g_1455[5]},{&l_1460,&g_1455[3],(void*)0},{&l_1460,&l_1061,(void*)0},{(void*)0,&g_1455[3],&l_1460}},{{(void*)0,&g_1455[3],&l_1460},{(void*)0,&l_1061,&l_1460},{&l_1460,(void*)0,&l_1460},{&l_1061,&l_1460,&l_1460},{&g_1455[1],&g_1455[5],&l_1460},{&g_1455[6],(void*)0,(void*)0},{&g_1455[5],(void*)0,(void*)0},{&g_1455[6],&l_1460,&g_1455[5]}},{{&g_1455[1],&l_1460,&l_1460},{&l_1061,&l_1460,(void*)0},{&l_1460,&l_1460,&l_1061},{(void*)0,&l_1460,&g_1455[3]},{(void*)0,&l_1460,&g_1455[3]},{(void*)0,(void*)0,&l_1061},{&l_1061,&g_1455[1],(void*)0},{(void*)0,&g_1455[3],(void*)0}},{{&l_1460,(void*)0,&l_1061},{&l_1061,&g_1455[3],&g_1455[3]},{&l_1061,&l_1061,(void*)0},{&l_1460,(void*)0,&g_1455[3]},{(void*)0,(void*)0,&g_1455[1]},{&l_1061,&g_1455[6],&l_1061},{&g_1455[3],(void*)0,(void*)0},{&g_1455[1],(void*)0,&l_1061}},{{&l_1460,&l_1061,&l_1460},{&l_1460,&g_1455[3],&l_1460},{&g_1455[5],(void*)0,&l_1061},{&l_1460,&g_1455[3],(void*)0},{&l_1460,&g_1455[1],&l_1061},{&g_1455[3],&l_1061,&g_1455[1]},{&l_1460,(void*)0,&g_1455[3]},{&l_1460,&l_1061,(void*)0}},{{&g_1455[5],&l_1460,&g_1455[3]},{&l_1460,&l_1460,&l_1061},{&l_1460,&l_1061,(void*)0},{&g_1455[1],(void*)0,(void*)0},{&g_1455[3],&l_1061,&g_1455[6]},{&l_1061,&g_1455[1],(void*)0},{(void*)0,&g_1455[3],(void*)0},{&l_1460,(void*)0,&l_1061}},{{&l_1061,&g_1455[3],&g_1455[3]},{&l_1061,&l_1061,(void*)0},{&l_1460,(void*)0,&g_1455[3]},{(void*)0,(void*)0,&g_1455[1]},{&l_1061,&g_1455[6],&l_1061},{&g_1455[3],(void*)0,(void*)0},{&g_1455[1],(void*)0,&l_1061},{&l_1460,&l_1061,&l_1460}},{{&l_1460,&g_1455[3],&l_1460},{&g_1455[5],(void*)0,&l_1061},{&l_1460,&g_1455[3],(void*)0},{&l_1460,&g_1455[1],&l_1061},{&g_1455[3],&l_1061,&g_1455[1]},{&l_1460,(void*)0,&g_1455[3]},{&l_1460,&l_1061,(void*)0},{&g_1455[5],&l_1460,&g_1455[3]}},{{&l_1460,&l_1460,&l_1061},{&l_1460,&l_1061,(void*)0},{&g_1455[1],(void*)0,(void*)0},{&g_1455[3],&l_1061,&g_1455[6]},{&l_1061,&g_1455[1],(void*)0},{(void*)0,&g_1455[3],(void*)0},{&l_1460,(void*)0,&l_1061},{&l_1061,&g_1455[3],&g_1455[3]}}};
            uint8_t l_1730 = 5UL;
            uint16_t **l_1738 = (void*)0;
            uint16_t l_1748 = 65532UL;
            int i, j, k;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                    l_1422[i][j] = 1L;
            }
            if ((safe_sub_func_int64_t_s_s_unsafe_macro/*263*//* ___SAFE__OP */(((((g_322.f2 == ((*l_1401) = (((p_23 ^ p_23) , ((~((*l_1390) , ((((*l_1395) = 0xF627L) == (((*l_1390) , ((*l_1094) = p_23)) >= (safe_mod_func_uint16_t_u_u_unsafe_macro/*264*//* ___SAFE__OP */((((**l_1391) , (safe_div_func_int8_t_s_s_unsafe_macro/*265*//* ___SAFE__OP */(l_1372, l_1070[3]))) | g_203[5].f0), g_32)))) < p_25))) || p_25)) || 0UL))) & p_24) & l_1070[3]) , 0x40BAED3CACB6D4D0LL), g_659[2][0][0])))
            { /* block id: 708 */
                if (l_1374)
                    break;
                if (p_24)
                    break;
            }
            else
            { /* block id: 711 */
                int16_t l_1408[2];
                int32_t l_1417 = 0x067A0229L;
                int32_t l_1420 = 8L;
                int32_t l_1424[3][6] = {{0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL},{0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL},{0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL,0x6B2175DDL}};
                int32_t l_1452 = (-1L);
                uint8_t **l_1519 = &g_936;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_1408[i] = (-5L);
                if ((g_1214 < g_129))
                { /* block id: 712 */
                    int32_t *l_1409 = (void*)0;
                    int32_t *l_1410 = &g_178;
                    uint64_t *l_1414[8];
                    int32_t l_1423[7] = {(-5L),3L,3L,(-5L),3L,3L,(-5L)};
                    int32_t *l_1469 = &l_1374;
                    int32_t *l_1470 = &g_178;
                    int32_t *l_1471 = &l_1070[1];
                    int32_t *l_1472 = &g_178;
                    int32_t *l_1473 = &l_1423[5];
                    int32_t *l_1474 = (void*)0;
                    int32_t *l_1475 = (void*)0;
                    int32_t *l_1476[5][3] = {{&l_1070[3],&l_1424[1][3],&l_1070[3]},{&g_51[2][5],&l_1423[0],&g_51[2][5]},{&l_1070[3],&l_1424[1][3],&l_1070[3]},{&g_51[2][5],&l_1423[0],&g_51[2][5]},{&l_1070[3],&l_1424[1][3],&l_1070[3]}};
                    int i, j;
                    for (i = 0; i < 8; i++)
                        l_1414[i] = &g_206;
                    if (((safe_sub_func_int64_t_s_s_unsafe_macro/*266*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*267*//* ___SAFE__OP */((g_1017[0][0].f1 || (l_1415 ^= ((l_1413[3] = ((safe_add_func_uint32_t_u_u_unsafe_macro/*268*//* ___SAFE__OP */((((((*l_1410) = l_1408[1]) , ((*l_1395) |= (((*l_1410) = 0x64L) >= ((void*)0 == &g_241)))) && (p_24 > ((*l_1094) = (l_1304 != l_1413[3])))) & (p_25 || 0x2DL)), p_23)) | 0xF300C44DL)) , 0xAA46A42D9E19C1B8LL))), l_1416)), p_23)) > p_24))
                    { /* block id: 719 */
                        int32_t *l_1418 = &l_1038;
                        int32_t *l_1419 = &l_1070[5];
                        int32_t *l_1421[4][3] = {{&g_51[4][2],&g_51[4][2],&g_51[4][2]},{&g_51[4][2],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&l_1070[3],&g_51[4][2],(void*)0}};
                        int i, j;
                        l_1425++;
                    }
                    else
                    { /* block id: 721 */
                        uint64_t l_1428 = 1UL;
                        int64_t l_1445 = 0x8653296EB68B70F2LL;
                        uint32_t *****l_1457 = &l_1061;
                        l_1428 ^= l_1424[1][3];
                        l_1415 ^= (safe_add_func_uint32_t_u_u_unsafe_macro/*269*//* ___SAFE__OP */(((safe_mul_func_int32_t_s_s_unsafe_macro/*270*//* ___SAFE__OP */(p_23, ((safe_mul_func_uint32_t_u_u_unsafe_macro/*271*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*272*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*273*//* ___SAFE__OP */((l_1420 ^ (((l_1424[2][2] &= ((l_1413[3] ^= l_1428) <= (safe_lshift_func_int32_t_s_s_unsafe_macro/*274*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*275*//* ___SAFE__OP */((l_1428 == (safe_add_func_uint8_t_u_u_unsafe_macro/*276*//* ___SAFE__OP */((l_1445 > ((safe_mul_func_int8_t_s_s_unsafe_macro/*277*//* ___SAFE__OP */((255UL != l_1425), (l_1452 = (((*l_1410) || (safe_div_func_int64_t_s_s_unsafe_macro/*278*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*279*//* ___SAFE__OP */(l_1417, p_24)), 0x6175AEF336E24D7BLL))) , p_24)))) , p_25)), 0x80L))), 13)), 20)))) >= l_1038) > p_23)), p_23)), p_25)), p_23)) & l_1422[2][1]))) > p_25), 7UL));
                        (*l_1410) = (((safe_mul_func_int16_t_s_s_unsafe_macro/*280*//* ___SAFE__OP */((&g_542[3] == ((*l_1457) = g_1455[3])), (safe_rshift_func_int8_t_s_s_unsafe_macro/*281*//* ___SAFE__OP */(((l_1422[2][1] <= (l_1374 = (l_1460 != &g_542[3]))) , (safe_lshift_func_uint64_t_u_u_unsafe_macro/*282*//* ___SAFE__OP */(p_25, (((((((*g_1096) = (safe_div_func_int16_t_s_s_unsafe_macro/*283*//* ___SAFE__OP */((0xF511L & ((safe_add_func_uint16_t_u_u_unsafe_macro/*284*//* ___SAFE__OP */((g_752[5][4][4]++), 1L)) , ((***g_541) != (void*)0))), l_1425))) <= l_1413[1]) == l_1452) > l_1416) || 0x55L) , 18446744073709551615UL)))), 5)))) , g_752[4][3][2]) == 1UL);
                    }
                    g_1477--;
                    l_1070[1] ^= (safe_rshift_func_uint8_t_u_s_unsafe_macro/*285*//* ___SAFE__OP */(p_23, ((void*)0 != l_1041[9])));
                }
                else
                { /* block id: 735 */
                    int8_t l_1493 = 1L;
                    int32_t l_1512 = 0x2887993CL;
                    const uint8_t *l_1521 = &g_121;
                    const uint8_t **l_1520 = &l_1521;
                    int32_t *l_1524[10][8][3] = {{{&g_46,(void*)0,&l_1415},{&l_1420,&l_1416,&l_1422[2][4]},{&l_1422[2][4],(void*)0,&l_1417},{&g_51[0][6],&l_1512,&l_1415},{&l_1422[2][4],(void*)0,(void*)0},{&l_1420,(void*)0,&l_1374},{&g_46,(void*)0,&l_1424[1][3]},{&l_1415,(void*)0,&l_1420}},{{(void*)0,&l_1512,&l_1512},{(void*)0,(void*)0,&l_1420},{(void*)0,&l_1416,&l_1424[1][3]},{(void*)0,(void*)0,&l_1374},{(void*)0,&l_1038,(void*)0},{(void*)0,&l_1416,&l_1415},{(void*)0,&g_745,&l_1417},{(void*)0,&l_1416,&l_1422[2][4]}},{{&l_1415,&l_1038,&l_1415},{&g_46,(void*)0,&l_1415},{&l_1420,&l_1416,&l_1422[2][4]},{&l_1422[2][4],(void*)0,&l_1417},{&g_51[0][6],&l_1512,&l_1415},{&l_1422[2][4],(void*)0,(void*)0},{&l_1420,(void*)0,&l_1374},{&g_46,(void*)0,&l_1424[1][3]}},{{&l_1415,(void*)0,&l_1420},{(void*)0,&l_1512,&l_1512},{(void*)0,(void*)0,&l_1420},{(void*)0,&l_1416,&l_1424[1][3]},{(void*)0,(void*)0,&l_1374},{(void*)0,&l_1038,(void*)0},{(void*)0,&l_1416,&l_1415},{(void*)0,&g_745,&l_1417}},{{(void*)0,&l_1416,&l_1422[2][4]},{&l_1415,&l_1038,&l_1415},{&g_46,(void*)0,&l_1415},{&l_1420,&l_1416,&l_1422[2][4]},{&l_1422[2][4],(void*)0,&l_1417},{&g_51[0][6],&l_1512,&l_1415},{&l_1422[2][4],(void*)0,(void*)0},{&l_1420,(void*)0,&l_1374}},{{&g_46,(void*)0,&l_1424[1][3]},{&l_1415,(void*)0,&l_1420},{(void*)0,&l_1512,&l_1512},{(void*)0,(void*)0,&l_1420},{(void*)0,&l_1416,&l_1424[1][3]},{(void*)0,(void*)0,&l_1374},{(void*)0,&l_1038,(void*)0},{(void*)0,&l_1416,&l_1415}},{{(void*)0,&g_745,&l_1417},{(void*)0,&l_1416,&l_1422[2][4]},{&l_1415,&l_1038,&l_1415},{&g_46,(void*)0,&l_1415},{&l_1420,&l_1416,&l_1422[2][4]},{&l_1422[2][4],(void*)0,&l_1417},{&g_51[0][6],&l_1512,&l_1415},{&l_1422[2][4],(void*)0,(void*)0}},{{&l_1420,(void*)0,&l_1374},{&g_46,(void*)0,&l_1424[1][3]},{&l_1415,(void*)0,&l_1420},{(void*)0,&l_1512,&l_1416},{&g_51[4][1],(void*)0,&l_1070[3]},{&g_51[0][6],&l_1417,&l_1374},{&l_1416,(void*)0,&l_1374},{&l_1416,&l_1413[4],&g_51[4][1]}},{{&g_51[0][6],&l_1424[1][3],&l_1424[1][3]},{&g_51[4][1],&l_1512,&l_1374},{&g_178,&l_1424[1][3],&l_1512},{(void*)0,&l_1413[4],(void*)0},{&l_1413[3],(void*)0,(void*)0},{&l_1070[3],&l_1417,&l_1512},{&l_1512,(void*)0,&l_1374},{&g_51[0][6],(void*)0,&l_1424[1][3]}},{{&l_1512,&l_1420,&g_51[4][1]},{&l_1070[3],(void*)0,&l_1374},{&l_1413[3],(void*)0,&l_1374},{(void*)0,&l_1420,&l_1070[3]},{&g_178,(void*)0,&l_1416},{&g_51[4][1],(void*)0,&l_1070[3]},{&g_51[0][6],&l_1417,&l_1374},{&l_1416,(void*)0,&l_1374}}};
                    int i, j, k;
                    if (((safe_sub_func_uint32_t_u_u_unsafe_macro/*286*//* ___SAFE__OP */((l_1452 || (safe_add_func_int8_t_s_s_unsafe_macro/*287*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*288*//* ___SAFE__OP */(p_24, (safe_mul_func_int32_t_s_s_unsafe_macro/*289*//* ___SAFE__OP */(((safe_unary_minus_func_int64_t_s_unsafe_macro/*290*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_s_unsafe_macro/*291*//* ___SAFE__OP */((g_811 ^ g_1227), 4)) != (l_1493 = l_1422[0][4])))) , (safe_mul_func_uint32_t_u_u_unsafe_macro/*292*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u_unsafe_macro/*293*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*294*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s_unsafe_macro/*295*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*296*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*297*//* ___SAFE__OP */(((safe_mul_func_int8_t_s_s_unsafe_macro/*298*//* ___SAFE__OP */(l_1408[0], (g_659[2][0][3] && (g_342 | ((((safe_lshift_func_uint64_t_u_u_unsafe_macro/*299*//* ___SAFE__OP */(((((safe_lshift_func_int32_t_s_s_unsafe_macro/*300*//* ___SAFE__OP */(0x4EF6399DL, 16)) & (*g_936)) ^ l_1493) ^ 0x05L), l_1493)) > p_25) >= l_1424[1][3]) & 6UL))))) >= l_1493), l_1415)), l_1422[2][1])), l_1038)), l_1413[3])), l_1420)) || 6UL), p_23))), l_1512)))), 0L))), 0x4B98DD08L)) != 2UL))
                    { /* block id: 737 */
                        int32_t **l_1513[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1513[i] = &g_154;
                        (*g_153) = (g_1017[0][0].f2 , &l_1413[3]);
                    }
                    else
                    { /* block id: 739 */
                        int16_t l_1517 = 0xE0B8L;
                        uint16_t l_1522 = 0x6F2CL;
                        int32_t l_1523 = (-4L);
                        l_1523 = (p_23 == ((((((((~l_1517) <= ((*l_1094) = p_23)) || l_1422[2][2]) >= 0UL) >= ((l_1519 = l_1518[2]) != l_1520)) ^ (((p_25 , ((void*)0 != &g_546)) , &l_1094) == (void*)0)) < l_1522) , g_993[0][0][2]));
                    }
                    l_1070[3] |= 0xD18623BFL;
                    return g_1079.f2;
                }
                if (l_1422[1][0])
                    continue;
                for (g_241 = 9; (g_241 >= 0); g_241 -= 1)
                { /* block id: 750 */
                    uint64_t *l_1536 = &g_559;
                    int i, j;
                    (*g_1525) = &l_1422[(p_24 + 1)][(g_81 + 1)];
                    (*g_154) |= (*g_242);
                    l_1413[0] = (((((l_1526 == &g_548) && ((((safe_sub_func_uint32_t_u_u_unsafe_macro/*301*//* ___SAFE__OP */((l_1531 == &g_361), (l_1422[(p_24 + 1)][(g_81 + 1)] = ((safe_lshift_func_uint16_t_u_s_unsafe_macro/*302*//* ___SAFE__OP */((((((safe_sub_func_int64_t_s_s_unsafe_macro/*303*//* ___SAFE__OP */(((g_1017[0][0] , l_1425) , g_518.f0), ((*l_1536)--))) && p_24) >= (l_1539[2][5] != (***l_1460))) != g_51[1][1]) ^ p_24), 7)) != 4294967289UL)))) != p_24) && 0x0D9CD0B05B207734LL) , l_1415)) != (-5L)) != p_24) ^ g_1477);
                }
            }
        }
        for (g_32 = 4; (g_32 >= 0); g_32 -= 1)
        { /* block id: 864 */
            l_1760 = &g_1626;
        }
        return p_25;
    }
    return p_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_129 g_31 g_154 g_51 g_121 g_732 g_745 g_178 g_813 g_125 g_241 g_193 g_204 g_49 g_559 g_749 g_206 g_659 g_932 g_733 g_153 g_934 g_935 g_936 g_546 g_933 g_752 g_987 g_46 g_177 g_1017
 * writes: g_32 g_46 g_51 g_206 g_154 g_121 g_81 g_732 g_361 g_125 g_749 g_752 g_178 g_745 g_241 g_204 g_559 g_129 g_723 g_193 g_31
 */
static uint8_t  func_28(int8_t  p_29, int8_t * p_30)
{ /* block id: 1 */
    uint32_t l_43 = 0UL;
    int32_t l_775 = 7L;
    int32_t l_781 = (-6L);
    int32_t l_789 = 0xD7296448L;
    int32_t l_790 = 1L;
    int32_t l_795[4];
    union U1 l_843 = {0x2DEC051AL};
    int8_t **l_984 = &g_31;
    const uint16_t l_999 = 0xFAA3L;
    uint32_t * const *l_1020 = (void*)0;
    uint32_t *l_1025[4] = {&l_843.f0,&l_843.f0,&l_843.f0,&l_843.f0};
    uint64_t *l_1026[10][1][1] = {{{(void*)0}},{{&g_546}},{{(void*)0}},{{&g_546}},{{(void*)0}},{{&g_546}},{{(void*)0}},{{&g_546}},{{(void*)0}},{{&g_546}}};
    uint32_t ***l_1028 = &g_614;
    uint32_t ****l_1027 = &l_1028;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_795[i] = 0x1C0D739FL;
    for (g_32 = 0; (g_32 < 25); ++g_32)
    { /* block id: 4 */
        int8_t **l_430[2][4][1] = {{{&g_31},{(void*)0},{&g_31},{(void*)0}},{{&g_31},{(void*)0},{&g_31},{(void*)0}}};
        int8_t *** const l_429 = &l_430[0][2][0];
        int32_t l_737 = 0xC748C075L;
        uint8_t *l_739 = &g_121;
        uint8_t **l_738 = &l_739;
        union U1 l_742 = {1UL};
        int32_t l_776 = (-9L);
        int32_t l_777 = 0x22D813A4L;
        int32_t l_778[3][4][4] = {{{(-1L),(-1L),0x16FFDD26L,0x0CD2C41CL},{0x0CD2C41CL,0x4D921656L,0x16FFDD26L,0x4D921656L},{(-1L),4L,0xF8314A79L,0x16FFDD26L},{0x4D921656L,4L,4L,0x4D921656L}},{{4L,0x4D921656L,(-1L),0x0CD2C41CL},{4L,(-1L),4L,0xF8314A79L},{0x4D921656L,0x0CD2C41CL,0xF8314A79L,0xF8314A79L},{(-1L),(-1L),0x16FFDD26L,0x0CD2C41CL}},{{0x0CD2C41CL,0x4D921656L,0x16FFDD26L,0x4D921656L},{(-1L),4L,0xF8314A79L,0x16FFDD26L},{0x4D921656L,4L,4L,0x4D921656L},{4L,0x4D921656L,(-1L),0x0CD2C41CL}}};
        uint32_t l_845 = 0x919EB15CL;
        int32_t **l_881[10] = {&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154};
        uint16_t *l_883 = (void*)0;
        int i, j, k;
        if ((l_737 ^= ((*p_30) >= func_35(g_32, p_29, func_41(l_43), &g_32, ((l_429 != &l_430[1][3][0]) , &g_129)))))
        { /* block id: 356 */
            int64_t *l_746 = &g_125[1];
            int64_t *l_747 = (void*)0;
            int64_t *l_748 = &g_749;
            int32_t l_750[6] = {0x508EF5E4L,0x54CFBD47L,0x54CFBD47L,0x508EF5E4L,0x54CFBD47L,0x54CFBD47L};
            uint16_t *l_751 = &g_752[5][4][0];
            int64_t l_779 = (-8L);
            uint32_t **l_838 = &g_228;
            int32_t **l_844 = &g_154;
            int i;
            if ((((void*)0 != l_738) < ((*l_751) = ((safe_add_func_int16_t_s_s_unsafe_macro/*304*//* ___SAFE__OP */((0x5BL & (l_742 , 1UL)), 65534UL)) , ((safe_mul_func_int64_t_s_s_unsafe_macro/*305*//* ___SAFE__OP */((l_742.f0 , ((*l_748) = ((*l_746) = g_745))), (0x3FL >= l_750[1]))) > p_29)))))
            { /* block id: 360 */
                int64_t l_780 = 0L;
                int32_t l_783 = 1L;
                int32_t l_786 = 1L;
                int32_t l_787 = 0xAE70DD88L;
                int32_t l_791 = 1L;
                int32_t l_794 = 0x4F7F8B62L;
                int32_t l_796 = 0x53E81DAAL;
                int32_t l_797 = 1L;
                int32_t l_798[10];
                int i;
                for (i = 0; i < 10; i++)
                    l_798[i] = 0xF92CB344L;
                for (g_178 = 0; (g_178 > 13); g_178 = safe_add_func_int32_t_s_s_unsafe_macro/*306*//* ___SAFE__OP */(g_178, 7))
                { /* block id: 363 */
                    int64_t l_773 = 0x86E28755E908FEF1LL;
                    int32_t l_774 = 0L;
                    int32_t l_782 = (-2L);
                    int32_t l_784 = (-3L);
                    int32_t l_785 = 1L;
                    int32_t l_788 = 0x328ADB1CL;
                    int32_t l_792 = 0x04B7AB7AL;
                    int32_t l_793 = 0x37FB5860L;
                    int32_t l_799 = 0x0E97CE2BL;
                    uint64_t *l_805[6][7][6] = {{{&g_559,&g_559,&g_559,&g_206,&g_559,&g_546},{&g_559,&g_546,&g_546,&g_546,&g_559,(void*)0},{&g_206,&g_559,&g_559,&g_559,&g_559,&g_206},{&g_546,&g_559,&g_546,&g_546,&g_546,&g_546},{&g_559,(void*)0,&g_206,&g_559,&g_206,(void*)0},{&g_559,&g_546,&g_559,&g_546,&g_206,&g_206},{&g_546,&g_546,&g_206,&g_559,(void*)0,(void*)0}},{{&g_206,&g_559,&g_206,&g_546,&g_206,&g_559},{(void*)0,&g_559,&g_546,&g_559,&g_546,&g_546},{&g_546,(void*)0,&g_559,&g_559,(void*)0,(void*)0},{&g_546,&g_206,&g_546,&g_559,&g_559,&g_206},{&g_546,&g_546,(void*)0,&g_206,&g_206,&g_559},{&g_206,&g_206,&g_206,&g_206,&g_546,&g_559},{&g_206,&g_559,&g_546,&g_206,&g_559,&g_206}},{{&g_559,&g_206,&g_559,&g_206,&g_559,&g_206},{&g_206,&g_546,&g_559,&g_206,(void*)0,&g_206},{&g_559,&g_559,&g_206,&g_559,(void*)0,&g_559},{&g_559,&g_206,(void*)0,&g_206,&g_559,&g_206},{&g_206,(void*)0,&g_559,&g_546,&g_546,&g_559},{(void*)0,&g_559,&g_559,(void*)0,&g_559,&g_559},{(void*)0,(void*)0,&g_559,&g_546,&g_546,&g_206}},{{&g_559,&g_206,(void*)0,&g_559,&g_559,&g_559},{(void*)0,(void*)0,&g_206,&g_559,&g_559,&g_206},{&g_546,(void*)0,&g_559,&g_546,&g_559,&g_206},{&g_546,&g_546,&g_559,&g_559,&g_206,&g_206},{&g_546,&g_546,&g_546,&g_559,(void*)0,&g_559},{(void*)0,&g_559,&g_206,&g_546,&g_559,&g_559},{&g_206,&g_546,(void*)0,&g_206,&g_546,&g_206}},{{(void*)0,&g_546,&g_546,&g_559,&g_206,(void*)0},{&g_546,&g_546,&g_559,&g_206,&g_206,&g_546},{&g_559,&g_206,&g_546,&g_546,&g_206,&g_559},{&g_546,(void*)0,&g_206,&g_206,&g_559,&g_559},{&g_559,&g_206,&g_206,&g_559,&g_546,&g_559},{&g_546,&g_206,&g_206,(void*)0,(void*)0,&g_559},{&g_206,&g_546,&g_559,&g_546,(void*)0,&g_206}},{{&g_559,&g_206,(void*)0,&g_559,&g_546,&g_559},{&g_206,&g_206,&g_559,(void*)0,&g_559,&g_559},{&g_559,(void*)0,&g_546,&g_206,&g_206,&g_546},{&g_559,&g_206,(void*)0,(void*)0,&g_206,&g_546},{&g_559,&g_546,(void*)0,&g_206,&g_546,&g_559},{&g_546,&g_559,(void*)0,&g_559,&g_206,(void*)0},{(void*)0,&g_546,&g_559,&g_559,&g_546,&g_559}}};
                    const uint16_t **l_808 = (void*)0;
                    const uint16_t *l_810 = &g_811;
                    const uint16_t **l_809 = &l_810;
                    int i, j, k;
                }
            }
            else
            { /* block id: 380 */
                for (l_737 = (-3); (l_737 == (-30)); l_737 = safe_sub_func_uint32_t_u_u_unsafe_macro/*307*//* ___SAFE__OP */(l_737, 1))
                { /* block id: 383 */
                    uint16_t **l_816 = &l_751;
                    int32_t l_827 = 1L;
                    uint64_t *l_828 = &g_206;
                    (*g_154) = ((l_776 & 0xC593697FL) & ((((&g_811 != ((*l_816) = &g_752[4][1][3])) == ((*g_31) & (safe_mul_func_uint64_t_u_u_unsafe_macro/*308*//* ___SAFE__OP */(0UL, ((*l_828) = (safe_div_func_uint8_t_u_u_unsafe_macro/*309*//* ___SAFE__OP */(((safe_mod_func_int32_t_s_s_unsafe_macro/*310*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*311*//* ___SAFE__OP */((((l_777 ^= ((safe_sub_func_int32_t_s_s_unsafe_macro/*312*//* ___SAFE__OP */(((0UL >= (0xBCFD1846L < l_790)) || 9L), (**g_813))) >= 65535UL)) ^ l_789) || 1L), 9L)), l_827)) , p_29), l_742.f0))))))) < g_129) || 0x201706368EF4A919LL));
                    l_790 ^= (((*l_828) = ((((safe_rshift_func_uint64_t_u_u_unsafe_macro/*313*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*314*//* ___SAFE__OP */(9UL, ((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*315*//* ___SAFE__OP */(1UL, ((*g_31) > (~(0xE9L == (-10L)))))) < (safe_add_func_uint64_t_u_u_unsafe_macro/*316*//* ___SAFE__OP */(((((void*)0 == l_838) >= (((p_29 ^ ((safe_div_func_uint32_t_u_u_unsafe_macro/*317*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u_unsafe_macro/*318*//* ___SAFE__OP */(((g_125[1] != 0xE28FFBE02146CDEFLL) | p_29), p_29)) , l_737), 9UL)) ^ p_29)) , 0x50DBCD00L) == l_827)) != 0x90EAACC63F19D0F0LL), 0xD801FAE977A051C0LL))) >= l_750[1]) < 0UL))), 61)) , l_843) , l_778[2][3][1]) & 0xBFL)) && p_29);
                }
            }
            (*l_844) = &l_781;
            return l_845;
        }
        else
        { /* block id: 394 */
            union U1 * const l_852 = &l_843;
            int32_t l_860 = (-9L);
            uint16_t *l_878 = &g_752[4][3][2];
            uint16_t l_888 = 0xCBB8L;
            for (g_745 = (-20); (g_745 < (-12)); ++g_745)
            { /* block id: 397 */
                const union U1 *l_851[1];
                int16_t *l_853 = &g_241;
                int32_t l_859[6] = {1L,1L,1L,1L,1L,1L};
                uint32_t l_869 = 9UL;
                int32_t **l_882 = &g_154;
                int i;
                for (i = 0; i < 1; i++)
                    l_851[i] = &g_733;
                (*g_154) = (~(l_776 > (l_860 = ((-5L) != (((0L && (*p_30)) == (((l_843.f0 , ((*l_853) ^= (p_29 <= (l_851[0] == l_852)))) || (safe_lshift_func_int64_t_s_u_unsafe_macro/*319*//* ___SAFE__OP */((l_859[5] = (((safe_add_func_uint16_t_u_u_unsafe_macro/*320*//* ___SAFE__OP */((((~l_778[2][3][1]) > g_193) || 0x333F6AB06750FD09LL), l_859[5])) > 4294967286UL) , 7L)), 14))) ^ p_29)) , (*g_31))))));
                for (l_775 = (-9); (l_775 == 7); l_775 = safe_add_func_int8_t_s_s_unsafe_macro/*321*//* ___SAFE__OP */(l_775, 2))
                { /* block id: 404 */
                    const int16_t l_864 = 0x35EFL;
                    int32_t l_868 = 0x12220BA5L;
                    if (((*g_154) ^= ((g_204 = 0x7E27L) == 0UL)))
                    { /* block id: 407 */
                        int8_t l_863 = 0xB0L;
                        if (l_863)
                            break;
                        if (l_864)
                            continue;
                    }
                    else
                    { /* block id: 410 */
                        int32_t *l_865 = &l_859[3];
                        int32_t *l_866 = &l_859[5];
                        int32_t *l_867[5] = {&l_778[2][0][0],&l_778[2][0][0],&l_778[2][0][0],&l_778[2][0][0],&l_778[2][0][0]};
                        int i;
                        ++l_869;
                    }
                    (**l_882) = (safe_mod_func_uint32_t_u_u_unsafe_macro/*322*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u_unsafe_macro/*323*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*324*//* ___SAFE__OP */((l_878 == ((0L & ((safe_mod_func_int8_t_s_s_unsafe_macro/*325*//* ___SAFE__OP */((*g_31), 0xCBL)) != (l_881[8] != l_882))) , l_883)), ((safe_rshift_func_uint32_t_u_u_unsafe_macro/*326*//* ___SAFE__OP */(l_789, 17)) , (safe_sub_func_uint8_t_u_u_unsafe_macro/*327*//* ___SAFE__OP */(p_29, (**l_882)))))), l_888)), p_29));
                    for (p_29 = 0; (p_29 != (-15)); p_29 = safe_sub_func_int16_t_s_s_unsafe_macro/*328*//* ___SAFE__OP */(p_29, 5))
                    { /* block id: 416 */
                        return g_129;
                    }
                    return g_204;
                }
                return g_49;
            }
        }
        for (g_559 = (-11); (g_559 == 23); g_559++)
        { /* block id: 426 */
            int32_t l_924[6] = {0L,0L,0x9ABB2A43L,0L,0L,0x9ABB2A43L};
            int32_t l_925 = (-4L);
            int32_t *l_928[2][9][7] = {{{&l_775,&l_776,&g_178,&l_737,&g_178,(void*)0,(void*)0},{(void*)0,&g_46,&l_789,(void*)0,&l_777,&l_795[2],(void*)0},{&g_46,&g_178,&g_178,&l_775,(void*)0,&g_178,&g_178},{&g_46,&l_778[2][3][1],&g_46,&l_778[2][3][1],&g_46,&l_778[0][1][3],(void*)0},{&g_46,&g_178,&g_178,&l_776,&l_737,&g_46,&l_737},{(void*)0,&g_46,&l_777,&g_745,&l_776,&l_790,&l_781},{&g_46,&l_776,(void*)0,&l_776,(void*)0,(void*)0,&l_776},{&g_46,&l_737,&g_46,&l_790,(void*)0,(void*)0,&l_781},{&g_46,(void*)0,&l_737,(void*)0,&l_795[2],(void*)0,&l_737}},{{(void*)0,&l_795[2],&l_776,(void*)0,&l_781,(void*)0,(void*)0},{&l_775,&g_178,(void*)0,&g_178,&g_178,(void*)0,&g_178},{&l_777,&l_778[0][1][3],(void*)0,(void*)0,&l_781,&l_790,(void*)0},{(void*)0,&g_46,&l_795[2],&g_178,&l_795[2],&g_46,(void*)0},{(void*)0,&l_790,&l_781,(void*)0,(void*)0,&l_778[0][1][3],&l_777},{&g_178,(void*)0,&g_178,&g_178,(void*)0,&g_178,&l_775},{(void*)0,(void*)0,&l_781,(void*)0,&l_776,&l_795[2],(void*)0},{&l_737,(void*)0,&l_795[2],(void*)0,&l_737,(void*)0,&g_46},{&l_781,(void*)0,(void*)0,&l_790,&g_46,&l_737,&g_46}}};
            int16_t l_962 = 0x570AL;
            int16_t l_971 = (-1L);
            int i, j, k;
            if ((safe_sub_func_int64_t_s_s_unsafe_macro/*329*//* ___SAFE__OP */((&l_43 == &l_845), (~(p_29 | (-1L))))))
            { /* block id: 427 */
                uint32_t l_916 = 4294967295UL;
                int32_t ***l_919 = &l_881[9];
                int32_t l_923[7];
                uint32_t *l_948 = (void*)0;
                uint16_t *l_969 = &g_752[3][2][4];
                uint32_t *l_970 = &g_193;
                int i;
                for (i = 0; i < 7; i++)
                    l_923[i] = 9L;
                for (g_204 = 0; (g_204 == (-25)); g_204 = safe_sub_func_uint64_t_u_u_unsafe_macro/*330*//* ___SAFE__OP */(g_204, 7))
                { /* block id: 430 */
                    uint8_t l_898 = 246UL;
                    int32_t l_901[9] = {7L,7L,7L,7L,7L,7L,7L,7L,7L};
                    int32_t l_921 = 3L;
                    int32_t ***l_922 = &l_881[8];
                    int32_t *l_929[1];
                    int32_t * const *l_960[5];
                    int32_t * const **l_959 = &l_960[2];
                    int32_t * const ***l_958 = &l_959;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_929[i] = &l_925;
                    for (i = 0; i < 5; i++)
                        l_960[i] = &l_929[0];
                    if (l_898)
                        break;
                    for (g_121 = (-14); (g_121 > 20); ++g_121)
                    { /* block id: 434 */
                        int16_t *l_914[7];
                        int32_t l_915 = 0x3CF4F51EL;
                        int32_t ****l_920 = &l_919;
                        int i;
                        for (i = 0; i < 7; i++)
                            l_914[i] = &g_723;
                        l_901[2] &= 0xC5FFF840L;
                        l_901[1] |= (safe_lshift_func_int16_t_s_s_unsafe_macro/*331*//* ___SAFE__OP */((!(+(safe_div_func_uint16_t_u_u_unsafe_macro/*332*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*333*//* ___SAFE__OP */(((p_29 > (safe_div_func_int16_t_s_s_unsafe_macro/*334*//* ___SAFE__OP */((l_923[6] = ((**g_813) && (safe_add_func_int32_t_s_s_unsafe_macro/*335*//* ___SAFE__OP */(((*g_154) = 0xF8603EE2L), (g_749 > ((l_916 |= (l_915 ^= g_206)) <= (l_925 = (l_924[1] = (g_125[1] , (safe_sub_func_int32_t_s_s_unsafe_macro/*336*//* ___SAFE__OP */(((((*l_920) = l_919) == (l_921 , l_922)) >= l_923[0]), p_29))))))))))), p_29))) != l_795[2]), g_241)), g_659[2][0][0])))), g_241));
                    }
                    for (p_29 = 0; (p_29 < 17); ++p_29)
                    { /* block id: 447 */
                        l_929[0] = l_928[0][7][6];
                    }
                    for (g_129 = (-29); (g_129 > (-8)); g_129 = safe_add_func_uint8_t_u_u_unsafe_macro/*337*//* ___SAFE__OP */(g_129, 6))
                    { /* block id: 452 */
                        uint8_t ** volatile ** volatile * volatile l_937 = &g_933;/* VOLATILE GLOBAL l_937 */
                        int32_t l_951 = (-6L);
                        int16_t *l_961 = &g_723;
                        l_937 = g_932[1];
                        l_962 ^= (((*l_961) = (safe_div_func_int32_t_s_s_unsafe_macro/*338*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*339*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*340*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*341*//* ___SAFE__OP */((safe_div_func_uint32_t_u_u_unsafe_macro/*342*//* ___SAFE__OP */(((&l_43 == ((*g_732) , l_948)) , (((safe_add_func_int32_t_s_s_unsafe_macro/*343*//* ___SAFE__OP */((l_951 = ((g_206 ^= g_745) | ((((((g_745 , (*p_30)) < (l_951 == (g_125[1] = ((g_125[1] || (safe_add_func_int8_t_s_s_unsafe_macro/*344*//* ___SAFE__OP */((((safe_mod_func_uint8_t_u_u_unsafe_macro/*345*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*346*//* ___SAFE__OP */((l_958 == (void*)0), (**g_153))), p_29)) <= (*p_30)) >= p_29), 5UL))) != l_951)))) , &p_30) == (void*)0) , (***g_934)) && (-1L)))), l_843.f0)) , p_29) <= p_29)), p_29)), 18446744073709551615UL)), (-7L))), g_546)), p_29))) != p_29);
                    }
                }
                l_795[2] &= (safe_div_func_uint32_t_u_u_unsafe_macro/*347*//* ___SAFE__OP */(((*l_970) = (((safe_mul_func_int16_t_s_s_unsafe_macro/*348*//* ___SAFE__OP */((((****g_933) , (p_29 == (p_29 >= (p_29 < 0L)))) < 0xC8DE2EDAL), ((p_29 , func_41((((l_775 |= (*g_936)) & (((*l_969) &= (safe_mod_func_uint16_t_u_u_unsafe_macro/*349*//* ___SAFE__OP */(((g_51[4][2] , p_29) > 18446744073709551615UL), g_206))) & g_178)) != p_29))) != (void*)0))) == l_923[0]) > (*g_31))), l_971));
                return p_29;
            }
            else
            { /* block id: 466 */
                return (*g_936);
            }
        }
    }
    (*g_154) ^= (safe_lshift_func_int64_t_s_s_unsafe_macro/*350*//* ___SAFE__OP */((p_29 >= (((((0xE2L && (**g_935)) == ((safe_mod_func_uint8_t_u_u_unsafe_macro/*351*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*352*//* ___SAFE__OP */(((((safe_rshift_func_uint8_t_u_u_unsafe_macro/*353*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u_unsafe_macro/*354*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*355*//* ___SAFE__OP */((((*l_984) = (void*)0) == &g_659[0][1][0]), (p_29 || (safe_lshift_func_int64_t_s_u_unsafe_macro/*356*//* ___SAFE__OP */((g_987 && ((((0x806CL >= 65535UL) , (-3L)) , g_46) <= 2L)), 18))))), 0x46AFL)) , p_29), 6)) , (*p_30)) != (*g_936)) || g_749), p_29)), 0xE2L)) > 0x31F810AB6297B391LL)) != l_790) == 0xA94C2F7A87564DF2LL) >= p_29)), 12));
    for (g_121 = 0; (g_121 >= 49); g_121 = safe_add_func_uint8_t_u_u_unsafe_macro/*357*//* ___SAFE__OP */(g_121, 6))
    { /* block id: 475 */
        int16_t l_990 = 0xDF31L;
        int32_t l_991[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
        uint8_t *l_992[9][10] = {{&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_121,&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[2][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[2][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[2][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0]},{&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[2][0][0],&g_993[0][0][2],&g_993[0][0][2],&g_993[0][0][2],&g_993[1][0][0],&g_993[1][0][0],&g_993[0][0][2]}};
        uint32_t l_994 = 0x231DD2B6L;
        int32_t l_1009 = 0L;
        int32_t l_1010 = 1L;
        int i, j;
        (*g_154) ^= ((l_994--) == (safe_mul_func_int16_t_s_s_unsafe_macro/*358*//* ___SAFE__OP */(l_999, g_121)));
        l_1010 = ((*g_177) = ((safe_add_func_int16_t_s_s_unsafe_macro/*359*//* ___SAFE__OP */(((p_29 != (((g_206 |= p_29) | p_29) ^ (1UL <= (safe_mul_func_int8_t_s_s_unsafe_macro/*360*//* ___SAFE__OP */((p_29 != (safe_unary_minus_func_int64_t_s_unsafe_macro/*361*//* ___SAFE__OP */(p_29))), (l_1009 &= (safe_mod_func_uint32_t_u_u_unsafe_macro/*362*//* ___SAFE__OP */((l_991[1] = 1UL), 1L)))))))) > (0x9A84L && l_994)), 0x8AE4L)) > 1UL));
    }
    (*g_154) = ((safe_div_func_uint64_t_u_u_unsafe_macro/*363*//* ___SAFE__OP */(((safe_rshift_func_int64_t_s_s_unsafe_macro/*364*//* ___SAFE__OP */((&l_781 == (void*)0), (safe_sub_func_int8_t_s_s_unsafe_macro/*365*//* ___SAFE__OP */(((((((l_781 = (((g_1017[0][0] , p_30) != (void*)0) | (g_559 ^ (l_789 ^ (l_1020 == (((safe_rshift_func_int32_t_s_u_unsafe_macro/*366*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*367*//* ___SAFE__OP */((l_790 = ((l_775 = 7UL) > p_29)), p_29)), p_29)) ^ 0x3E398B36L) , (void*)0)))))) , &g_86) != l_1027) <= g_206) , l_999) <= g_178), (*p_30))))) < p_29), 0x3038178BA9F806CELL)) & l_999);
    return l_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_154 g_206 g_121 g_81 g_31 g_32 g_732
 * writes: g_51 g_206 g_154 g_121 g_81 g_732 g_361
 */
static int8_t  func_35(int32_t  p_36, uint16_t  p_37, int8_t * p_38, int8_t * p_39, int8_t * p_40)
{ /* block id: 176 */
    uint32_t *l_431[3];
    int32_t l_436[8] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
    int32_t l_437 = 0x1C26F647L;
    uint8_t **l_438 = (void*)0;
    int32_t l_440 = 1L;
    uint64_t l_457 = 18446744073709551615UL;
    uint64_t l_485 = 18446744073709551609UL;
    union U1 l_487 = {1UL};
    int32_t **l_506 = &g_154;
    const struct S0 *l_517[2];
    const struct S0 **l_516 = &l_517[1];
    int32_t *l_557 = &l_436[1];
    uint64_t l_582[4][2];
    union U1 **l_734 = &g_732;
    union U1 *l_736 = &g_733;
    union U1 **l_735[6][5][6] = {{{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,(void*)0,(void*)0},{&l_736,(void*)0,(void*)0,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736}},{{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,(void*)0,&l_736,&l_736,(void*)0,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{(void*)0,&l_736,&l_736,&l_736,&l_736,&l_736}},{{(void*)0,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,(void*)0,&l_736,&l_736,(void*)0},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736}},{{&l_736,&l_736,&l_736,&l_736,(void*)0,(void*)0},{&l_736,(void*)0,(void*)0,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,(void*)0,&l_736,&l_736,&l_736,&l_736}},{{&l_736,&l_736,(void*)0,(void*)0,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,(void*)0,(void*)0,&l_736}},{{&l_736,&l_736,&l_736,&l_736,&l_736,(void*)0},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,(void*)0},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736},{&l_736,&l_736,&l_736,&l_736,&l_736,&l_736}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_431[i] = (void*)0;
    for (i = 0; i < 2; i++)
        l_517[i] = &g_203[5];
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
            l_582[i][j] = 18446744073709551615UL;
    }
    (*g_154) = (4294967295UL < ((void*)0 != l_431[2]));
    for (g_206 = (-6); (g_206 == 46); g_206 = safe_add_func_uint16_t_u_u_unsafe_macro/*368*//* ___SAFE__OP */(g_206, 9))
    { /* block id: 180 */
        int32_t *l_434 = &g_51[3][0];
        int32_t **l_435 = &g_154;
        uint8_t **l_439 = (void*)0;
        int32_t l_500[5][2][7] = {{{(-1L),0xB8121743L,0xB8121743L,(-1L),3L,0x64521CD6L,7L},{8L,0L,0xB8121743L,3L,7L,8L,8L}},{{0L,7L,0L,7L,0L,0x5C6EB183L,7L},{(-1L),3L,0x64521CD6L,7L,0xB8121743L,0x64521CD6L,0L}},{{0xB8121743L,0L,3L,3L,0L,0xB8121743L,3L},{(-1L),7L,7L,(-1L),0L,8L,7L}},{{0L,8L,0xB8121743L,0xEA393E00L,0xB8121743L,8L,0L},{8L,7L,3L,0xB8121743L,0L,8L,0xB8121743L}},{{(-1L),0L,8L,7L,7L,8L,0L},{7L,3L,3L,0xEA393E00L,3L,0xB8121743L,0L}}};
        int32_t ***l_512 = (void*)0;
        uint64_t l_535 = 2UL;
        int32_t **l_555 = &g_154;
        uint32_t **l_613 = &g_228;
        uint32_t *l_625 = &l_487.f0;
        union U1 *l_705 = &l_487;
        int i, j, k;
        (*l_435) = l_434;
        l_437 |= ((*l_434) = l_436[2]);
        l_440 |= (l_438 != l_439);
    }
    for (g_121 = 2; (g_121 <= 7); g_121 += 1)
    { /* block id: 343 */
        int i;
        (*l_557) = l_436[g_121];
        (*l_557) = p_37;
        for (g_81 = 0; (g_81 <= 2); g_81 += 1)
        { /* block id: 348 */
            return (*g_31);
        }
    }
    g_361 = ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*369*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*370*//* ___SAFE__OP */((3L < g_32), (safe_mul_func_int16_t_s_s_unsafe_macro/*371*//* ___SAFE__OP */(0L, (safe_rshift_func_int16_t_s_u_unsafe_macro/*372*//* ___SAFE__OP */(g_32, 5)))))), 18)) , ((*l_734) = g_732));
    return (*p_39);
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_51 g_129 g_31 g_32 g_154
 * writes: g_46 g_51
 */
static int8_t * func_41(int32_t  p_42)
{ /* block id: 5 */
    int32_t *l_82 = (void*)0;
    int8_t *l_164 = &g_32;
    int32_t l_368[5][1][10] = {{{0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L,0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L}},{{0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L,0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L}},{{0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L,0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L}},{{0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L,0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L}},{{0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xFD595969L,0x6353CE2CL,0x6F73D7B1L,0x6F73D7B1L,0x6353CE2CL,0xA2663EAAL}}};
    uint32_t l_380 = 6UL;
    int32_t **l_425 = (void*)0;
    int i, j, k;
    for (p_42 = (-22); (p_42 < 4); ++p_42)
    { /* block id: 8 */
        int8_t *l_72 = &g_32;
        int8_t **l_71 = &l_72;
        int8_t **l_79 = &l_72;
        int32_t l_365 = 0L;
        int32_t l_366 = 1L;
        int32_t l_371 = 4L;
        int32_t l_372 = 0x5FD5A456L;
        int32_t l_376 = 0x420F41B5L;
        int32_t l_377 = 0x5E2743C9L;
        int32_t l_378 = 0x1154BF5FL;
        int32_t l_414 = (-5L);
        for (g_46 = 0; (g_46 >= (-7)); g_46 = safe_sub_func_uint32_t_u_u_unsafe_macro/*373*//* ___SAFE__OP */(g_46, 6))
        { /* block id: 11 */
            int8_t **l_76[10] = {&l_72,&l_72,&l_72,&l_72,&l_72,&l_72,&l_72,&l_72,&l_72,&l_72};
            int32_t l_208 = 3L;
            int32_t *l_363[10][2] = {{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178},{&g_178,&g_178}};
            int i, j;
            for (g_51[0][6] = 12; (g_51[0][6] > (-9)); --g_51[0][6])
            { /* block id: 14 */
                int8_t **l_68 = &g_31;
                int8_t *l_70 = &g_32;
                int8_t **l_69 = &l_70;
                int8_t **l_78 = &l_72;
                int8_t ***l_77[6][10][2] = {{{&l_71,&l_68},{&l_76[3],&l_78},{&l_68,&l_76[3]},{&l_71,&l_71},{&l_71,&l_76[3]},{&l_68,&l_78},{&l_76[3],&l_68},{&l_71,&l_78},{(void*)0,&l_76[3]},{&l_76[3],&l_71}},{{&l_76[3],&l_76[3]},{(void*)0,&l_78},{&l_71,&l_68},{&l_76[3],&l_78},{&l_68,&l_76[3]},{&l_71,&l_71},{&l_71,&l_76[3]},{&l_68,&l_78},{&l_76[3],&l_68},{&l_71,&l_78}},{{(void*)0,&l_76[3]},{&l_76[3],&l_71},{&l_76[3],&l_76[3]},{(void*)0,&l_78},{&l_71,&l_68},{&l_76[3],&l_78},{&l_68,&l_76[3]},{&l_71,&l_71},{&l_71,&l_76[3]},{&l_68,&l_78}},{{&l_76[3],&l_68},{&l_71,&l_78},{(void*)0,&l_76[3]},{&l_76[3],&l_71},{&l_76[3],&l_76[3]},{(void*)0,&l_78},{&l_71,&l_68},{&l_76[3],&l_78},{&l_68,&l_76[3]},{&l_71,&l_71}},{{&l_71,&l_76[3]},{&l_68,&l_78},{&l_76[3],&l_68},{&l_71,&l_78},{(void*)0,&l_76[3]},{&l_76[3],&l_71},{&l_76[3],&l_76[3]},{(void*)0,&l_78},{&l_71,&l_68},{&l_76[3],&l_78}},{{&l_68,&l_76[3]},{&l_71,&l_71},{&l_71,&l_76[3]},{&l_68,&l_78},{&l_76[3],&l_68},{&l_71,&l_78},{(void*)0,&l_76[3]},{&l_76[3],&l_71},{&l_76[3],&l_76[3]},{(void*)0,&l_78}}};
                uint32_t *l_80 = &g_81;
                int32_t **l_362[2];
                union U1 l_401 = {4294967291UL};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_362[i] = &g_154;
            }
        }
        (*g_154) &= ((g_129 > (*g_31)) | (safe_lshift_func_uint8_t_u_u_unsafe_macro/*374*//* ___SAFE__OP */(p_42, 4)));
    }
    return &g_129;
}


/* ------------------------------------------ */
/* 
 * reads : g_153 g_154 g_46 g_51 g_81 g_31 g_129 g_204 g_193 g_98 g_203.f0 g_242 g_241 g_206
 * writes: g_228 g_204 g_241 g_178 g_129 g_154 g_206 g_361
 */
static int32_t * func_54(uint8_t  p_55, int16_t  p_56)
{ /* block id: 79 */
    uint32_t *l_221 = &g_98;
    uint32_t **l_220 = &l_221;
    uint32_t ***l_219 = &l_220;
    uint32_t ***l_223 = (void*)0;
    uint32_t ****l_222 = &l_223;
    int32_t l_239 = 0x6150DF3EL;
    int16_t *l_240 = &g_241;
    int16_t l_303[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
    int32_t l_340 = 0x1D5AB82BL;
    int32_t l_341 = 0x9293A919L;
    int32_t l_343 = 3L;
    int32_t l_344 = 0x099B265CL;
    int32_t l_345 = 0x5A67F2C6L;
    int32_t l_346 = 0x90E1155EL;
    int32_t l_347 = 3L;
    int32_t l_348 = (-8L);
    int32_t l_349[2];
    uint32_t l_350 = 0xB9983F3DL;
    const union U1 *l_360 = &g_163;
    const union U1 **l_359[9] = {&l_360,&l_360,(void*)0,&l_360,&l_360,(void*)0,&l_360,&l_360,(void*)0};
    int i;
    for (i = 0; i < 2; i++)
        l_349[i] = 0xF744EF90L;
    (*g_242) = (safe_mod_func_uint64_t_u_u_unsafe_macro/*375*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u_unsafe_macro/*376*//* ___SAFE__OP */((safe_sub_func_int32_t_s_s_unsafe_macro/*377*//* ___SAFE__OP */((**g_153), (safe_mod_func_uint64_t_u_u_unsafe_macro/*378*//* ___SAFE__OP */((((*l_240) = (safe_lshift_func_int32_t_s_s_unsafe_macro/*379*//* ___SAFE__OP */((g_51[0][6] | (l_219 != ((*l_222) = &l_220))), ((((safe_sub_func_uint16_t_u_u_unsafe_macro/*380*//* ___SAFE__OP */(((((((((((g_228 = (*l_220)) == (void*)0) | (p_55 >= (safe_lshift_func_int16_t_s_u_unsafe_macro/*381*//* ___SAFE__OP */((g_204 &= ((((((safe_rshift_func_uint64_t_u_s_unsafe_macro/*382*//* ___SAFE__OP */(g_81, ((safe_add_func_uint16_t_u_u_unsafe_macro/*383*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_s_unsafe_macro/*384*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s_unsafe_macro/*385*//* ___SAFE__OP */((*g_31), 0xCFL)), g_46)), 0xC9DCL)) , g_51[3][6]))) <= p_56) && g_129) | 0L) | l_239) , l_239)), g_193)))) != l_239) & g_129) , 0xC7B25D94L) > g_98) & l_239) , 0x8014FFD6L) == p_56), p_55)) , g_203[5].f0) ^ p_56) ^ 5L)))) , l_239), g_98)))), p_55)), 0x1D7D21DF0A651410LL));
    for (g_241 = 22; (g_241 <= (-15)); g_241--)
    { /* block id: 87 */
        int16_t l_247 = 0x4F5FL;
        uint8_t *l_290 = &g_121;
        uint8_t **l_289 = &l_290;
        int32_t l_304 = 0xA1727C7DL;
        int32_t **l_332 = &g_154;
        int16_t l_337 = 1L;
        int32_t l_338[1];
        int32_t l_339 = 0xD6407A86L;
        int8_t l_355 = (-7L);
        uint16_t l_356 = 65533UL;
        int i;
        for (i = 0; i < 1; i++)
            l_338[i] = 1L;
        for (g_129 = 0; (g_129 >= (-4)); --g_129)
        { /* block id: 90 */
            int32_t l_259 = 0L;
            uint32_t *l_280 = &g_193;
            uint8_t **l_294 = &l_290;
            int32_t l_300 = 0x55CF20D0L;
        }
        (*l_332) = &l_304;
        for (g_206 = 0; (g_206 != 35); g_206++)
        { /* block id: 135 */
            int32_t *l_335 = &l_304;
            int32_t *l_336[5];
            int32_t l_353 = (-7L);
            int16_t l_354 = 0L;
            int i;
            for (i = 0; i < 5; i++)
                l_336[i] = &g_178;
            ++l_350;
            l_356++;
            if (p_55)
                break;
            (**l_332) = 1L;
        }
    }
    g_361 = &g_163;
    return &g_51[2][6];
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_32 g_85 g_81 g_177 g_193 g_125 g_203 g_154 g_46 g_51 g_98 g_204
 * writes: g_178 g_31 g_193 g_206
 */
static int8_t  func_57(int64_t  p_58, const union U1  p_59, int8_t * p_60)
{ /* block id: 70 */
    uint8_t l_171 = 255UL;
    int32_t l_172 = (-3L);
    int8_t *l_186 = &g_129;
    int8_t **l_187 = &g_31;
    uint32_t *l_192[9][5][5] = {{{&g_193,&g_193,&g_193,(void*)0,(void*)0},{&g_193,&g_193,(void*)0,&g_193,(void*)0},{(void*)0,&g_193,&g_193,&g_193,&g_193},{(void*)0,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,(void*)0}},{{&g_193,&g_193,&g_193,&g_193,(void*)0},{&g_193,(void*)0,&g_193,&g_193,&g_193},{(void*)0,&g_193,&g_193,&g_193,&g_193},{&g_193,(void*)0,&g_193,(void*)0,(void*)0},{&g_193,&g_193,&g_193,&g_193,&g_193}},{{&g_193,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,(void*)0,(void*)0,&g_193},{&g_193,(void*)0,(void*)0,&g_193,(void*)0},{&g_193,&g_193,&g_193,&g_193,(void*)0},{(void*)0,&g_193,&g_193,&g_193,&g_193}},{{(void*)0,&g_193,&g_193,&g_193,&g_193},{(void*)0,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,(void*)0,(void*)0,(void*)0},{&g_193,(void*)0,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193}},{{&g_193,&g_193,&g_193,(void*)0,&g_193},{&g_193,(void*)0,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,(void*)0,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193}},{{&g_193,(void*)0,(void*)0,&g_193,(void*)0},{&g_193,(void*)0,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193},{(void*)0,(void*)0,&g_193,&g_193,&g_193},{(void*)0,&g_193,&g_193,&g_193,&g_193}},{{(void*)0,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,(void*)0},{&g_193,&g_193,&g_193,(void*)0,&g_193},{&g_193,&g_193,(void*)0,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193}},{{&g_193,&g_193,(void*)0,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193},{(void*)0,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,&g_193,&g_193}},{{&g_193,&g_193,&g_193,&g_193,&g_193},{(void*)0,(void*)0,(void*)0,&g_193,(void*)0},{&g_193,&g_193,&g_193,&g_193,&g_193},{&g_193,&g_193,&g_193,(void*)0,(void*)0},{&g_193,&g_193,&g_193,(void*)0,&g_193}}};
    int32_t l_194 = 2L;
    int32_t l_195 = 9L;
    int32_t l_196 = 0xE3130C64L;
    int32_t l_197[1];
    int32_t **l_200 = (void*)0;
    uint32_t * const l_202 = (void*)0;
    uint32_t * const *l_201 = &l_202;
    uint64_t *l_205 = &g_206;
    int32_t *l_207 = &l_172;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_197[i] = 1L;
    (*g_177) = (safe_div_func_uint32_t_u_u_unsafe_macro/*386*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_u_unsafe_macro/*387*//* ___SAFE__OP */((l_172 &= (safe_sub_func_uint8_t_u_u_unsafe_macro/*388*//* ___SAFE__OP */(l_171, (((*g_31) & g_85) != (p_60 != &l_171))))), (safe_sub_func_uint8_t_u_u_unsafe_macro/*389*//* ___SAFE__OP */(l_171, (&g_31 != (void*)0))))) || ((((safe_sub_func_int32_t_s_s_unsafe_macro/*390*//* ___SAFE__OP */((&g_154 == (void*)0), g_32)) != g_81) >= p_59.f0) , g_81)), p_58));
    (*l_207) = (l_172 , (safe_add_func_uint64_t_u_u_unsafe_macro/*391*//* ___SAFE__OP */(((*l_205) = ((~(((((safe_mul_func_int8_t_s_s_unsafe_macro/*392*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*393*//* ___SAFE__OP */((((*l_187) = l_186) == (void*)0), l_171)) == (((((l_197[0] ^= ((safe_sub_func_int32_t_s_s_unsafe_macro/*394*//* ___SAFE__OP */(l_171, (safe_sub_func_int64_t_s_s_unsafe_macro/*395*//* ___SAFE__OP */((((((g_193++) < (g_125[4] | p_58)) ^ (l_200 == (((((void*)0 == l_201) , l_196) , g_203[5]) , (void*)0))) < (*g_154)) && p_58), g_51[0][6])))) <= 0UL)) , 1L) ^ g_125[1]) < 0L) > (*p_60))), g_98)) | (-2L)) || p_59.f0) ^ g_204) > 65534UL)) , p_58)), p_59.f0)));
    return (*p_60);
}


/* ------------------------------------------ */
/* 
 * reads : g_83 g_86 g_85 g_31 g_32 g_98 g_81 g_49 g_51 g_50 g_84 g_153 g_154 g_46
 * writes: g_83 g_81 g_98 g_121 g_125 g_129 g_49 g_50 g_154
 */
static uint32_t  func_61(uint32_t  p_62, int16_t  p_63, int32_t * p_64, int32_t  p_65)
{ /* block id: 19 */
    int32_t *l_87[10][1] = {{(void*)0},{&g_51[0][6]},{(void*)0},{&g_51[0][6]},{(void*)0},{&g_51[0][6]},{(void*)0},{&g_51[0][6]},{(void*)0},{&g_51[0][6]}};
    uint16_t l_88 = 0x3F91L;
    uint8_t *l_120 = &g_121;
    int64_t * const l_133 = (void*)0;
    uint32_t l_160 = 0x639CECDFL;
    int i, j;
    (*g_86) = g_83;
    l_88++;
    for (p_63 = 14; (p_63 <= (-16)); p_63 = safe_sub_func_int8_t_s_s_unsafe_macro/*396*//* ___SAFE__OP */(p_63, 1))
    { /* block id: 24 */
        int32_t *l_95 = (void*)0;
        uint8_t *l_123 = &g_121;
        int32_t l_143 = 0x27960817L;
        int32_t l_155 = 2L;
        int32_t l_156 = 1L;
        int32_t l_157 = 1L;
        int32_t l_158 = 0x915659CFL;
        int32_t l_159[2][6] = {{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}};
        int i, j;
        if (g_85)
        { /* block id: 25 */
            int16_t l_93 = (-1L);
            return l_93;
        }
        else
        { /* block id: 27 */
            int32_t *l_94[8][5];
            int i, j;
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 5; j++)
                    l_94[i][j] = (void*)0;
            }
            for (p_62 = 0; (p_62 <= 3); p_62 += 1)
            { /* block id: 30 */
                uint64_t l_141[9] = {0x0828D0E3497F94F0LL,1UL,1UL,0x0828D0E3497F94F0LL,1UL,1UL,0x0828D0E3497F94F0LL,1UL,1UL};
                int i;
                l_95 = l_94[6][4];
                for (g_81 = 0; (g_81 <= 3); g_81 += 1)
                { /* block id: 34 */
                    const int8_t **l_117 = (void*)0;
                    const int8_t ***l_116 = &l_117;
                    int32_t l_142[2];
                    volatile int32_t *l_148 = &g_49;
                    volatile int32_t **l_147 = &l_148;
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_142[i] = 0xA3D26D73L;
                    for (p_65 = 3; (p_65 >= 0); p_65 -= 1)
                    { /* block id: 37 */
                        uint64_t l_115 = 8UL;
                        uint8_t *l_118 = (void*)0;
                        int32_t l_119[4][10][4] = {{{0L,0xCD17FF15L,0L,(-2L)},{0x366C4368L,(-5L),0x2EC94644L,6L},{0xB09764F7L,(-1L),0xE5EB5CE3L,(-5L)},{0xF2DDDEE6L,0xC1AF31ABL,0xE5EB5CE3L,0x068BD6B8L},{0xB09764F7L,2L,0x2EC94644L,(-1L)},{0x366C4368L,0x677434CAL,0L,0x677434CAL},{0L,0x677434CAL,0x366C4368L,(-1L)},{0x2EC94644L,2L,0xB09764F7L,0x068BD6B8L},{0xE5EB5CE3L,0xC1AF31ABL,0xF2DDDEE6L,(-5L)},{0xE5EB5CE3L,(-1L),0xB09764F7L,6L}},{{0x2EC94644L,(-5L),0x366C4368L,(-2L)},{0L,0xCD17FF15L,0L,(-2L)},{0x366C4368L,(-5L),0x2EC94644L,6L},{0xB09764F7L,(-1L),0xE5EB5CE3L,(-5L)},{0xF2DDDEE6L,0xC1AF31ABL,0xE5EB5CE3L,0x068BD6B8L},{0xB09764F7L,2L,0x2EC94644L,(-1L)},{0x366C4368L,0x677434CAL,0L,0x677434CAL},{0L,0x677434CAL,0x366C4368L,(-1L)},{0x2EC94644L,2L,0xB09764F7L,0x068BD6B8L},{0xE5EB5CE3L,0xC1AF31ABL,0xF2DDDEE6L,(-5L)}},{{0xE5EB5CE3L,(-1L),0xB09764F7L,6L},{0x2EC94644L,(-5L),0x366C4368L,(-2L)},{0L,0xCD17FF15L,0L,(-2L)},{0x366C4368L,(-5L),0x2EC94644L,6L},{0xB09764F7L,(-1L),0xE5EB5CE3L,(-5L)},{0xF2DDDEE6L,0xC1AF31ABL,0xE5EB5CE3L,0x068BD6B8L},{0xB09764F7L,2L,0x2EC94644L,(-1L)},{0x366C4368L,0x677434CAL,0L,0x677434CAL},{0L,0x677434CAL,0x366C4368L,(-1L)},{0x2EC94644L,2L,0xB09764F7L,0x068BD6B8L}},{{0xE5EB5CE3L,0xC1AF31ABL,0xF2DDDEE6L,(-5L)},{0xE5EB5CE3L,(-1L),0xB09764F7L,6L},{0x2EC94644L,(-5L),0x366C4368L,(-2L)},{0L,0xCD17FF15L,0L,(-2L)},{0x366C4368L,(-5L),0x2EC94644L,6L},{0xB09764F7L,(-1L),0xE5EB5CE3L,(-5L)},{0xF2DDDEE6L,0xC1AF31ABL,0xE5EB5CE3L,0x068BD6B8L},{0L,(-8L),1L,(-5L)},{0xB09764F7L,0xCD17FF15L,4L,0xCD17FF15L},{4L,0xCD17FF15L,0xB09764F7L,(-5L)}}};
                        uint8_t **l_122 = &l_118;
                        int64_t *l_124 = &g_125[1];
                        int8_t *l_126 = (void*)0;
                        int8_t *l_127 = (void*)0;
                        int8_t *l_128 = &g_129;
                        int32_t l_130 = (-1L);
                        uint16_t *l_136 = &l_88;
                        uint64_t l_144 = 0x1456848F5E8599F0LL;
                        int i, j, k;
                        l_130 = ((safe_lshift_func_uint32_t_u_s_unsafe_macro/*397*//* ___SAFE__OP */(p_63, ((g_98 |= (*g_31)) != ((*l_128) = (safe_sub_func_int32_t_s_s_unsafe_macro/*398*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*399*//* ___SAFE__OP */((((*l_124) = ((safe_mod_func_int64_t_s_s_unsafe_macro/*400*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_u_unsafe_macro/*401*//* ___SAFE__OP */(((*l_120) = (safe_mul_func_uint32_t_u_u_unsafe_macro/*402*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s_unsafe_macro/*403*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_s_unsafe_macro/*404*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*405*//* ___SAFE__OP */((*g_31), p_65)), g_81)), l_115)), (((l_119[2][5][0] = (l_116 != (void*)0)) >= (((*l_122) = l_120) == l_123)) < 0x6AL)))), 6)) > 18446744073709551606UL), p_62)) , 3L)) , g_49), p_63)) || 0x7583F029L), g_81)))))) >= g_51[0][6]);
                        l_143 |= ((p_65 <= (safe_rshift_func_uint32_t_u_u_unsafe_macro/*406*//* ___SAFE__OP */((8UL >= 7L), 9))) > ((((p_62 , (void*)0) == l_133) ^ p_63) != (l_142[0] = ((safe_mod_func_uint16_t_u_u_unsafe_macro/*407*//* ___SAFE__OP */((--(*l_136)), g_51[3][3])) , ((safe_mod_func_int64_t_s_s_unsafe_macro/*408*//* ___SAFE__OP */((l_119[2][5][0] | l_141[6]), 1L)) ^ 0x8FL)))));
                        g_49 = (-3L);
                        --l_144;
                    }
                    g_50[0][2][3] |= g_51[0][6];
                    (*l_147) = g_84[(g_81 + 1)][p_62][g_81];
                }
            }
            for (l_143 = (-27); (l_143 != 15); l_143 = safe_add_func_uint8_t_u_u_unsafe_macro/*409*//* ___SAFE__OP */(l_143, 6))
            { /* block id: 57 */
                for (g_98 = 0; (g_98 == 8); g_98 = safe_add_func_uint16_t_u_u_unsafe_macro/*410*//* ___SAFE__OP */(g_98, 2))
                { /* block id: 60 */
                    (*g_153) = &g_46;
                }
            }
        }
        l_160++;
        if ((**g_153))
            break;
        if ((*g_154))
            continue;
    }
    return p_62;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_50[i][j][k], "g_50[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_51[i][j], "g_51[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_125[i], "g_125[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_163.f0, "g_163.f0", print_hash_value);
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_193, "g_193", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_203[i].f0, "g_203[i].f0", print_hash_value);
        transparent_crc(g_203[i].f1, "g_203[i].f1", print_hash_value);
        transparent_crc(g_203[i].f2, "g_203[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_204, "g_204", print_hash_value);
    transparent_crc(g_206, "g_206", print_hash_value);
    transparent_crc(g_241, "g_241", print_hash_value);
    transparent_crc(g_322.f0, "g_322.f0", print_hash_value);
    transparent_crc(g_322.f1, "g_322.f1", print_hash_value);
    transparent_crc(g_322.f2, "g_322.f2", print_hash_value);
    transparent_crc(g_342, "g_342", print_hash_value);
    transparent_crc(g_518.f0, "g_518.f0", print_hash_value);
    transparent_crc(g_518.f1, "g_518.f1", print_hash_value);
    transparent_crc(g_518.f2, "g_518.f2", print_hash_value);
    transparent_crc(g_546, "g_546", print_hash_value);
    transparent_crc(g_559, "g_559", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_659[i][j][k], "g_659[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_722, "g_722", print_hash_value);
    transparent_crc(g_723, "g_723", print_hash_value);
    transparent_crc(g_733.f0, "g_733.f0", print_hash_value);
    transparent_crc(g_745, "g_745", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_752[i][j][k], "g_752[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_811, "g_811", print_hash_value);
    transparent_crc(g_987, "g_987", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_993[i][j][k], "g_993[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1017[i][j].f0, "g_1017[i][j].f0", print_hash_value);
            transparent_crc(g_1017[i][j].f1, "g_1017[i][j].f1", print_hash_value);
            transparent_crc(g_1017[i][j].f2, "g_1017[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1079.f0, "g_1079.f0", print_hash_value);
    transparent_crc(g_1079.f1, "g_1079.f1", print_hash_value);
    transparent_crc(g_1079.f2, "g_1079.f2", print_hash_value);
    transparent_crc(g_1214, "g_1214", print_hash_value);
    transparent_crc(g_1227, "g_1227", print_hash_value);
    transparent_crc(g_1270.f0, "g_1270.f0", print_hash_value);
    transparent_crc(g_1270.f1, "g_1270.f1", print_hash_value);
    transparent_crc(g_1270.f2, "g_1270.f2", print_hash_value);
    transparent_crc(g_1477, "g_1477", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1632[i][j], "g_1632[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1652[i], "g_1652[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1697, "g_1697", print_hash_value);
    transparent_crc(g_1746, "g_1746", print_hash_value);
    transparent_crc(g_1762, "g_1762", print_hash_value);
    transparent_crc(g_1798, "g_1798", print_hash_value);
    transparent_crc(g_1809, "g_1809", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1812[i][j][k], "g_1812[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1883.f0, "g_1883.f0", print_hash_value);
    transparent_crc(g_1883.f1, "g_1883.f1", print_hash_value);
    transparent_crc(g_1883.f2, "g_1883.f2", print_hash_value);
    transparent_crc(g_1915.f0, "g_1915.f0", print_hash_value);
    transparent_crc(g_1915.f1, "g_1915.f1", print_hash_value);
    transparent_crc(g_1915.f2, "g_1915.f2", print_hash_value);
    transparent_crc(g_1924, "g_1924", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_2068[i][j], "g_2068[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2191.f0, "g_2191.f0", print_hash_value);
    transparent_crc(g_2191.f1, "g_2191.f1", print_hash_value);
    transparent_crc(g_2191.f2, "g_2191.f2", print_hash_value);
    transparent_crc(g_2337, "g_2337", print_hash_value);
    transparent_crc(g_2353, "g_2353", print_hash_value);
    transparent_crc(g_2364, "g_2364", print_hash_value);
    transparent_crc(g_2425.f0, "g_2425.f0", print_hash_value);
    transparent_crc(g_2586, "g_2586", print_hash_value);
    transparent_crc(g_2730, "g_2730", print_hash_value);
    transparent_crc(g_2818, "g_2818", print_hash_value);
    transparent_crc(g_2863, "g_2863", print_hash_value);
    transparent_crc(g_2908, "g_2908", print_hash_value);
    transparent_crc(g_2952, "g_2952", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_2969[i][j], "g_2969[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3003.f0, "g_3003.f0", print_hash_value);
    transparent_crc(g_3003.f1, "g_3003.f1", print_hash_value);
    transparent_crc(g_3003.f2, "g_3003.f2", print_hash_value);
    transparent_crc(g_3016, "g_3016", print_hash_value);
    transparent_crc(g_3022.f0, "g_3022.f0", print_hash_value);
    transparent_crc(g_3022.f1, "g_3022.f1", print_hash_value);
    transparent_crc(g_3022.f2, "g_3022.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 843
   depth: 1, occurrence: 9
XXX total union variables: 25

XXX non-zero bitfields defined in structs: 4
XXX zero bitfields defined in structs: 1
XXX const bitfields defined in structs: 2
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 22
breakdown:
   indirect level: 0, occurrence: 9
   indirect level: 1, occurrence: 7
   indirect level: 2, occurrence: 6
XXX full-bitfields structs in the program: 9
breakdown:
   indirect level: 0, occurrence: 9
XXX times a bitfields struct's address is taken: 48
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 16
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 35

XXX max expression depth: 49
breakdown:
   depth: 1, occurrence: 342
   depth: 2, occurrence: 104
   depth: 3, occurrence: 5
   depth: 4, occurrence: 6
   depth: 5, occurrence: 6
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 3
   depth: 15, occurrence: 2
   depth: 16, occurrence: 7
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 20, occurrence: 5
   depth: 21, occurrence: 1
   depth: 22, occurrence: 6
   depth: 23, occurrence: 6
   depth: 24, occurrence: 3
   depth: 25, occurrence: 4
   depth: 26, occurrence: 4
   depth: 27, occurrence: 6
   depth: 28, occurrence: 3
   depth: 29, occurrence: 1
   depth: 31, occurrence: 1
   depth: 33, occurrence: 3
   depth: 38, occurrence: 1
   depth: 49, occurrence: 1

XXX total number of pointers: 721

XXX times a variable address is taken: 2039
XXX times a pointer is dereferenced on RHS: 361
breakdown:
   depth: 1, occurrence: 265
   depth: 2, occurrence: 53
   depth: 3, occurrence: 27
   depth: 4, occurrence: 12
   depth: 5, occurrence: 4
XXX times a pointer is dereferenced on LHS: 381
breakdown:
   depth: 1, occurrence: 339
   depth: 2, occurrence: 22
   depth: 3, occurrence: 9
   depth: 4, occurrence: 10
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 16
XXX times a pointer is compared with another pointer: 19
XXX times a pointer is qualified to be dereferenced: 11260

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1500
   level: 2, occurrence: 389
   level: 3, occurrence: 175
   level: 4, occurrence: 85
   level: 5, occurrence: 8
XXX number of pointers point to pointers: 344
XXX number of pointers point to scalars: 357
XXX number of pointers point to structs: 10
XXX percent of pointers has null in alias set: 28.8
XXX average alias set size: 1.51

XXX times a non-volatile is read: 2351
XXX times a non-volatile is write: 1226
XXX times a volatile is read: 159
XXX    times read thru a pointer: 51
XXX times a volatile is write: 48
XXX    times written thru a pointer: 6
XXX times a volatile is available for access: 2.05e+03
XXX percentage of non-volatile access: 94.5

XXX forward jumps: 1
XXX backward jumps: 13

XXX stmts: 362
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 40
   depth: 1, occurrence: 43
   depth: 2, occurrence: 45
   depth: 3, occurrence: 57
   depth: 4, occurrence: 77
   depth: 5, occurrence: 100

XXX percentage a fresh-made variable is used: 18
XXX percentage an existing variable is used: 82
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

