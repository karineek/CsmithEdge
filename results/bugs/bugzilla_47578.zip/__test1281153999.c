/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 1281153999 --bitfields --packed-struct
 * Seed:      1281153999
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   unsigned f0 : 6;
   const signed f1 : 5;
   signed f2 : 20;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static int16_t g_7 = (-1L);
static uint8_t g_46 = 251UL;
static int16_t g_49 = (-1L);
static int32_t g_60[2] = {(-4L),(-4L)};
static int16_t g_106 = 1L;
static int64_t g_121[8] = {0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL,0x78CED03213856DD1LL};
static uint8_t ** volatile g_133 = (void*)0;/* VOLATILE GLOBAL g_133 */
static uint8_t *g_135 = (void*)0;
static uint8_t **g_134 = &g_135;
static int32_t g_139 = 0L;
static int32_t g_141 = (-1L);
static uint32_t g_190 = 0x95E05244L;
static int32_t * volatile g_194 = (void*)0;/* VOLATILE GLOBAL g_194 */
static int32_t * volatile *g_193[3] = {&g_194,&g_194,&g_194};
static const int32_t g_198 = 0x069AAEB0L;
static const int32_t *g_197 = &g_198;
static volatile struct S0 g_203 = {2,-3,360};/* VOLATILE GLOBAL g_203 */
static uint32_t g_207 = 0xE85EEBD7L;
static volatile uint32_t g_226[5] = {0UL,0UL,0UL,0UL,0UL};
static const int64_t *g_250[9][7] = {{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]},{&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2],&g_121[2]}};
static const int64_t **g_249 = &g_250[7][3];
static const int64_t *** volatile g_252 = (void*)0;/* VOLATILE GLOBAL g_252 */
static const int64_t **g_254 = &g_250[2][2];
static const int64_t *** volatile g_253[8] = {&g_254,&g_254,&g_254,&g_254,&g_254,&g_254,&g_254,&g_254};
static const int64_t *** volatile g_256 = &g_254;/* VOLATILE GLOBAL g_256 */
static int16_t *g_265 = (void*)0;
static int8_t g_276 = (-4L);
static int32_t *g_288[10][3] = {{&g_60[1],(void*)0,&g_60[0]},{&g_60[1],&g_60[0],&g_60[1]},{&g_60[0],(void*)0,&g_60[1]},{&g_141,&g_141,&g_60[1]},{&g_139,&g_141,&g_60[1]},{&g_141,&g_141,&g_60[0]},{&g_139,&g_60[0],&g_141},{&g_141,&g_60[0],&g_139},{&g_60[0],&g_141,&g_141},{&g_60[1],&g_141,&g_139}};
static int32_t **g_287 = &g_288[2][0];
static uint16_t g_295[2][1][2] = {{{0xA1FFL,0xA1FFL}},{{0xA1FFL,0xA1FFL}}};
static volatile int64_t g_318 = 0x50612BCC693499C1LL;/* VOLATILE GLOBAL g_318 */
static uint8_t g_330 = 0x04L;
static int32_t *** volatile g_375 = (void*)0;/* VOLATILE GLOBAL g_375 */
static volatile uint8_t g_411 = 0UL;/* VOLATILE GLOBAL g_411 */
static int32_t g_468 = 0x0E6BEA86L;
static int32_t *g_467[6][9][4] = {{{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,(void*)0,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}},{{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,(void*)0,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}},{{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,(void*)0,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}},{{(void*)0,&g_468,&g_468,&g_468},{&g_468,&g_468,&g_468,&g_468},{(void*)0,&g_468,(void*)0,(void*)0},{(void*)0,&g_468,(void*)0,(void*)0},{&g_468,&g_468,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{(void*)0,(void*)0,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}},{{(void*)0,&g_468,(void*)0,(void*)0},{(void*)0,(void*)0,&g_468,&g_468},{(void*)0,&g_468,(void*)0,(void*)0},{(void*)0,&g_468,(void*)0,(void*)0},{&g_468,&g_468,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{(void*)0,(void*)0,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}},{{(void*)0,&g_468,(void*)0,(void*)0},{(void*)0,(void*)0,&g_468,&g_468},{(void*)0,&g_468,(void*)0,(void*)0},{(void*)0,&g_468,(void*)0,(void*)0},{&g_468,&g_468,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{(void*)0,(void*)0,&g_468,(void*)0},{&g_468,&g_468,&g_468,&g_468},{&g_468,&g_468,(void*)0,&g_468}}};
static uint16_t g_541[8] = {9UL,0x296BL,9UL,9UL,0x296BL,9UL,9UL,0x296BL};
static int32_t **g_546 = (void*)0;
static int32_t *** volatile g_545 = &g_546;/* VOLATILE GLOBAL g_545 */
static int64_t g_573 = 6L;
static uint32_t *g_603 = &g_190;
static uint32_t * volatile *g_602 = &g_603;
static int8_t g_698 = 0xE0L;
static uint64_t g_710 = 18446744073709551609UL;
static int32_t ** volatile g_715 = &g_288[2][0];/* VOLATILE GLOBAL g_715 */
static volatile struct S0 g_760 = {3,1,7};/* VOLATILE GLOBAL g_760 */
static const struct S0 *g_782 = (void*)0;
static const struct S0 **g_781[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const struct S0 ***g_780 = &g_781[0];
static const struct S0 **** volatile g_779[1][2] = {{&g_780,&g_780}};
static int64_t g_861 = 0x1237BF8C82B6BFB0LL;
static volatile int32_t g_894 = (-9L);/* VOLATILE GLOBAL g_894 */
static volatile int32_t *g_893 = &g_894;
static struct S0 g_917 = {7,0,-931};
static volatile uint32_t g_1032 = 0x3F6E2555L;/* VOLATILE GLOBAL g_1032 */
static volatile int32_t **g_1121 = &g_893;
static volatile int32_t ** volatile *g_1120[8] = {&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121,&g_1121};
static volatile int32_t ** volatile * const *g_1119 = &g_1120[2];
static volatile int32_t ** volatile **g_1125 = &g_1120[4];
static volatile int32_t ** volatile *** volatile g_1124[7] = {&g_1125,&g_1125,&g_1125,&g_1125,&g_1125,&g_1125,&g_1125};
static volatile int32_t ** volatile *** volatile g_1126 = &g_1125;/* VOLATILE GLOBAL g_1126 */
static int64_t *g_1163 = &g_121[2];
static int64_t **g_1162 = &g_1163;
static int32_t *g_1213 = &g_139;
static int32_t ** volatile g_1212 = &g_1213;/* VOLATILE GLOBAL g_1212 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_17(int32_t  p_18, uint64_t  p_19, int32_t  p_20, uint8_t  p_21);
static int32_t  func_22(int64_t  p_23, uint64_t  p_24, uint64_t  p_25, int32_t  p_26);
static int8_t  func_33(uint32_t  p_34, int8_t  p_35, int32_t  p_36);
static uint32_t  func_37(int32_t  p_38, uint32_t  p_39, int64_t  p_40, int8_t  p_41);
static uint8_t  func_42(uint8_t  p_43);
static int32_t  func_52(uint8_t * p_53, int32_t * const  p_54, uint8_t * p_55, int32_t * p_56, uint8_t * p_57);
static uint8_t * func_61(int32_t * p_62, uint8_t * p_63);
static int32_t * func_64(uint32_t  p_65, int32_t * p_66);
static uint8_t * func_69(int32_t * p_70, struct S0  p_71);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_256 g_254 g_60 g_698 g_760.f0 g_893 g_49 g_603 g_190 g_121 g_541 g_287 g_276 g_861 g_894 g_139 g_226 g_106 g_710 g_197 g_198 g_468 g_330 g_141 g_467 g_1032 g_602 g_46 g_207 g_295 g_1119 g_1126 g_1162 g_1163 g_1121 g_1212 g_917.f1
 * writes: g_46 g_49 g_60 g_698 g_861 g_121 g_288 g_894 g_139 g_106 g_468 g_330 g_141 g_276 g_710 g_573 g_190 g_1125 g_541 g_1162 g_265 g_917.f0 g_1213
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_10 = 0x925EF2C3L;
    int32_t l_995 = 0xD292F5F5L;
    (*g_893) = ((safe_unary_minus_func_uint64_t_u/*0*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/*1*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/*2*//* ___SAFE__OP */(g_7, ((safe_div_func_uint64_t_u_u/*3*//* ___SAFE__OP */(l_10, (safe_lshift_func_int64_t_s_s((safe_sub_func_uint32_t_u_u/*5*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/*6*//* ___SAFE__OP */(l_10, ((l_10 >= func_17(((l_10 ^ (func_22((safe_rshift_func_uint8_t_u_s(((safe_lshift_func_uint8_t_u_u/*8*//* ___SAFE__OP */(l_10, ((safe_mod_func_uint16_t_u_u/*9*//* ___SAFE__OP */((((g_7 || func_33(func_37(((g_7 , g_7) > 0xC1B1L), l_10, g_7, l_10), g_541[1], l_10)) , (-1L)) | g_710), l_10)) < (-4L)))) | 3UL), l_10)), l_995, l_10, l_10) , g_861)) , (-1L)), l_995, l_10, l_995)) != l_10))), g_917.f1)), l_10)))) & g_198))), l_10)))) != l_10);
    return l_995;
}


/* ------------------------------------------ */
/* 
 * reads : g_330 g_468 g_141 g_467 g_287 g_60 g_1032 g_602 g_603 g_190 g_276 g_46 g_710 g_49 g_760.f0 g_893 g_894 g_106 g_121 g_139 g_207 g_295 g_1119 g_1126 g_541 g_1162 g_226 g_1163 g_1121 g_1212
 * writes: g_468 g_330 g_288 g_141 g_60 g_139 g_276 g_710 g_49 g_46 g_106 g_573 g_190 g_1125 g_541 g_1162 g_265 g_917.f0 g_894 g_1213
 */
static int16_t  func_17(int32_t  p_18, uint64_t  p_19, int32_t  p_20, uint8_t  p_21)
{ /* block id: 506 */
    uint16_t l_1034 = 0UL;
    uint32_t l_1035 = 0x55CA850FL;
    int32_t *l_1087 = (void*)0;
    int16_t *l_1180[2];
    int8_t *l_1185 = &g_698;
    int32_t l_1201 = 1L;
    int32_t l_1202[9][6][2] = {{{0x0DB43F2BL,6L},{0x7AF18E62L,0x0DB43F2BL},{0xE7A8DB00L,0x1636EFA5L},{0xE7A8DB00L,0x0DB43F2BL},{0x7AF18E62L,6L},{0x0DB43F2BL,(-1L)}},{{7L,0x0DB43F2BL},{0x1636EFA5L,0xE7A8DB00L},{0xE7A8DB00L,0x35EE2D50L},{7L,6L},{0x35EE2D50L,6L},{7L,0x35EE2D50L}},{{0xE7A8DB00L,0xE7A8DB00L},{0x1636EFA5L,0x0DB43F2BL},{7L,(-1L)},{0x0DB43F2BL,6L},{0x7AF18E62L,0x0DB43F2BL},{0xE7A8DB00L,0x1636EFA5L}},{{0xE7A8DB00L,0x0DB43F2BL},{0x7AF18E62L,6L},{0x0DB43F2BL,(-1L)},{7L,0x0DB43F2BL},{0x1636EFA5L,0xE7A8DB00L},{0xE7A8DB00L,0x35EE2D50L}},{{7L,6L},{0x35EE2D50L,6L},{7L,0x35EE2D50L},{0xE7A8DB00L,0xE7A8DB00L},{0x1636EFA5L,0x7AF18E62L},{0xA90AC80DL,(-7L)}},{{0x7AF18E62L,0x1636EFA5L},{1L,0x7AF18E62L},{0x35EE2D50L,0xD2D44289L},{0x35EE2D50L,0x7AF18E62L},{1L,0x1636EFA5L},{0x7AF18E62L,(-7L)}},{{0xA90AC80DL,0x7AF18E62L},{0xD2D44289L,0x35EE2D50L},{0x35EE2D50L,0x24F540B8L},{0xA90AC80DL,0x1636EFA5L},{0x24F540B8L,0x1636EFA5L},{0xA90AC80DL,0x24F540B8L}},{{0x35EE2D50L,0x35EE2D50L},{0xD2D44289L,0x7AF18E62L},{0xA90AC80DL,(-7L)},{0x7AF18E62L,0x1636EFA5L},{1L,0x7AF18E62L},{0x35EE2D50L,0xD2D44289L}},{{0x35EE2D50L,0x7AF18E62L},{1L,0x1636EFA5L},{0x7AF18E62L,(-7L)},{0xA90AC80DL,0x7AF18E62L},{0xD2D44289L,0x35EE2D50L},{0x35EE2D50L,0x24F540B8L}}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1180[i] = &g_49;
lbl_1214:
    for (g_468 = 0; (g_468 <= 2); g_468 += 1)
    { /* block id: 509 */
        const int32_t **l_1029 = (void*)0;
        const int32_t ***l_1028 = &l_1029;
        uint8_t l_1065 = 0UL;
        int16_t *l_1090 = &g_49;
        int32_t l_1094 = 0x7EA8C7DFL;
        const uint32_t l_1118 = 9UL;
        struct S0 l_1136 = {0,-1,123};
        struct S0 ***l_1189[5];
        struct S0 ****l_1188 = &l_1189[4];
        uint64_t l_1195[2];
        int32_t l_1203 = 0x126E1266L;
        int32_t l_1205[4][9] = {{0x296C8B77L,0x296C8B77L,(-1L),0x296C8B77L,0x296C8B77L,(-1L),0x296C8B77L,0x296C8B77L,(-1L)},{0L,0xC1E36626L,0x063F2C66L,0xC1E36626L,0L,8L,0L,0xC1E36626L,0x063F2C66L},{0x296C8B77L,0x296C8B77L,(-1L),0x296C8B77L,0x296C8B77L,(-1L),0x296C8B77L,0x296C8B77L,(-1L)},{0L,0xC1E36626L,0x063F2C66L,0xC1E36626L,0L,8L,0L,0xC1E36626L,0x063F2C66L}};
        int i, j;
        for (i = 0; i < 5; i++)
            l_1189[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_1195[i] = 0x2FDF504BEDE3B3A6LL;
        for (g_330 = 0; (g_330 <= 1); g_330 += 1)
        { /* block id: 512 */
            int16_t l_1036 = 0xABD0L;
            int16_t **l_1043 = &g_265;
            const struct S0 ***l_1046[3][9] = {{&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0]},{&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0]},{&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0],&g_781[0]}};
            uint32_t *l_1079[7] = {(void*)0,(void*)0,&g_190,(void*)0,(void*)0,&g_190,(void*)0};
            uint16_t * const l_1080 = &g_541[5];
            uint16_t *l_1081 = &l_1034;
            int64_t l_1155 = 0L;
            const int64_t **l_1161 = &g_250[0][2];
            int8_t *l_1184 = &g_276;
            int8_t *l_1187[3][4] = {{&g_698,(void*)0,&g_698,&g_276},{&g_698,&g_276,&g_276,&g_698},{&g_698,&g_276,&g_276,&g_276}};
            int32_t l_1204[6][7] = {{(-3L),1L,1L,(-3L),0L,0L,0L},{0L,6L,6L,0L,0x24BDDAE2L,9L,0x24BDDAE2L},{(-3L),1L,1L,(-3L),0L,0L,0L},{0L,6L,6L,0L,0x24BDDAE2L,9L,0x24BDDAE2L},{(-3L),1L,1L,(-3L),0L,0L,0L},{0L,6L,6L,0L,0x24BDDAE2L,9L,0x24BDDAE2L}};
            uint64_t l_1209[7][6][5] = {{{18446744073709551606UL,1UL,3UL,0xA006FE44849ACE20LL,0UL},{5UL,0UL,5UL,0xDB765F2921197DD1LL,0xB174B048020CB015LL},{0xCFF30FB0E4A6245ALL,0UL,18446744073709551615UL,18446744073709551606UL,18446744073709551606UL},{18446744073709551613UL,0x79C33AF0AB07E622LL,0x5601F5C0393EB5E0LL,0x6826DEAF785EEDC4LL,18446744073709551613UL},{18446744073709551606UL,0UL,0x8676BA748052DD02LL,18446744073709551615UL,3UL},{18446744073709551609UL,0xA2C88408BCE4E13ALL,18446744073709551613UL,18446744073709551615UL,1UL}},{{3UL,0x3D9F0E5426BF3C88LL,0x8676BA748052DD02LL,3UL,1UL},{3UL,18446744073709551613UL,0x5601F5C0393EB5E0LL,0xE05ABB478190482BLL,0xF299996BC8AA4707LL},{18446744073709551615UL,7UL,0x3D9F0E5426BF3C88LL,0xDB0CB991D941D03ALL,0x3D9F0E5426BF3C88LL},{0x6826DEAF785EEDC4LL,0x6826DEAF785EEDC4LL,0xF97CABD8A56BC25BLL,18446744073709551611UL,2UL},{1UL,1UL,18446744073709551615UL,18446744073709551606UL,0x3B0AA9B92130B1D6LL},{0xB174B048020CB015LL,0x059301430A890310LL,0xE05ABB478190482BLL,18446744073709551613UL,18446744073709551615UL}},{{0x5AA86E90095FCA04LL,1UL,0x02AB023818A2550ALL,18446744073709551615UL,0xCFF30FB0E4A6245ALL},{18446744073709551606UL,0x6826DEAF785EEDC4LL,18446744073709551610UL,0UL,18446744073709551609UL},{0x02AB023818A2550ALL,7UL,0UL,0UL,7UL},{1UL,18446744073709551613UL,0x059301430A890310LL,4UL,0xE05ABB478190482BLL},{0xF9D889BDDFE3F8BCLL,0x3D9F0E5426BF3C88LL,18446744073709551615UL,0xCFF30FB0E4A6245ALL,0UL},{2UL,0xA2C88408BCE4E13ALL,0x9DB603F2577D0C3BLL,18446744073709551610UL,5UL}},{{0xF9D889BDDFE3F8BCLL,0UL,0xDB0CB991D941D03ALL,1UL,0UL},{1UL,0x79C33AF0AB07E622LL,0UL,3UL,4UL},{0x02AB023818A2550ALL,0x5AA86E90095FCA04LL,7UL,0x5AA86E90095FCA04LL,0x02AB023818A2550ALL},{18446744073709551606UL,9UL,3UL,18446744073709551615UL,0x6826DEAF785EEDC4LL},{0x5AA86E90095FCA04LL,0x7F41CD49F904CFFBLL,0x1068828D63FBE14BLL,18446744073709551610UL,3UL},{0xB174B048020CB015LL,5UL,0x678593AD0D9CD939LL,9UL,0x6826DEAF785EEDC4LL}},{{1UL,18446744073709551610UL,0UL,18446744073709551613UL,0x02AB023818A2550ALL},{0x6826DEAF785EEDC4LL,18446744073709551610UL,0UL,18446744073709551609UL,4UL},{18446744073709551615UL,18446744073709551606UL,18446744073709551606UL,18446744073709551615UL,0UL},{3UL,18446744073709551615UL,0xA2C88408BCE4E13ALL,5UL,5UL},{3UL,0xF9D889BDDFE3F8BCLL,0x5AA86E90095FCA04LL,0x8676BA748052DD02LL,0UL},{18446744073709551609UL,0xB174B048020CB015LL,4UL,5UL,0xE05ABB478190482BLL}},{{18446744073709551606UL,18446744073709551615UL,3UL,18446744073709551615UL,7UL},{0x5601F5C0393EB5E0LL,0xE05ABB478190482BLL,0xF299996BC8AA4707LL,18446744073709551609UL,18446744073709551609UL},{0UL,18446744073709551609UL,0UL,18446744073709551613UL,0xCFF30FB0E4A6245ALL},{18446744073709551610UL,0x5601F5C0393EB5E0LL,0xDB765F2921197DD1LL,9UL,18446744073709551615UL},{0x650BADC90C7B2E17LL,0x02AB023818A2550ALL,0xCFF30FB0E4A6245ALL,18446744073709551610UL,0x3B0AA9B92130B1D6LL},{0xF97CABD8A56BC25BLL,0xF299996BC8AA4707LL,0xDB765F2921197DD1LL,18446744073709551615UL,2UL}},{{0xDB0CB991D941D03ALL,0xCFF30FB0E4A6245ALL,0UL,0x5AA86E90095FCA04LL,0x3D9F0E5426BF3C88LL},{0x678593AD0D9CD939LL,0UL,0xF299996BC8AA4707LL,3UL,0xF299996BC8AA4707LL},{18446744073709551613UL,18446744073709551613UL,3UL,1UL,1UL},{5UL,18446744073709551611UL,4UL,18446744073709551610UL,1UL},{0x7F41CD49F904CFFBLL,0UL,0x5AA86E90095FCA04LL,0xCFF30FB0E4A6245ALL,3UL},{0xE05ABB478190482BLL,18446744073709551611UL,3UL,18446744073709551613UL,0x5601F5C0393EB5E0LL}}};
            int i, j, k;
            g_288[(g_330 + 5)][g_468] = &g_60[g_330];
            for (g_141 = 0; (g_141 <= 1); g_141 += 1)
            { /* block id: 516 */
                const int32_t ****l_1030 = (void*)0;
                const int32_t ****l_1031 = (void*)0;
                int32_t *l_1033 = &g_60[1];
                int32_t *l_1037 = &g_139;
                uint8_t l_1062 = 0x6BL;
                const struct S0 **l_1086 = &g_782;
                int32_t l_1133[2][5][7] = {{{0L,0L,2L,0xF49C9B0AL,(-1L),0x31DC2434L,0x2DDDACE4L},{1L,2L,0x2DDDACE4L,1L,0xA735F7F5L,(-1L),0x6C495520L},{0x31DC2434L,(-7L),(-1L),0x2DDDACE4L,(-1L),(-7L),0x31DC2434L},{6L,0x31DC2434L,1L,0x2DDDACE4L,0L,0x6C495520L,1L},{0x5F641FE9L,0xF51B225FL,0L,1L,6L,0xA735F7F5L,0xA735F7F5L}},{{0L,0xF49C9B0AL,1L,0xF49C9B0AL,0L,1L,2L},{2L,0xF49C9B0AL,(-1L),0x31DC2434L,0x2DDDACE4L,0x2B2D71A6L,6L},{0xF49C9B0AL,0xF51B225FL,0x2DDDACE4L,0x2EDFA502L,1L,1L,0x2EDFA502L},{2L,0x31DC2434L,2L,1L,0x6C495520L,0xF51B225FL,0x2EDFA502L},{0L,(-7L),0x2B2D71A6L,1L,0x2EDFA502L,2L,6L}}};
                uint32_t **l_1156[10][1][5] = {{{&l_1079[5],&g_603,&l_1079[4],&g_603,&l_1079[5]}},{{&l_1079[4],&l_1079[4],&l_1079[4],(void*)0,(void*)0}},{{&l_1079[4],&g_603,(void*)0,(void*)0,&g_603}},{{&l_1079[3],&l_1079[4],&g_603,&l_1079[4],(void*)0}},{{&g_603,(void*)0,&l_1079[5],(void*)0,&l_1079[5]}},{{(void*)0,(void*)0,&l_1079[4],&l_1079[3],&g_603}},{{&g_603,(void*)0,&l_1079[4],&l_1079[4],&l_1079[4]}},{{&l_1079[3],&l_1079[2],&l_1079[3],&l_1079[0],(void*)0}},{{&l_1079[4],(void*)0,&g_603,&g_603,&l_1079[1]}},{{&l_1079[4],(void*)0,(void*)0,&l_1079[4],&l_1079[3]}}};
                struct S0 * const l_1193 = &l_1136;
                struct S0 * const *l_1192 = &l_1193;
                struct S0 * const **l_1191 = &l_1192;
                struct S0 * const ***l_1190 = &l_1191;
                int32_t l_1207 = 0x8DDD3EC4L;
                int32_t l_1208 = 0xEF838AA4L;
                int i, j, k;
                (*g_287) = g_467[g_141][(g_468 + 4)][g_468];
                for (p_19 = 0; (p_19 <= 1); p_19 += 1)
                { /* block id: 520 */
                    int i;
                    if (g_60[p_19])
                        break;
                }
                if (((*l_1037) = (246UL & (~((safe_sub_func_int8_t_s_s/*10*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u((safe_add_func_int8_t_s_s/*12*//* ___SAFE__OP */(p_19, (safe_div_func_int8_t_s_s/*13*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u/*14*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u(((safe_mod_func_int32_t_s_s(4L, ((!(&g_193[0] == (l_1028 = l_1028))) && (0x7518L == (g_1032 > (((*l_1033) = p_19) , (((**g_602) , 4294967289UL) | l_1034))))))) == l_1034), g_141)), l_1034)) , l_1035), 247UL)))), g_276)), l_1036)) && p_18)))))
                { /* block id: 526 */
                    uint64_t l_1055 = 0x08DBF327ADCC46B1LL;
                    int32_t ***l_1059[6][1][4] = {{{&g_546,&g_546,&g_546,&g_546}},{{&g_546,&g_546,(void*)0,&g_546}},{{&g_546,&g_546,(void*)0,(void*)0}},{{&g_546,&g_546,&g_546,(void*)0}},{{&g_546,&g_546,&g_546,&g_546}},{{&g_546,&g_546,&g_546,&g_546}}};
                    int32_t ****l_1058 = &l_1059[2][0][2];
                    int32_t l_1063 = 1L;
                    const int16_t *l_1068 = &g_7;
                    const int16_t **l_1067 = &l_1068;
                    int i, j, k;
                    for (g_276 = 0; (g_276 <= 1); g_276 += 1)
                    { /* block id: 529 */
                        uint32_t *l_1064[9];
                        int32_t l_1066[2];
                        uint64_t *l_1069 = &g_710;
                        int i;
                        for (i = 0; i < 9; i++)
                            l_1064[i] = (void*)0;
                        for (i = 0; i < 2; i++)
                            l_1066[i] = 0L;
                        (*g_287) = func_64((safe_rshift_func_uint8_t_u_u/*17*//* ___SAFE__OP */((safe_unary_minus_func_uint8_t_u/*18*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/*19*//* ___SAFE__OP */((((*l_1069) &= (l_1043 == ((safe_div_func_int64_t_s_s/*20*//* ___SAFE__OP */((l_1066[1] |= ((((void*)0 == l_1046[1][7]) >= (safe_lshift_func_int8_t_s_s(g_60[g_141], (safe_add_func_int8_t_s_s/*22*//* ___SAFE__OP */((((0xC7L == (safe_add_func_int16_t_s_s/*23*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u(l_1055, (safe_mod_func_uint16_t_u_u((((l_1058 == (void*)0) && (((*l_1037) = (l_1063 = (safe_add_func_uint32_t_u_u/*26*//* ___SAFE__OP */(l_1062, p_19)))) , p_18)) , p_18), (*l_1033))))), l_1055))) , l_1065) == g_46), g_276))))) <= 0x0545L)), 0x59C2C310F3360F87LL)) , l_1067))) && 18446744073709551615UL), (**g_602))))), p_19)), &g_60[g_330]);
                    }
                }
                else
                { /* block id: 536 */
                    if ((0x4D06FBD762F84413LL <= g_760.f0))
                    { /* block id: 537 */
                        uint8_t *l_1074 = (void*)0;
                        uint8_t *l_1075[4] = {&l_1062,&l_1062,&l_1062,&l_1062};
                        int16_t *l_1078 = &g_106;
                        int8_t *l_1082[8];
                        int32_t l_1083 = 1L;
                        int i;
                        for (i = 0; i < 8; i++)
                            l_1082[i] = &g_276;
                        (*l_1033) &= (safe_sub_func_uint32_t_u_u/*27*//* ___SAFE__OP */(((((*l_1078) |= (safe_sub_func_int32_t_s_s/*28*//* ___SAFE__OP */((*g_893), ((g_46++) , p_21)))) >= (((void*)0 == l_1079[4]) == (l_1083 = (((&g_710 != (void*)0) >= (((g_573 = (l_1080 != l_1081)) || (((p_19 >= 0x2BEEFEA7L) , g_330) ^ (-1L))) <= 0x4D02E4EFL)) > g_121[2])))) < p_20), 1UL));
                        if (p_18)
                            continue;
                        if (p_21)
                            break;
                    }
                    else
                    { /* block id: 545 */
                        (*l_1033) ^= ((void*)0 == &g_603);
                    }
                    (*l_1033) = (*l_1037);
                    if (p_18)
                        break;
                    (*g_287) = func_64((safe_rshift_func_int32_t_s_u/*29*//* ___SAFE__OP */(((*l_1033) = (l_1086 != (void*)0)), 19)), l_1087);
                }
                for (g_139 = 0; (g_139 != 4); ++g_139)
                { /* block id: 555 */
                    struct S0 l_1091[4][9][3] = {{{{7,3,-839},{1,4,178},{3,-2,453}},{{7,-2,747},{4,-4,970},{7,-2,747}},{{2,-1,118},{3,4,-204},{0,-4,-609}},{{2,-1,118},{7,-4,-686},{7,2,-495}},{{7,-2,747},{5,1,-77},{7,3,-839}},{{7,3,-839},{3,2,-508},{0,-4,-609}},{{7,-2,747},{1,4,178},{7,-2,-483}},{{2,-1,118},{5,1,-77},{1,-0,190}},{{2,-1,118},{4,-1,316},{5,-0,194}}},{{{7,-2,747},{5,-3,210},{7,2,-495}},{{7,3,-839},{4,-4,970},{1,-0,190}},{{7,-2,747},{3,2,-508},{3,-1,401}},{{2,-1,118},{5,-3,210},{3,-2,453}},{{2,-1,118},{5,-0,194},{3,1,-614}},{{1,0,-256},{7,-2,747},{0,-4,-160}},{{3,1,-614},{0,-1,187},{0,-2,986}},{{1,0,-256},{3,-0,-559},{1,0,-256}},{{1,1,357},{7,-2,747},{5,-2,-578}}},{{{1,1,357},{7,2,-495},{5,-2,-444}},{{1,0,-256},{3,-1,401},{3,1,-614}},{{3,1,-614},{2,-1,118},{5,-2,-578}},{{1,0,-256},{0,-1,187},{5,-4,-426}},{{1,1,357},{3,-1,401},{2,-3,-17}},{{1,1,357},{7,3,-839},{0,-4,-160}},{{1,0,-256},{7,-2,-483},{5,-2,-444}},{{3,1,-614},{3,-0,-559},{2,-3,-17}},{{1,0,-256},{2,-1,118},{2,3,85}}},{{{1,1,357},{7,-2,-483},{0,-2,986}},{{1,1,357},{5,-0,194},{3,1,-614}},{{1,0,-256},{7,-2,747},{0,-4,-160}},{{3,1,-614},{0,-1,187},{0,-2,986}},{{1,0,-256},{3,-0,-559},{1,0,-256}},{{1,1,357},{7,-2,747},{5,-2,-578}},{{1,1,357},{7,2,-495},{5,-2,-444}},{{1,0,-256},{3,-1,401},{3,1,-614}},{{3,1,-614},{2,-1,118},{5,-2,-578}}}};
                    int64_t l_1117 = 0xE2023820B00F2416LL;
                    int32_t l_1123 = 8L;
                    int16_t l_1144[10] = {(-8L),(-3L),(-8L),9L,9L,(-8L),(-3L),(-8L),9L,9L};
                    int32_t l_1206 = 0xD6D310FCL;
                    int i, j, k;
                    if (((g_207 , ((l_1090 = l_1090) != (l_1091[0][4][1] , &g_7))) , ((*l_1033) = (*g_893))))
                    { /* block id: 558 */
                        int64_t *l_1122 = &l_1117;
                        l_1094 ^= (safe_div_func_int8_t_s_s((g_894 > 0xCCCEL), p_19));
                        (*l_1033) = (*l_1037);
                        l_1123 ^= (((g_760.f0 , p_21) == 0x5BL) > ((safe_lshift_func_uint64_t_u_u/*31*//* ___SAFE__OP */((*l_1033), 15)) >= (!((safe_rshift_func_int32_t_s_u((safe_lshift_func_uint64_t_u_s((--p_19), 32)), (safe_sub_func_int64_t_s_s/*34*//* ___SAFE__OP */(((((((safe_rshift_func_uint16_t_u_s/*35*//* ___SAFE__OP */(((safe_mod_func_int64_t_s_s/*36*//* ___SAFE__OP */((!((((*l_1122) = ((((safe_lshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u/*38*//* ___SAFE__OP */(((*l_1033) > ((((safe_div_func_int8_t_s_s/*39*//* ___SAFE__OP */(g_295[0][0][0], g_207)) > ((*g_603) |= 0UL)) >= (*l_1037)) , l_1117)), l_1118)), l_1091[0][4][1].f2)) ^ p_20) , g_1119) == &l_1028)) & g_121[2]) != p_20)), 0x32FF0190C6C478FDLL)) >= 18446744073709551607UL), 10)) , 1UL) , g_121[5]) == g_330) || 0xAE06D7E3L) & g_106), g_46)))) >= 0xD74A2F5E1B232115LL))));
                        if (p_20)
                            continue;
                    }
                    else
                    { /* block id: 566 */
                        (*g_1126) = &g_1120[2];
                    }
                    if (p_19)
                    { /* block id: 569 */
                        return p_19;
                    }
                    else
                    { /* block id: 571 */
                        uint8_t *l_1143[9][8][2] = {{{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330}},{{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062}},{{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46}},{{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062}},{{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330}},{{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330}},{{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062},{&g_330,&l_1062},{&l_1062,&g_330},{&g_46,&g_46},{&g_46,&g_330},{&l_1062,&l_1062}},{{&l_1062,&g_46},{&l_1065,&l_1062},{&g_330,&g_330},{&g_330,&l_1062},{&l_1065,&g_46},{&l_1062,&g_46},{&l_1065,&l_1062},{&g_330,&g_330}},{{&g_330,&l_1062},{&l_1065,&g_46},{&l_1062,&g_46},{&l_1065,&l_1062},{&g_330,&g_330},{&g_330,&l_1062},{&l_1065,&g_46},{&l_1062,&g_46}}};
                        struct S0 ***l_1154 = (void*)0;
                        struct S0 ****l_1153 = &l_1154;
                        int32_t l_1177 = 0x6FC778CAL;
                        const int16_t *l_1181 = &g_106;
                        int8_t **l_1186[6];
                        uint32_t l_1194 = 0xC443C619L;
                        int i, j, k;
                        for (i = 0; i < 6; i++)
                            l_1186[i] = (void*)0;
                        (*g_287) = func_64((safe_mul_func_uint32_t_u_u/*40*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/*41*//* ___SAFE__OP */(((((safe_rshift_func_int64_t_s_u/*42*//* ___SAFE__OP */(l_1133[0][1][2], 63)) , (safe_div_func_int16_t_s_s/*43*//* ___SAFE__OP */((0x4C9A231C86D91DCELL | (l_1136 , p_19)), (safe_add_func_uint32_t_u_u/*44*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u/*45*//* ___SAFE__OP */(p_18, (safe_div_func_uint8_t_u_u/*46*//* ___SAFE__OP */(((p_21--) >= (safe_div_func_uint64_t_u_u/*47*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/*48*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_s/*49*//* ___SAFE__OP */(p_18, 15)), l_1144[8])), (((((*l_1153) = (void*)0) == (((*l_1080) |= (&l_1090 == &g_265)) , (void*)0)) != 0xF6EF6553F4113E56LL) | 8L)))), 0xF1L)))), p_20))))) ^ p_19) != p_19), (*g_603))), l_1155)), &l_1094);
                        (*l_1033) = (((void*)0 != l_1156[4][0][3]) > ((*l_1080) = (l_1117 , (safe_mod_func_uint16_t_u_u/*50*//* ___SAFE__OP */(7UL, (safe_rshift_func_uint16_t_u_s/*51*//* ___SAFE__OP */((l_1161 == (g_1162 = g_1162)), (safe_rshift_func_int32_t_s_s/*52*//* ___SAFE__OP */(((&l_1086 != (void*)0) >= p_19), 20)))))))));
                        if (p_20)
                            break;
                        (**g_1121) = (safe_sub_func_uint32_t_u_u/*53*//* ___SAFE__OP */((!((safe_mod_func_int32_t_s_s/*54*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u/*55*//* ___SAFE__OP */((((safe_lshift_func_uint32_t_u_s/*56*//* ___SAFE__OP */((g_917.f0 = ((safe_lshift_func_uint16_t_u_s/*57*//* ___SAFE__OP */(((p_20 ^= ((*l_1033) = l_1177)) , (1UL <= (((g_226[2] != ((safe_mul_func_int8_t_s_s/*58*//* ___SAFE__OP */(((((*l_1043) = l_1180[0]) == l_1181) ^ (p_19 ^ (safe_sub_func_int64_t_s_s/*59*//* ___SAFE__OP */((**g_1162), (((((((*g_603) = (((l_1184 == (l_1187[0][0] = l_1185)) , l_1188) != l_1190)) <= p_20) , p_19) ^ 0x2BA0714BL) , (-2L)) || 0x50C5L))))), 0x0BL)) , p_21)) && 0xA79BFD0EL) && p_20))), g_139)) & 0xA9E04F36EDEC380BLL)), p_21)) <= l_1194) , l_1195[1]), 0xA0585E87L)), p_21)) > 0UL)), (-4L)));
                    }
                    for (g_710 = 0; (g_710 < 7); g_710 = safe_add_func_uint8_t_u_u/*60*//* ___SAFE__OP */(g_710, 5))
                    { /* block id: 590 */
                        int32_t *l_1198 = &g_60[1];
                        int32_t *l_1199 = &l_1123;
                        int32_t *l_1200[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1200[i] = (void*)0;
                        l_1209[3][1][3]++;
                    }
                }
            }
        }
        return p_21;
    }
    (*g_1212) = ((*g_287) = &l_1201);
    if (p_21)
        goto lbl_1214;
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_698 g_893 g_197 g_198 g_60 g_49 g_287
 * writes: g_698 g_894 g_49 g_60 g_46 g_106 g_288
 */
static int32_t  func_22(int64_t  p_23, uint64_t  p_24, uint64_t  p_25, int32_t  p_26)
{ /* block id: 497 */
    struct S0 *l_1010 = &g_917;
    struct S0 **l_1009 = &l_1010;
    struct S0 ***l_1008[7] = {&l_1009,&l_1009,&l_1009,&l_1009,&l_1009,&l_1009,&l_1009};
    struct S0 ****l_1007 = &l_1008[1];
    int32_t l_1011 = 0x1E0D57B5L;
    int i;
    for (g_698 = (-17); (g_698 < 5); g_698 = safe_add_func_uint8_t_u_u/*61*//* ___SAFE__OP */(g_698, 3))
    { /* block id: 500 */
        uint32_t l_1000[1][1][2];
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 2; k++)
                    l_1000[i][j][k] = 0x6B6E9D56L;
            }
        }
        (*g_893) = (safe_lshift_func_uint8_t_u_u(l_1000[0][0][0], 3));
        if ((*g_197))
            continue;
    }
    (*g_287) = (((p_26 | (safe_rshift_func_uint8_t_u_s/*63*//* ___SAFE__OP */(((safe_rshift_func_int8_t_s_u(p_25, 5)) || (safe_rshift_func_uint8_t_u_s/*65*//* ___SAFE__OP */((0x6BL && ((void*)0 != l_1007)), 7))), 1))) != 0x1681L) , func_64(l_1011, &l_1011));
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_861 g_60 g_893 g_894 g_139 g_226 g_49 g_287 g_106
 * writes: g_861 g_894 g_139 g_49 g_60 g_46 g_106 g_288
 */
static int8_t  func_33(uint32_t  p_34, int8_t  p_35, int32_t  p_36)
{ /* block id: 454 */
    int32_t *l_898 = &g_60[0];
    int32_t *l_899 = &g_139;
    int32_t *l_900 = &g_60[1];
    int32_t *l_901 = (void*)0;
    int32_t *l_902 = &g_60[1];
    int32_t *l_903[8] = {&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139};
    uint16_t l_904 = 0x4B23L;
    struct S0 *l_916 = &g_917;
    struct S0 **l_915[4] = {&l_916,&l_916,&l_916,&l_916};
    struct S0 *** const l_914 = &l_915[1];
    struct S0 *** const *l_913 = &l_914;
    int16_t **l_922 = &g_265;
    int8_t l_930 = 0xBEL;
    uint8_t l_931 = 0xE3L;
    uint8_t l_972 = 0UL;
    int i;
    l_904++;
    for (g_861 = 0; (g_861 <= 7); g_861 += 1)
    { /* block id: 458 */
        int i;
        (*g_893) ^= (*l_900);
        for (g_139 = 6; (g_139 >= 0); g_139 -= 1)
        { /* block id: 462 */
            uint64_t *l_911[2][7][3] = {{{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0}},{{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710},{(void*)0,&g_710,(void*)0},{&g_710,&g_710,&g_710}}};
            int32_t l_912[3];
            int32_t l_929 = 0x03D9D36AL;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_912[i] = 0L;
        }
        for (p_36 = 4; (p_36 >= 0); p_36 -= 1)
        { /* block id: 491 */
            int i;
            if (g_226[p_36])
                break;
        }
        (*g_287) = func_64(p_35, l_901);
    }
    return g_106;
}


/* ------------------------------------------ */
/* 
 * reads : g_256 g_254 g_60 g_698 g_760.f0 g_893 g_49 g_603 g_190 g_121 g_541 g_287 g_276
 * writes: g_46 g_49 g_60 g_698 g_861 g_121 g_288 g_894
 */
static uint32_t  func_37(int32_t  p_38, uint32_t  p_39, int64_t  p_40, int8_t  p_41)
{ /* block id: 1 */
    uint64_t l_44 = 0x6B5A7DD9AE65C342LL;
    uint8_t *l_45 = &g_46;
    int32_t *l_888[7] = {&g_468,&g_468,&g_468,&g_468,&g_468,&g_468,&g_468};
    int64_t *l_895 = &g_861;
    int64_t *l_896 = &g_121[0];
    int8_t l_897 = 0x93L;
    int i;
    (*g_287) = (((func_42(((*l_45) = l_44)) , (safe_unary_minus_func_uint64_t_u/*66*//* ___SAFE__OP */(g_760.f0))) , (safe_lshift_func_int32_t_s_u/*67*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_s/*68*//* ___SAFE__OP */((0xE6L & (((((void*)0 != l_888[5]) & (((*l_896) ^= ((*l_895) = (safe_mod_func_int32_t_s_s/*69*//* ___SAFE__OP */(((p_39 , 0UL) ^ (safe_mod_func_int16_t_s_s/*70*//* ___SAFE__OP */(((g_893 == (void*)0) | l_44), g_49))), (*g_603))))) & g_541[3])) < 6UL) == l_44)), l_44)), l_897))) , l_888[0]);
    (*g_893) = p_41;
    return g_276;
}


/* ------------------------------------------ */
/* 
 * reads : g_256 g_254 g_60 g_698
 * writes: g_49 g_60 g_698
 */
static uint8_t  func_42(uint8_t  p_43)
{ /* block id: 3 */
    uint8_t l_47 = 0x28L;
    int32_t * const l_59 = &g_60[1];
    uint32_t l_830 = 7UL;
    uint16_t *l_875[9] = {&g_541[1],&g_295[0][0][1],&g_541[1],&g_541[1],&g_295[0][0][1],&g_541[1],&g_541[1],&g_295[0][0][1],&g_541[1]};
    uint16_t **l_874[9][5] = {{&l_875[7],&l_875[7],&l_875[7],&l_875[2],&l_875[7]},{(void*)0,(void*)0,&l_875[7],&l_875[7],&l_875[7]},{&l_875[7],&l_875[7],&l_875[7],&l_875[2],&l_875[7]},{(void*)0,(void*)0,&l_875[7],&l_875[7],&l_875[7]},{&l_875[7],&l_875[7],&l_875[7],&l_875[2],&l_875[7]},{(void*)0,(void*)0,&l_875[7],&l_875[7],&l_875[7]},{&l_875[7],&l_875[7],&l_875[7],&l_875[2],&l_875[7]},{(void*)0,(void*)0,&l_875[7],&l_875[7],&l_875[7]},{&l_875[7],&l_875[7],&l_875[7],&l_875[2],&l_875[7]}};
    int32_t l_882[6];
    int i, j;
    for (i = 0; i < 6; i++)
        l_882[i] = 0x6109968BL;
    if (l_47)
    { /* block id: 4 */
        uint32_t l_48[8][7][4] = {{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}},{{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL},{0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL,0xB7BE74FDL}}};
        uint8_t *l_58 = &l_47;
        int32_t *l_72[1];
        const int32_t *l_73[1][3][4] = {{{&g_60[1],(void*)0,(void*)0,&g_60[1]},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_60[1],(void*)0}}};
        uint8_t *l_75 = &l_47;
        uint8_t **l_74 = &l_75;
        struct S0 l_76 = {0,3,854};
        uint16_t *l_806 = (void*)0;
        uint16_t *l_807 = &g_541[5];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_72[i] = (void*)0;
        g_49 = l_48[4][4][1];
    }
    else
    { /* block id: 435 */
        int64_t *l_879 = &g_573;
        int64_t **l_878 = &l_879;
        (*l_59) = ((*g_256) == l_878);
    }
    if (p_43)
    { /* block id: 438 */
        return (*l_59);
    }
    else
    { /* block id: 440 */
        for (g_698 = 0; (g_698 != 9); g_698 = safe_add_func_uint32_t_u_u/*71*//* ___SAFE__OP */(g_698, 3))
        { /* block id: 443 */
            (*l_59) = 0xEEE49168L;
        }
    }
    l_882[2] |= ((p_43 <= (*l_59)) & 18446744073709551615UL);
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_139 g_197 g_198 g_46 g_330 g_287 g_288 g_60 g_49 g_276 g_249 g_250 g_121 g_106 g_226 g_256 g_254 g_295 g_141 g_411 g_190 g_203.f2 g_203.f0 g_203.f1 g_541 g_468 g_545 g_573 g_603 g_698 g_715 g_546 g_7 g_710
 * writes: g_139 g_330 g_49 g_60 g_46 g_106 g_288 g_276 g_287 g_121 g_141 g_190 g_467 g_207 g_546 g_573 g_602 g_265 g_710 g_698 g_545 g_541
 */
static int32_t  func_52(uint8_t * p_53, int32_t * const  p_54, uint8_t * p_55, int32_t * p_56, uint8_t * p_57)
{ /* block id: 159 */
    uint16_t l_325[2];
    int32_t **l_331 = &g_288[2][0];
    int32_t l_356 = 6L;
    int32_t l_385 = 0x836B807CL;
    int32_t l_391 = (-1L);
    int32_t l_392 = 0L;
    int32_t l_394 = 0L;
    int32_t l_397 = 0x857F8C8CL;
    int32_t l_398[8][5] = {{0xA9BD878AL,0xFE482D0FL,0xFE482D0FL,0xA9BD878AL,0x122D1E0EL},{0L,0xD2836525L,0L,(-1L),0L},{0xA9BD878AL,0xA9BD878AL,1L,0xFE482D0FL,0x122D1E0EL},{0x42ED4935L,(-1L),(-5L),(-1L),0x42ED4935L},{0x122D1E0EL,0xFE482D0FL,1L,0xA9BD878AL,0xA9BD878AL},{0L,(-1L),0L,0xD2836525L,0L},{0x122D1E0EL,0xA9BD878AL,0xFE482D0FL,0xFE482D0FL,0xA9BD878AL},{0x42ED4935L,0xD2836525L,(-5L),0xD2836525L,0x42ED4935L}};
    int16_t l_697 = 0L;
    uint32_t l_699[7] = {0x96FA2DDEL,1UL,0x96FA2DDEL,0x96FA2DDEL,1UL,0x96FA2DDEL,0x96FA2DDEL};
    uint64_t *l_709 = &g_710;
    struct S0 l_711 = {4,4,-981};
    int32_t l_714 = (-5L);
    int32_t **l_749 = &g_467[3][4][0];
    volatile struct S0 *l_759 = &g_760;
    int16_t l_805[5][6] = {{0xAE07L,(-1L),0x26BDL,0x5D3BL,0x5D3BL,0x26BDL},{0xAE07L,0xAE07L,0x5D3BL,0x55FAL,0x8F33L,0x55FAL},{(-1L),0xAE07L,(-1L),0x26BDL,0x5D3BL,0x5D3BL},{4L,(-1L),(-1L),4L,0xAE07L,0x55FAL},{0x55FAL,4L,0x5D3BL,4L,0x55FAL,0x26BDL}};
    int i, j;
    for (i = 0; i < 2; i++)
        l_325[i] = 0xAD5EL;
    for (g_139 = 0; (g_139 <= 0); g_139 += 1)
    { /* block id: 162 */
        int16_t **l_324[7];
        int32_t l_328 = 1L;
        uint8_t *l_329 = &g_330;
        int32_t l_332 = 0L;
        int32_t l_390[5][8][1] = {{{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L}},{{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L}},{{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L}},{{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L}},{{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L},{0x5606A952L},{0L},{0x5606A952L}}};
        int32_t *l_585 = &l_394;
        uint32_t l_630 = 0x678224DAL;
        const int64_t l_662 = 0xF0FE2714E93AEF57LL;
        int16_t l_696 = (-1L);
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_324[i] = (void*)0;
        (*l_331) = func_64(((((((*p_53) = ((void*)0 != l_324[0])) & ((*g_197) , l_325[1])) , (-2L)) & ((*l_329) &= ((safe_lshift_func_uint8_t_u_u/*72*//* ___SAFE__OP */(0x22L, 0)) & (l_328 = g_46)))) == ((((((*g_197) || 0xFD6F96F3L) , (void*)0) == l_331) | l_332) & l_332)), (*g_287));
        if (l_328)
        { /* block id: 167 */
            return l_328;
        }
        else
        { /* block id: 169 */
            int8_t *l_335 = (void*)0;
            int8_t *l_336[3][4][1] = {{{&g_276},{&g_276},{(void*)0},{&g_276}},{{(void*)0},{&g_276},{&g_276},{(void*)0}},{{&g_276},{(void*)0},{&g_276},{&g_276}}};
            int32_t l_341 = 0x82308056L;
            int32_t l_373 = 0x966889BCL;
            int32_t *l_374 = &g_141;
            int32_t l_386 = 0L;
            int32_t l_387 = (-1L);
            int32_t l_388 = 0xEF88663BL;
            int32_t l_389 = 0L;
            int32_t l_393 = 0xE6BE8D91L;
            int32_t l_395 = (-1L);
            int32_t l_396[4][3][1];
            int64_t l_399[9][8][3] = {{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}},{{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)},{0x18EB14B404C0DA5FLL,0xC374DF2F93B74952LL,0x18EB14B404C0DA5FLL},{0xB039B658798CC1B1LL,(-3L),(-3L)},{0x36C433F4CFAEA7CCLL,0xC374DF2F93B74952LL,0x36C433F4CFAEA7CCLL},{0xB039B658798CC1B1LL,0xB039B658798CC1B1LL,(-3L)}}};
            int32_t l_400 = 0x92C4B39BL;
            struct S0 l_436 = {6,1,517};
            uint64_t l_444 = 0UL;
            int i, j, k;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_396[i][j][k] = 0xB4C32286L;
                }
            }
            (*p_54) ^= ((safe_mod_func_uint16_t_u_u/*73*//* ___SAFE__OP */((((((g_276 &= 0x1DL) < (g_139 & ((((+(safe_lshift_func_int8_t_s_u/*74*//* ___SAFE__OP */((~((l_341 == (**g_249)) != (safe_sub_func_int64_t_s_s/*75*//* ___SAFE__OP */((((safe_div_func_uint64_t_u_u/*76*//* ___SAFE__OP */((((safe_unary_minus_func_uint8_t_u/*77*//* ___SAFE__OP */((((((safe_mod_func_uint64_t_u_u/*78*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u/*79*//* ___SAFE__OP */((*p_53), l_341)), (safe_sub_func_int16_t_s_s/*80*//* ___SAFE__OP */(g_106, l_341)))) , (safe_rshift_func_uint16_t_u_u/*81*//* ___SAFE__OP */(((((+(l_325[1] > g_330)) || l_341) ^ g_226[2]) == l_328), l_341))) , 0L) , l_328) != 0x40L))) != l_356) >= 0x4818L), 0xA5F05DE2EDC6F922LL)) , 1UL) || (***g_256)), 0x667EA78243528B4ALL)))), 7))) , (**g_249)) | l_341) || l_341))) != l_341) != 0x527131D98C76D83FLL) & 0UL), 7UL)) && 0x7225EB02964983E5LL);
            if ((safe_sub_func_uint8_t_u_u/*82*//* ___SAFE__OP */(0xC1L, (~((*l_331) == p_54)))))
            { /* block id: 172 */
                int16_t l_368 = 0x9A28L;
                const int32_t l_371[2][1][5] = {{{0x97C2D6C3L,0x97C2D6C3L,0x97C2D6C3L,0x97C2D6C3L,0x97C2D6C3L}},{{(-9L),(-9L),(-9L),(-9L),(-9L)}}};
                int32_t *l_372 = (void*)0;
                int32_t *l_377 = &g_60[1];
                int32_t *l_378 = &l_373;
                int32_t *l_379 = &l_328;
                int32_t *l_380 = &g_141;
                int32_t *l_381 = &g_141;
                int32_t *l_382 = (void*)0;
                int32_t *l_383 = &g_60[0];
                int32_t *l_384[5];
                uint32_t l_401 = 4294967295UL;
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_384[i] = &l_341;
                l_373 &= (((safe_add_func_int32_t_s_s/*83*//* ___SAFE__OP */(0L, ((*p_57) < 0xB7L))) | ((&g_276 != p_53) <= (safe_mul_func_uint16_t_u_u/*84*//* ___SAFE__OP */((((safe_div_func_uint8_t_u_u/*85*//* ___SAFE__OP */((((*l_329) = ((((4294967290UL || (l_368 ^= (safe_rshift_func_uint32_t_u_u/*86*//* ___SAFE__OP */(4294967295UL, 25)))) != ((l_328 == (safe_rshift_func_int64_t_s_s/*87*//* ___SAFE__OP */(l_341, l_341))) >= (*p_54))) && 0L) > 3L)) == (*p_53)), (*p_57))) <= l_371[0][0][3]) && (*p_53)), g_295[0][0][1])))) ^ 0x91875BBBL);
                for (l_328 = 0; (l_328 <= 0); l_328 += 1)
                { /* block id: 178 */
                    int32_t ***l_376[4] = {&l_331,&l_331,&l_331,&l_331};
                    int i;
                    l_374 = (*l_331);
                    g_287 = l_331;
                    for (l_356 = 0; (l_356 <= 0); l_356 += 1)
                    { /* block id: 183 */
                        int i, j, k;
                        (*l_331) = func_64(g_295[g_139][l_328][(g_139 + 1)], func_64(g_49, &l_328));
                        return (*p_54);
                    }
                }
                for (g_106 = 0; (g_106 <= 0); g_106 += 1)
                { /* block id: 190 */
                    return (*p_54);
                }
                --l_401;
            }
            else
            { /* block id: 194 */
                uint16_t l_408 = 65535UL;
                int32_t l_416 = 0x6E81AE16L;
                uint32_t l_463 = 4UL;
                if ((*p_54))
                { /* block id: 195 */
                    int32_t **l_414 = &g_288[9][2];
                    (*l_374) = ((safe_mod_func_int16_t_s_s/*88*//* ___SAFE__OP */((safe_mod_func_int8_t_s_s/*89*//* ___SAFE__OP */(((((l_408 <= (((g_121[5] = ((*l_374) , ((0x4CL >= (safe_mod_func_uint16_t_u_u/*90*//* ___SAFE__OP */(((0x0CCC0D73L & (g_411 , ((*l_374) <= ((*l_374) < ((((g_121[3] == ((safe_rshift_func_int64_t_s_s/*91*//* ___SAFE__OP */((&p_54 != l_414), l_390[0][2][0])) , 6UL)) ^ 0UL) <= l_408) && 0UL))))) == 0x5D571919L), l_332))) < l_408))) | l_390[2][7][0]) , g_226[3])) & 0xBDL) >= g_190) , l_390[0][4][0]), 5UL)), l_390[2][3][0])) && (*l_374));
                }
                else
                { /* block id: 198 */
                    uint64_t l_424 = 0xD251325A87A4DF89LL;
                    uint32_t *l_434 = (void*)0;
                    uint32_t *l_435 = &g_190;
                    int32_t l_439 = (-7L);
                    int32_t l_440 = 0x3F660C1DL;
                    int32_t l_441 = 0xF1AB0378L;
                    int32_t l_442 = 1L;
                    int32_t l_443[10][8][3] = {{{0x47779AA6L,0x309C8CC3L,0x005DD1F9L},{(-9L),0L,0x961830DFL},{0xC1CEFA76L,0x39997598L,1L},{(-10L),(-9L),1L},{0x80F737CDL,(-1L),0x8583B7D8L},{0x242EEA31L,(-4L),0xC1CEFA76L},{1L,0xA1DD3402L,(-7L)},{0xA1DD3402L,1L,0xC1CEFA76L}},{{(-4L),0x242EEA31L,0x8583B7D8L},{0xE219B264L,0xA1DD3402L,(-6L)},{(-2L),0xAE97BBC2L,(-6L)},{0L,(-1L),0x8583B7D8L},{1L,(-2L),0xC1CEFA76L},{0x0DA0B9A1L,0xA17665F8L,(-7L)},{0L,0x242EEA31L,0xC1CEFA76L},{0xAE97BBC2L,0x0DA0B9A1L,0x8583B7D8L}},{{0L,0xA17665F8L,(-6L)},{(-4L),(-4L),(-6L)},{0xA17665F8L,0L,0x8583B7D8L},{0x0DA0B9A1L,0xAE97BBC2L,0xC1CEFA76L},{0x242EEA31L,0L,(-7L)},{0xA17665F8L,0x0DA0B9A1L,0xC1CEFA76L},{(-2L),1L,0x8583B7D8L},{(-1L),0L,(-6L)}},{{0xAE97BBC2L,(-2L),(-6L)},{0xA1DD3402L,0xE219B264L,0x8583B7D8L},{0x242EEA31L,(-4L),0xC1CEFA76L},{1L,0xA1DD3402L,(-7L)},{0xA1DD3402L,1L,0xC1CEFA76L},{(-4L),0x242EEA31L,0x8583B7D8L},{0xE219B264L,0xA1DD3402L,(-6L)},{(-2L),0xAE97BBC2L,(-6L)}},{{0L,(-1L),0x8583B7D8L},{1L,(-2L),0xC1CEFA76L},{0x0DA0B9A1L,0xA17665F8L,(-7L)},{0L,0x242EEA31L,0xC1CEFA76L},{0xAE97BBC2L,0x0DA0B9A1L,0x8583B7D8L},{0L,0xA17665F8L,(-6L)},{(-4L),(-4L),(-6L)},{0xA17665F8L,0L,0x8583B7D8L}},{{0x0DA0B9A1L,0xAE97BBC2L,0xC1CEFA76L},{0x242EEA31L,0L,(-7L)},{0xA17665F8L,0x0DA0B9A1L,0xC1CEFA76L},{(-2L),1L,0x8583B7D8L},{(-1L),0L,(-6L)},{0xAE97BBC2L,(-2L),(-6L)},{0xA1DD3402L,0xE219B264L,0x8583B7D8L},{0x242EEA31L,(-4L),0xC1CEFA76L}},{{1L,0xA1DD3402L,(-7L)},{0xA1DD3402L,1L,0xC1CEFA76L},{(-4L),0x242EEA31L,0x8583B7D8L},{0xE219B264L,0xA1DD3402L,(-6L)},{(-2L),0xAE97BBC2L,(-6L)},{0L,(-1L),0x8583B7D8L},{1L,(-2L),0xC1CEFA76L},{0x0DA0B9A1L,0xA17665F8L,(-7L)}},{{0L,0x242EEA31L,0xC1CEFA76L},{0xAE97BBC2L,0x0DA0B9A1L,0x8583B7D8L},{0L,0xA17665F8L,(-6L)},{(-4L),(-4L),(-6L)},{0xA17665F8L,0L,0x8583B7D8L},{0x0DA0B9A1L,0xAE97BBC2L,0xC1CEFA76L},{0x242EEA31L,0L,(-7L)},{0xA17665F8L,0x0DA0B9A1L,0xC1CEFA76L}},{{(-2L),1L,0x8583B7D8L},{(-1L),0L,(-6L)},{0xAE97BBC2L,(-2L),(-6L)},{0xA1DD3402L,0xE219B264L,0x8583B7D8L},{0x242EEA31L,0xFC00396AL,(-1L)},{0L,1L,0x9C4E886DL},{1L,0L,(-1L)},{0xFC00396AL,1L,0L}},{{0x6EA09242L,1L,(-4L)},{(-8L),1L,(-4L)},{1L,1L,0L},{0L,(-8L),(-1L)},{0x961830DFL,0x5C81A6F6L,0x9C4E886DL},{1L,1L,(-1L)},{1L,0x961830DFL,0L},{1L,0x5C81A6F6L,(-4L)}}};
                    int32_t l_460 = 0xBD5440D9L;
                    int i, j, k;
                    (*l_374) ^= 0x3916DEC0L;
                    for (l_387 = 0; (l_387 >= 0); l_387 -= 1)
                    { /* block id: 202 */
                        int64_t l_415 = 7L;
                        int32_t *l_417 = &l_396[2][2][0];
                        int32_t *l_418 = &g_141;
                        int32_t *l_419 = &g_60[1];
                        int32_t *l_420 = &l_400;
                        int32_t *l_421 = &l_397;
                        int32_t *l_422 = &l_390[4][6][0];
                        int32_t *l_423[8] = {(void*)0,&l_397,(void*)0,&l_397,(void*)0,&l_397,(void*)0,&l_397};
                        int i;
                        l_424--;
                        if (l_356)
                            goto lbl_716;
                    }
                    for (l_394 = 0; (l_394 <= 0); l_394 += 1)
                    { /* block id: 207 */
                        return (*p_54);
                    }
                    if ((safe_add_func_int8_t_s_s/*92*//* ___SAFE__OP */(g_411, ((g_276 = ((l_424 != ((l_424 < ((safe_mod_func_int64_t_s_s/*93*//* ___SAFE__OP */(l_408, l_408)) || (((0UL && ((((*p_54) = (((+(safe_rshift_func_int8_t_s_s/*94*//* ___SAFE__OP */((l_424 > (((*l_435) |= l_416) || ((void*)0 != p_53))), g_198))) != 0x69L) == 247UL)) & l_424) > (*l_374))) , l_436) , 0UL))) > l_416)) ^ (-2L))) == g_198))))
                    { /* block id: 213 */
                        int32_t *l_437 = &l_328;
                        int32_t *l_438[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_438[i] = &l_391;
                        l_444--;
                    }
                    else
                    { /* block id: 215 */
                        int32_t *l_449 = &l_356;
                        const int32_t l_450 = 0L;
                        struct S0 l_459[3][2] = {{{7,4,291},{7,4,291}},{{7,4,291},{7,4,291}},{{7,4,291},{7,4,291}}};
                        int64_t *l_461 = &l_399[8][4][2];
                        int64_t *l_462 = &g_121[3];
                        uint8_t l_464 = 255UL;
                        int32_t **l_465 = (void*)0;
                        int32_t **l_466[7] = {(void*)0,&l_449,(void*)0,(void*)0,&l_449,(void*)0,(void*)0};
                        int i, j;
                        (*p_54) &= (safe_mul_func_int64_t_s_s/*95*//* ___SAFE__OP */((((*l_449) = 0x9EE1B0FCL) , l_450), ((safe_mul_func_uint8_t_u_u/*96*//* ___SAFE__OP */((l_463 = ((++(*p_57)) != (((+(((0xF20A3C7D15100DA6LL >= ((*l_462) |= (safe_add_func_uint64_t_u_u/*97*//* ___SAFE__OP */((~(p_53 != (l_408 , func_69(p_56, l_459[1][0])))), (((*l_461) = l_460) != l_390[2][7][0]))))) >= 0UL) != 0x5674C8F2L)) >= l_459[1][0].f2) == g_203.f2))), l_464)) , l_463)));
                        (*l_374) |= ((g_288[6][2] == (g_467[3][4][0] = l_374)) >= 0x1F0DL);
                    }
                }
                (*g_287) = (*l_331);
            }
        }
        for (l_394 = 0; (l_394 <= 0); l_394 += 1)
        { /* block id: 231 */
            uint8_t l_470 = 255UL;
            int8_t *l_490 = &g_276;
            int32_t l_504 = 0x4D7835CFL;
            int32_t l_505 = 0x59CBD55DL;
            int32_t l_506 = 9L;
            int32_t l_508 = 3L;
            int32_t l_509[7] = {0L,0L,0L,0L,0L,0L,0L};
            uint32_t * const l_588 = &g_190;
            int32_t l_629 = 2L;
            int16_t l_664 = 9L;
            int i;
            for (l_391 = 0; (l_391 <= 0); l_391 += 1)
            { /* block id: 234 */
                int8_t l_469[7][5] = {{(-1L),(-1L),(-6L),0x24L,(-1L)},{2L,0x20L,0x20L,2L,1L},{1L,0x24L,0x9FL,0x9FL,0x24L},{1L,0x20L,(-3L),1L,1L},{(-7L),(-1L),(-7L),0x9FL,(-6L)},{0xB8L,2L,1L,2L,0xB8L},{(-7L),1L,(-1L),0x24L,(-1L)}};
                int i, j;
                l_469[4][2] |= (*p_54);
                if (l_470)
                    continue;
            }
            for (g_330 = 0; (g_330 <= 0); g_330 += 1)
            { /* block id: 240 */
                uint16_t l_471 = 65535UL;
                uint32_t *l_484 = &g_190;
                int32_t *l_488 = &l_390[1][4][0];
                uint64_t l_489 = 1UL;
                int32_t l_503[3];
                int16_t l_512 = 1L;
                uint32_t l_513 = 0UL;
                int i;
                for (i = 0; i < 3; i++)
                    l_503[i] = (-10L);
                (*p_54) = l_471;
                (*l_488) |= (safe_sub_func_int32_t_s_s/*98*//* ___SAFE__OP */((((safe_div_func_uint64_t_u_u/*99*//* ___SAFE__OP */((l_470 && (--(*p_57))), (((safe_div_func_int16_t_s_s/*100*//* ___SAFE__OP */(((safe_div_func_int32_t_s_s/*101*//* ___SAFE__OP */((0x888AE71177D13B6FLL > (safe_sub_func_uint32_t_u_u/*102*//* ___SAFE__OP */(l_332, ((l_385 <= g_203.f0) < 0xB163A981B0D22350LL)))), ((*l_484) = g_49))) ^ (~(safe_mul_func_int8_t_s_s/*103*//* ___SAFE__OP */(((g_46 = (l_470 , 0x01L)) < 0x8EL), g_60[0])))), l_394)) <= g_121[0]) , 0x8CB4816DE83F2A3ELL))) || 0xB9E2B439L) != 248UL), 0x42CDAE55L));
                for (g_141 = 0; (g_141 >= 0); g_141 -= 1)
                { /* block id: 248 */
                    int8_t *l_491 = &g_276;
                    int32_t l_507 = 6L;
                    int32_t l_510[2][3] = {{(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L)}};
                    int16_t l_511 = 0xD6ABL;
                    int i, j;
                    l_489 = (l_470 > g_203.f1);
                    if ((l_490 == l_491))
                    { /* block id: 250 */
                        int32_t *l_492 = &l_385;
                        int32_t *l_493 = &l_398[1][2];
                        int32_t *l_494 = &l_392;
                        int32_t *l_495 = &l_398[7][3];
                        int32_t *l_496 = &l_391;
                        int32_t *l_497 = &l_392;
                        int32_t *l_498 = (void*)0;
                        int32_t *l_499 = &l_392;
                        int32_t *l_500 = &l_392;
                        int32_t *l_501 = &l_391;
                        int32_t *l_502[8][3][4] = {{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_397,&l_390[2][3][0]},{&l_390[2][3][0],&g_139,&g_139,&l_390[2][3][0]},{&g_139,&l_390[2][3][0],&g_139,&g_139}},{{&l_390[2][3][0],&l_390[2][3][0],&l_390[2][3][0],&g_139},{&g_139,&l_397,&l_397,&g_139},{&l_397,&g_139,&l_397,&l_397}}};
                        int i, j, k;
                        ++l_513;
                    }
                    else
                    { /* block id: 252 */
                        (*l_331) = (void*)0;
                    }
                }
            }
            for (l_504 = 0; (l_504 <= 0); l_504 += 1)
            { /* block id: 259 */
                uint8_t l_522 = 0UL;
                for (l_508 = 0; (l_508 <= 7); l_508 += 1)
                { /* block id: 262 */
                    uint64_t l_517 = 0x3B1FA4E80BAEE67ALL;
                    int64_t *l_570 = &g_121[3];
                    int64_t *l_571 = (void*)0;
                    int64_t *l_572 = &g_573;
                    for (g_207 = 0; (g_207 <= 0); g_207 += 1)
                    { /* block id: 265 */
                        int32_t *l_516[7] = {&g_60[1],&g_60[1],&g_60[1],&g_60[1],&g_60[1],&g_60[1],&g_60[1]};
                        int64_t *l_539 = (void*)0;
                        int64_t *l_540 = &g_121[2];
                        uint64_t *l_542 = (void*)0;
                        uint64_t *l_543[2][3];
                        int32_t **l_544 = (void*)0;
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_543[i][j] = (void*)0;
                        }
                        --l_517;
                        (*g_545) = (((-5L) ^ (((g_411 & ((l_332 = ((((safe_lshift_func_uint32_t_u_u/*104*//* ___SAFE__OP */(l_522, 1)) <= ((safe_mod_func_int32_t_s_s/*105*//* ___SAFE__OP */((safe_div_func_int16_t_s_s/*106*//* ___SAFE__OP */(((l_328 = 0L) != (l_517 == (safe_add_func_int64_t_s_s/*107*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/*108*//* ___SAFE__OP */(g_46, ((((*l_540) = (((safe_add_func_uint64_t_u_u/*109*//* ___SAFE__OP */((1L & (safe_lshift_func_uint32_t_u_u/*110*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/*111*//* ___SAFE__OP */(l_517, g_330)) != g_60[0]), l_390[2][7][0]))), l_470)) , 0x4018L) , l_522)) >= l_509[2]) | 0x565604DBAA6A9FAFLL))), g_541[5])))), g_468)), l_508)) | g_190)) , 0xD11BL) | l_332)) && g_190)) , 1UL) , 0xCD0AL)) , l_544);
                        (*p_54) = l_517;
                    }
                    (*p_54) = ((0x20BFB858C7D1F471LL && (l_504 | (((safe_mod_func_uint64_t_u_u/*112*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_u/*113*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/*114*//* ___SAFE__OP */((((*p_57) < l_390[3][4][0]) , (safe_add_func_int32_t_s_s/*115*//* ___SAFE__OP */((255UL != (l_517 & ((safe_mod_func_uint16_t_u_u/*116*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u/*117*//* ___SAFE__OP */(((safe_rshift_func_int64_t_s_u/*118*//* ___SAFE__OP */((+((g_541[5] == 1UL) >= (safe_sub_func_uint16_t_u_u/*119*//* ___SAFE__OP */((l_522 , 0xA5DBL), l_522)))), l_517)) > (**g_249)), (-1L))), g_330)) <= g_295[0][0][1]))), l_517))), l_522)), g_295[1][0][1])) && (*p_57)), l_390[4][3][0])) || (*p_57)) <= l_517))) > 0x567CD13A49A45479LL);
                    (*l_331) = (*l_331);
                    (*l_331) = func_64(((((((safe_lshift_func_uint8_t_u_u/*120*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/*121*//* ___SAFE__OP */(l_390[2][7][0], (*p_54))), (((((0x8D70B3F9L | (safe_lshift_func_int64_t_s_s/*122*//* ___SAFE__OP */(((*l_570) = l_522), 28))) == (0UL <= (((*l_572) ^= ((*p_53) ^ 0L)) ^ (safe_add_func_int32_t_s_s/*123*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/*124*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u/*125*//* ___SAFE__OP */(((1L | (((safe_mul_func_uint64_t_u_u/*126*//* ___SAFE__OP */(((+((safe_rshift_func_uint8_t_u_s/*127*//* ___SAFE__OP */(l_390[2][7][0], 4)) <= 9UL)) < l_517), 0x8724CF460E0A7AB1LL)) ^ (-1L)) | l_517)) > g_276), g_295[0][0][0])), 0x60L)), l_517))))) || l_470) , 0xFD18L) && l_328))) == l_517) == l_470) == l_505) & l_505) != l_505), p_56);
                }
                for (l_392 = 0; (l_392 <= 0); l_392 += 1)
                { /* block id: 281 */
                    (*g_287) = l_585;
                    for (g_276 = 0; (g_276 <= 0); g_276 += 1)
                    { /* block id: 285 */
                        uint32_t *l_589 = (void*)0;
                        l_508 = (safe_sub_func_int8_t_s_s/*128*//* ___SAFE__OP */((l_505 ^ 0x39L), (((l_588 == l_589) > ((*p_54) = (g_60[1] , (safe_add_func_int64_t_s_s/*129*//* ___SAFE__OP */((g_121[3] = 6L), ((safe_sub_func_int16_t_s_s/*130*//* ___SAFE__OP */(((*l_585) != (*g_197)), (*l_585))) > (*l_585))))))) ^ l_522)));
                        if ((*p_54))
                            break;
                    }
                    if ((*l_585))
                        break;
                }
            }
            if ((*g_197))
            { /* block id: 294 */
                uint16_t l_599 = 0x120CL;
                int32_t *l_617[8][2][4] = {{{&g_139,&l_509[6],(void*)0,&g_139},{(void*)0,&g_139,(void*)0,(void*)0}},{{&g_139,&g_139,&l_392,(void*)0},{&g_139,&l_509[6],(void*)0,&g_139}},{{(void*)0,(void*)0,(void*)0,(void*)0},{&g_139,(void*)0,&l_392,&g_139}},{{(void*)0,&l_509[6],&l_509[6],(void*)0},{(void*)0,&g_139,&l_509[6],(void*)0}},{{(void*)0,&g_139,&l_392,&g_139},{&g_139,&l_509[6],(void*)0,&g_139}},{{(void*)0,&g_139,(void*)0,(void*)0},{&g_139,&g_139,&l_392,(void*)0}},{{&g_139,&l_509[6],(void*)0,&g_139},{(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_139,(void*)0,&l_392,&g_139},{(void*)0,&l_509[6],&l_509[6],(void*)0}}};
                int i, j, k;
                if ((*p_54))
                { /* block id: 295 */
                    int32_t *l_594 = &l_398[0][4];
                    l_594 = ((*g_287) = p_56);
                }
                else
                { /* block id: 298 */
                    uint8_t l_600 = 255UL;
                    (*p_54) &= (+(+(1UL <= (((((safe_mul_func_int8_t_s_s/*131*//* ___SAFE__OP */((l_599 && 0x189C0C57FE6A28EFLL), (l_600 != (!((*p_53) > (0xBDL && ((*l_490) = 0L))))))) || (0x75L >= ((0x2FL | l_508) != (-1L)))) && l_470) | 0x7CL) && 0L))));
                    for (l_392 = 0; (l_392 <= 0); l_392 += 1)
                    { /* block id: 303 */
                        int32_t l_604 = 0x40DEDA19L;
                        int32_t l_605 = (-3L);
                        (*p_54) = (*p_54);
                        g_602 = (void*)0;
                        l_605 = l_604;
                    }
                }
                l_509[2] &= (safe_mod_func_uint64_t_u_u/*132*//* ___SAFE__OP */(1UL, (safe_add_func_uint16_t_u_u/*133*//* ___SAFE__OP */(((((g_265 = &g_7) == (void*)0) , (safe_unary_minus_func_uint32_t_u/*134*//* ___SAFE__OP */(l_470))) < (*l_585)), (((safe_add_func_uint8_t_u_u/*135*//* ___SAFE__OP */(((g_60[1] , (0x2201B421L | (safe_div_func_int32_t_s_s/*136*//* ___SAFE__OP */((l_398[2][1] |= (+((!(*p_54)) , ((*l_585) || 0xF5C18785F2767B4FLL)))), l_470)))) || g_198), 255UL)) & l_506) | g_276)))));
                l_630 ^= (l_629 ^= (~(((0x4C7D4190L <= (*l_585)) >= 0x4EL) <= (65527UL > (g_49 |= (0xE4EAL < (~(((g_295[0][0][0] | l_394) & (safe_div_func_uint64_t_u_u/*137*//* ___SAFE__OP */((((safe_mod_func_uint64_t_u_u/*138*//* ___SAFE__OP */(((safe_mod_func_uint64_t_u_u/*139*//* ___SAFE__OP */(g_60[0], (safe_rshift_func_uint16_t_u_u/*140*//* ___SAFE__OP */((((~l_504) , 0x49L) && g_468), g_468)))) & l_505), (*l_585))) ^ l_385) > (*p_53)), 0x94FBDFC1BC2CBF92LL))) || l_470))))))));
            }
            else
            { /* block id: 315 */
                uint64_t l_631[2][9] = {{18446744073709551615UL,0x117C4619E1C54EEDLL,0x117C4619E1C54EEDLL,18446744073709551615UL,0x3E959C337C2E7097LL,0x1CA19B79DD0834FELL,0x3E959C337C2E7097LL,18446744073709551615UL,0x117C4619E1C54EEDLL},{0x3E959C337C2E7097LL,0x3E959C337C2E7097LL,0x35CA7697B7CC8C15LL,0x1CA19B79DD0834FELL,0xA854AE15AA89EB60LL,0x1CA19B79DD0834FELL,0x35CA7697B7CC8C15LL,0x3E959C337C2E7097LL,0x3E959C337C2E7097LL}};
                int i, j;
                l_509[2] = (l_332 = l_631[1][3]);
            }
            for (g_141 = 0; (g_141 <= 0); g_141 += 1)
            { /* block id: 321 */
                int64_t ***l_663 = (void*)0;
                int32_t l_666 = (-1L);
                int32_t *l_700 = &l_390[2][7][0];
                (*p_54) = (safe_unary_minus_func_uint64_t_u/*141*//* ___SAFE__OP */((+0UL)));
                (*p_54) |= ((safe_mod_func_uint64_t_u_u/*142*//* ___SAFE__OP */((g_139 ^ ((safe_mul_func_uint64_t_u_u/*143*//* ___SAFE__OP */(((l_508 && (safe_mod_func_int32_t_s_s/*144*//* ___SAFE__OP */((9UL >= (*l_585)), (safe_div_func_uint32_t_u_u/*145*//* ___SAFE__OP */((*g_603), ((p_56 != p_54) & ((safe_mod_func_int16_t_s_s/*146*//* ___SAFE__OP */(((*l_585) == (safe_sub_func_int8_t_s_s/*147*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s/*148*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/*149*//* ___SAFE__OP */((((safe_mod_func_uint32_t_u_u/*150*//* ___SAFE__OP */(((safe_div_func_int16_t_s_s/*151*//* ___SAFE__OP */(((safe_sub_func_int16_t_s_s/*152*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u/*153*//* ___SAFE__OP */(((((l_662 , l_663) == (void*)0) >= 0L) > 0x5439B2D876EA3E34LL), (-1L))), 65533UL)) >= l_629), (-1L))) < l_508), (*g_603))) || 0xC602L) <= l_664), 0UL)), g_139)), (*l_585)))), g_121[2])) , 1UL))))))) >= l_506), 18446744073709551615UL)) == l_664)), g_541[4])) , (*g_197));
                (*l_700) |= (safe_unary_minus_func_uint64_t_u/*154*//* ___SAFE__OP */((l_666 , (0x7F82AB60L & ((1UL || (l_398[1][2] = ((((*p_54) || (safe_div_func_uint32_t_u_u/*155*//* ___SAFE__OP */((((*l_585) ^ 0UL) , (safe_add_func_int64_t_s_s/*156*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_u/*157*//* ___SAFE__OP */((*l_585), 3)) >= (0xE94FL || (safe_rshift_func_int8_t_s_s/*158*//* ___SAFE__OP */(((((safe_add_func_int32_t_s_s/*159*//* ___SAFE__OP */(((((safe_div_func_uint32_t_u_u/*160*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/*161*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u/*162*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u/*163*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s/*164*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s/*165*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u/*166*//* ___SAFE__OP */((+((safe_sub_func_uint8_t_u_u/*167*//* ___SAFE__OP */((safe_div_func_int32_t_s_s/*168*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u/*169*//* ___SAFE__OP */(((((*p_54) |= (((void*)0 != p_56) && g_49)) | (*l_585)) < 65534UL), 26)), l_696)), g_106)) != l_666)), 3)))), (*l_585))) < (*p_53)), l_666)))), g_226[4])), 0xEC53F17CL)) <= l_697) , l_508) , (*p_54)), (*l_585))) < 0UL) ^ (*l_585)) | l_629), 3)))), g_698))), (*l_585)))) , l_506) , l_509[6]))) < l_699[3])))));
            }
        }
    }
lbl_716:
    (*g_715) = ((l_697 , (safe_div_func_uint64_t_u_u/*170*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u/*171*//* ___SAFE__OP */(((**g_254) , (safe_add_func_uint8_t_u_u/*172*//* ___SAFE__OP */((((l_398[3][4] = (g_60[0] && (safe_add_func_uint8_t_u_u/*173*//* ___SAFE__OP */(((((*l_709) = 0x890193D8A02254C4LL) , (((l_711 , (safe_lshift_func_int64_t_s_u/*174*//* ___SAFE__OP */((18446744073709551615UL >= (((*p_54) = (l_394 = ((**g_256) != (*g_254)))) == (*g_197))), g_46))) ^ 0xFEL) || l_385)) ^ l_714), l_697)))) ^ 0x9F1A2149D449BE9FLL) == 0UL), (*p_57)))), 255UL)), 0xFB06895D6215CA76LL))) , p_54);
    for (g_330 = 4; (g_330 == 1); --g_330)
    { /* block id: 338 */
        uint8_t l_735[2][4] = {{0x94L,0x94L,0x94L,0x94L},{0x94L,0x94L,0x94L,0x94L}};
        int32_t l_740[5];
        int32_t l_743 = 3L;
        int32_t **l_753[8] = {&g_467[3][4][0],(void*)0,&g_467[3][4][0],(void*)0,&g_467[3][4][0],(void*)0,&g_467[3][4][0],(void*)0};
        int8_t l_772[6][8] = {{1L,1L,(-5L),0x85L,0L,(-5L),0L,0x85L},{4L,0x85L,4L,0x50L,0x85L,0x75L,0x75L,0x85L},{0x85L,0x75L,0x75L,0x85L,0x50L,4L,0x85L,4L},{0x85L,0L,(-5L),0L,0x85L,(-5L),1L,1L},{4L,0L,0x50L,0x50L,0L,4L,0x75L,0L},{1L,0x75L,0x50L,1L,0x50L,0x75L,1L,4L}};
        int32_t l_788 = 0x26BA831DL;
        int32_t *l_801 = &l_394;
        int64_t *l_804 = &g_573;
        int i, j;
        for (i = 0; i < 5; i++)
            l_740[i] = 1L;
        for (l_394 = 0; (l_394 >= (-4)); l_394 = safe_sub_func_int16_t_s_s/*175*//* ___SAFE__OP */(l_394, 8))
        { /* block id: 341 */
            uint32_t l_741 = 0xCF542612L;
            int32_t ***l_752 = &g_546;
            int32_t l_761 = 0L;
            int32_t l_762 = 0L;
            const struct S0 ***l_783 = (void*)0;
            (*g_287) = (void*)0;
            for (l_697 = 6; (l_697 >= 0); l_697 -= 1)
            { /* block id: 345 */
                int32_t l_725 = 0L;
                int8_t *l_734[7] = {&g_698,&g_698,&g_276,&g_698,&g_698,&g_276,&g_698};
                uint8_t *l_742 = &g_46;
                int32_t ***l_746 = &g_546;
                int32_t **l_748 = &g_467[3][4][0];
                int32_t ***l_747 = &l_748;
                int i;
                l_743 |= (safe_mod_func_int8_t_s_s/*176*//* ___SAFE__OP */((((safe_sub_func_int32_t_s_s/*177*//* ___SAFE__OP */((l_725 || ((safe_mul_func_int16_t_s_s/*178*//* ___SAFE__OP */(g_573, ((((safe_lshift_func_int16_t_s_u/*179*//* ___SAFE__OP */((6L != ((*l_742) &= ((*p_57) = ((safe_mod_func_uint8_t_u_u/*180*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_u/*181*//* ___SAFE__OP */((g_573 != ((((l_735[0][1] = l_725) && (*p_53)) != 18446744073709551607UL) , l_735[1][0])), ((safe_add_func_uint64_t_u_u/*182*//* ___SAFE__OP */(((safe_lshift_func_int8_t_s_s/*183*//* ___SAFE__OP */(l_740[0], 0)) == l_741), 0x5D26CD892765F2B9LL)) , 0x18E7800CB7C9225FLL))) && (-1L)), g_60[1])) || l_735[0][1])))), 0)) > 4UL) != 0x0FFE8A2FB0BA6B05LL) != l_725))) < l_741)), (*p_54))) || l_725) , l_740[0]), l_725));
                (*g_287) = ((safe_rshift_func_int16_t_s_s/*184*//* ___SAFE__OP */((((*l_747) = ((*l_746) = (*g_545))) == (l_711 , l_749)), 15)) , func_64((safe_div_func_uint8_t_u_u/*185*//* ___SAFE__OP */((((void*)0 == l_752) & ((l_741 || l_725) <= (l_725 | l_740[0]))), 0x21L)), &l_725));
                if ((l_753[4] != (*l_752)))
                { /* block id: 353 */
                    uint32_t l_754 = 0UL;
                    --l_754;
                }
                else
                { /* block id: 355 */
                    volatile struct S0 *l_758 = &g_203;
                    volatile struct S0 **l_757[1][2][1];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 2; j++)
                        {
                            for (k = 0; k < 1; k++)
                                l_757[i][j][k] = &l_758;
                        }
                    }
                    l_759 = &g_203;
                    for (g_49 = 1; (g_49 <= 6); g_49 += 1)
                    { /* block id: 359 */
                        return l_761;
                    }
                    (*g_287) = (void*)0;
                }
                for (g_698 = 2; (g_698 <= 6); g_698 += 1)
                { /* block id: 366 */
                    int16_t *l_773 = &g_106;
                    int32_t l_774 = 0x2094444AL;
                    const struct S0 *l_777 = &l_711;
                    const struct S0 **l_776 = &l_777;
                    const struct S0 ***l_775 = &l_776;
                    const struct S0 ****l_778 = &l_775;
                    (*p_54) ^= ((((l_762 = 0L) && 1UL) , (0UL > ((((g_190 , (safe_rshift_func_uint8_t_u_s/*186*//* ___SAFE__OP */(((*p_53) , (safe_add_func_int16_t_s_s/*187*//* ___SAFE__OP */((g_7 <= (safe_mul_func_uint16_t_u_u/*188*//* ___SAFE__OP */(((((*l_773) = (safe_add_func_uint8_t_u_u/*189*//* ___SAFE__OP */((*p_57), (l_725 |= (4UL ^ (!l_772[5][4])))))) || 0xBE16L) > 0x1C6A02096E233B75LL), l_761))), 0x78A4L))), 0))) , l_774) == g_46) , (-1L)))) & g_203.f0);
                    l_783 = ((*l_778) = l_775);
                    for (l_762 = 0; (l_762 <= 6); l_762 += 1)
                    { /* block id: 375 */
                        uint8_t l_784 = 0x96L;
                        if (l_385)
                            goto lbl_716;
                        (*g_287) = func_64(l_784, &l_762);
                        g_545 = l_752;
                    }
                }
            }
            (*l_331) = p_56;
            for (g_698 = 0; (g_698 == 6); g_698 = safe_add_func_uint8_t_u_u/*190*//* ___SAFE__OP */(g_698, 8))
            { /* block id: 385 */
                for (g_710 = 2; (g_710 <= 6); g_710 += 1)
                { /* block id: 388 */
                    const struct S0 l_787 = {0,-2,906};
                    (*l_331) = (l_787 , func_64(l_788, p_56));
                }
            }
        }
        for (l_397 = (-2); (l_397 >= 10); l_397++)
        { /* block id: 395 */
            uint8_t l_798 = 0UL;
            uint16_t *l_799 = &g_541[1];
            uint16_t *l_800 = &l_325[1];
            (*p_54) ^= (0x18C32D63L | (safe_rshift_func_uint64_t_u_s/*191*//* ___SAFE__OP */(0x68A59C8E220763ACLL, ((0xE504L <= ((l_735[0][1] > (safe_div_func_uint8_t_u_u/*192*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/*193*//* ___SAFE__OP */(0xFFL, (+((*l_800) = ((*l_799) = ((-1L) == (l_743 || l_798))))))), ((*p_53) = l_788)))) == l_735[1][0])) | 255UL))));
        }
        l_801 = &l_740[2];
        (*l_801) = (safe_lshift_func_uint64_t_u_s/*194*//* ___SAFE__OP */(g_121[5], ((*l_804) = (*l_801))));
    }
    return l_805[1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_141 g_49
 * writes: g_141 g_49
 */
static uint8_t * func_61(int32_t * p_62, uint8_t * p_63)
{ /* block id: 148 */
    int16_t l_308 = (-1L);
    int32_t l_315 = 0x53CEB621L;
    int32_t l_319 = 0xBBB49296L;
    uint8_t *l_323 = (void*)0;
    for (g_141 = (-5); (g_141 > (-20)); g_141 = safe_sub_func_int8_t_s_s/*195*//* ___SAFE__OP */(g_141, 5))
    { /* block id: 151 */
        uint32_t l_320 = 0x546C5381L;
        for (g_49 = 0; (g_49 >= 10); g_49++)
        { /* block id: 154 */
            int32_t *l_301 = &g_139;
            int32_t *l_302 = (void*)0;
            int32_t *l_303 = &g_60[1];
            int32_t *l_304 = &g_139;
            int32_t *l_305 = &g_60[1];
            int32_t *l_306 = &g_139;
            int32_t *l_307 = &g_139;
            int32_t l_309 = (-8L);
            int32_t *l_310 = (void*)0;
            int32_t *l_311 = (void*)0;
            int32_t *l_312 = &g_60[1];
            int32_t *l_313 = &g_60[0];
            int32_t *l_314 = &g_60[1];
            int32_t *l_316 = &g_60[0];
            int32_t *l_317[3];
            int i;
            for (i = 0; i < 3; i++)
                l_317[i] = &l_309;
            --l_320;
        }
    }
    return l_323;
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_49
 * writes: g_49 g_60 g_46 g_106
 */
static int32_t * func_64(uint32_t  p_65, int32_t * p_66)
{ /* block id: 10 */
    int32_t *l_91 = &g_60[0];
    int32_t **l_90 = &l_91;
    int32_t l_102 = (-10L);
    uint8_t **l_115 = (void*)0;
    uint32_t l_176 = 18446744073709551607UL;
    int32_t l_215 = 0x0DC46826L;
    int32_t l_218 = 0x9293DCF5L;
    int32_t l_219 = 0x1282EE7AL;
    int16_t *l_263 = &g_49;
    int32_t *l_296 = &l_102;
    l_90 = &p_66;
    for (p_65 = 0; (p_65 != 18); p_65 = safe_add_func_uint8_t_u_u/*196*//* ___SAFE__OP */(p_65, 6))
    { /* block id: 14 */
        int64_t *l_119 = (void*)0;
        int64_t *l_120 = &g_121[3];
        int32_t l_122 = 0x02198734L;
        struct S0 l_124 = {3,-4,-453};
        uint8_t **l_136 = &g_135;
        int32_t *l_137 = &l_102;
        int32_t *l_138 = &g_139;
        int32_t *l_140[7];
        uint8_t l_156 = 0UL;
        int16_t *l_266 = &g_106;
        int32_t l_289[8][4] = {{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L},{5L,5L,5L,5L}};
        int i, j;
        for (i = 0; i < 7; i++)
            l_140[i] = &g_141;
        for (g_49 = (-25); (g_49 != 28); ++g_49)
        { /* block id: 17 */
            uint32_t l_103 = 0x49B5B57AL;
            int32_t l_107 = (-10L);
            g_60[1] &= 0x622E340DL;
            for (g_46 = 0; (g_46 == 5); g_46 = safe_add_func_int8_t_s_s/*197*//* ___SAFE__OP */(g_46, 7))
            { /* block id: 21 */
                int32_t *l_98 = &g_60[1];
                int32_t *l_99 = &g_60[1];
                int32_t *l_100 = &g_60[1];
                int32_t *l_101[5][1] = {{&g_60[1]},{(void*)0},{&g_60[1]},{(void*)0},{&g_60[1]}};
                uint32_t l_108[7][9] = {{18446744073709551615UL,0xA8EECE75L,7UL,0xA8EECE75L,18446744073709551615UL,18446744073709551615UL,0xA8EECE75L,7UL,0xA8EECE75L},{0xA8EECE75L,18446744073709551615UL,7UL,7UL,18446744073709551615UL,0xA8EECE75L,18446744073709551615UL,7UL,7UL},{18446744073709551615UL,18446744073709551615UL,0xA8EECE75L,7UL,0xA8EECE75L,18446744073709551615UL,18446744073709551615UL,0xA8EECE75L,7UL},{9UL,18446744073709551615UL,9UL,0xA8EECE75L,0xA8EECE75L,9UL,18446744073709551615UL,9UL,0xA8EECE75L},{9UL,0xA8EECE75L,0xA8EECE75L,9UL,18446744073709551615UL,9UL,0xA8EECE75L,0xA8EECE75L,9UL},{18446744073709551615UL,0xA8EECE75L,7UL,0xA8EECE75L,18446744073709551615UL,18446744073709551615UL,0xA8EECE75L,7UL,0xA8EECE75L},{0xA8EECE75L,18446744073709551615UL,7UL,7UL,18446744073709551615UL,0xA8EECE75L,18446744073709551615UL,7UL,7UL}};
                int i, j;
                --l_103;
                if (g_49)
                    continue;
                if ((g_106 = (g_60[0] &= l_103)))
                { /* block id: 26 */
                    --l_108[4][7];
                }
                else
                { /* block id: 28 */
                    return &g_60[0];
                }
            }
        }
    }
    return p_66;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t * func_69(int32_t * p_70, struct S0  p_71)
{ /* block id: 7 */
    int32_t *l_77 = (void*)0;
    int32_t *l_78 = &g_60[1];
    int32_t l_79 = (-2L);
    int32_t *l_80 = (void*)0;
    int32_t *l_81 = &g_60[1];
    int32_t *l_82 = &g_60[1];
    int32_t *l_83 = &g_60[1];
    int32_t *l_84 = &l_79;
    int32_t *l_85[9][4] = {{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]},{&g_60[0],(void*)0,(void*)0,&g_60[0]}};
    int16_t l_86 = (-1L);
    uint32_t l_87 = 1UL;
    int i, j;
    --l_87;
    return &g_46;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_60[i], "g_60[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_121[i], "g_121[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    transparent_crc(g_198, "g_198", print_hash_value);
    transparent_crc(g_203.f0, "g_203.f0", print_hash_value);
    transparent_crc(g_203.f1, "g_203.f1", print_hash_value);
    transparent_crc(g_203.f2, "g_203.f2", print_hash_value);
    transparent_crc(g_207, "g_207", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_226[i], "g_226[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_276, "g_276", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_295[i][j][k], "g_295[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_318, "g_318", print_hash_value);
    transparent_crc(g_330, "g_330", print_hash_value);
    transparent_crc(g_411, "g_411", print_hash_value);
    transparent_crc(g_468, "g_468", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_541[i], "g_541[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_573, "g_573", print_hash_value);
    transparent_crc(g_698, "g_698", print_hash_value);
    transparent_crc(g_710, "g_710", print_hash_value);
    transparent_crc(g_760.f0, "g_760.f0", print_hash_value);
    transparent_crc(g_760.f1, "g_760.f1", print_hash_value);
    transparent_crc(g_760.f2, "g_760.f2", print_hash_value);
    transparent_crc(g_861, "g_861", print_hash_value);
    transparent_crc(g_894, "g_894", print_hash_value);
    transparent_crc(g_917.f0, "g_917.f0", print_hash_value);
    transparent_crc(g_917.f1, "g_917.f1", print_hash_value);
    transparent_crc(g_917.f2, "g_917.f2", print_hash_value);
    transparent_crc(g_1032, "g_1032", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 264
   depth: 1, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 20
breakdown:
   indirect level: 0, occurrence: 11
   indirect level: 1, occurrence: 1
   indirect level: 2, occurrence: 1
   indirect level: 3, occurrence: 3
   indirect level: 4, occurrence: 4
XXX full-bitfields structs in the program: 11
breakdown:
   indirect level: 0, occurrence: 11
XXX times a bitfields struct's address is taken: 7
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 15
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 22

XXX max expression depth: 39
breakdown:
   depth: 1, occurrence: 173
   depth: 2, occurrence: 54
   depth: 3, occurrence: 7
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 17, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 4
   depth: 23, occurrence: 1
   depth: 24, occurrence: 2
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 35, occurrence: 1
   depth: 39, occurrence: 2

XXX total number of pointers: 274

XXX times a variable address is taken: 380
XXX times a pointer is dereferenced on RHS: 132
breakdown:
   depth: 1, occurrence: 119
   depth: 2, occurrence: 11
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 148
breakdown:
   depth: 1, occurrence: 146
   depth: 2, occurrence: 2
XXX times a pointer is compared with null: 21
XXX times a pointer is compared with address of another variable: 8
XXX times a pointer is compared with another pointer: 7
XXX times a pointer is qualified to be dereferenced: 2897

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 750
   level: 2, occurrence: 189
   level: 3, occurrence: 8
   level: 4, occurrence: 2
XXX number of pointers point to pointers: 86
XXX number of pointers point to scalars: 181
XXX number of pointers point to structs: 7
XXX percent of pointers has null in alias set: 29.9
XXX average alias set size: 1.34

XXX times a non-volatile is read: 939
XXX times a non-volatile is write: 439
XXX times a volatile is read: 35
XXX    times read thru a pointer: 4
XXX times a volatile is write: 12
XXX    times written thru a pointer: 5
XXX times a volatile is available for access: 526
XXX percentage of non-volatile access: 96.7

XXX forward jumps: 2
XXX backward jumps: 6

XXX stmts: 181
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 21
   depth: 2, occurrence: 20
   depth: 3, occurrence: 32
   depth: 4, occurrence: 40
   depth: 5, occurrence: 38

XXX percentage a fresh-made variable is used: 16.9
XXX percentage an existing variable is used: 83.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

