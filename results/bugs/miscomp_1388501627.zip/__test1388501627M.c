/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 1388501627 --bitfields --packed-struct
 * Seed:      1388501627
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_4 = 0UL;
static int32_t * volatile g_32[1] = {(void*)0};
static int32_t g_34 = 0xC2273637L;
static int32_t * volatile g_33[9][9] = {{(void*)0,&g_34,&g_34,(void*)0,&g_34,&g_34,&g_34,(void*)0,&g_34},{&g_34,&g_34,(void*)0,&g_34,&g_34,&g_34,&g_34,&g_34,&g_34},{&g_34,&g_34,&g_34,&g_34,&g_34,(void*)0,&g_34,&g_34,&g_34},{&g_34,&g_34,(void*)0,(void*)0,&g_34,&g_34,&g_34,(void*)0,&g_34},{&g_34,(void*)0,&g_34,(void*)0,(void*)0,&g_34,&g_34,(void*)0,(void*)0},{&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,(void*)0,&g_34,&g_34},{&g_34,&g_34,&g_34,(void*)0,&g_34,&g_34,&g_34,&g_34,&g_34},{&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,(void*)0},{&g_34,&g_34,(void*)0,&g_34,(void*)0,(void*)0,&g_34,(void*)0,(void*)0}};
static int32_t * volatile g_35 = (void*)0;/* VOLATILE GLOBAL g_35 */
static int32_t *g_39 = &g_34;
static int32_t *g_41[3][4][2] = {{{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34}},{{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34}},{{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34},{&g_34,&g_34}}};
static int32_t *g_42 = (void*)0;
static volatile int32_t g_45 = 0x2F82966BL;/* VOLATILE GLOBAL g_45 */
static volatile int32_t g_46 = (-4L);/* VOLATILE GLOBAL g_46 */
static volatile int32_t g_47 = 0xF8278B72L;/* VOLATILE GLOBAL g_47 */
static int32_t g_48 = 0x08CDAC36L;
static int8_t g_92 = 0x9EL;
static int8_t **g_99 = (void*)0;
static int8_t *** volatile g_98[8][5] = {{&g_99,&g_99,(void*)0,&g_99,&g_99},{&g_99,&g_99,&g_99,&g_99,&g_99},{&g_99,&g_99,&g_99,&g_99,&g_99},{&g_99,&g_99,(void*)0,&g_99,&g_99},{&g_99,&g_99,&g_99,&g_99,&g_99},{&g_99,&g_99,&g_99,&g_99,&g_99},{&g_99,&g_99,(void*)0,&g_99,&g_99},{&g_99,&g_99,&g_99,&g_99,&g_99}};
static int32_t g_120 = 1L;
static int32_t g_137 = (-1L);
static int32_t * const  volatile g_136 = &g_137;/* VOLATILE GLOBAL g_136 */
static int8_t *** volatile g_149 = &g_99;/* VOLATILE GLOBAL g_149 */
static int64_t g_177 = 0xF04335EDE0B67276LL;
static int16_t g_231 = (-1L);
static int32_t ** volatile * const  volatile g_240 = (void*)0;/* VOLATILE GLOBAL g_240 */
static int32_t ** volatile g_243 = &g_41[1][1][0];/* VOLATILE GLOBAL g_243 */
static int32_t ** volatile * volatile g_242 = &g_243;/* VOLATILE GLOBAL g_242 */
static int32_t ** volatile * volatile * volatile g_241 = &g_242;/* VOLATILE GLOBAL g_241 */
static int64_t *g_259 = &g_177;
static int64_t **g_258[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int64_t *** volatile g_257[7][7][5] = {{{&g_258[2],(void*)0,&g_258[7],(void*)0,&g_258[1]},{&g_258[1],&g_258[5],&g_258[9],&g_258[5],&g_258[1]},{(void*)0,&g_258[8],&g_258[8],&g_258[8],&g_258[1]},{&g_258[8],&g_258[8],&g_258[8],(void*)0,&g_258[1]},{(void*)0,(void*)0,&g_258[1],&g_258[8],&g_258[1]},{&g_258[2],(void*)0,&g_258[7],(void*)0,&g_258[1]},{&g_258[1],&g_258[5],&g_258[9],&g_258[5],&g_258[1]}},{{(void*)0,&g_258[8],&g_258[8],&g_258[8],&g_258[1]},{&g_258[8],&g_258[8],&g_258[8],(void*)0,&g_258[1]},{(void*)0,(void*)0,&g_258[1],&g_258[8],&g_258[1]},{&g_258[2],(void*)0,&g_258[7],(void*)0,&g_258[1]},{&g_258[1],&g_258[5],&g_258[9],&g_258[5],&g_258[1]},{(void*)0,&g_258[8],&g_258[8],&g_258[8],&g_258[1]},{&g_258[8],&g_258[8],&g_258[8],(void*)0,&g_258[1]}},{{(void*)0,(void*)0,&g_258[1],&g_258[8],&g_258[1]},{&g_258[2],(void*)0,&g_258[7],(void*)0,&g_258[1]},{&g_258[1],&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0},{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0}},{{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0},{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0},{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0}},{{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0},{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0},{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0}},{{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0},{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0},{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0},{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0}},{{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0},{&g_258[8],&g_258[8],&g_258[5],&g_258[8],(void*)0},{&g_258[5],&g_258[0],&g_258[8],&g_258[8],(void*)0},{(void*)0,&g_258[8],&g_258[6],&g_258[8],(void*)0},{&g_258[8],&g_258[8],&g_258[2],&g_258[9],(void*)0},{(void*)0,&g_258[9],&g_258[8],&g_258[0],(void*)0}}};
static volatile int16_t g_264[8][6][2] = {{{(-1L),0xD60AL},{(-7L),5L},{0x8517L,0x3A70L},{0L,0xC518L},{0xEEB0L,(-1L)},{(-5L),0L}},{{0L,0x8216L},{0x90A1L,0x90A1L},{0x5B53L,(-8L)},{0x8216L,0xEEB0L},{0x78A9L,0L},{0x743DL,0x78A9L}},{{6L,0x81DFL},{0L,0x743DL},{(-5L),0x81DFL},{0x743DL,5L},{(-1L),3L},{(-7L),(-1L)}},{{(-1L),(-1L)},{0L,(-8L)},{0x8517L,0x2DA5L},{5L,6L},{0xC518L,0xEEB0L},{0x29CBL,0x78A9L}},{{0x8216L,6L},{0x2DA5L,0L},{0xD60AL,0x8517L},{0L,0x8517L},{0xD60AL,0L},{0x2DA5L,6L}},{{0x8216L,0x78A9L},{0x29CBL,0xEEB0L},{0xC518L,6L},{5L,0x2DA5L},{0x8517L,(-8L)},{0L,(-1L)}},{{(-1L),(-1L)},{(-7L),3L},{(-1L),5L},{0x743DL,0x81DFL},{(-5L),0x743DL},{0L,0x90A1L}},{{0L,0x743DL},{(-5L),0x81DFL},{0x743DL,5L},{(-1L),3L},{(-7L),(-1L)},{(-1L),(-1L)}}};
static uint64_t g_281 = 18446744073709551615UL;
static uint8_t g_312 = 0x76L;
static uint64_t g_340 = 2UL;
static uint16_t g_346 = 0x0E9AL;
static volatile int32_t g_386[6] = {0xDF7C0BD7L,0xDF7C0BD7L,0xDF7C0BD7L,0xDF7C0BD7L,0xDF7C0BD7L,0xDF7C0BD7L};
static volatile int16_t g_387[10][8] = {{0x18B0L,0xFF29L,0xFF29L,0x18B0L,(-1L),0xB634L,0x18B0L,0xB634L},{0x18B0L,(-1L),(-5L),(-1L),0x18B0L,(-5L),7L,7L},{0xB634L,(-1L),(-1L),(-1L),(-1L),0xB634L,0xFF29L,(-1L)},{7L,0xFF29L,(-1L),7L,(-1L),0xFF29L,7L,0xB634L},{(-1L),0x18B0L,(-5L),7L,7L,(-5L),0x18B0L,(-1L)},{0xB634L,7L,0xFF29L,(-1L),7L,(-1L),0xFF29L,7L},{(-1L),0xFF29L,0xB634L,(-1L),(-1L),(-1L),(-1L),0xB634L},{7L,7L,(-5L),0x18B0L,(-1L),(-5L),(-1L),0x18B0L},{0xB634L,0x18B0L,0xB634L,(-1L),0x18B0L,0xFF29L,0xFF29L,0x18B0L},{0x18B0L,0xFF29L,0xFF29L,0x18B0L,(-1L),0xB634L,0x18B0L,0xB634L}};
static int8_t g_415 = 0x97L;
static uint16_t g_418 = 8UL;
static int32_t ** volatile g_419 = (void*)0;/* VOLATILE GLOBAL g_419 */
static volatile int32_t g_448 = (-5L);/* VOLATILE GLOBAL g_448 */
static const volatile int32_t *g_447 = &g_448;
static const volatile int32_t * volatile *g_446 = &g_447;
static const volatile int32_t * volatile * volatile *g_445 = &g_446;
static const volatile int32_t * volatile * volatile * volatile *g_444[5][7][6] = {{{&g_445,&g_445,&g_445,&g_445,(void*)0,&g_445},{&g_445,&g_445,&g_445,&g_445,(void*)0,&g_445},{(void*)0,&g_445,&g_445,(void*)0,&g_445,&g_445},{&g_445,(void*)0,&g_445,(void*)0,&g_445,&g_445},{(void*)0,&g_445,&g_445,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_445,&g_445,&g_445,&g_445,&g_445,&g_445},{(void*)0,&g_445,&g_445,&g_445,(void*)0,&g_445},{&g_445,(void*)0,&g_445,&g_445,&g_445,&g_445},{&g_445,&g_445,&g_445,&g_445,&g_445,(void*)0},{&g_445,&g_445,(void*)0,&g_445,&g_445,&g_445},{(void*)0,&g_445,(void*)0,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_445,&g_445,&g_445,&g_445,&g_445,&g_445},{(void*)0,&g_445,&g_445,&g_445,(void*)0,&g_445},{&g_445,(void*)0,&g_445,&g_445,&g_445,&g_445},{&g_445,&g_445,&g_445,&g_445,&g_445,(void*)0},{&g_445,&g_445,(void*)0,&g_445,&g_445,&g_445},{(void*)0,&g_445,(void*)0,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_445,&g_445,&g_445,&g_445,&g_445,&g_445},{(void*)0,&g_445,&g_445,&g_445,(void*)0,&g_445},{&g_445,(void*)0,&g_445,&g_445,&g_445,&g_445},{&g_445,&g_445,&g_445,&g_445,&g_445,(void*)0},{&g_445,&g_445,(void*)0,&g_445,&g_445,&g_445},{(void*)0,&g_445,(void*)0,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_445,&g_445,&g_445,&g_445,&g_445,&g_445},{(void*)0,&g_445,&g_445,&g_445,(void*)0,&g_445},{&g_445,(void*)0,&g_445,&g_445,&g_445,&g_445},{&g_445,&g_445,&g_445,&g_445,&g_445,(void*)0},{&g_445,&g_445,(void*)0,&g_445,&g_445,&g_445},{(void*)0,&g_445,(void*)0,&g_445,&g_445,&g_445},{&g_445,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
static uint16_t g_486 = 65534UL;
static int32_t ** const  volatile g_533 = &g_41[2][0][0];/* VOLATILE GLOBAL g_533 */
static int16_t g_547[6][2][3] = {{{0x3D12L,0x080DL,0L},{0xE553L,0xE553L,0L}},{{0x3D12L,0x080DL,0L},{0xE553L,0xE553L,0L}},{{0x3D12L,0x080DL,0L},{0xE553L,0x97B4L,0xE553L}},{{0xAFFEL,0L,0x3D12L},{0x97B4L,0x97B4L,0xE553L}},{{0xAFFEL,0L,0x3D12L},{0x97B4L,0x97B4L,0xE553L}},{{0xAFFEL,0L,0x3D12L},{0x97B4L,0x97B4L,0xE553L}}};
static int64_t g_624 = 4L;
static int32_t ** volatile g_643 = &g_41[1][1][0];/* VOLATILE GLOBAL g_643 */
static int8_t g_703 = (-8L);
static uint32_t g_710 = 4294967295UL;
static int32_t g_728 = 0x70EFFF85L;
static volatile uint8_t *g_797[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile uint8_t * volatile *g_796 = &g_797[4];
static volatile uint8_t * volatile **g_795 = &g_796;
static uint64_t *g_831 = &g_281;
static const int8_t g_1053 = (-7L);
static const int8_t g_1055 = (-6L);
static int32_t *g_1160[7] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
static int32_t *g_1161[1][8][9] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728,&g_728}}};
static int32_t g_1206 = 0L;
static const uint8_t g_1253 = 6UL;
static int32_t ** volatile g_1268 = &g_41[2][2][0];/* VOLATILE GLOBAL g_1268 */
static uint32_t g_1299[1][2][6] = {{{0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L},{0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L,0xBBE2CEB8L}}};
static int16_t *g_1363[2] = {&g_547[4][1][1],&g_547[4][1][1]};
static int16_t ** volatile g_1362 = &g_1363[0];/* VOLATILE GLOBAL g_1362 */
static uint16_t g_1392 = 0x3D18L;
static uint32_t g_1396 = 0UL;
static int8_t * const ***g_1401 = (void*)0;
static int8_t * const **** volatile g_1400 = &g_1401;/* VOLATILE GLOBAL g_1400 */
static int32_t g_1445 = 0x7DE75C05L;
static uint16_t g_1463[5][7][1] = {{{0x07F1L},{65531UL},{0x07F1L},{0UL},{0xB591L},{0UL},{0x07F1L}},{{65531UL},{0x07F1L},{0UL},{0xB591L},{0UL},{0x07F1L},{65531UL}},{{0x07F1L},{0UL},{0xB591L},{0UL},{0x07F1L},{65531UL},{0x07F1L}},{{0UL},{0xB591L},{0UL},{0x07F1L},{65531UL},{0x07F1L},{0UL}},{{0xB591L},{0UL},{0x07F1L},{65531UL},{0x07F1L},{0UL},{0xB591L}}};
static int32_t g_1507 = 3L;
static int32_t ** volatile g_1549 = &g_41[1][1][0];/* VOLATILE GLOBAL g_1549 */
static int64_t g_1558 = 0xFD435989B415060ELL;
static uint64_t g_1599 = 0x9C8BA29329FBA127LL;
static volatile uint16_t g_1619 = 0x65E3L;/* VOLATILE GLOBAL g_1619 */
static volatile uint16_t * volatile g_1618 = &g_1619;/* VOLATILE GLOBAL g_1618 */
static volatile uint16_t * volatile *g_1617 = &g_1618;
static int64_t g_1623 = 1L;
static uint8_t g_1630 = 0xA9L;
static int32_t **g_1641 = &g_1161[0][6][3];
static int32_t ***g_1640 = &g_1641;
static int32_t ****g_1639 = &g_1640;
static int32_t *****g_1638 = &g_1639;
static uint32_t g_1666 = 0x6F4D3CF1L;
static volatile uint8_t g_1723 = 0xE2L;/* VOLATILE GLOBAL g_1723 */
static uint8_t *g_1782 = (void*)0;
static volatile uint16_t * volatile * volatile *g_1816 = &g_1617;
static volatile uint16_t * volatile * volatile **g_1815 = &g_1816;
static volatile uint16_t * volatile * volatile ***g_1814 = &g_1815;
static const int32_t *g_1916 = &g_728;
static const int32_t **g_1915 = &g_1916;
static const int32_t ***g_1914 = &g_1915;
static const uint16_t ****g_2025 = (void*)0;
static const uint16_t *****g_2024 = &g_2025;
static volatile uint32_t g_2076 = 0xC62FE700L;/* VOLATILE GLOBAL g_2076 */
static volatile uint32_t *g_2075 = &g_2076;
static volatile uint32_t * volatile * volatile g_2074 = &g_2075;/* VOLATILE GLOBAL g_2074 */
static const int64_t *g_2091 = &g_177;
static const int64_t **g_2090 = &g_2091;
static uint64_t * const * volatile g_2133[4] = {&g_831,&g_831,&g_831,&g_831};
static uint64_t * const * volatile *g_2132 = &g_2133[1];
static volatile int32_t *g_2136 = &g_47;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_2(uint32_t  p_3);
static uint32_t  func_9(uint32_t  p_10, int16_t  p_11, const int64_t  p_12);
static int64_t  func_22(int32_t  p_23, int32_t  p_24);
static uint32_t  func_27(int8_t  p_28, const int32_t  p_29);
static int32_t * func_37(int32_t * p_38);
static int32_t * func_62(int32_t * const  p_63, int32_t * p_64, int32_t  p_65, int64_t  p_66);
static int32_t * const  func_67(const uint16_t  p_68, int32_t * p_69, int32_t * const  p_70);
static uint32_t  func_78(int32_t  p_79, uint32_t  p_80, int32_t ** p_81);
static int8_t  func_86(int32_t ** p_87, uint8_t  p_88, int32_t * p_89, const int8_t  p_90);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_34 g_241 g_242 g_243 g_486 g_415 g_92 g_48 g_547 g_703 g_32 g_710 g_231 g_728 g_259 g_177 g_149 g_99 g_445 g_446 g_447 g_448 g_281 g_137 g_386 g_418 g_120 g_795 g_831 g_340 g_312 g_136 g_624 g_39 g_1053 g_45 g_346 g_643 g_1160 g_1055 g_264 g_46 g_387 g_1299 g_1362 g_1363 g_1445 g_1463 g_1392 g_1206 g_1549 g_1507 g_1599 g_1617 g_1623 g_796 g_1640 g_1641 g_1666 g_1916 g_1618 g_1619 g_1639 g_1396 g_1161 g_1814 g_1815 g_1638 g_1400 g_1401 g_2074 g_2075 g_2076 g_2132 g_2136 g_1915 g_1914
 * writes: g_34 g_39 g_41 g_42 g_48 g_45 g_444 g_547 g_415 g_92 g_258 g_703 g_32 g_710 g_728 g_99 g_418 g_346 g_177 g_831 g_340 g_231 g_486 g_281 g_386 g_624 g_137 g_1161 g_120 g_1206 g_1299 g_312 g_1558 g_1599 g_1630 g_1638 g_1396 g_1640 g_2024 g_2074 g_1463 g_1666 g_2132 g_447 g_47 g_1916
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    const int64_t l_15 = (-1L);
    uint32_t l_1166 = 0x404C77C5L;
    uint64_t *l_1167 = &g_281;
    uint16_t l_1216 = 1UL;
    int32_t l_1217 = (-5L);
    uint16_t *l_2158 = &g_1463[0][5][0];
    if ((func_2((g_4 , (((*l_2158) = (safe_mul_func_int16_t_s_s_unsafe_macro/*0*//* ___SAFE__OP */(g_4, (safe_mod_func_uint64_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */((func_9((g_4 > ((safe_mod_func_int64_t_s_s_unsafe_macro/*2*//* ___SAFE__OP */((l_15 || (l_1217 &= (((safe_mul_func_uint16_t_u_u_unsafe_macro/*3*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */(((safe_div_func_uint16_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */((func_22((((safe_unary_minus_func_int64_t_s_unsafe_macro/*6*//* ___SAFE__OP */(l_15)) <= ((*l_1167) = (~((func_27((safe_rshift_func_int16_t_s_s_unsafe_macro/*7*//* ___SAFE__OP */(l_15, 5)), g_4) , ((safe_lshift_func_int64_t_s_s_unsafe_macro/*8*//* ___SAFE__OP */((safe_sub_func_uint32_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */(0x9D4A02D3L, l_1166)), 47)) && 4L)) | g_4)))) && l_15), g_1055) , g_387[7][4]), 0x4D35L)) | g_1053), g_1055)) > l_1216), g_4)) , 18446744073709551615UL) >= 18446744073709551614UL))), 8L)) >= l_1166)), g_4, l_1216) < l_1166), 1L))))) , (**g_2074)))) > l_1166))
    { /* block id: 984 */
        uint32_t l_2182 = 0xF55C3846L;
        for (g_710 = 0; (g_710 <= 1); g_710 += 1)
        { /* block id: 987 */
            return l_2182;
        }
    }
    else
    { /* block id: 990 */
        int32_t l_2183 = 0xF4D0619BL;
        return l_2183;
    }
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_1915 g_1916 g_1914 g_259 g_1362 g_1363 g_547
 * writes: g_1916 g_177
 */
static int16_t  func_2(uint32_t  p_3)
{ /* block id: 972 */
    uint8_t l_2159 = 247UL;
    uint32_t *l_2164[4] = {&g_1299[0][0][0],&g_1299[0][0][0],&g_1299[0][0][0],&g_1299[0][0][0]};
    uint32_t l_2165[10][1] = {{6UL},{0xFD32500BL},{0xB682075FL},{0xB682075FL},{0xFD32500BL},{6UL},{0xFD32500BL},{0xB682075FL},{0xB682075FL},{0xFD32500BL}};
    int32_t l_2168 = (-9L);
    int32_t l_2175 = 0x03444A32L;
    int32_t l_2176 = 1L;
    int64_t *l_2177[2];
    int32_t l_2178[3];
    int32_t l_2179[2][1][9] = {{{0xFB05DBB0L,1L,0x90B65FDCL,0x90B65FDCL,1L,0xFB05DBB0L,1L,0x90B65FDCL,0x90B65FDCL}},{{(-1L),(-1L),0xFB05DBB0L,0x90B65FDCL,0xFB05DBB0L,(-1L),0xFB05DBB0L,0L,1L}}};
    int32_t l_2180 = 1L;
    int32_t l_2181 = (-9L);
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2177[i] = &g_1558;
    for (i = 0; i < 3; i++)
        l_2178[i] = (-8L);
    (**g_1914) = (*g_1915);
    l_2181 = (l_2159 , (safe_div_func_int64_t_s_s_unsafe_macro/*10*//* ___SAFE__OP */((l_2180 = (l_2179[1][0][7] &= (((l_2178[0] = (safe_lshift_func_int8_t_s_u(((l_2165[4][0]--) , ((l_2168 = 1L) < (((p_3 || (safe_add_func_uint64_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*13*//* ___SAFE__OP */(((((*g_259) = (l_2159 , (-4L))) && ((p_3 != (safe_add_func_uint64_t_u_u_unsafe_macro/*14*//* ___SAFE__OP */((l_2175 = l_2159), ((l_2176 |= (1L && ((1UL < p_3) != p_3))) , 0x8FBB8B666DC3B731LL)))) , p_3)) | l_2165[4][0]), 0xE49AL)), 18446744073709551615UL))) ^ l_2165[1][0]) >= l_2159))), l_2159))) <= 18446744073709551614UL) < l_2159))), p_3)));
    return (**g_1362);
}


/* ------------------------------------------ */
/* 
 * reads : g_703 g_34 g_137 g_120 g_831 g_340 g_281 g_1299 g_1362 g_1363 g_547 g_1445 g_346 g_1463 g_177 g_92 g_1392 g_312 g_624 g_1206 g_447 g_448 g_1549 g_418 g_1507 g_486 g_1599 g_1617 g_1623 g_795 g_796 g_728 g_1640 g_1641 g_1053 g_259 g_1666 g_231 g_1916 g_1618 g_1619 g_1639 g_1396 g_1161 g_1814 g_1815 g_1638 g_1400 g_1401 g_2074 g_2075 g_2076 g_387 g_2132 g_2136 g_445 g_446
 * writes: g_703 g_34 g_120 g_1299 g_137 g_346 g_312 g_710 g_177 g_831 g_386 g_1206 g_41 g_281 g_547 g_1558 g_340 g_1599 g_1630 g_415 g_418 g_1638 g_624 g_1161 g_231 g_92 g_1396 g_1640 g_2024 g_2074 g_1463 g_1666 g_728 g_2132 g_447 g_47
 */
static uint32_t  func_9(uint32_t  p_10, int16_t  p_11, const int64_t  p_12)
{ /* block id: 529 */
    int32_t * const l_1222 = &g_137;
    int32_t *l_1223[10] = {&g_48,&g_728,&g_48,&g_728,&g_728,&g_48,&g_728,&g_48,&g_728,&g_728};
    int32_t *l_1254 = (void*)0;
    int64_t *l_1262 = &g_624;
    int32_t *** const **l_1311 = (void*)0;
    int16_t l_1406 = (-1L);
    int8_t *l_1419[7] = {&g_92,(void*)0,(void*)0,&g_92,(void*)0,(void*)0,&g_92};
    int8_t **l_1418 = &l_1419[6];
    int64_t l_1499[4] = {0L,0L,0L,0L};
    int64_t l_1513 = 0x83FA8AA61023D7C3LL;
    uint16_t *l_1554 = &g_1463[3][6][0];
    uint32_t l_1624 = 0UL;
    uint32_t l_1654 = 0xE2DB5F6BL;
    const uint64_t *l_1662 = &g_281;
    const uint64_t **l_1661 = &l_1662;
    int64_t ***l_1712 = &g_258[7];
    const int32_t l_1794[10] = {0x900C5670L,0x900C5670L,0xD1CD9583L,0x900C5670L,0x900C5670L,0xD1CD9583L,0x900C5670L,0x900C5670L,0xD1CD9583L,0x900C5670L};
    uint16_t ** const *l_1813 = (void*)0;
    uint16_t ** const * const *l_1812 = &l_1813;
    uint16_t ** const * const **l_1811 = &l_1812;
    int8_t *l_1836 = &g_92;
    const int64_t l_1855 = (-6L);
    int32_t ***l_1913 = &g_1641;
    int8_t ***l_1947 = (void*)0;
    int8_t *** const * const l_1946 = &l_1947;
    uint64_t l_2007[10];
    const uint16_t ***l_2023 = (void*)0;
    const uint16_t ****l_2022[6][2] = {{&l_2023,&l_2023},{&l_2023,&l_2023},{&l_2023,&l_2023},{&l_2023,&l_2023},{&l_2023,&l_2023},{&l_2023,&l_2023}};
    const uint16_t *****l_2021[3];
    uint8_t **l_2072 = &g_1782;
    int16_t l_2125 = 0xFC6CL;
    int32_t l_2139 = 0x24E484EEL;
    int32_t *l_2157 = (void*)0;
    int i, j;
    for (i = 0; i < 10; i++)
        l_2007[i] = 18446744073709551608UL;
    for (i = 0; i < 3; i++)
        l_2021[i] = &l_2022[3][1];
    for (g_703 = 0; (g_703 < (-25)); g_703--)
    { /* block id: 532 */
        int32_t *l_1220 = (void*)0;
        int32_t *l_1221 = &g_34;
        (*l_1221) = 0L;
        if ((*l_1221))
            break;
        (*l_1221) = p_10;
        l_1223[9] = l_1221;
    }
    if ((p_12 , (*l_1222)))
    { /* block id: 539 */
        uint64_t l_1231[3];
        const uint8_t *l_1251 = &g_4;
        int32_t *l_1267 = &g_137;
        int32_t **l_1288 = &g_42;
        int32_t ***l_1287 = &l_1288;
        int32_t ****l_1286[3];
        int32_t *****l_1285[3][7][5] = {{{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0],(void*)0},{(void*)0,&l_1286[0],&l_1286[0],(void*)0,(void*)0},{(void*)0,&l_1286[0],&l_1286[0],&l_1286[1],&l_1286[1]},{&l_1286[2],&l_1286[0],&l_1286[2],&l_1286[0],&l_1286[0]},{&l_1286[2],&l_1286[1],&l_1286[0],&l_1286[1],&l_1286[0]},{&l_1286[0],&l_1286[0],(void*)0,&l_1286[0],&l_1286[0]},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0]}},{{&l_1286[1],&l_1286[0],&l_1286[2],&l_1286[2],&l_1286[0]},{&l_1286[1],&l_1286[1],&l_1286[0],&l_1286[0],&l_1286[0]},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[2]},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0],(void*)0},{&l_1286[0],&l_1286[2],&l_1286[0],&l_1286[0],&l_1286[0]},{&l_1286[0],&l_1286[2],&l_1286[0],&l_1286[2],&l_1286[0]},{&l_1286[0],&l_1286[1],&l_1286[0],&l_1286[0],&l_1286[0]}},{{&l_1286[2],&l_1286[1],&l_1286[0],&l_1286[0],&l_1286[2]},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[1],&l_1286[0]},{&l_1286[0],&l_1286[0],(void*)0,&l_1286[0],&l_1286[0]},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[1],&l_1286[0]},{&l_1286[0],&l_1286[1],&l_1286[0],(void*)0,(void*)0},{&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[0],&l_1286[2]},{&l_1286[0],&l_1286[2],&l_1286[1],&l_1286[1],&l_1286[0]}}};
        const int32_t *l_1329 = &g_120;
        int16_t *l_1372 = &g_547[2][0][1];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1231[i] = 0x9F67C1C29C15379CLL;
        for (i = 0; i < 3; i++)
            l_1286[i] = &l_1287;
        for (g_120 = 0; (g_120 != 6); g_120++)
        { /* block id: 542 */
            int64_t **l_1230[2][7] = {{&g_259,&g_259,&g_259,&g_259,&g_259,&g_259,&g_259},{&g_259,&g_259,&g_259,&g_259,&g_259,&g_259,&g_259}};
            int32_t l_1249[5][9] = {{(-9L),0xE692EB60L,0xAB781DDBL,3L,0x0295D2D8L,0L,0xFE0F116FL,0L,0x0295D2D8L},{1L,0x0295D2D8L,0x0295D2D8L,1L,0x24BA5202L,0xAB781DDBL,(-7L),0xFE0F116FL,0xB04D8E96L},{1L,0x3E287314L,0xBBB502D5L,0xAB781DDBL,0xB04D8E96L,0x24BA5202L,0x24BA5202L,0x680577DFL,(-7L)},{0x24BA5202L,3L,0x24BA5202L,0x3E287314L,0L,0xE692EB60L,0xFE0F116FL,0L,(-7L)},{(-9L),0x24BA5202L,0x680577DFL,1L,0xB04D8E96L,0L,0xB04D8E96L,1L,0x680577DFL}};
            const uint8_t *l_1252[6] = {&g_1253,&g_1253,&g_1253,&g_1253,&g_1253,&g_1253};
            int16_t *l_1325 = &g_547[5][1][1];
            int16_t **l_1324 = &l_1325;
            int32_t l_1334 = 0x71159F2BL;
            int i, j;
        }
    }
    else
    { /* block id: 639 */
        int8_t *l_1408 = &g_415;
        int8_t ** const l_1407 = &l_1408;
        int32_t l_1409 = 0xE898F511L;
        uint32_t *l_1416 = &g_1299[0][0][4];
        int64_t * const *l_1417 = &g_259;
        int32_t l_1497 = 1L;
        int32_t l_1498 = 0L;
        int32_t l_1503 = 0xA7003116L;
        int32_t l_1504 = 0L;
        int32_t l_1508[5][4];
        uint64_t l_1518 = 0x82ED4465A9B59399LL;
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 4; j++)
                l_1508[i][j] = 0x0A0BD220L;
        }
        if ((safe_mul_func_int32_t_s_s_unsafe_macro/*15*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u_unsafe_macro/*16*//* ___SAFE__OP */((l_1406 < (l_1407 != ((l_1409 >= (safe_add_func_uint8_t_u_u_unsafe_macro/*17*//* ___SAFE__OP */(((*g_831) >= (-5L)), ((l_1409 == p_11) <= (safe_lshift_func_int64_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */(l_1409, (((((((*l_1416) ^= p_10) , (**g_1362)) == p_12) & 0xCF7CL) , l_1417) == (void*)0))), l_1409)))))) , l_1418))), 1UL)), p_11)))
        { /* block id: 641 */
            int8_t ** const **l_1425 = (void*)0;
            int8_t ** const ***l_1424 = &l_1425;
            const int8_t *l_1444[6][1][6] = {{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}},{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}},{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}},{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}},{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}},{{&g_92,&g_92,&g_703,&g_92,&g_92,&g_703}}};
            const int8_t **l_1443 = &l_1444[1][0][4];
            const int8_t ***l_1442 = &l_1443;
            const int8_t ****l_1441 = &l_1442;
            const int8_t *****l_1440[6][7][3] = {{{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0}},{{(void*)0,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{(void*)0,&l_1441,(void*)0},{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0},{(void*)0,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{(void*)0,&l_1441,(void*)0},{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441}}};
            int32_t l_1446 = (-1L);
            int i, j, k;
            (*l_1222) |= (-10L);
            for (p_10 = 21; (p_10 == 40); p_10++)
            { /* block id: 645 */
                int32_t **l_1429 = (void*)0;
                int32_t ***l_1428 = &l_1429;
                int32_t ****l_1427 = &l_1428;
                int32_t *****l_1426 = &l_1427;
                uint16_t *l_1455 = &g_346;
                uint8_t *l_1462[8][10] = {{&g_312,&g_312,&g_312,&g_312,&g_312,&g_312,&g_4,&g_4,&g_312,&g_4},{&g_4,(void*)0,(void*)0,&g_312,&g_4,&g_4,&g_312,(void*)0,(void*)0,&g_4},{&g_4,&g_4,&g_312,&g_4,&g_4,(void*)0,&g_312,&g_4,(void*)0,&g_312},{&g_312,&g_4,&g_312,&g_4,&g_4,&g_312,&g_312,&g_4,&g_4,&g_4},{&g_4,&g_312,&g_4,&g_4,&g_4,&g_312,&g_4,&g_4,&g_312,&g_4},{(void*)0,&g_312,(void*)0,&g_4,&g_312,&g_312,(void*)0,&g_312,&g_312,&g_4},{&g_312,&g_312,&g_312,&g_4,&g_4,&g_312,&g_4,&g_4,&g_312,&g_4},{&g_312,&g_312,&g_312,&g_312,&g_312,&g_4,&g_312,(void*)0,(void*)0,&g_312}};
                int i, j;
                l_1446 = (((((safe_rshift_func_int16_t_s_u_unsafe_macro/*20*//* ___SAFE__OP */(l_1409, ((((*g_831) | (l_1424 == (((void*)0 != l_1426) , ((safe_rshift_func_int32_t_s_u_unsafe_macro/*21*//* ___SAFE__OP */(((safe_unary_minus_func_int16_t_s_unsafe_macro/*22*//* ___SAFE__OP */((**g_1362))) & (safe_mod_func_uint32_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */((((0x09AE29A0L & (safe_mod_func_int16_t_s_s_unsafe_macro/*25*//* ___SAFE__OP */(((((p_12 , (!(9UL & 0x95C7L))) <= l_1409) || g_547[2][0][1]) , (-1L)), 0x2B67L))) , 0x39CDL) ^ 0xA647L), (-1L))), p_11))), 21)) , l_1440[2][4][1])))) == g_1445) <= 249UL))) , l_1409) | p_10) | l_1446) | 1UL);
                if (((((0x32L != (g_1299[0][1][0] , p_11)) , ((safe_mod_func_int8_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */(p_11, (((((safe_mod_func_int8_t_s_s_unsafe_macro/*27*//* ___SAFE__OP */((safe_rshift_func_uint64_t_u_u_unsafe_macro/*28*//* ___SAFE__OP */(((((*l_1455) |= (l_1446 || (safe_lshift_func_uint8_t_u_u_unsafe_macro/*29*//* ___SAFE__OP */(p_11, 1)))) & ((safe_div_func_int8_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */(l_1409, (g_312 = (g_340 >= ((safe_div_func_int32_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */((0x69L < p_12), p_10)) , p_10))))), 251UL)) < (**g_1362))) & 0UL), (*g_831))), (*l_1222))) > g_1463[0][5][0]) || 0x597867CDL) <= l_1446) | 4294967294UL))) , (*g_1362))) != &g_547[3][1][1]) || p_10))
                { /* block id: 649 */
                    int8_t *l_1471 = (void*)0;
                    uint32_t *l_1480 = &g_710;
                    uint16_t *l_1481 = &g_486;
                    int16_t *l_1482 = &l_1406;
                    int32_t l_1483 = 0xF6D8A124L;
                    l_1483 = (p_11 , (((*l_1482) = (safe_div_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((((((~((safe_div_func_uint32_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */(((*l_1480) = (((safe_add_func_int32_t_s_s_unsafe_macro/*35*//* ___SAFE__OP */(((*l_1222) = (((l_1471 = l_1462[1][7]) != (l_1446 , (*l_1418))) , ((((safe_lshift_func_int64_t_s_u_unsafe_macro/*36*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u_unsafe_macro/*37*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*38*//* ___SAFE__OP */(l_1409, l_1446)), (((safe_mod_func_uint8_t_u_u_unsafe_macro/*39*//* ___SAFE__OP */(p_12, 0x19L)) != l_1446) , p_11))), 34)) , g_177) , p_12) | l_1446))), l_1409)) <= 0x4D92D9BCF3E347CBLL) || 18446744073709551606UL)), p_11)) && p_11)) > g_92) , 0UL) , l_1481) == (void*)0), 0xD8D57C1B0D4B9879LL))) , 8L));
                    for (g_177 = (-14); (g_177 <= (-22)); g_177 = safe_sub_func_uint8_t_u_u_unsafe_macro/*40*//* ___SAFE__OP */(g_177, 5))
                    { /* block id: 657 */
                        uint64_t l_1486 = 18446744073709551610UL;
                        uint64_t **l_1489 = &g_831;
                        uint64_t *l_1491 = &l_1486;
                        uint64_t **l_1490 = &l_1491;
                        ++l_1486;
                        l_1409 ^= ((((*g_831) > (0xD0DEA6BCL & g_137)) >= (0x542C0DF7L | p_10)) && ((**g_1362) != (((*l_1489) = &g_281) == ((*l_1490) = &g_340))));
                    }
                    if (p_11)
                        break;
                }
                else
                { /* block id: 664 */
                    return g_1392;
                }
            }
        }
        else
        { /* block id: 668 */
            int32_t l_1500 = (-1L);
            int32_t l_1501 = (-8L);
            int32_t l_1502 = 5L;
            int32_t l_1505 = (-1L);
            int32_t l_1506 = (-1L);
            int32_t l_1509 = 8L;
            int32_t l_1510 = 1L;
            int32_t l_1517 = 0L;
            for (g_312 = 0; (g_312 == 35); g_312 = safe_add_func_uint16_t_u_u_unsafe_macro/*41*//* ___SAFE__OP */(g_312, 8))
            { /* block id: 671 */
                uint16_t l_1494 = 4UL;
                int32_t l_1495 = 0x9D01062EL;
                int32_t l_1496 = (-1L);
                int32_t l_1511 = 1L;
                int32_t l_1512 = 0L;
                int32_t l_1514 = 4L;
                int32_t l_1515 = 0x2F8D2A6AL;
                int32_t l_1516 = 0L;
                l_1494 = (-1L);
                l_1518--;
                for (l_1494 = 0; (l_1494 <= 1); l_1494 += 1)
                { /* block id: 676 */
                    int64_t l_1523[3][8][4] = {{{0x33F939A93D5F95EELL,0x33F939A93D5F95EELL,0x9D8BD2A827B1B250LL,(-1L)},{(-1L),1L,0x9D8BD2A827B1B250LL,1L},{0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL,0x9D8BD2A827B1B250LL},{1L,0x1ED934E5365529CALL,0x1ED934E5365529CALL,1L},{0x1ED934E5365529CALL,1L,0x33F939A93D5F95EELL,(-1L)},{0x1ED934E5365529CALL,0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL},{1L,(-1L),0xD971B6D7590DD89BLL,0xD971B6D7590DD89BLL},{0x33F939A93D5F95EELL,0x33F939A93D5F95EELL,0x9D8BD2A827B1B250LL,(-1L)}},{{(-1L),1L,0x9D8BD2A827B1B250LL,1L},{0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL,0x9D8BD2A827B1B250LL},{1L,0x1ED934E5365529CALL,0x1ED934E5365529CALL,1L},{0x1ED934E5365529CALL,1L,0x33F939A93D5F95EELL,(-1L)},{0x1ED934E5365529CALL,0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL},{1L,(-1L),0xD971B6D7590DD89BLL,0xD971B6D7590DD89BLL},{0x33F939A93D5F95EELL,0x33F939A93D5F95EELL,0x9D8BD2A827B1B250LL,(-1L)},{(-1L),1L,0x9D8BD2A827B1B250LL,1L}},{{0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL,0x9D8BD2A827B1B250LL},{1L,0x1ED934E5365529CALL,0x1ED934E5365529CALL,1L},{0x1ED934E5365529CALL,1L,0x33F939A93D5F95EELL,(-1L)},{0x1ED934E5365529CALL,0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL},{1L,(-1L),0xD971B6D7590DD89BLL,0xD971B6D7590DD89BLL},{0x33F939A93D5F95EELL,0x33F939A93D5F95EELL,0x9D8BD2A827B1B250LL,(-1L)},{(-1L),1L,0x9D8BD2A827B1B250LL,1L},{0x33F939A93D5F95EELL,0x1ED934E5365529CALL,0xD971B6D7590DD89BLL,0x9D8BD2A827B1B250LL}}};
                    int32_t l_1524 = 0x3BD44DACL;
                    uint16_t *l_1527 = &g_346;
                    int i, j, k;
                    g_386[l_1494] = (((*l_1527) = (p_12 <= (((((safe_lshift_func_int32_t_s_s_unsafe_macro/*42*//* ___SAFE__OP */(l_1523[1][2][3], 18)) <= g_703) , 18446744073709551615UL) != ((l_1524 = (l_1510 == (*g_831))) && (p_12 | (safe_add_func_int16_t_s_s_unsafe_macro/*43*//* ___SAFE__OP */((-1L), ((l_1506 = p_12) != 3UL)))))) <= (*g_831)))) ^ 0xB443L);
                    return g_624;
                }
            }
            return l_1508[1][2];
        }
    }
    if (p_11)
    { /* block id: 687 */
        const uint32_t l_1528[2] = {0x45E18B87L,0x45E18B87L};
        int32_t l_1548 = 0L;
        uint8_t l_1572 = 6UL;
        int32_t ** const l_1627[9] = {&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0],&g_41[1][1][0]};
        int32_t ** const *l_1626 = &l_1627[1];
        int32_t ** const ** const l_1625 = &l_1626;
        uint32_t l_1701 = 3UL;
        int32_t l_1703 = 0xF827EFCEL;
        uint32_t l_1710 = 7UL;
        uint64_t l_1807 = 1UL;
        uint16_t *l_1907[4] = {&g_346,&g_346,&g_346,&g_346};
        int32_t **l_1919 = &g_42;
        int i;
        for (g_1206 = 4; (g_1206 >= 0); g_1206 -= 1)
        { /* block id: 690 */
            int32_t l_1543 = 0xF3AC2ED1L;
            int32_t l_1545[8][9][3] = {{{0x7CF3C53BL,0L,0x912781FDL},{(-1L),(-9L),(-1L)},{0L,0L,0xC7BA35B7L},{0x60086C7AL,0x7935EAEFL,0L},{0x3FFFF3CBL,1L,0x585A6C86L},{0x99D6703FL,(-3L),0x912781FDL},{1L,0xCBFF69C0L,0L},{6L,(-3L),(-1L)},{4L,1L,1L}},{{0x207E8370L,0x974D4F9FL,1L},{0x7A588EEDL,(-1L),0x599942C8L},{0xD70D2D46L,(-1L),0xEC46AFF9L},{1L,0x4EF1F79BL,0x1E5E2F1EL},{0x7CF3C53BL,0xBF73A271L,0x7CF3C53BL},{0xE02BF115L,0x8C1F1CC5L,0L},{0xCFBD7A01L,(-1L),(-1L)},{0xE4D48EDAL,0xAA3F3263L,0x974D4F9FL},{0L,4L,0L}},{{0xE4D48EDAL,0x7A588EEDL,0xA1F44886L},{0xCFBD7A01L,0x9D2B9E89L,(-1L)},{0xE02BF115L,(-1L),0L},{0x7CF3C53BL,0x912781FDL,0L},{1L,0xC7BA35B7L,(-1L)},{0xD70D2D46L,1L,0x9E2F9890L},{0x7A588EEDL,0L,0L},{0x207E8370L,0x9E2F9890L,0L},{4L,0xEC46AFF9L,(-1L)}},{{6L,0x74FC2FBEL,0x1B48F953L},{1L,0x3C0DB32CL,(-1L)},{0x99D6703FL,(-1L),0xE3AF18A6L},{0x3FFFF3CBL,0L,(-9L)},{0x60086C7AL,1L,0x9ADA9514L},{0L,0x38C4FA47L,0x333BC1E2L},{(-1L),0x430ED91DL,0L},{7L,0x430ED91DL,0xAA3F3263L},{0L,0x38C4FA47L,(-1L)}},{{(-1L),1L,1L},{0x1ABB270AL,0L,0x53D42B09L},{(-1L),(-1L),4L},{0L,0x3C0DB32CL,4L},{0xDAAAF96CL,0x74FC2FBEL,0xCBFF69C0L},{0L,0xEC46AFF9L,0x3C0DB32CL},{0x9D2B9E89L,0x9E2F9890L,0xDAAAF96CL},{(-1L),0L,0xE02BF115L},{1L,1L,0x1ABB270AL}},{{(-1L),0xC7BA35B7L,0L},{0x900F0058L,0x912781FDL,(-1L)},{(-1L),(-1L),(-1L)},{0L,0x9D2B9E89L,1L},{0xAA3F3263L,0x7A588EEDL,0L},{0xFB9AF04FL,4L,0x64331D28L},{0x599942C8L,0xAA3F3263L,0L},{0x38C4FA47L,(-1L),1L},{(-1L),0x8C1F1CC5L,(-1L)}},{{0x585A6C86L,0xBF73A271L,(-1L)},{0L,0x4EF1F79BL,0L},{(-3L),(-1L),0x1ABB270AL},{0x1B48F953L,(-1L),0xE02BF115L},{1L,0x974D4F9FL,0xDAAAF96CL},{0L,1L,0x3C0DB32CL},{(-1L),(-3L),0xCBFF69C0L},{1L,0xCBFF69C0L,4L},{0x974D4F9FL,(-3L),4L}},{{1L,1L,0x53D42B09L},{0x8C1F1CC5L,0x5B99F837L,1L},{0L,0x207E8370L,(-1L)},{0L,0xBF73A271L,0x1B48F953L},{0x64855516L,0xE3B847A6L,1L},{0x64855516L,0xCBFF69C0L,0L},{0L,0xD66EF859L,0x925F99E5L},{0L,0L,0xBF73A271L},{(-1L),(-1L),0x3FFFF3CBL}}};
            int16_t *l_1547[4][7][5] = {{{(void*)0,&l_1406,(void*)0,&l_1406,(void*)0},{&g_547[1][0][1],&g_231,(void*)0,&l_1406,(void*)0},{(void*)0,&l_1406,&g_231,&g_231,&l_1406},{&l_1406,&g_231,(void*)0,(void*)0,&g_547[3][1][0]},{&l_1406,&g_231,(void*)0,&l_1406,(void*)0},{&g_231,&l_1406,&l_1406,&g_231,&l_1406},{&l_1406,&g_231,&g_547[3][1][0],&g_231,&l_1406}},{{&l_1406,&l_1406,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1406,&g_231,&g_547[3][1][0]},{&g_547[1][0][1],&l_1406,&l_1406,&g_231,&l_1406},{(void*)0,&l_1406,(void*)0,&l_1406,(void*)0},{&g_231,&l_1406,&g_547[3][1][0],(void*)0,(void*)0},{&g_231,(void*)0,&l_1406,&g_231,&g_231},{(void*)0,&l_1406,(void*)0,&l_1406,(void*)0}},{{&g_547[1][0][1],&g_231,(void*)0,&l_1406,(void*)0},{(void*)0,&l_1406,&g_231,&g_231,&l_1406},{&l_1406,&g_231,(void*)0,(void*)0,&g_547[3][1][0]},{&l_1406,&g_231,(void*)0,&l_1406,(void*)0},{&g_231,&l_1406,&l_1406,&g_231,&l_1406},{&l_1406,&g_231,&g_547[3][1][0],&g_231,&l_1406},{&l_1406,&l_1406,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_1406,&g_231,&g_547[3][1][0]},{&g_547[1][0][1],&l_1406,&l_1406,&g_231,&l_1406},{(void*)0,&l_1406,(void*)0,&l_1406,(void*)0},{&g_231,&l_1406,&g_547[3][1][0],(void*)0,(void*)0},{&g_231,(void*)0,&l_1406,&g_231,&g_231},{(void*)0,&l_1406,(void*)0,&l_1406,(void*)0},{&g_547[1][0][1],&g_231,(void*)0,&l_1406,(void*)0}}};
            int8_t l_1559 = 0xBDL;
            int32_t *l_1561 = &l_1548;
            uint8_t *l_1629 = &g_4;
            uint8_t **l_1628 = &l_1629;
            int32_t * const *l_1646[7] = {&l_1223[6],&g_41[1][1][0],&g_41[1][1][0],&l_1223[6],&g_41[1][1][0],&g_41[1][1][0],&l_1223[6]};
            int32_t * const **l_1645 = &l_1646[6];
            int32_t * const *** const l_1644 = &l_1645;
            int32_t * const *** const *l_1643 = &l_1644;
            uint16_t ***l_1648[1][3][9];
            uint16_t **** const l_1647 = &l_1648[0][1][5];
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    for (k = 0; k < 9; k++)
                        l_1648[i][j][k] = (void*)0;
                }
            }
            (*l_1222) = 0x7B5AC933L;
            if ((*g_447))
                break;
            (*l_1222) = (p_12 | (((p_11 , l_1528[1]) == ((safe_sub_func_int16_t_s_s_unsafe_macro/*44*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*45*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*46*//* ___SAFE__OP */(l_1528[0], (safe_mod_func_int16_t_s_s_unsafe_macro/*47*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u_unsafe_macro/*48*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*49*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u_unsafe_macro/*50*//* ___SAFE__OP */(l_1543, 7)), ((~((l_1548 = ((p_11 <= p_10) != ((l_1545[2][6][1] |= p_10) <= (~p_10)))) & g_1445)) ^ p_11))), l_1543)), p_12)))), 0UL)), 0L)) < p_11)) , 251UL));
            for (p_10 = 0; (p_10 <= 4); p_10 += 1)
            { /* block id: 698 */
                uint64_t l_1560 = 0xB674C1EA1DC3C782LL;
                int64_t **l_1564 = &l_1262;
                int32_t l_1573 = (-1L);
                int32_t l_1631 = 1L;
                (*g_1549) = &l_1545[2][1][1];
                if (p_11)
                { /* block id: 700 */
                    int8_t l_1555 = 0x21L;
                    if (p_12)
                        break;
                    for (g_281 = 0; (g_281 <= 4); g_281 += 1)
                    { /* block id: 704 */
                        int64_t l_1550 = (-1L);
                        uint8_t *l_1556 = (void*)0;
                        uint8_t *l_1557[2];
                        int i, j;
                        for (i = 0; i < 2; i++)
                            l_1557[i] = (void*)0;
                        (*l_1222) = (((((l_1550 || (p_12 == ((**g_1362) = (~(0x9F34L && l_1545[2][3][2]))))) , (((g_1558 = (g_312 = (p_11 == ((*g_447) & ((safe_add_func_uint64_t_u_u_unsafe_macro/*51*//* ___SAFE__OP */(((l_1554 != (void*)0) , (*g_831)), l_1555)) , (-8L)))))) > g_418) > l_1559)) | 0x1FF1C944L) <= l_1548) , l_1560);
                        l_1561 = (void*)0;
                    }
                    l_1548 &= p_11;
                }
                else
                { /* block id: 712 */
                    return l_1560;
                }
                if (((((*g_831) = 0x898F693DEFD4F0F0LL) , ((((safe_lshift_func_uint16_t_u_u_unsafe_macro/*52*//* ___SAFE__OP */((((((((((&l_1262 == l_1564) ^ (l_1573 |= (l_1548 = ((safe_mod_func_int64_t_s_s_unsafe_macro/*53*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u_unsafe_macro/*54*//* ___SAFE__OP */(((*g_831) <= (&g_418 != l_1547[1][2][3])), 15)), (((*l_1222) ^= (p_12 ^ (-1L))) & ((safe_rshift_func_uint64_t_u_u_unsafe_macro/*55*//* ___SAFE__OP */(((safe_unary_minus_func_int8_t_s_unsafe_macro/*56*//* ___SAFE__OP */(p_11)) , 0x0D2A030F94DCC6B0LL), 26)) && l_1572)))) , p_12)))) >= l_1528[0]) < g_1463[0][1][0]) | p_12) ^ g_1507) && l_1560) == g_486) && 0xD4L), g_340)) > 0x645DB328BBBE1E19LL) , 0xED51C97215437BCCLL) | p_10)) | 0L))
                { /* block id: 719 */
                    uint16_t l_1591 = 0xBD3BL;
                    uint64_t *l_1598 = &g_1599;
                    uint16_t **l_1616 = (void*)0;
                    uint8_t *l_1621 = (void*)0;
                    uint8_t *l_1622 = &g_312;
                    l_1631 &= ((safe_mod_func_int16_t_s_s_unsafe_macro/*57*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*58*//* ___SAFE__OP */(l_1560, (g_1630 = (0xCA1BFE6F891241DBLL || (((safe_rshift_func_int16_t_s_u_unsafe_macro/*59*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*60*//* ___SAFE__OP */((((!(((((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*61*//* ___SAFE__OP */((--(*g_831)), l_1572)) > ((((safe_add_func_uint16_t_u_u_unsafe_macro/*62*//* ___SAFE__OP */(p_10, (safe_sub_func_int8_t_s_s_unsafe_macro/*63*//* ___SAFE__OP */((-1L), l_1591)))) , (!(((safe_lshift_func_uint32_t_u_s_unsafe_macro/*64*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*65*//* ___SAFE__OP */(((+((*l_1222) = ((--(*l_1598)) == (safe_div_func_uint64_t_u_u_unsafe_macro/*66*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*67*//* ___SAFE__OP */((+((~((((*l_1622) = (safe_mul_func_uint32_t_u_u_unsafe_macro/*68*//* ___SAFE__OP */(((safe_add_func_int16_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */(((l_1548 = ((safe_div_func_uint64_t_u_u_unsafe_macro/*70*//* ___SAFE__OP */(((safe_sub_func_int32_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */((l_1616 != g_1617), (+(p_10 <= l_1528[1])))) > 0UL), l_1591)) , l_1591)) && l_1573), (**g_1362))) , 4294967295UL), l_1573))) & l_1572) <= g_1623)) <= l_1560)), 0x9669L)), l_1573))))) <= 0x962080FEL), p_12)) == l_1624), p_11)) || 0xEFL) < g_92))) >= l_1572) | p_10)) , (void*)0) != l_1625) , l_1628) == (*g_795)) | p_12)) || p_10) & 1UL), 0x96L)), p_11)) && g_728) , 0L))))), p_10)) == 65535UL);
                    return p_12;
                }
                else
                { /* block id: 728 */
                    (*l_1222) = 6L;
                    for (l_1543 = 0; l_1543 < 3; l_1543 += 1)
                    {
                        for (g_415 = 0; g_415 < 4; g_415 += 1)
                        {
                            for (g_281 = 0; g_281 < 2; g_281 += 1)
                            {
                                g_41[l_1543][g_415][g_281] = &l_1631;
                            }
                        }
                    }
                }
                for (g_177 = 0; (g_177 <= 4); g_177 += 1)
                { /* block id: 734 */
                    int32_t *****l_1642 = &g_1639;
                    (*l_1222) = ((safe_sub_func_uint64_t_u_u_unsafe_macro/*72*//* ___SAFE__OP */((*g_831), 0L)) < (0x08L == p_10));
                    if (p_10)
                        break;
                    for (g_418 = 0; (g_418 <= 4); g_418 += 1)
                    { /* block id: 739 */
                        int32_t **l_1637 = &l_1254;
                        int32_t ***l_1636[3][3] = {{&l_1637,&l_1637,&l_1637},{&l_1637,&l_1637,&l_1637},{&l_1637,&l_1637,&l_1637}};
                        int32_t ****l_1635 = &l_1636[0][1];
                        int32_t *****l_1634 = &l_1635;
                        int i, j;
                        (*l_1222) = ((l_1642 = (g_1638 = l_1634)) == l_1643);
                    }
                    for (g_624 = 4; (g_624 >= 0); g_624 -= 1)
                    { /* block id: 746 */
                        uint16_t ****l_1650 = &l_1648[0][1][5];
                        uint16_t *****l_1649 = &l_1650;
                        int32_t *l_1651[6] = {&l_1543,&l_1543,&l_1543,&l_1543,&l_1543,&l_1543};
                        int i;
                        (*l_1649) = l_1647;
                        (**g_1640) = l_1651[4];
                    }
                }
            }
        }
        if ((((safe_div_func_uint32_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */((*l_1222), p_12)) | ((((l_1654 >= (((p_11 < (safe_mul_func_int64_t_s_s_unsafe_macro/*74*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*76*//* ___SAFE__OP */(p_10, ((void*)0 == l_1661))), (+(((*g_259) = ((g_1053 , (l_1222 == (void*)0)) , (-9L))) > 0UL)))), p_10))) , g_1666) > 0UL)) , p_10) == p_11) ^ 7L)) ^ 1UL))
        { /* block id: 754 */
            int32_t l_1669[3];
            int i;
            for (i = 0; i < 3; i++)
                l_1669[i] = 0xC55D720AL;
            (*l_1222) = (l_1669[2] = (safe_div_func_int64_t_s_s_unsafe_macro/*77*//* ___SAFE__OP */(p_10, 0xFB1B2C5014B096E2LL)));
        }
        else
        { /* block id: 757 */
            int32_t l_1689 = 1L;
            int32_t l_1711 = 0x9F18D6DFL;
            uint32_t *l_1726 = &l_1710;
            const uint64_t * const *l_1764[7];
            uint16_t l_1768 = 65535UL;
            const uint8_t *l_1833 = &g_1253;
            const uint8_t **l_1832[6][8] = {{&l_1833,&l_1833,(void*)0,&l_1833,(void*)0,&l_1833,(void*)0,(void*)0},{&l_1833,&l_1833,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1833,&l_1833,&l_1833,&l_1833,(void*)0,&l_1833,(void*)0,&l_1833},{&l_1833,(void*)0,&l_1833,(void*)0,&l_1833,&l_1833,&l_1833,&l_1833},{(void*)0,(void*)0,(void*)0,&l_1833,&l_1833,(void*)0,(void*)0,(void*)0},{&l_1833,&l_1833,(void*)0,(void*)0,&l_1833,&l_1833,&l_1833,(void*)0}};
            const uint8_t ***l_1831 = &l_1832[5][1];
            const int8_t l_1880[6] = {0x03L,0x03L,0x03L,0x03L,0x03L,0x03L};
            int32_t * const *l_1920[10];
            int i, j;
            for (i = 0; i < 7; i++)
                l_1764[i] = (void*)0;
            for (i = 0; i < 10; i++)
                l_1920[i] = &l_1223[6];
            (*l_1222) &= p_10;
            for (g_231 = 9; (g_231 >= 0); g_231 -= 1)
            { /* block id: 761 */
                uint32_t l_1688 = 0xD9B5EE5BL;
                uint16_t l_1694 = 65533UL;
                int8_t l_1699 = (-1L);
                int32_t l_1702 = (-7L);
                uint32_t *l_1763[9] = {&g_1666,&g_1666,&g_1666,&g_1666,&g_1666,&g_1666,&g_1666,&g_1666,&g_1666};
                int16_t l_1765 = 0x31F6L;
                uint8_t *l_1766 = &g_1630;
                uint8_t *l_1767 = &l_1572;
                int64_t l_1808[10] = {0x39C55BD8DC1639D2LL,0xB51AF18216A02A7BLL,0x7EE2D4689CA2C047LL,0x7EE2D4689CA2C047LL,0xB51AF18216A02A7BLL,0x39C55BD8DC1639D2LL,0xB51AF18216A02A7BLL,0x7EE2D4689CA2C047LL,0x7EE2D4689CA2C047LL,0xB51AF18216A02A7BLL};
                uint16_t ****l_1850 = (void*)0;
                const int32_t l_1854 = 0xC0BA2741L;
                uint16_t l_1865 = 65529UL;
                int32_t l_1884 = 1L;
                int i;
            }
        }
        (*l_1222) &= p_10;
    }
    else
    { /* block id: 858 */
        uint32_t l_1931 = 0x3B5387FBL;
        uint16_t *l_1943 = (void*)0;
        int32_t l_1954 = 0x92032054L;
        int8_t **l_1996 = &l_1419[6];
        int32_t ** const *l_2015 = &g_1641;
        int64_t ***l_2016 = &g_258[8];
        int16_t l_2041 = 6L;
        int16_t l_2070 = (-9L);
        int32_t *l_2137 = &g_137;
        int32_t l_2144 = 0xCBB4AC70L;
        int32_t l_2146 = 0x8C8ED818L;
        int32_t l_2150 = 0x07250439L;
        int32_t l_2151 = 3L;
        int32_t l_2152 = 0L;
        int32_t l_2153 = 0xD2CB00A1L;
        uint16_t l_2154 = 0x02A0L;
        if ((p_10 ^ 0x149CL))
        { /* block id: 859 */
            uint32_t l_1928 = 0x7686FB4AL;
            for (g_120 = (-20); (g_120 == 6); g_120 = safe_add_func_uint16_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */(g_120, 6))
            { /* block id: 862 */
                int32_t l_1927[9][5][3] = {{{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L}},{{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L}},{{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L}},{{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L}},{{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L}},{{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L}},{{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L}},{{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L},{0xB7524922L,(-3L),0L},{0xE1FC7396L,0xE1FC7396L,0L},{(-3L),0xB7524922L,0L}},{{0xB7524922L,(-3L),0L},{0xE1FC7396L,0x3EB55ED6L,0xE1FC7396L},{0x11F14860L,0L,0xE1FC7396L},{0L,0x11F14860L,0xE1FC7396L},{0x3EB55ED6L,0x3EB55ED6L,0xE1FC7396L}}};
                int i, j, k;
                --l_1928;
                ++l_1931;
                return p_10;
            }
            return p_10;
        }
        else
        { /* block id: 868 */
            uint16_t *l_1942[3][5][1] = {{{(void*)0},{&g_1463[0][5][0]},{&g_1392},{&g_1463[0][5][0]},{(void*)0}},{{&g_346},{(void*)0},{&g_1463[0][5][0]},{&g_1392},{&g_1463[0][5][0]}},{{(void*)0},{&g_346},{(void*)0},{&g_1463[0][5][0]},{&g_1392}}};
            int8_t ***l_1945 = &l_1418;
            int8_t ****l_1944 = &l_1945;
            int32_t l_1948 = (-1L);
            int i, j, k;
            (*l_1222) = ((((safe_sub_func_uint16_t_u_u_unsafe_macro/*79*//* ___SAFE__OP */(((((*l_1262) = p_11) && (safe_div_func_uint32_t_u_u_unsafe_macro/*80*//* ___SAFE__OP */((((((safe_mod_func_uint64_t_u_u_unsafe_macro/*81*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*82*//* ___SAFE__OP */((l_1942[1][0][0] != (l_1943 = l_1942[2][3][0])), (l_1944 != l_1946))), p_11)) | (l_1931 & (l_1948 < (((l_1223[0] == &g_710) , l_1948) | p_11)))) && (*g_831)) ^ p_11) >= l_1948), (*g_1916)))) , l_1931), l_1931)) && 0L) || 0L) <= (-1L));
        }
        if (((void*)0 == &g_831))
        { /* block id: 873 */
            uint32_t l_1955 = 0xE157A7F5L;
            const uint32_t l_1977 = 1UL;
            const int8_t *l_1993 = (void*)0;
            const int8_t **l_1992[6];
            const int8_t ***l_1991 = &l_1992[0];
            uint64_t l_1997 = 5UL;
            int32_t l_2008 = 0xCA13E4CBL;
            uint16_t **l_2014 = &l_1943;
            uint16_t ***l_2013 = &l_2014;
            uint16_t ****l_2012 = &l_2013;
            int32_t l_2017 = (-1L);
            int i;
            for (i = 0; i < 6; i++)
                l_1992[i] = &l_1993;
            for (g_92 = 0; (g_92 == 20); g_92 = safe_add_func_uint16_t_u_u_unsafe_macro/*83*//* ___SAFE__OP */(g_92, 8))
            { /* block id: 876 */
                int64_t l_1953[2];
                int32_t l_1964 = 0x27C3166FL;
                int i;
                for (i = 0; i < 2; i++)
                    l_1953[i] = (-8L);
                for (g_1599 = 0; (g_1599 < 3); g_1599++)
                { /* block id: 879 */
                    uint8_t *l_1963[3];
                    int32_t ****l_1967 = &l_1913;
                    uint32_t *l_1976 = &g_1396;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1963[i] = &g_1630;
                    l_1955++;
                    if ((safe_mul_func_uint8_t_u_u_unsafe_macro/*84*//* ___SAFE__OP */((l_1954 && ((+((*l_1976) ^= (safe_sub_func_uint8_t_u_u_unsafe_macro/*85*//* ___SAFE__OP */((l_1964 = p_11), (((((safe_add_func_uint32_t_u_u_unsafe_macro/*86*//* ___SAFE__OP */(((**g_1617) & ((*g_1639) == ((*l_1967) = l_1913))), ((((safe_add_func_uint16_t_u_u_unsafe_macro/*87*//* ___SAFE__OP */(g_418, (safe_sub_func_uint16_t_u_u_unsafe_macro/*88*//* ___SAFE__OP */(0xE875L, (safe_mod_func_uint8_t_u_u_unsafe_macro/*89*//* ___SAFE__OP */((p_10 < (safe_div_func_int64_t_s_s_unsafe_macro/*90*//* ___SAFE__OP */(l_1954, p_10))), 254UL)))))) , (*g_831)) == l_1953[1]) , 1L))) & 1L) , 0L) && p_10) , (*l_1222)))))) , l_1977)), p_10)))
                    { /* block id: 884 */
                        uint32_t l_1978 = 0xD4E169AEL;
                        --l_1978;
                        return l_1978;
                    }
                    else
                    { /* block id: 887 */
                        int64_t l_1987 = 6L;
                        int8_t ****l_1990 = &l_1947;
                        int32_t l_1998 = 0xF797F896L;
                        (***g_1639) = (**l_1913);
                    }
                    l_2008 = ((65535UL || (safe_sub_func_uint16_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */(65533UL, (l_1931 || (((*l_1976) &= (p_10 ^ (((((safe_sub_func_int64_t_s_s_unsafe_macro/*92*//* ___SAFE__OP */(((*l_1262) ^= (safe_rshift_func_int8_t_s_s_unsafe_macro/*93*//* ___SAFE__OP */(((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*94*//* ___SAFE__OP */(18446744073709551610UL, 32)) | ((l_1954 = (l_1953[1] && (0x17L < p_12))) , 9L)) , p_12) > p_12), 5))), (*g_831))) >= 0xFA269121L) == 0xD6L) & p_12) || p_11))) , l_2007[3]))))) , p_12);
                }
            }
            l_2017 |= (((p_11 , (((!(safe_mul_func_uint32_t_u_u_unsafe_macro/*95*//* ___SAFE__OP */((((*l_1222) != ((**g_1362) || ((((*g_1814) != l_2012) , ((((((**g_1638) = (void*)0) != l_2015) < ((*l_1262) |= 0x1AC98BD2051D8388LL)) & (4294967295UL < l_2008)) && 254UL)) , l_1955))) & l_1977), p_12))) ^ 1UL) , (void*)0)) == l_2016) != l_1954);
            l_2008 = l_1997;
        }
        else
        { /* block id: 902 */
            int8_t **** const l_2036 = &l_1947;
            int32_t l_2037 = 0x158AB28BL;
            uint64_t *l_2042 = &g_1599;
            uint32_t *l_2050 = (void*)0;
            uint32_t *l_2051 = &l_1624;
            int64_t **l_2094[4];
            int64_t l_2124 = 0x468C2F20EBDEBE0BLL;
            int32_t l_2126 = 0x5A4C7D6CL;
            int32_t *l_2138 = &g_120;
            int16_t l_2140 = (-1L);
            int32_t l_2145 = (-2L);
            int32_t l_2147 = 0x2A87FC8EL;
            int32_t l_2148 = 1L;
            int32_t l_2149[9][8] = {{0xE1E8F596L,0x070D74E6L,0x00EA18F4L,0x0198FADAL,0x070D74E6L,0L,0x070D74E6L,0x0198FADAL},{0x1E8407EAL,0x070D74E6L,0x1E8407EAL,(-2L),0xE1E8F596L,0x1E8407EAL,0L,(-1L)},{(-7L),(-2L),4L,0xE1E8F596L,0x29A70F2DL,0x29A70F2DL,0xE1E8F596L,4L},{(-7L),(-7L),0L,0x0198FADAL,0xE1E8F596L,(-1L),(-7L),0xE1E8F596L},{0x1E8407EAL,0xE1E8F596L,(-2L),0x1E8407EAL,0x070D74E6L,0x1E8407EAL,(-2L),0xE1E8F596L},{0xE1E8F596L,0L,4L,0x0198FADAL,0L,(-2L),0x070D74E6L,4L},{(-1L),0x070D74E6L,4L,0xE1E8F596L,0xE1E8F596L,4L,0x070D74E6L,(-1L)},{0x29A70F2DL,0xE1E8F596L,4L,(-2L),(-7L),0x29A70F2DL,(-2L),0x0198FADAL},{(-7L),0x29A70F2DL,(-2L),0x0198FADAL,(-2L),0x29A70F2DL,(-7L),(-2L)}};
            int i, j;
            for (i = 0; i < 4; i++)
                l_2094[i] = &l_1262;
            (*l_1222) = ((safe_sub_func_uint64_t_u_u_unsafe_macro/*96*//* ___SAFE__OP */(((!(((&g_1815 != (g_2024 = l_2021[1])) | (!(l_2016 != ((safe_add_func_int64_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */(p_10, ((*g_259) = (safe_add_func_uint32_t_u_u_unsafe_macro/*98*//* ___SAFE__OP */(((void*)0 == &g_1396), p_10))))) , (((((((safe_rshift_func_int64_t_s_u_unsafe_macro/*99*//* ___SAFE__OP */((~(safe_rshift_func_int32_t_s_u_unsafe_macro/*100*//* ___SAFE__OP */(((*g_1400) != l_2036), g_34))), 8)) || 0x5AL) >= l_2037) ^ (*g_831)) || (-7L)) != 0x6CL) , (void*)0))))) , p_12)) ^ l_2037), (*g_831))) , (-4L));
            if ((6L == ((safe_rshift_func_uint8_t_u_s_unsafe_macro/*101*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s_unsafe_macro/*102*//* ___SAFE__OP */(((l_2041 && l_2037) || (((*g_831) == ((*l_2042) = 0x8C8812DB6BFCB71CLL)) | ((safe_div_func_uint32_t_u_u_unsafe_macro/*103*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*104*//* ___SAFE__OP */(p_10, ((*l_1262) |= ((((!(safe_mod_func_int64_t_s_s_unsafe_macro/*105*//* ___SAFE__OP */(((++(*l_2051)) , p_10), l_2037))) >= p_12) != p_10) == 1L)))), 4294967295UL)) <= p_12))))), p_12)) && 0x1FB45119C8A397D5LL)))
            { /* block id: 909 */
                int64_t l_2060 = 0x01E8BA66AFCACF55LL;
                uint32_t *l_2071[9] = {&l_1931,&l_1931,&l_1931,&l_1931,&l_1931,&l_1931,&l_1931,&l_1931,&l_1931};
                int i;
                (*l_1222) = (safe_add_func_int32_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */((p_10 & (safe_lshift_func_int16_t_s_s_unsafe_macro/*107*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u_unsafe_macro/*108*//* ___SAFE__OP */(l_2060, ((safe_mul_func_uint32_t_u_u_unsafe_macro/*109*//* ___SAFE__OP */((5UL >= l_2060), (l_2037 = ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*110*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*111*//* ___SAFE__OP */((*g_831), (safe_sub_func_uint16_t_u_u_unsafe_macro/*112*//* ___SAFE__OP */((~(((**g_1362) = (1UL && ((*l_2042) = p_11))) , p_11)), ((l_2070 , l_2036) != (void*)0))))), 57)) ^ 1L)))) > p_11))), p_11))), p_12));
                for (p_10 = 0; (p_10 <= 6); p_10 += 1)
                { /* block id: 916 */
                    const int64_t ***l_2092 = (void*)0;
                    const int64_t **l_2093 = &g_2091;
                    int16_t *l_2095 = &l_2041;
                    int i;
                    for (g_177 = 5; (g_177 >= 0); g_177 -= 1)
                    { /* block id: 919 */
                        uint8_t ***l_2073 = (void*)0;
                        volatile uint32_t * volatile * volatile *l_2077[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2077[i] = &g_2074;
                        l_2072 = l_2072;
                        l_2037 = 0x38E84FADL;
                        g_2074 = g_2074;
                    }
                    (****g_1638) = (l_1223[(p_10 + 2)] = (**l_1913));
                    l_2126 &= (safe_lshift_func_uint64_t_u_u_unsafe_macro/*113*//* ___SAFE__OP */((*g_831), ((safe_add_func_int64_t_s_s_unsafe_macro/*114*//* ___SAFE__OP */(p_12, (((safe_mul_func_uint16_t_u_u_unsafe_macro/*115*//* ___SAFE__OP */(0x61E6L, (((safe_mul_func_uint64_t_u_u_unsafe_macro/*116*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */(1L, (safe_mul_func_int8_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */(((*l_1836) = 0L), ((safe_sub_func_uint32_t_u_u_unsafe_macro/*119*//* ___SAFE__OP */((g_1666 = (p_11 , (((++(*l_1554)) <= (((safe_lshift_func_uint32_t_u_u_unsafe_macro/*120*//* ___SAFE__OP */(((safe_rshift_func_int32_t_s_u_unsafe_macro/*121*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s_unsafe_macro/*122*//* ___SAFE__OP */((safe_div_func_uint64_t_u_u_unsafe_macro/*123*//* ___SAFE__OP */((0x7B61F922DFF0342BLL != ((safe_div_func_int8_t_s_s_unsafe_macro/*124*//* ___SAFE__OP */((l_2037 &= (1UL <= (safe_mod_func_uint64_t_u_u_unsafe_macro/*125*//* ___SAFE__OP */((*g_831), p_12)))), 0xEDL)) , p_12)), 0x525140151125422ELL)), l_2124)), 17)) && (*g_2075)), l_2124)) , 0x66F9A030A9E8A93FLL) , 0UL)) > p_11))), l_2125)) != l_2124))))), (-7L))) || 0x8F0BL) == 0x81E7E4928B9C178ALL))) > (*g_1916)) , (-1L)))) || p_12)));
                    for (g_281 = 0; (g_281 <= 9); g_281 += 1)
                    { /* block id: 938 */
                        int i, j;
                        if (g_387[g_281][(p_10 + 1)])
                            break;
                    }
                    for (l_2037 = 5; (l_2037 >= 0); l_2037 -= 1)
                    { /* block id: 943 */
                        int i, j;
                        return g_387[(p_10 + 3)][(p_10 + 1)];
                    }
                }
                for (g_137 = (-28); (g_137 <= 3); ++g_137)
                { /* block id: 949 */
                    uint8_t l_2131[4][5][6] = {{{0x9DL,0x7EL,0UL,0xFBL,255UL,0x1CL},{0xA8L,0xA2L,0x57L,0x53L,6UL,0xE2L},{9UL,0xEEL,255UL,0xF8L,7UL,7UL},{0x2CL,0xFBL,0xFBL,0x2CL,0xBEL,9UL},{0xB2L,0x57L,250UL,6UL,7UL,0xCAL}},{{0xEEL,6UL,0x4DL,0xBFL,7UL,0x35L},{0UL,0x57L,0x48L,255UL,0xBEL,1UL},{0UL,0xFBL,255UL,0x48L,7UL,0x53L},{255UL,0xEEL,0x7EL,0xE3L,6UL,0x48L},{8UL,0xA2L,0xF8L,0x57L,255UL,0xB2L}},{{0xF8L,0x7EL,3UL,0x7EL,0xF8L,0x44L},{6UL,0x1CL,0x53L,255UL,250UL,0xBEL},{255UL,0x42L,0xEEL,0x1CL,0x57L,0xBEL},{3UL,0UL,0x53L,255UL,255UL,0x7EL},{255UL,0x2CL,0xCAL,0x48L,0x7EL,255UL}},{{0UL,0xFBL,255UL,0x1CL,0x48L,0x44L},{0xA2L,0x7EL,0x4DL,255UL,0UL,6UL},{0x53L,0x5FL,0UL,0UL,0x5FL,0x53L},{0x42L,250UL,0x44L,0UL,7UL,0xE3L},{0xFBL,0xE2L,0x5FL,1UL,0xA2L,0x1CL}}};
                    int32_t l_2135[4] = {(-5L),(-5L),(-5L),(-5L)};
                    int i, j, k;
                    for (g_728 = 0; (g_728 < 26); ++g_728)
                    { /* block id: 952 */
                        uint64_t * const * volatile **l_2134[1][4][6] = {{{&g_2132,&g_2132,&g_2132,&g_2132,&g_2132,&g_2132},{&g_2132,&g_2132,&g_2132,&g_2132,&g_2132,&g_2132},{&g_2132,&g_2132,&g_2132,&g_2132,&g_2132,&g_2132},{&g_2132,&g_2132,&g_2132,&g_2132,&g_2132,&g_2132}}};
                        int i, j, k;
                        l_2131[0][1][2] = (p_10 != p_12);
                        g_2132 = g_2132;
                        (**g_1640) = (void*)0;
                    }
                    l_2135[3] = 0x1467941DL;
                    (**g_445) = g_2136;
                    if (p_10)
                        continue;
                }
                l_2138 = l_2137;
            }
            else
            { /* block id: 962 */
                uint64_t l_2141 = 0x74C09AC348FDE5C3LL;
                l_2141--;
            }
            ++l_2154;
        }
        (*g_2136) = p_12;
    }
    (**l_1913) = l_2157;
    return (*l_1222);
}


/* ------------------------------------------ */
/* 
 * reads : g_264 g_346 g_48 g_34 g_120 g_547 g_231 g_46 g_92 g_312 g_137 g_4 g_710 g_39
 * writes: g_120 g_34 g_486 g_1206 g_703 g_39
 */
static int64_t  func_22(int32_t  p_23, int32_t  p_24)
{ /* block id: 517 */
    uint8_t l_1180 = 0x4AL;
    int32_t l_1185 = 0xCF69EC5AL;
    int32_t **l_1193 = &g_39;
    int32_t ***l_1192 = &l_1193;
    int32_t *l_1194 = &g_120;
    int32_t *l_1195 = &g_34;
    uint16_t *l_1196 = &g_486;
    int32_t *l_1197[9] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
    int16_t l_1198 = 1L;
    int32_t *l_1205 = &g_1206;
    int8_t *l_1207 = &g_703;
    int i;
    l_1198 |= (g_264[2][1][0] >= (safe_unary_minus_func_uint64_t_u_unsafe_macro/*126*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s_unsafe_macro/*127*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_s_unsafe_macro/*128*//* ___SAFE__OP */(p_24, (~((safe_div_func_int32_t_s_s_unsafe_macro/*129*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*130*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */(l_1180, (((*l_1196) = (safe_add_func_uint8_t_u_u_unsafe_macro/*132*//* ___SAFE__OP */(((l_1185 &= (safe_mod_func_int8_t_s_s_unsafe_macro/*133*//* ___SAFE__OP */((&g_1055 == (void*)0), g_346))) >= ((((*l_1195) |= ((*l_1194) = ((safe_lshift_func_int32_t_s_s_unsafe_macro/*134*//* ___SAFE__OP */(p_24, 18)) && ((safe_sub_func_int16_t_s_s_unsafe_macro/*135*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*136*//* ___SAFE__OP */(((l_1192 != &g_446) && g_48), p_24)), p_23)) == 0UL)))) || g_120) <= g_547[2][0][1])), g_231))) <= p_23))), p_24)), p_23)) && (*l_1194))))) , (*l_1194)), (-5L))))));
    (**l_1192) = ((safe_lshift_func_int64_t_s_s_unsafe_macro/*137*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */(((*l_1207) = ((((*l_1205) = (safe_rshift_func_int32_t_s_u_unsafe_macro/*139*//* ___SAFE__OP */((-1L), g_46))) , &l_1193) != &g_446)), (safe_mod_func_uint64_t_u_u_unsafe_macro/*140*//* ___SAFE__OP */((safe_unary_minus_func_uint64_t_u_unsafe_macro/*141*//* ___SAFE__OP */((((&l_1193 != (void*)0) != g_92) ^ (((*l_1195) = ((safe_mul_func_uint32_t_u_u_unsafe_macro/*142*//* ___SAFE__OP */(1UL, (!((safe_sub_func_uint16_t_u_u_unsafe_macro/*143*//* ___SAFE__OP */((4L & p_23), g_312)) , g_137)))) >= g_4)) && g_710)))), p_24)))), p_23)) , (**l_1192));
    return (*l_1195);
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_241 g_242 g_243 g_486 g_415 g_92 g_48 g_547 g_703 g_32 g_710 g_231 g_4 g_728 g_259 g_177 g_149 g_99 g_445 g_446 g_447 g_448 g_281 g_137 g_386 g_418 g_120 g_795 g_831 g_340 g_312 g_136 g_624 g_39 g_1053 g_45 g_346 g_643 g_1160
 * writes: g_34 g_39 g_41 g_42 g_48 g_45 g_444 g_547 g_415 g_92 g_258 g_703 g_32 g_710 g_728 g_99 g_418 g_346 g_177 g_831 g_340 g_231 g_486 g_281 g_386 g_624 g_137 g_1161
 */
static uint32_t  func_27(int8_t  p_28, const int32_t  p_29)
{ /* block id: 1 */
    int32_t *l_36 = &g_34;
    int32_t **l_40[6][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0}};
    int i, j;
    (*l_36) ^= p_28;
    (*g_643) = func_37((g_42 = (g_41[1][1][0] = (g_39 = (void*)0))));
    g_1161[0][0][8] = g_1160[2];
    return (*l_36);
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_241 g_242 g_243 g_486 g_415 g_92 g_48 g_547 g_703 g_32 g_710 g_231 g_4 g_728 g_259 g_177 g_149 g_99 g_445 g_446 g_447 g_448 g_281 g_137 g_386 g_418 g_120 g_795 g_831 g_340 g_312 g_136 g_624 g_39 g_1053 g_45 g_346
 * writes: g_34 g_48 g_41 g_45 g_444 g_547 g_39 g_415 g_92 g_258 g_703 g_32 g_710 g_728 g_99 g_418 g_346 g_177 g_831 g_340 g_231 g_486 g_42 g_281 g_386 g_624 g_137
 */
static int32_t * func_37(int32_t * p_38)
{ /* block id: 6 */
    uint64_t l_59 = 0x8AE633C574C3FC6CLL;
    int64_t **l_571 = (void*)0;
    int32_t l_592[3][9] = {{0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L},{0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L,0x5990E871L},{0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L,0x891A42F6L}};
    uint64_t l_655 = 0x466A2BC35A74D091LL;
    uint8_t l_663 = 0xA4L;
    int32_t l_667[3];
    int32_t l_680 = (-6L);
    int32_t l_681 = (-5L);
    int8_t *l_735 = &g_703;
    int8_t **l_734 = &l_735;
    uint8_t l_755 = 0x13L;
    int64_t **l_785 = &g_259;
    volatile uint8_t * volatile **l_798 = (void*)0;
    int32_t **l_861 = &g_39;
    int32_t ***l_860 = &l_861;
    int32_t *** const *l_859 = &l_860;
    int8_t l_982 = (-2L);
    uint32_t l_983 = 0x449087D3L;
    int32_t l_1027 = 0xEAE477B6L;
    int8_t l_1028 = (-1L);
    int16_t l_1080 = 0x25EFL;
    int32_t l_1118 = 3L;
    int16_t *l_1125 = (void*)0;
    int16_t **l_1124 = &l_1125;
    int64_t ***l_1131 = &l_571;
    int64_t **** const l_1130 = &l_1131;
    int32_t *l_1157[3];
    uint64_t l_1158 = 1UL;
    uint64_t l_1159 = 0x1C36073B0574FF9DLL;
    int i, j;
    for (i = 0; i < 3; i++)
        l_667[i] = 1L;
    for (i = 0; i < 3; i++)
        l_1157[i] = (void*)0;
    for (g_34 = (-17); (g_34 >= (-26)); g_34 = safe_sub_func_int8_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */(g_34, 9))
    { /* block id: 9 */
        int32_t l_55 = 5L;
        int32_t l_57 = 1L;
        int32_t l_58[2];
        uint64_t l_500 = 0x992154861DBEC9ACLL;
        uint16_t l_622 = 1UL;
        int32_t l_646[4][6] = {{0xE8B72640L,4L,7L,0x9DA81176L,7L,4L},{0xE8B72640L,4L,7L,0x9DA81176L,7L,4L},{0xE8B72640L,4L,7L,0x9DA81176L,7L,4L},{0xE8B72640L,4L,7L,0x9DA81176L,7L,4L}};
        int16_t l_652 = 1L;
        uint32_t l_660 = 0xF4BFF47BL;
        uint8_t *l_666 = &g_312;
        int32_t **l_682 = &g_41[1][1][0];
        int32_t **l_683 = (void*)0;
        int32_t **l_684 = &g_39;
        int i, j;
        for (i = 0; i < 2; i++)
            l_58[i] = 0xEDE8B3ECL;
        for (g_48 = 0; (g_48 <= 0); g_48 += 1)
        { /* block id: 12 */
            int32_t l_49 = (-4L);
            int32_t l_56 = (-9L);
            int8_t **l_589 = (void*)0;
            int32_t *l_627[2][5][6] = {{{&g_34,&g_48,&g_48,&g_34,(void*)0,&g_34},{&g_34,(void*)0,&g_34,&g_48,&g_48,&g_34},{(void*)0,(void*)0,&g_48,&l_58[0],&g_48,(void*)0},{&g_48,(void*)0,&l_58[0],&l_58[0],(void*)0,&g_48},{(void*)0,&g_48,&l_58[0],&g_48,(void*)0,(void*)0}},{{&g_34,&g_48,&g_48,&g_34,(void*)0,&g_34},{&g_34,(void*)0,&g_34,&g_48,&g_48,&g_34},{(void*)0,(void*)0,&g_48,&l_58[0],&g_48,(void*)0},{&g_34,(void*)0,(void*)0,(void*)0,(void*)0,&g_34},{&g_48,&g_34,(void*)0,&g_34,&g_48,&g_48}}};
            uint64_t l_633[2];
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_633[i] = 1UL;
        }
        if ((safe_rshift_func_uint8_t_u_s_unsafe_macro/*145*//* ___SAFE__OP */((l_666 != &l_663), l_667[2])))
        { /* block id: 273 */
            int32_t * const l_668[4][7][9] = {{{&g_120,(void*)0,&l_58[1],(void*)0,&l_58[0],&l_592[1][7],(void*)0,&l_55,&l_58[1]},{&l_57,(void*)0,&g_34,&l_58[1],&l_55,&g_34,&g_34,&l_592[1][7],(void*)0},{&l_55,&l_55,(void*)0,&g_48,&l_592[0][6],(void*)0,&l_592[1][0],&l_592[1][7],&g_34},{&g_137,&l_592[1][7],(void*)0,&g_120,&l_58[1],&g_137,&l_55,&l_55,&l_592[1][7]},{&l_592[1][7],&l_58[1],&g_48,&g_120,&g_48,&l_55,&l_58[1],&l_592[1][7],&g_34},{&g_137,(void*)0,&l_592[1][7],&g_137,&l_58[1],&l_58[1],&g_137,&l_592[1][7],(void*)0},{&g_137,&g_34,&l_592[1][7],&l_58[1],&l_55,&g_48,&g_120,&g_48,&l_58[1]}},{{&l_592[1][7],&l_592[1][7],&l_55,&l_55,&g_137,&l_58[1],&g_120,(void*)0,&l_592[1][7]},{&g_137,&g_34,&l_592[1][7],&l_592[1][0],(void*)0,&l_592[0][6],&g_48,(void*)0,&l_55},{&l_55,(void*)0,&l_592[1][7],&g_34,&g_34,&l_55,&l_58[1],&g_34,(void*)0},{&l_57,&l_58[1],&l_55,(void*)0,&l_592[1][7],&l_58[0],(void*)0,&l_58[1],(void*)0},{&g_120,&l_592[1][7],&l_592[1][7],&g_34,(void*)0,&l_592[1][7],&g_48,&l_592[1][7],&l_592[1][7]},{&g_48,&l_55,&l_592[1][7],&l_592[1][0],(void*)0,&g_34,(void*)0,&l_592[1][7],&l_592[1][7]},{(void*)0,(void*)0,&g_48,&l_55,&l_592[1][7],&l_592[2][7],&g_137,(void*)0,&g_120}},{{&l_592[1][0],(void*)0,(void*)0,&l_58[1],&g_34,&g_34,&l_57,(void*)0,(void*)0},{&l_57,&l_592[1][7],(void*)0,&g_137,(void*)0,&l_592[1][7],&l_57,&l_592[2][7],&l_592[0][3]},{(void*)0,&l_592[1][7],&g_34,&g_120,&g_137,&l_58[0],&g_137,&g_34,(void*)0},{&g_48,&g_120,&l_58[1],&g_120,&l_55,&l_55,(void*)0,&l_592[2][7],&g_48},{&g_34,(void*)0,&l_592[1][7],&g_48,&l_58[1],&l_592[0][6],&g_48,(void*)0,&g_48},{(void*)0,&l_592[0][3],&l_592[1][7],&l_58[1],&g_48,&l_58[1],(void*)0,(void*)0,&l_58[0]},{&l_58[0],&l_58[0],&l_55,&l_592[0][6],&g_120,(void*)0,&l_58[1],&l_55,(void*)0}},{{&l_57,(void*)0,&l_592[1][7],(void*)0,(void*)0,&g_48,(void*)0,&g_48,&l_592[1][7]},{&g_137,(void*)0,&l_58[0],&g_120,&l_58[1],&l_592[2][6],(void*)0,&g_48,&g_137},{(void*)0,&l_58[0],&g_34,&l_58[1],(void*)0,&l_592[1][7],&g_34,&l_592[1][7],&l_57},{&l_592[0][6],(void*)0,&l_58[0],(void*)0,&l_58[0],(void*)0,(void*)0,(void*)0,&l_58[0]},{(void*)0,&l_592[1][7],&l_592[1][7],(void*)0,&l_55,&g_34,&g_34,&l_58[0],&l_58[1]},{&l_55,&g_137,&l_55,&l_58[1],&l_58[0],&g_48,&l_592[1][7],&l_58[1],(void*)0},{&l_592[2][7],&l_57,&l_55,&g_120,&l_55,&l_58[0],&l_55,&l_58[0],&l_592[2][6]}}};
            int i, j, k;
            (***g_241) = l_668[0][2][7];
        }
        else
        { /* block id: 275 */
            int8_t *l_669 = &g_92;
            int32_t l_672 = (-1L);
            int16_t *l_675 = &g_547[2][0][1];
            int32_t *l_678 = (void*)0;
            int32_t *l_679 = (void*)0;
            for (l_500 = 0; l_500 < 5; l_500 += 1)
            {
                for (l_55 = 0; l_55 < 7; l_55 += 1)
                {
                    for (g_45 = 0; g_45 < 6; g_45 += 1)
                    {
                        g_444[l_500][l_55][g_45] = &g_445;
                    }
                }
            }
            if (l_660)
                continue;
            l_681 = ((((void*)0 == l_669) ^ (safe_sub_func_int64_t_s_s_unsafe_macro/*146*//* ___SAFE__OP */((g_486 ^ l_672), (l_672 & (l_680 = ((safe_div_func_int16_t_s_s_unsafe_macro/*147*//* ___SAFE__OP */(((*l_675) = 0x4233L), ((l_500 < (safe_add_func_int32_t_s_s_unsafe_macro/*148*//* ___SAFE__OP */((l_592[2][4] = 0x302E4AEFL), (l_652 | 0x0EL)))) ^ 0UL))) , 0x9A5E3A71L)))))) , 0L);
        }
        (*l_684) = ((*l_682) = p_38);
        if (l_667[2])
            break;
    }
    for (g_415 = 3; (g_415 >= 1); g_415 -= 1)
    { /* block id: 289 */
        uint8_t l_701 = 0UL;
        int32_t l_705 = 1L;
        int64_t ***l_726[9][6] = {{&g_258[8],&l_571,&g_258[8],&l_571,&g_258[5],&g_258[8]},{&g_258[8],&g_258[8],&g_258[8],&g_258[5],&g_258[8],&g_258[8]},{&g_258[8],&g_258[8],&g_258[5],&l_571,&g_258[8],&l_571},{&g_258[8],&g_258[5],&g_258[8],&l_571,&l_571,&g_258[8]},{&g_258[5],&g_258[5],(void*)0,&g_258[8],&g_258[8],&l_571},{&g_258[8],&g_258[8],&l_571,(void*)0,&g_258[8],(void*)0},{&l_571,&g_258[8],&l_571,&l_571,&g_258[5],&l_571},{&g_258[9],&l_571,(void*)0,&l_571,&g_258[8],&g_258[8]},{&l_571,&g_258[8],&g_258[8],&l_571,(void*)0,&l_571}};
        int32_t l_742 = (-2L);
        int32_t l_746 = (-1L);
        int32_t l_749 = (-5L);
        int32_t l_750 = 0x88460DDFL;
        int64_t **l_786 = &g_259;
        int32_t **l_789 = &g_42;
        int32_t ***l_788[5][8][4] = {{{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{(void*)0,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789}},{{&l_789,&l_789,&l_789,&l_789},{(void*)0,&l_789,&l_789,&l_789},{(void*)0,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789}},{{&l_789,&l_789,&l_789,&l_789},{(void*)0,&l_789,(void*)0,&l_789},{&l_789,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,(void*)0},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789}},{{&l_789,&l_789,(void*)0,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{(void*)0,&l_789,(void*)0,&l_789},{&l_789,&l_789,(void*)0,(void*)0},{&l_789,&l_789,&l_789,&l_789},{(void*)0,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789}},{{&l_789,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,(void*)0},{&l_789,&l_789,&l_789,&l_789},{(void*)0,(void*)0,&l_789,&l_789}}};
        int32_t ****l_787 = &l_788[4][0][1];
        int8_t *l_835[6][8][5] = {{{&g_92,&g_92,&g_415,(void*)0,&g_415},{&g_415,&g_415,&g_92,&g_92,(void*)0},{&g_703,&g_703,(void*)0,&g_703,(void*)0},{&g_703,&g_92,&g_415,&g_92,&g_92},{(void*)0,&g_703,&g_703,&g_703,&g_703},{&g_703,&g_415,(void*)0,&g_703,&g_92},{&g_92,&g_92,&g_415,&g_415,&g_415},{&g_92,&g_415,&g_415,&g_92,(void*)0}},{{&g_703,&g_92,(void*)0,(void*)0,&g_92},{&g_415,&g_92,&g_415,&g_415,&g_92},{&g_92,&g_703,&g_703,(void*)0,(void*)0},{&g_415,&g_92,&g_415,&g_92,&g_415},{&g_415,&g_92,&g_415,&g_703,&g_703},{&g_92,&g_415,(void*)0,&g_92,&g_92},{&g_703,&g_703,&g_703,&g_92,&g_703},{(void*)0,&g_92,&g_703,(void*)0,&g_415}},{{&g_703,&g_415,&g_703,&g_703,(void*)0},{(void*)0,&g_415,&g_415,(void*)0,&g_92},{&g_415,&g_415,&g_92,&g_92,&g_92},{&g_415,&g_92,(void*)0,&g_92,&g_92},{(void*)0,&g_415,(void*)0,&g_415,(void*)0},{&g_703,&g_92,&g_415,(void*)0,(void*)0},{&g_415,(void*)0,&g_415,&g_92,&g_703},{&g_92,&g_415,&g_92,&g_92,&g_415}},{{&g_703,&g_92,&g_92,&g_415,&g_92},{&g_92,(void*)0,&g_92,&g_415,&g_415},{&g_703,(void*)0,&g_415,(void*)0,&g_415},{&g_92,&g_92,&g_415,&g_703,&g_703},{&g_415,&g_703,(void*)0,&g_92,&g_92},{&g_415,&g_703,(void*)0,(void*)0,&g_703},{&g_703,&g_703,&g_703,&g_92,(void*)0},{&g_415,&g_415,&g_415,&g_415,&g_415}},{{(void*)0,(void*)0,&g_703,&g_703,(void*)0},{&g_415,&g_92,(void*)0,&g_92,&g_415},{&g_703,&g_703,&g_703,(void*)0,&g_92},{(void*)0,&g_415,(void*)0,(void*)0,&g_92},{&g_703,&g_703,(void*)0,&g_703,&g_415},{&g_415,&g_415,&g_415,&g_415,&g_703},{(void*)0,&g_703,(void*)0,&g_92,&g_92},{&g_415,&g_92,&g_92,&g_703,&g_415}},{{&g_703,&g_415,(void*)0,(void*)0,(void*)0},{&g_415,(void*)0,&g_92,&g_415,(void*)0},{&g_415,(void*)0,&g_703,&g_415,&g_703},{&g_92,&g_92,&g_92,&g_92,&g_415},{&g_703,&g_415,&g_703,&g_703,&g_415},{&g_92,(void*)0,&g_415,&g_92,&g_703},{&g_703,&g_92,(void*)0,&g_703,&g_92},{&g_92,&g_92,&g_415,&g_92,&g_92}}};
        int8_t ***l_897 = (void*)0;
        uint16_t *l_1008[7];
        uint8_t l_1026[1][5] = {{0xA1L,0xA1L,0xA1L,0xA1L,0xA1L}};
        int32_t *l_1029[2][7] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_592[1][5],(void*)0,&l_592[1][5],(void*)0,&l_592[1][5],(void*)0,&l_592[1][5]}};
        int16_t l_1069 = 0x8F95L;
        int32_t l_1119 = 0x01FA3F9AL;
        const int8_t l_1151[2] = {6L,6L};
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_1008[i] = &g_346;
        for (g_34 = 0; (g_34 >= 0); g_34 -= 1)
        { /* block id: 292 */
            int32_t l_685 = 0x1F70A14AL;
            int32_t *l_686 = &l_685;
            int32_t l_743 = 0x594D2220L;
            int32_t l_748 = 1L;
            int32_t l_751 = 0L;
            int32_t l_752 = 0x6755F35BL;
            int32_t l_753 = 0x3309E530L;
            int32_t l_754 = 1L;
            int32_t * const *l_782[4];
            int32_t * const **l_781 = &l_782[1];
            int32_t * const ***l_780[6][6] = {{&l_781,&l_781,&l_781,&l_781,&l_781,&l_781},{&l_781,&l_781,&l_781,&l_781,&l_781,&l_781},{&l_781,&l_781,&l_781,&l_781,&l_781,&l_781},{(void*)0,&l_781,&l_781,(void*)0,&l_781,(void*)0},{&l_781,&l_781,&l_781,&l_781,(void*)0,&l_781},{&l_781,&l_781,&l_781,&l_781,(void*)0,&l_781}};
            const int32_t l_841 = 0x86572135L;
            uint16_t l_881 = 0xB5DBL;
            uint32_t l_883 = 0x697BCC95L;
            uint32_t l_912 = 1UL;
            uint16_t l_955 = 65535UL;
            uint8_t l_958 = 255UL;
            int i, j;
            for (i = 0; i < 4; i++)
                l_782[i] = (void*)0;
            if (((*l_686) = l_685))
            { /* block id: 294 */
                int8_t l_700 = (-1L);
                int32_t l_711 = 0xF3514FBFL;
                int64_t ***l_727 = (void*)0;
                int32_t l_745 = (-1L);
                int16_t l_803 = (-5L);
                int32_t **l_832[9] = {&g_41[1][1][0],&g_39,&g_41[1][1][0],&g_41[1][1][0],&g_39,&g_41[1][1][0],&g_41[1][1][0],&g_39,&g_41[1][1][0]};
                uint32_t l_849 = 0xA94B4111L;
                int i;
                for (g_48 = 0; (g_48 <= 0); g_48 += 1)
                { /* block id: 297 */
                    int64_t **l_692 = &g_259;
                    int32_t l_704 = 3L;
                    int8_t ***l_732 = (void*)0;
                    int8_t ***l_733 = &g_99;
                    int32_t l_744 = 0xDF669E84L;
                    int32_t l_747 = 0x5C4BB80AL;
                    int i, j, k;
                    for (g_92 = 1; (g_92 <= 4); g_92 += 1)
                    { /* block id: 300 */
                        int64_t ***l_690 = (void*)0;
                        int64_t ***l_691 = &g_258[8];
                        int32_t ***l_699 = (void*)0;
                        int32_t ****l_698 = &l_699;
                        int32_t *****l_697 = &l_698;
                        int8_t *l_702 = &g_703;
                        uint32_t *l_708 = (void*)0;
                        uint32_t *l_709[1][4][4] = {{{&g_710,&g_710,&g_710,&g_710},{&g_710,(void*)0,&g_710,&g_710},{&g_710,&g_710,&g_710,&g_710},{&g_710,&g_710,&g_710,&g_710}}};
                        uint64_t *l_716 = &l_655;
                        int32_t *l_729 = &l_592[1][7];
                        int i, j, k;
                        l_705 = (safe_rshift_func_int32_t_s_s_unsafe_macro/*149*//* ___SAFE__OP */((+((((*l_691) = l_571) != l_692) || (((((*l_702) |= (0x13302EE4E260CDB9LL < ((*l_686) &= (safe_sub_func_int8_t_s_s_unsafe_macro/*150*//* ___SAFE__OP */((((safe_sub_func_int8_t_s_s_unsafe_macro/*151*//* ___SAFE__OP */((((&g_445 == ((*l_697) = (void*)0)) && ((g_547[(g_92 + 1)][(g_48 + 1)][g_48] , l_667[2]) == (-1L))) & (6L && l_700)), 4L)) ^ l_701) ^ (-9L)), (-10L)))))) & 0xDBL) ^ (-7L)) , l_704))), 31));
                        g_32[g_34] = g_32[g_48];
                        (*l_729) ^= (safe_add_func_uint64_t_u_u_unsafe_macro/*152*//* ___SAFE__OP */(((++g_710) > (safe_mul_func_uint64_t_u_u_unsafe_macro/*153*//* ___SAFE__OP */(((((*l_716) = (18446744073709551615UL != ((void*)0 != g_32[0]))) <= 18446744073709551611UL) , (safe_mod_func_uint32_t_u_u_unsafe_macro/*154*//* ___SAFE__OP */(0x52C1115FL, l_701))), (*l_686)))), (((safe_add_func_uint8_t_u_u_unsafe_macro/*155*//* ___SAFE__OP */(l_701, (safe_mod_func_uint32_t_u_u_unsafe_macro/*156*//* ___SAFE__OP */((g_728 &= (safe_unary_minus_func_int64_t_s_unsafe_macro/*157*//* ___SAFE__OP */(((((((((safe_add_func_int8_t_s_s_unsafe_macro/*158*//* ___SAFE__OP */(l_704, 0x47L)) , l_701) , g_231) , g_4) == 0x01E7AD95L) , l_726[3][5]) != l_727) > (*l_686))))), (-10L))))) & g_547[2][0][1]) , (*g_259))));
                    }
                    if (g_547[(g_415 + 2)][g_34][(g_48 + 1)])
                        continue;
                    if ((safe_mod_func_uint16_t_u_u_unsafe_macro/*159*//* ___SAFE__OP */((((*l_733) = (*g_149)) == l_734), 1L)))
                    { /* block id: 314 */
                        uint32_t l_736 = 0x59E5074AL;
                        (*l_686) = ((((*l_734) = &l_700) != ((0L || l_700) , &l_700)) , (l_711 |= l_736));
                    }
                    else
                    { /* block id: 318 */
                        int32_t *l_737 = &l_705;
                        int32_t *l_738 = &g_120;
                        int32_t *l_739 = &l_680;
                        int32_t *l_740 = &l_705;
                        int32_t *l_741[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_741[i] = (void*)0;
                        l_755++;
                        if ((***g_445))
                            break;
                    }
                }
                if ((0x7E871B48L & ((safe_rshift_func_int64_t_s_s_unsafe_macro/*160*//* ___SAFE__OP */((l_663 ^ (18446744073709551615UL != (*l_686))), l_667[2])) , (((safe_div_func_int32_t_s_s_unsafe_macro/*161*//* ___SAFE__OP */(l_750, (safe_lshift_func_int64_t_s_s_unsafe_macro/*162*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u_unsafe_macro/*163*//* ___SAFE__OP */(l_750, (safe_rshift_func_uint8_t_u_s_unsafe_macro/*164*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*165*//* ___SAFE__OP */(((((safe_lshift_func_uint64_t_u_s_unsafe_macro/*166*//* ___SAFE__OP */((g_281 , (g_4 == l_655)), 24)) > 1L) < l_755) == l_680), 8)), 6)))) , l_749), (*l_686))))) | 1UL) , g_137))))
                { /* block id: 323 */
                    int32_t * const ****l_783 = &l_780[2][2];
                    int64_t ** const l_784 = &g_259;
                    uint16_t *l_792[3][7];
                    uint32_t *l_793 = &g_710;
                    int32_t l_794 = 0x000D298AL;
                    int i, j;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_792[i][j] = &g_486;
                    }
                    l_794 |= (((*g_259) = ((safe_sub_func_int16_t_s_s_unsafe_macro/*167*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*168*//* ___SAFE__OP */((g_92 || ((((safe_mod_func_uint16_t_u_u_unsafe_macro/*169*//* ___SAFE__OP */((g_346 = (((*l_793) |= ((l_745 = ((*l_686) >= (safe_lshift_func_uint64_t_u_u_unsafe_macro/*170*//* ___SAFE__OP */((((*l_783) = l_780[2][2]) == ((l_784 == (l_786 = l_785)) , l_787)), 20)))) | (((g_418 &= ((g_386[0] && 8UL) <= (((safe_div_func_int8_t_s_s_unsafe_macro/*171*//* ___SAFE__OP */(l_681, l_59)) != 255UL) > l_700))) , g_177) <= 8L))) < 0xB0A424A7L)), l_667[2])) , l_663) >= g_120) > 4294967295UL)), (-1L))), l_59)) , l_700)) || g_137);
                    for (l_681 = 0; (l_681 <= 1); l_681 += 1)
                    { /* block id: 334 */
                        uint64_t l_804[9] = {0x8D017DCD5BD2D096LL,0x8D017DCD5BD2D096LL,1UL,0x8D017DCD5BD2D096LL,0x8D017DCD5BD2D096LL,1UL,0x8D017DCD5BD2D096LL,0x8D017DCD5BD2D096LL,1UL};
                        uint8_t *l_833 = &l_701;
                        uint64_t *l_834 = &g_340;
                        int16_t *l_836 = &g_231;
                        int32_t l_850 = 0xCE5979C0L;
                        int i, j, k;
                        l_798 = g_795;
                        l_680 = (safe_mod_func_int16_t_s_s_unsafe_macro/*172*//* ___SAFE__OP */(((((((((safe_rshift_func_uint32_t_u_u_unsafe_macro/*173*//* ___SAFE__OP */(l_663, (l_803 ^ ((*l_836) |= ((l_804[8] ^ (((safe_add_func_uint32_t_u_u_unsafe_macro/*174*//* ___SAFE__OP */(g_4, (safe_mod_func_int32_t_s_s_unsafe_macro/*175*//* ___SAFE__OP */((((*l_734) = (((*l_834) = (safe_div_func_uint16_t_u_u_unsafe_macro/*176*//* ___SAFE__OP */((l_803 > ((*l_833) ^= (safe_rshift_func_int8_t_s_u_unsafe_macro/*177*//* ___SAFE__OP */(l_667[0], (((safe_lshift_func_uint16_t_u_s_unsafe_macro/*178*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u_unsafe_macro/*179*//* ___SAFE__OP */((safe_mod_func_uint8_t_u_u_unsafe_macro/*180*//* ___SAFE__OP */((((((((safe_rshift_func_uint16_t_u_s_unsafe_macro/*181*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*182*//* ___SAFE__OP */(0x10D711E544DC3B15LL, (safe_lshift_func_int8_t_s_u_unsafe_macro/*183*//* ___SAFE__OP */(l_804[8], ((safe_div_func_uint8_t_u_u_unsafe_macro/*184*//* ___SAFE__OP */((safe_lshift_func_uint8_t_u_u_unsafe_macro/*185*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u_unsafe_macro/*186*//* ___SAFE__OP */((((g_831 = &g_340) == &l_804[8]) && l_655), 0xBF082C04L)) > g_120), 2)), l_803)) || (*g_831)))))), 5)) , 0L) == g_547[2][0][1]) | l_804[8]) | l_804[1]) , l_832[3]) == (*g_242)), 0xEFL)), g_120)), 1)) ^ g_547[2][0][1]) , l_667[2]))))), l_804[8]))) , l_835[2][0][2])) != l_835[2][0][2]), l_755)))) , g_340) <= g_415)) <= (*g_259)))))) >= g_710) <= 0x353E9B89L) | g_703) , 1UL) <= 0xF0B3CBCDFF5B2117LL) != g_418) , (-1L)), 0xA256L));
                        l_850 ^= (l_849 = ((safe_mul_func_uint8_t_u_u_unsafe_macro/*187*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*188*//* ___SAFE__OP */(((((l_841 ^ 0xA1L) <= (*g_447)) || (safe_rshift_func_int32_t_s_u_unsafe_macro/*189*//* ___SAFE__OP */(((safe_lshift_func_uint16_t_u_s_unsafe_macro/*190*//* ___SAFE__OP */(((((*l_793) = (g_231 , ((+0UL) != (safe_sub_func_uint64_t_u_u_unsafe_macro/*191*//* ___SAFE__OP */(((&g_99 == (void*)0) , ((void*)0 == (*l_783))), 0xEAEEE86B5ED01C4ALL))))) < l_663) , g_547[2][0][1]), 14)) , 0x5AA1BAFAL), g_312))) | (*g_259)), 15)), g_547[(g_415 + 2)][l_681][g_34])) < 1L));
                        l_794 |= (*l_686);
                    }
                }
                else
                { /* block id: 347 */
                    int16_t *l_863[6] = {&g_547[5][0][1],&g_547[5][0][1],&g_547[5][0][1],&g_547[5][0][1],&g_547[5][0][1],&g_547[5][0][1]};
                    const int32_t l_864 = 0xDFB1863AL;
                    int32_t l_865 = 1L;
                    int32_t l_866 = 9L;
                    int32_t l_868 = 0xEC30AFBEL;
                    uint8_t l_869 = 3UL;
                    int i;
                    l_592[0][2] &= ((*l_686) = l_681);
                    if (((safe_div_func_int8_t_s_s_unsafe_macro/*192*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u_unsafe_macro/*193*//* ___SAFE__OP */(0L, 12)) <= (safe_lshift_func_int64_t_s_u_unsafe_macro/*194*//* ___SAFE__OP */(((safe_mul_func_uint64_t_u_u_unsafe_macro/*195*//* ___SAFE__OP */((*g_831), l_755)) < 0x0D06L), (l_859 != ((~(g_231 &= 0L)) , &l_860))))) > l_864), l_864)) , l_864))
                    { /* block id: 351 */
                        int64_t l_867[1][8][7] = {{{(-2L),(-2L),1L,0x28F87F6962A8649DLL,0L,1L,0L},{0x4E26769329150494LL,0x42615D3307370537LL,0x42615D3307370537LL,0x4E26769329150494LL,0x5B6DE16694081714LL,(-1L),0x4E26769329150494LL},{2L,0L,1L,1L,0L,2L,0x7AB4ECE03C6D3C7ALL},{0x8F0AB522F41C4847LL,0x4E26769329150494LL,1L,(-1L),(-1L),1L,0x4E26769329150494LL},{0L,0x7AB4ECE03C6D3C7ALL,2L,0L,1L,1L,0L},{(-1L),0x4E26769329150494LL,(-1L),0x5B6DE16694081714LL,0x4E26769329150494LL,0x42615D3307370537LL,0x42615D3307370537LL},{0x28F87F6962A8649DLL,0L,1L,0L,0x28F87F6962A8649DLL,1L,(-2L)},{(-1L),0x42615D3307370537LL,0x5B6DE16694081714LL,(-1L),0x5B6DE16694081714LL,0x42615D3307370537LL,(-1L)}}};
                        int i, j, k;
                        if ((*g_136))
                            break;
                        --l_869;
                    }
                    else
                    { /* block id: 354 */
                        (*l_686) = l_864;
                    }
                }
            }
            else
            { /* block id: 358 */
                for (g_486 = 0; (g_486 <= 4); g_486 += 1)
                { /* block id: 361 */
                    int64_t ****l_872 = &l_726[0][5];
                    int i, j, k;
                    (*l_789) = p_38;
                    for (l_59 = 0; (l_59 <= 9); l_59 += 1)
                    { /* block id: 365 */
                        return p_38;
                    }
                    (*l_872) = &g_258[2];
                }
                (*l_789) = p_38;
            }
            for (g_281 = 21; (g_281 >= 52); g_281++)
            { /* block id: 374 */
                int16_t *l_888 = (void*)0;
                uint16_t l_893 = 0x26E2L;
                int32_t l_894 = 1L;
                uint16_t l_905 = 65526UL;
                int32_t l_911[1];
                const int32_t l_917 = 0x7C243C4BL;
                int8_t * const l_920 = &g_92;
                int64_t l_925 = (-1L);
                int i;
                for (i = 0; i < 1; i++)
                    l_911[i] = 0x8CA07F33L;
                for (l_753 = 0; (l_753 >= (-8)); l_753 = safe_sub_func_uint16_t_u_u_unsafe_macro/*196*//* ___SAFE__OP */(l_753, 2))
                { /* block id: 377 */
                    uint64_t l_879 = 18446744073709551615UL;
                    uint32_t *l_880 = &g_710;
                    int16_t *l_889 = &g_547[2][1][1];
                    int16_t *l_891 = &g_231;
                    int16_t **l_890 = &l_891;
                    int16_t *l_892 = &g_547[5][0][2];
                    int32_t l_906[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_906[i] = (-8L);
                    (**l_860) = p_38;
                    if ((((g_448 , (safe_rshift_func_uint8_t_u_s_unsafe_macro/*197*//* ___SAFE__OP */((*l_686), (l_894 ^= ((((*l_880) = l_879) ^ l_881) != ((~l_883) , (safe_rshift_func_uint64_t_u_u_unsafe_macro/*198*//* ___SAFE__OP */((0x1DC5E3F1L | ((safe_mul_func_int16_t_s_s_unsafe_macro/*199*//* ___SAFE__OP */(g_624, (l_893 = ((*l_892) = ((l_889 = l_888) == ((*l_890) = (void*)0)))))) >= 0x3308E4476EF35A0ELL)), (*g_831))))))))) , l_892) != (void*)0))
                    { /* block id: 385 */
                        uint64_t l_904[1][7] = {{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL}};
                        int32_t l_907 = 0x3BAA88C7L;
                        int32_t l_908 = 0x1E0AC03CL;
                        int32_t l_909 = (-1L);
                        int32_t l_910[5];
                        uint64_t *l_921 = &l_59;
                        int i, j;
                        for (i = 0; i < 5; i++)
                            l_910[i] = 0x2D587CA6L;
                        l_906[2] = ((safe_sub_func_uint64_t_u_u_unsafe_macro/*200*//* ___SAFE__OP */((*g_831), (l_894 = ((**l_785) &= (l_897 != &g_99))))) <= (safe_div_func_uint16_t_u_u_unsafe_macro/*201*//* ___SAFE__OP */(((((4294967295UL ^ ((((void*)0 != &l_788[4][0][1]) & l_879) != (safe_mod_func_uint8_t_u_u_unsafe_macro/*202*//* ___SAFE__OP */(((void*)0 != (*g_149)), l_904[0][6])))) ^ 1UL) , l_879) || l_879), l_905)));
                        --l_912;
                        if ((*g_447))
                            break;
                        l_908 |= ((safe_div_func_int8_t_s_s_unsafe_macro/*203*//* ___SAFE__OP */(((*g_447) < l_917), (safe_div_func_int64_t_s_s_unsafe_macro/*204*//* ___SAFE__OP */(((0x206160741A87DFADLL <= l_906[2]) <= l_906[2]), ((*l_921) &= ((0x9CL && l_906[2]) , ((g_624 , l_920) == (void*)0))))))) || (*l_686));
                    }
                    else
                    { /* block id: 393 */
                        uint8_t l_922 = 5UL;
                        ++l_922;
                        if ((*g_136))
                            break;
                    }
                }
                if (l_925)
                    continue;
                for (l_748 = 0; (l_748 <= 1); l_748 += 1)
                { /* block id: 401 */
                    int i, j, k;
                    if (g_386[g_34])
                        break;
                    g_386[g_34] = g_547[(g_415 + 2)][g_34][(g_34 + 1)];
                }
                for (g_624 = 20; (g_624 > (-22)); g_624--)
                { /* block id: 407 */
                    uint32_t l_928 = 4294967287UL;
                    int8_t ***l_954 = &g_99;
                    if ((0UL && l_917))
                    { /* block id: 408 */
                        int32_t *****l_931 = &l_787;
                        int32_t l_932[8][5][6] = {{{0x2C6A34A8L,0xD6F69174L,0L,9L,0x570574C6L,(-1L)},{0xEA09B496L,0x0006BB22L,0xABA1397BL,1L,0xB6AD6772L,0xF9572ED4L},{0xB6AD6772L,0xABA1397BL,(-7L),0xD6F69174L,0L,0xE387AE15L},{9L,0L,(-1L),(-8L),0x43592C26L,0xEA09B496L},{(-1L),1L,0x6CFD9EA5L,3L,0x6CFD9EA5L,1L}},{{0xCE4569F2L,0x43592C26L,1L,0xF9572ED4L,3L,(-1L)},{(-3L),0L,0x69DF5259L,4L,0xEA09B496L,(-1L)},{0L,0L,9L,1L,3L,0L},{0L,0x43592C26L,0L,(-7L),0x6CFD9EA5L,0x86A63486L},{0L,1L,0xEFB0441CL,1L,0x43592C26L,0x443A60A6L}},{{0x86A63486L,0L,(-1L),0L,0L,0xABA1397BL},{1L,0xABA1397BL,1L,0x443A60A6L,0xB6AD6772L,3L},{4L,0x0006BB22L,1L,(-2L),(-1L),0x005AA668L},{1L,(-3L),0xF9572ED4L,0xF9572ED4L,(-3L),1L},{(-1L),0xEA09B496L,(-1L),0x2C6A34A8L,3L,0L}},{{(-1L),0L,0x99307D46L,0x52E9CB51L,1L,1L},{(-1L),0x69DF5259L,0x52E9CB51L,0x2C6A34A8L,0x0006BB22L,1L},{(-1L),3L,4L,0xF9572ED4L,0L,0x570574C6L},{1L,1L,3L,1L,(-1L),(-8L)},{0x6CFD9EA5L,(-1L),(-5L),(-1L),0xEA09B496L,4L}},{{(-1L),0x005AA668L,0x69DF5259L,3L,0xABA1397BL,0xCE4569F2L},{1L,(-2L),0xABA1397BL,(-1L),0x833340E0L,0xEA09B496L},{0x69DF5259L,0xB6AD6772L,1L,0xB6AD6772L,0x69DF5259L,0xD6F69174L},{(-2L),0x6CFD9EA5L,0L,0x77615A9DL,4L,(-1L)},{0L,1L,1L,0x6CFD9EA5L,0xD6F69174L,(-1L)}},{{0x52E9CB51L,0L,0L,1L,0xF9572ED4L,0xD6F69174L},{0xD6F69174L,0xCE4569F2L,1L,0L,0L,0xEA09B496L},{1L,0x99307D46L,0xABA1397BL,4L,0L,0xCE4569F2L},{0xE387AE15L,(-7L),0x69DF5259L,(-3L),1L,4L},{0xFEE7EF9FL,(-1L),(-5L),1L,0xE387AE15L,(-8L)}},{{(-5L),0L,3L,0xE387AE15L,0x570574C6L,0x570574C6L},{0x005AA668L,4L,4L,0x005AA668L,0x86A63486L,1L},{9L,0L,0x52E9CB51L,0xEA09B496L,0x2C6A34A8L,1L},{0xF9572ED4L,(-1L),0x99307D46L,(-7L),0x2C6A34A8L,0L},{0L,0L,(-1L),0L,0x86A63486L,1L}},{{3L,4L,0xF9572ED4L,0L,0x570574C6L,0x005AA668L},{0xEFB0441CL,0L,0x833340E0L,0x99307D46L,0xE387AE15L,0L},{0x2C6A34A8L,(-1L),(-1L),0x570574C6L,1L,1L},{0L,(-7L),0x443A60A6L,(-1L),0L,(-1L)},{4L,0x99307D46L,0L,1L,0L,1L}}};
                        int i, j, k;
                        l_928++;
                        l_932[4][4][2] ^= (l_911[0] != ((l_931 = (void*)0) == &g_241));
                    }
                    else
                    { /* block id: 412 */
                        uint8_t l_947 = 253UL;
                        int32_t l_948 = (-8L);
                        uint8_t *l_949 = &l_663;
                        uint64_t *l_950 = &l_655;
                        uint32_t *l_951 = &l_928;
                        int16_t *l_952 = &g_231;
                        int32_t l_953 = (-3L);
                        l_953 ^= (safe_mod_func_int16_t_s_s_unsafe_macro/*205*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*206*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s_unsafe_macro/*207*//* ___SAFE__OP */(0L, l_911[0])) > (((*l_952) = (((*l_951) = (l_928 ^ ((safe_div_func_uint16_t_u_u_unsafe_macro/*208*//* ___SAFE__OP */(0x5CA8L, (safe_mul_func_int32_t_s_s_unsafe_macro/*209*//* ___SAFE__OP */((((*l_950) = (safe_mul_func_uint16_t_u_u_unsafe_macro/*210*//* ___SAFE__OP */(l_917, ((l_948 ^= (((void*)0 != &g_547[5][1][0]) >= (safe_rshift_func_int64_t_s_s_unsafe_macro/*211*//* ___SAFE__OP */(l_947, 42)))) | (((((*l_949) = 0xDAL) , 0x02L) < l_905) != (*l_686)))))) == (*g_831)), l_928)))) == l_905))) >= g_231)) < 7L)), 0xF63EC7F5F0AB8A27LL)), l_947));
                        l_911[0] = (l_955 = (l_954 != &g_99));
                    }
                    for (l_753 = 0; (l_753 > 25); ++l_753)
                    { /* block id: 424 */
                        (***l_859) = p_38;
                    }
                }
            }
            l_958--;
            (*l_686) ^= (-1L);
        }
        if ((*g_136))
        { /* block id: 432 */
            uint16_t l_969[8] = {0x5275L,0x5275L,0x5275L,0x5275L,0x5275L,0x5275L,0x5275L,0x5275L};
            int32_t *l_987 = &l_681;
            uint64_t *l_1021 = (void*)0;
            const int8_t *l_1054 = &g_1055;
            int32_t l_1076 = 0x8B9E1D47L;
            int32_t l_1079[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1079[i] = 1L;
            for (l_742 = 0; (l_742 == (-29)); l_742 = safe_sub_func_int8_t_s_s_unsafe_macro/*212*//* ___SAFE__OP */(l_742, 5))
            { /* block id: 435 */
                uint8_t l_977 = 0x56L;
                int8_t l_984 = 0x82L;
                uint32_t l_985 = 0xBA2E0661L;
                int64_t l_1024[1][6] = {{0x7C228F62284CE4FALL,0x7C228F62284CE4FALL,0x7C228F62284CE4FALL,0x7C228F62284CE4FALL,0x7C228F62284CE4FALL,0x7C228F62284CE4FALL}};
                int i, j;
                for (g_92 = 2; (g_92 >= 0); g_92 -= 1)
                { /* block id: 438 */
                    uint16_t *l_1007 = &g_486;
                    int32_t l_1025 = 0L;
                    int i;
                }
            }
            (**l_860) = p_38;
            if (l_1028)
            { /* block id: 455 */
                return (**l_860);
            }
            else
            { /* block id: 457 */
                uint8_t l_1044[4][1][6];
                int8_t * const l_1063 = (void*)0;
                int32_t l_1067 = 0xAD1461A4L;
                uint32_t l_1081 = 2UL;
                int32_t l_1109[8][6] = {{1L,0x1AE4DAE1L,0L,0xBCB8E744L,0xBCB8E744L,0L},{1L,1L,0xBCB8E744L,0x338019A6L,3L,0x338019A6L},{0x338019A6L,3L,0x338019A6L,0xBCB8E744L,1L,1L},{0x1AE4DAE1L,0x338019A6L,0x338019A6L,0x1AE4DAE1L,3L,0L},{0L,0x1AE4DAE1L,1L,0x1AE4DAE1L,0L,0xBCB8E744L},{0x1AE4DAE1L,0L,0xBCB8E744L,0xBCB8E744L,0L,0x1AE4DAE1L},{0x338019A6L,0x1AE4DAE1L,3L,0L,3L,0x1AE4DAE1L},{3L,0x338019A6L,0xBCB8E744L,1L,1L,0xBCB8E744L}};
                int i, j, k;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 6; k++)
                            l_1044[i][j][k] = 255UL;
                    }
                }
                for (g_92 = 0; (g_92 >= 27); g_92++)
                { /* block id: 460 */
                    int32_t *l_1036 = &l_681;
                    const int8_t *l_1052 = &g_1053;
                    const int8_t **l_1051[8][3][6] = {{{&l_1052,&l_1052,(void*)0,(void*)0,&l_1052,&l_1052},{&l_1052,&l_1052,(void*)0,&l_1052,&l_1052,(void*)0},{(void*)0,&l_1052,(void*)0,&l_1052,&l_1052,&l_1052}},{{(void*)0,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,(void*)0,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052}},{{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,(void*)0,&l_1052,&l_1052},{&l_1052,&l_1052,(void*)0,(void*)0,&l_1052,(void*)0}},{{(void*)0,&l_1052,(void*)0,&l_1052,&l_1052,&l_1052},{&l_1052,&l_1052,(void*)0,&l_1052,&l_1052,(void*)0},{(void*)0,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052}},{{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,(void*)0},{(void*)0,&l_1052,&l_1052,(void*)0,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,(void*)0,&l_1052,(void*)0}},{{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,(void*)0},{&l_1052,&l_1052,(void*)0,(void*)0,&l_1052,&l_1052}},{{&l_1052,&l_1052,(void*)0,&l_1052,&l_1052,(void*)0},{(void*)0,&l_1052,(void*)0,&l_1052,&l_1052,&l_1052},{(void*)0,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052}},{{&l_1052,&l_1052,&l_1052,(void*)0,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052},{&l_1052,&l_1052,&l_1052,&l_1052,&l_1052,&l_1052}}};
                    uint32_t *l_1064 = &g_710;
                    int16_t *l_1065 = &g_547[2][0][1];
                    uint8_t *l_1066[8][4][8] = {{{&g_4,&l_663,&l_1044[3][0][3],&l_1044[3][0][3],&l_663,&g_4,&l_755,&l_701},{&l_1044[3][0][3],&l_1044[1][0][4],&l_1044[1][0][4],&g_4,&g_312,&l_663,&l_1026[0][2],&g_4},{&l_755,&l_1044[1][0][4],&l_755,&g_4,&l_701,&l_755,&l_755,&l_1044[1][0][4]},{&g_4,&l_701,&l_755,&g_312,&l_1026[0][2],&g_312,&l_755,&l_701}},{{&l_1044[3][0][3],&l_663,&g_4,&l_1044[1][0][4],&g_312,&l_1044[1][0][4],&l_1044[1][0][4],&l_1026[0][2]},{&g_4,&l_1026[0][2],&l_1044[3][0][3],&l_755,&l_1044[3][0][3],&l_755,&l_1044[1][0][4],&l_1044[1][0][4]},{&l_1026[0][2],&l_755,&g_4,&l_1044[1][0][4],&l_1044[1][0][1],&l_755,&l_755,&l_1044[1][0][1]},{&l_1044[1][0][1],&l_755,&l_755,&l_1044[1][0][1],&l_1044[1][0][4],&g_4,&l_755,&l_1026[0][2]}},{{&l_1044[1][0][4],&l_1044[1][0][4],&l_755,&l_1044[3][0][3],&l_755,&l_1044[3][0][3],&l_1026[0][2],&g_4},{&l_1026[0][2],&l_1044[1][0][4],&l_1044[1][0][4],&g_312,&l_1044[1][0][4],&g_4,&l_663,&l_1044[3][0][3]},{&l_701,&l_755,&g_312,&l_1026[0][2],&g_312,&l_755,&l_701,&g_4},{&l_1044[1][0][4],&l_755,&l_755,&l_701,&g_4,&l_755,&l_1044[1][0][4],&l_755}},{{&g_4,&l_1026[0][2],&l_663,&g_312,&g_4,&l_1044[1][0][4],&l_755,&l_1026[0][2]},{&l_1044[1][0][4],&l_663,&l_1026[0][2],&l_755,&g_312,&g_312,&l_755,&l_1026[0][2]},{&l_701,&l_701,&l_1044[3][0][3],&l_1044[1][0][4],&l_1044[1][0][4],&l_755,&l_1044[3][0][3],&l_755},{&l_1026[0][2],&l_1044[1][0][4],&l_1044[3][0][3],&l_1044[1][0][4],&l_755,&l_663,&l_755,&l_755}},{{&l_1044[1][0][4],&l_755,&l_1026[0][2],&l_1044[1][0][4],&l_1044[1][0][4],&l_1026[0][2],&l_1044[1][0][1],&l_1026[0][2]},{&l_1044[1][0][1],&l_755,&l_755,&l_755,&l_1044[1][0][1],&l_1044[3][0][3],&g_4,&l_1026[0][2]},{&l_1026[0][2],&l_1044[3][0][3],&l_663,&g_312,&l_1044[3][0][3],&l_1044[3][0][3],&l_663,&l_755},{&g_4,&l_755,&l_663,&l_701,&g_312,&l_1026[0][2],&g_4,&g_4}},{{&l_1044[3][0][3],&l_1044[1][0][1],&l_755,&l_1026[0][2],&l_1026[0][2],&l_755,&l_1044[1][0][1],&l_1044[3][0][3]},{&g_4,&g_4,&l_1026[0][2],&g_312,&l_701,&l_663,&l_755,&g_4},{&l_755,&l_663,&l_1044[3][0][3],&l_1044[3][0][3],&g_312,&l_663,&l_1044[3][0][3],&l_1026[0][2]},{&l_1026[0][2],&g_4,&l_1044[3][0][3],&l_1044[1][0][1],&l_755,&l_755,&l_755,&l_1044[1][0][1]}},{{&l_1026[0][2],&l_1044[1][0][1],&l_1026[0][2],&l_1044[1][0][4],&l_1044[1][0][4],&l_1026[0][2],&l_755,&l_1044[1][0][4]},{&l_755,&l_755,&l_755,&l_663,&l_701,&l_663,&l_755,&l_663},{&l_663,&g_312,&g_4,&l_1044[1][0][4],&l_755,&l_1026[0][2],&l_1044[3][0][3],&l_1044[3][0][3]},{&l_663,&l_663,&l_1026[0][2],&l_1026[0][2],&l_663,&l_663,&l_755,&l_1044[1][0][4]}},{{&g_4,&l_1044[3][0][3],&l_701,&l_1026[0][2],&l_1026[0][2],&l_755,&g_4,&l_701},{&l_663,&l_755,&g_4,&l_1026[0][2],&l_1044[3][0][3],&g_4,&l_663,&l_1044[1][0][4]},{&l_701,&l_1044[3][0][3],&l_1044[3][0][3],&l_1026[0][2],&g_4,&l_1026[0][2],&l_1044[3][0][3],&l_1044[3][0][3]},{&g_312,&l_755,&l_701,&l_1044[1][0][4],&l_1026[0][2],&l_701,&l_1044[1][0][4],&l_663}}};
                    int32_t l_1068 = (-5L);
                    int i, j, k;
                    if ((((safe_mul_func_uint16_t_u_u_unsafe_macro/*213*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*214*//* ___SAFE__OP */(((((l_1036 == p_38) | (safe_mul_func_int16_t_s_s_unsafe_macro/*215*//* ___SAFE__OP */(((((+(safe_unary_minus_func_uint64_t_u_unsafe_macro/*216*//* ___SAFE__OP */((g_231 | (0x4EABF90DL && ((safe_mul_func_uint16_t_u_u_unsafe_macro/*217*//* ___SAFE__OP */((~(((l_1044[3][0][3] ^ ((**l_785) = (safe_sub_func_int8_t_s_s_unsafe_macro/*218*//* ___SAFE__OP */((g_703 ^= (safe_lshift_func_int16_t_s_s_unsafe_macro/*219*//* ___SAFE__OP */((((l_1067 &= (safe_lshift_func_int32_t_s_s_unsafe_macro/*220*//* ___SAFE__OP */(((0x348FL & ((*l_1065) &= (((*l_1064) = ((l_1054 = (void*)0) != (((safe_lshift_func_int32_t_s_s_unsafe_macro/*221*//* ___SAFE__OP */(((*l_1036) = ((-4L) <= (safe_div_func_int64_t_s_s_unsafe_macro/*222*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_u_unsafe_macro/*223*//* ___SAFE__OP */(((!0xD2C31A9DE7946560LL) , l_1044[3][0][0]), 6)) || 0xC73CED2BL), (*l_987))))), l_969[3])) > l_1044[3][0][2]) , l_1063))) & l_1044[1][0][1]))) == l_969[3]), (*g_136)))) ^ l_1068) <= l_1069), 15))), g_312)))) < 4L) | 0xAFD87DB53F93DEA2LL)), l_1044[0][0][4])) && g_386[3])))))) > 0UL) | l_1044[3][0][3]) == g_486), l_1044[1][0][5]))) , (void*)0) == &g_258[8]), g_1053)), 0x6D6CL)) | 0x4A21L) || (*l_987)))
                    { /* block id: 468 */
                        return p_38;
                    }
                    else
                    { /* block id: 470 */
                        int32_t ** volatile * volatile *l_1075 = &g_242;
                        int32_t ** volatile * volatile **l_1074 = &l_1075;
                        int32_t l_1077 = 0xF6053D96L;
                        int32_t l_1078 = 0x27B61E21L;
                        uint16_t **l_1085 = &l_1008[3];
                        uint16_t ***l_1084 = &l_1085;
                        (*l_1074) = ((safe_lshift_func_int64_t_s_u_unsafe_macro/*224*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_s_unsafe_macro/*225*//* ___SAFE__OP */(0x74DD95A1EB9BD4CFLL, 48)), 46)) , &g_242);
                        ++l_1081;
                        (*l_1084) = (void*)0;
                        (*g_136) ^= (*l_1036);
                    }
                }
                for (g_703 = (-2); (g_703 <= 5); g_703 = safe_add_func_uint64_t_u_u_unsafe_macro/*226*//* ___SAFE__OP */(g_703, 2))
                { /* block id: 479 */
                    uint64_t l_1088 = 18446744073709551615UL;
                    if ((*l_987))
                        break;
                    --l_1088;
                }
                (*l_987) = (safe_div_func_uint32_t_u_u_unsafe_macro/*227*//* ___SAFE__OP */(1UL, (1UL || (safe_div_func_uint8_t_u_u_unsafe_macro/*228*//* ___SAFE__OP */((~((safe_add_func_uint16_t_u_u_unsafe_macro/*229*//* ___SAFE__OP */(((*l_987) | 0xA0L), g_45)) , (*l_987))), ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*230*//* ___SAFE__OP */(((*g_259) ^ ((safe_sub_func_uint8_t_u_u_unsafe_macro/*231*//* ___SAFE__OP */(0xEAL, ((safe_mul_func_int16_t_s_s_unsafe_macro/*232*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*233*//* ___SAFE__OP */(0x9D7C8503L, l_1044[3][0][3])), g_281)) ^ (*l_987)))) != 1L)), l_1044[1][0][4])) && (-10L)))))));
                if ((l_1067 > g_624))
                { /* block id: 484 */
                    int32_t l_1108 = 0x6B709AD6L;
                    uint8_t l_1110 = 0xBAL;
                    int32_t l_1115 = 0x50EDD3BEL;
                    int16_t l_1116[10] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
                    int32_t l_1117[9][9][2] = {{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)},{(-1L),0xF25011A8L},{(-1L),(-1L)},{0xF25011A8L,(-1L)}},{{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L},{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L},{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L}},{{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L},{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L},{0xF25011A8L,0x25A26D5FL},{0xF25011A8L,0xF25011A8L},{0x25A26D5FL,0xF25011A8L}}};
                    uint32_t l_1120 = 0xFBC0256AL;
                    int i, j, k;
                    l_1110--;
                    l_1108 = (safe_add_func_int16_t_s_s_unsafe_macro/*234*//* ___SAFE__OP */(l_1067, l_1108));
                    if (l_1110)
                        break;
                    l_1120++;
                }
                else
                { /* block id: 489 */
                    int32_t *l_1123[1][7];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_1123[i][j] = &g_137;
                    }
                    l_681 = 0x0D0F20ACL;
                    return l_1123[0][1];
                }
            }
        }
        else
        { /* block id: 494 */
            uint32_t l_1141[4][1];
            int32_t l_1156 = 1L;
            int i, j;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1141[i][j] = 8UL;
            }
            for (l_982 = 3; (l_982 <= 9); l_982 += 1)
            { /* block id: 497 */
                int16_t **l_1126 = (void*)0;
                int32_t l_1127[8] = {0x7E012E16L,0x7E012E16L,0x7E012E16L,0x7E012E16L,0x7E012E16L,0x7E012E16L,0x7E012E16L,0x7E012E16L};
                const int64_t *l_1135 = &g_624;
                const int64_t ** const l_1134[1][9][8] = {{{(void*)0,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135},{&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135},{(void*)0,&l_1135,(void*)0,&l_1135,&l_1135,&l_1135,(void*)0,&l_1135},{&l_1135,&l_1135,&l_1135,(void*)0,&l_1135,&l_1135,&l_1135,&l_1135},{&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135},{&l_1135,&l_1135,&l_1135,&l_1135,(void*)0,(void*)0,(void*)0,&l_1135},{(void*)0,(void*)0,(void*)0,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135},{&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135,&l_1135},{&l_1135,&l_1135,&l_1135,(void*)0,&l_1135,&l_1135,&l_1135,&l_1135}}};
                const int64_t ** const *l_1133 = &l_1134[0][1][1];
                const int64_t ** const ** const l_1132 = &l_1133;
                int32_t l_1152 = 9L;
                uint8_t *l_1153 = (void*)0;
                uint8_t *l_1154 = &l_1026[0][4];
                int32_t l_1155 = 0L;
                int i, j, k;
                l_1127[5] &= (l_1124 == l_1126);
                l_1156 |= (safe_mul_func_uint64_t_u_u_unsafe_macro/*235*//* ___SAFE__OP */(18446744073709551613UL, (((l_1130 == l_1132) , 0xE87EC174L) < ((safe_mul_func_int64_t_s_s_unsafe_macro/*236*//* ___SAFE__OP */(((safe_div_func_int64_t_s_s_unsafe_macro/*237*//* ___SAFE__OP */(((((*l_1154) = ((((!((l_1141[2][0] , (*g_831)) & ((g_346--) <= ((l_1141[2][0] && (safe_rshift_func_int8_t_s_u_unsafe_macro/*238*//* ___SAFE__OP */((l_1127[7] = 4L), 4))) > (safe_div_func_int16_t_s_s_unsafe_macro/*239*//* ___SAFE__OP */((safe_unary_minus_func_uint32_t_u_unsafe_macro/*240*//* ___SAFE__OP */((((*g_259) = ((((safe_rshift_func_uint32_t_u_u_unsafe_macro/*241*//* ___SAFE__OP */(0UL, l_1151[0])) >= l_1152) != l_1141[2][0]) != l_1152)) != (*g_831)))), g_547[1][1][2])))))) , (void*)0) != (void*)0) == 1L)) && 0x48L) & 0UL), l_1141[2][0])) && 0xB2F110A6L), (-3L))) != l_1155))));
                return p_38;
            }
            return p_38;
        }
    }
    (*g_136) |= (l_1158 ^= 8L);
    (*g_136) = l_1159;
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_120 g_447 g_448 g_137 g_281 g_259 g_177 g_312 g_34 g_242 g_243 g_41 g_533 g_241 g_415 g_231 g_547 g_387
 * writes: g_137 g_281 g_41 g_415 g_547
 */
static int32_t * func_62(int32_t * const  p_63, int32_t * p_64, int32_t  p_65, int64_t  p_66)
{ /* block id: 195 */
    int32_t *l_501 = &g_137;
    int32_t *l_502 = &g_137;
    int32_t *l_503 = &g_120;
    int32_t l_504 = 0L;
    int32_t *l_505 = &g_137;
    int32_t *l_506 = &g_120;
    int32_t *l_507 = &g_137;
    int32_t *l_508[8][7][4] = {{{&l_504,(void*)0,(void*)0,&g_34},{&l_504,(void*)0,&g_34,(void*)0},{&g_34,&g_34,&g_34,(void*)0},{&g_48,&g_34,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_34},{&g_34,(void*)0,(void*)0,(void*)0},{(void*)0,&g_48,(void*)0,&g_48}},{{&g_48,(void*)0,&g_34,&g_48},{&g_34,&g_48,&g_34,(void*)0},{&l_504,(void*)0,(void*)0,&g_34},{&l_504,(void*)0,&g_34,(void*)0},{&g_34,&g_34,&g_34,(void*)0},{&g_48,&g_34,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_34}},{{&g_34,(void*)0,(void*)0,(void*)0},{(void*)0,&g_48,(void*)0,&g_48},{&g_48,(void*)0,&g_34,&g_48},{&g_34,&g_48,&g_34,(void*)0},{&l_504,(void*)0,(void*)0,(void*)0},{&g_34,&g_120,&g_137,&g_34},{&g_48,(void*)0,&g_48,&g_34}},{{&g_34,(void*)0,&l_504,&g_34},{(void*)0,&g_120,(void*)0,(void*)0},{&g_48,&g_34,(void*)0,&g_34},{(void*)0,(void*)0,&l_504,(void*)0},{&g_34,&g_120,&g_48,(void*)0},{&g_48,(void*)0,&g_137,&g_34},{&g_34,&g_34,&l_504,(void*)0}},{{&g_34,&g_120,&g_137,&g_34},{&g_48,(void*)0,&g_48,&g_34},{&g_34,(void*)0,&l_504,&g_34},{(void*)0,&g_120,(void*)0,(void*)0},{&g_48,&g_34,(void*)0,&g_34},{(void*)0,(void*)0,&l_504,(void*)0},{&g_34,&g_120,&g_48,(void*)0}},{{&g_48,(void*)0,&g_137,&g_34},{&g_34,&g_34,&l_504,(void*)0},{&g_34,&g_120,&g_137,&g_34},{&g_48,(void*)0,&g_48,&g_34},{&g_34,(void*)0,&l_504,&g_34},{(void*)0,&g_120,(void*)0,(void*)0},{&g_48,&g_34,(void*)0,&g_34}},{{(void*)0,(void*)0,&l_504,(void*)0},{&g_34,&g_120,&g_48,(void*)0},{&g_48,(void*)0,&g_137,&g_34},{&g_34,&g_34,&l_504,(void*)0},{&g_34,&g_120,&g_137,&g_34},{&g_48,(void*)0,&g_48,&g_34},{&g_34,(void*)0,&l_504,&g_34}},{{(void*)0,&g_120,(void*)0,(void*)0},{&g_48,&g_34,(void*)0,&g_34},{(void*)0,(void*)0,&l_504,(void*)0},{&g_34,&g_120,&g_48,(void*)0},{&g_48,(void*)0,&g_137,&g_34},{&g_34,&g_34,&l_504,(void*)0},{&g_34,&g_120,&g_137,&g_34}}};
    uint16_t l_509 = 0UL;
    int64_t * const *l_519 = &g_259;
    uint64_t *l_529[9] = {&g_281,&g_340,&g_281,&g_340,&g_281,&g_340,&g_281,&g_340,&g_281};
    uint32_t l_530 = 0x3B8E25ABL;
    uint32_t l_552 = 7UL;
    int32_t **l_558 = &g_39;
    int32_t ***l_557 = &l_558;
    int32_t *** const *l_556[1];
    int32_t *** const **l_555 = &l_556[0];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_556[i] = &l_557;
    ++l_509;
    if (((safe_rshift_func_int16_t_s_s_unsafe_macro/*242*//* ___SAFE__OP */((+(g_46 , (((safe_rshift_func_int32_t_s_u_unsafe_macro/*243*//* ___SAFE__OP */(((safe_mod_func_int8_t_s_s_unsafe_macro/*244*//* ___SAFE__OP */(((*l_503) < ((((l_519 != l_519) , p_65) , ((((*g_447) <= ((safe_add_func_uint64_t_u_u_unsafe_macro/*245*//* ___SAFE__OP */((!((((*l_505) |= ((void*)0 == &g_259)) , (((safe_sub_func_uint64_t_u_u_unsafe_macro/*246*//* ___SAFE__OP */((g_281 ^= ((safe_add_func_int16_t_s_s_unsafe_macro/*247*//* ___SAFE__OP */(0xB3B3L, p_66)) != p_66)), (*g_259))) >= 0xDEL) >= (*p_64))) & 0L)), 0x448FF153B970BD7ALL)) >= 8UL)) >= 0UL) < (*l_503))) < (*l_506))), 9L)) < g_312), p_66)) <= (*l_506)) > l_530))), g_34)) == g_312))
    { /* block id: 199 */
        int32_t **l_531 = (void*)0;
        int32_t **l_532 = (void*)0;
        (*g_533) = (**g_242);
        return (***g_241);
    }
    else
    { /* block id: 202 */
        uint16_t l_542 = 65528UL;
        int32_t *l_543 = &g_137;
        int32_t l_544[7][4][6] = {{{0x62B1E092L,0L,0x10955B9AL,0x62B1E092L,7L,0x935C8229L},{(-1L),1L,1L,3L,(-1L),3L},{0xCC5C8D1BL,0xB4AA2DF9L,0xCC5C8D1BL,0xD19B02A5L,(-1L),0xAE9FB83CL},{1L,1L,(-1L),0xCC5C8D1BL,7L,(-1L)}},{{0x10955B9AL,0L,0x62B1E092L,0xCC5C8D1BL,1L,0xD19B02A5L},{1L,0L,0xAE9FB83CL,0x38B475ABL,(-1L),0L},{0x4A695B27L,(-6L),0x0B152A21L,0x247F1794L,0xD19B02A5L,0x38B475ABL},{9L,0x62B1E092L,0L,0L,0x62B1E092L,9L}},{{0L,0x62B1E092L,9L,0L,0xD19B02A5L,0x0B152A21L},{0x0B152A21L,(-6L),0x4A695B27L,0x699F95D3L,(-1L),0x247F1794L},{0x0B152A21L,0x10955B9AL,0x699F95D3L,0L,0xAE9FB83CL,0xC1AEFD7AL},{0L,0xD19B02A5L,0xA52B703EL,0L,3L,0xC1AEFD7AL}},{{9L,0xAE9FB83CL,0x699F95D3L,0x247F1794L,0x935C8229L,0x247F1794L},{0x4A695B27L,(-1L),0x4A695B27L,0x38B475ABL,0x935C8229L,0x0B152A21L},{0x699F95D3L,0xAE9FB83CL,9L,0x4A695B27L,3L,9L},{0xA52B703EL,0xD19B02A5L,0L,0x4A695B27L,0xAE9FB83CL,0x38B475ABL}},{{0x699F95D3L,0x10955B9AL,0x0B152A21L,0x38B475ABL,(-1L),0L},{0x4A695B27L,(-6L),0x0B152A21L,0x247F1794L,0xD19B02A5L,0x38B475ABL},{9L,0x62B1E092L,0L,0L,0x62B1E092L,9L},{0L,0x62B1E092L,9L,0L,0xD19B02A5L,0x0B152A21L}},{{0x0B152A21L,(-6L),0x4A695B27L,0x699F95D3L,(-1L),0x247F1794L},{0x0B152A21L,0x10955B9AL,0x699F95D3L,0L,0xAE9FB83CL,0xC1AEFD7AL},{0L,0xD19B02A5L,0xA52B703EL,0L,3L,0xC1AEFD7AL},{9L,0xAE9FB83CL,0x699F95D3L,0x247F1794L,0x935C8229L,0x247F1794L}},{{0x4A695B27L,(-1L),0x4A695B27L,0x38B475ABL,0x935C8229L,0x0B152A21L},{0x699F95D3L,0xAE9FB83CL,9L,0x4A695B27L,3L,9L},{0xA52B703EL,0xD19B02A5L,0L,0x4A695B27L,0xAE9FB83CL,0x38B475ABL},{0x699F95D3L,0x10955B9AL,0x0B152A21L,0x38B475ABL,(-1L),0L}}};
        int16_t *l_545 = (void*)0;
        int16_t *l_546 = &g_547[2][0][1];
        int i, j, k;
        (*p_64) |= ((safe_add_func_uint64_t_u_u_unsafe_macro/*248*//* ___SAFE__OP */((0x0EL < ((g_448 < ((*l_546) ^= ((!((safe_lshift_func_uint8_t_u_u_unsafe_macro/*249*//* ___SAFE__OP */((*l_501), 7)) < ((safe_add_func_int8_t_s_s_unsafe_macro/*250*//* ___SAFE__OP */((g_415 ^= (((!((void*)0 != &p_66)) > 18446744073709551615UL) , ((l_542 < (l_543 == (l_544[0][1][3] , (void*)0))) & 0L))), (*l_502))) ^ g_231))) != 0xE4BC1600L))) , 0L)), (*l_505))) , 0xF8546B31L);
        (*l_543) &= (safe_rshift_func_uint8_t_u_u_unsafe_macro/*251*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*252*//* ___SAFE__OP */(g_387[4][1], 4)), 2));
        ++l_552;
        l_555 = l_555;
    }
    return (*g_243);
}


/* ------------------------------------------ */
/* 
 * reads : g_149 g_92 g_34 g_137 g_312 g_259 g_231 g_45 g_340 g_99 g_242 g_243 g_41 g_386 g_418 g_47 g_281 g_346 g_444 g_136 g_447 g_448 g_177 g_486 g_446
 * writes: g_99 g_92 g_41 g_137 g_281 g_177 g_231 g_415 g_346 g_418 g_312 g_447
 */
static int32_t * const  func_67(const uint16_t  p_68, int32_t * p_69, int32_t * const  p_70)
{ /* block id: 55 */
    int8_t *l_183 = &g_92;
    int8_t **l_182[1][9];
    int8_t ***l_184[2];
    int8_t **l_185 = &l_183;
    int32_t l_225 = 0xDF0F13A5L;
    int64_t *l_256 = (void*)0;
    int64_t **l_255 = &l_256;
    int32_t **l_311[6][9][2] = {{{(void*)0,&g_42},{&g_42,&g_42},{(void*)0,&g_39},{&g_39,&g_42},{&g_39,&g_39},{&g_41[0][3][0],&g_41[1][1][0]},{&g_41[1][1][0],(void*)0},{&g_41[2][2][1],&g_41[2][2][1]},{&g_41[0][0][0],&g_39}},{{&g_39,&g_39},{&g_42,&g_39},{(void*)0,&g_42},{&g_39,&g_41[1][1][0]},{&g_39,&g_42},{(void*)0,&g_39},{&g_42,&g_39},{&g_39,&g_39},{&g_41[0][0][0],&g_41[2][2][1]}},{{&g_41[2][2][1],(void*)0},{&g_41[1][1][0],&g_41[1][1][0]},{&g_41[0][3][0],&g_39},{&g_39,&g_42},{&g_39,&g_39},{(void*)0,&g_42},{&g_42,&g_42},{(void*)0,&g_39},{&g_39,&g_42}},{{&g_39,&g_41[0][0][0]},{&g_41[2][2][1],&g_41[1][1][0]},{&g_42,&g_41[2][0][1]},{&g_41[1][1][0],&g_41[1][1][0]},{&g_42,(void*)0},{&g_39,&g_42},{&g_39,&g_42},{&g_41[2][1][1],&g_39},{&g_41[0][0][0],(void*)0}},{{&g_41[0][0][0],&g_39},{&g_41[2][1][1],&g_42},{&g_39,&g_42},{&g_39,(void*)0},{&g_42,&g_41[1][1][0]},{&g_41[1][1][0],&g_41[2][0][1]},{&g_42,&g_41[1][1][0]},{&g_41[2][2][1],&g_41[0][0][0]},{&g_39,&g_39}},{{(void*)0,&g_41[0][3][0]},{&g_41[2][0][1],&g_41[1][1][0]},{&g_39,&g_41[1][1][0]},{&g_41[2][0][1],&g_41[0][3][0]},{(void*)0,&g_39},{&g_39,&g_41[0][0][0]},{&g_41[2][2][1],&g_41[1][1][0]},{&g_42,&g_41[2][0][1]},{&g_41[1][1][0],&g_41[1][1][0]}}};
    int32_t ** const *l_310 = &l_311[3][2][0];
    uint8_t l_373 = 0UL;
    uint64_t l_391 = 5UL;
    uint64_t *l_398[1];
    uint32_t l_399[7][1] = {{4294967295UL},{7UL},{7UL},{4294967295UL},{7UL},{7UL},{4294967295UL}};
    int16_t *l_400 = &g_231;
    int16_t l_411 = 0xCC7BL;
    int16_t *l_412 = (void*)0;
    int16_t *l_413 = (void*)0;
    int16_t *l_414[5][1];
    uint16_t *l_416 = &g_346;
    uint16_t *l_417[10][6][4] = {{{(void*)0,&g_418,(void*)0,(void*)0},{(void*)0,&g_418,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418}},{{(void*)0,&g_418,(void*)0,&g_418},{&g_418,&g_418,&g_418,(void*)0},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418}},{{&g_418,(void*)0,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{(void*)0,(void*)0,&g_418,(void*)0},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418}},{{&g_418,&g_418,(void*)0,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,(void*)0},{&g_418,&g_418,&g_418,&g_418}},{{(void*)0,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418}},{{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,(void*)0},{(void*)0,(void*)0,&g_418,&g_418},{&g_418,&g_418,(void*)0,&g_418},{&g_418,&g_418,&g_418,&g_418},{(void*)0,(void*)0,(void*)0,&g_418}},{{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,(void*)0,&g_418},{(void*)0,&g_418,&g_418,(void*)0}},{{&g_418,&g_418,(void*)0,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,(void*)0}},{{(void*)0,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,(void*)0,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418}},{{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{(void*)0,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418},{&g_418,&g_418,&g_418,&g_418}}};
    const int64_t *l_463 = &g_177;
    uint32_t l_474 = 18446744073709551615UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
            l_182[i][j] = &l_183;
    }
    for (i = 0; i < 2; i++)
        l_184[i] = &l_182[0][5];
    for (i = 0; i < 1; i++)
        l_398[i] = &l_391;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
            l_414[i][j] = &l_411;
    }
    l_185 = ((*g_149) = l_182[0][0]);
    for (g_92 = 25; (g_92 >= (-5)); g_92 = safe_sub_func_int8_t_s_s_unsafe_macro/*253*//* ___SAFE__OP */(g_92, 9))
    { /* block id: 60 */
        int64_t *l_209 = &g_177;
        int32_t l_224 = 0x92F33C9AL;
        int16_t l_247 = 6L;
        int16_t l_263 = 0x4B13L;
        int32_t l_314 = 0x57259765L;
        uint8_t l_341[6];
        int32_t l_349[10] = {0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L,0xD7EF8BE0L};
        int64_t l_382 = (-3L);
        int i;
        for (i = 0; i < 6; i++)
            l_341[i] = 0x40L;
        if ((*p_70))
        { /* block id: 61 */
            int32_t **l_188 = &g_41[1][1][0];
            int32_t l_227 = (-1L);
            int8_t **l_271 = &l_183;
            int64_t l_293 = 0x9A28790FD715AADELL;
            uint64_t *l_352 = (void*)0;
            uint64_t *l_353 = (void*)0;
            uint8_t *l_369 = &l_341[2];
            uint64_t l_372[8];
            int i;
            for (i = 0; i < 8; i++)
                l_372[i] = 0x91C3C8AF4EB58E62LL;
            (*l_188) = p_70;
            for (g_137 = 10; (g_137 >= 16); ++g_137)
            { /* block id: 65 */
                int32_t l_193 = 6L;
                int32_t *l_246 = &g_120;
                uint8_t *l_337 = &g_312;
                uint64_t *l_338 = &g_281;
                uint64_t *l_339 = &g_340;
                uint16_t *l_345 = &g_346;
            }
            l_372[0] ^= ((safe_lshift_func_uint64_t_u_s_unsafe_macro/*254*//* ___SAFE__OP */((g_281 = g_312), 46)) | ((*p_70) ^ (safe_add_func_int64_t_s_s_unsafe_macro/*255*//* ___SAFE__OP */(((~((*g_259) = p_68)) ^ (((safe_rshift_func_int8_t_s_u_unsafe_macro/*256*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*257*//* ___SAFE__OP */((((((safe_mod_func_uint8_t_u_u_unsafe_macro/*258*//* ___SAFE__OP */((g_231 > p_68), 0x30L)) , ((safe_add_func_uint8_t_u_u_unsafe_macro/*259*//* ___SAFE__OP */(7UL, ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*260*//* ___SAFE__OP */(((((l_349[5] = (safe_sub_func_int32_t_s_s_unsafe_macro/*261*//* ___SAFE__OP */(((--(*l_369)) , (*p_70)), g_45))) && (-1L)) >= g_340) != p_68), 40)) , p_68))) <= g_137)) && p_68) >= (-9L)) , 0x0776D319144B7A48LL), 1L)), 7)) < p_68) >= (**g_99))), p_68))));
            if (l_373)
                continue;
        }
        else
        { /* block id: 142 */
            int8_t l_374 = 0x1CL;
            int32_t l_375 = (-3L);
            int32_t l_376 = 0x8B695132L;
            int32_t l_377 = 3L;
            int32_t l_378 = 2L;
            int32_t l_379 = 0xA395CD1FL;
            int32_t l_380 = 1L;
            int32_t l_381 = (-8L);
            int32_t l_383 = 1L;
            int32_t l_384 = 1L;
            int32_t l_385[6][3][7] = {{{(-1L),0xCBB322BFL,0x8912448BL,4L,0x48DA2AB3L,1L,1L},{4L,0x8912448BL,0xCBB322BFL,(-1L),(-1L),1L,1L},{(-1L),0L,4L,0L,(-1L),1L,1L}},{{0x5FEB5DD1L,0L,7L,0x2CF8F0DDL,1L,0xCBB322BFL,1L},{7L,1L,(-1L),0xB1692AAEL,0x1A12764EL,(-1L),1L},{0x5FEB5DD1L,0x2CF8F0DDL,1L,1L,1L,0x2CF8F0DDL,0x5FEB5DD1L}},{{(-1L),0x2CF8F0DDL,0xF8E76158L,1L,0L,0x5FEB5DD1L,4L},{4L,1L,5L,0xF8E76158L,1L,1L,0L},{(-1L),0L,0xF8E76158L,7L,0x2CF8F0DDL,7L,0xF8E76158L}},{{0L,0L,1L,7L,0x8912448BL,7L,0x1A12764EL},{0x2CF8F0DDL,7L,1L,(-1L),0x66FEFA49L,1L,1L},{0x1A12764EL,(-1L),0L,0xF8E76158L,7L,0x2CF8F0DDL,7L}},{{1L,0x66FEFA49L,0x66FEFA49L,1L,4L,0x2CF8F0DDL,0xB1692AAEL},{0xF8E76158L,0L,(-1L),0x1A12764EL,1L,1L,0L},{(-1L),1L,7L,4L,(-1L),0L,0xB1692AAEL}},{{0L,5L,(-1L),(-1L),5L,0L,7L},{0L,(-1L),1L,1L,1L,0x8912448BL,1L},{(-1L),0xB1692AAEL,1L,0x66FEFA49L,0xF8E76158L,0xCBB322BFL,1L}}};
            uint64_t l_388 = 0xEA12EFCB469D889CLL;
            int i, j, k;
            l_388--;
        }
        return (**g_242);
    }
lbl_421:
    l_391--;
    if (((*p_70) >= ((safe_add_func_uint64_t_u_u_unsafe_macro/*262*//* ___SAFE__OP */((l_399[5][0] &= g_386[0]), 0xF8DAB3FDEFD5054CLL)) < (0xACEDEE32332A4DB8LL > (p_68 == (g_418 &= ((*l_416) = (((*l_400) = p_68) | (~(g_415 = (safe_sub_func_int8_t_s_s_unsafe_macro/*263*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u_unsafe_macro/*264*//* ___SAFE__OP */(g_34, (+(g_340 | (((safe_rshift_func_uint16_t_u_u_unsafe_macro/*265*//* ___SAFE__OP */(((void*)0 != &g_259), 1)) != 0x2DD2FDE7L) < l_411))))), 1UL))))))))))))
    { /* block id: 153 */
        int32_t **l_420 = &g_41[1][0][1];
        (*l_420) = p_70;
    }
    else
    { /* block id: 155 */
        int32_t *l_422 = &g_34;
        int64_t **l_431 = &l_256;
        int32_t ***l_443 = &l_311[3][2][0];
        int32_t ****l_442[10][2][8] = {{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}},{{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443},{(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443,(void*)0,&l_443}}};
        int32_t l_453 = (-1L);
        int i, j, k;
        if (p_68)
            goto lbl_421;
        (*g_243) = l_422;
        for (g_312 = 0; (g_312 <= 12); g_312 = safe_add_func_uint64_t_u_u_unsafe_macro/*266*//* ___SAFE__OP */(g_312, 9))
        { /* block id: 160 */
            uint32_t l_434 = 18446744073709551606UL;
            int32_t l_439 = (-6L);
            int32_t l_440[5];
            int32_t l_441 = (-6L);
            int32_t l_449 = 0xF85F2FCCL;
            int32_t l_450 = 0xC349CE26L;
            int64_t *l_462 = &g_177;
            const int8_t *l_485 = &g_92;
            const int8_t **l_484 = &l_485;
            const int8_t ***l_483 = &l_484;
            int i;
            for (i = 0; i < 5; i++)
                l_440[i] = 0xB57A13C9L;
            if ((safe_rshift_func_int16_t_s_s_unsafe_macro/*267*//* ___SAFE__OP */((safe_mod_func_int64_t_s_s_unsafe_macro/*268*//* ___SAFE__OP */(((l_450 = (((safe_rshift_func_uint8_t_u_s_unsafe_macro/*269*//* ___SAFE__OP */(0x4AL, (((l_431 != &l_256) != ((0xEF61L ^ ((((l_449 = ((((((((safe_lshift_func_uint8_t_u_s_unsafe_macro/*270*//* ___SAFE__OP */(l_434, 6)) <= (p_68 != (l_441 ^= ((((*l_183) |= p_68) & ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*271*//* ___SAFE__OP */((((&l_422 != ((safe_lshift_func_int64_t_s_u_unsafe_macro/*272*//* ___SAFE__OP */((l_440[3] = (l_439 |= 1L)), g_231)) , (void*)0)) & 0x6BF3L) != g_47), 41)) , g_281)) | g_346)))) | p_68) < (*l_422)) , l_442[1][0][4]) != g_444[4][6][3]) > 0L) >= g_281)) || g_346) | 0x1FD9L) & 0x4F5ABCADE687EA47LL)) , l_439)) , p_68))) , g_281) < 7UL)) < 0UL), p_68)), 8)))
            { /* block id: 167 */
                return p_70;
            }
            else
            { /* block id: 169 */
                int16_t *l_451 = &g_231;
                int32_t l_452 = (-4L);
                l_452 = (l_451 != &g_387[7][4]);
                if ((l_441 &= (*g_136)))
                { /* block id: 172 */
                    l_453 |= (*g_447);
                    for (g_177 = 0; (g_177 <= 1); g_177 += 1)
                    { /* block id: 176 */
                        return p_70;
                    }
                }
                else
                { /* block id: 179 */
                    uint32_t *l_487 = &l_399[5][0];
                    int32_t l_488 = (-1L);
                    l_439 &= (safe_sub_func_int64_t_s_s_unsafe_macro/*273*//* ___SAFE__OP */(0x516692B3A094E473LL, (0UL <= (safe_add_func_uint16_t_u_u_unsafe_macro/*274*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_s_unsafe_macro/*275*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*276*//* ___SAFE__OP */((g_418 && (((l_462 != l_463) , (l_488 ^= (safe_add_func_uint16_t_u_u_unsafe_macro/*277*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_u_unsafe_macro/*278*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*279*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s_unsafe_macro/*280*//* ___SAFE__OP */((((safe_mod_func_int32_t_s_s_unsafe_macro/*281*//* ___SAFE__OP */((l_474 = (*p_70)), ((*l_487) |= (9UL & (safe_sub_func_uint32_t_u_u_unsafe_macro/*282*//* ___SAFE__OP */(((safe_mul_func_uint32_t_u_u_unsafe_macro/*283*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s_unsafe_macro/*284*//* ___SAFE__OP */((safe_add_func_int64_t_s_s_unsafe_macro/*285*//* ___SAFE__OP */((p_68 && (l_483 != &g_99)), 18446744073709551615UL)), g_486)), g_34)) || (*p_70)), 0x476A7906L)))))) , g_45) ^ (*p_70)), (*p_70))), l_452)), 9)), g_418)))) , 251UL)), 0L)), 4)), p_68)))));
                    (*g_446) = (*g_446);
                }
            }
            l_440[2] = (((safe_sub_func_uint32_t_u_u_unsafe_macro/*286*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u_unsafe_macro/*287*//* ___SAFE__OP */(((((*p_70) , (((*l_431) = (*l_431)) == l_462)) > 1UL) <= (safe_add_func_int16_t_s_s_unsafe_macro/*288*//* ___SAFE__OP */((p_68 , ((l_449 = (safe_lshift_func_int16_t_s_s_unsafe_macro/*289*//* ___SAFE__OP */((-1L), 2))) & (safe_lshift_func_int8_t_s_s_unsafe_macro/*290*//* ___SAFE__OP */(0x18L, p_68)))), g_92))), 59)), (*p_70))) > p_68) > g_312);
            l_440[4] = ((l_450 = (*l_422)) < (253UL && 0xA8L));
        }
    }
    return p_70;
}


/* ------------------------------------------ */
/* 
 * reads : g_149 g_136 g_137 g_42 g_4 g_46 g_34 g_120 g_177 g_48
 * writes: g_99 g_177 g_42 g_120
 */
static uint32_t  func_78(int32_t  p_79, uint32_t  p_80, int32_t ** p_81)
{ /* block id: 40 */
    int8_t **l_148 = (void*)0;
    int32_t l_152 = (-1L);
    int32_t *l_153[9] = {&g_120,&g_120,&g_120,&g_120,&g_120,&g_120,&g_120,&g_120,&g_120};
    uint8_t l_154 = 0UL;
    uint64_t l_179 = 0x725A8890B9DDE583LL;
    int32_t l_180[4];
    int i;
    for (i = 0; i < 4; i++)
        l_180[i] = (-7L);
    (*g_149) = l_148;
    l_154 |= (0x9199376EL & (safe_rshift_func_uint32_t_u_s_unsafe_macro/*291*//* ___SAFE__OP */(p_80, (l_152 |= (*g_136)))));
    for (p_79 = 1; (p_79 <= 4); p_79 += 1)
    { /* block id: 46 */
        int32_t l_159 = 0xDD0038FFL;
        uint8_t *l_160 = &l_154;
        int32_t *l_165 = &g_137;
        int64_t *l_176 = &g_177;
        int32_t l_178 = 0x1CAC5C3DL;
        (*p_81) = ((safe_lshift_func_uint8_t_u_u_unsafe_macro/*292*//* ___SAFE__OP */((((safe_sub_func_int8_t_s_s_unsafe_macro/*293*//* ___SAFE__OP */((((*l_160) |= l_159) , (((l_178 &= ((((*l_176) ^= (0xC0AFFF8CD5190A73LL != ((((safe_sub_func_int8_t_s_s_unsafe_macro/*294*//* ___SAFE__OP */(((((safe_div_func_int64_t_s_s_unsafe_macro/*295*//* ___SAFE__OP */(p_80, p_79)) ^ ((*p_81) != l_165)) , (0x07550281L != (safe_mul_func_uint16_t_u_u_unsafe_macro/*296*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*297*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*298*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s_unsafe_macro/*299*//* ___SAFE__OP */(p_80, (safe_rshift_func_uint32_t_u_u_unsafe_macro/*300*//* ___SAFE__OP */((g_4 != p_79), 14)))), g_46)), (*l_165))), g_34)))) < 6UL), 0UL)) || g_120) && p_80) , 2UL))) < g_4) ^ g_48)) || 0xCF63E863L) > p_79)), 0x8BL)) || 0x82DDL) & l_179), 5)) , &g_120);
        (*g_42) = (**p_81);
        return (*l_165);
    }
    return l_180[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_92 g_48 g_4 g_47 g_34 g_136 g_137
 * writes: g_120 g_137 g_41
 */
static int8_t  func_86(int32_t ** p_87, uint8_t  p_88, int32_t * p_89, const int8_t  p_90)
{ /* block id: 24 */
    int8_t *l_97 = (void*)0;
    int8_t **l_96 = &l_97;
    int32_t l_101 = 6L;
    int32_t l_142 = 0xD62C3E90L;
    int32_t l_143[1][10][8] = {{{(-1L),0xB716CAE9L,(-1L),1L,7L,(-1L),0xCB3D53BAL,0x1BB5F034L},{0x9E5FB738L,1L,0L,7L,0xCF246574L,0xCF246574L,7L,0L},{0x9E5FB738L,0x9E5FB738L,0x6F98B6A6L,1L,7L,(-10L),0x9E5FB738L,7L},{(-1L),7L,1L,(-1L),0xB716CAE9L,(-1L),1L,7L},{7L,0xCB3D53BAL,0L,1L,0xCB3D53BAL,1L,0xB716CAE9L,0L},{0x1BB5F034L,0xB716CAE9L,0x913E687FL,7L,7L,0x913E687FL,0xB716CAE9L,0x1BB5F034L},{0xCF246574L,7L,0L,1L,0x9E5FB738L,0xCF246574L,1L,1L},{0x9E5FB738L,0xCF246574L,1L,1L,1L,0xCF246574L,0x9E5FB738L,1L},{0x1BB5F034L,7L,0x6F98B6A6L,0x1BB5F034L,0xB716CAE9L,0x913E687FL,7L,7L},{1L,0xB716CAE9L,0L,0L,0xB716CAE9L,1L,0xCB3D53BAL,1L}}};
    int i, j, k;
    for (p_88 = 0; (p_88 != 10); ++p_88)
    { /* block id: 27 */
        int8_t **l_100[9][10] = {{&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,(void*)0,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,&l_97,&l_97,&l_97,(void*)0,&l_97,&l_97,&l_97,&l_97,&l_97},{(void*)0,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,(void*)0,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{(void*)0,&l_97,&l_97,(void*)0,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97},{&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97,&l_97}};
        int i, j;
        l_100[7][7] = l_96;
    }
    if ((l_101 > (((safe_mod_func_uint8_t_u_u_unsafe_macro/*301*//* ___SAFE__OP */(p_90, 252UL)) < ((*l_96) != ((safe_rshift_func_uint8_t_u_u_unsafe_macro/*302*//* ___SAFE__OP */(g_92, ((p_88 < (safe_mod_func_uint32_t_u_u_unsafe_macro/*303*//* ___SAFE__OP */(p_90, (safe_lshift_func_uint8_t_u_u_unsafe_macro/*304*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*305*//* ___SAFE__OP */(((((safe_add_func_uint32_t_u_u_unsafe_macro/*306*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*307*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*308*//* ___SAFE__OP */(((g_48 & g_4) || l_101), 1L)), 251UL)), l_101)) , l_101) , 1L) , 0x432BL), l_101)), g_47))))) < l_101))) , &p_90))) & 0x45L)))
    { /* block id: 30 */
        int64_t l_118 = 0x563F42B182C9CB7CLL;
        int32_t *l_119 = &g_120;
        (*l_119) = (l_118 >= (l_101 = l_118));
    }
    else
    { /* block id: 33 */
        uint32_t l_129 = 1UL;
        int32_t *l_130 = &g_120;
        int32_t *l_138 = (void*)0;
        int32_t *l_139 = &g_120;
        int32_t *l_140 = &l_101;
        int32_t *l_141[8] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
        uint32_t l_144 = 0x424E3CA8L;
        int i;
        (*g_136) ^= ((safe_div_func_int8_t_s_s_unsafe_macro/*309*//* ___SAFE__OP */((+((!(l_101 ^ p_88)) < (safe_mul_func_uint32_t_u_u_unsafe_macro/*310*//* ___SAFE__OP */((l_101 >= (safe_div_func_int32_t_s_s_unsafe_macro/*311*//* ___SAFE__OP */(l_101, ((*l_130) = l_129)))), (g_34 > (((safe_mod_func_uint16_t_u_u_unsafe_macro/*312*//* ___SAFE__OP */((p_90 ^ ((+p_88) ^ ((safe_add_func_int16_t_s_s_unsafe_macro/*313*//* ___SAFE__OP */(0x8C74L, (-1L))) | l_101))), p_88)) || (-6L)) , 0L)))))), p_88)) == 0x68D4C3CCL);
        for (p_88 = 0; p_88 < 3; p_88 += 1)
        {
            for (l_101 = 0; l_101 < 4; l_101 += 1)
            {
                for (g_120 = 0; g_120 < 2; g_120 += 1)
                {
                    g_41[p_88][l_101][g_120] = &g_120;
                }
            }
        }
        l_144++;
    }
    return p_88;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_231, "g_231", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_264[i][j][k], "g_264[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_312, "g_312", print_hash_value);
    transparent_crc(g_340, "g_340", print_hash_value);
    transparent_crc(g_346, "g_346", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_386[i], "g_386[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_387[i][j], "g_387[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_415, "g_415", print_hash_value);
    transparent_crc(g_418, "g_418", print_hash_value);
    transparent_crc(g_448, "g_448", print_hash_value);
    transparent_crc(g_486, "g_486", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_547[i][j][k], "g_547[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_624, "g_624", print_hash_value);
    transparent_crc(g_703, "g_703", print_hash_value);
    transparent_crc(g_710, "g_710", print_hash_value);
    transparent_crc(g_728, "g_728", print_hash_value);
    transparent_crc(g_1053, "g_1053", print_hash_value);
    transparent_crc(g_1055, "g_1055", print_hash_value);
    transparent_crc(g_1206, "g_1206", print_hash_value);
    transparent_crc(g_1253, "g_1253", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1299[i][j][k], "g_1299[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1392, "g_1392", print_hash_value);
    transparent_crc(g_1396, "g_1396", print_hash_value);
    transparent_crc(g_1445, "g_1445", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1463[i][j][k], "g_1463[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1507, "g_1507", print_hash_value);
    transparent_crc(g_1558, "g_1558", print_hash_value);
    transparent_crc(g_1599, "g_1599", print_hash_value);
    transparent_crc(g_1619, "g_1619", print_hash_value);
    transparent_crc(g_1623, "g_1623", print_hash_value);
    transparent_crc(g_1630, "g_1630", print_hash_value);
    transparent_crc(g_1666, "g_1666", print_hash_value);
    transparent_crc(g_1723, "g_1723", print_hash_value);
    transparent_crc(g_2076, "g_2076", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 537
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 272
   depth: 2, occurrence: 64
   depth: 3, occurrence: 5
   depth: 4, occurrence: 7
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 4
   depth: 17, occurrence: 1
   depth: 19, occurrence: 6
   depth: 20, occurrence: 6
   depth: 21, occurrence: 2
   depth: 22, occurrence: 1
   depth: 23, occurrence: 4
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 3
   depth: 30, occurrence: 2
   depth: 31, occurrence: 3
   depth: 33, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 44, occurrence: 1
   depth: 48, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 485

XXX times a variable address is taken: 1506
XXX times a pointer is dereferenced on RHS: 211
breakdown:
   depth: 1, occurrence: 169
   depth: 2, occurrence: 34
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 247
breakdown:
   depth: 1, occurrence: 226
   depth: 2, occurrence: 14
   depth: 3, occurrence: 6
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 33
XXX times a pointer is compared with address of another variable: 20
XXX times a pointer is compared with another pointer: 14
XXX times a pointer is qualified to be dereferenced: 7795

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 955
   level: 2, occurrence: 246
   level: 3, occurrence: 179
   level: 4, occurrence: 84
   level: 5, occurrence: 30
XXX number of pointers point to pointers: 234
XXX number of pointers point to scalars: 251
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.5
XXX average alias set size: 1.39

XXX times a non-volatile is read: 1620
XXX times a non-volatile is write: 810
XXX times a volatile is read: 128
XXX    times read thru a pointer: 47
XXX times a volatile is write: 33
XXX    times written thru a pointer: 8
XXX times a volatile is available for access: 2.38e+03
XXX percentage of non-volatile access: 93.8

XXX forward jumps: 0
XXX backward jumps: 3

XXX stmts: 265
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 37
   depth: 1, occurrence: 40
   depth: 2, occurrence: 42
   depth: 3, occurrence: 38
   depth: 4, occurrence: 59
   depth: 5, occurrence: 49

XXX percentage a fresh-made variable is used: 15.8
XXX percentage an existing variable is used: 84.2
********************* end of statistics **********************/

