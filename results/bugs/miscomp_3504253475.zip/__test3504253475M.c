/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 1115e43
 * Options:   --seed 3504253475 --bitfields --packed-struct
 * Seed:      3504253475
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   uint8_t  f1;
   const int16_t  f2;
   uint8_t  f3;
   int16_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_8 = 0x7928FBC7L;
static int64_t g_23 = 1L;
static uint64_t g_26 = 0x94BB489F7A9D2E81LL;
static uint16_t g_85 = 0UL;
static uint32_t g_89 = 0x2E732266L;
static uint32_t g_92 = 4294967295UL;
static int64_t g_95[4][10][6] = {{{(-1L),0x1DDA348D5C8807C7LL,0x549E1F9A5DE3B0BALL,0x549E1F9A5DE3B0BALL,0x1DDA348D5C8807C7LL,(-1L)},{(-1L),(-1L),0x549E1F9A5DE3B0BALL,(-1L),(-1L),(-1L)},{0xD8FEB948C0F44DC8LL,(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL},{0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L),0xD8FEB948C0F44DC8LL},{(-1L),(-1L),(-1L),0x549E1F9A5DE3B0BALL,(-1L),(-1L)},{(-1L),0x1DDA348D5C8807C7LL,0x549E1F9A5DE3B0BALL,0x549E1F9A5DE3B0BALL,0x1DDA348D5C8807C7LL,(-1L)},{(-1L),(-1L),0x549E1F9A5DE3B0BALL,(-1L),(-1L),(-1L)},{0xD8FEB948C0F44DC8LL,(-1L),(-1L),0xD8FEB948C0F44DC8LL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)}},{{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)},{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)}},{{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)},{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)}},{{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L)},{0xD8FEB948C0F44DC8LL,(-1L),0x1DDA348D5C8807C7LL,0x1DDA348D5C8807C7LL,(-1L),0xD8FEB948C0F44DC8LL},{(-1L),0xD8FEB948C0F44DC8LL,0x1DDA348D5C8807C7LL,0xD8FEB948C0F44DC8LL,(-1L),(-1L)},{0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL},{0x549E1F9A5DE3B0BALL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL,0xD8FEB948C0F44DC8LL,0x549E1F9A5DE3B0BALL},{(-1L),(-1L),0xD8FEB948C0F44DC8LL,(-1L),0x549E1F9A5DE3B0BALL,0xD8FEB948C0F44DC8LL}}};
static int64_t g_96[6] = {3L,3L,3L,3L,3L,3L};
static volatile uint16_t g_97 = 1UL;/* VOLATILE GLOBAL g_97 */
static int64_t g_99 = 0x4D755E4DDAE41605LL;
static uint8_t g_112 = 0x61L;
static int16_t g_122 = (-1L);
static int32_t g_124[6][6] = {{1L,0xC1807002L,1L,(-6L),(-7L),(-7L)},{0x89F23B65L,1L,1L,0x89F23B65L,0xC1807002L,0x28A6F30DL},{0x28A6F30DL,0x89F23B65L,(-7L),0x89F23B65L,0x28A6F30DL,(-6L)},{0x89F23B65L,0x28A6F30DL,(-6L),(-6L),0x28A6F30DL,0x89F23B65L},{1L,0x89F23B65L,0xC1807002L,0x28A6F30DL,0xC1807002L,0x89F23B65L},{0xC1807002L,1L,(-6L),(-7L),(-7L),(-6L)}};
static volatile uint64_t g_127 = 1UL;/* VOLATILE GLOBAL g_127 */
static int32_t g_153 = 1L;
static volatile uint32_t g_156 = 0xCC42B5F3L;/* VOLATILE GLOBAL g_156 */
static int32_t *g_160 = &g_8;
static int32_t ** volatile g_159 = &g_160;/* VOLATILE GLOBAL g_159 */
static uint8_t g_166[6][10][4] = {{{0x3CL,0x8EL,0x33L,1UL},{0x19L,0x18L,0xD5L,0xC7L},{7UL,0xE1L,0xF2L,255UL},{8UL,1UL,0x03L,0xE1L},{0x26L,246UL,246UL,3UL},{0x8EL,0x6CL,0xF2L,255UL},{247UL,7UL,0xCFL,0xCFL},{0x19L,0x19L,0x8EL,7UL},{255UL,0xF2L,0x6CL,0x8EL},{0xA8L,255UL,3UL,0x6CL}},{{0x9FL,255UL,9UL,0x8EL},{255UL,0xF2L,0xE1L,7UL},{1UL,0x19L,255UL,0xCFL},{0x70L,7UL,0x23L,255UL},{0xD0L,0x6CL,1UL,3UL},{255UL,246UL,0xDAL,0xE1L},{0x18L,1UL,248UL,255UL},{0xD0L,0xE1L,8UL,0xC7L},{1UL,0x18L,255UL,1UL},{0xC7L,0x8EL,0xF8L,0xD0L}},{{255UL,1UL,0xCCL,0x18L},{0xE1L,0x21L,3UL,255UL},{3UL,0xC1L,0x78L,0xD0L},{255UL,8UL,0x33L,0x70L},{0xCFL,0x18L,0xCFL,1UL},{7UL,0x9FL,0xB7L,255UL},{0x8EL,0xCCL,0x03L,0x9FL},{0x6CL,246UL,0x03L,0xA8L},{0x8EL,0x26L,0xB7L,255UL},{7UL,0x33L,0xCFL,0x19L}},{{0xCFL,0x19L,0x33L,247UL},{255UL,0xFEL,0x78L,0x8EL},{3UL,0x03L,3UL,0x26L},{0xE1L,255UL,0xCCL,8UL},{255UL,0xFEL,0xF8L,7UL},{0xC7L,0xCFL,255UL,0x19L},{1UL,0xDAL,253UL,248UL},{0xE1L,0xF2L,255UL,0UL},{1UL,0x8EL,0x30L,1UL},{0x4AL,247UL,246UL,0x2EL}},{{0xE1L,1UL,0x18L,0x6CL},{0x45L,0x4AL,0x4AL,0x45L},{0x78L,255UL,0xCFL,0xF8L},{0UL,0x03L,7UL,1UL},{1UL,0x30L,0x8EL,1UL},{0x51L,0x03L,0xB7L,0xF8L},{1UL,255UL,0x21L,0x45L},{0x18L,0x4AL,252UL,0x6CL},{0xD5L,1UL,0x39L,0x2EL},{255UL,247UL,0xD0L,1UL}},{{0xF2L,0x8EL,0x2EL,0UL},{253UL,0xF2L,0x39L,248UL},{0xCFL,0xDAL,0xA8L,0x18L},{0x18L,252UL,0x91L,0xCFL},{248UL,3UL,0xB7L,253UL},{0UL,0UL,7UL,0xF2L},{1UL,0x2EL,255UL,255UL},{0x2EL,3UL,0xCFL,0xD5L},{0x6CL,0x18L,9UL,0x18L},{0x45L,0x91L,253UL,1UL}}};
static int8_t g_176 = 0x35L;
static volatile int32_t g_188 = (-4L);/* VOLATILE GLOBAL g_188 */
static uint64_t g_190 = 18446744073709551615UL;
static uint64_t g_208 = 0xF375C898DBEBFAB1LL;
static int32_t ** volatile g_261 = &g_160;/* VOLATILE GLOBAL g_261 */
static int32_t ** volatile g_263 = &g_160;/* VOLATILE GLOBAL g_263 */
static volatile struct S0 g_282 = {0UL,6UL,-6L,0x4DL,1L};/* VOLATILE GLOBAL g_282 */
static uint8_t *g_308 = &g_166[4][3][0];
static uint32_t g_349 = 18446744073709551612UL;
static uint32_t g_350[5][10][3] = {{{18446744073709551615UL,0x9B8B7CAEL,0x013C89DEL},{4UL,0x9B6E637CL,0x18BDE3FCL},{0x25439125L,0xB650EF13L,0x172247DEL},{0xA8099693L,4UL,0x5609E3F4L},{18446744073709551606UL,18446744073709551606UL,18446744073709551607UL},{0x668FCE3DL,7UL,1UL},{18446744073709551606UL,0UL,18446744073709551615UL},{0xC2C69E6BL,0UL,18446744073709551614UL},{0x5638F954L,18446744073709551606UL,18446744073709551615UL},{0x6EAFACCBL,1UL,1UL}},{{0x7EAEE474L,0x9B8B7CAEL,18446744073709551607UL},{0x70541828L,0x3ABF3A2DL,0x5609E3F4L},{1UL,18446744073709551613UL,0x172247DEL},{1UL,0x70541828L,0x18BDE3FCL},{0xCB51733BL,0x5638F954L,0x013C89DEL},{0x668FCE3DL,18446744073709551615UL,18446744073709551615UL},{0x013C89DEL,0xB650EF13L,9UL},{0x7A8B45E6L,0UL,0xB6F0A05AL},{18446744073709551606UL,0x013C89DEL,0x20F61167L},{1UL,0xA8099693L,1UL}},{{18446744073709551615UL,0x013C89DEL,18446744073709551606UL},{18446744073709551615UL,0UL,18446744073709551615UL},{1UL,0xB650EF13L,18446744073709551615UL},{0x6EAFACCBL,18446744073709551615UL,0xFCC1EED5L},{1UL,0x5638F954L,18446744073709551607UL},{18446744073709551614UL,0x70541828L,1UL},{0x9B8B7CAEL,18446744073709551613UL,9UL},{0xC2C69E6BL,0x3ABF3A2DL,0xC2C69E6BL},{0xCB51733BL,0x9B8B7CAEL,0x13E0FCADL},{1UL,1UL,18446744073709551615UL}},{{0x25439125L,18446744073709551606UL,18446744073709551615UL},{7UL,0UL,0x5609E3F4L},{0x55E3E626L,0xB111EF7BL,0x13E0FCADL},{18446744073709551615UL,18446744073709551615UL,0x60EF523AL},{18446744073709551615UL,0x88932E3EL,0x7EAEE474L},{0UL,0xC2C69E6BL,0x49318141L},{18446744073709551615UL,1UL,18446744073709551613UL},{0x9A203BC8L,0xA8099693L,0x5609E3F4L},{18446744073709551615UL,18446744073709551615UL,0UL},{0x99866C25L,0x99866C25L,18446744073709551614UL}},{{18446744073709551615UL,0x172247DEL,18446744073709551615UL},{0x7A8B45E6L,0x95139BD6L,0xCCAACA31L},{1UL,0xCB51733BL,0x55E3E626L},{18446744073709551615UL,0x7A8B45E6L,0xCCAACA31L},{0x88932E3EL,18446744073709551615UL,18446744073709551615UL},{0xFCC1EED5L,0xC2C69E6BL,18446744073709551614UL},{18446744073709551615UL,0xB111EF7BL,0UL},{0x18BDE3FCL,2UL,0x5609E3F4L},{18446744073709551615UL,18446744073709551615UL,18446744073709551613UL},{7UL,18446744073709551615UL,0x49318141L}}};
static uint8_t **g_356 = &g_308;
static uint8_t *** const  volatile g_355 = &g_356;/* VOLATILE GLOBAL g_355 */
static uint16_t g_377[2] = {65527UL,65527UL};
static int32_t g_380[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
static volatile int64_t g_381 = 0x163DC83A24B7C976LL;/* VOLATILE GLOBAL g_381 */
static struct S0 g_385 = {1UL,0x85L,8L,0xA4L,0L};
static const int32_t *g_430[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const int32_t **g_429[1][5] = {{&g_430[6],&g_430[6],&g_430[6],&g_430[6],&g_430[6]}};
static const int32_t ***g_428[10] = {&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1],&g_429[0][1]};
static volatile int64_t *g_433 = &g_381;
static volatile int64_t * volatile *g_432 = &g_433;
static int32_t g_446 = 0L;
static uint8_t ****g_475 = (void*)0;
static struct S0 *g_481 = &g_385;
static struct S0 ** volatile g_480 = &g_481;/* VOLATILE GLOBAL g_480 */
static int16_t g_500 = 0L;
static volatile uint32_t g_608 = 0xBA687AD1L;/* VOLATILE GLOBAL g_608 */
static uint16_t g_630 = 0xA863L;
static int32_t *g_642 = &g_380[4];
static int32_t ** volatile g_641 = &g_642;/* VOLATILE GLOBAL g_641 */
static uint32_t g_659[1] = {0x80B044C6L};
static volatile int16_t g_674 = 0L;/* VOLATILE GLOBAL g_674 */
static volatile uint32_t g_677 = 0x9A4E1EBFL;/* VOLATILE GLOBAL g_677 */
static uint32_t *g_717 = &g_89;
static uint32_t **g_716 = &g_717;
static int32_t **** const g_720 = (void*)0;
static int32_t **** const *g_719 = &g_720;
static uint16_t g_814 = 1UL;
static struct S0 g_842 = {8UL,1UL,0xC578L,0xEEL,0xDA7AL};
static uint32_t *g_922[8] = {&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349,&g_349};
static struct S0 g_998 = {5UL,254UL,0xC302L,0x58L,1L};
static int32_t g_1088[6][9] = {{0x511C2B4CL,0x511C2B4CL,0xDE19BDACL,4L,0x511C2B4CL,(-4L),4L,4L,(-4L)},{0x8661A9FEL,1L,5L,1L,0x8661A9FEL,0x1C6B8633L,0x8661A9FEL,1L,5L},{0x511C2B4CL,4L,0xDE19BDACL,0x511C2B4CL,0x511C2B4CL,0xDE19BDACL,4L,0x511C2B4CL,(-4L)},{0x2E0EFB87L,1L,0xDD22BBC3L,1L,0x2E0EFB87L,0x1C6B8633L,0x2E0EFB87L,1L,0xDD22BBC3L},{0x511C2B4CL,0x511C2B4CL,0xDE19BDACL,4L,0x511C2B4CL,(-4L),4L,4L,(-4L)},{0x8661A9FEL,1L,5L,1L,0x8661A9FEL,0x1C6B8633L,0x8661A9FEL,1L,5L}};
static int8_t g_1092 = 0x00L;
static int32_t *g_1110 = &g_380[8];
static int32_t ** const g_1109 = &g_1110;
static int32_t ** const *g_1108 = &g_1109;
static int32_t ** const **g_1107[5] = {&g_1108,&g_1108,&g_1108,&g_1108,&g_1108};
static int32_t ** const ***g_1106 = &g_1107[3];
static uint64_t *g_1123 = &g_190;
static int8_t g_1124 = (-5L);
static volatile int32_t g_1146 = 2L;/* VOLATILE GLOBAL g_1146 */
static volatile int32_t *g_1145 = &g_1146;
static uint8_t g_1180[8] = {254UL,0x2AL,254UL,0x2AL,254UL,0x2AL,254UL,0x2AL};
static int32_t **g_1259 = &g_160;
static int32_t ***g_1258 = &g_1259;
static struct S0 ** volatile g_1268 = &g_481;/* VOLATILE GLOBAL g_1268 */
static uint8_t ***g_1338 = &g_356;
static uint8_t ****g_1337 = &g_1338;
static struct S0 g_1364 = {0x7EB4E354678C3A1ALL,0x65L,6L,254UL,6L};
static int8_t *g_1375 = &g_1124;
static const uint8_t *g_1381[8] = {&g_385.f3,&g_385.f3,&g_385.f3,&g_385.f3,&g_385.f3,&g_385.f3,&g_385.f3,&g_385.f3};
static const uint8_t **g_1380 = &g_1381[3];
static const uint8_t ***g_1379[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const uint8_t ****g_1378[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint32_t **g_1394[8] = {&g_922[4],&g_922[4],&g_922[4],&g_922[4],&g_922[4],&g_922[4],&g_922[4],&g_922[4]};
static int32_t g_1401 = 1L;
static uint64_t ****g_1406[9][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
static int8_t g_1560 = 0x77L;
static const uint64_t *g_1614 = &g_385.f0;
static const uint64_t **g_1613 = &g_1614;
static const uint64_t ***g_1612 = &g_1613;
static const uint64_t ***g_1617[1] = {&g_1613};
static uint8_t g_1639[1] = {0xF9L};
static struct S0 ** volatile g_1669 = (void*)0;/* VOLATILE GLOBAL g_1669 */
static struct S0 ** const  volatile g_1670 = (void*)0;/* VOLATILE GLOBAL g_1670 */
static struct S0 g_1674 = {6UL,0xA1L,0xAC5DL,255UL,6L};
static struct S0 *g_1673[8] = {(void*)0,&g_1674,&g_1674,(void*)0,&g_1674,&g_1674,(void*)0,&g_1674};
static int32_t g_1696 = 7L;
static const volatile uint32_t g_1712[10] = {0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L,0x890A8C99L};
static volatile uint8_t *g_1759 = &g_282.f1;
static volatile uint8_t * volatile * volatile g_1758 = &g_1759;/* VOLATILE GLOBAL g_1758 */
static volatile uint8_t * volatile * volatile *g_1757 = &g_1758;
static volatile int8_t g_1762 = 3L;/* VOLATILE GLOBAL g_1762 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t * func_2(int32_t * p_3, int32_t * p_4, struct S0  p_5, const int32_t * p_6);
static int32_t * func_9(uint32_t  p_10, int32_t * p_11, int64_t  p_12, int32_t * p_13);
static uint32_t  func_14(int32_t * p_15, const uint16_t  p_16);
static int32_t  func_17(int16_t  p_18, int32_t  p_19, int32_t  p_20, int16_t  p_21);
static uint16_t  func_27(const uint32_t  p_28, uint16_t  p_29, uint16_t  p_30, uint32_t  p_31, struct S0  p_32);
static uint8_t  func_39(uint64_t * p_40, int16_t  p_41);
static int32_t  func_49(uint8_t  p_50, int32_t * p_51, int32_t  p_52, int8_t  p_53, int64_t  p_54);
static int32_t  func_60(const uint64_t * p_61, uint64_t * p_62, int32_t * p_63, uint64_t  p_64);
static uint64_t * func_65(int64_t * p_66, int32_t * p_67, int64_t  p_68, int8_t  p_69);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_23 g_85 g_89 g_26 g_96 g_97 g_99 g_112 g_95 g_124 g_127 g_261 g_160 g_166 g_92 g_282.f1 g_350 g_380 g_381 g_190 g_385.f3 g_176 g_355 g_356 g_308 g_428 g_432 g_377 g_446 g_208 g_480 g_385.f0 g_385.f4 g_500 g_429 g_385.f1 g_159 g_282.f4 g_385.f2 g_608 g_282.f3 g_641 g_433 g_659 g_814 g_842 g_642 g_717 g_716 g_630 g_122 g_263 g_481 g_998.f3 g_719 g_720 g_998.f4 g_998.f0 g_1088 g_1092
 * writes: g_23 g_26 g_85 g_89 g_92 g_95 g_97 g_99 g_112 g_122 g_124 g_127 g_160 g_8 g_380 g_190 g_385.f3 g_176 g_428 g_377 g_385.f1 g_475 g_481 g_430 g_500 g_166 g_385.f0 g_208 g_446 g_608 g_630 g_642 g_842.f0 g_349 g_350 g_842.f1 g_922 g_96 g_153 g_308 g_998.f4 g_385.f4 g_842.f4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_7[6][1] = {{(void*)0},{&g_8},{(void*)0},{(void*)0},{&g_8},{(void*)0}};
    int64_t *l_22[9];
    int8_t l_24 = (-9L);
    uint64_t *l_25 = &g_26;
    int32_t l_42 = 2L;
    uint32_t **l_838 = (void*)0;
    int8_t l_841 = (-1L);
    int16_t l_1026 = 0x4716L;
    struct S0 l_1074 = {0x3F0FC651F88B368DLL,0xC8L,-1L,0x4DL,-1L};
    int32_t **l_1078 = &g_642;
    uint16_t *l_1083[6][2];
    int32_t ***l_1089 = &l_1078;
    int16_t *l_1090[4];
    int8_t l_1091 = 0x7CL;
    uint64_t l_1126 = 0x34C6048F780EB93DLL;
    int32_t *l_1148[8][2][9] = {{{&g_446,&g_1088[5][3],&g_446,&g_8,(void*)0,&g_1088[5][5],&g_1088[4][7],&g_1088[4][7],&g_1088[5][5]},{&g_1088[5][5],&g_446,&g_446,&g_446,&g_1088[5][5],&g_380[8],(void*)0,&g_8,&g_8}},{{&g_446,&g_8,&g_1088[5][5],&g_8,&g_1088[5][5],&g_8,&g_446,(void*)0,&g_1088[2][7]},{&g_1088[4][7],&g_1088[2][7],&g_446,&g_380[8],(void*)0,&g_380[8],&g_446,&g_1088[2][7],&g_1088[4][7]}},{{&g_8,&g_380[8],&g_1088[4][7],(void*)0,(void*)0,&g_1088[5][5],(void*)0,(void*)0,&g_1088[4][7]},{(void*)0,(void*)0,&g_8,&g_446,&g_1088[2][7],&g_8,&g_1088[4][7],&g_8,&g_1088[2][7]}},{{&g_8,(void*)0,(void*)0,&g_8,&g_446,&g_1088[2][7],&g_8,&g_1088[4][7],&g_8},{&g_1088[4][7],&g_380[8],&g_8,&g_8,&g_380[8],&g_1088[4][7],(void*)0,(void*)0,&g_1088[5][5]}},{{&g_446,&g_1088[2][7],&g_1088[4][7],&g_446,&g_446,&g_1088[4][7],&g_1088[2][7],&g_446,&g_380[8]},{&g_1088[5][5],&g_8,&g_446,(void*)0,&g_1088[2][7],&g_1088[2][7],(void*)0,&g_446,&g_8}},{{&g_446,&g_446,&g_1088[5][5],&g_380[8],(void*)0,&g_8,&g_8,(void*)0,&g_380[8]},{&g_446,&g_1088[5][3],&g_446,&g_8,(void*)0,&g_1088[5][5],&g_1088[4][7],&g_1088[4][7],&g_1088[5][5]}},{{&g_1088[5][5],&g_446,&g_446,&g_446,&g_1088[5][5],&g_380[8],(void*)0,&g_8,&g_8},{&g_446,&g_8,&g_1088[5][5],&g_8,&g_1088[5][5],&g_8,&g_446,(void*)0,&g_1088[2][7]}},{{&g_1088[4][7],&g_1088[2][7],&g_446,&g_380[8],(void*)0,&g_380[8],&g_446,&g_1088[2][7],&g_1088[4][7]},{&g_8,&g_380[8],&g_1088[4][7],(void*)0,(void*)0,&g_1088[5][5],(void*)0,(void*)0,&g_1088[4][7]}}};
    int64_t l_1223 = 0L;
    int32_t l_1237 = 0x3F74BC18L;
    uint32_t l_1278 = 0x9CC77BAAL;
    uint32_t l_1299 = 9UL;
    uint16_t l_1302 = 1UL;
    uint32_t l_1346 = 1UL;
    uint32_t **l_1393 = &g_922[4];
    int8_t l_1400 = (-1L);
    uint64_t ****l_1404 = (void*)0;
    uint64_t l_1407[10] = {18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL,18446744073709551611UL};
    int8_t l_1437 = 0xC8L;
    int32_t *l_1439[2][4][7] = {{{&g_1088[5][5],&l_42,&g_1088[2][8],&g_1088[2][8],&l_42,&g_1088[5][5],&l_42},{(void*)0,(void*)0,&g_380[3],(void*)0,(void*)0,&g_380[3],(void*)0},{&l_42,&l_42,&g_1088[5][5],&l_42,&g_1088[2][8],&g_1088[2][8],&l_42},{&g_1088[5][5],(void*)0,&g_1088[5][5],(void*)0,(void*)0,&g_1088[5][7],&g_1088[5][7]}},{{(void*)0,&l_42,&g_1088[4][5],&l_42,(void*)0,&g_1088[4][5],(void*)0},{(void*)0,&g_1088[5][7],(void*)0,(void*)0,(void*)0,&g_1088[5][7],(void*)0},{&g_1088[5][5],(void*)0,&l_42,&g_1088[2][8],(void*)0,&g_1088[2][8],&l_42},{(void*)0,(void*)0,&g_380[3],(void*)0,(void*)0,&g_380[3],(void*)0}}};
    int32_t l_1451 = 0xEF55F40AL;
    int64_t l_1452 = (-1L);
    int8_t l_1458[3][9][9] = {{{4L,5L,7L,0x73L,0L,0L,0x73L,7L,5L},{0x73L,0L,7L,0xF6L,0L,5L,0x71L,7L,7L},{4L,0L,5L,0xF6L,5L,0L,4L,5L,7L},{0x48L,0L,0xE6L,0x73L,5L,0xE6L,0x71L,0xE6L,5L},{0x48L,5L,5L,0x48L,0L,0xE6L,0x73L,5L,0xE6L},{4L,5L,7L,0x73L,0L,0L,0x73L,7L,5L},{0x73L,0L,7L,0xF6L,0L,5L,0x71L,7L,7L},{4L,0L,5L,0xF6L,5L,0L,4L,5L,7L},{0x48L,0L,0xE6L,0x73L,5L,0xE6L,0x71L,0xE6L,5L}},{{0x48L,5L,5L,0x48L,0L,0xE6L,0x73L,5L,0xE6L},{4L,5L,7L,0x73L,0L,0L,0x73L,7L,5L},{0x73L,0L,7L,0xF6L,0L,5L,0x71L,7L,7L},{4L,0L,5L,0xF6L,5L,0L,4L,5L,7L},{0x48L,0L,0xE6L,0x73L,5L,0xE6L,0x71L,0xE6L,5L},{0x48L,5L,5L,7L,0x58L,6L,0xE6L,1L,6L},{5L,1L,(-1L),0xE6L,(-1L),(-1L),0xE6L,(-1L),1L},{0xE6L,0x58L,(-1L),0L,0x58L,1L,0L,(-1L),(-1L)},{5L,(-1L),1L,0L,1L,(-1L),5L,1L,(-1L)}},{{7L,0x58L,6L,0xE6L,1L,6L,0L,6L,1L},{7L,1L,1L,7L,0x58L,6L,0xE6L,1L,6L},{5L,1L,(-1L),0xE6L,(-1L),(-1L),0xE6L,(-1L),1L},{0xE6L,0x58L,(-1L),0L,0x58L,1L,0L,(-1L),(-1L)},{5L,(-1L),1L,0L,1L,(-1L),5L,1L,(-1L)},{7L,0x58L,6L,0xE6L,1L,6L,0L,6L,1L},{7L,1L,1L,7L,0x58L,6L,0xE6L,1L,6L},{5L,1L,(-1L),0xE6L,(-1L),(-1L),0xE6L,(-1L),1L},{0xE6L,0x58L,(-1L),0L,0x58L,1L,0L,(-1L),(-1L)}}};
    int8_t l_1488 = 1L;
    uint32_t l_1520 = 0xBCA97E2FL;
    const int32_t l_1558 = 0x39926F00L;
    uint64_t l_1610 = 18446744073709551615UL;
    const uint32_t *l_1648 = &l_1346;
    const uint32_t **l_1647[1][1];
    uint32_t l_1699 = 18446744073709551610UL;
    uint8_t ***l_1756[1][6] = {{&g_356,&g_356,&g_356,&g_356,&g_356,&g_356}};
    int64_t l_1761 = 1L;
    uint16_t l_1763[2];
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_22[i] = &g_23;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
            l_1083[i][j] = (void*)0;
    }
    for (i = 0; i < 4; i++)
        l_1090[i] = &l_1026;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_1647[i][j] = &l_1648;
    }
    for (i = 0; i < 2; i++)
        l_1763[i] = 65535UL;
    (*l_1078) = func_2(l_7[5][0], func_9(func_14((func_17((((g_23 &= g_8) == ((*l_25) = l_24)) , (((func_27((safe_mul_func_uint64_t_u_u_unsafe_macro/*0*//* ___SAFE__OP */((safe_sub_func_uint64_t_u_u_unsafe_macro/*1*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*2*//* ___SAFE__OP */((((func_39(l_22[8], l_42) == (l_838 == &g_717)) <= (safe_div_func_uint64_t_u_u_unsafe_macro/*3*//* ___SAFE__OP */((g_96[5] , 18446744073709551615UL), g_96[5]))) , (**g_432)), g_659[0])) <= g_814), g_350[3][3][1])), g_659[0])), g_350[0][5][2], l_841, g_350[3][3][1], g_842) , (*g_641)) != &l_42) <= 4UL)), l_1026, g_842.f3, g_385.f4) , &l_42), g_842.f3), &l_42, g_998.f0, &l_42), l_1074, l_7[5][0]);
    g_380[6] |= (safe_rshift_func_int32_t_s_s_unsafe_macro/*4*//* ___SAFE__OP */(0L, (9L ^ ((safe_mul_func_uint8_t_u_u_unsafe_macro/*5*//* ___SAFE__OP */(((*g_308) = 0x60L), (((g_630 = g_124[3][3]) | (g_842.f4 = ((g_282.f1 != (safe_add_func_uint64_t_u_u_unsafe_macro/*6*//* ___SAFE__OP */((0xE949D8F62BBC9432LL ^ (g_112 > ((safe_sub_func_int32_t_s_s_unsafe_macro/*7*//* ___SAFE__OP */((g_1088[5][5] == (((((l_1089 = &l_1078) == &l_1078) || 0xE3C457F1L) > 0x83L) ^ 0x3FL)), 0xA1BF1D84L)) || 65535UL))), g_350[3][3][1]))) <= g_99))) >= l_1091))) ^ g_1092))));
    for (l_841 = 0; (l_841 <= 3); l_841 += 1)
    { /* block id: 542 */
        int32_t ** const *l_1105 = &l_1078;
        int32_t ** const **l_1104 = &l_1105;
        int32_t ** const ***l_1103 = &l_1104;
        int32_t l_1125 = 0x6B3D0F84L;
        uint16_t l_1147 = 3UL;
        const uint32_t l_1170 = 1UL;
        int32_t l_1177[2];
        int16_t l_1191 = 0x2531L;
        struct S0 l_1199 = {0x0EE347FDCFDE9050LL,0x82L,0x75C4L,253UL,-5L};
        uint32_t l_1203 = 4294967295UL;
        int8_t l_1239 = 0L;
        const int16_t l_1261 = 0L;
        uint32_t l_1269[2];
        int i;
        for (i = 0; i < 2; i++)
            l_1177[i] = 1L;
        for (i = 0; i < 2; i++)
            l_1269[i] = 0UL;
    }
    for (g_85 = 0; (g_85 != 41); ++g_85)
    { /* block id: 649 */
        int8_t *l_1307 = &l_1091;
        int32_t l_1308 = 0xE3B9896BL;
        int32_t l_1313 = 0xF22D4127L;
        struct S0 l_1355 = {18446744073709551615UL,0x53L,0x32D2L,8UL,2L};
        int32_t ****l_1361[8][10] = {{&l_1089,&g_1258,&l_1089,&l_1089,&l_1089,&l_1089,&l_1089,&l_1089,(void*)0,&g_1258},{&g_1258,&g_1258,(void*)0,&l_1089,&g_1258,(void*)0,&l_1089,&l_1089,&l_1089,(void*)0},{&l_1089,&l_1089,&l_1089,&l_1089,&l_1089,(void*)0,&l_1089,(void*)0,&l_1089,&l_1089},{&g_1258,(void*)0,&g_1258,(void*)0,&l_1089,&l_1089,&l_1089,&l_1089,&g_1258,&l_1089},{&l_1089,(void*)0,&l_1089,&l_1089,&l_1089,(void*)0,(void*)0,&g_1258,&g_1258,(void*)0},{(void*)0,&g_1258,&g_1258,&g_1258,&g_1258,(void*)0,(void*)0,&l_1089,&g_1258,&g_1258},{&g_1258,&g_1258,(void*)0,&l_1089,&l_1089,(void*)0,&l_1089,&l_1089,&g_1258,(void*)0},{&g_1258,(void*)0,&g_1258,&l_1089,&g_1258,&l_1089,&g_1258,&l_1089,&g_1258,&l_1089}};
        int32_t *****l_1360 = &l_1361[7][4];
        const uint8_t ****l_1382 = (void*)0;
        uint64_t *****l_1435 = &g_1406[1][0];
        uint64_t *****l_1436 = &g_1406[1][0];
        int8_t l_1454 = 1L;
        int16_t l_1459[7][2][2] = {{{1L,0xA739L},{(-1L),1L}},{{0xD4F8L,0xD4F8L},{0xD4F8L,1L}},{{(-1L),0xA739L},{1L,0xA739L}},{{(-1L),1L},{0xD4F8L,0xD4F8L}},{{0xD4F8L,1L},{(-1L),0xA739L}},{{1L,0xA739L},{(-1L),1L}},{{0xD4F8L,0xD4F8L},{0xD4F8L,1L}}};
        uint8_t l_1460 = 0UL;
        int8_t l_1522[8] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
        int8_t l_1596 = 0x99L;
        uint8_t * const l_1638 = &g_1639[0];
        uint8_t * const *l_1637[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint8_t * const **l_1636 = &l_1637[7];
        uint8_t * const ***l_1635 = &l_1636;
        uint32_t l_1645 = 0x57F163EDL;
        const int32_t l_1659 = 1L;
        int8_t l_1719 = 0xB8L;
        int8_t l_1724 = (-1L);
        uint8_t l_1750 = 0xB8L;
        uint32_t l_1760 = 0x00127D84L;
        uint32_t l_1764 = 1UL;
        int i, j, k;
    }
    return (*g_717);
}


/* ------------------------------------------ */
/* 
 * reads : g_26
 * writes: g_8 g_380 g_1088
 */
static int32_t * func_2(int32_t * p_3, int32_t * p_4, struct S0  p_5, const int32_t * p_6)
{ /* block id: 531 */
    int32_t *l_1077[2][4][5] = {{{(void*)0,&g_380[8],(void*)0,(void*)0,(void*)0},{&g_380[1],&g_380[3],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_380[3],&g_380[3],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_8}},{{&g_380[8],(void*)0,(void*)0,&g_8,&g_380[3]},{&g_8,(void*)0,(void*)0,&g_8,&g_8},{&g_380[8],&g_380[3],&g_8,&g_380[9],&g_8},{(void*)0,&g_380[8],&g_380[3],(void*)0,&g_380[3]}}};
    int i, j, k;
    (*p_4) = (safe_lshift_func_uint16_t_u_s_unsafe_macro/*8*//* ___SAFE__OP */(g_26, 5));
    return l_1077[0][0][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_97 g_642 g_8 g_380 g_385.f2 g_385.f4 g_96 g_1088 g_350
 * writes: g_642 g_998.f4 g_8 g_380 g_385.f4 g_1088 g_350
 */
static int32_t * func_9(uint32_t  p_10, int32_t * p_11, int64_t  p_12, int32_t * p_13)
{ /* block id: 508 */
    int32_t *l_1048[7][1] = {{&g_380[3]},{&g_8},{&g_380[3]},{&g_8},{&g_380[3]},{&g_8},{&g_380[3]}};
    int32_t **l_1049 = &g_642;
    int16_t *l_1050 = &g_998.f4;
    int32_t ***l_1054 = &l_1049;
    int32_t ****l_1053 = &l_1054;
    int32_t ****l_1058 = (void*)0;
    int32_t *****l_1057 = &l_1058;
    int32_t *****l_1059 = (void*)0;
    int32_t ****l_1060 = &l_1054;
    int32_t ****l_1062 = &l_1054;
    int32_t *****l_1061 = &l_1062;
    uint8_t l_1063 = 5UL;
    uint64_t l_1069 = 0UL;
    int i, j;
    (*l_1049) = l_1048[4][0];
    if (((*g_642) = (((*l_1050) = ((void*)0 != &g_720)) != (safe_mul_func_uint8_t_u_u_unsafe_macro/*9*//* ___SAFE__OP */(((l_1053 == ((safe_mod_func_uint16_t_u_u_unsafe_macro/*10*//* ___SAFE__OP */(g_97, (p_10 | (***l_1054)))) , ((*l_1061) = (l_1060 = ((*l_1057) = &l_1054))))) > g_385.f2), ((l_1063 , (***l_1054)) , p_12))))))
    { /* block id: 515 */
        return (****l_1061);
    }
    else
    { /* block id: 517 */
        int32_t l_1064 = 0x42333C92L;
        int16_t l_1065[5][8] = {{9L,0xA32AL,0x59B9L,(-1L),(-7L),(-1L),(-7L),(-1L)},{7L,0x5235L,7L,(-5L),(-1L),(-1L),0x59B9L,0x59B9L},{0x59B9L,0xA32AL,9L,9L,0xA32AL,0x59B9L,(-1L),(-7L)},{0x59B9L,0x9801L,(-3L),0xA32AL,(-1L),0xA32AL,(-3L),0x9801L},{7L,(-3L),(-1L),0xA32AL,(-7L),(-5L),(-5L),(-7L)}};
        int32_t l_1066 = 0xA4438731L;
        int32_t l_1067 = 0x6C47885DL;
        int32_t l_1068[7] = {4L,1L,4L,4L,1L,4L,4L};
        int i, j;
        l_1069--;
        for (p_10 = 7; (p_10 >= 23); p_10 = safe_add_func_int8_t_s_s_unsafe_macro/*11*//* ___SAFE__OP */(p_10, 5))
        { /* block id: 521 */
            for (g_385.f4 = 4; (g_385.f4 >= 0); g_385.f4 -= 1)
            { /* block id: 524 */
                int i;
                (*p_11) &= g_96[g_385.f4];
                (***l_1054) |= (-1L);
            }
        }
        return p_11;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_356 g_308 g_719 g_720 g_998.f4 g_642 g_717 g_89
 * writes: g_308 g_998.f4 g_8 g_380
 */
static uint32_t  func_14(int32_t * p_15, const uint16_t  p_16)
{ /* block id: 501 */
    uint32_t l_1034 = 0xE3AB8C11L;
    uint64_t l_1043 = 0UL;
    uint16_t *l_1044[2][7] = {{&g_814,&g_814,&g_814,&g_814,&g_814,&g_814,&g_814},{&g_377[0],(void*)0,&g_377[0],(void*)0,&g_377[0],(void*)0,&g_377[0]}};
    int32_t l_1045 = 8L;
    uint8_t *l_1046 = (void*)0;
    int16_t *l_1047 = &g_998.f4;
    int i, j;
    (*g_642) = ((((*l_1047) &= (safe_rshift_func_uint32_t_u_u_unsafe_macro/*12*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u_unsafe_macro/*13*//* ___SAFE__OP */((safe_lshift_func_uint16_t_u_u(l_1034, 12)), (safe_rshift_func_uint8_t_u_s_unsafe_macro/*15*//* ___SAFE__OP */(((safe_lshift_func_int32_t_s_u(2L, (safe_sub_func_uint32_t_u_u_unsafe_macro/*17*//* ___SAFE__OP */(l_1034, ((safe_sub_func_int8_t_s_s_unsafe_macro/*18*//* ___SAFE__OP */(((l_1045 |= (l_1043 = p_16)) | (((*g_356) = (*g_356)) == l_1046)), ((void*)0 != (*g_719)))) != l_1034))))) ^ l_1034), 7)))), 4))) || l_1043) , (*p_15));
    return (*g_717);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_17(int16_t  p_18, int32_t  p_19, int32_t  p_20, int16_t  p_21)
{ /* block id: 499 */
    uint8_t l_1027[5];
    int i;
    for (i = 0; i < 5; i++)
        l_1027[i] = 252UL;
    return l_1027[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_842.f0 g_642 g_356 g_308 g_166 g_208 g_282.f4 g_717 g_89 g_716 g_432 g_433 g_381 g_842 g_659 g_23 g_92 g_8 g_630 g_641 g_380 g_122 g_385.f1 g_124 g_282.f3 g_263 g_480 g_481 g_998.f3
 * writes: g_842.f0 g_8 g_380 g_166 g_349 g_350 g_95 g_176 g_842.f1 g_89 g_922 g_26 g_208 g_122 g_500 g_428 g_96 g_630 g_92 g_23 g_160 g_153 g_481
 */
static uint16_t  func_27(const uint32_t  p_28, uint16_t  p_29, uint16_t  p_30, uint32_t  p_31, struct S0  p_32)
{ /* block id: 414 */
    uint64_t *l_844[3][4] = {{&g_208,&g_208,&g_208,&g_208},{&g_208,&g_208,&g_208,&g_208},{&g_208,&g_208,&g_208,&g_208}};
    uint64_t **l_843 = &l_844[1][2];
    int32_t l_845 = 0x2CC0EB5FL;
    int16_t *l_975 = &g_842.f4;
    int32_t l_1010[10] = {0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL,0xFB626FADL};
    int i, j;
lbl_925:
    l_845 = (l_843 != &l_844[1][0]);
    for (g_842.f0 = (-10); (g_842.f0 < 16); g_842.f0 = safe_add_func_int32_t_s_s_unsafe_macro/*19*//* ___SAFE__OP */(g_842.f0, 1))
    { /* block id: 418 */
        uint64_t l_853 = 1UL;
        uint16_t *l_854 = (void*)0;
        uint16_t *l_855[3][3][2] = {{{&g_814,&g_814},{&g_814,&g_814},{&g_814,&g_814}},{{&g_814,&g_814},{&g_814,&g_814},{&g_814,&g_814}},{{&g_814,&g_814},{&g_814,&g_814},{&g_814,&g_814}}};
        int32_t l_867 = 0x11E68745L;
        int32_t l_888[9];
        int32_t *l_926[6] = {&l_845,&l_845,&l_845,&l_845,&l_845,&l_845};
        uint8_t **l_932 = &g_308;
        int8_t l_945 = 7L;
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_888[i] = 0L;
        if (((safe_unary_minus_func_int8_t_s_unsafe_macro/*20*//* ___SAFE__OP */(((((safe_mul_func_uint16_t_u_u_unsafe_macro/*21*//* ___SAFE__OP */((safe_mod_func_uint16_t_u_u_unsafe_macro/*22*//* ___SAFE__OP */((p_30 = l_853), l_845)), (safe_sub_func_uint8_t_u_u_unsafe_macro/*23*//* ___SAFE__OP */(p_32.f1, (p_31 > (safe_add_func_int32_t_s_s_unsafe_macro/*24*//* ___SAFE__OP */((l_867 = ((safe_mod_func_uint16_t_u_u_unsafe_macro/*25*//* ___SAFE__OP */(0x5F9BL, (safe_mul_func_int8_t_s_s_unsafe_macro/*26*//* ___SAFE__OP */(p_32.f4, (l_853 != (+p_32.f0)))))) ^ (safe_mul_func_uint64_t_u_u_unsafe_macro/*27*//* ___SAFE__OP */(p_32.f3, p_32.f1)))), l_845))))))) <= 0x381C143AC572380BLL) , &g_433) == &g_433))) && l_845))
        { /* block id: 421 */
            return l_853;
        }
        else
        { /* block id: 423 */
            int8_t l_871[1];
            uint32_t *l_878 = &g_349;
            int32_t *l_887[10][3] = {{(void*)0,&l_867,(void*)0},{&g_446,&l_867,&l_867},{&g_446,&g_446,&l_867},{(void*)0,&l_867,&l_867},{&l_867,&l_867,&l_867},{(void*)0,&l_867,(void*)0},{&g_446,&l_867,&l_867},{&g_446,&g_446,&l_867},{(void*)0,&l_867,&l_867},{&l_867,&l_867,&l_867}};
            int8_t *l_889[5][6] = {{&g_176,&g_176,&l_871[0],&g_176,&g_176,&l_871[0]},{&g_176,&g_176,&l_871[0],&g_176,&g_176,&l_871[0]},{&g_176,&g_176,&l_871[0],&g_176,&g_176,&l_871[0]},{&g_176,&g_176,&l_871[0],&g_176,&g_176,&l_871[0]},{&g_176,&g_176,&l_871[0],&g_176,&g_176,&l_871[0]}};
            int16_t l_924 = (-10L);
            const uint32_t l_947[7][6] = {{1UL,1UL,0xCB4EC600L,5UL,0xFDAB9451L,1UL},{0x0A00F048L,0x45978141L,4294967295UL,0x6A055185L,0UL,0xCB4EC600L},{0xE6B0722AL,0x0A00F048L,4294967295UL,1UL,1UL,1UL},{0xCB4EC600L,1UL,0xCB4EC600L,0UL,0xE8A2C97BL,0x5607AFD9L},{0UL,0xE8A2C97BL,0x5607AFD9L,0UL,0x95D75621L,0xFDAB9451L},{5UL,0x5607AFD9L,1UL,0UL,0UL,0UL},{0UL,1UL,1UL,0UL,0x0A00F048L,0x45978141L}};
            int i, j;
            for (i = 0; i < 1; i++)
                l_871[i] = (-1L);
            if ((safe_unary_minus_func_int32_t_s_unsafe_macro/*28*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u_unsafe_macro/*29*//* ___SAFE__OP */(l_871[0], ((safe_div_func_int8_t_s_s_unsafe_macro/*30*//* ___SAFE__OP */((g_176 = (g_842.f0 || (safe_mul_func_int16_t_s_s_unsafe_macro/*31*//* ___SAFE__OP */((p_31 < (safe_div_func_int64_t_s_s_unsafe_macro/*32*//* ___SAFE__OP */((((((*g_642) = (-6L)) <= ((((g_350[4][5][1] = ((*l_878) = (((**g_356) = 4UL) < l_871[0]))) , (*g_308)) , (l_888[7] |= (safe_lshift_func_uint64_t_u_u_unsafe_macro/*33*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*34*//* ___SAFE__OP */(((g_95[3][0][1] = ((safe_mul_func_int32_t_s_s_unsafe_macro/*35*//* ___SAFE__OP */((((((safe_mul_func_uint16_t_u_u_unsafe_macro/*36*//* ___SAFE__OP */(l_871[0], p_32.f2)) ^ p_32.f2) , (-4L)) != l_845) > p_32.f2), 1L)) || 4294967289UL)) | g_208), l_867)), g_282.f4)))) != (*g_717))) < p_32.f3) < p_30), 18446744073709551615UL))), 65531UL)))), p_32.f0)) && p_30))))))
            { /* block id: 431 */
                uint16_t l_901 = 65532UL;
                int64_t *l_929[4][2];
                uint8_t *l_930 = &g_385.f1;
                uint8_t *l_931[9][4] = {{&g_166[5][3][1],&g_385.f1,&g_842.f1,&g_385.f1},{&g_385.f1,(void*)0,&g_385.f1,&g_385.f1},{&g_385.f1,&g_385.f1,(void*)0,(void*)0},{(void*)0,(void*)0,&g_842.f1,&g_166[5][3][1]},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_385.f1,&g_166[5][3][1],&g_385.f1,(void*)0},{&g_385.f1,&g_166[5][3][1],&g_842.f1,(void*)0},{&g_166[5][3][1],(void*)0,(void*)0,&g_166[5][3][1]},{&g_385.f1,(void*)0,(void*)0,(void*)0}};
                int i, j;
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_929[i][j] = &g_95[3][0][1];
                }
                for (g_842.f1 = 29; (g_842.f1 != 13); g_842.f1 = safe_sub_func_int16_t_s_s_unsafe_macro/*37*//* ___SAFE__OP */(g_842.f1, 8))
                { /* block id: 434 */
                    uint32_t **l_921[8][9][3] = {{{(void*)0,(void*)0,&l_878},{&l_878,(void*)0,&l_878},{(void*)0,(void*)0,&l_878},{&l_878,(void*)0,&l_878},{(void*)0,(void*)0,&l_878},{&l_878,(void*)0,&l_878},{(void*)0,(void*)0,&l_878},{&l_878,(void*)0,&l_878},{(void*)0,(void*)0,&l_878}},{{&l_878,(void*)0,&l_878},{(void*)0,(void*)0,&l_878},{&l_878,(void*)0,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878}},{{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0}},{{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878}},{{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0}},{{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878}},{{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0}},{{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878},{&l_878,&l_878,(void*)0},{&l_878,&l_878,&l_878}}};
                    int16_t *l_923 = &g_122;
                    int i, j, k;
                    l_924 ^= (((**g_716) = p_32.f4) ^ (((safe_div_func_uint64_t_u_u_unsafe_macro/*38*//* ___SAFE__OP */(0x92E96D92F86063D1LL, (safe_mul_func_uint16_t_u_u_unsafe_macro/*39*//* ___SAFE__OP */((((*l_923) = ((**g_432) < (safe_rshift_func_int16_t_s_u_unsafe_macro/*40*//* ___SAFE__OP */((g_842 , (0x87EEL && ((safe_unary_minus_func_int32_t_s_unsafe_macro/*41*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*42*//* ___SAFE__OP */(((++l_901) && (safe_mod_func_uint64_t_u_u_unsafe_macro/*43*//* ___SAFE__OP */(((**l_843) = ((((((!0x2D53L) == ((safe_lshift_func_uint64_t_u_u_unsafe_macro/*44*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s_unsafe_macro/*45*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*46*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*47*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s_unsafe_macro/*48*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s_unsafe_macro/*49*//* ___SAFE__OP */(((5L <= (((safe_mod_func_int64_t_s_s_unsafe_macro/*50*//* ___SAFE__OP */(((g_922[4] = &g_349) == &g_350[0][2][1]), (-2L))) == g_659[0]) > l_845)) > p_32.f2), 0x9DDFA79DC0270D49LL)), 54)), g_23)), l_867)), 2)), 60)) , l_845)) ^ 1UL) && g_92) , 0xA1AE8C21L) >= l_901)), 0x107C7115E49C0251LL))), 4L)))) ^ 65526UL))), 1)))) == g_8), p_32.f1)))) < g_842.f2) < 0x03L));
                    if (l_845)
                        goto lbl_925;
                }
                for (g_500 = 0; g_500 < 10; g_500 += 1)
                {
                    g_428[g_500] = (void*)0;
                }
                l_926[0] = &l_845;
                if ((((**g_432) > (safe_add_func_int64_t_s_s_unsafe_macro/*51*//* ___SAFE__OP */((g_96[5] = (g_95[0][7][0] = g_23)), l_901))) > (((((l_930 != (l_931[7][3] = l_931[7][3])) == p_32.f3) , l_932) == (void*)0) | (g_176 = (p_28 || (*g_308))))))
                { /* block id: 449 */
                    uint16_t l_946 = 0x5E98L;
                    int32_t l_948 = 1L;
                    for (g_630 = 0; (g_630 <= 35); ++g_630)
                    { /* block id: 452 */
                        l_948 = ((p_30 || ((safe_mul_func_int64_t_s_s_unsafe_macro/*52*//* ___SAFE__OP */(p_30, (g_166[4][7][3] , ((((safe_rshift_func_int16_t_s_u_unsafe_macro/*53*//* ___SAFE__OP */((((p_31 > p_32.f4) ^ ((**g_641) <= ((((safe_mod_func_int32_t_s_s_unsafe_macro/*54*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s_unsafe_macro/*55*//* ___SAFE__OP */((((g_122 ^= g_8) , p_28) & (l_945 , (**g_716))), l_946)) , l_947[1][2]), p_30)) | l_901) , (void*)0) != &g_717))) , p_30), 5)) && l_845) && 4L) != g_8)))) < (-1L))) & 0xE5L);
                        if (p_29)
                            break;
                        if (l_946)
                            goto lbl_925;
                    }
                }
                else
                { /* block id: 458 */
                    return p_32.f4;
                }
            }
            else
            { /* block id: 461 */
                uint16_t l_990 = 0x3DB7L;
                int32_t l_1007 = (-9L);
                int32_t l_1018[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                uint32_t l_1021 = 18446744073709551615UL;
                int i;
                for (g_92 = 12; (g_92 != 12); ++g_92)
                { /* block id: 464 */
                    int16_t l_951 = 0xB14CL;
                    int32_t l_988 = (-10L);
                    int32_t l_989 = 0x1A99F5F3L;
                    struct S0 *l_997 = &g_998;
                    int32_t l_1011 = 0x1C79BE03L;
                    int32_t l_1012 = (-1L);
                    int32_t l_1013 = 0x892F70A5L;
                    int32_t l_1015 = 0L;
                    int32_t l_1016 = 0x7D4CFDF5L;
                    int32_t l_1017 = 1L;
                    int32_t l_1019 = (-1L);
                    int32_t l_1020[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1020[i] = 0L;
                    l_951 = l_845;
                    for (g_23 = 0; (g_23 <= 13); ++g_23)
                    { /* block id: 468 */
                        uint8_t l_956 = 0x79L;
                        int32_t l_986[9] = {0x85ACAB8CL,0x52C62A5AL,0x85ACAB8CL,0x52C62A5AL,0x85ACAB8CL,0x52C62A5AL,0x85ACAB8CL,0x52C62A5AL,0x85ACAB8CL};
                        int32_t **l_987 = (void*)0;
                        int i;
                        l_986[0] |= ((g_95[3][0][1] = (safe_lshift_func_int8_t_s_u_unsafe_macro/*56*//* ___SAFE__OP */(l_956, (safe_div_func_int32_t_s_s_unsafe_macro/*57*//* ___SAFE__OP */(p_28, ((**g_716) = p_32.f2)))))) && (safe_mod_func_uint64_t_u_u_unsafe_macro/*58*//* ___SAFE__OP */(((((g_385.f1 | ((safe_mul_func_uint32_t_u_u_unsafe_macro/*59*//* ___SAFE__OP */((--(**g_716)), (safe_lshift_func_uint32_t_u_u_unsafe_macro/*60*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u_unsafe_macro/*61*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u_unsafe_macro/*62*//* ___SAFE__OP */((g_124[3][3] ^ ((((safe_div_func_uint64_t_u_u_unsafe_macro/*63*//* ___SAFE__OP */(((**l_843) = (safe_lshift_func_uint16_t_u_s_unsafe_macro/*64*//* ___SAFE__OP */((((-1L) | (((((l_975 != l_855[1][1][1]) , (((safe_sub_func_uint32_t_u_u_unsafe_macro/*65*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*66*//* ___SAFE__OP */(((safe_unary_minus_func_uint64_t_u_unsafe_macro/*67*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s_unsafe_macro/*68*//* ___SAFE__OP */((safe_add_func_int32_t_s_s_unsafe_macro/*69*//* ___SAFE__OP */((safe_unary_minus_func_int16_t_s_unsafe_macro/*70*//* ___SAFE__OP */(p_29)), l_845)), 0x8B31L)))) ^ p_31), (*g_433))), p_28)) == p_29) == (**g_356))) || p_29) , p_30) || l_956)) && 65535UL), 7))), g_842.f0)) || g_282.f3) == p_30) > (-7L))), p_32.f2)), l_956)), 21)))) , l_956)) < 0x60L) || 0x1733CB08700A74EFLL) < (*g_308)), 0xA3588EFB98FE9FECLL)));
                        (*g_263) = &l_867;
                        ++l_990;
                    }
                    for (g_153 = 0; (g_153 == (-18)); g_153 = safe_sub_func_int64_t_s_s_unsafe_macro/*71*//* ___SAFE__OP */(g_153, 5))
                    { /* block id: 479 */
                        struct S0 **l_995 = (void*)0;
                        struct S0 **l_996[8];
                        int32_t l_1008 = 0x7C579B24L;
                        int32_t l_1009 = 2L;
                        int32_t l_1014[2][3];
                        int i, j;
                        for (i = 0; i < 8; i++)
                            l_996[i] = &g_481;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_1014[i][j] = 0x568AB986L;
                        }
                        l_845 &= ((((((*g_480) = (*g_480)) != (l_997 = &p_32)) && (safe_mod_func_int8_t_s_s_unsafe_macro/*72*//* ___SAFE__OP */(g_998.f3, (safe_lshift_func_uint64_t_u_u_unsafe_macro/*73*//* ___SAFE__OP */(((safe_add_func_int64_t_s_s_unsafe_macro/*74*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u_unsafe_macro/*75*//* ___SAFE__OP */(65535UL, (l_990 , (((l_1007 = ((**g_432) >= 1UL)) || 0xA6BBL) && (((&g_475 != (void*)0) < 1L) < p_32.f3))))), l_988)) > (**g_716)), 55))))) != p_32.f2) <= p_32.f3);
                        l_926[5] = &l_988;
                        ++l_1021;
                    }
                }
                for (l_1007 = 0; (l_1007 == 15); l_1007 = safe_add_func_uint64_t_u_u_unsafe_macro/*76*//* ___SAFE__OP */(l_1007, 5))
                { /* block id: 490 */
                    return p_32.f1;
                }
                if (p_32.f0)
                    break;
            }
            return g_166[5][4][1];
        }
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_23 g_85 g_89 g_26 g_96 g_97 g_99 g_112 g_95 g_124 g_127 g_261 g_160 g_166 g_92 g_282.f1 g_350 g_380 g_381 g_190 g_385.f3 g_176 g_355 g_356 g_308 g_428 g_432 g_377 g_446 g_208 g_480 g_385.f0 g_385.f4 g_500 g_429 g_385.f1 g_159 g_282.f4 g_385.f2 g_608 g_282.f3 g_641
 * writes: g_85 g_89 g_26 g_92 g_95 g_97 g_99 g_112 g_122 g_124 g_127 g_160 g_8 g_380 g_190 g_385.f3 g_176 g_428 g_377 g_385.f1 g_475 g_481 g_23 g_430 g_500 g_166 g_385.f0 g_208 g_446 g_608 g_630 g_642
 */
static uint8_t  func_39(uint64_t * p_40, int16_t  p_41)
{ /* block id: 3 */
    uint32_t l_45 = 0UL;
    uint32_t l_46 = 0x01E07AD4L;
    int64_t l_57 = 0x3024A13297949028LL;
    int8_t l_58 = 0L;
    int32_t *l_59 = &g_8;
    int32_t l_403 = (-1L);
    int32_t l_408[4] = {(-3L),(-3L),(-3L),(-3L)};
    uint32_t *l_468 = &g_92;
    uint64_t *l_529 = &g_385.f0;
    struct S0 **l_565 = &g_481;
    uint8_t ***l_577 = &g_356;
    int32_t * const l_588 = &g_8;
    int32_t **l_629 = &g_160;
    int32_t ***l_628 = &l_629;
    int32_t ****l_627 = &l_628;
    int32_t *l_635 = &g_446;
    int16_t l_673 = 0x70BAL;
    uint64_t l_730[9][10] = {{0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL},{3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL},{0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL},{0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL},{3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL},{0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL},{0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL},{3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL,0x2F6C7ED2D375656DLL,3UL,3UL},{0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL,0x2F6C7ED2D375656DLL,1UL,0x2F6C7ED2D375656DLL}};
    struct S0 l_795 = {0x926FA92594432524LL,0UL,0x1DA9L,249UL,0xEDC1L};
    int8_t l_813[4][6][8] = {{{(-5L),0xEBL,0x93L,0L,(-1L),(-1L),0L,0x93L},{0x82L,0x82L,0x1BL,(-1L),(-4L),0x19L,5L,0xC6L},{0x61L,0x3AL,0x64L,0x93L,(-5L),1L,0x55L,0xC6L},{0x3AL,(-1L),1L,(-1L),0x64L,1L,(-4L),0x93L},{0x85L,0x40L,0x49L,0L,0x82L,0xD1L,0x82L,0L},{0x64L,5L,0x64L,0L,0L,0x61L,1L,5L}},{{5L,1L,0xEBL,0x85L,1L,1L,0L,0x55L},{5L,(-4L),(-1L),0x40L,0L,0xDFL,0x3AL,(-4L)},{0x64L,0x3AL,0x61L,1L,0x82L,0L,0L,0x82L},{0x85L,0x55L,0x55L,0x85L,0x64L,(-1L),0xC6L,1L},{0x3AL,0x85L,0xD1L,0xC6L,(-5L),0x1BL,0x3AL,0L},{0x61L,0x85L,9L,0x69L,0x61L,0xD1L,0x69L,0xD6L}},{{0L,0x19L,0xEFL,1L,0xD1L,(-1L),0x64L,(-1L)},{1L,0xD6L,0x40L,0xD6L,1L,0x85L,0L,0x93L},{9L,0x61L,0x5CL,0xDFL,1L,0x5CL,0xD1L,0xD6L},{0x55L,0x1BL,0x5CL,(-1L),0x19L,0x49L,0L,0x69L},{1L,0x29L,0x40L,0x93L,(-1L),5L,0x64L,0x64L},{0x5CL,0xEBL,0xEFL,0xEFL,0xEBL,0x5CL,0x69L,0L}},{{0x64L,0xD1L,9L,0xEBL,0x69L,0x1BL,0xD6L,0xD1L},{1L,0xD6L,5L,0xEBL,0L,0x3AL,0x93L,0L},{0xEFL,0L,0x19L,0xEFL,1L,0xD1L,(-1L),0x64L},{0xD6L,0xEFL,0x49L,0x93L,0x49L,0xEFL,0xD6L,0x69L},{1L,0x55L,5L,(-1L),0x61L,(-5L),(-1L),0xD6L},{0x19L,0L,0xEFL,0xDFL,0x61L,(-1L),0x5CL,0x93L}}};
    int i, j, k;
    if ((((((safe_div_func_int8_t_s_s_unsafe_macro/*77*//* ___SAFE__OP */(((l_45 & l_46) < (safe_mod_func_uint32_t_u_u_unsafe_macro/*78*//* ___SAFE__OP */(g_8, func_49((safe_mul_func_int64_t_s_s_unsafe_macro/*79*//* ___SAFE__OP */(((l_57 == (p_41 | l_58)) , (g_8 >= ((255UL > (l_58 <= 0L)) <= l_45))), (-6L))), l_59, p_41, (*l_59), g_23)))), g_166[4][7][3])) == (*l_59)) <= (*l_59)) && (*l_59)) <= (*l_59)))
    { /* block id: 150 */
        struct S0 *l_386 = (void*)0;
        int32_t l_407 = 0x077F8227L;
        int32_t l_409[10][1][3] = {{{0x08C9777DL,(-8L),(-8L)}},{{0x9F7F49F8L,0x2F150483L,0xCEE45C02L}},{{0x08C9777DL,(-8L),(-8L)}},{{0x9F7F49F8L,0x2F150483L,0xCEE45C02L}},{{0x08C9777DL,(-8L),(-8L)}},{{0x9F7F49F8L,0x2F150483L,0xCEE45C02L}},{{0x08C9777DL,(-8L),(-8L)}},{{0x9F7F49F8L,0x2F150483L,0xCEE45C02L}},{{0x08C9777DL,(-8L),(-8L)}},{{0x9F7F49F8L,0x2F150483L,0xCEE45C02L}}};
        int i, j, k;
        for (g_92 = (-13); (g_92 > 53); ++g_92)
        { /* block id: 153 */
            int32_t *l_361 = (void*)0;
            uint16_t *l_376 = &g_377[0];
            for (g_99 = (-25); (g_99 < 1); g_99++)
            { /* block id: 156 */
                for (g_112 = 0; g_112 < 6; g_112 += 1)
                {
                    for (g_26 = 0; g_26 < 6; g_26 += 1)
                    {
                        g_124[g_112][g_26] = 9L;
                    }
                }
                for (g_89 = 0; (g_89 <= 3); g_89 += 1)
                { /* block id: 160 */
                    int32_t **l_362 = &g_160;
                    uint16_t *l_367 = &g_85;
                    int32_t *l_379 = &g_380[3];
                    int i, j, k;
                    if (g_166[(g_89 + 1)][g_89][g_89])
                        break;
                    (*l_362) = l_361;
                    (*l_379) ^= (safe_div_func_uint64_t_u_u_unsafe_macro/*80*//* ___SAFE__OP */((*p_40), ((((safe_add_func_uint64_t_u_u_unsafe_macro/*81*//* ___SAFE__OP */((((++(*l_367)) || (safe_rshift_func_uint16_t_u_s_unsafe_macro/*82*//* ___SAFE__OP */((g_282.f1 , 1UL), 2))) < (safe_mod_func_int8_t_s_s_unsafe_macro/*83*//* ___SAFE__OP */((g_350[2][3][0] <= 0xD2A1L), p_41))), ((safe_rshift_func_int32_t_s_s_unsafe_macro/*84*//* ___SAFE__OP */(((void*)0 != l_376), ((*l_59) &= (safe_unary_minus_func_uint16_t_u_unsafe_macro/*85*//* ___SAFE__OP */(p_41))))) == p_41))) > p_41) & 0x21A6010EL) || (*l_59))));
                    (*l_59) ^= 0L;
                }
            }
            if (g_381)
                continue;
        }
        for (l_58 = 0; (l_58 >= (-17)); l_58 = safe_sub_func_int16_t_s_s_unsafe_macro/*86*//* ___SAFE__OP */(l_58, 4))
        { /* block id: 173 */
            struct S0 *l_384 = &g_385;
            int32_t l_404 = 0x91311902L;
            int32_t l_405 = 2L;
            int32_t l_406[5] = {0L,0L,0L,0L,0L};
            int i;
            l_386 = l_384;
            for (g_190 = 0; (g_190 <= 48); ++g_190)
            { /* block id: 177 */
                int32_t *l_395 = &g_380[3];
                int32_t *l_396 = &g_380[3];
                int32_t *l_397 = &g_380[3];
                int32_t *l_398 = &g_8;
                int32_t *l_399 = (void*)0;
                int32_t *l_400 = (void*)0;
                int32_t l_401 = 2L;
                int32_t *l_402[8][1] = {{&l_401},{&l_401},{&l_401},{&l_401},{&l_401},{&l_401},{&l_401},{&l_401}};
                int32_t l_410 = 7L;
                uint32_t l_411[1][6] = {{0UL,0UL,0UL,0UL,0UL,0UL}};
                int i, j;
                for (g_385.f3 = 0; (g_385.f3 >= 52); g_385.f3 = safe_add_func_int32_t_s_s_unsafe_macro/*87*//* ___SAFE__OP */(g_385.f3, 2))
                { /* block id: 180 */
                    (*l_59) = ((void*)0 != p_40);
                }
                for (l_46 = (-5); (l_46 > 4); l_46++)
                { /* block id: 185 */
                    for (g_176 = 0; (g_176 < (-10)); g_176 = safe_sub_func_int64_t_s_s_unsafe_macro/*88*//* ___SAFE__OP */(g_176, 8))
                    { /* block id: 188 */
                        return p_41;
                    }
                    (*l_59) = p_41;
                }
                l_411[0][4]--;
            }
            return (***g_355);
        }
    }
    else
    { /* block id: 197 */
        int64_t l_434 = 0x26ED60B8108AF6CCLL;
        int32_t l_439 = 0x64EAC22BL;
        uint64_t l_440 = 5UL;
        int32_t *l_441 = &l_439;
        uint8_t ***l_461 = (void*)0;
        const uint8_t *l_465 = &g_166[4][7][3];
        const uint8_t **l_464 = &l_465;
        const uint8_t *** const l_463[1][6][5] = {{{&l_464,&l_464,&l_464,&l_464,&l_464},{&l_464,&l_464,&l_464,&l_464,&l_464},{&l_464,&l_464,&l_464,&l_464,&l_464},{&l_464,&l_464,&l_464,&l_464,&l_464},{&l_464,&l_464,&l_464,&l_464,&l_464},{&l_464,&l_464,&l_464,&l_464,&l_464}}};
        uint32_t *l_467[2][5][2] = {{{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92}},{{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92},{&g_92,&g_92}}};
        int32_t ****l_506 = (void*)0;
        int32_t *****l_505 = &l_506;
        int64_t *l_516[8][3] = {{(void*)0,&g_96[5],&l_434},{&g_96[5],&g_96[5],&g_96[5]},{&g_99,(void*)0,&l_434},{&g_96[5],&g_96[5],&g_95[3][0][1]},{&g_96[5],(void*)0,(void*)0},{&g_95[3][0][1],&g_96[5],&g_96[3]},{&g_96[5],&g_96[5],&g_96[5]},{&g_96[5],&g_95[3][0][1],&g_96[3]}};
        int32_t *l_517 = &l_408[0];
        uint32_t l_528 = 0xAFF9587EL;
        int16_t *l_530 = &g_500;
        int32_t *l_531[9] = {&g_380[3],&g_380[3],&g_380[3],&g_380[3],&g_380[3],&g_380[3],&g_380[3],&g_380[3],&g_380[3]};
        int16_t l_532 = (-5L);
        struct S0 **l_580 = (void*)0;
        uint32_t **l_639 = &l_467[1][0][0];
        int32_t **l_640 = (void*)0;
        int i, j, k;
        for (g_112 = 0; (g_112 < 9); g_112++)
        { /* block id: 200 */
            int32_t **l_425 = (void*)0;
            int32_t ***l_424 = &l_425;
            int32_t ****l_426 = (void*)0;
            int32_t ****l_427 = &l_424;
            const int32_t ****l_431 = &g_428[7];
            uint16_t *l_435 = &g_377[0];
            uint16_t *l_438 = (void*)0;
            if (((safe_lshift_func_int8_t_s_s_unsafe_macro/*89*//* ___SAFE__OP */(((*l_59) = (*l_59)), 1)) , (((l_439 = (p_41 , (safe_div_func_uint16_t_u_u_unsafe_macro/*90*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u_unsafe_macro/*91*//* ___SAFE__OP */(((((*l_59) ^ (safe_lshift_func_int64_t_s_s_unsafe_macro/*92*//* ___SAFE__OP */((((*l_427) = l_424) == ((*l_431) = g_428[7])), ((g_432 == (void*)0) > ((((--(*l_435)) || g_127) ^ p_41) , (-3L)))))) , (*l_59)) | l_434), g_96[0])), p_41)))) , l_440) || (**g_261))))
            { /* block id: 206 */
                g_380[3] &= (**g_261);
                l_441 = &l_408[2];
                if (p_41)
                    continue;
            }
            else
            { /* block id: 210 */
                int32_t *l_442 = &g_380[4];
                int16_t *l_445 = &g_122;
                const uint8_t ** const *l_477 = &l_464;
                const uint8_t ** const **l_476[4] = {&l_477,&l_477,&l_477,&l_477};
                struct S0 * const l_479 = (void*)0;
                int i;
                (*l_442) ^= ((*g_160) = (*l_441));
                for (g_385.f1 = 0; (g_385.f1 <= 3); g_385.f1 += 1)
                { /* block id: 215 */
                    uint8_t ****l_462 = &l_461;
                    uint32_t *l_466 = &g_89;
                    int i;
                    if ((*l_442))
                        break;
                    if ((((safe_lshift_func_int32_t_s_s_unsafe_macro/*93*//* ___SAFE__OP */((l_445 == &p_41), 24)) == ((***g_355) < g_446)) | ((safe_mul_func_int64_t_s_s_unsafe_macro/*94*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*95*//* ___SAFE__OP */(p_41, (safe_div_func_uint32_t_u_u_unsafe_macro/*96*//* ___SAFE__OP */(((*l_466) = (safe_sub_func_int16_t_s_s_unsafe_macro/*97*//* ___SAFE__OP */((((safe_mul_func_int32_t_s_s_unsafe_macro/*98*//* ___SAFE__OP */(((&p_41 != (void*)0) != (++g_26)), (((safe_mul_func_uint8_t_u_u_unsafe_macro/*99*//* ___SAFE__OP */((((*l_462) = l_461) == l_463[0][0][2]), (*l_442))) ^ 0x1803L) | (*l_59)))) > 0x949BDD16L) , g_208), g_92))), 0x2F732053L)))), g_208)) ^ p_41)))
                    { /* block id: 220 */
                        (*g_160) = ((l_467[1][0][0] = l_441) != (p_41 , l_468));
                        return p_41;
                    }
                    else
                    { /* block id: 224 */
                        uint8_t *****l_473 = (void*)0;
                        uint8_t *****l_474[7];
                        int32_t l_478[8] = {0x86D7C754L,0x86D7C754L,0x86D7C754L,0x86D7C754L,0x86D7C754L,0x86D7C754L,0x86D7C754L,0x86D7C754L};
                        int i;
                        for (i = 0; i < 7; i++)
                            l_474[i] = (void*)0;
                        (*l_442) ^= p_41;
                        l_478[5] = (safe_lshift_func_int64_t_s_u_unsafe_macro/*100*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_u_unsafe_macro/*101*//* ___SAFE__OP */(1L, ((g_475 = &l_461) == l_476[1]))), 20));
                    }
                    (*g_480) = l_479;
                    for (g_99 = 0; (g_99 <= 3); g_99 += 1)
                    { /* block id: 232 */
                        return p_41;
                    }
                }
                for (g_26 = (-5); (g_26 != 40); g_26++)
                { /* block id: 238 */
                    int8_t *l_504[3];
                    int32_t *****l_507 = (void*)0;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_504[i] = &g_176;
                    (*l_59) |= (safe_rshift_func_uint8_t_u_u_unsafe_macro/*102*//* ___SAFE__OP */((safe_add_func_int16_t_s_s_unsafe_macro/*103*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*104*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*105*//* ___SAFE__OP */((***g_355), (g_176 = ((((safe_div_func_int16_t_s_s_unsafe_macro/*106*//* ___SAFE__OP */((((*p_40) = g_385.f0) == (safe_div_func_uint16_t_u_u_unsafe_macro/*107*//* ___SAFE__OP */(g_208, (safe_rshift_func_int64_t_s_u_unsafe_macro/*108*//* ___SAFE__OP */((((((safe_rshift_func_int64_t_s_s_unsafe_macro/*109*//* ___SAFE__OP */(g_385.f4, p_41)) , g_350[3][3][1]) , 0x7EB33500E2A8EBCELL) > (g_500 | (((!(safe_mod_func_int64_t_s_s_unsafe_macro/*110*//* ___SAFE__OP */(g_190, 0xFD44838A89A34895LL))) , 0x6F5BL) ^ p_41))) >= (*l_441)), 33))))), g_124[2][5])) > 4294967295UL) < g_350[0][7][1]) ^ g_124[1][5])))), (*l_441))), 0xE089L)), 6));
                    l_507 = l_505;
                }
                (***l_431) = &l_408[3];
            }
            if (p_41)
                continue;
        }
        l_532 = (l_403 = (g_380[0] = ((*l_59) = ((safe_lshift_func_uint8_t_u_s_unsafe_macro/*111*//* ___SAFE__OP */(((((0xE2L > ((*l_517) = (safe_mod_func_int64_t_s_s_unsafe_macro/*112*//* ___SAFE__OP */(1L, ((safe_div_func_int64_t_s_s_unsafe_macro/*113*//* ___SAFE__OP */((((*l_530) = (safe_lshift_func_int8_t_s_s_unsafe_macro/*114*//* ___SAFE__OP */(((-1L) && (((l_529 = func_65((l_516[6][2] = &l_434), l_517, (((safe_sub_func_uint8_t_u_u_unsafe_macro/*115*//* ___SAFE__OP */(((*l_517) < ((((*l_441) > ((((safe_mod_func_int8_t_s_s_unsafe_macro/*116*//* ___SAFE__OP */(((p_41 ^ ((safe_sub_func_int32_t_s_s_unsafe_macro/*117*//* ___SAFE__OP */((safe_div_func_int16_t_s_s_unsafe_macro/*118*//* ___SAFE__OP */((((((*l_468) = (&l_58 == (void*)0)) , (*l_59)) != l_528) & (-1L)), 65532UL)), p_41)) < g_99)) || 4294967295UL), g_23)) != (*g_308)) <= p_41) , (*l_517))) & p_41) <= 1UL)), 0UL)) || (*l_59)) || 0xC907L), g_99)) == &g_208) , 0x65867E60L)), p_41))) ^ p_41), g_112)) , g_385.f1))))) == 9L) ^ (**g_356)) , (**g_356)), 6)) , (**g_159)))));
        if ((safe_lshift_func_uint32_t_u_s_unsafe_macro/*119*//* ___SAFE__OP */(((*l_59) = (safe_div_func_uint64_t_u_u_unsafe_macro/*120*//* ___SAFE__OP */((g_385.f0 |= ((safe_mod_func_int8_t_s_s_unsafe_macro/*121*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u_unsafe_macro/*122*//* ___SAFE__OP */(p_41, (((p_41 == ((**g_356) = (safe_mul_func_int8_t_s_s_unsafe_macro/*123*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u_unsafe_macro/*124*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_u_unsafe_macro/*125*//* ___SAFE__OP */(g_208, (safe_rshift_func_uint32_t_u_s_unsafe_macro/*126*//* ___SAFE__OP */(1UL, 5)))) , (safe_mod_func_uint64_t_u_u_unsafe_macro/*127*//* ___SAFE__OP */(((((safe_unary_minus_func_int64_t_s_unsafe_macro/*128*//* ___SAFE__OP */(((((*l_517) = ((((((0UL || (*p_40)) , (g_23 == p_41)) == (((safe_sub_func_uint8_t_u_u_unsafe_macro/*129*//* ___SAFE__OP */((g_208 == 0x3A18CAA5387B9FA7LL), p_41)) <= 65535UL) & p_41)) <= p_41) , (*l_59)) && p_41)) == g_96[5]) ^ (-3L)))) , p_41) == g_282.f4) || (*l_517)), g_85))) , 0x84L), (*l_59))), g_85)))) > 0x11L) , 0x5CL))), p_41)) , 0x08AC81DB3B173A38LL)), 1UL))), p_41)))
        { /* block id: 261 */
            int32_t **l_554[4] = {&l_59,&l_59,&l_59,&l_59};
            uint32_t l_570 = 4294967295UL;
            struct S0 l_587 = {0x0F311822A2B11087LL,1UL,3L,0UL,0xBE72L};
            uint8_t l_632 = 0xE0L;
            int i;
lbl_611:
            l_441 = (void*)0;
            for (g_89 = 0; (g_89 <= 5); g_89 += 1)
            { /* block id: 265 */
                int32_t l_594 = 4L;
                int16_t l_598[7][2] = {{0x186EL,0x186EL},{0x186EL,0x186EL},{0x186EL,0x186EL},{0x186EL,0x186EL},{0x186EL,0x186EL},{0x186EL,0x186EL},{0x186EL,0x186EL}};
                int32_t l_601 = (-1L);
                int32_t l_602 = 1L;
                int32_t l_604 = 1L;
                int32_t l_607 = 0x6B72D213L;
                int i, j;
                for (l_403 = 0; (l_403 <= 5); l_403 += 1)
                { /* block id: 268 */
                    int8_t l_592 = (-1L);
                    int32_t l_595 = 0L;
                    int32_t l_596 = 7L;
                    int32_t l_597 = 0x8E9C89B4L;
                    int32_t l_599 = 0x94A298CAL;
                    int32_t l_605 = 0x6AA5BE53L;
                    for (g_208 = 0; (g_208 <= 5); g_208 += 1)
                    { /* block id: 271 */
                        uint16_t *l_569[4][3] = {{&g_377[0],&g_377[0],&g_377[0]},{&g_377[0],&g_377[0],&g_377[0]},{&g_377[0],&g_377[0],&g_377[0]},{&g_377[0],&g_377[0],&g_377[0]}};
                        int i, j;
                        g_446 &= ((safe_mod_func_uint8_t_u_u_unsafe_macro/*130*//* ___SAFE__OP */(((safe_add_func_int32_t_s_s_unsafe_macro/*131*//* ___SAFE__OP */(((*l_517) = (safe_mod_func_uint8_t_u_u_unsafe_macro/*132*//* ___SAFE__OP */(g_124[l_403][l_403], g_96[g_208]))), (4294967295UL != g_96[l_403]))) < (((safe_add_func_uint32_t_u_u_unsafe_macro/*133*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s_unsafe_macro/*134*//* ___SAFE__OP */(g_96[2], (g_124[1][5] <= (&g_481 != l_565)))), (safe_unary_minus_func_uint64_t_u_unsafe_macro/*135*//* ___SAFE__OP */(((safe_sub_func_uint32_t_u_u_unsafe_macro/*136*//* ___SAFE__OP */(((g_377[1] = (g_85 |= (*l_59))) == g_124[l_403][l_403]), p_41)) && 0x1B573E32L))))) | 1L) , p_41)), g_385.f1)) , l_570);
                    }
                    for (g_26 = 0; (g_26 <= 2); g_26 += 1)
                    { /* block id: 279 */
                        int8_t *l_591 = &l_58;
                        int32_t l_593 = 7L;
                        int32_t l_600 = 0x15660811L;
                        int32_t l_603 = (-1L);
                        int32_t l_606 = 4L;
                        (*l_517) = (safe_mod_func_uint32_t_u_u_unsafe_macro/*137*//* ___SAFE__OP */((safe_div_func_int8_t_s_s_unsafe_macro/*138*//* ___SAFE__OP */((((void*)0 != l_577) ^ ((safe_mul_func_uint16_t_u_u_unsafe_macro/*139*//* ___SAFE__OP */(((void*)0 != l_580), (((safe_lshift_func_int64_t_s_s_unsafe_macro/*140*//* ___SAFE__OP */(p_41, 36)) , (((**g_356)++) <= ((safe_div_func_int8_t_s_s_unsafe_macro/*141*//* ___SAFE__OP */((l_587 , ((void*)0 != l_588)), (safe_sub_func_int64_t_s_s_unsafe_macro/*142*//* ___SAFE__OP */((((*l_591) ^= (&l_577 != &l_577)) >= l_592), p_41)))) >= l_593))) || g_96[4]))) < p_41)), 0x6AL)), p_41));
                        l_594 = ((*l_588) = (((*l_468) = g_385.f2) > (**g_159)));
                        g_608--;
                        if (l_528)
                            goto lbl_611;
                    }
                }
                for (l_601 = 0; (l_601 <= 5); l_601 += 1)
                { /* block id: 292 */
                    int32_t ****l_626 = (void*)0;
                    int32_t l_631 = (-1L);
                    for (g_385.f1 = 1; (g_385.f1 <= 5); g_385.f1 += 1)
                    { /* block id: 295 */
                        int32_t l_625 = (-1L);
                        l_59 = (*g_159);
                        (***l_628) |= ((safe_mod_func_int16_t_s_s_unsafe_macro/*143*//* ___SAFE__OP */((+0x5532E57DL), 0xF56BL)) ^ ((g_630 = (((safe_mod_func_int16_t_s_s_unsafe_macro/*144*//* ___SAFE__OP */((safe_div_func_int64_t_s_s_unsafe_macro/*145*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u_unsafe_macro/*146*//* ___SAFE__OP */(((safe_add_func_int8_t_s_s_unsafe_macro/*147*//* ___SAFE__OP */((((*l_468) = l_625) & (&g_428[9] != ((*l_505) = (void*)0))), p_41)) >= (l_626 != (g_282.f3 , l_627))), p_41)), 0x4426C7D89A73C911LL)), 2UL)) && 0x66A6B6F4988978A5LL) , p_41)) < 0x8DECB16BL));
                        (*l_59) ^= (-1L);
                    }
                    ++l_632;
                }
            }
            l_635 = (void*)0;
        }
        else
        { /* block id: 307 */
            uint64_t l_636 = 0xBEE0CCA3D6DEA124LL;
            ++l_636;
        }
        (*g_641) = ((&g_89 != ((*l_639) = l_59)) , ((*l_629) = (*g_159)));
    }
    for (g_208 = 0; (g_208 < 20); ++g_208)
    { /* block id: 316 */
        int32_t **l_645 = (void*)0;
        int32_t **l_646 = (void*)0;
        uint8_t * const *l_649[9][10][2] = {{{(void*)0,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{(void*)0,&g_308}},{{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,&g_308}},{{&g_308,&g_308},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,&g_308},{&g_308,&g_308}},{{&g_308,&g_308},{(void*)0,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308}},{{(void*)0,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{(void*)0,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{(void*)0,&g_308}},{{&g_308,(void*)0},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308}},{{&g_308,&g_308},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308}},{{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,(void*)0},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308}},{{&g_308,(void*)0},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308},{&g_308,&g_308}}};
        uint8_t * const **l_648[7] = {&l_649[0][5][1],(void*)0,(void*)0,&l_649[0][5][1],(void*)0,(void*)0,&l_649[0][5][1]};
        uint8_t * const ***l_647 = &l_648[0];
        uint32_t *l_655 = &g_89;
        struct S0 l_658 = {0x7A2A3D74ACD6D13FLL,0xE5L,7L,0xE8L,-7L};
        int32_t l_675 = 0xC8091E15L;
        int32_t l_676[7] = {0x33F5E29BL,0x43B386CBL,0x33F5E29BL,0x33F5E29BL,0x43B386CBL,0x33F5E29BL,0x33F5E29BL};
        int8_t l_729 = 0L;
        int8_t l_766[6] = {0x89L,0x89L,0x89L,0x89L,0x89L,0x89L};
        uint16_t l_784 = 0x7719L;
        uint64_t **l_797 = &l_529;
        uint64_t ***l_796 = &l_797;
        int i, j, k;
    }
    return (***g_355);
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_85 g_89 g_26 g_23 g_96 g_97 g_99 g_112 g_95 g_124 g_127 g_261 g_160
 * writes: g_85 g_89 g_26 g_92 g_95 g_97 g_99 g_112 g_122 g_124 g_127
 */
static int32_t  func_49(uint8_t  p_50, int32_t * p_51, int32_t  p_52, int8_t  p_53, int64_t  p_54)
{ /* block id: 4 */
    int32_t l_82[5] = {0xC3D8FFFCL,0xC3D8FFFCL,0xC3D8FFFCL,0xC3D8FFFCL,0xC3D8FFFCL};
    uint32_t *l_88 = &g_89;
    uint64_t *l_90 = &g_26;
    uint32_t *l_91 = &g_92;
    int32_t *l_93 = (void*)0;
    int32_t *l_94[2];
    int64_t l_120 = 0x76934E6C7C9CA9E2LL;
    uint16_t l_123 = 65533UL;
    int16_t *l_235 = (void*)0;
    uint64_t l_283 = 3UL;
    int64_t **l_348 = (void*)0;
    int i;
    for (i = 0; i < 2; i++)
        l_94[i] = (void*)0;
    p_52 = (*p_51);
    g_99 ^= func_60(func_65(&g_23, &g_8, (((safe_rshift_func_int8_t_s_s((+(((g_95[3][0][1] = (safe_add_func_int32_t_s_s_unsafe_macro/*149*//* ___SAFE__OP */(((+(((*l_91) = ((safe_add_func_uint16_t_u_u_unsafe_macro/*150*//* ___SAFE__OP */((((((*l_90) ^= (safe_lshift_func_int64_t_s_u((((&g_8 != &g_8) >= (safe_sub_func_int32_t_s_s_unsafe_macro/*152*//* ___SAFE__OP */(l_82[4], (safe_lshift_func_uint8_t_u_s(((((g_85++) < ((l_82[3] < (((*p_51) < g_8) == ((*l_88) = (((void*)0 != &g_23) & g_8)))) > 0x44478C2BA2848AA2LL)) && g_89) , 0x83L), 3))))) ^ p_52), 58))) < l_82[4]) , g_89) | (*p_51)), 2L)) != 0L)) != g_23)) <= g_23), g_23))) & (-1L)) > g_8)), p_52)) || p_53) , 0L), g_96[5]), l_90, &l_82[4], p_53);
    for (p_50 = 7; (p_50 == 50); p_50 = safe_add_func_int16_t_s_s_unsafe_macro/*154*//* ___SAFE__OP */(p_50, 8))
    { /* block id: 19 */
        uint16_t l_109 = 65534UL;
        uint16_t l_110 = 8UL;
        uint8_t *l_111 = &g_112;
        int16_t *l_121 = &g_122;
        int32_t l_186 = 1L;
        g_124[3][3] |= (((*l_121) = (safe_mod_func_uint8_t_u_u_unsafe_macro/*155*//* ___SAFE__OP */((safe_unary_minus_func_int32_t_s_unsafe_macro/*156*//* ___SAFE__OP */((safe_add_func_int8_t_s_s_unsafe_macro/*157*//* ___SAFE__OP */(((((((l_109 != (l_109 , (-10L))) >= l_110) && 18446744073709551615UL) | (g_96[5] != l_109)) || ((*l_111)--)) | (((((safe_mul_func_int16_t_s_s_unsafe_macro/*158*//* ___SAFE__OP */((+((*l_90)++)), l_109)) , 4UL) == p_50) , g_95[3][0][1]) || g_89)), l_120)))), p_53))) && l_123);
        for (g_112 = 15; (g_112 != 39); g_112 = safe_add_func_int64_t_s_s_unsafe_macro/*159*//* ___SAFE__OP */(g_112, 4))
        { /* block id: 26 */
            uint16_t l_130 = 65535UL;
            int32_t l_167 = 0x82038209L;
            int32_t l_189[2][6] = {{0xEEF009D0L,0x186F313AL,0x5C23F69FL,0x5C23F69FL,0x186F313AL,0xEEF009D0L},{0x8628B0E1L,0xEEF009D0L,0x5C23F69FL,0xEEF009D0L,0x8628B0E1L,0x8628B0E1L}};
            int i, j;
            g_127 ^= 8L;
        }
    }
    for (p_52 = 0; (p_52 < (-1)); --p_52)
    { /* block id: 59 */
        int32_t l_199 = 0x4424C02BL;
        int64_t *l_204 = (void*)0;
        int32_t l_207 = 0xD395282EL;
        const struct S0 l_212[2] = {{0xE910D8181497D27ELL,0x82L,0x0576L,0UL,7L},{0xE910D8181497D27ELL,0x82L,0x0576L,0UL,7L}};
        int64_t *l_221 = &g_95[3][0][1];
        int64_t *l_222 = &g_96[5];
        int64_t *l_223 = &l_120;
        uint8_t **l_323 = &g_308;
        int i;
    }
    return (**g_261);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_60(const uint64_t * p_61, uint64_t * p_62, int32_t * p_63, uint64_t  p_64)
{ /* block id: 14 */
    return (*p_63);
}


/* ------------------------------------------ */
/* 
 * reads : g_97
 * writes: g_97
 */
static uint64_t * func_65(int64_t * p_66, int32_t * p_67, int64_t  p_68, int8_t  p_69)
{ /* block id: 11 */
    uint64_t *l_98[2][9][2] = {{{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26}},{{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26},{(void*)0,&g_26},{&g_26,&g_26}}};
    int i, j, k;
    g_97 &= 2L;
    return l_98[0][7][1];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_95[i][j][k], "g_95[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_96[i], "g_96[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_124[i][j], "g_124[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_166[i][j][k], "g_166[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    transparent_crc(g_208, "g_208", print_hash_value);
    transparent_crc(g_282.f0, "g_282.f0", print_hash_value);
    transparent_crc(g_282.f1, "g_282.f1", print_hash_value);
    transparent_crc(g_282.f2, "g_282.f2", print_hash_value);
    transparent_crc(g_282.f3, "g_282.f3", print_hash_value);
    transparent_crc(g_282.f4, "g_282.f4", print_hash_value);
    transparent_crc(g_349, "g_349", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_350[i][j][k], "g_350[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_377[i], "g_377[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_380[i], "g_380[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_381, "g_381", print_hash_value);
    transparent_crc(g_385.f0, "g_385.f0", print_hash_value);
    transparent_crc(g_385.f1, "g_385.f1", print_hash_value);
    transparent_crc(g_385.f2, "g_385.f2", print_hash_value);
    transparent_crc(g_385.f3, "g_385.f3", print_hash_value);
    transparent_crc(g_385.f4, "g_385.f4", print_hash_value);
    transparent_crc(g_446, "g_446", print_hash_value);
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_608, "g_608", print_hash_value);
    transparent_crc(g_630, "g_630", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_659[i], "g_659[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_674, "g_674", print_hash_value);
    transparent_crc(g_677, "g_677", print_hash_value);
    transparent_crc(g_814, "g_814", print_hash_value);
    transparent_crc(g_842.f0, "g_842.f0", print_hash_value);
    transparent_crc(g_842.f1, "g_842.f1", print_hash_value);
    transparent_crc(g_842.f2, "g_842.f2", print_hash_value);
    transparent_crc(g_842.f3, "g_842.f3", print_hash_value);
    transparent_crc(g_842.f4, "g_842.f4", print_hash_value);
    transparent_crc(g_998.f0, "g_998.f0", print_hash_value);
    transparent_crc(g_998.f1, "g_998.f1", print_hash_value);
    transparent_crc(g_998.f2, "g_998.f2", print_hash_value);
    transparent_crc(g_998.f3, "g_998.f3", print_hash_value);
    transparent_crc(g_998.f4, "g_998.f4", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1088[i][j], "g_1088[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1092, "g_1092", print_hash_value);
    transparent_crc(g_1124, "g_1124", print_hash_value);
    transparent_crc(g_1146, "g_1146", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1180[i], "g_1180[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1364.f0, "g_1364.f0", print_hash_value);
    transparent_crc(g_1364.f1, "g_1364.f1", print_hash_value);
    transparent_crc(g_1364.f2, "g_1364.f2", print_hash_value);
    transparent_crc(g_1364.f3, "g_1364.f3", print_hash_value);
    transparent_crc(g_1364.f4, "g_1364.f4", print_hash_value);
    transparent_crc(g_1401, "g_1401", print_hash_value);
    transparent_crc(g_1560, "g_1560", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1639[i], "g_1639[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1674.f0, "g_1674.f0", print_hash_value);
    transparent_crc(g_1674.f1, "g_1674.f1", print_hash_value);
    transparent_crc(g_1674.f2, "g_1674.f2", print_hash_value);
    transparent_crc(g_1674.f3, "g_1674.f3", print_hash_value);
    transparent_crc(g_1674.f4, "g_1674.f4", print_hash_value);
    transparent_crc(g_1696, "g_1696", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1712[i], "g_1712[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1762, "g_1762", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 420
   depth: 1, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 47
breakdown:
   depth: 1, occurrence: 116
   depth: 2, occurrence: 37
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 23, occurrence: 4
   depth: 24, occurrence: 1
   depth: 32, occurrence: 1
   depth: 36, occurrence: 1
   depth: 38, occurrence: 2
   depth: 40, occurrence: 1
   depth: 42, occurrence: 1
   depth: 47, occurrence: 1

XXX total number of pointers: 313

XXX times a variable address is taken: 734
XXX times a pointer is dereferenced on RHS: 239
breakdown:
   depth: 1, occurrence: 147
   depth: 2, occurrence: 66
   depth: 3, occurrence: 24
   depth: 4, occurrence: 2
XXX times a pointer is dereferenced on LHS: 221
breakdown:
   depth: 1, occurrence: 164
   depth: 2, occurrence: 37
   depth: 3, occurrence: 16
   depth: 4, occurrence: 4
XXX times a pointer is compared with null: 40
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 4
XXX times a pointer is qualified to be dereferenced: 5833

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 690
   level: 2, occurrence: 315
   level: 3, occurrence: 180
   level: 4, occurrence: 82
   level: 5, occurrence: 69
XXX number of pointers point to pointers: 154
XXX number of pointers point to scalars: 149
XXX number of pointers point to structs: 10
XXX percent of pointers has null in alias set: 35.1
XXX average alias set size: 1.62

XXX times a non-volatile is read: 1404
XXX times a non-volatile is write: 756
XXX times a volatile is read: 103
XXX    times read thru a pointer: 43
XXX times a volatile is write: 26
XXX    times written thru a pointer: 10
XXX times a volatile is available for access: 1.05e+03
XXX percentage of non-volatile access: 94.4

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 126
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 26
   depth: 1, occurrence: 13
   depth: 2, occurrence: 16
   depth: 3, occurrence: 23
   depth: 4, occurrence: 25
   depth: 5, occurrence: 23

XXX percentage a fresh-made variable is used: 16.1
XXX percentage an existing variable is used: 83.9
********************* end of statistics **********************/

