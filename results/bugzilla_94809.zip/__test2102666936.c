/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: d619b03
 * Options:   --seed 2102666936 --bitfields --packed-struct
 * Seed:      2102666936
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int32_t  f0;
   int64_t  f1;
   uint64_t  f2;
   volatile signed f3 : 21;
};

union U1 {
   int8_t * volatile  f0;
   volatile int16_t  f1;
};

union U2 {
   volatile uint32_t  f0;
   uint32_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_13 = 65535UL;
static uint64_t g_61 = 7UL;
static int32_t g_68 = 0x6DA84B50L;
static int32_t *g_67 = &g_68;
static uint16_t g_79 = 0x2426L;
static int32_t g_81 = 0xCA929EFCL;
static int32_t * volatile g_80 = &g_81;/* VOLATILE GLOBAL g_80 */
static union U0 g_85 = {-1L};/* VOLATILE GLOBAL g_85 */
static int8_t g_119 = 9L;
static int32_t g_121 = 1L;
static int32_t * volatile g_120[4] = {&g_121,&g_121,&g_121,&g_121};
static int32_t * volatile g_122 = &g_121;/* VOLATILE GLOBAL g_122 */
static uint64_t g_142 = 7UL;
static uint64_t *g_141[4] = {&g_142,&g_142,&g_142,&g_142};
static uint64_t *g_143[7][1][10] = {{{&g_142,(void*)0,&g_142,&g_142,&g_142,&g_142,(void*)0,&g_142,(void*)0,&g_142}},{{&g_85.f2,&g_61,&g_142,&g_61,(void*)0,&g_142,&g_61,&g_142,&g_142,&g_142}},{{&g_85.f2,&g_61,&g_142,(void*)0,(void*)0,&g_142,&g_61,&g_142,(void*)0,(void*)0}},{{&g_142,(void*)0,&g_142,&g_142,&g_61,&g_85.f2,(void*)0,&g_142,&g_142,&g_85.f2}},{{&g_85.f2,&g_85.f2,&g_142,&g_85.f2,&g_142,&g_61,&g_85.f2,(void*)0,&g_142,&g_142}},{{(void*)0,&g_85.f2,&g_142,&g_142,&g_142,&g_142,&g_85.f2,(void*)0,&g_85.f2,&g_142}},{{&g_85.f2,(void*)0,&g_142,&g_142,&g_85.f2,&g_85.f2,(void*)0,(void*)0,&g_142,&g_142}}};
static union U0 g_162 = {1L};/* VOLATILE GLOBAL g_162 */
static uint32_t g_196[9] = {4294967294UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL};
static volatile uint32_t g_198[9][8][2] = {{{0x2A3AB484L,4294967287UL},{0xE63DA663L,0x1DB4CFA5L},{4294967292UL,0xC0632B81L},{4294967287UL,4294967295UL},{0x1DB4CFA5L,0x24755464L},{0UL,0x81135C14L},{4294967295UL,4294967294UL},{0x16D18036L,0UL}},{{4294967295UL,1UL},{4294967291UL,0UL},{0x7F41821AL,0x688B2AD5L},{4294967291UL,0x16D18036L},{4294967295UL,0UL},{0x46F7BBE7L,0xA8BF02E3L},{0x1CBD15FEL,0x6CD91451L},{0x3A45DBAEL,0xE63DA663L}},{{0UL,4294967290UL},{0UL,0UL},{0x688B2AD5L,4294967289UL},{4294967292UL,0x1CBD15FEL},{0x8CD2B34EL,0x1CBD15FEL},{4294967292UL,4294967289UL},{0x688B2AD5L,0UL},{0UL,4294967290UL}},{{0UL,0xE63DA663L},{0x3A45DBAEL,0x6CD91451L},{0x1CBD15FEL,0xA8BF02E3L},{0x46F7BBE7L,0UL},{4294967295UL,0x16D18036L},{4294967291UL,0x688B2AD5L},{0x7F41821AL,0UL},{4294967291UL,1UL}},{{4294967295UL,0UL},{0x16D18036L,4294967294UL},{4294967295UL,0x81135C14L},{0UL,0x24755464L},{0x1DB4CFA5L,4294967295UL},{4294967287UL,0xC0632B81L},{4294967292UL,0x1DB4CFA5L},{0xE63DA663L,4294967287UL}},{{0x2A3AB484L,0UL},{4294967288UL,0x021E97B7L},{1UL,4294967295UL},{0x706E003AL,0x7F41821AL},{3UL,0x0F89493EL},{0UL,0UL},{0x6CD91451L,0x6233F163L},{4294967295UL,4294967291UL}},{{6UL,9UL},{4294967290UL,6UL},{1UL,1UL},{1UL,6UL},{4294967290UL,9UL},{6UL,4294967291UL},{4294967295UL,0x6233F163L},{0x6CD91451L,0UL}},{{0UL,0x0F89493EL},{3UL,0x7F41821AL},{0x706E003AL,4294967295UL},{1UL,0x021E97B7L},{4294967288UL,0UL},{0x2A3AB484L,4294967287UL},{0xE63DA663L,0x1DB4CFA5L},{4294967292UL,0xC0632B81L}},{{4294967287UL,4294967295UL},{0x1DB4CFA5L,0x24755464L},{0UL,0x81135C14L},{4294967295UL,4294967294UL},{0x16D18036L,0UL},{4294967295UL,1UL},{4294967291UL,0UL},{0x7F41821AL,0x688B2AD5L}}};
static volatile union U2 g_222 = {8UL};/* VOLATILE GLOBAL g_222 */
static int32_t ** volatile g_235 = &g_67;/* VOLATILE GLOBAL g_235 */
static volatile uint16_t **g_265[2][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int8_t *g_278 = &g_119;
static int8_t **g_277[2] = {&g_278,&g_278};
static int8_t *** const  volatile g_276[10] = {&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1],&g_277[1]};
static int16_t g_343 = 0xBB7BL;
static volatile union U1 g_349 = {0};/* VOLATILE GLOBAL g_349 */
static volatile union U1 *g_353 = &g_349;
static union U1 g_357 = {0};/* VOLATILE GLOBAL g_357 */
static union U1 *g_356 = &g_357;
static uint32_t g_368 = 0xA88DE528L;
static union U0 g_389 = {1L};/* VOLATILE GLOBAL g_389 */
static int16_t g_403 = 0x7D9FL;
static uint8_t g_415 = 0UL;
static volatile union U1 g_463 = {0};/* VOLATILE GLOBAL g_463 */
static volatile union U2 g_466[2] = {{0UL},{0UL}};
static int64_t g_473 = 0x152DA7EACAC37D0DLL;
static const union U1 *g_478 = &g_357;
static const union U1 **g_477 = &g_478;
static int32_t ** volatile g_482[3][4] = {{&g_67,&g_67,&g_67,&g_67},{&g_67,&g_67,&g_67,&g_67},{&g_67,&g_67,&g_67,&g_67}};
static volatile uint16_t *** volatile g_499 = (void*)0;/* VOLATILE GLOBAL g_499 */
static volatile uint16_t *** volatile g_500 = (void*)0;/* VOLATILE GLOBAL g_500 */
static volatile union U2 g_523 = {0x9993719CL};/* VOLATILE GLOBAL g_523 */
static int32_t ** volatile g_590 = &g_67;/* VOLATILE GLOBAL g_590 */
static union U0 g_618 = {2L};/* VOLATILE GLOBAL g_618 */
static const volatile union U1 g_619[3][3] = {{{0},{0},{0}},{{0},{0},{0}},{{0},{0},{0}}};
static int16_t g_621 = 0xE6EDL;
static volatile union U0 g_628 = {0x68386735L};/* VOLATILE GLOBAL g_628 */
static union U1 g_720 = {0};/* VOLATILE GLOBAL g_720 */
static volatile union U1 * volatile * const  volatile g_721 = &g_353;/* VOLATILE GLOBAL g_721 */
static union U1 g_777 = {0};/* VOLATILE GLOBAL g_777 */
static volatile int16_t g_791 = 0xDCB8L;/* VOLATILE GLOBAL g_791 */
static volatile int16_t *g_790 = &g_791;
static volatile int16_t **g_789 = &g_790;
static union U0 g_798 = {-1L};/* VOLATILE GLOBAL g_798 */
static union U2 g_815 = {5UL};/* VOLATILE GLOBAL g_815 */
static union U2 *g_829 = &g_815;
static union U2 ** volatile g_828 = &g_829;/* VOLATILE GLOBAL g_828 */
static int32_t ** volatile g_841[6][7] = {{&g_67,&g_67,&g_67,&g_67,(void*)0,&g_67,&g_67},{&g_67,&g_67,&g_67,(void*)0,(void*)0,&g_67,&g_67},{&g_67,&g_67,&g_67,(void*)0,&g_67,&g_67,&g_67},{&g_67,&g_67,&g_67,&g_67,(void*)0,&g_67,&g_67},{&g_67,&g_67,&g_67,(void*)0,(void*)0,&g_67,&g_67},{&g_67,&g_67,&g_67,(void*)0,&g_67,&g_67,&g_67}};
static union U0 g_868 = {0xA9ED0813L};/* VOLATILE GLOBAL g_868 */
static volatile union U0 g_877 = {-5L};/* VOLATILE GLOBAL g_877 */
static union U0 g_886[1] = {{0x1D2E102DL}};
static union U1 g_907 = {0};/* VOLATILE GLOBAL g_907 */
static volatile union U2 g_929 = {0xAD3B4E9CL};/* VOLATILE GLOBAL g_929 */
static uint32_t *g_1079 = &g_368;
static uint32_t **g_1078 = &g_1079;
static volatile union U1 g_1116 = {0};/* VOLATILE GLOBAL g_1116 */
static int16_t g_1119 = 0x229EL;
static int16_t *g_1145 = &g_621;
static int16_t **g_1144 = &g_1145;
static int16_t ***g_1143[7] = {&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144,&g_1144};
static int16_t ****g_1142 = &g_1143[5];
static union U1 **g_1206 = (void*)0;
static union U1 ***g_1205 = &g_1206;
static int8_t g_1239 = (-6L);
static volatile union U1 g_1257 = {0};/* VOLATILE GLOBAL g_1257 */
static int32_t * volatile g_1301 = &g_68;/* VOLATILE GLOBAL g_1301 */
static int32_t ****g_1325 = (void*)0;
static union U0 g_1343 = {8L};/* VOLATILE GLOBAL g_1343 */
static volatile union U0 g_1346[2][3][8] = {{{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}},{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}},{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}}},{{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}},{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}},{{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL},{0x93DAE7F4L},{0x93DAE7F4L},{0x50B232DFL},{0x50B232DFL}}}};
static int32_t ** volatile g_1347 = &g_67;/* VOLATILE GLOBAL g_1347 */
static union U0 g_1354 = {0x685CD550L};/* VOLATILE GLOBAL g_1354 */
static uint8_t g_1386 = 1UL;
static uint32_t g_1387 = 0x41EF1148L;
static int32_t ** volatile g_1392 = &g_67;/* VOLATILE GLOBAL g_1392 */
static const uint32_t g_1399[8] = {0x3CE40247L,0x3CE40247L,0x3CE40247L,0x3CE40247L,0x3CE40247L,0x3CE40247L,0x3CE40247L,0x3CE40247L};
static const uint32_t *g_1398 = &g_1399[1];
static const uint32_t **g_1397 = &g_1398;
static volatile union U2 g_1414[8][6][3] = {{{{1UL},{0x15D7561AL},{0UL}},{{0UL},{0x15D7561AL},{0x5BC6E69AL}},{{0x15D7561AL},{0x1CBCF10EL},{0xC35C29ACL}},{{0x6A2E8371L},{0UL},{0x5BC6E69AL}},{{0x40A8018AL},{0x123F418DL},{0UL}},{{0x40A8018AL},{0x24CCDC58L},{0UL}}},{{{0x6A2E8371L},{0xA8FB5924L},{1UL}},{{0x15D7561AL},{0x24CCDC58L},{1UL}},{{0UL},{0x123F418DL},{1UL}},{{1UL},{0UL},{1UL}},{{0x1CBCF10EL},{0x1CBCF10EL},{0UL}},{{1UL},{0x15D7561AL},{0UL}}},{{{0UL},{0x15D7561AL},{0x5BC6E69AL}},{{0x15D7561AL},{0x1CBCF10EL},{0xC35C29ACL}},{{0x6A2E8371L},{0UL},{0x5BC6E69AL}},{{0xF10802DFL},{5UL},{0xA8FB5924L}},{{0xF10802DFL},{18446744073709551607UL},{0x1CBCF10EL}},{{0xE0B350EBL},{0x18E9C0A8L},{0x24CCDC58L}}},{{{18446744073709551615UL},{18446744073709551607UL},{0x6A2E8371L}},{{0UL},{5UL},{0x6A2E8371L}},{{0x3E741387L},{0UL},{0x24CCDC58L}},{{0x8D5C599FL},{0x8D5C599FL},{0x1CBCF10EL}},{{0x3E741387L},{18446744073709551615UL},{0xA8FB5924L}},{{0UL},{18446744073709551615UL},{0x40A8018AL}}},{{{18446744073709551615UL},{0x8D5C599FL},{18446744073709551612UL}},{{0xE0B350EBL},{0UL},{0x40A8018AL}},{{0xF10802DFL},{5UL},{0xA8FB5924L}},{{0xF10802DFL},{18446744073709551607UL},{0x1CBCF10EL}},{{0xE0B350EBL},{0x18E9C0A8L},{0x24CCDC58L}},{{18446744073709551615UL},{18446744073709551607UL},{0x6A2E8371L}}},{{{0UL},{5UL},{0x6A2E8371L}},{{0x3E741387L},{0UL},{0x24CCDC58L}},{{0x8D5C599FL},{0x8D5C599FL},{0x1CBCF10EL}},{{0x3E741387L},{18446744073709551615UL},{0xA8FB5924L}},{{0UL},{18446744073709551615UL},{0x40A8018AL}},{{18446744073709551615UL},{0x8D5C599FL},{18446744073709551612UL}}},{{{0xE0B350EBL},{0UL},{0x40A8018AL}},{{0xF10802DFL},{5UL},{0xA8FB5924L}},{{0xF10802DFL},{18446744073709551607UL},{0x1CBCF10EL}},{{0xE0B350EBL},{0x18E9C0A8L},{0x24CCDC58L}},{{18446744073709551615UL},{18446744073709551607UL},{0x6A2E8371L}},{{0UL},{5UL},{0x6A2E8371L}}},{{{0x3E741387L},{0UL},{0x24CCDC58L}},{{0x8D5C599FL},{0x8D5C599FL},{0x1CBCF10EL}},{{0x3E741387L},{18446744073709551615UL},{0xA8FB5924L}},{{0UL},{18446744073709551615UL},{0x40A8018AL}},{{18446744073709551615UL},{0x8D5C599FL},{18446744073709551612UL}},{{0xE0B350EBL},{0UL},{0x40A8018AL}}}};
static int16_t * const *g_1428 = (void*)0;
static int16_t * const **g_1427 = &g_1428;
static int16_t * const ***g_1426 = &g_1427;
static volatile union U1 g_1445[8][7] = {{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0}}};
static int8_t ***g_1452 = &g_277[1];
static int8_t **** volatile g_1451 = &g_1452;/* VOLATILE GLOBAL g_1451 */
static int32_t *g_1461 = &g_121;
static int32_t ** volatile g_1460 = &g_1461;/* VOLATILE GLOBAL g_1460 */
static const int16_t g_1507[2][2][7] = {{{2L,0x0FFDL,0xC92FL,(-1L),(-1L),0xC92FL,0x0FFDL},{(-1L),2L,1L,(-1L),9L,0L,0L}},{{1L,2L,(-1L),2L,1L,(-1L),9L},{0xC92FL,0x0FFDL,2L,(-1L),0x14F4L,(-1L),2L}}};
static union U1 g_1537 = {0};/* VOLATILE GLOBAL g_1537 */
static uint32_t ***g_1567 = &g_1078;
static int32_t g_1587 = (-5L);
static volatile union U2 g_1610 = {0x5BDDC53FL};/* VOLATILE GLOBAL g_1610 */
static union U2 g_1611 = {0UL};/* VOLATILE GLOBAL g_1611 */
static const int32_t *g_1643 = (void*)0;
static const int32_t ** volatile g_1642[5] = {&g_1643,&g_1643,&g_1643,&g_1643,&g_1643};
static int16_t *****g_1669[1][9] = {{&g_1142,&g_1142,&g_1142,(void*)0,&g_1142,(void*)0,(void*)0,&g_1142,(void*)0}};
static const volatile union U1 g_1670 = {0};/* VOLATILE GLOBAL g_1670 */
static volatile union U2 g_1682 = {0x77AE8919L};/* VOLATILE GLOBAL g_1682 */
static int64_t *g_1685[7][8][4] = {{{&g_868.f1,(void*)0,&g_473,&g_868.f1},{&g_868.f1,(void*)0,&g_473,(void*)0},{&g_473,&g_473,&g_868.f1,&g_473},{&g_473,&g_473,&g_868.f1,&g_473},{&g_473,&g_473,&g_473,&g_868.f1},{&g_473,&g_473,(void*)0,&g_868.f1},{&g_868.f1,&g_473,&g_868.f1,&g_868.f1},{&g_868.f1,&g_473,(void*)0,(void*)0}},{{&g_473,&g_868.f1,&g_473,&g_868.f1},{&g_473,(void*)0,&g_868.f1,&g_868.f1},{&g_473,&g_868.f1,&g_868.f1,(void*)0},{&g_473,(void*)0,&g_473,&g_868.f1},{&g_868.f1,(void*)0,&g_473,&g_473},{&g_868.f1,&g_868.f1,&g_473,&g_473},{(void*)0,(void*)0,(void*)0,&g_473},{&g_473,(void*)0,&g_868.f1,(void*)0}},{{&g_868.f1,(void*)0,&g_868.f1,&g_473},{(void*)0,(void*)0,(void*)0,&g_473},{&g_868.f1,&g_868.f1,(void*)0,&g_473},{&g_868.f1,(void*)0,&g_868.f1,&g_868.f1},{&g_473,(void*)0,&g_473,(void*)0},{&g_473,&g_868.f1,(void*)0,&g_868.f1},{&g_868.f1,(void*)0,&g_868.f1,&g_868.f1},{&g_868.f1,&g_868.f1,&g_868.f1,(void*)0}},{{&g_868.f1,&g_473,&g_473,&g_868.f1},{&g_473,&g_473,&g_473,&g_868.f1},{&g_868.f1,&g_473,&g_868.f1,&g_868.f1},{&g_868.f1,&g_473,&g_868.f1,&g_473},{&g_868.f1,&g_473,(void*)0,&g_473},{&g_473,&g_473,&g_473,(void*)0},{&g_473,(void*)0,&g_868.f1,&g_868.f1},{&g_868.f1,(void*)0,(void*)0,&g_868.f1}},{{&g_868.f1,&g_473,(void*)0,(void*)0},{(void*)0,&g_473,&g_868.f1,&g_473},{&g_868.f1,&g_868.f1,&g_868.f1,&g_473},{&g_473,&g_473,(void*)0,(void*)0},{(void*)0,&g_473,&g_473,&g_868.f1},{&g_868.f1,(void*)0,&g_473,&g_868.f1},{&g_868.f1,(void*)0,&g_473,(void*)0},{&g_473,&g_473,&g_868.f1,&g_473}},{{&g_473,&g_473,&g_868.f1,&g_473},{&g_473,&g_473,&g_473,&g_868.f1},{&g_473,&g_473,(void*)0,&g_868.f1},{&g_868.f1,&g_473,&g_868.f1,&g_868.f1},{&g_868.f1,&g_473,(void*)0,(void*)0},{&g_473,&g_868.f1,&g_473,&g_868.f1},{&g_473,&g_868.f1,&g_868.f1,&g_473},{&g_868.f1,(void*)0,&g_473,(void*)0}},{{&g_868.f1,&g_473,&g_473,&g_473},{&g_868.f1,(void*)0,&g_868.f1,&g_868.f1},{&g_868.f1,&g_868.f1,&g_868.f1,&g_798.f1},{&g_473,&g_473,(void*)0,&g_868.f1},{&g_868.f1,(void*)0,&g_868.f1,(void*)0},{(void*)0,(void*)0,&g_473,&g_868.f1},{(void*)0,&g_473,(void*)0,&g_798.f1},{&g_473,&g_868.f1,&g_868.f1,&g_868.f1}}};
static volatile union U2 g_1686 = {4UL};/* VOLATILE GLOBAL g_1686 */
static union U0 g_1740 = {7L};/* VOLATILE GLOBAL g_1740 */
static union U1 g_1774 = {0};/* VOLATILE GLOBAL g_1774 */
static int64_t g_1793 = (-1L);
static int8_t g_1807 = (-7L);
static int8_t g_1809 = 0x9AL;
static volatile union U1 g_1822 = {0};/* VOLATILE GLOBAL g_1822 */
static union U1 g_1880 = {0};/* VOLATILE GLOBAL g_1880 */
static union U1 g_1925[2][5] = {{{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0}}};
static union U0 g_1947 = {0x69BAD805L};/* VOLATILE GLOBAL g_1947 */
static const int8_t g_1956 = (-4L);
static uint8_t g_1959 = 8UL;
static int32_t g_1973 = 6L;
static int32_t ** volatile g_1974 = &g_1461;/* VOLATILE GLOBAL g_1974 */
static volatile union U2 g_2005[8] = {{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L},{0x46CF4DE4L}};
static volatile uint32_t g_2040 = 0UL;/* VOLATILE GLOBAL g_2040 */
static uint16_t *g_2069 = &g_13;
static uint16_t **g_2068 = &g_2069;
static int16_t g_2129 = (-1L);
static int32_t g_2130 = 0xFFF92067L;
static int16_t g_2131 = 0L;
static int32_t g_2133 = (-1L);
static int16_t g_2134 = 0L;
static uint8_t g_2135 = 0x9CL;
static volatile union U2 g_2174 = {0x7F22A131L};/* VOLATILE GLOBAL g_2174 */
static union U2 g_2183 = {3UL};/* VOLATILE GLOBAL g_2183 */
static union U0 g_2184 = {-10L};/* VOLATILE GLOBAL g_2184 */
static int32_t ** volatile g_2202[4][1][7] = {{{&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67}},{{&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67}},{{&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67}},{{&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67}}};
static union U0 g_2205[9][8] = {{{0x886DEA7FL},{0x26823B74L},{0x26823B74L},{0x886DEA7FL},{0x0A914A2DL},{0x24D71808L},{0x67D9CA93L},{0x20164AB8L}},{{0xE2AADA11L},{0x886DEA7FL},{0x254A3983L},{0x67D9CA93L},{0x254A3983L},{0x886DEA7FL},{0xE2AADA11L},{-7L}},{{0x254A3983L},{0x886DEA7FL},{0xE2AADA11L},{-7L},{0x24D71808L},{0x24D71808L},{-7L},{0xE2AADA11L}},{{0x26823B74L},{0x26823B74L},{0x886DEA7FL},{0x0A914A2DL},{0x24D71808L},{0x67D9CA93L},{0x20164AB8L},{0x67D9CA93L}},{{0x254A3983L},{0xE2AADA11L},{0x0A914A2DL},{0xE2AADA11L},{0x254A3983L},{1L},{0x26823B74L},{0x67D9CA93L}},{{0xE2AADA11L},{0x24D71808L},{0x20164AB8L},{0x0A914A2DL},{0x0A914A2DL},{0x20164AB8L},{0x24D71808L},{0xE2AADA11L}},{{0x886DEA7FL},{1L},{0x20164AB8L},{-7L},{0x26823B74L},{0x254A3983L},{0x26823B74L},{-7L}},{{0x0A914A2DL},{1L},{0x0A914A2DL},{0x67D9CA93L},{-7L},{0x254A3983L},{0x20164AB8L},{0x20164AB8L}},{{0x20164AB8L},{1L},{0x886DEA7FL},{0x886DEA7FL},{1L},{0x20164AB8L},{-7L},{0x26823B74L}}};
static const int32_t g_2208 = 7L;
static const int32_t ** volatile g_2209[6][7] = {{&g_1643,(void*)0,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643},{(void*)0,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643},{&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,(void*)0},{&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643},{&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643},{&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643,&g_1643}};
static int32_t * volatile g_2225[3] = {&g_798.f0,&g_798.f0,&g_798.f0};
static int32_t * volatile g_2226 = &g_798.f0;/* VOLATILE GLOBAL g_2226 */
static union U1 g_2233 = {0};/* VOLATILE GLOBAL g_2233 */
static union U2 **g_2238 = (void*)0;
static union U2 ***g_2237 = &g_2238;
static int64_t g_2249 = 0x8BC311EB29455C25LL;
static union U2 g_2271 = {0xFF7BF18AL};/* VOLATILE GLOBAL g_2271 */
static union U2 g_2273[2][7][5] = {{{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}}},{{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL}}}};
static union U2 g_2274 = {3UL};/* VOLATILE GLOBAL g_2274 */
static union U2 g_2275 = {0xE664771BL};/* VOLATILE GLOBAL g_2275 */
static uint32_t g_2276 = 0x239F5E21L;
static union U0 g_2283 = {1L};/* VOLATILE GLOBAL g_2283 */
static union U0 g_2284[5][1] = {{{0xB7F306FCL}},{{0L}},{{0xB7F306FCL}},{{0L}},{{0xB7F306FCL}}};
static volatile int32_t g_2308 = 1L;/* VOLATILE GLOBAL g_2308 */
static volatile union U0 g_2311 = {0x822F4E44L};/* VOLATILE GLOBAL g_2311 */
static union U1 g_2414[6] = {{0},{0},{0},{0},{0},{0}};
static volatile union U2 g_2471[7] = {{0xE705E6A0L},{0xE705E6A0L},{0xE705E6A0L},{0xE705E6A0L},{0xE705E6A0L},{0xE705E6A0L},{0xE705E6A0L}};
static union U1 ****g_2494 = (void*)0;
static union U1 *****g_2493 = &g_2494;
static volatile union U1 g_2543 = {0};/* VOLATILE GLOBAL g_2543 */
static volatile union U0 g_2549 = {0xEFDC4F2BL};/* VOLATILE GLOBAL g_2549 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t * func_2(int64_t  p_3);
static union U0  func_6(int32_t * p_7, int32_t * p_8, int32_t * p_9, int32_t  p_10);
static union U1  func_11(uint8_t  p_12);
static int32_t * func_16(uint16_t  p_17, int32_t * p_18, int64_t  p_19, uint16_t  p_20);
static int32_t * func_21(uint32_t  p_22, int8_t * p_23, int32_t * p_24, int32_t * p_25, uint16_t  p_26);
static uint32_t  func_27(int32_t * p_28, int32_t * p_29);
static int32_t * func_30(int32_t  p_31, int32_t  p_32, int8_t  p_33, int32_t * p_34, int32_t * p_35);
static uint32_t  func_41(uint32_t  p_42, int32_t  p_43, int8_t  p_44, int32_t  p_45, uint64_t  p_46);
static int8_t  func_54(int16_t  p_55, int32_t * p_56, int32_t * p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_198 g_389.f0 g_1392 g_343 g_1426 g_1399 g_828 g_829 g_466 g_1145 g_621 g_67 g_1144 g_1445 g_798.f0 g_1386 g_1451 g_1460 g_235 g_403 g_196 g_278 g_119 g_79 g_1461 g_1354.f0 g_523 g_1142 g_1143 g_789 g_790 g_791 g_61 g_618.f0 g_1537 g_1239 g_721 g_353 g_349 g_122 g_121 g_1452 g_1610 g_1611 g_1119 g_1507 g_277 g_1387 g_1740 g_1587 g_1301 g_68 g_1643 g_81 g_1774 g_1793 g_142 g_1807 g_1809 g_1822 g_868.f0 g_1740.f0 g_1610.f0 g_1880 g_1397 g_1398 g_1343.f0 g_1567 g_1078 g_590 g_1079 g_1925 g_618 g_1947 g_415 g_1956 g_1959 g_222 g_389 g_1973 g_1974 g_2284 g_523.f0 g_815 g_2069 g_2308 g_2311 g_2284.f0 g_368 g_2134 g_2068 g_2414 g_80 g_1947.f0
 * writes: g_13 g_67 g_1426 g_1354.f0 g_1354.f2 g_1452 g_473 g_1461 g_403 g_119 g_415 g_621 g_61 g_1567 g_618.f0 g_79 g_1643 g_121 g_1587 g_868.f0 g_1809 g_162.f1 g_1740.f0 g_1143 g_1611.f1 g_1343.f0 g_1386 g_1144 g_1079 g_1807 g_1959 g_343 g_2284.f0 g_368 g_142 g_2284.f2 g_196 g_68 g_1119 g_2068 g_1947.f0 g_1078 g_81
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_1775[9] = {&g_868.f0,&g_1740.f0,&g_868.f0,&g_1740.f0,&g_868.f0,&g_1740.f0,&g_868.f0,&g_1740.f0,&g_868.f0};
    uint8_t l_1778 = 0UL;
    const int32_t l_1800 = 7L;
    uint16_t l_1801 = 9UL;
    union U1 ****l_1802 = &g_1205;
    int32_t l_1803 = 0xFAE4B007L;
    const int16_t l_1804 = 1L;
    const uint16_t l_1805[1] = {0xC9FBL};
    const int8_t l_1806[5] = {0L,0L,0L,0L,0L};
    int8_t *l_1808 = &g_1809;
    int16_t l_1810 = 0xD295L;
    uint8_t l_1811 = 1UL;
    int64_t *l_1812 = &g_162.f1;
    int32_t l_1813 = 0xB4B3D74CL;
    int64_t l_1814 = (-5L);
    int32_t *l_1815[4];
    int32_t *l_2576[10] = {&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0,&g_2205[4][5].f0};
    uint16_t l_2577 = 0xF444L;
    uint16_t l_2582[8][10] = {{0x531CL,0xC6F6L,0xC6F6L,0x531CL,0xDE08L,0xC6F6L,8UL,0xDE08L,0xDE08L,8UL},{0xDE08L,0x531CL,0xC6F6L,0xC6F6L,0x531CL,0xDE08L,0xC6F6L,8UL,0xDE08L,0xDE08L},{0x531CL,8UL,0xD4EAL,0x531CL,0x531CL,0xD4EAL,8UL,0x531CL,0xED36L,8UL},{0x531CL,0xDE08L,0xC6F6L,8UL,0xDE08L,0xDE08L,8UL,0xC6F6L,0xDE08L,0x531CL},{0xDE08L,8UL,0xC6F6L,0xDE08L,0x531CL,0xC6F6L,0xC6F6L,0x531CL,0xDE08L,0xC6F6L},{0x531CL,0x531CL,0xD4EAL,8UL,0x531CL,0xED36L,8UL,8UL,0xED36L,0x531CL},{0x531CL,0xC6F6L,0xC6F6L,0x531CL,0xDE08L,0xC6F6L,0xC6F6L,0xED36L,0xED36L,0xC6F6L},{0xED36L,0xDE08L,0xD4EAL,0xD4EAL,0xDE08L,0xED36L,0xD4EAL,0xC6F6L,0xED36L,0xED36L}};
    int64_t l_2583[2][8][5] = {{{(-1L),0L,0L,(-1L),(-1L)},{(-1L),(-1L),0xDADCA18A4ECF5D11LL,0xDADCA18A4ECF5D11LL,(-1L)},{(-1L),0L,0xDADCA18A4ECF5D11LL,0x6C87760D45001CB2LL,0x6C87760D45001CB2LL},{0L,(-1L),0L,0xDADCA18A4ECF5D11LL,0x6C87760D45001CB2LL},{(-1L),(-1L),0x6C87760D45001CB2LL,(-1L),(-1L)},{0L,(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),0x6C87760D45001CB2LL,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L)}},{{(-1L),(-1L),0xDADCA18A4ECF5D11LL,0xDADCA18A4ECF5D11LL,(-1L)},{(-1L),0L,0xDADCA18A4ECF5D11LL,0x6C87760D45001CB2LL,0x6C87760D45001CB2LL},{0L,(-1L),0L,0xDADCA18A4ECF5D11LL,0x6C87760D45001CB2LL},{(-1L),(-1L),0x6C87760D45001CB2LL,(-1L),(-1L)},{0L,(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),0x6C87760D45001CB2LL,(-1L),(-1L)},{(-1L),0L,0L,(-1L),(-1L)},{(-1L),(-1L),0xDADCA18A4ECF5D11LL,0xDADCA18A4ECF5D11LL,(-1L)}}};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1815[i] = &g_868.f0;
    l_2576[0] = func_2((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*0*//* ___SAFE__OP */((func_6((func_11(g_13) , (void*)0), l_1775[1], ((safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*1*//* ___SAFE__OP */(l_1778, (8UL != ((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*2*//* ___SAFE__OP */((((*l_1812) = (safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*3*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*4*//* ___SAFE__OP */(((((*l_1808) &= (((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*5*//* ___SAFE__OP */(((~(0xC3L & (safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*6*//* ___SAFE__OP */(((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*7*//* ___SAFE__OP */(((safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*8*//* ___SAFE__OP */(g_1793)) | ((g_868.f0 = (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*9*//* ___SAFE__OP */(((((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*10*//* ___SAFE__OP */((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*11*//* ___SAFE__OP */(1L, l_1800)), l_1801)) < 65535UL) , &g_1205) == l_1802), l_1803))) == g_142)), l_1804)) <= (-10L)), l_1805[0])))) >= l_1806[2]), g_1807)) , (void*)0) != (void*)0)) > l_1810) != 0L), l_1811)), 23))) ^ l_1813), l_1814)) | g_798.f0)))) , l_1815[3]), g_1507[0][1][4]) , (**g_1144)), 1UL)));
    --l_2577;
    (*g_80) = (safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*12*//* ___SAFE__OP */(l_2582[3][4], g_1507[0][1][4]));
    return l_2583[1][7][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_523.f0 g_815 g_789 g_790 g_791 g_1142 g_1143 g_1144 g_1145 g_621 g_343 g_2069 g_13 g_2308 g_2311 g_1822 g_1399 g_2284.f0 g_1610.f0 g_1880 g_1397 g_1398 g_1793 g_81 g_119 g_1343.f0 g_1386 g_79 g_1567 g_1078 g_67 g_61 g_590 g_1079 g_1925 g_389.f0 g_196 g_1610 g_618 g_618.f0 g_1947 g_1807 g_415 g_1239 g_1956 g_1460 g_1959 g_222 g_389 g_1973 g_828 g_829 g_466 g_1974 g_2284 g_278 g_368 g_2134 g_142 g_68 g_1119 g_198 g_2068 g_1587 g_2414 g_1387 g_1452 g_277 g_80 g_1947.f0 g_1451
 * writes: g_343 g_79 g_2284.f0 g_1143 g_621 g_1611.f1 g_1343.f0 g_67 g_1386 g_1144 g_1079 g_13 g_1807 g_1461 g_1959 g_1354.f0 g_368 g_142 g_2284.f2 g_196 g_68 g_1119 g_618.f0 g_415 g_2068 g_119 g_1947.f0 g_1078
 */
static int32_t * func_2(int64_t  p_3)
{ /* block id: 913 */
    uint8_t l_2291 = 5UL;
    uint32_t ***l_2298[8];
    int32_t *l_2303[4];
    int8_t l_2304 = 0L;
    int16_t *l_2305 = (void*)0;
    int16_t *l_2306 = (void*)0;
    int16_t *l_2307 = &g_343;
    int32_t *l_2309 = &g_618.f0;
    int8_t ****l_2338 = &g_1452;
    int8_t ****l_2340[7][8][4] = {{{&g_1452,(void*)0,&g_1452,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{(void*)0,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452}},{{&g_1452,&g_1452,&g_1452,(void*)0},{(void*)0,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0},{&g_1452,&g_1452,(void*)0,&g_1452},{(void*)0,&g_1452,(void*)0,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452}},{{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,(void*)0,&g_1452},{(void*)0,&g_1452,(void*)0,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452}},{{(void*)0,(void*)0,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,(void*)0,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452}},{{&g_1452,&g_1452,(void*)0,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{(void*)0,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0}},{{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{(void*)0,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,(void*)0,&g_1452},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0}},{{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,&g_1452,&g_1452,(void*)0},{&g_1452,&g_1452,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,&g_1452,(void*)0,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,(void*)0,&g_1452,&g_1452},{&g_1452,&g_1452,(void*)0,&g_1452}}};
    const union U1 ***l_2492 = &g_477;
    const union U1 ****l_2491[5][4][10] = {{{&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492},{(void*)0,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492}},{{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492}},{{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,(void*)0},{&l_2492,(void*)0,&l_2492,&l_2492,(void*)0,&l_2492,(void*)0,(void*)0,&l_2492,(void*)0},{&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492}},{{&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,(void*)0,&l_2492,&l_2492},{&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492}},{{&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492,&l_2492},{&l_2492,(void*)0,&l_2492,&l_2492,&l_2492,&l_2492,(void*)0,&l_2492,&l_2492,&l_2492}}};
    const union U1 *****l_2490 = &l_2491[1][1][8];
    union U2 *l_2524[7][1][1] = {{{&g_2273[0][1][0]}},{{(void*)0}},{{&g_2273[0][1][0]}},{{(void*)0}},{{&g_2273[0][1][0]}},{{(void*)0}},{{&g_2273[0][1][0]}}};
    int32_t ****l_2551 = (void*)0;
    int16_t ***l_2573 = (void*)0;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_2298[i] = &g_1078;
    for (i = 0; i < 4; i++)
        l_2303[i] = &g_2284[3][0].f0;
    if ((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*13*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*14*//* ___SAFE__OP */((((((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*15*//* ___SAFE__OP */(p_3, g_523.f0)) || (p_3 == ((*l_2307) &= (l_2291 , (((((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*16*//* ___SAFE__OP */((g_815 , (l_2304 = (((safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*17*//* ___SAFE__OP */((safe_rshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*18*//* ___SAFE__OP */((l_2298[0] == (void*)0), (((-1L) == (((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*19*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*20*//* ___SAFE__OP */(p_3, l_2291)) ^ p_3), (**g_789))) | 0xE7L) == p_3)) > 0xA284C74CFEC7753FLL))), p_3)) | 0x8DD52AA8L) ^ l_2291))), p_3)) && 0x338A74ADA1D80AB1LL) , (****g_1142)) < p_3) != p_3))))) ^ p_3) & 1L) && p_3), (*g_2069))) , g_2308), 59)))
    { /* block id: 916 */
        int32_t *l_2310[3];
        uint16_t l_2312 = 0x1ACFL;
        uint64_t *l_2325 = (void*)0;
        uint64_t *l_2326 = &g_798.f2;
        uint64_t *l_2327 = &g_2205[4][5].f2;
        uint64_t *l_2328 = &g_2283.f2;
        uint64_t *l_2329 = &g_2284[3][0].f2;
        uint64_t *l_2330 = &g_868.f2;
        uint64_t *l_2331 = &g_142;
        uint32_t *l_2332 = &g_2275.f1;
        uint32_t *l_2333[6][2][7] = {{{&g_196[5],(void*)0,&g_196[5],(void*)0,&g_196[5],(void*)0,&g_196[5]},{&g_196[0],&g_196[5],(void*)0,&g_196[6],&g_196[0],&g_196[5],(void*)0}},{{&g_196[5],&g_196[0],&g_196[8],(void*)0,&g_196[8],&g_196[0],&g_196[5]},{&g_196[0],&g_196[6],(void*)0,&g_196[0],&g_196[5],&g_196[5],(void*)0}},{{&g_196[5],&g_196[0],&g_196[5],&g_196[7],&g_196[5],&g_196[7],&g_196[5]},{&g_196[5],&g_196[5],(void*)0,(void*)0,&g_196[0],&g_196[5],&g_196[6]}},{{&g_196[8],(void*)0,&g_196[8],&g_196[7],&g_196[5],(void*)0,&g_196[5]},{&g_196[0],(void*)0,(void*)0,&g_196[0],&g_196[0],(void*)0,&g_196[5]}},{{&g_196[5],(void*)0,&g_196[5],(void*)0,&g_196[5],(void*)0,&g_196[5]},{&g_196[5],&g_196[5],&g_196[6],&g_196[6],&g_196[5],&g_196[5],&g_196[5]}},{{&g_196[5],&g_196[7],&g_196[8],(void*)0,&g_196[8],&g_196[7],&g_196[5]},{&g_196[5],&g_196[6],&g_196[5],&g_196[0],&g_196[0],&g_196[5],&g_196[6]}}};
        int16_t l_2334 = 0L;
        uint8_t l_2366 = 0x30L;
        union U1 ***l_2488 = &g_1206;
        int8_t *l_2533 = &g_119;
        int32_t *l_2547[4][1] = {{&g_798.f0},{&g_121},{&g_798.f0},{&g_121}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2310[i] = &g_2205[4][5].f0;
        l_2312 &= (func_6(l_2310[2], l_2303[1], (g_2311 , l_2303[1]), p_3) , p_3);
        if ((0xD4L == ((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*21*//* ___SAFE__OP */((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*22*//* ___SAFE__OP */((((*g_278) , ((***g_1567) ^= 0x45381C9BL)) , ((p_3 != ((((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*23*//* ___SAFE__OP */(18446744073709551615UL, p_3)) < ((g_196[1] &= (safe_unary_minus_func_uint16_t_u/* ___REMOVE_SAFE__OP *//*24*//* ___SAFE__OP */((((+((safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*25*//* ___SAFE__OP */(p_3, ((*l_2329) = ((*l_2331) ^= ((*l_2309) || ((p_3 == p_3) & g_2134)))))) != p_3)) , p_3) & p_3)))) == g_415)) , (*g_790)) <= 65535UL)) || 0L)), l_2334)), p_3)) && p_3)))
        { /* block id: 924 */
            uint16_t l_2337 = 0x5534L;
            int32_t l_2423 = 0xEC24A879L;
            int32_t l_2424 = 0xA3D5FEECL;
            const uint16_t *l_2440[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
            const uint16_t **l_2439 = &l_2440[1];
            int i;
            for (g_68 = 4; (g_68 >= 2); g_68--)
            { /* block id: 927 */
                const uint16_t l_2342[7] = {0x6C71L,0x6C71L,65535UL,0x6C71L,0x6C71L,65535UL,0x6C71L};
                int32_t *l_2451 = &g_389.f0;
                int i;
                if (l_2337)
                    break;
                for (g_1119 = 0; (g_1119 <= 1); g_1119 += 1)
                { /* block id: 931 */
                    int8_t *****l_2339 = &l_2338;
                    int8_t *****l_2341 = &l_2340[1][0][0];
                    int32_t **l_2343 = &l_2303[0];
                    uint16_t ***l_2441[8][5] = {{(void*)0,&g_2068,&g_2068,(void*)0,&g_2068},{&g_2068,&g_2068,&g_2068,&g_2068,&g_2068},{&g_2068,(void*)0,&g_2068,&g_2068,(void*)0},{&g_2068,&g_2068,&g_2068,&g_2068,(void*)0},{&g_2068,(void*)0,(void*)0,(void*)0,&g_2068},{&g_2068,&g_2068,&g_2068,(void*)0,&g_2068},{&g_2068,&g_2068,&g_2068,&g_2068,&g_2068},{&g_2068,&g_2068,&g_2068,&g_2068,&g_2068}};
                    int i, j;
                    if ((((*l_2339) = l_2338) == ((*l_2341) = l_2340[1][0][0])))
                    { /* block id: 934 */
                        uint8_t l_2365 = 0UL;
                        uint16_t *l_2380 = (void*)0;
                        uint16_t *l_2381 = &l_2312;
                        uint8_t *l_2425 = &g_415;
                        const int32_t l_2426 = 0x54F23DFBL;
                        int i;
                        (*l_2309) = (l_2342[4] , ((void*)0 == l_2343));
                        (*l_2343) = func_16(((((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*26*//* ___SAFE__OP */(((safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*27*//* ___SAFE__OP */(0x58L, (p_3 || g_198[6][5][0]))) >= (safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*28*//* ___SAFE__OP */((safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*29*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*30*//* ___SAFE__OP */((((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*31*//* ___SAFE__OP */((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*32*//* ___SAFE__OP */(p_3, l_2337)), (~l_2342[4]))) == (safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*33*//* ___SAFE__OP */((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*34*//* ___SAFE__OP */(4294967291UL, (p_3 , (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*35*//* ___SAFE__OP */(((((((((p_3 <= 0x9966L) | p_3) , l_2365) != g_119) , (**g_2068)) >= p_3) <= p_3) , 0xB7L), p_3))))), p_3))) > 0xF91F6B071CE904CDLL), 40)), 1UL)), p_3))), 0x54L)) , (-1L)) != l_2366) | l_2337), (*l_2343), l_2337, p_3);
                        g_1343.f0 |= (safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*36*//* ___SAFE__OP */((safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*37*//* ___SAFE__OP */(0xB3L, (~(safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*38*//* ___SAFE__OP */((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*39*//* ___SAFE__OP */((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*40*//* ___SAFE__OP */(((((*l_2381) = (++(*g_2069))) <= (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*41*//* ___SAFE__OP */(((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*42*//* ___SAFE__OP */(((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*43*//* ___SAFE__OP */((((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*44*//* ___SAFE__OP */(((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*45*//* ___SAFE__OP */((((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*46*//* ___SAFE__OP */((safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*47*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*48*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*49*//* ___SAFE__OP */(((*l_2425) ^= (safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*50*//* ___SAFE__OP */(((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*51*//* ___SAFE__OP */(((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*52*//* ___SAFE__OP */((p_3 ^ 4L), ((l_2342[4] < p_3) | (((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*53*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*54*//* ___SAFE__OP */(((g_1587 , ((((*g_790) , (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*55*//* ___SAFE__OP */((g_2414[3] , (((((*l_2309) = (l_2423 = (safe_lshift_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*56*//* ___SAFE__OP */((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*57*//* ___SAFE__OP */(((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*58*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*59*//* ___SAFE__OP */(l_2342[4], 0x8797L)), 1L)) | 255UL), 0x2BDA4FDBC366FF5FLL)), 27)))) && 0x1534744AL) , p_3) ^ (-1L))), p_3))) == p_3) || l_2342[4])) == p_3), 255UL)), l_2424)) != 0UL) && (*g_1145))))) & l_2342[4]), p_3)) == p_3), l_2424))), l_2365)), 60)), 6)), (**g_1144))) <= p_3) , l_2426), 0L)) < l_2365), l_2426)) | p_3) , p_3), l_2337)) != 0x704B525832669E62LL), 0x5235L)) & 0xCDL), l_2342[5]))) | p_3), p_3)), 40)), p_3))))), p_3));
                    }
                    else
                    { /* block id: 943 */
                        int64_t l_2430[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2430[i] = 1L;
                        (**l_2343) = (((*g_1145) ^= (((safe_div_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*60*//* ___SAFE__OP */((((safe_unary_minus_func_int64_t_s/* ___REMOVE_SAFE__OP *//*61*//* ___SAFE__OP */(l_2424)) < (*l_2309)) != ((l_2430[2] != (safe_lshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*62*//* ___SAFE__OP */(((*g_2069) = 0x074BL), 8))) || p_3)), 0xD6E77E33L)) , 0xA04C897B4F3EC932LL) , (p_3 | ((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*63*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*64*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*65*//* ___SAFE__OP */((p_3 <= l_2423), 2)) <= p_3), 5)), p_3)) , 247UL)))) < p_3);
                        if (l_2342[4])
                            continue;
                    }
                    if ((((((void*)0 == &g_721) , l_2439) != (g_2068 = (void*)0)) , ((((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*66*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*67*//* ___SAFE__OP */(g_1387, 31)), ((*****l_2339) = p_3))) == p_3) <= ((*l_2309) = (l_2423 = (*g_80)))) <= ((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*68*//* ___SAFE__OP */((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*69*//* ___SAFE__OP */(0x9CB204CEL, p_3)), l_2424)) == p_3))))
                    { /* block id: 953 */
                        int32_t *l_2450 = &g_1947.f0;
                        (*l_2343) = l_2450;
                        (*l_2450) &= p_3;
                        (*l_2309) &= l_2342[4];
                        (*l_2343) = l_2451;
                    }
                    else
                    { /* block id: 958 */
                        int32_t *l_2452 = &g_81;
                        return l_2452;
                    }
                    return l_2451;
                }
            }
        }
        else
        { /* block id: 964 */
            uint64_t l_2455 = 0x784057810B6CD385LL;
            int16_t *l_2465 = &l_2334;
            union U2 * const *l_2473 = &g_829;
            union U2 * const **l_2472 = &l_2473;
            uint32_t l_2474 = 0UL;
            int32_t l_2479 = 5L;
            int32_t l_2480 = 0xD11B3277L;
            int32_t l_2481[7];
            union U1 ***l_2487 = (void*)0;
            union U2 *l_2523 = (void*)0;
            int i;
            for (i = 0; i < 7; i++)
                l_2481[i] = 0x4C083527L;
        }
    }
    else
    { /* block id: 1016 */
        uint32_t **l_2570 = &g_1079;
        int32_t l_2575[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i;
        l_2575[2] = (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*70*//* ___SAFE__OP */(0xF0L, (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*71*//* ___SAFE__OP */(((*l_2309) != (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*72*//* ___SAFE__OP */((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*73*//* ___SAFE__OP */((((*g_1567) = l_2570) != l_2570), ((p_3 , 1UL) || ((((((void*)0 == l_2573) >= ((~((((****g_1451) <= p_3) & p_3) , p_3)) <= (*l_2309))) == p_3) , p_3) < 0x094CEFB8L)))), l_2575[3]))), p_3))));
    }
    return l_2303[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_1822 g_1399 g_343 g_868.f0 g_1740.f0 g_1142 g_1145 g_1610.f0 g_1880 g_1397 g_1398 g_1793 g_81 g_119 g_1343.f0 g_621 g_1143 g_79 g_1386 g_1567 g_1078 g_67 g_790 g_791 g_61 g_590 g_1079 g_1925 g_389.f0 g_196 g_1610 g_618 g_13 g_618.f0 g_1807 g_1947 g_415 g_1239 g_1956 g_1460 g_1959 g_222 g_389 g_1973 g_828 g_829 g_466 g_1974 g_2284 g_2284.f0
 * writes: g_79 g_868.f0 g_1740.f0 g_1143 g_621 g_1611.f1 g_1343.f0 g_67 g_1386 g_1144 g_1079 g_13 g_1807 g_1461 g_1959 g_1354.f0 g_2284.f0
 */
static union U0  func_6(int32_t * p_7, int32_t * p_8, int32_t * p_9, int32_t  p_10)
{ /* block id: 749 */
    int16_t * const *** const l_1825 = &g_1427;
    int32_t l_1826 = 0x6ACED11CL;
    uint16_t *l_1829[6];
    const uint32_t ***l_1830 = &g_1397;
    int8_t ****l_1832 = &g_1452;
    int8_t *****l_1831[2][5] = {{&l_1832,&l_1832,&l_1832,&l_1832,&l_1832},{&l_1832,&l_1832,&l_1832,&l_1832,&l_1832}};
    int16_t ***l_1833 = &g_1144;
    uint64_t *l_1846[10] = {&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61};
    int32_t l_1847 = 5L;
    int64_t *l_1848 = &g_1740.f1;
    int32_t l_1849[4][1] = {{0L},{1L},{0L},{1L}};
    int8_t **l_1893 = &g_278;
    union U1 *l_1998[7][5] = {{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907},{(void*)0,&g_1925[0][0],&g_1925[0][0],(void*)0,&g_907}};
    const uint64_t l_2011 = 18446744073709551612UL;
    int64_t l_2063 = 0xA8D8DCDEF169A8A8LL;
    uint16_t **l_2081 = &l_1829[2];
    int8_t l_2166 = 0x70L;
    const int32_t *l_2210 = &g_2184.f0;
    int8_t ** const l_2236 = &g_278;
    uint8_t l_2250 = 0x5DL;
    int i, j;
    for (i = 0; i < 6; i++)
        l_1829[i] = &g_13;
    (*p_8) = (safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*74*//* ___SAFE__OP */((((((&g_1078 == (((((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*75*//* ___SAFE__OP */((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*76*//* ___SAFE__OP */(1L, (g_1822 , g_1399[3]))), 2)) | (g_79 = (safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*77*//* ___SAFE__OP */(((void*)0 == l_1825), ((((l_1826 , 0x8446A8E2L) == (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*78*//* ___SAFE__OP */((4294967295UL && l_1826), 0x9CL))) > l_1826) <= l_1826))))) < g_343) > p_10) , l_1830)) , l_1831[1][4]) != (void*)0) , (*p_8)) > l_1826), 11));
    if ((((*g_1142) = l_1833) != (((l_1849[1][0] &= (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*79*//* ___SAFE__OP */((p_10 > (((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*80*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*81*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*82*//* ___SAFE__OP */((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*83*//* ___SAFE__OP */(p_10, (l_1826 = (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*84*//* ___SAFE__OP */((-1L), ((*g_1145) = l_1826)))))), g_1610.f0)), 7)), ((*p_9) = l_1847))) & 0L) , (((l_1847 || (-9L)) , (void*)0) == &g_1587))), 0L))) , 0x882470E504131243LL) , (void*)0)))
    { /* block id: 757 */
        int64_t l_1860[10] = {(-3L),0xF2F483711F1C1A1BLL,0xF2F483711F1C1A1BLL,(-3L),0xF2F483711F1C1A1BLL,0xF2F483711F1C1A1BLL,(-3L),0xF2F483711F1C1A1BLL,0xF2F483711F1C1A1BLL,(-3L)};
        uint32_t *l_1871 = &g_1611.f1;
        int16_t ***l_1881 = (void*)0;
        uint64_t l_1882 = 0xB2C0CEEC9F54C859LL;
        int16_t l_1912 = (-1L);
        int32_t l_1943 = 0xA2E543A3L;
        int32_t *l_1975 = (void*)0;
        int32_t *l_1976 = (void*)0;
        int32_t *l_1977 = (void*)0;
        int32_t *l_1978[7][8][2] = {{{&g_68,&g_1354.f0},{(void*)0,&g_886[0].f0},{(void*)0,&g_1354.f0},{&g_68,&g_389.f0},{&g_1354.f0,&g_798.f0},{&g_618.f0,&g_68},{&g_81,&l_1847},{&l_1847,&g_85.f0}},{{&l_1847,&g_81},{&g_886[0].f0,&g_68},{&g_68,&g_886[0].f0},{&g_389.f0,&g_85.f0},{&g_618.f0,(void*)0},{(void*)0,(void*)0},{&g_85.f0,&l_1847},{(void*)0,&g_68}},{{(void*)0,&l_1847},{&g_1354.f0,(void*)0},{&g_68,&g_389.f0},{&g_68,(void*)0},{&g_1354.f0,&l_1847},{(void*)0,&g_68},{(void*)0,&l_1847},{&g_85.f0,(void*)0}},{{(void*)0,(void*)0},{&g_618.f0,&g_85.f0},{&g_389.f0,&g_886[0].f0},{&l_1847,&g_886[0].f0},{&g_389.f0,&g_85.f0},{&g_618.f0,(void*)0},{(void*)0,(void*)0},{&g_85.f0,&l_1847}},{{(void*)0,&g_68},{(void*)0,&l_1847},{&g_1354.f0,(void*)0},{&g_68,&g_389.f0},{&g_68,(void*)0},{&g_1354.f0,&l_1847},{(void*)0,&g_68},{(void*)0,&l_1847}},{{&g_85.f0,(void*)0},{(void*)0,(void*)0},{&g_618.f0,&g_85.f0},{&g_389.f0,&g_886[0].f0},{&l_1847,&g_886[0].f0},{&g_389.f0,&g_85.f0},{&g_618.f0,(void*)0},{(void*)0,(void*)0}},{{&g_85.f0,&l_1847},{(void*)0,&g_68},{(void*)0,&l_1847},{&g_1354.f0,(void*)0},{&g_68,&g_389.f0},{&g_68,(void*)0},{&g_1354.f0,&l_1847},{(void*)0,&g_68}}};
        uint32_t l_1979 = 18446744073709551615UL;
        int i, j, k;
        if ((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*85*//* ___SAFE__OP */((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*86*//* ___SAFE__OP */((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*87*//* ___SAFE__OP */(l_1826, 0xC2D1L)), ((((((safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*88*//* ___SAFE__OP */(((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*89*//* ___SAFE__OP */(l_1826, l_1860[8])) >= l_1849[1][0]), ((g_1343.f0 ^= (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*90*//* ___SAFE__OP */(((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*91*//* ___SAFE__OP */((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*92*//* ___SAFE__OP */((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*93*//* ___SAFE__OP */(((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*94*//* ___SAFE__OP */((((*l_1871) = 0x23D6790FL) , (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*95*//* ___SAFE__OP */((safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*96*//* ___SAFE__OP */((((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*97*//* ___SAFE__OP */((safe_rshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*98*//* ___SAFE__OP */((2L || (((g_1880 , (void*)0) != (**l_1830)) < g_1793)), 10)), p_10)) || (*p_9)) != p_10), p_10)), 8UL))), g_81)) & l_1860[7]), g_119)), 0x1F4AL)), l_1849[1][0])) && 1UL), l_1849[1][0]))) != l_1860[0]))) == g_621) , (*g_1142)) == l_1881) < p_10) == l_1849[0][0]))), l_1882)))
        { /* block id: 760 */
            int32_t **l_1883 = &g_67;
            int16_t **l_1909 = &g_1145;
            (*l_1883) = &l_1847;
            for (g_79 = 4; (g_79 >= 34); g_79 = safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*99*//* ___SAFE__OP */(g_79, 5))
            { /* block id: 764 */
                uint8_t *l_1888 = &g_1386;
                int32_t l_1891 = (-1L);
                int8_t **l_1892 = &g_278;
                int32_t l_1898 = 0L;
                int64_t *l_1930 = &l_1860[5];
                l_1898 &= (((p_10 && (safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*100*//* ___SAFE__OP */(((**l_1883) = (((((((*l_1888)++) , (((l_1893 = ((l_1891 != g_79) , l_1892)) != (void*)0) < (((l_1826 &= (l_1891 == (((-1L) < (safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*101*//* ___SAFE__OP */((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*102*//* ___SAFE__OP */(((((p_10 > p_10) != p_10) != 0xA7C87BDBL) && l_1891), 0xE2DBC869L)), l_1849[1][0]))) , 0UL))) , p_10) != 0xDC22B65E501EB831LL))) , (*g_1567)) != (void*)0) , 65533UL) & l_1882)), 15))) ^ 0L) <= (*g_790));
                if ((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*103*//* ___SAFE__OP */((l_1849[1][0] != ((void*)0 == (*g_1567))), (safe_rshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*104*//* ___SAFE__OP */(((l_1826 ^= l_1898) & (safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*105*//* ___SAFE__OP */((0x873528A2L > (((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*106*//* ___SAFE__OP */((safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*107*//* ___SAFE__OP */((((**g_1142) = l_1909) == (void*)0), (((((g_61 >= ((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*108*//* ___SAFE__OP */(p_10, p_10)) >= (**g_590))) < p_10) , &l_1829[5]) != (void*)0) ^ l_1912))), 2)) >= (*g_67)) > l_1882)), 14))), 13)))))
                { /* block id: 772 */
                    uint64_t l_1915[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1915[i] = 8UL;
                    (*p_9) = ((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*109*//* ___SAFE__OP */((((((**g_1567) = (**g_1567)) != l_1871) == l_1915[6]) , (**l_1883)), 27)) & (((safe_lshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*110*//* ___SAFE__OP */((+(((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*111*//* ___SAFE__OP */((((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*112*//* ___SAFE__OP */((((void*)0 == &g_1078) , ((0xCCL < (safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*113*//* ___SAFE__OP */(((((((g_1925[1][0] , (p_10 , l_1915[4])) | 0x144139F4D2EE5FE2LL) >= p_10) , (void*)0) == l_1871) , p_10), (**l_1883)))) & 0x6FL)), p_10)) || g_389.f0) && l_1847), l_1826)) >= (**l_1883)) , g_196[5])), 28)) && l_1891) , l_1860[8]));
                    if ((*p_9))
                        continue;
                }
                else
                { /* block id: 776 */
                    uint32_t ** const l_1941[2] = {&l_1871,&l_1871};
                    int32_t l_1942 = (-1L);
                    int16_t l_1944[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1944[i] = 1L;
                    l_1943 &= (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*114*//* ___SAFE__OP */((l_1891 &= ((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*115*//* ___SAFE__OP */((p_10 > (g_1610 , (((g_618 , &g_473) != l_1930) <= p_10))), ((((((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*116*//* ___SAFE__OP */((~(l_1898 = (g_13 |= (safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*117*//* ___SAFE__OP */((!(safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*118*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*119*//* ___SAFE__OP */(((l_1941[1] != l_1941[0]) >= ((p_10 > 1L) <= (**l_1883))), p_10)) , 8L), p_10))), 0xBCL))))), g_618.f0)) , &g_81) != &p_10) , 1L) , g_621) & p_10))) >= l_1942)), p_10));
                    (**l_1883) = l_1944[0];
                }
            }
        }
        else
        { /* block id: 784 */
            for (g_1807 = 15; (g_1807 >= 13); g_1807 = safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*120*//* ___SAFE__OP */(g_1807, 2))
            { /* block id: 787 */
                return g_1947;
            }
        }
        if ((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*121*//* ___SAFE__OP */((((((l_1912 > p_10) | ((l_1847 , (((((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*122*//* ___SAFE__OP */((-1L), (((safe_div_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*123*//* ___SAFE__OP */(0xD713093A35E2C721LL, (g_791 | p_10))) == (((((safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*124*//* ___SAFE__OP */((g_1807 && 0xD90C5C0CL), l_1849[0][0])) <= 0UL) , 0x19593351898EF398LL) == 0x9C8AAD25BA878B77LL) , l_1882)) && p_10))) <= 0xA7L) || p_10) >= p_10) | l_1860[8])) || g_415)) , l_1826) <= g_1239) < l_1943), g_1956)))
        { /* block id: 791 */
            (*g_1460) = &l_1943;
        }
        else
        { /* block id: 793 */
            int32_t *l_1957 = (void*)0;
            int32_t *l_1958[7][1] = {{&g_121},{&g_1343.f0},{&g_121},{&g_1343.f0},{&g_121},{&g_1343.f0},{&g_121}};
            int16_t ****l_1972 = &g_1143[5];
            int i, j;
            --g_1959;
            (*p_9) |= (safe_mod_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*125*//* ___SAFE__OP */((-1L), 0x0EL));
            (*g_1974) = func_16(p_10, &p_10, (0xBDL & (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*126*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*127*//* ___SAFE__OP */((*p_9), 20)), (((p_10 == ((((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*128*//* ___SAFE__OP */(((g_222 , (safe_lshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*129*//* ___SAFE__OP */(((**g_1567) == (**l_1830)), (g_389 , p_10)))) & g_61), p_10)) , &l_1881) != l_1972) || g_1973)) < p_10) & l_1912)))), g_1807);
        }
        l_1979++;
    }
    else
    { /* block id: 799 */
        int16_t l_1997 = 0x3656L;
        uint16_t *l_2004[5][8][6] = {{{(void*)0,(void*)0,&g_13,&g_79,&g_79,&g_79},{(void*)0,(void*)0,(void*)0,&g_79,&g_13,&g_13},{&g_13,(void*)0,(void*)0,&g_13,(void*)0,&g_79},{&g_79,&g_13,&g_13,&g_13,&g_79,&g_79},{&g_13,&g_79,&g_79,&g_79,&g_79,&g_13},{(void*)0,&g_13,(void*)0,&g_79,(void*)0,&g_13},{(void*)0,(void*)0,&g_79,&g_13,&g_13,&g_79},{(void*)0,(void*)0,&g_13,&g_79,&g_79,&g_79}},{{(void*)0,(void*)0,(void*)0,&g_79,&g_13,&g_13},{&g_13,(void*)0,(void*)0,&g_13,(void*)0,&g_79},{&g_79,&g_13,&g_13,&g_13,&g_79,&g_79},{&g_13,&g_79,&g_79,&g_79,&g_79,&g_13},{(void*)0,&g_13,(void*)0,&g_79,(void*)0,&g_13},{(void*)0,(void*)0,&g_79,&g_13,&g_13,&g_79},{(void*)0,(void*)0,&g_13,&g_79,&g_79,&g_79},{(void*)0,&g_79,&g_79,&g_13,(void*)0,(void*)0}},{{(void*)0,&g_79,&g_79,(void*)0,&g_79,&g_79},{&g_79,(void*)0,(void*)0,(void*)0,&g_79,&g_13},{(void*)0,&g_79,&g_13,&g_13,&g_79,(void*)0},{&g_79,(void*)0,&g_79,&g_79,&g_79,(void*)0},{&g_79,&g_79,&g_13,(void*)0,(void*)0,&g_13},{&g_79,&g_79,(void*)0,&g_79,&g_13,&g_79},{&g_79,&g_79,&g_79,&g_13,(void*)0,(void*)0},{(void*)0,&g_79,&g_79,(void*)0,&g_79,&g_79}},{{&g_79,(void*)0,(void*)0,(void*)0,&g_79,&g_13},{(void*)0,&g_79,&g_13,&g_13,&g_79,(void*)0},{&g_79,(void*)0,&g_79,&g_79,&g_79,(void*)0},{&g_79,&g_79,&g_13,(void*)0,(void*)0,&g_13},{&g_79,&g_79,(void*)0,&g_79,&g_13,&g_79},{&g_79,&g_79,&g_79,&g_13,(void*)0,(void*)0},{(void*)0,&g_79,&g_79,(void*)0,&g_79,&g_79},{&g_79,(void*)0,(void*)0,(void*)0,&g_79,&g_13}},{{(void*)0,&g_79,&g_13,&g_13,&g_79,(void*)0},{&g_79,(void*)0,&g_79,&g_79,&g_79,(void*)0},{&g_79,&g_79,&g_13,(void*)0,(void*)0,&g_13},{&g_79,&g_79,(void*)0,&g_79,&g_13,&g_79},{&g_79,&g_79,&g_79,&g_13,(void*)0,(void*)0},{(void*)0,&g_79,&g_79,(void*)0,&g_79,&g_79},{&g_79,(void*)0,(void*)0,(void*)0,&g_79,&g_13},{(void*)0,&g_79,&g_13,&g_13,&g_79,(void*)0}}};
        int8_t ****l_2057[9] = {&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452};
        int32_t l_2115 = 1L;
        uint32_t l_2117 = 0xB3943BFAL;
        int32_t l_2158 = 0x8F13B9BCL;
        uint8_t l_2159 = 0x41L;
        int32_t l_2171 = 0x384A1D15L;
        const uint64_t *l_2173 = &g_61;
        const uint64_t **l_2172[1][5][5] = {{{&l_2173,&l_2173,&l_2173,&l_2173,&l_2173},{&l_2173,(void*)0,&l_2173,&l_2173,(void*)0},{&l_2173,&l_2173,&l_2173,&l_2173,&l_2173},{(void*)0,(void*)0,&l_2173,(void*)0,(void*)0},{&l_2173,&l_2173,&l_2173,&l_2173,&l_2173}}};
        uint32_t *l_2180[6][9][4] = {{{&g_196[5],&g_196[5],&g_196[8],&g_196[8]},{(void*)0,&g_196[5],&g_196[8],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]}},{{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]}},{{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]}},{{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]}},{{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]},{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[8],&g_196[8]}},{{&g_196[8],&g_196[8],&g_196[5],&g_196[4]},{&g_196[8],&g_196[8],&g_196[5],&g_196[8]},{&g_196[5],&g_196[3],&g_196[5],&g_196[7]},{&g_196[8],&g_196[5],&g_196[5],&g_196[7]},{&g_196[8],&g_196[3],&g_196[5],&g_196[4]},{&g_196[5],&g_196[4],&g_196[8],&g_196[7]},{&g_196[5],&g_196[4],(void*)0,&g_196[4]},{&g_196[8],&g_196[5],(void*)0,&g_196[3]},{&g_196[5],&g_196[8],&g_196[8],&g_196[3]}}};
        int32_t l_2198 = 0xAA44517EL;
        const int32_t *l_2206 = &g_121;
        const uint32_t **l_2229[8];
        int32_t l_2246 = 0x4652F45EL;
        int32_t l_2247 = 0xACDFD619L;
        int32_t l_2248[3][1][6] = {{{1L,0x5B1B3C5BL,0x64780F70L,1L,0x64780F70L,0x5B1B3C5BL}},{{0L,0x5B1B3C5BL,0x4F7817E0L,0L,0x64780F70L,0x64780F70L}},{{0xC2E480DAL,0x5B1B3C5BL,0x5B1B3C5BL,0xC2E480DAL,0x64780F70L,0x4F7817E0L}}};
        uint32_t l_2277 = 0x9DEDE5F5L;
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2229[i] = (void*)0;
    }
    return g_2284[3][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_198 g_389.f0 g_13 g_1392 g_343 g_1426 g_1399 g_828 g_829 g_466 g_1145 g_621 g_67 g_1144 g_1445 g_798.f0 g_1386 g_1451 g_1460 g_235 g_403 g_196 g_278 g_119 g_79 g_1461 g_1354.f0 g_523 g_1142 g_1143 g_789 g_790 g_791 g_61 g_618.f0 g_1537 g_1239 g_721 g_353 g_349 g_122 g_121 g_1452 g_1610 g_1611 g_1119 g_1507 g_277 g_1387 g_1740 g_1587 g_1301 g_68 g_1643 g_81 g_1774
 * writes: g_13 g_67 g_1426 g_1354.f0 g_1354.f2 g_1452 g_473 g_1461 g_403 g_119 g_415 g_621 g_61 g_1567 g_618.f0 g_79 g_1643 g_121 g_1587
 */
static union U1  func_11(uint8_t  p_12)
{ /* block id: 1 */
    int32_t l_50 = (-1L);
    int32_t l_51 = 0xA9C79EBEL;
    int64_t l_62[4];
    int32_t *l_107 = (void*)0;
    int32_t l_1371 = (-1L);
    int32_t l_1393 = (-1L);
    uint8_t l_1415 = 0x15L;
    uint16_t *l_1424 = (void*)0;
    int16_t ****l_1425 = &g_1143[3];
    union U1 **l_1448[7][5][1] = {{{&g_356},{(void*)0},{&g_356},{&g_356},{(void*)0}},{{&g_356},{&g_356},{(void*)0},{&g_356},{&g_356}},{{(void*)0},{&g_356},{&g_356},{(void*)0},{&g_356}},{{&g_356},{(void*)0},{&g_356},{&g_356},{(void*)0}},{{&g_356},{&g_356},{(void*)0},{&g_356},{&g_356}},{{(void*)0},{&g_356},{&g_356},{(void*)0},{&g_356}},{{&g_356},{(void*)0},{&g_356},{&g_356},{(void*)0}}};
    uint64_t l_1449 = 0x981A0971596AC86DLL;
    int8_t *l_1512 = &g_1239;
    int32_t **l_1520 = (void*)0;
    int32_t ***l_1519 = &l_1520;
    int32_t ****l_1518 = &l_1519;
    uint32_t l_1554 = 0x0BC5EDC5L;
    int32_t l_1592 = 0L;
    int32_t l_1593 = 0xB10E6219L;
    int32_t l_1594 = 5L;
    int32_t l_1595 = 0x813E0B79L;
    int32_t l_1596[3];
    uint64_t l_1597[6][3][9] = {{{0xC3D0099F76F4A972LL,0x32237FAE77F888DDLL,0xE2371F03D9C63115LL,18446744073709551615UL,0x7267692BEFCF30DFLL,0x8465C6195F213D27LL,18446744073709551615UL,18446744073709551611UL,0x865D4FEA19941903LL},{0xC3D0099F76F4A972LL,18446744073709551615UL,0xD9194A1A3FB81F0DLL,0x8465C6195F213D27LL,0x4EAC0B52FEDB2F10LL,0x4EAC0B52FEDB2F10LL,0x8465C6195F213D27LL,0xD9194A1A3FB81F0DLL,18446744073709551615UL},{18446744073709551614UL,1UL,0x7267692BEFCF30DFLL,0x661406A924C21360LL,0x84A722E9CDD1680ALL,0xBA57C1404EDA68F5LL,1UL,0xAEE37CD59B774A81LL,0UL}},{{5UL,6UL,0x32237FAE77F888DDLL,18446744073709551613UL,0xECAB726637A24806LL,0x2CBBE18C3F771DB8LL,0UL,0x013682793A67E4C9LL,0x84A722E9CDD1680ALL},{0x97FEFACD0E76FA44LL,1UL,18446744073709551609UL,18446744073709551615UL,18446744073709551615UL,0x5363327C8174DD96LL,0UL,0x84A722E9CDD1680ALL,0xAEE37CD59B774A81LL},{18446744073709551611UL,18446744073709551615UL,18446744073709551615UL,0x6C05454257BA0937LL,18446744073709551615UL,0x32237FAE77F888DDLL,1UL,0x865D4FEA19941903LL,18446744073709551609UL}},{{1UL,0x32237FAE77F888DDLL,18446744073709551615UL,0x97FEFACD0E76FA44LL,0xBA57C1404EDA68F5LL,18446744073709551615UL,18446744073709551615UL,0xBA57C1404EDA68F5LL,0x97FEFACD0E76FA44LL},{18446744073709551609UL,5UL,18446744073709551609UL,0xBA57C1404EDA68F5LL,18446744073709551611UL,18446744073709551615UL,0xD9194A1A3FB81F0DLL,18446744073709551613UL,18446744073709551615UL},{0xBA57C1404EDA68F5LL,1UL,0x32237FAE77F888DDLL,18446744073709551615UL,18446744073709551609UL,1UL,0x661406A924C21360LL,0x97FEFACD0E76FA44LL,0x7267692BEFCF30DFLL}},{{18446744073709551615UL,0UL,0x7267692BEFCF30DFLL,0xBA57C1404EDA68F5LL,1UL,0xECAB726637A24806LL,1UL,18446744073709551615UL,6UL},{0x013682793A67E4C9LL,0xD04AC6B97C5C4CACLL,0xD9194A1A3FB81F0DLL,0x97FEFACD0E76FA44LL,0xD519CFEC0BC42AE1LL,1UL,18446744073709551615UL,0xE2371F03D9C63115LL,5UL},{0x5363327C8174DD96LL,1UL,0xE2371F03D9C63115LL,0x6C05454257BA0937LL,0xD519CFEC0BC42AE1LL,18446744073709551613UL,18446744073709551615UL,18446744073709551615UL,18446744073709551613UL}},{{1UL,18446744073709551615UL,0x2CBBE18C3F771DB8LL,18446744073709551615UL,1UL,1UL,0xC3D0099F76F4A972LL,18446744073709551609UL,1UL},{1UL,0x013682793A67E4C9LL,18446744073709551614UL,1UL,1UL,18446744073709551615UL,6UL,0xAEE37CD59B774A81LL,18446744073709551609UL},{6UL,0xD9194A1A3FB81F0DLL,0x84A722E9CDD1680ALL,18446744073709551615UL,0x661406A924C21360LL,0UL,18446744073709551613UL,18446744073709551615UL,6UL}},{{18446744073709551615UL,0xD519CFEC0BC42AE1LL,0x4EAC0B52FEDB2F10LL,5UL,0x7267692BEFCF30DFLL,1UL,18446744073709551615UL,4UL,0x5363327C8174DD96LL},{18446744073709551611UL,0x84A722E9CDD1680ALL,0x7267692BEFCF30DFLL,0x2201554312E6D239LL,1UL,0x865D4FEA19941903LL,18446744073709551615UL,5UL,5UL},{18446744073709551613UL,18446744073709551615UL,0xAEE37CD59B774A81LL,1UL,0xAEE37CD59B774A81LL,18446744073709551615UL,18446744073709551613UL,0UL,0xECAB726637A24806LL}}};
    uint16_t *l_1621 = &g_79;
    int64_t l_1628 = 0x37F51409A5B1748ELL;
    int32_t *l_1631 = &l_1594;
    const int16_t l_1632 = 8L;
    uint16_t **l_1634 = &l_1424;
    uint16_t ***l_1633 = &l_1634;
    uint8_t l_1635 = 0x0AL;
    int64_t l_1636 = 7L;
    uint64_t l_1637 = 0xD454BCAC6E3A8381LL;
    int64_t *l_1638[10][5] = {{&l_1628,&l_1628,&g_389.f1,&g_389.f1,&l_1628},{&l_62[1],&l_62[1],&l_62[1],&l_62[1],&l_62[1]},{&l_1628,&g_389.f1,&g_389.f1,&l_1628,&l_1628},{&l_1636,&l_62[1],&l_1636,&l_62[1],&l_1636},{&l_1628,&l_1628,&g_389.f1,&g_389.f1,&l_1628},{&l_62[1],&l_62[1],&l_62[1],&l_62[1],&l_62[1]},{&l_1628,&g_389.f1,&g_389.f1,&l_1628,&l_1628},{&l_1636,&l_62[1],&l_1636,&l_62[1],&l_1636},{&l_1628,&l_1628,&g_389.f1,&g_389.f1,&l_1628},{&l_62[1],&l_62[1],&l_62[1],&l_62[1],&l_62[1]}};
    uint16_t *l_1639 = &g_13;
    int32_t l_1735 = 0xCA4AED75L;
    union U1 ****l_1773 = &g_1205;
    union U1 *****l_1772[7] = {&l_1773,&l_1773,&l_1773,&l_1773,&l_1773,&l_1773,&l_1773};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_62[i] = 0xE4DDBB7A2E255BB5LL;
    for (i = 0; i < 3; i++)
        l_1596[i] = 0xBB4EBC26L;
    for (p_12 = 0; (p_12 > 42); p_12++)
    { /* block id: 4 */
        int32_t l_40 = 0x55C0C8FBL;
        uint64_t *l_60[7] = {&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61};
        int32_t *l_108 = &g_68;
        int8_t *l_1238 = &g_1239;
        uint8_t l_1382 = 0x1EL;
        uint8_t *l_1383 = &g_415;
        uint8_t *l_1388 = &l_1382;
        uint16_t l_1391 = 0xC0E7L;
        const uint32_t *l_1395 = &g_368;
        const uint32_t **l_1394 = &l_1395;
        const uint32_t ***l_1396[3];
        uint32_t ***l_1400 = &g_1078;
        uint32_t **l_1402 = (void*)0;
        uint32_t ***l_1401 = &l_1402;
        union U2 *l_1413 = &g_815;
        int i;
        for (i = 0; i < 3; i++)
            l_1396[i] = &l_1394;
    }
    if ((g_198[3][5][0] != ((p_12 | 0L) > g_389.f0)))
    { /* block id: 568 */
        uint16_t *l_1416[1];
        int32_t l_1417 = (-1L);
        union U2 **l_1423 = &g_829;
        union U2 ***l_1422 = &l_1423;
        int16_t * const ***l_1429 = (void*)0;
        int16_t * const ****l_1430 = (void*)0;
        int16_t * const ****l_1431 = &g_1426;
        int16_t * const ***l_1433[4] = {&g_1427,&g_1427,&g_1427,&g_1427};
        int16_t * const ****l_1432 = &l_1433[3];
        int32_t **l_1434 = &g_67;
        int i;
        for (i = 0; i < 1; i++)
            l_1416[i] = &g_13;
        (*l_1434) = func_16((++g_13), ((*g_1392) = &l_50), l_1417, ((((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*130*//* ___SAFE__OP */(((((*l_1422) = (g_343 , &g_829)) != (((void*)0 == l_1424) , &g_829)) > (l_1425 == ((*l_1432) = ((*l_1431) = (l_1429 = g_1426))))), l_1417)) == g_1399[0]) | l_1393) && 1L));
        (*l_1434) = (*l_1434);
    }
    else
    { /* block id: 577 */
        uint32_t l_1456 = 0xDB340B2BL;
        union U2 **l_1489 = &g_829;
        union U2 ***l_1488 = &l_1489;
        int32_t l_1494 = (-1L);
        const int16_t *l_1508 = (void*)0;
        int8_t ***l_1581 = (void*)0;
        int32_t *l_1586 = &g_1587;
        int32_t *l_1589 = &l_1494;
        int32_t *l_1591[5][3][6] = {{{&l_1371,&l_1371,&l_1393,&l_1371,&g_121,&g_618.f0},{&g_121,(void*)0,&g_798.f0,&g_389.f0,(void*)0,&l_1393},{&g_618.f0,&g_121,&g_798.f0,&g_618.f0,&l_1371,&g_618.f0}},{{&l_1393,&g_618.f0,&l_1393,&l_1494,&l_51,&g_868.f0},{&l_1494,&l_51,&g_868.f0,(void*)0,(void*)0,&g_121},{&l_1371,&g_868.f0,(void*)0,(void*)0,&l_1494,&l_1494}},{{&l_1494,(void*)0,(void*)0,&l_1494,&g_121,(void*)0},{&l_1393,&l_1371,&g_121,&g_618.f0,(void*)0,&g_798.f0},{&g_618.f0,(void*)0,&l_1371,&g_389.f0,(void*)0,&l_51}},{{&g_121,&l_1371,&l_1494,&l_1371,&g_121,&g_389.f0},{&l_1371,(void*)0,(void*)0,(void*)0,&l_1494,&g_618.f0},{(void*)0,&g_868.f0,&g_121,(void*)0,(void*)0,&g_618.f0}},{{&g_389.f0,&l_51,(void*)0,(void*)0,&l_51,&g_389.f0},{(void*)0,&g_618.f0,&l_1494,(void*)0,&g_618.f0,(void*)0},{&g_868.f0,&l_1371,&g_618.f0,&g_121,&g_798.f0,&g_618.f0}}};
        int i, j, k;
        if ((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*131*//* ___SAFE__OP */(((p_12 ^ (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*132*//* ___SAFE__OP */((((safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*133*//* ___SAFE__OP */(((((**g_1144) >= p_12) , &p_12) != &g_1386), (safe_lshift_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*134*//* ___SAFE__OP */(p_12, 10)))) >= ((safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*135*//* ___SAFE__OP */((g_1445[3][2] , (p_12 == (((l_1448[0][3][0] != l_1448[3][2][0]) != l_1449) <= g_798.f0))), 1UL)) ^ g_1386)) & 0xF8L), g_343))) != 0x22L), (-1L))))
        { /* block id: 578 */
            uint8_t l_1486 = 255UL;
            int32_t l_1511 = 9L;
            uint32_t l_1538 = 0x954E4B4EL;
            const int8_t *l_1550[9] = {&g_1239,&g_1239,&g_1239,&g_1239,&g_1239,&g_1239,&g_1239,&g_1239,&g_1239};
            const int8_t **l_1549 = &l_1550[0];
            const int8_t ***l_1548 = &l_1549;
            const int8_t ****l_1547 = &l_1548;
            int16_t l_1553[2][6][8] = {{{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L}},{{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L},{0xEA0DL,0L,0xEA0DL,0x0FA7L,0xEA0DL,0L,0xEA0DL,0x0FA7L}}};
            uint32_t ***l_1568 = &g_1078;
            int i, j, k;
            for (l_1415 = 0; (l_1415 <= 3); l_1415 += 1)
            { /* block id: 581 */
                int64_t l_1487 = 0L;
                for (g_1354.f2 = 0; (g_1354.f2 <= 3); g_1354.f2 += 1)
                { /* block id: 584 */
                    int8_t ***l_1450[2][3][1] = {{{&g_277[0]},{&g_277[1]},{&g_277[0]}},{{&g_277[1]},{&g_277[0]},{&g_277[1]}}};
                    int32_t *l_1453 = (void*)0;
                    int32_t *l_1454 = (void*)0;
                    int32_t l_1455 = 1L;
                    int i, j, k;
                    (*g_1451) = l_1450[0][0][0];
                    l_1456++;
                    (*g_1392) = (void*)0;
                }
                for (g_473 = 3; (g_473 >= 0); g_473 -= 1)
                { /* block id: 591 */
                    int32_t **l_1459 = &g_67;
                    (*g_1460) = ((*l_1459) = &l_1371);
                    (**g_235) = 0x2A877370L;
                    for (g_403 = 3; (g_403 >= 0); g_403 -= 1)
                    { /* block id: 597 */
                        uint8_t l_1465 = 0xA7L;
                        union U2 ****l_1490 = &l_1488;
                        int32_t l_1491[5][10] = {{1L,3L,1L,3L,1L,3L,1L,3L,1L,3L},{1L,3L,1L,3L,1L,3L,1L,3L,1L,3L},{1L,3L,1L,3L,1L,3L,1L,3L,1L,3L},{1L,3L,1L,3L,1L,3L,1L,3L,1L,3L},{1L,3L,1L,3L,1L,3L,1L,3L,1L,3L}};
                        uint8_t *l_1492 = &l_1486;
                        uint16_t *l_1493 = &g_13;
                        int i, j;
                        (*g_1461) = ((!l_1465) || (((l_1456 ^ l_1465) || (safe_sub_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*136*//* ___SAFE__OP */((safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*137*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*138*//* ___SAFE__OP */(p_12, ((((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*139*//* ___SAFE__OP */(((*l_1493) |= ((safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*140*//* ___SAFE__OP */(((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*141*//* ___SAFE__OP */(0xA054E0A9L, (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*142*//* ___SAFE__OP */(((**g_235) & (g_196[5] | ((*g_278) = ((safe_rshift_func_uint16_t_u_s/* ___REMOVE_SAFE__OP *//*143*//* ___SAFE__OP */(((+(((((0xADL == ((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*144*//* ___SAFE__OP */((((*l_1492) = (l_1491[4][1] = (((*l_1490) = ((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*145*//* ___SAFE__OP */((l_1486 <= l_1487), l_1486)) , l_1488)) != (void*)0))) & l_1487), 5)) != (**g_1144))) & p_12) < 0xC4L) , (*g_278)) >= (*g_278))) , g_79), 15)) & p_12)))), 0x44L)))) == p_12))) >= (**l_1459))), p_12)) < 4294967290UL) & p_12) , (**l_1459)))) && p_12), 0x6CL)), p_12))) < l_1456));
                    }
                }
            }
            for (l_1371 = 1; (l_1371 >= 0); l_1371 -= 1)
            { /* block id: 609 */
                uint32_t l_1495 = 1UL;
                int32_t *l_1513 = &g_618.f0;
                int16_t * const *l_1527 = &g_1145;
                uint8_t *l_1551 = &l_1415;
                uint16_t l_1555 = 0x5CC7L;
                uint32_t ***l_1566 = &g_1078;
                if (l_1456)
                { /* block id: 610 */
                    l_1494 = 0xECF339FDL;
                    for (g_1354.f0 = 0; (g_1354.f0 <= 1); g_1354.f0 += 1)
                    { /* block id: 614 */
                        int32_t *l_1496[4][5] = {{&g_68,&g_1354.f0,&g_1354.f0,&g_68,&g_1354.f0},{&g_798.f0,&g_798.f0,&g_81,&g_798.f0,&g_798.f0},{&g_1354.f0,&g_68,&g_1354.f0,&g_1354.f0,&g_68},{&g_798.f0,(void*)0,(void*)0,&g_798.f0,(void*)0}};
                        int i, j;
                        l_1494 |= l_1495;
                    }
                }
                else
                { /* block id: 617 */
                    int16_t *l_1502 = &g_621;
                    const int16_t *l_1506 = &g_1507[0][1][4];
                    const int16_t **l_1505[10] = {&l_1506,&l_1506,&l_1506,&l_1506,&l_1506,&l_1506,&l_1506,&l_1506,&l_1506,&l_1506};
                    uint32_t *l_1509 = &g_196[5];
                    uint32_t *l_1510[1];
                    uint32_t l_1514 = 18446744073709551615UL;
                    uint16_t *l_1515 = (void*)0;
                    uint16_t *l_1516 = &g_13;
                    uint8_t *l_1517 = (void*)0;
                    int32_t *l_1535[2];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1510[i] = &l_1456;
                    for (i = 0; i < 2; i++)
                        l_1535[i] = &g_618.f0;
                    if (((((safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*146*//* ___SAFE__OP */(g_79, ((g_415 = ((18446744073709551615UL >= (safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*147*//* ___SAFE__OP */(((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*148*//* ___SAFE__OP */(((*l_1516) = ((g_523 , &l_1456) != &l_1495)), 8UL)) , p_12)))) ^ 0x48L)) , 5L))) , (void*)0) == l_1518) >= p_12))
                    { /* block id: 624 */
                        uint16_t l_1521 = 0x9135L;
                        uint8_t *l_1533 = &g_415;
                        uint64_t *l_1534 = &g_61;
                        l_1535[0] = func_16(l_1521, &l_1494, (((((safe_rshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*149*//* ___SAFE__OP */(l_1456, 0)) != 0UL) || ((~(l_1494 = l_1511)) ^ (((*l_1534) ^= (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*150*//* ___SAFE__OP */((((((void*)0 == l_1527) >= (18446744073709551606UL || (+(safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*151*//* ___SAFE__OP */(((safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*152*//* ___SAFE__OP */(((****g_1142) ^= (((*l_1533) = p_12) | p_12)), l_1521)) | 1L), 14))))) | 0xD1AD9824L) > (**g_789)), 1UL))) == 18446744073709551609UL))) == 0xB3B7C840L) & p_12), (*l_1513));
                    }
                    else
                    { /* block id: 630 */
                        int32_t *l_1536 = &g_1354.f0;
                        l_1536 = l_1513;
                        return g_1537;
                    }
                    l_1538--;
                }
                l_1555 = (safe_mod_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*153*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*154*//* ___SAFE__OP */(p_12, (((((((((g_1239 == (safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*155*//* ___SAFE__OP */(((p_12 >= ((*l_1551) = (p_12 ^ ((void*)0 == l_1547)))) , l_1538), ((((!p_12) & (((**g_721) , 0x09EC213F2D5FF351LL) <= p_12)) == l_1553[0][2][3]) <= (*g_278))))) && l_1554) > p_12) > 0x6BL) , l_1486) >= 0L) > g_343) , (*l_1513)) > l_1456))), l_1456));
                if (l_1415)
                    goto lbl_1590;
                l_1513 = (*g_1392);
                for (l_1495 = 0; (l_1495 <= 1); l_1495 += 1)
                { /* block id: 641 */
                    int64_t *l_1571 = &g_886[0].f1;
                    int64_t *l_1572 = &g_886[0].f1;
                    int64_t *l_1573 = &g_886[0].f1;
                    int64_t *l_1574 = &g_85.f1;
                    int64_t *l_1575 = &g_868.f1;
                    int64_t *l_1576 = &g_162.f1;
                    int64_t *l_1577 = (void*)0;
                    int64_t *l_1578 = &g_1343.f1;
                    int32_t l_1579[1][5][6] = {{{0xE1A7F5EFL,(-1L),9L,(-1L),0xE1A7F5EFL,0x9B1DFF8BL},{(-1L),0xE1A7F5EFL,0x9B1DFF8BL,0x9B1DFF8BL,0xE1A7F5EFL,(-1L)},{(-1L),(-1L),(-6L),0xE1A7F5EFL,(-6L),(-1L)},{(-6L),(-1L),0x9B1DFF8BL,9L,9L,0x9B1DFF8BL},{(-6L),(-6L),9L,0xE1A7F5EFL,0x393E896FL,0xE1A7F5EFL}}};
                    int i, j, k;
                    g_618.f0 ^= (p_12 & (safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*156*//* ___SAFE__OP */((l_1579[0][0][5] &= (safe_rshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*157*//* ___SAFE__OP */(((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*158*//* ___SAFE__OP */((safe_lshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*159*//* ___SAFE__OP */(0x7BL, (0xDBDE9C04L != (*g_122)))), (safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*160*//* ___SAFE__OP */((((l_1553[0][2][3] <= ((g_1567 = l_1566) == l_1568)) , (void*)0) != ((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*161*//* ___SAFE__OP */((*g_278), 7)) , (*l_1518))), p_12)))) , p_12), 6))), (-10L))));
                    return (*g_353);
                }
            }
        }
        else
        { /* block id: 648 */
            int8_t ****l_1580 = (void*)0;
            int8_t ****l_1582 = &g_1452;
            int32_t **l_1583 = &g_67;
            (*l_1582) = (l_1581 = (*g_1451));
            (*l_1583) = (void*)0;
        }
lbl_1590:
        l_1589 = &l_1494;
        l_1597[5][2][7]++;
    }
    if ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*162*//* ___SAFE__OP */((p_12 > ((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*163*//* ___SAFE__OP */((safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*164*//* ___SAFE__OP */((((*l_1639) = (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*165*//* ___SAFE__OP */((((l_50 |= (safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*166*//* ___SAFE__OP */(((g_1610 , (g_1611 , (((*l_1631) = ((((***g_1452) &= (!(((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*167*//* ___SAFE__OP */(0x611FL, ((!(safe_mul_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*168*//* ___SAFE__OP */((g_1119 | (~((*l_1621) = (0x1DL < g_1507[1][1][2])))), (safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*169*//* ___SAFE__OP */(((safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*170*//* ___SAFE__OP */((((((((safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*171*//* ___SAFE__OP */(l_1628, ((!((!((l_1631 == &l_1371) || p_12)) && p_12)) , p_12))) , g_196[3]) && l_1632) <= p_12) , l_1633) != &l_1634) <= g_198[1][4][1]), p_12)) <= l_1635), l_1636))))) , 0x9653L))) == 0L) != l_1637))) | p_12) != 0x76E3D081L)) , p_12))) , p_12), 0UL))) || 0xB7A3F6BDBC34D9CELL) | 0xA8L), p_12))) != g_1387), p_12)), p_12)) != p_12)), p_12)))
    { /* block id: 663 */
        const int32_t *l_1640 = &g_81;
        const int32_t **l_1641 = &l_1640;
        const int32_t **l_1644 = &g_1643;
        int16_t l_1697 = 0xAC50L;
        int32_t l_1698[6][10][1] = {{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}},{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}},{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}},{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}},{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}},{{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L},{0x4D7E7A81L},{0x409450A9L}}};
        int i, j, k;
        (*l_1644) = ((*l_1641) = l_1640);
        for (g_121 = 0; (g_121 <= 2); g_121 += 1)
        { /* block id: 668 */
            uint64_t l_1672 = 0x09AEBC7AADF52E20LL;
            int32_t l_1681 = 0x9E868785L;
            int64_t *l_1683 = (void*)0;
            int32_t l_1727 = (-2L);
            union U1 *l_1741 = &g_720;
            uint32_t l_1760 = 0xD7669580L;
            for (l_1593 = 8; (l_1593 >= 3); l_1593 -= 1)
            { /* block id: 671 */
                uint32_t l_1671 = 0x72D6E07DL;
                int32_t l_1702[3];
                uint8_t *l_1706 = &g_1386;
                int32_t *l_1715[4][8] = {{&g_121,&g_81,&g_121,&l_51,&g_121,&g_81,&g_121,&l_51},{&g_121,&g_81,&g_121,&l_51,&g_121,&g_81,&g_121,&l_51},{&g_121,&g_81,&g_121,&l_51,&g_121,&g_81,&g_121,&l_51},{&g_121,&g_81,&g_121,&l_51,&g_121,&g_81,&g_121,&l_51}};
                int i, j;
                for (i = 0; i < 3; i++)
                    l_1702[i] = 1L;
                for (l_1393 = 0; (l_1393 <= 2); l_1393 += 1)
                { /* block id: 674 */
                    uint8_t l_1673 = 1UL;
                    int8_t **l_1678 = &g_278;
                    int32_t *l_1699 = (void*)0;
                    int32_t *l_1700 = &g_68;
                    int32_t *l_1701[9][2][1] = {{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}},{{&l_1596[0]},{&l_1592}}};
                    uint16_t l_1703 = 65528UL;
                    int i, j, k;
                }
            }
            for (l_1449 = 0; (l_1449 <= 8); l_1449 += 1)
            { /* block id: 718 */
                int8_t ****l_1739 = &g_1452;
                int8_t *****l_1738 = &l_1739;
                int32_t l_1758 = (-1L);
                int32_t l_1759[7][3][3] = {{{0L,0xA6193E74L,0x2E85C52FL},{0xB5C9069AL,0xD14BDE1EL,(-1L)},{0x2E85C52FL,1L,0xB5C9069AL}},{{0xE5257201L,0xB5C9069AL,(-1L)},{0xA773C0CBL,0xAD1612A9L,0x2E85C52FL},{(-8L),5L,(-8L)}},{{0xEBD11DE4L,5L,0x7C964B28L},{0x7C964B28L,0xAD1612A9L,1L},{5L,0xB5C9069AL,0L}},{{(-8L),1L,(-1L)},{5L,0xD14BDE1EL,0xB8F60DBFL},{0x7C964B28L,0xA6193E74L,0xA6193E74L}},{{0xEBD11DE4L,0L,0xA6193E74L},{(-8L),(-8L),0xB5C9069AL},{(-1L),0xEBD11DE4L,0x2E85C52FL}},{{9L,(-1L),0xE5257201L},{0x7C964B28L,0xEBD11DE4L,0xA773C0CBL},{(-8L),0xA6193E74L,(-8L)}},{{0xE5257201L,0xE5257201L,0xEBD11DE4L},{0xE5257201L,0L,0x7C964B28L},{(-8L),0xB8F60DBFL,5L}}};
                int32_t *l_1771 = (void*)0;
                int i, j, k;
                (*l_1738) = (void*)0;
                l_1741 = ((*l_1631) , (g_1740 , (void*)0));
                for (g_1587 = 3; (g_1587 <= 8); g_1587 += 1)
                { /* block id: 723 */
                    union U2 **l_1752[6][5][4] = {{{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,(void*)0,&g_829},{&g_829,&g_829,&g_829,(void*)0},{&g_829,&g_829,&g_829,&g_829}},{{&g_829,&g_829,&g_829,&g_829},{(void*)0,&g_829,&g_829,&g_829},{(void*)0,&g_829,(void*)0,&g_829},{&g_829,&g_829,(void*)0,(void*)0},{&g_829,(void*)0,&g_829,&g_829}},{{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,(void*)0,&g_829},{&g_829,&g_829,(void*)0,&g_829},{(void*)0,&g_829,&g_829,(void*)0},{(void*)0,&g_829,&g_829,(void*)0}},{{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,(void*)0,(void*)0},{&g_829,&g_829,&g_829,(void*)0},{&g_829,&g_829,&g_829,&g_829}},{{&g_829,&g_829,&g_829,&g_829},{(void*)0,&g_829,&g_829,&g_829},{&g_829,&g_829,(void*)0,&g_829},{&g_829,(void*)0,&g_829,(void*)0},{(void*)0,&g_829,&g_829,&g_829}},{{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,&g_829,&g_829},{&g_829,&g_829,(void*)0,&g_829},{&g_829,&g_829,&g_829,(void*)0},{&g_829,&g_829,&g_829,&g_829}}};
                    int32_t l_1755[4] = {0x4690FE88L,0x4690FE88L,0x4690FE88L,0x4690FE88L};
                    int32_t l_1756 = 0xECD8F450L;
                    int i, j, k;
                    if ((*g_1301))
                    { /* block id: 724 */
                        uint32_t *l_1753 = &l_1554;
                        uint32_t **l_1754 = &l_1753;
                        int32_t l_1757 = (-3L);
                        int i, j, k;
                        if (p_12)
                            break;
                        l_1759[2][0][1] &= (l_1758 &= (l_1757 ^= (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*172*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*173*//* ___SAFE__OP */((0xE3DEL >= (((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*174*//* ___SAFE__OP */(1UL, (l_1756 |= (safe_lshift_func_int32_t_s_u/* ___REMOVE_SAFE__OP *//*175*//* ___SAFE__OP */((l_1448[0][3][0] == (void*)0), (p_12 < ((safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*176*//* ___SAFE__OP */((l_1597[(g_121 + 1)][g_121][(g_121 + 5)] = (((void*)0 == l_1752[2][2][0]) ^ ((p_12 <= (((*l_1754) = l_1753) == &l_1554)) > 0x991DF907L))), l_1755[1])) == p_12))))))) == 0xC3A4L) > 0xD59C98242BC5E004LL)), l_1681)), 18446744073709551609UL))));
                    }
                    else
                    { /* block id: 732 */
                        int32_t *l_1761 = (void*)0;
                        int32_t l_1767 = (-8L);
                        l_1771 = func_16((p_12 != l_1760), l_1761, p_12, ((safe_rshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*177*//* ___SAFE__OP */((l_1755[0] &= (l_1759[6][1][0] = (safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*178*//* ___SAFE__OP */(((+l_1767) ^ (+(safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*179*//* ___SAFE__OP */((65535UL <= (****g_1142)), (*g_790))))), ((**l_1644) | l_1760))))), 60)) || l_1756));
                        return (*g_353);
                    }
                    if (p_12)
                        break;
                }
            }
        }
    }
    else
    { /* block id: 742 */
        l_1772[4] = l_1772[3];
    }
    return g_1774;
}


/* ------------------------------------------ */
/* 
 * reads : g_1354.f0 g_828 g_829 g_466 g_1145 g_621
 * writes: g_1354.f0
 */
static int32_t * func_16(uint16_t  p_17, int32_t * p_18, int64_t  p_19, uint16_t  p_20)
{ /* block id: 544 */
    uint8_t l_1364 = 249UL;
    int32_t l_1366 = 0x7D3980EFL;
    for (g_1354.f0 = 0; (g_1354.f0 != (-30)); --g_1354.f0)
    { /* block id: 547 */
        int32_t *l_1365[9] = {&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0,&g_85.f0};
        int i;
        p_18 = (void*)0;
        l_1366 &= (l_1364 > p_17);
    }
    l_1366 = (((void*)0 != (*g_828)) , (safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*180*//* ___SAFE__OP */((((g_466[0] , p_17) || (((safe_mod_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*181*//* ___SAFE__OP */(255UL, p_17)) , ((((-2L) >= 0x3716L) , ((p_18 == p_18) < l_1364)) && 0xBA3AL)) <= p_19)) < p_19), (*g_1145))));
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_368 g_68 g_1257 g_67 g_121 g_162.f1 g_85.f2 g_790 g_791 g_80 g_81 g_1346 g_235 g_1347 g_1354 g_815.f1
 * writes: g_368 g_815.f1 g_68 g_121 g_85.f2 g_81 g_618.f0 g_162.f1 g_67 g_868.f2 g_798.f0
 */
static int32_t * func_21(uint32_t  p_22, int8_t * p_23, int32_t * p_24, int32_t * p_25, uint16_t  p_26)
{ /* block id: 480 */
    int64_t l_1248 = 6L;
    const union U1 * const *l_1255 = &g_478;
    const union U1 * const **l_1256 = &l_1255;
    const uint64_t l_1258[8] = {0xFC0E70574BF8828FLL,0x3033102638F1F072LL,0x3033102638F1F072LL,0xFC0E70574BF8828FLL,0x3033102638F1F072LL,0x3033102638F1F072LL,0xFC0E70574BF8828FLL,0x3033102638F1F072LL};
    uint32_t *l_1259 = &g_815.f1;
    uint64_t ** const l_1264[8] = {&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5],&g_143[1][0][5]};
    uint32_t l_1271 = 0x8E498CE8L;
    int32_t l_1345[5];
    int i;
    for (i = 0; i < 5; i++)
        l_1345[i] = 0xA85639B1L;
    (*p_24) = (safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*182*//* ___SAFE__OP */(((void*)0 == &g_1142), g_368));
    (*g_67) = (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*183*//* ___SAFE__OP */((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*184*//* ___SAFE__OP */(((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*185*//* ___SAFE__OP */((0L > ((((*l_1259) = (l_1248 >= ((((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*186*//* ___SAFE__OP */((safe_add_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*187*//* ___SAFE__OP */(g_68, (safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*188*//* ___SAFE__OP */((-3L), p_22)))), ((((*l_1256) = l_1255) == (void*)0) == 0x0DL))) , (g_1257 , l_1258[1])) & (*g_67)) , l_1248))) | l_1258[3]) ^ g_162.f1)), p_26)) != 0x8BL), 7UL)), l_1258[1]));
    for (g_85.f2 = 5; (g_85.f2 <= 44); g_85.f2 = safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*189*//* ___SAFE__OP */(g_85.f2, 5))
    { /* block id: 487 */
        uint64_t *l_1279 = &g_868.f2;
        const int16_t l_1287 = (-1L);
        int64_t l_1359 = 0xB2B7D27027D804FALL;
        int16_t l_1360[9] = {0x2E4FL,0x92B1L,0x2E4FL,0x2E4FL,0x92B1L,0x2E4FL,0x2E4FL,0x92B1L,0x2E4FL};
        int32_t l_1361[3];
        int i;
        for (i = 0; i < 3; i++)
            l_1361[i] = 0xE554A59FL;
        (*g_80) = (safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*190*//* ___SAFE__OP */(0x6DL, (l_1264[0] != (((*g_790) > (-1L)) , l_1264[2]))));
        (*p_24) ^= (&p_22 != &g_196[5]);
        for (g_618.f0 = 20; (g_618.f0 < 23); g_618.f0 = safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*191*//* ___SAFE__OP */(g_618.f0, 9))
        { /* block id: 492 */
            int32_t * volatile l_1272 = &g_886[0].f0;/* VOLATILE GLOBAL l_1272 */
            uint64_t *l_1278 = &g_162.f2;
            int32_t l_1298 = 5L;
            int32_t ****l_1324 = (void*)0;
            int16_t ***l_1327[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1327[i] = &g_1144;
            for (g_162.f1 = 19; (g_162.f1 < 5); g_162.f1--)
            { /* block id: 495 */
                int32_t **l_1269 = &g_67;
                (*l_1269) = p_25;
            }
            for (g_868.f2 = 0; (g_868.f2 <= 0); g_868.f2 += 1)
            { /* block id: 500 */
                int16_t ***l_1328 = &g_1144;
                int i;
                for (g_798.f0 = 0; (g_798.f0 >= 0); g_798.f0 -= 1)
                { /* block id: 503 */
                    if ((*g_80))
                        break;
                }
            }
            (*g_1347) = (g_1346[1][2][7] , (*g_235));
            (*p_24) &= (safe_sub_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*192*//* ___SAFE__OP */((((l_1361[1] = (safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*193*//* ___SAFE__OP */(p_22, (safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*194*//* ___SAFE__OP */(((g_1354 , p_22) > 18446744073709551606UL), (((-1L) >= (safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*195*//* ___SAFE__OP */(((g_815.f1 | ((l_1287 || (safe_mod_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*196*//* ___SAFE__OP */((((l_1271 , p_26) , l_1359) , l_1271), 1L))) , l_1359)) , 0x98FBL), p_22))) >= l_1360[0])))))) || p_26) >= 1L), l_1359));
        }
    }
    return p_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_162.f1 g_235 g_198 g_85.f2 g_121 g_81 g_67 g_13 g_265 g_196 g_68 g_798.f0
 * writes: g_162.f1 g_85.f2 g_67 g_196 g_61 g_68
 */
static uint32_t  func_27(int32_t * p_28, int32_t * p_29)
{ /* block id: 78 */
    int32_t l_260[10] = {5L,5L,5L,5L,5L,5L,5L,5L,5L,5L};
    int32_t l_266 = 2L;
    int32_t l_298 = (-4L);
    uint32_t *l_316 = &g_196[7];
    int8_t l_327 = 0x78L;
    uint16_t l_328 = 0x5841L;
    int8_t ***l_348[3];
    union U1 *l_359 = (void*)0;
    uint64_t l_432 = 0x0851EC8FE551804DLL;
    uint32_t *l_443[3][9] = {{&g_196[5],&g_196[6],(void*)0,&g_196[6],&g_196[5],&g_196[5],&g_196[5],&g_196[5],&g_196[6]},{&g_196[5],&g_196[3],&g_196[5],&g_196[5],(void*)0,(void*)0,&g_196[5],&g_196[5],&g_196[3]},{&g_196[3],&g_196[5],&g_196[5],(void*)0,(void*)0,&g_196[5],&g_196[5],&g_196[3],&g_196[5]}};
    uint16_t l_486[3];
    uint16_t l_597 = 0xCFF2L;
    union U1 **l_671 = &l_359;
    int16_t l_683 = 0x8B04L;
    uint32_t l_710 = 0x1E349AB9L;
    int16_t l_799 = (-2L);
    uint64_t l_825 = 0x087B146530015FEALL;
    int32_t l_852 = (-1L);
    int32_t *l_881 = &g_798.f0;
    int16_t l_923 = 0xF9B9L;
    uint16_t *l_1023 = &l_597;
    uint16_t **l_1022 = &l_1023;
    int32_t l_1096[7][9];
    uint16_t l_1097 = 4UL;
    uint64_t l_1121 = 18446744073709551615UL;
    int64_t * const l_1188 = &g_162.f1;
    const uint64_t l_1200 = 0x0EC574463DCE1AC4LL;
    int32_t *l_1231 = &g_798.f0;
    int32_t *l_1232 = (void*)0;
    int32_t *l_1233 = &g_81;
    int32_t *l_1234[1];
    uint32_t l_1235 = 0UL;
    int i, j;
    for (i = 0; i < 3; i++)
        l_348[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_486[i] = 1UL;
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
            l_1096[i][j] = 0x8B35956AL;
    }
    for (i = 0; i < 1; i++)
        l_1234[i] = &g_121;
    for (g_162.f1 = (-19); (g_162.f1 == (-3)); ++g_162.f1)
    { /* block id: 81 */
        int32_t l_255 = 0x81FCDCBAL;
        uint64_t *l_258 = &g_142;
        int32_t **l_259[3][1];
        int8_t *l_275 = &g_119;
        int8_t **l_274 = &l_275;
        int32_t *l_279 = &g_121;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_259[i][j] = &g_67;
        }
        for (g_85.f2 = (-29); (g_85.f2 <= 38); g_85.f2 = safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*197*//* ___SAFE__OP */(g_85.f2, 5))
        { /* block id: 84 */
            int32_t *l_234 = &g_121;
            uint64_t l_261 = 0x871682D74585E3A4LL;
            uint8_t l_262 = 255UL;
            if ((safe_lshift_func_uint8_t_u_s/* ___REMOVE_SAFE__OP *//*198*//* ___SAFE__OP */(0xBEL, 2)))
            { /* block id: 85 */
                int32_t **l_240 = &l_234;
                int32_t ***l_241 = &l_240;
                uint32_t *l_263 = &g_196[3];
                int32_t l_264 = 1L;
                (*g_235) = l_234;
                (*p_29) = (safe_add_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*199*//* ___SAFE__OP */(g_198[6][5][0], (((safe_mod_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*200*//* ___SAFE__OP */(((&g_67 == ((*l_241) = l_240)) ^ (((g_85.f2 & (safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*201*//* ___SAFE__OP */((((safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*202*//* ___SAFE__OP */((safe_mul_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*203*//* ___SAFE__OP */((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*204*//* ___SAFE__OP */((((*l_263) = (~(((((*l_234) >= ((safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*205*//* ___SAFE__OP */((((l_255 & (((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*206*//* ___SAFE__OP */(((void*)0 != l_258), (((((g_81 , l_259[1][0]) != &p_28) && l_260[7]) , l_261) != g_121))) , (*g_67)) != (*l_234))) && g_162.f1) , 8L), l_260[5])) || (*l_234))) >= (*p_29)) == l_262) || g_13))) && g_13), l_264)), (*g_67))), l_260[1])) & g_13) | (*g_67)), 4294967289UL))) , g_265[0][3]) != g_265[1][4])), (*l_234))) == 0x2550B3B6L) == l_266)));
            }
            else
            { /* block id: 90 */
                uint8_t l_267 = 0x4BL;
                l_267++;
                if (l_267)
                    break;
                for (l_267 = 0; (l_267 >= 25); l_267 = safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*207*//* ___SAFE__OP */(l_267, 1))
                { /* block id: 95 */
                    uint32_t *l_292[10][7][1] = {{{(void*)0},{&g_196[5]},{&g_196[5]},{&g_196[1]},{&g_196[0]},{&g_196[5]},{&g_196[8]}},{{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{&g_196[8]},{&g_196[5]}},{{&g_196[0]},{&g_196[1]},{&g_196[5]},{&g_196[5]},{(void*)0},{(void*)0},{&g_196[5]}},{{&g_196[3]},{&g_196[3]},{&g_196[5]},{&g_196[5]},{&g_196[5]},{&g_196[5]},{&g_196[3]}},{{&g_196[3]},{&g_196[5]},{(void*)0},{(void*)0},{&g_196[5]},{&g_196[5]},{&g_196[1]}},{{&g_196[0]},{&g_196[5]},{&g_196[8]},{(void*)0},{(void*)0},{(void*)0},{(void*)0}},{{(void*)0},{&g_196[8]},{&g_196[5]},{&g_196[0]},{&g_196[1]},{&g_196[5]},{&g_196[5]}},{{(void*)0},{(void*)0},{&g_196[5]},{&g_196[3]},{&g_196[3]},{&g_196[5]},{&g_196[5]}},{{&g_196[5]},{&g_196[5]},{&g_196[3]},{&g_196[3]},{&g_196[5]},{(void*)0},{(void*)0}},{{&g_196[5]},{&g_196[5]},{&g_196[1]},{&g_196[0]},{&g_196[5]},{&g_196[8]},{(void*)0}}};
                    int32_t l_293 = 0x99CE5FD4L;
                    int i, j, k;
                    for (g_61 = (-24); (g_61 <= 18); g_61 = safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*208*//* ___SAFE__OP */(g_61, 2))
                    { /* block id: 98 */
                        l_274 = l_274;
                        l_279 = ((*g_235) = p_29);
                    }
                    (*p_29) ^= (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*209*//* ___SAFE__OP */((!(safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*210*//* ___SAFE__OP */(g_196[5], (+((safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*211*//* ___SAFE__OP */(l_260[7], (safe_rshift_func_uint64_t_u_s/* ___REMOVE_SAFE__OP *//*212*//* ___SAFE__OP */((safe_lshift_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*213*//* ___SAFE__OP */((l_266 &= l_267), l_293)), 33)))) & l_267))))), 41));
                }
                if ((*l_279))
                    break;
            }
            return l_260[7];
        }
        (*p_28) &= (-3L);
        (*g_235) = (*g_235);
    }
    for (g_68 = 0; (g_68 == 23); g_68++)
    { /* block id: 115 */
        return l_260[6];
    }
    if (((((((*l_316) = ((((safe_lshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*214*//* ___SAFE__OP */(l_298, (+0xAE2DBC6560A787ACLL))) | (safe_lshift_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*215*//* ___SAFE__OP */(((((safe_lshift_func_int64_t_s_u/* ___REMOVE_SAFE__OP *//*216*//* ___SAFE__OP */(l_260[8], 9)) , ((l_266 = 2UL) >= 0x6D18A21EC6C1B368LL)) & (safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*217*//* ___SAFE__OP */((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*218*//* ___SAFE__OP */(((safe_sub_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*219*//* ___SAFE__OP */((g_198[6][5][0] || ((safe_div_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*220*//* ___SAFE__OP */((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*221*//* ___SAFE__OP */((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*222*//* ___SAFE__OP */(((void*)0 != &g_120[0]), (l_260[7] & l_298))), 5)), l_260[5])) != l_260[7])), 0x53A1L)) , (-1L)), l_298)), l_298))) <= 1L), l_260[7]))) , l_266) , 0UL)) > 7UL) > l_298) ^ 0UL) == l_298))
    { /* block id: 120 */
        int32_t *l_317 = &g_81;
        int32_t *l_318 = &g_68;
        int32_t *l_319 = (void*)0;
        int32_t *l_320 = &g_81;
        int32_t l_321 = 9L;
        int32_t *l_322 = &g_85.f0;
        int32_t *l_323 = &l_321;
        int32_t *l_324 = &l_260[2];
        int32_t *l_325 = &g_121;
        int32_t *l_326[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t **l_331 = &l_322;
        int i;
        ++l_328;
        (*l_331) = (void*)0;
    }
    else
    { /* block id: 123 */
        int32_t *l_332[4][4][2] = {{{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68}},{{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68}},{{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68}},{{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68},{&g_68,&g_68}}};
        uint32_t l_333 = 9UL;
        int16_t *l_342 = &g_343;
        int32_t l_346[7][6][4] = {{{(-6L),0xCAF07905L,0x38F403BAL,0x3B2AEE43L},{0xB604AA25L,0xAFC0850AL,0xDF1AA62DL,(-5L)},{0xBC1DC1D7L,(-1L),0L,(-1L)},{(-9L),0xA984D779L,0x4DE86E1FL,0x537DBD58L},{1L,(-1L),0xA5EF5CE9L,0xA5EF5CE9L},{0x56E569AFL,0x56E569AFL,0x2E03701DL,(-7L)}},{{0x2337F8D4L,(-5L),0x0DFC0DDBL,(-1L)},{0x75FBCA4FL,0x5FD38649L,0x46224244L,0x0DFC0DDBL},{0x4DE86E1FL,0x5FD38649L,1L,(-1L)},{0x5FD38649L,(-5L),0xFDCEC06DL,(-7L)},{0x824BA821L,0x56E569AFL,(-1L),0xA5EF5CE9L},{6L,(-1L),0xDAE04848L,0x537DBD58L}},{{(-6L),0xA984D779L,3L,(-1L)},{0xDD3B4845L,(-1L),0L,(-5L)},{0x52C26C8EL,0xAFC0850AL,1L,(-9L)},{0L,(-1L),0x8DF95F13L,0xDAE04848L},{9L,6L,0x7ED771F6L,1L},{0xA5EF5CE9L,0x980DC176L,0L,0x8DF95F13L}},{{(-1L),(-6L),3L,0x9857A78FL},{1L,0xD39461BCL,(-1L),0x38F403BAL},{(-5L),0x0A36DBC4L,0x55A909A3L,(-6L)},{0x537DBD58L,0x56E569AFL,(-2L),(-5L)},{(-1L),0xCF75B379L,0x46224244L,0x3B2AEE43L},{0L,1L,5L,6L}},{{0x824BA821L,0x6D310122L,(-5L),(-1L)},{(-6L),0x7ED771F6L,0x04509021L,0x7ED771F6L},{0x3B2AEE43L,0x5FD38649L,0xBC1DC1D7L,0x09077305L},{0x2E03701DL,0x16BD0946L,0L,0x4DE86E1FL},{0xFDCEC06DL,0x04509021L,(-7L),0x537DBD58L},{0xFDCEC06DL,(-6L),0L,0L}},{{0x2E03701DL,0x537DBD58L,0xBC1DC1D7L,3L},{0x3B2AEE43L,0xB604AA25L,0x04509021L,0x55A909A3L},{(-6L),6L,(-5L),1L},{0x824BA821L,0x8FBF3483L,5L,(-1L)},{0L,(-2L),0x46224244L,(-6L)},{(-1L),0x75FBCA4FL,(-2L),6L}},{{0x537DBD58L,0L,0x55A909A3L,(-1L)},{(-5L),(-1L),(-1L),0xAFC0850AL},{1L,(-1L),3L,0xA984D779L},{(-1L),(-7L),0L,0x5FD38649L},{0xA5EF5CE9L,0x55A909A3L,0x7ED771F6L,0x0DFC0DDBL},{9L,0x38F403BAL,0x8DF95F13L,0x50B5D90FL}}};
        uint16_t *l_347 = &g_79;
        int16_t l_446 = 6L;
        int8_t *l_524 = &l_327;
        uint32_t l_573 = 0x12AFBD09L;
        int8_t l_574 = 0L;
        uint64_t l_674 = 18446744073709551610UL;
        uint64_t *l_703 = (void*)0;
        uint32_t l_709[10][10] = {{0xFE3D5DB2L,0x60DFDD8DL,0xF50CC716L,0x60DFDD8DL,0xFE3D5DB2L,0x696B8693L,0x696B8693L,0xFE3D5DB2L,0x60DFDD8DL,0xF50CC716L},{0x21C11CAFL,0x21C11CAFL,0xF50CC716L,0xFE3D5DB2L,0xF53626D7L,0xFE3D5DB2L,0xF50CC716L,0x21C11CAFL,0x21C11CAFL,0xF50CC716L},{0x60DFDD8DL,0xFE3D5DB2L,0x696B8693L,0x696B8693L,0xFE3D5DB2L,0x60DFDD8DL,0xF50CC716L,0x60DFDD8DL,0xFE3D5DB2L,0x696B8693L},{0x474F36D4L,0x21C11CAFL,0x474F36D4L,0x696B8693L,0xF50CC716L,0xF50CC716L,0x696B8693L,0x474F36D4L,0x21C11CAFL,0x474F36D4L},{0x474F36D4L,0x60DFDD8DL,0x21C11CAFL,0xFE3D5DB2L,0x21C11CAFL,0x60DFDD8DL,0x474F36D4L,0x474F36D4L,0x60DFDD8DL,0x21C11CAFL},{0x60DFDD8DL,0x474F36D4L,0x474F36D4L,0x60DFDD8DL,0x21C11CAFL,0xFE3D5DB2L,0x21C11CAFL,0x60DFDD8DL,0x474F36D4L,0x474F36D4L},{0x21C11CAFL,0x474F36D4L,0x696B8693L,0xF50CC716L,0xF50CC716L,0x696B8693L,0x474F36D4L,0x21C11CAFL,0x474F36D4L,0x696B8693L},{0xFE3D5DB2L,0x60DFDD8DL,0xF50CC716L,0x60DFDD8DL,0xFE3D5DB2L,0x696B8693L,0x696B8693L,0xFE3D5DB2L,0x60DFDD8DL,0xF50CC716L},{0x21C11CAFL,0xF53626D7L,0x21C11CAFL,0x696B8693L,0x60DFDD8DL,0x696B8693L,0x21C11CAFL,0xF53626D7L,0xF53626D7L,0x21C11CAFL},{0x474F36D4L,0x696B8693L,0xF50CC716L,0xF50CC716L,0x696B8693L,0x474F36D4L,0x21C11CAFL,0x474F36D4L,0x696B8693L,0xF50CC716L}};
        int32_t l_740 = 1L;
        union U2 *l_827 = &g_815;
        int32_t l_830 = 6L;
        uint8_t l_832 = 0xFFL;
        uint32_t **l_1081 = (void*)0;
        int16_t * const *l_1092 = (void*)0;
        int16_t * const **l_1091[4][5][7] = {{{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,(void*)0},{&l_1092,&l_1092,(void*)0,&l_1092,(void*)0,&l_1092,&l_1092}},{{(void*)0,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,(void*)0,&l_1092,&l_1092,(void*)0},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,(void*)0,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092}},{{&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,(void*)0,(void*)0,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092}},{{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092},{&l_1092,&l_1092,&l_1092,(void*)0,&l_1092,&l_1092,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092},{&l_1092,&l_1092,&l_1092,&l_1092,(void*)0,&l_1092,&l_1092}}};
        uint32_t l_1181 = 6UL;
        int32_t **l_1191 = &l_332[3][3][1];
        int32_t *** const l_1190[2][8][5] = {{{&l_1191,&l_1191,&l_1191,&l_1191,&l_1191},{(void*)0,&l_1191,&l_1191,&l_1191,(void*)0},{&l_1191,&l_1191,&l_1191,(void*)0,&l_1191},{&l_1191,&l_1191,&l_1191,&l_1191,&l_1191},{(void*)0,&l_1191,&l_1191,&l_1191,(void*)0},{&l_1191,&l_1191,&l_1191,(void*)0,&l_1191},{&l_1191,&l_1191,&l_1191,(void*)0,&l_1191},{&l_1191,&l_1191,&l_1191,&l_1191,&l_1191}},{{&l_1191,&l_1191,&l_1191,&l_1191,(void*)0},{&l_1191,&l_1191,&l_1191,(void*)0,&l_1191},{(void*)0,&l_1191,&l_1191,(void*)0,&l_1191},{&l_1191,&l_1191,&l_1191,&l_1191,&l_1191},{(void*)0,&l_1191,(void*)0,&l_1191,(void*)0},{(void*)0,&l_1191,(void*)0,&l_1191,&l_1191},{&l_1191,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&l_1191,&l_1191}}};
        union U1 ***l_1203 = &l_671;
        int i, j, k;
        --l_333;
    }
    l_1235--;
    return (*l_881);
}


/* ------------------------------------------ */
/* 
 * reads : g_81 g_67 g_68 g_122 g_121 g_85 g_13 g_142 g_162 g_85.f2 g_196 g_198 g_119 g_79 g_162.f0 g_80 g_222 g_61
 * writes: g_81 g_85.f2 g_119 g_68 g_121 g_61 g_141 g_143 g_196 g_85.f1 g_162.f0
 */
static int32_t * func_30(int32_t  p_31, int32_t  p_32, int8_t  p_33, int32_t * p_34, int32_t * p_35)
{ /* block id: 16 */
    uint64_t l_114 = 18446744073709551615UL;
    int32_t l_128 = (-3L);
    int32_t l_131 = 0x47558758L;
    uint64_t **l_146 = &g_141[0];
    int32_t l_154 = (-1L);
    uint16_t l_179 = 65535UL;
    int8_t *l_205 = &g_119;
    int64_t *l_212 = &g_85.f1;
    int8_t l_215 = 0x2DL;
    int16_t l_216 = (-1L);
    int32_t *l_217 = &l_128;
    uint64_t *l_226 = &g_142;
    for (g_81 = 0; (g_81 < 22); g_81++)
    { /* block id: 19 */
        int64_t l_117 = 0xEDF5A291505FFFC4LL;
        int32_t *l_123 = &g_121;
        int32_t l_129 = 0x9F05BB7EL;
        int32_t l_132 = 0x93EB3337L;
        int32_t l_133 = 0L;
        int32_t l_134 = 0x9D9BB22BL;
        uint64_t l_135 = 0x7325A1CDA016E985LL;
        const uint32_t l_155 = 18446744073709551612UL;
        uint16_t *l_158 = (void*)0;
        for (g_85.f2 = 0; (g_85.f2 == 26); g_85.f2++)
        { /* block id: 22 */
            uint16_t *l_113[4] = {&g_79,&g_79,&g_79,&g_79};
            int8_t *l_118[7][3] = {{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119},{&g_119,&g_119,&g_119}};
            int32_t l_130 = 0x10F1DDE4L;
            int i, j;
            (*g_122) |= ((*g_67) ^= ((l_114 = g_81) && (safe_div_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*223*//* ___SAFE__OP */(0xFFL, (g_119 = l_117)))));
            l_123 = p_34;
            for (g_61 = (-21); (g_61 != 36); ++g_61)
            { /* block id: 30 */
                int32_t *l_126 = &g_121;
                int32_t *l_127[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint64_t **l_138 = (void*)0;
                uint64_t *l_140 = &l_135;
                uint64_t **l_139[6][6] = {{&l_140,&l_140,&l_140,&l_140,&l_140,&l_140},{&l_140,&l_140,(void*)0,&l_140,&l_140,(void*)0},{&l_140,&l_140,&l_140,&l_140,&l_140,&l_140},{&l_140,&l_140,&l_140,(void*)0,&l_140,&l_140},{&l_140,&l_140,&l_140,&l_140,&l_140,&l_140},{&l_140,&l_140,&l_140,&l_140,&l_140,(void*)0}};
                uint16_t **l_178 = &l_158;
                int i, j;
                l_135++;
                if (((g_143[1][0][5] = (g_141[2] = &l_135)) != &g_61))
                { /* block id: 34 */
                    const uint8_t l_153 = 0x8DL;
                    uint8_t l_159 = 0x76L;
                    (*g_67) &= ((((((((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*224*//* ___SAFE__OP */((((void*)0 == l_146) >= (safe_sub_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*225*//* ___SAFE__OP */((4294967295UL == (safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*226*//* ___SAFE__OP */(((safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*227*//* ___SAFE__OP */(((l_113[2] != (void*)0) != p_33), p_31)) & l_153), (g_85 , g_121)))), 18446744073709551612UL))), g_13)) | p_33) , l_130) , (void*)0) == (void*)0) , (void*)0) != (void*)0) == p_32);
                    if ((((void*)0 == &p_33) >= g_142))
                    { /* block id: 36 */
                        if (l_154)
                            break;
                        if ((*p_35))
                            continue;
                        if (l_155)
                            break;
                    }
                    else
                    { /* block id: 40 */
                        (*g_122) = (-1L);
                    }
                    for (l_128 = (-12); (l_128 < (-14)); --l_128)
                    { /* block id: 45 */
                        int32_t l_167[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_167[i] = 0xBD83D76CL;
                        if (l_154)
                            break;
                        (*l_126) = (((((void*)0 != l_158) && l_159) >= (safe_add_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*228*//* ___SAFE__OP */((g_162 , (safe_lshift_func_int8_t_s_u/* ___REMOVE_SAFE__OP *//*229*//* ___SAFE__OP */((safe_add_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*230*//* ___SAFE__OP */((-9L), l_167[0])), 1))), ((safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*231*//* ___SAFE__OP */(0L, ((~((*g_67) == (l_167[0] ^ l_167[0]))) || l_167[0]))) > g_85.f2)))) == l_167[0]);
                    }
                }
                else
                { /* block id: 49 */
                    uint16_t **l_177 = &l_113[2];
                    uint32_t *l_195 = &g_196[5];
                    uint32_t l_197 = 18446744073709551613UL;
                    if ((*p_35))
                        break;
                    l_130 &= (~(safe_add_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*232*//* ___SAFE__OP */(((safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*233*//* ___SAFE__OP */(((safe_rshift_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*234*//* ___SAFE__OP */(((((*l_177) = l_113[2]) != &g_13) <= ((((l_178 = (void*)0) != l_177) == (l_179 ^ ((l_128 = (safe_mod_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*235*//* ___SAFE__OP */(8L, ((p_33 <= ((safe_lshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*236*//* ___SAFE__OP */(((((safe_sub_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*237*//* ___SAFE__OP */((safe_lshift_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*238*//* ___SAFE__OP */((safe_mul_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*239*//* ___SAFE__OP */(((((safe_unary_minus_func_uint8_t_u/* ___REMOVE_SAFE__OP *//*240*//* ___SAFE__OP */(((safe_mul_func_uint32_t_u_u/* ___REMOVE_SAFE__OP *//*241*//* ___SAFE__OP */(((*l_195) |= ((((safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*242*//* ___SAFE__OP */(0x2B3D635D9A7C6434LL, (p_31 , l_128))) | p_33) , g_13) >= 0L)), g_81)) <= p_31))) | (*p_35)) && 0xC5D88C5394159496LL) & l_197), g_198[6][5][0])), l_197)), p_31)) | 0xA8L) != l_197) , p_32), (*p_35))) ^ p_32)) ^ g_119)))) > (*l_126)))) & g_79)), 14)) | 0x1AL))) >= 0x33L), 0x5B3C6BB1L)));
                }
            }
            if (l_130)
                break;
        }
    }
    (*g_122) = ((*l_217) = (safe_mod_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*243*//* ___SAFE__OP */(((g_196[4] != (g_162.f0 > (((safe_mod_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*244*//* ___SAFE__OP */(((safe_mul_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*245*//* ___SAFE__OP */((((*l_205) = 0xD1L) , (safe_add_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*246*//* ___SAFE__OP */(((l_131 = ((safe_rshift_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*247*//* ___SAFE__OP */(((safe_mul_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*248*//* ___SAFE__OP */(((*l_212) = g_119), (l_114 <= ((*g_67) ^= l_154)))) && p_33), 3)) < ((safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*249*//* ___SAFE__OP */((l_131 > (l_215 || (*g_80))), l_216)) && 0x7CEFL))) ^ 0x5071L), 0x8762L))), l_216)) , 0x57C5L), 0xFC68L)) || g_196[8]) != g_79))) , (-6L)), (-7L))));
    for (p_32 = 0; (p_32 != (-7)); p_32--)
    { /* block id: 69 */
        int8_t l_227[8] = {0x1FL,0x1FL,0x1FL,0x1FL,0x1FL,0x1FL,0x1FL,0x1FL};
        int i;
        for (g_162.f0 = 0; (g_162.f0 <= (-14)); g_162.f0 = safe_sub_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*250*//* ___SAFE__OP */(g_162.f0, 8))
        { /* block id: 72 */
            return &g_68;
        }
        (*p_35) = (((g_222 , p_31) != (safe_rshift_func_uint32_t_u_s/* ___REMOVE_SAFE__OP *//*251*//* ___SAFE__OP */((safe_unary_minus_func_int8_t_s/* ___REMOVE_SAFE__OP *//*252*//* ___SAFE__OP */((*l_217))), ((((g_61 , (&g_142 == &l_114)) && (1L | ((*l_217) & (((((void*)0 != l_226) ^ l_227[5]) || l_227[3]) , p_33)))) , (*g_67)) >= (-1L))))) ^ l_227[0]);
    }
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_85 g_68 g_79 g_81
 * writes: g_85.f2 g_81
 */
static uint32_t  func_41(uint32_t  p_42, int32_t  p_43, int8_t  p_44, int32_t  p_45, uint64_t  p_46)
{ /* block id: 11 */
    const uint32_t l_96 = 1UL;
    uint64_t *l_105 = &g_85.f2;
    int32_t *l_106 = &g_81;
    (*l_106) &= (safe_mul_func_uint8_t_u_u/* ___REMOVE_SAFE__OP *//*253*//* ___SAFE__OP */((~(p_44 = (g_85 , (safe_add_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*254*//* ___SAFE__OP */((((safe_div_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*255*//* ___SAFE__OP */(p_46, (safe_sub_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*256*//* ___SAFE__OP */((+(!g_68)), l_96)))) ^ ((safe_rshift_func_int16_t_s_u/* ___REMOVE_SAFE__OP *//*257*//* ___SAFE__OP */((-9L), 1)) <= (safe_lshift_func_int64_t_s_s/* ___REMOVE_SAFE__OP *//*258*//* ___SAFE__OP */(g_68, p_46)))) , p_42), ((*l_105) = (safe_div_func_int16_t_s_s/* ___REMOVE_SAFE__OP *//*259*//* ___SAFE__OP */((safe_mul_func_uint64_t_u_u/* ___REMOVE_SAFE__OP *//*260*//* ___SAFE__OP */(18446744073709551611UL, p_44)), g_79)))))))), 0x07L));
    return g_79;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_61 g_68 g_80 g_81 g_79
 * writes: g_79 g_81
 */
static int8_t  func_54(int16_t  p_55, int32_t * p_56, int32_t * p_57)
{ /* block id: 7 */
    int16_t l_76 = 0xEA3CL;
    uint8_t l_77 = 0x96L;
    uint16_t *l_78 = &g_79;
    (*g_80) &= (safe_add_func_int32_t_s_s/* ___REMOVE_SAFE__OP *//*261*//* ___SAFE__OP */((((*l_78) = (g_13 | (((safe_div_func_uint16_t_u_u/* ___REMOVE_SAFE__OP *//*262*//* ___SAFE__OP */(0x7067L, (~((safe_sub_func_int8_t_s_s/* ___REMOVE_SAFE__OP *//*263*//* ___SAFE__OP */(p_55, 251UL)) > ((((((18446744073709551611UL > 2UL) || (g_61 , ((18446744073709551611UL == g_68) , 18446744073709551606UL))) ^ l_76) , l_76) <= l_76) != 18446744073709551615UL))))) ^ l_77) != l_76))) || p_55), g_61));
    return g_79;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_85.f0, "g_85.f0", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_162.f1, "g_162.f1", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_196[i], "g_196[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_198[i][j][k], "g_198[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_222.f0, "g_222.f0", print_hash_value);
    transparent_crc(g_343, "g_343", print_hash_value);
    transparent_crc(g_368, "g_368", print_hash_value);
    transparent_crc(g_389.f0, "g_389.f0", print_hash_value);
    transparent_crc(g_403, "g_403", print_hash_value);
    transparent_crc(g_415, "g_415", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_466[i].f0, "g_466[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_473, "g_473", print_hash_value);
    transparent_crc(g_523.f0, "g_523.f0", print_hash_value);
    transparent_crc(g_618.f0, "g_618.f0", print_hash_value);
    transparent_crc(g_621, "g_621", print_hash_value);
    transparent_crc(g_628.f0, "g_628.f0", print_hash_value);
    transparent_crc(g_791, "g_791", print_hash_value);
    transparent_crc(g_798.f0, "g_798.f0", print_hash_value);
    transparent_crc(g_815.f0, "g_815.f0", print_hash_value);
    transparent_crc(g_868.f0, "g_868.f0", print_hash_value);
    transparent_crc(g_877.f0, "g_877.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_886[i].f0, "g_886[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_929.f0, "g_929.f0", print_hash_value);
    transparent_crc(g_1119, "g_1119", print_hash_value);
    transparent_crc(g_1239, "g_1239", print_hash_value);
    transparent_crc(g_1343.f0, "g_1343.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_1346[i][j][k].f0, "g_1346[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1386, "g_1386", print_hash_value);
    transparent_crc(g_1387, "g_1387", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1399[i], "g_1399[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1414[i][j][k].f0, "g_1414[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_1507[i][j][k], "g_1507[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1587, "g_1587", print_hash_value);
    transparent_crc(g_1610.f0, "g_1610.f0", print_hash_value);
    transparent_crc(g_1682.f0, "g_1682.f0", print_hash_value);
    transparent_crc(g_1686.f0, "g_1686.f0", print_hash_value);
    transparent_crc(g_1793, "g_1793", print_hash_value);
    transparent_crc(g_1807, "g_1807", print_hash_value);
    transparent_crc(g_1809, "g_1809", print_hash_value);
    transparent_crc(g_1947.f0, "g_1947.f0", print_hash_value);
    transparent_crc(g_1956, "g_1956", print_hash_value);
    transparent_crc(g_1959, "g_1959", print_hash_value);
    transparent_crc(g_1973, "g_1973", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2005[i].f0, "g_2005[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2040, "g_2040", print_hash_value);
    transparent_crc(g_2129, "g_2129", print_hash_value);
    transparent_crc(g_2130, "g_2130", print_hash_value);
    transparent_crc(g_2131, "g_2131", print_hash_value);
    transparent_crc(g_2133, "g_2133", print_hash_value);
    transparent_crc(g_2134, "g_2134", print_hash_value);
    transparent_crc(g_2135, "g_2135", print_hash_value);
    transparent_crc(g_2174.f0, "g_2174.f0", print_hash_value);
    transparent_crc(g_2183.f0, "g_2183.f0", print_hash_value);
    transparent_crc(g_2184.f0, "g_2184.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_2205[i][j].f0, "g_2205[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2208, "g_2208", print_hash_value);
    transparent_crc(g_2249, "g_2249", print_hash_value);
    transparent_crc(g_2271.f0, "g_2271.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_2273[i][j][k].f0, "g_2273[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2274.f0, "g_2274.f0", print_hash_value);
    transparent_crc(g_2275.f0, "g_2275.f0", print_hash_value);
    transparent_crc(g_2276, "g_2276", print_hash_value);
    transparent_crc(g_2283.f0, "g_2283.f0", print_hash_value);
    transparent_crc(g_2308, "g_2308", print_hash_value);
    transparent_crc(g_2311.f0, "g_2311.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2471[i].f0, "g_2471[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2549.f0, "g_2549.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 614
XXX total union variables: 53

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 20
breakdown:
   indirect level: 0, occurrence: 20
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 28
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 56
breakdown:
   depth: 1, occurrence: 158
   depth: 2, occurrence: 44
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 3
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 19, occurrence: 5
   depth: 20, occurrence: 3
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 31, occurrence: 2
   depth: 33, occurrence: 1
   depth: 37, occurrence: 2
   depth: 39, occurrence: 2
   depth: 43, occurrence: 1
   depth: 56, occurrence: 1

XXX total number of pointers: 519

XXX times a variable address is taken: 1373
XXX times a pointer is dereferenced on RHS: 259
breakdown:
   depth: 1, occurrence: 203
   depth: 2, occurrence: 50
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
XXX times a pointer is dereferenced on LHS: 280
breakdown:
   depth: 1, occurrence: 262
   depth: 2, occurrence: 10
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 55
XXX times a pointer is compared with address of another variable: 7
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 7219

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1240
   level: 2, occurrence: 180
   level: 3, occurrence: 42
   level: 4, occurrence: 36
   level: 5, occurrence: 1
XXX number of pointers point to pointers: 209
XXX number of pointers point to scalars: 292
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 34.7
XXX average alias set size: 1.47

XXX times a non-volatile is read: 1982
XXX times a non-volatile is write: 855
XXX times a volatile is read: 140
XXX    times read thru a pointer: 33
XXX times a volatile is write: 31
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5.11e+03
XXX percentage of non-volatile access: 94.3

XXX forward jumps: 4
XXX backward jumps: 5

XXX stmts: 169
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 29
   depth: 2, occurrence: 25
   depth: 3, occurrence: 26
   depth: 4, occurrence: 29
   depth: 5, occurrence: 27

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

